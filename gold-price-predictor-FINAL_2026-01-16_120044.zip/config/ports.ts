/**
 * Port Configuration - Extracted from Nginx Configuration
 * Source: D:\Ai_Project\nginx\conf.d\default.conf
 * 
 * All AI Projects follow this port pattern:
 * - Project N: Backend N001, Frontend N501, DB N+2502, ML N101, AI N601
 */

export const PORTS = {
  // Gold Price Predictor (Project 2)
  GOLD: {
    BACKEND: 2001,
    FRONTEND: 2501,
    DATABASE: 4502,     // PostgreSQL: 4502 (internal 5432)
    ML: 2101,           // Machine Learning service
    AI: 2601,           // AI/RAG service
    REDIS: 6372,        // Redis cache
    TRPC: 2505,         // tRPC server (additional)
    PYTHON_ML: 2005,    // Python ML backend (additional)
  },

  // Other Projects (for reference)
  TEST: {
    BACKEND: 1001,
    FRONTEND: 1501,
  },
  ZAKAT: {
    BACKEND: 3001,
    FRONTEND: 3501,
    DATABASE: 6502,
    REDIS: 6373,
  },
  SCAN: {
    BACKEND: 4001,
    FRONTEND: 4501,
    DATABASE: 8502,
    ML: 4101,
    AI: 4601,
    REDIS: 6374,
  },
  ERP: {
    BACKEND: 5001,
    FRONTEND: 5501,
    DATABASE: 10502,
    REDIS: 6375,
  },
  STORE: {
    BACKEND: 6001,
    FRONTEND: 6501,
    DATABASE: 12502,
    REDIS: 6376,
  },

  // Infrastructure
  INFRA: {
    NGINX_HTTP: 80,
    NGINX_HTTPS: 443,
    NGINX_CONFIG: 8181,
    PORTAINER_HTTP: 9000,
    PORTAINER_HTTPS: 9443,
  },
} as const;

// Currently running ports (from Docker)
export const DOCKER_PORTS = {
  FRONTEND: 2506,      // gold-predictor-frontend
  TRPC: 2505,          // gold-predictor-trpc-server
  BACKEND: 2005,       // gold-predictor-backend (Python)
  POSTGRES: 5434,      // gold-predictor-postgres
  REDIS: 6372,         // gold-price-predictor-redis
  PGADMIN: 5050,       // pgAdmin
} as const;

// Test URLs
export const TEST_URLS = {
  FRONTEND: `http://localhost:${DOCKER_PORTS.FRONTEND}`,
  BACKEND: `http://localhost:${DOCKER_PORTS.TRPC}`,
  PYTHON_ML: `http://localhost:${DOCKER_PORTS.BACKEND}`,
} as const;

// Health check endpoints
export const HEALTH_ENDPOINTS = {
  TRPC: '/api/health',
  PYTHON: '/health',
  NGINX: '/health',
} as const;

export default PORTS;
