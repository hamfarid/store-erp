"""
سكريبت تشغيل Dashboard
Run Dashboard Script
"""

import subprocess
import sys
import os

def main():
    print("=" * 80)
    print("🚀 Starting Gold Price Predictor Dashboard...")
    print("=" * 80)
    print()
    print("📊 Dashboard will open in your browser automatically")
    print("   URL: http://localhost:8501")
    print()
    print("Press CTRL+C to stop the dashboard")
    print("=" * 80)
    print()
    
    # تشغيل Streamlit
    dashboard_path = os.path.join(os.path.dirname(__file__), 'dashboard', 'app.py')
    
    subprocess.run([
        sys.executable, '-m', 'streamlit', 'run',
        dashboard_path,
        '--server.port=8501',
        '--server.address=0.0.0.0',
        '--browser.gatherUsageStats=false'
    ])

if __name__ == "__main__":
    main()

