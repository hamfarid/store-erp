# FILE: backend/run_tests.py | PURPOSE: Test runner script with coverage reporting | OWNER: Backend Team | RELATED: pytest.ini, .coveragerc | LAST-AUDITED: 2025-01-18

"""
Comprehensive test runner for backend tests
Runs all tests with coverage reporting and generates HTML report
"""

import sys
import subprocess
from pathlib import Path


def run_tests(test_type="all", coverage=True, verbose=True):
    """
    Run tests with optional coverage reporting
    
    Args:
        test_type: Type of tests to run (all, unit, integration, crud)
        coverage: Whether to generate coverage report
        verbose: Verbose output
    """
    
    # Base command
    cmd = ["pytest"]
    
    # Add coverage if requested
    if coverage:
        cmd.extend([
            "--cov=app",
            "--cov-report=html",
            "--cov-report=term-missing",
            "--cov-report=json",
            f"--cov-fail-under=80"  # Fail if coverage < 80%
        ])
    
    # Add verbosity
    if verbose:
        cmd.append("-v")
    
    # Add test selection
    if test_type == "unit":
        cmd.append("app/tests/test_*_crud.py")
    elif test_type == "integration":
        cmd.append("app/tests/test_integration.py")
    elif test_type == "security":
        cmd.extend([
            "app/tests/test_csrf_protection.py",
            "app/tests/test_jwt_rotation.py",
            "app/tests/test_account_lockout.py"
        ])
    elif test_type == "crud":
        cmd.extend([
            "app/tests/test_users_crud.py",
            "app/tests/test_assets_crud.py"
        ])
    else:  # all
        cmd.append("app/tests/")
    
    # Add markers
    cmd.extend([
        "-m", "not slow",  # Skip slow tests by default
        "--tb=short",  # Short traceback format
        "--strict-markers",  # Strict marker checking
    ])
    
    print(f"Running tests: {' '.join(cmd)}")
    print("=" * 80)
    
    # Run tests
    result = subprocess.run(cmd, cwd=Path(__file__).parent)
    
    if result.returncode == 0:
        print("\n" + "=" * 80)
        print("✅ All tests passed!")
        if coverage:
            print("📊 Coverage report generated in htmlcov/index.html")
    else:
        print("\n" + "=" * 80)
        print("❌ Some tests failed!")
        sys.exit(1)
    
    return result.returncode


def run_coverage_only():
    """Generate coverage report without running tests"""
    cmd = ["coverage", "html"]
    subprocess.run(cmd, cwd=Path(__file__).parent)
    print("📊 Coverage report generated in htmlcov/index.html")


def run_specific_test(test_file, test_name=None):
    """Run a specific test file or test function"""
    cmd = ["pytest", "-v"]
    
    if test_name:
        cmd.append(f"{test_file}::{test_name}")
    else:
        cmd.append(test_file)
    
    subprocess.run(cmd, cwd=Path(__file__).parent)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run backend tests")
    parser.add_argument(
        "--type",
        choices=["all", "unit", "integration", "security", "crud"],
        default="all",
        help="Type of tests to run"
    )
    parser.add_argument(
        "--no-coverage",
        action="store_true",
        help="Skip coverage reporting"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Quiet output"
    )
    parser.add_argument(
        "--file",
        type=str,
        help="Run specific test file"
    )
    parser.add_argument(
        "--test",
        type=str,
        help="Run specific test function (requires --file)"
    )
    
    args = parser.parse_args()
    
    if args.file:
        run_specific_test(args.file, args.test)
    else:
        run_tests(
            test_type=args.type,
            coverage=not args.no_coverage,
            verbose=not args.quiet
        )

