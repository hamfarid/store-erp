# /home/ubuntu/gold-price-predictor/rate_limiter.py
"""
Rate limiting system for Gold Price Predictor API
Prevents abuse and DDoS attacks using sliding window algorithm
"""

import time
from typing import Dict, Tuple
from fastapi import HTTPException, Request, status
from collections import defaultdict, deque
from config import settings


class RateLimiter:
    """
    In-memory rate limiter using sliding window algorithm
    For production, use Redis-based rate limiting
    """
    
    def __init__(self):
        # Store: {client_id: deque of timestamps}
        self.requests: Dict[str, deque] = defaultdict(deque)
        self.limits = {
            "minute": (settings.RATE_LIMIT_PER_MINUTE, 60),
            "hour": (settings.RATE_LIMIT_PER_HOUR, 3600)
        }
    
    def _get_client_id(self, request: Request) -> str:
        """Get client identifier from request"""
        # Try to get user from auth, otherwise use IP
        client_ip = request.client.host if request.client else "unknown"
        
        # If authenticated, use user ID
        if hasattr(request.state, "user"):
            return f"user_{request.state.user.id}"
        
        return f"ip_{client_ip}"
    
    def _clean_old_requests(self, timestamps: deque, window: int):
        """Remove timestamps outside the current window"""
        current_time = time.time()
        while timestamps and timestamps[0] < current_time - window:
            timestamps.popleft()
    
    def check_rate_limit(self, request: Request) -> Tuple[bool, Dict[str, int]]:
        """
        Check if request is within rate limits
        Returns: (is_allowed, remaining_counts)
        """
        client_id = self._get_client_id(request)
        current_time = time.time()
        
        # Get or create request queue for this client
        timestamps = self.requests[client_id]
        
        # Check each limit (minute, hour)
        for limit_name, (max_requests, window) in self.limits.items():
            # Clean old requests
            self._clean_old_requests(timestamps, window)
            
            # Check if limit exceeded
            if len(timestamps) >= max_requests:
                remaining = {
                    "minute": max(0, self.limits["minute"][0] - len(timestamps)),
                    "hour": max(0, self.limits["hour"][0] - len(timestamps))
                }
                return False, remaining
        
        # Add current request
        timestamps.append(current_time)
        
        # Calculate remaining requests
        remaining = {
            "minute": max(0, self.limits["minute"][0] - len(timestamps)),
            "hour": max(0, self.limits["hour"][0] - len(timestamps))
        }
        
        return True, remaining
    
    async def __call__(self, request: Request):
        """Middleware to check rate limits"""
        is_allowed, remaining = self.check_rate_limit(request)
        
        # Add rate limit headers
        request.state.rate_limit_remaining = remaining
        
        if not is_allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error": "Rate limit exceeded",
                    "message": f"Too many requests. Limit: {settings.RATE_LIMIT_PER_MINUTE}/minute",
                    "remaining": remaining,
                    "retry_after": 60
                },
                headers={
                    "X-RateLimit-Limit": str(settings.RATE_LIMIT_PER_MINUTE),
                    "X-RateLimit-Remaining": str(remaining["minute"]),
                    "Retry-After": "60"
                }
            )


# Global rate limiter instance
rate_limiter = RateLimiter()


# Dependency for routes
async def check_rate_limit(request: Request):
    """Dependency to check rate limits"""
    await rate_limiter(request)

