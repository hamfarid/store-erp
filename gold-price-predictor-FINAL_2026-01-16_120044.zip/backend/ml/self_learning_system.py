"""
Self-Learning System for Asset Price Prediction
- Compares predictions with actual prices
- Searches for influencing events
- Retrains models with new data
- Stores lessons learned
"""

import json
import pickle
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
import yfinance as yf

# Paths
MODELS_DIR = Path("models/recent")
DATA_DIR = Path("data")
LESSONS_FILE = DATA_DIR / "lessons_learned.json"

# Asset mapping
ASSET_SYMBOLS = {
    1: "GC=F",      # Gold
    2: "SI=F",      # Silver
    3: "CL=F",      # Oil WTI
    4: "BZ=F",      # Brent
    5: "PL=F",      # Platinum
    6: "PA=F",      # Palladium
    7: "HG=F",      # Copper
    8: "NG=F",      # Natural Gas
    9: "BTC-USD",   # Bitcoin
    10: "ETH-USD",  # Ethereum
    11: "TRY=X",    # TRY/USD
    12: "EGP=X",    # EGP/USD
    13: "EUR=X",    # EUR/USD
    14: "DX-Y.NYB", # USD Index
    15: "SAR=X",    # SAR/USD
    16: "AED=X",    # AED/USD
    17: "OMR=X"     # OMR/USD
}

ASSET_NAMES = {
    1: "Gold", 2: "Silver", 3: "Oil WTI", 4: "Brent", 
    5: "Platinum", 6: "Palladium", 7: "Copper", 8: "Natural Gas",
    9: "Bitcoin", 10: "Ethereum", 11: "TRY/USD", 12: "EGP/USD",
    13: "EUR/USD", 14: "USD Index", 15: "SAR/USD", 16: "AED/USD", 17: "OMR/USD"
}

class SelfLearningSystem:
    def __init__(self):
        self.lessons = self.load_lessons()
        
    def load_lessons(self):
        """Load lessons learned from previous iterations"""
        if LESSONS_FILE.exists():
            with open(LESSONS_FILE, 'r') as f:
                return json.load(f)
        return {"lessons": [], "total_iterations": 0, "improvements": []}
    
    def save_lessons(self):
        """Save lessons learned"""
        LESSONS_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LESSONS_FILE, 'w') as f:
            json.dump(self.lessons, f, indent=2, default=str)
    
    def get_actual_price(self, asset_id):
        """Get current actual price from Yahoo Finance"""
        try:
            symbol = ASSET_SYMBOLS.get(asset_id)
            if not symbol:
                return None
            
            ticker = yf.Ticker(symbol)
            data = ticker.history(period="1d")
            
            if data.empty:
                return None
            
            return float(data['Close'].iloc[-1])
        except Exception as e:
            print(f"Error getting actual price for asset {asset_id}: {e}")
            return None
    
    def search_influencing_events(self, asset_name, price_change_pct):
        """Search for events that may have influenced the price change"""
        events = []
        
        # Heuristic-based event detection
        # TODO: Integrate with real news APIs
        
        if abs(price_change_pct) > 5:
            events.append({
                "type": "large_movement",
                "description": f"Significant price movement detected: {price_change_pct:.2f}%",
                "severity": "high"
            })
        
        if price_change_pct > 3:
            events.append({
                "type": "bullish_sentiment",
                "description": f"Possible bullish sentiment or positive news for {asset_name}",
                "severity": "medium"
            })
        elif price_change_pct < -3:
            events.append({
                "type": "bearish_sentiment",
                "description": f"Possible bearish sentiment or negative news for {asset_name}",
                "severity": "medium"
            })
        
        # Asset-specific events
        if "Gold" in asset_name or "Silver" in asset_name:
            if abs(price_change_pct) > 2:
                events.append({
                    "type": "precious_metals",
                    "description": "Precious metals affected by inflation concerns or safe-haven demand",
                    "severity": "medium"
                })
        
        elif "Bitcoin" in asset_name or "Ethereum" in asset_name:
            if abs(price_change_pct) > 5:
                events.append({
                    "type": "cryptocurrency",
                    "description": "Cryptocurrency prices affected by regulatory news or market sentiment",
                    "severity": "high"
                })
        
        elif "Oil" in asset_name or "Brent" in asset_name:
            if abs(price_change_pct) > 3:
                events.append({
                    "type": "oil_market",
                    "description": "Oil prices affected by OPEC decisions or geopolitical events",
                    "severity": "high"
                })
        
        return events
    
    def calculate_error_metrics(self, predicted, actual, confidence_level):
        """Calculate error metrics"""
        error = actual - predicted
        percent_error = (error / predicted) * 100
        absolute_percent_error = abs(percent_error)
        
        # Accuracy considering confidence level
        accuracy = 1 - (absolute_percent_error / 100)
        
        # Check if within confidence interval (simplified)
        confidence_margin = predicted * (1 - confidence_level) * 0.5
        within_confidence = abs(error) <= confidence_margin
        
        return {
            "error": error,
            "percent_error": percent_error,
            "absolute_percent_error": absolute_percent_error,
            "accuracy": max(0, accuracy),
            "within_confidence": within_confidence
        }
    
    def retrain_model(self, asset_id, new_data_point):
        """Retrain model with new data point"""
        try:
            symbol = ASSET_SYMBOLS.get(asset_id)
            asset_name = ASSET_NAMES.get(asset_id, f"Asset_{asset_id}")
            
            print(f"[Self-Learning] Retraining model for {asset_name}...")
            
            # Download recent data
            ticker = yf.Ticker(symbol)
            df = ticker.history(period="2y")
            
            if df.empty:
                print(f"[Self-Learning] No data available for {asset_name}")
                return False
            
            # Add new data point
            new_row = pd.DataFrame({
                'Close': [new_data_point['actual_price']],
                'Open': [new_data_point['actual_price']],
                'High': [new_data_point['actual_price']],
                'Low': [new_data_point['actual_price']],
                'Volume': [df['Volume'].mean()]
            }, index=[datetime.now()])
            
            df = pd.concat([df, new_row])
            
            # Create features
            df['lag_1'] = df['Close'].shift(1)
            df['lag_7'] = df['Close'].shift(7)
            df['lag_30'] = df['Close'].shift(30)
            df['ma_7'] = df['Close'].rolling(window=7).mean()
            df['ma_30'] = df['Close'].rolling(window=30).mean()
            df['volatility'] = df['Close'].rolling(window=7).std()
            
            # Drop NaN
            df = df.dropna()
            
            if len(df) < 100:
                print(f"[Self-Learning] Insufficient data for {asset_name}")
                return False
            
            # Prepare training data
            feature_cols = ['lag_1', 'lag_7', 'lag_30', 'ma_7', 'ma_30', 'volatility']
            X = df[feature_cols].values
            y = df['Close'].values
            
            # Train model
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            model = Ridge(alpha=1.0)
            model.fit(X_scaled, y)
            
            # Calculate training accuracy
            y_pred = model.predict(X_scaled)
            train_accuracy = 1 - np.mean(np.abs((y - y_pred) / y))
            
            print(f"[Self-Learning] New model accuracy: {train_accuracy:.4f}")
            
            # Save model
            model_path = MODELS_DIR / f"{asset_name.lower().replace(' ', '_')}_model.pkl"
            scaler_path = MODELS_DIR / f"{asset_name.lower().replace(' ', '_')}_scaler.pkl"
            
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            
            with open(model_path, 'wb') as f:
                pickle.dump(model, f)
            
            with open(scaler_path, 'wb') as f:
                pickle.dump(scaler, f)
            
            print(f"[Self-Learning] Model saved: {model_path}")
            
            return True
            
        except Exception as e:
            print(f"[Self-Learning] Error retraining model: {e}")
            return False
    
    def learn_from_prediction(self, prediction_data):
        """
        Learn from a prediction by comparing with actual price
        
        Args:
            prediction_data: {
                "asset_id": int,
                "predicted_price": float,
                "confidence_level": float,
                "prediction_time": str (ISO format),
                "target_time": str (ISO format)
            }
        """
        asset_id = prediction_data["asset_id"]
        asset_name = ASSET_NAMES.get(asset_id, f"Asset_{asset_id}")
        predicted_price = prediction_data["predicted_price"]
        confidence_level = prediction_data["confidence_level"]
        
        print(f"\n[Self-Learning] Analyzing prediction for {asset_name}")
        print(f"[Self-Learning] Predicted: ${predicted_price:.2f}")
        
        # Get actual price
        actual_price = self.get_actual_price(asset_id)
        
        if actual_price is None:
            print(f"[Self-Learning] Could not get actual price for {asset_name}")
            return None
        
        print(f"[Self-Learning] Actual: ${actual_price:.2f}")
        
        # Calculate error metrics
        metrics = self.calculate_error_metrics(predicted_price, actual_price, confidence_level)
        
        print(f"[Self-Learning] Error: {metrics['percent_error']:.2f}%")
        print(f"[Self-Learning] Accuracy: {metrics['accuracy']*100:.2f}%")
        print(f"[Self-Learning] Within confidence: {metrics['within_confidence']}")
        
        # Search for influencing events
        events = self.search_influencing_events(asset_name, metrics['percent_error'])
        
        if events:
            print(f"[Self-Learning] Found {len(events)} influencing events:")
            for event in events:
                print(f"  - {event['description']} (severity: {event['severity']})")
        
        # Create lesson
        lesson = {
            "timestamp": datetime.now().isoformat(),
            "asset_id": asset_id,
            "asset_name": asset_name,
            "predicted_price": predicted_price,
            "actual_price": actual_price,
            "error_metrics": metrics,
            "influencing_events": events,
            "confidence_level": confidence_level,
            "retrained": False
        }
        
        # Decide if retraining is needed
        should_retrain = (
            metrics['accuracy'] < 0.80 or  # Accuracy below 80%
            not metrics['within_confidence'] or  # Outside confidence interval
            abs(metrics['percent_error']) > 5  # Error > 5%
        )
        
        if should_retrain:
            print(f"[Self-Learning] Retraining needed for {asset_name}")
            success = self.retrain_model(asset_id, {
                "actual_price": actual_price,
                "timestamp": datetime.now()
            })
            lesson["retrained"] = success
            
            if success:
                self.lessons["improvements"].append({
                    "timestamp": datetime.now().isoformat(),
                    "asset_name": asset_name,
                    "old_accuracy": metrics['accuracy'],
                    "reason": f"Error {metrics['percent_error']:.2f}% exceeded threshold"
                })
        
        # Save lesson
        self.lessons["lessons"].append(lesson)
        self.lessons["total_iterations"] += 1
        self.save_lessons()
        
        print(f"[Self-Learning] Lesson saved. Total iterations: {self.lessons['total_iterations']}")
        
        return lesson

# Example usage
if __name__ == "__main__":
    system = SelfLearningSystem()
    
    # Example: Learn from a gold prediction
    prediction = {
        "asset_id": 1,
        "predicted_price": 4216.0,
        "confidence_level": 0.95,
        "prediction_time": datetime.now().isoformat(),
        "target_time": (datetime.now() + timedelta(days=1)).isoformat()
    }
    
    lesson = system.learn_from_prediction(prediction)
    
    if lesson:
        print("\n" + "="*50)
        print("LESSON LEARNED:")
        print(json.dumps(lesson, indent=2, default=str))

