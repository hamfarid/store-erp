"""
إعادة تدريب نموذج الذهب باستخدام البيانات الموسعة
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib
import json

# إضافة المسار الجذر للمشروع
ROOT_DIR = Path(__file__).parent
sys.path.append(str(ROOT_DIR))


def train_gold_model():
    """إعادة تدريب نموذج الذهب"""
    
    print("=" * 60)
    print("إعادة تدريب نموذج الذهب")
    print("=" * 60)
    
    # قراءة البيانات
    data_file = ROOT_DIR / 'data' / 'processed' / 'extended_dataset.csv'
    
    if not data_file.exists():
        print(f"❌ ملف البيانات غير موجود: {data_file}")
        return False
    
    print(f"\n📂 قراءة البيانات من: {data_file.name}")
    df = pd.read_csv(data_file)
    
    print(f"✅ تم قراءة {len(df)} صف و {len(df.columns)} عمود")
    
    # تحديد الميزات والهدف
    target = 'Gold_Price'
    
    # الميزات المتاحة للذهب
    feature_cols = [
        'Silver_Price',
        'Oil_Price',
        'SP500',
        'CPI',
        'Interest_Rate',
        'Gold_MA7',
        'Gold_MA30',
        'Gold_Daily_Change',
        'Gold_Volatility'
    ]
    
    # التحقق من وجود جميع الأعمدة
    missing_cols = [col for col in feature_cols + [target] if col not in df.columns]
    if missing_cols:
        print(f"❌ الأعمدة المفقودة: {missing_cols}")
        return False
    
    # استخراج الميزات والهدف
    X = df[feature_cols].copy()
    y = df[target].copy()
    
    # إزالة القيم المفقودة
    mask = X.notna().all(axis=1) & y.notna()
    X = X[mask]
    y = y[mask]
    
    print(f"\n✅ عدد الصفوف بعد إزالة القيم المفقودة: {len(X)}")
    print(f"✅ الميزات المستخدمة: {len(feature_cols)}")
    
    # تقسيم البيانات
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\n📊 حجم بيانات التدريب: {len(X_train)}")
    print(f"📊 حجم بيانات الاختبار: {len(X_test)}")
    
    # تطبيع البيانات
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب النماذج المختلفة
    models = {
        'gradient_boosting': GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=5,
            random_state=42
        ),
        'random_forest': RandomForestRegressor(
            n_estimators=200,
            max_depth=15,
            random_state=42
        ),
        'svr': SVR(
            kernel='rbf',
            C=100,
            gamma='scale'
        )
    }
    
    results = {}
    
    print("\n" + "=" * 60)
    print("تدريب النماذج")
    print("=" * 60)
    
    for name, model in models.items():
        print(f"\n🔄 تدريب نموذج {name}...")
        
        # تدريب
        model.fit(X_train_scaled, y_train)
        
        # التنبؤ
        y_pred = model.predict(X_test_scaled)
        
        # حساب المقاييس
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        
        results[name] = {
            'model': model,
            'rmse': rmse,
            'r2': r2,
            'mae': mae
        }
        
        print(f"✅ RMSE: {rmse:.2f}")
        print(f"✅ R²: {r2:.4f}")
        print(f"✅ MAE: {mae:.2f}")
    
    # اختيار أفضل نموذج
    best_model_name = max(results.keys(), key=lambda k: results[k]['r2'])
    best_model_info = results[best_model_name]
    
    print("\n" + "=" * 60)
    print("أفضل نموذج")
    print("=" * 60)
    print(f"🏆 النموذج: {best_model_name}")
    print(f"✅ RMSE: {best_model_info['rmse']:.2f}")
    print(f"✅ R²: {best_model_info['r2']:.4f}")
    print(f"✅ MAE: {best_model_info['mae']:.2f}")
    
    # حفظ النموذج
    model_dir = ROOT_DIR / 'models'
    model_dir.mkdir(exist_ok=True)
    
    model_file = model_dir / f'best_model_{best_model_name}.pkl'
    scaler_file = model_dir / 'scaler.pkl'
    features_file = model_dir / 'feature_names.pkl'
    info_file = model_dir / 'model_info.json'
    
    print(f"\n💾 حفظ النموذج...")
    
    joblib.dump(best_model_info['model'], model_file)
    joblib.dump(scaler, scaler_file)
    joblib.dump(feature_cols, features_file)
    
    # حفظ معلومات النموذج
    model_info = {
        'model_type': best_model_name,
        'rmse': float(best_model_info['rmse']),
        'r2': float(best_model_info['r2']),
        'mae': float(best_model_info['mae']),
        'features': feature_cols,
        'target': target,
        'train_size': len(X_train),
        'test_size': len(X_test)
    }
    
    with open(info_file, 'w', encoding='utf-8') as f:
        json.dump(model_info, f, indent=2, ensure_ascii=False)
    
    print(f"✅ تم حفظ النموذج: {model_file.name}")
    print(f"✅ تم حفظ المعايير: {scaler_file.name}")
    print(f"✅ تم حفظ الميزات: {features_file.name}")
    print(f"✅ تم حفظ المعلومات: {info_file.name}")
    
    print("\n" + "=" * 60)
    print("✅ اكتمل التدريب بنجاح!")
    print("=" * 60)
    
    return True


def main():
    """الدالة الرئيسية"""
    success = train_gold_model()
    
    if not success:
        print("\n❌ فشل التدريب")
        sys.exit(1)


if __name__ == '__main__':
    main()

