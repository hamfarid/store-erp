#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final Model Training System
نظام التدريب النهائي للنماذج

Uses:
- Time series split (no shuffling)
- Proper feature selection
- Regularization
- Same hyperparameters as successful old models
"""

import os
import sys
import pickle
import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import json
from datetime import datetime

warnings.filterwarnings('ignore')


def load_and_prepare_data():
    """
    تحميل وتحضير البيانات
    """
    data_path = 'data/extended_dataset.csv'
    
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return None
    
    print(f"📂 Loading data from {data_path}...")
    df = pd.read_csv(data_path)
    
    # تحويل Date إلى datetime
    df['Date'] = pd.to_datetime(df['Date'])
    
    # ترتيب حسب التاريخ
    df = df.sort_values('Date').reset_index(drop=True)
    
    print(f"📊 Loaded {len(df)} rows")
    print(f"📅 Date range: {df['Date'].min()} to {df['Date'].max()}")
    
    return df


def select_features_smart(df, target_col):
    """
    اختيار الميزات بذكاء بناءً على الارتباط
    """
    # الميزات الأساسية
    base_features = [
        'Gold_Price', 'Silver_Price', 'Oil_Price', 'SP500',
        'CPI', 'Interest_Rate', 'DXY_Index'
    ]
    
    # ميزات متقدمة حسب الأصل
    if target_col == 'Gold_Price':
        extra_features = ['Gold_MA7', 'Gold_MA30', 'Gold_Volatility']
    elif target_col == 'BTC_Price':
        extra_features = ['BTC_MA7', 'BTC_MA30', 'BTC_Volatility', 'ETH_Price']
    elif target_col == 'ETH_Price':
        extra_features = ['ETH_MA7', 'ETH_MA30', 'ETH_Volatility', 'BTC_Price']
    elif target_col == 'TRY_USD':
        extra_features = ['TRY_USD_MA7', 'TRY_USD_MA30', 'EUR_USD']
    elif target_col == 'EGP_USD':
        extra_features = ['EGP_USD_MA7', 'EGP_USD_MA30', 'EUR_USD']
    else:
        extra_features = []
    
    # دمج الميزات
    all_features = base_features + extra_features
    
    # إزالة العمود المستهدف والميزات غير الموجودة
    features = [f for f in all_features if f != target_col and f in df.columns]
    
    return features


def train_asset_model(df, asset_name, target_col, model_params):
    """
    تدريب نموذج لأصل معين
    """
    print(f"\n{'='*80}")
    print(f"🔧 Training {asset_name}")
    print(f"{'='*80}")
    
    # اختيار الميزات
    features = select_features_smart(df, target_col)
    
    print(f"🔧 Selected {len(features)} features")
    
    # تحضير البيانات
    df_clean = df[[target_col] + features].copy()
    df_clean = df_clean.dropna()
    
    if len(df_clean) < 100:
        print(f"❌ Not enough data: {len(df_clean)} rows")
        return None
    
    print(f"📊 Using {len(df_clean)} rows")
    
    X = df_clean[features].values
    y = df_clean[target_col].values
    
    # Time series split (80% train, 20% test)
    split_idx = int(0.8 * len(X))
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"📊 Train: {len(X_train)}, Test: {len(X_test)}")
    
    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب النموذج
    model_type = model_params.get('type', 'GradientBoosting')
    
    if model_type == 'RandomForest':
        print(f"🚀 Training RandomForestRegressor...")
        model = RandomForestRegressor(
            n_estimators=model_params.get('n_estimators', 200),
            max_depth=model_params.get('max_depth', 10),
            min_samples_split=model_params.get('min_samples_split', 2),
            min_samples_leaf=model_params.get('min_samples_leaf', 1),
            random_state=42,
            n_jobs=-1
        )
    else:
        print(f"🚀 Training GradientBoostingRegressor...")
        model = GradientBoostingRegressor(
            n_estimators=model_params.get('n_estimators', 200),
            learning_rate=model_params.get('learning_rate', 0.1),
            max_depth=model_params.get('max_depth', 5),
            min_samples_split=model_params.get('min_samples_split', 5),
            random_state=42
        )
    
    model.fit(X_train_scaled, y_train)
    
    # التقييم
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mae = mean_absolute_error(y_test, y_test_pred)
    test_mape = np.mean(np.abs((y_test - y_test_pred) / (y_test + 1e-10))) * 100
    
    print(f"\n📊 Performance:")
    print(f"   Train R²: {train_r2:.4f}")
    print(f"   Test R²: {test_r2:.4f}")
    print(f"   RMSE: {test_rmse:.4f}")
    print(f"   MAE: {test_mae:.4f}")
    print(f"   MAPE: {test_mape:.2f}%")
    
    # حفظ النموذج
    os.makedirs('models', exist_ok=True)
    
    model_path = f'models/{asset_name}_model_v5.pkl'
    scaler_path = f'models/{asset_name}_scaler_v5.pkl'
    features_path = f'models/{asset_name}_features_v5.pkl'
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f, protocol=2)
    
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f, protocol=2)
    
    with open(features_path, 'wb') as f:
        pickle.dump(features, f, protocol=2)
    
    print(f"✅ Saved to {model_path}")
    
    # حفظ معلومات النموذج
    info = {
        'asset': asset_name,
        'target_col': target_col,
        'model_type': model_type,
        'features': features,
        'n_features': len(features),
        'train_r2': float(train_r2),
        'test_r2': float(test_r2),
        'test_rmse': float(test_rmse),
        'test_mae': float(test_mae),
        'test_mape': float(test_mape),
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'model_params': model_params,
        'timestamp': datetime.now().isoformat()
    }
    
    info_path = f'models/{asset_name}_info_v5.json'
    with open(info_path, 'w') as f:
        json.dump(info, f, indent=2)
    
    return info


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🚀 Final Model Training System")
    print("="*80)
    
    # تحميل البيانات
    df = load_and_prepare_data()
    
    if df is None:
        return
    
    # تعريف الأصول والمعاملات (من النماذج القديمة الناجحة)
    assets = {
        'Gold': {
            'target': 'Gold_Price',
            'params': {
                'type': 'GradientBoosting',
                'n_estimators': 200,
                'learning_rate': 0.1,
                'max_depth': 5,
                'min_samples_split': 5
            }
        },
        'Bitcoin': {
            'target': 'BTC_Price',
            'params': {
                'type': 'GradientBoosting',
                'n_estimators': 200,
                'learning_rate': 0.1,
                'max_depth': 5,
                'min_samples_split': 5
            }
        },
        'Ethereum': {
            'target': 'ETH_Price',
            'params': {
                'type': 'GradientBoosting',
                'n_estimators': 200,
                'learning_rate': 0.1,
                'max_depth': 5,
                'min_samples_split': 2
            }
        },
        'TRY_USD': {
            'target': 'TRY_USD',
            'params': {
                'type': 'GradientBoosting',
                'n_estimators': 200,
                'learning_rate': 0.1,
                'max_depth': 5,
                'min_samples_split': 2
            }
        },
        'EGP_USD': {
            'target': 'EGP_USD',
            'params': {
                'type': 'RandomForest',
                'n_estimators': 200,
                'max_depth': 10,
                'min_samples_split': 2,
                'min_samples_leaf': 1
            }
        }
    }
    
    results = {}
    
    for asset_name, config in assets.items():
        target_col = config['target']
        params = config['params']
        
        if target_col in df.columns:
            info = train_asset_model(df, asset_name, target_col, params)
            if info:
                results[asset_name] = info
        else:
            print(f"⚠️ Column {target_col} not found")
    
    # حفظ ملخص
    summary_path = 'models/training_summary_v5_final.json'
    with open(summary_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*80}")
    print("✅ Training completed!")
    print(f"💾 Summary: {summary_path}")
    print(f"{'='*80}")
    
    # عرض ملخص
    print(f"\n📊 Final Results:")
    print(f"{'Asset':<15} {'R²':<10} {'RMSE':<12} {'MAPE':<10} {'Status':<10}")
    print(f"{'-'*60}")
    
    for asset, info in results.items():
        r2 = info['test_r2']
        rmse = info['test_rmse']
        mape = info['test_mape']
        
        if r2 >= 0.95:
            status = "✅ Excellent"
        elif r2 >= 0.80:
            status = "⚠️ Good"
        elif r2 >= 0.50:
            status = "⚠️ Fair"
        else:
            status = "❌ Poor"
        
        print(f"{asset:<15} {r2:<10.4f} {rmse:<12.2f} {mape:<10.2f}% {status:<10}")


if __name__ == '__main__':
    main()

