#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Retrain All Models V5
إعادة تدريب جميع النماذج مع الميزات المحسّنة
"""

import os
import sys
import pickle
import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import json

warnings.filterwarnings('ignore')

# إضافة المسارات
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class OptimizedFeatureEngineer:
    """
    نظام هندسة الميزات المحسّن
    """
    
    def add_basic_features(self, df: pd.DataFrame, price_col: str) -> pd.DataFrame:
        """
        إضافة الميزات الأساسية فقط
        """
        # Moving Averages
        df[f'{price_col}_MA7'] = df[price_col].rolling(window=7, min_periods=1).mean()
        df[f'{price_col}_MA30'] = df[price_col].rolling(window=30, min_periods=1).mean()
        
        # Price Changes
        df[f'{price_col}_Change'] = df[price_col].diff()
        df[f'{price_col}_PctChange'] = df[price_col].pct_change()
        
        # Volatility
        df[f'{price_col}_Volatility'] = df[price_col].rolling(window=7, min_periods=1).std()
        
        # RSI
        delta = df[price_col].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14, min_periods=1).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14, min_periods=1).mean()
        rs = gain / (loss + 1e-10)
        df[f'{price_col}_RSI'] = 100 - (100 / (1 + rs))
        
        # MACD
        exp1 = df[price_col].ewm(span=12, adjust=False).mean()
        exp2 = df[price_col].ewm(span=26, adjust=False).mean()
        df[f'{price_col}_MACD'] = exp1 - exp2
        
        # Bollinger Bands
        rolling_mean = df[price_col].rolling(window=20, min_periods=1).mean()
        rolling_std = df[price_col].rolling(window=20, min_periods=1).std()
        df[f'{price_col}_BB_Width'] = rolling_std * 2
        
        # Time features
        if 'Date' in df.columns:
            df['DayOfWeek'] = pd.to_datetime(df['Date']).dt.dayofweek
            df['Month'] = pd.to_datetime(df['Date']).dt.month
            df['Quarter'] = pd.to_datetime(df['Date']).dt.quarter
        
        # تنظيف NaN
        df = df.fillna(method='ffill').fillna(method='bfill').fillna(0)
        
        return df
    
    def get_feature_names(self, price_col: str) -> list:
        """
        الحصول على أسماء الميزات
        """
        return [
            f'{price_col}_MA7',
            f'{price_col}_MA30',
            f'{price_col}_Change',
            f'{price_col}_PctChange',
            f'{price_col}_Volatility',
            f'{price_col}_RSI',
            f'{price_col}_MACD',
            f'{price_col}_BB_Width',
            'DayOfWeek',
            'Month',
            'Quarter'
        ]


def load_data(asset_name: str, price_col: str) -> pd.DataFrame:
    """
    تحميل البيانات
    """
    # محاولة تحميل من merged_data.csv
    if os.path.exists('data/merged_data.csv'):
        df = pd.read_csv('data/merged_data.csv')
        if 'Date' not in df.columns and df.index.name == 'Date':
            df = df.reset_index()
        
        # التأكد من وجود عمود السعر
        if price_col in df.columns:
            return df
    
    # محاولة تحميل من Yahoo Finance
    try:
        import yfinance as yf
        
        symbols = {
            'Gold': 'GC=F',
            'Bitcoin': 'BTC-USD',
            'Ethereum': 'ETH-USD',
            'TRY_USD': 'TRY=X',
            'EGP_USD': 'EGP=X'
        }
        
        if asset_name in symbols:
            symbol = symbols[asset_name]
            ticker = yf.Ticker(symbol)
            df = ticker.history(period='2y')
            df = df.reset_index()
            df.columns = ['Date'] + list(df.columns[1:])
            df[price_col] = df['Close']
            return df
    except:
        pass
    
    return None


def train_model(asset_name: str, price_col: str):
    """
    تدريب نموذج لأصل معين
    """
    print(f"\n{'='*80}")
    print(f"🔧 Training model for {asset_name}")
    print(f"{'='*80}")
    
    # تحميل البيانات
    df = load_data(asset_name, price_col)
    
    if df is None or df.empty:
        print(f"❌ No data available for {asset_name}")
        return None
    
    print(f"📊 Loaded {len(df)} rows")
    
    # إضافة الميزات
    engineer = OptimizedFeatureEngineer()
    df = engineer.add_basic_features(df, price_col)
    feature_names = engineer.get_feature_names(price_col)
    
    print(f"🔧 Added {len(feature_names)} features")
    
    # تحضير البيانات
    df = df.dropna(subset=[price_col])
    
    # التأكد من وجود جميع الميزات
    missing_features = [f for f in feature_names if f not in df.columns]
    if missing_features:
        print(f"⚠️ Missing features: {missing_features}")
        feature_names = [f for f in feature_names if f in df.columns]
    
    if len(feature_names) == 0:
        print(f"❌ No valid features for {asset_name}")
        return None
    
    X = df[feature_names].values
    y = df[price_col].values
    
    print(f"📊 Training data shape: X={X.shape}, y={y.shape}")
    
    # تقسيم البيانات
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )
    
    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب النموذج
    print(f"🚀 Training GradientBoostingRegressor...")
    model = GradientBoostingRegressor(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=5,
        random_state=42,
        verbose=0
    )
    
    model.fit(X_train_scaled, y_train)
    
    # التقييم
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mae = mean_absolute_error(y_test, y_test_pred)
    
    print(f"\n📊 Model Performance:")
    print(f"   Train R²: {train_r2:.4f}")
    print(f"   Test R²: {test_r2:.4f}")
    print(f"   Test RMSE: {test_rmse:.4f}")
    print(f"   Test MAE: {test_mae:.4f}")
    
    # حفظ النموذج
    os.makedirs('models', exist_ok=True)
    
    model_path = f'models/{asset_name}_model_v5.pkl'
    scaler_path = f'models/{asset_name}_scaler_v5.pkl'
    features_path = f'models/{asset_name}_features_v5.pkl'
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f, protocol=2)  # استخدام protocol 2 للتوافق
    
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f, protocol=2)
    
    with open(features_path, 'wb') as f:
        pickle.dump(feature_names, f, protocol=2)
    
    print(f"✅ Model saved to {model_path}")
    
    # حفظ معلومات النموذج
    info = {
        'asset': asset_name,
        'price_col': price_col,
        'features': feature_names,
        'n_features': len(feature_names),
        'train_r2': float(train_r2),
        'test_r2': float(test_r2),
        'test_rmse': float(test_rmse),
        'test_mae': float(test_mae),
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'model_type': 'GradientBoostingRegressor',
        'timestamp': pd.Timestamp.now().isoformat()
    }
    
    info_path = f'models/{asset_name}_info_v5.json'
    with open(info_path, 'w') as f:
        json.dump(info, f, indent=2)
    
    return info


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🚀 Retraining All Models V5")
    print("="*80)
    
    assets = {
        'Gold': 'Gold_Price',
        'Bitcoin': 'BTC_Price',
        'Ethereum': 'ETH_Price',
        'TRY_USD': 'TRY_USD',
        'EGP_USD': 'EGP_USD'
    }
    
    results = {}
    
    for asset_name, price_col in assets.items():
        info = train_model(asset_name, price_col)
        if info:
            results[asset_name] = info
    
    # حفظ ملخص النتائج
    summary_path = 'models/training_summary_v5.json'
    with open(summary_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*80}")
    print("✅ All models trained successfully!")
    print(f"💾 Summary saved to {summary_path}")
    print(f"{'='*80}")
    
    # عرض ملخص
    print(f"\n📊 Training Summary:")
    print(f"{'Asset':<15} {'R² Score':<12} {'RMSE':<12} {'Features':<10}")
    print(f"{'-'*50}")
    for asset, info in results.items():
        print(f"{asset:<15} {info['test_r2']:<12.4f} {info['test_rmse']:<12.4f} {info['n_features']:<10}")


if __name__ == '__main__':
    main()

