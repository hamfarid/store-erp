#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Advanced Training System with LSTM, Transformers, and Political Events
نظام التدريب المتقدم مع LSTM و Transformers والأحداث السياسية

File: /home/ubuntu/gold_price_predictor_clean/train_advanced_system.py
"""

import os
import sys
import json
import pickle
import warnings
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge

warnings.filterwarnings('ignore')

# استيراد النماذج المتقدمة
sys.path.append('ml')
try:
    from ml.deep_learning_models import LSTMPredictor, TransformerPredictor
    from ml.advanced_features import AdvancedFeatureEngineer
    DL_AVAILABLE = True
    print("✅ Deep Learning models available")
except Exception as e:
    DL_AVAILABLE = False
    print(f"⚠️ Deep Learning models not available: {e}")


class AdvancedTrainingSystem:
    """نظام التدريب المتقدم"""
    
    def __init__(self):
        self.models_dir = 'models_advanced'
        self.data_dir = 'data'
        os.makedirs(self.models_dir, exist_ok=True)
        
        self.assets = {
            'Gold': 'Gold_Price',
            'Bitcoin': 'BTC_Price',
            'Ethereum': 'ETH_Price',
            'TRY_USD': 'TRY_USD',
            'EGP_USD': 'EGP_USD'
        }
        
        self.results = {}
        
        print("✅ Advanced Training System initialized")
    
    def load_data(self):
        """تحميل البيانات"""
        data_path = os.path.join(self.data_dir, 'extended_dataset.csv')
        
        if not os.path.exists(data_path):
            print(f"❌ Data file not found: {data_path}")
            return None
        
        df = pd.read_csv(data_path)
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date').reset_index(drop=True)
        
        print(f"📊 Loaded {len(df)} rows from {df['Date'].min()} to {df['Date'].max()}")
        
        return df
    
    def load_political_events(self):
        """تحميل الأحداث السياسية"""
        events_path = os.path.join(self.data_dir, 'political_events.csv')
        
        if not os.path.exists(events_path):
            print(f"⚠️ Political events file not found: {events_path}")
            return pd.DataFrame()
        
        events = pd.read_csv(events_path)
        events['Date'] = pd.to_datetime(events['Date'])
        
        print(f"📅 Loaded {len(events)} political/economic events")
        
        return events
    
    def add_political_features(self, df, events, asset_name):
        """إضافة ميزات الأحداث السياسية"""
        # إنشاء عمود للأحداث
        df['Event_Impact'] = 0
        df['Event_Category'] = 'None'
        df['Days_Since_Event'] = 999
        
        # تصفية الأحداث المؤثرة على هذا الأصل
        relevant_events = events[events['Affected_Assets'].str.contains(asset_name, na=False)]
        
        # تعيين مستوى التأثير
        impact_map = {
            'Low': 1,
            'Medium': 2,
            'High': 3,
            'Very High': 4,
            'Extreme': 5
        }
        
        for _, event in relevant_events.iterrows():
            event_date = event['Date']
            impact_level = impact_map.get(event['Impact_Level'], 0)
            
            # تأثير الحدث يستمر لمدة 30 يوم
            mask = (df['Date'] >= event_date) & (df['Date'] <= event_date + timedelta(days=30))
            
            # تحديث التأثير (أخذ الأقصى)
            df.loc[mask, 'Event_Impact'] = df.loc[mask, 'Event_Impact'].apply(
                lambda x: max(x, impact_level)
            )
            
            # حساب الأيام منذ الحدث
            df.loc[df['Date'] >= event_date, 'Days_Since_Event'] = (
                df.loc[df['Date'] >= event_date, 'Date'] - event_date
            ).dt.days
        
        # تحويل الفئة إلى رقم
        category_map = {
            'None': 0,
            'Economic': 1,
            'Political': 2,
            'Military': 3,
            'Health': 4
        }
        
        print(f"✅ Added political event features for {asset_name}")
        
        return df
    
    def prepare_features_simple(self, df, target_col):
        """تحضير الميزات البسيطة (lag features)"""
        # Lag features
        for lag in [1, 2, 3, 7, 14, 30]:
            df[f'{target_col}_lag{lag}'] = df[target_col].shift(lag)
        
        # MA features
        df[f'{target_col}_MA7'] = df[target_col].rolling(window=7, min_periods=1).mean()
        df[f'{target_col}_MA30'] = df[target_col].rolling(window=30, min_periods=1).mean()
        df[f'{target_col}_MA90'] = df[target_col].rolling(window=90, min_periods=1).mean()
        
        # Volatility
        df[f'{target_col}_Volatility'] = df[target_col].rolling(window=7, min_periods=1).std()
        
        # Change features
        df[f'{target_col}_Change'] = df[target_col].diff()
        df[f'{target_col}_PctChange'] = df[target_col].pct_change()
        
        return df
    
    def select_features(self, df, target_col, use_advanced=False):
        """اختيار الميزات"""
        # الميزات الأساسية
        lag_features = [f'{target_col}_lag{i}' for i in [1, 2, 3, 7, 14, 30] if f'{target_col}_lag{i}' in df.columns]
        
        ma_features = [
            f'{target_col}_MA7',
            f'{target_col}_MA30',
            f'{target_col}_MA90',
            f'{target_col}_Volatility',
            f'{target_col}_Change',
            f'{target_col}_PctChange'
        ]
        
        # ميزات الأحداث السياسية
        event_features = ['Event_Impact', 'Days_Since_Event']
        
        # ميزات خارجية
        external_features = []
        if target_col == 'Gold_Price':
            external_features = ['Silver_Price', 'Oil_Price', 'DXY_Index', 'CPI', 'Interest_Rate']
        elif target_col in ['BTC_Price', 'ETH_Price']:
            if target_col == 'BTC_Price' and 'ETH_Price' in df.columns:
                external_features = ['ETH_Price', 'Gold_Price', 'DXY_Index']
            elif target_col == 'ETH_Price' and 'BTC_Price' in df.columns:
                external_features = ['BTC_Price', 'Gold_Price', 'DXY_Index']
        elif target_col in ['TRY_USD', 'EGP_USD']:
            external_features = ['DXY_Index', 'Gold_Price', 'EUR_USD', 'CPI']
        
        # دمج جميع الميزات
        all_features = lag_features + ma_features + event_features + external_features
        
        # التأكد من وجود الميزات
        features = [f for f in all_features if f in df.columns and f != target_col]
        
        return features
    
    def train_simple_model(self, df, asset_name, target_col):
        """تدريب نموذج بسيط (Ridge)"""
        print(f"\n{'='*80}")
        print(f"🔧 Training Simple Model: {asset_name}")
        print(f"{'='*80}")
        
        # تحضير الميزات
        df = self.prepare_features_simple(df.copy(), target_col)
        
        # اختيار الميزات
        features = self.select_features(df, target_col)
        
        print(f"🔧 Selected {len(features)} features")
        
        # تنظيف البيانات
        df_clean = df[[target_col] + features].dropna()
        
        if len(df_clean) < 100:
            print(f"❌ Not enough data: {len(df_clean)} rows")
            return None
        
        print(f"📊 Using {len(df_clean)} rows")
        
        X = df_clean[features].values
        y = df_clean[target_col].values
        
        # Time series split (80% train, 20% test)
        split_idx = int(0.8 * len(X))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Scaling
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # تدريب النموذج
        model = Ridge(alpha=1.0)
        model.fit(X_train_scaled, y_train)
        
        # التقييم
        y_train_pred = model.predict(X_train_scaled)
        y_test_pred = model.predict(X_test_scaled)
        
        train_r2 = r2_score(y_train, y_train_pred)
        test_r2 = r2_score(y_test, y_test_pred)
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        test_mae = mean_absolute_error(y_test, y_test_pred)
        test_mape = np.mean(np.abs((y_test - y_test_pred) / (y_test + 1e-10))) * 100
        
        print(f"\n📊 Performance:")
        print(f"   Train R²: {train_r2:.4f}")
        print(f"   Test R²: {test_r2:.4f}")
        print(f"   RMSE: {test_rmse:.4f}")
        print(f"   MAE: {test_mae:.4f}")
        print(f"   MAPE: {test_mape:.2f}%")
        
        # حفظ النموذج
        model_path = os.path.join(self.models_dir, f'{asset_name}_simple.pkl')
        scaler_path = os.path.join(self.models_dir, f'{asset_name}_simple_scaler.pkl')
        features_path = os.path.join(self.models_dir, f'{asset_name}_simple_features.pkl')
        
        with open(model_path, 'wb') as f:
            pickle.dump(model, f, protocol=2)
        with open(scaler_path, 'wb') as f:
            pickle.dump(scaler, f, protocol=2)
        with open(features_path, 'wb') as f:
            pickle.dump(features, f, protocol=2)
        
        print(f"✅ Saved to {model_path}")
        
        return {
            'model_type': 'Ridge',
            'train_r2': float(train_r2),
            'test_r2': float(test_r2),
            'test_rmse': float(test_rmse),
            'test_mae': float(test_mae),
            'test_mape': float(test_mape),
            'n_features': len(features),
            'train_samples': len(X_train),
            'test_samples': len(X_test)
        }
    
    def train_lstm_model(self, df, asset_name, target_col):
        """تدريب نموذج LSTM"""
        if not DL_AVAILABLE:
            print(f"⚠️ LSTM not available for {asset_name}")
            return None
        
        print(f"\n{'='*80}")
        print(f"🧠 Training LSTM Model: {asset_name}")
        print(f"{'='*80}")
        
        # تحضير الميزات
        df = self.prepare_features_simple(df.copy(), target_col)
        features = self.select_features(df, target_col)
        
        # تنظيف البيانات
        df_clean = df[[target_col] + features].dropna()
        
        if len(df_clean) < 200:
            print(f"❌ Not enough data for LSTM: {len(df_clean)} rows")
            return None
        
        print(f"📊 Using {len(df_clean)} rows, {len(features)} features")
        
        X = df_clean[features].values
        y = df_clean[target_col].values
        
        # Scaling
        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        
        X_scaled = scaler_X.fit_transform(X)
        y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).flatten()
        
        # إنشاء نموذج LSTM
        sequence_length = 30
        lstm = LSTMPredictor(sequence_length=sequence_length, features=len(features))
        
        # تحضير التسلسلات
        X_seq, y_seq = lstm.prepare_sequences(X_scaled, y_scaled)
        
        # Time series split
        split_idx = int(0.8 * len(X_seq))
        X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
        y_train, y_test = y_seq[:split_idx], y_seq[split_idx:]
        
        print(f"📊 Train: {len(X_train)}, Test: {len(X_test)}")
        
        # بناء وتدريب النموذج
        lstm.build_model(lstm_units=[64, 32])
        
        try:
            history = lstm.train(
                X_train, y_train,
                X_test, y_test,
                epochs=50,
                batch_size=32
            )
            
            # التقييم
            y_test_pred_scaled = lstm.predict(X_test).flatten()
            y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled.reshape(-1, 1)).flatten()
            y_test_actual = scaler_y.inverse_transform(y_test.reshape(-1, 1)).flatten()
            
            test_r2 = r2_score(y_test_actual, y_test_pred)
            test_rmse = np.sqrt(mean_squared_error(y_test_actual, y_test_pred))
            test_mae = mean_absolute_error(y_test_actual, y_test_pred)
            test_mape = np.mean(np.abs((y_test_actual - y_test_pred) / (y_test_actual + 1e-10))) * 100
            
            print(f"\n📊 LSTM Performance:")
            print(f"   Test R²: {test_r2:.4f}")
            print(f"   RMSE: {test_rmse:.4f}")
            print(f"   MAE: {test_mae:.4f}")
            print(f"   MAPE: {test_mape:.2f}%")
            
            # حفظ النموذج
            model_path = os.path.join(self.models_dir, f'{asset_name}_lstm.h5')
            lstm.save(model_path)
            
            # حفظ scalers
            scaler_X_path = os.path.join(self.models_dir, f'{asset_name}_lstm_scaler_X.pkl')
            scaler_y_path = os.path.join(self.models_dir, f'{asset_name}_lstm_scaler_y.pkl')
            
            with open(scaler_X_path, 'wb') as f:
                pickle.dump(scaler_X, f, protocol=2)
            with open(scaler_y_path, 'wb') as f:
                pickle.dump(scaler_y, f, protocol=2)
            
            print(f"✅ Saved to {model_path}")
            
            return {
                'model_type': 'LSTM',
                'test_r2': float(test_r2),
                'test_rmse': float(test_rmse),
                'test_mae': float(test_mae),
                'test_mape': float(test_mape),
                'n_features': len(features),
                'sequence_length': sequence_length,
                'test_samples': len(X_test)
            }
            
        except Exception as e:
            print(f"❌ LSTM training failed: {e}")
            return None


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🚀 Advanced Training System with Political Events")
    print("="*80)
    
    system = AdvancedTrainingSystem()
    
    # تحميل البيانات
    df = system.load_data()
    if df is None:
        return
    
    # تحميل الأحداث السياسية
    events = system.load_political_events()
    
    # تدريب النماذج لكل أصل
    all_results = {}
    
    for asset_name, target_col in system.assets.items():
        if target_col not in df.columns:
            print(f"⚠️ {target_col} not found in data")
            continue
        
        print(f"\n{'='*80}")
        print(f"📊 Processing {asset_name}")
        print(f"{'='*80}")
        
        # إضافة ميزات الأحداث السياسية
        df_asset = system.add_political_features(df.copy(), events, asset_name)
        
        # تدريب النموذج البسيط
        simple_result = system.train_simple_model(df_asset, asset_name, target_col)
        
        # تدريب LSTM
        lstm_result = system.train_lstm_model(df_asset, asset_name, target_col)
        
        all_results[asset_name] = {
            'simple': simple_result,
            'lstm': lstm_result
        }
    
    # حفظ النتائج
    results_path = os.path.join(system.models_dir, 'training_results.json')
    with open(results_path, 'w') as f:
        json.dump(all_results, f, indent=2)
    
    # عرض ملخص
    print(f"\n{'='*80}")
    print("📊 TRAINING SUMMARY")
    print(f"{'='*80}")
    
    print(f"\n{'Asset':<15} {'Model':<10} {'R²':<10} {'RMSE':<12} {'MAPE':<10}")
    print(f"{'-'*60}")
    
    for asset, results in all_results.items():
        if results['simple']:
            r = results['simple']
            print(f"{asset:<15} {'Simple':<10} {r['test_r2']:<10.4f} {r['test_rmse']:<12.2f} {r['test_mape']:<10.2f}%")
        
        if results['lstm']:
            r = results['lstm']
            print(f"{asset:<15} {'LSTM':<10} {r['test_r2']:<10.4f} {r['test_rmse']:<12.2f} {r['test_mape']:<10.2f}%")
    
    print(f"\n{'='*80}")
    print(f"✅ Training completed!")
    print(f"💾 Results saved to {results_path}")
    print(f"{'='*80}")


if __name__ == '__main__':
    main()

