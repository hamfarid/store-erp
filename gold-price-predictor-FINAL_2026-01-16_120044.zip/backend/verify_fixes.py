
import sys
import os

# Add backend directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

print("Verifying imports...")

try:
    print("Importing app.auth.auth_2fa...")
    import app.auth.auth_2fa
    print("✅ app.auth.auth_2fa imported")

    print("Importing app.auth.auth_argon2...")
    import app.auth.auth_argon2
    print("✅ app.auth.auth_argon2 imported")

    print("Importing app.auth.auth_postgresql...")
    import app.auth.auth_postgresql
    print("✅ app.auth.auth_postgresql imported")

    print("Importing app.database_enhanced...")
    import app.database_enhanced
    print("✅ app.database_enhanced imported")

    print("Importing app.health_checks...")
    import app.health_checks
    print("✅ app.health_checks imported")

    print("Importing app.error_handlers...")
    import app.error_handlers
    print("✅ app.error_handlers imported")

    # Importing main might start the app or have side effects if not careful, but it should be fine as it defines 'app'
    print("Importing app.main...")
    import app.main
    print("✅ app.main imported")

    print("Importing app.routers.monitoring...")
    import app.routers.monitoring
    print("✅ app.routers.monitoring imported")

    print("Importing app.services.external_api_client...")
    import app.services.external_api_client
    print("✅ app.services.external_api_client imported")

    print("Importing app.services.notification...")
    import app.services.notification
    print("✅ app.services.notification imported")

    print("\n🎉 All critical modules imported successfully!")
except Exception as e:
    print(f"\n❌ Import failed: {e}")
    sys.exit(1)
