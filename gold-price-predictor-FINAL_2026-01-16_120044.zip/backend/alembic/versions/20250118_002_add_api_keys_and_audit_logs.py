"""Add API keys and audit logs tables

Revision ID: 002_api_audit
Revises: 001_initial
Create Date: 2025-01-18 00:01:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '002_api_audit'
down_revision: Union[str, None] = '001_initial'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Create API keys and audit logs tables
    """
    
    # Create api_keys table
    op.create_table(
        'api_keys',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('key_hash', sa.String(length=255), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('request_count', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('expires_at', sa.DateTime(), nullable=True),
        sa.Column('last_used_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name='fk_api_keys_user_id', ondelete='CASCADE'),
        sa.UniqueConstraint('key_hash', name='uq_api_keys_key_hash'),
        sa.CheckConstraint('length(name) >= 1', name='ck_api_keys_name_length'),
    )
    op.create_index('idx_api_keys_user_id', 'api_keys', ['user_id'])
    op.create_index('idx_api_keys_key_hash', 'api_keys', ['key_hash'])
    op.create_index('idx_api_keys_is_active', 'api_keys', ['is_active'])
    op.create_index('idx_api_keys_expires_at', 'api_keys', ['expires_at'])
    op.create_index('idx_api_keys_user_active', 'api_keys', ['user_id', 'is_active'])
    op.create_index('idx_api_keys_expires', 'api_keys', ['expires_at', 'is_active'])

    # Create audit_logs table
    op.create_table(
        'audit_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('event_type', sa.String(length=50), nullable=False),
        sa.Column('ip_address', sa.String(length=45), nullable=True),
        sa.Column('user_agent', sa.Text(), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=True),
        sa.Column('details', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name='fk_audit_logs_user_id', ondelete='SET NULL'),
        sa.CheckConstraint('length(event_type) >= 1', name='ck_audit_logs_event_type_length'),
    )
    op.create_index('idx_audit_logs_user_id', 'audit_logs', ['user_id'])
    op.create_index('idx_audit_logs_event_type', 'audit_logs', ['event_type'])
    op.create_index('idx_audit_logs_ip_address', 'audit_logs', ['ip_address'])
    op.create_index('idx_audit_logs_success', 'audit_logs', ['success'])
    op.create_index('idx_audit_logs_created_at', 'audit_logs', ['created_at'])
    op.create_index('idx_audit_logs_user_event', 'audit_logs', ['user_id', 'event_type'])
    op.create_index('idx_audit_logs_event_created', 'audit_logs', ['event_type', 'created_at'])
    op.create_index('idx_audit_logs_ip_created', 'audit_logs', ['ip_address', 'created_at'])


def downgrade() -> None:
    """
    Drop API keys and audit logs tables
    """
    op.drop_table('audit_logs')
    op.drop_table('api_keys')

