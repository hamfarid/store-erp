# Database Migrations with Alembic

This directory contains database migration scripts managed by Alembic.

## Setup

1. Install Alembic:
```bash
pip install alembic
```

2. Initialize the database (first time only):
```bash
cd backend
alembic upgrade head
```

## Common Commands

### Create a new migration
```bash
# Auto-generate migration from model changes
alembic revision --autogenerate -m "description of changes"

# Create empty migration
alembic revision -m "description of changes"
```

### Apply migrations
```bash
# Upgrade to latest version
alembic upgrade head

# Upgrade one version
alembic upgrade +1

# Upgrade to specific revision
alembic upgrade <revision_id>
```

### Rollback migrations
```bash
# Downgrade one version
alembic downgrade -1

# Downgrade to specific revision
alembic downgrade <revision_id>

# Downgrade all
alembic downgrade base
```

### View migration history
```bash
# Show current version
alembic current

# Show migration history
alembic history

# Show pending migrations
alembic history --verbose
```

## Migration Files

### 001_initial_schema_with_constraints.py
- Creates core tables: users, assets, predictions, alerts
- Adds foreign key constraints
- Adds check constraints for data validation
- Creates performance indexes

### 002_add_api_keys_and_audit_logs.py
- Creates api_keys table for API authentication
- Creates audit_logs table for security auditing
- Adds indexes for performance

## Best Practices

1. **Always test migrations in development first**
2. **Create backups before running migrations in production**
3. **Review auto-generated migrations** - they may need manual adjustments
4. **Write reversible migrations** - always implement downgrade()
5. **Use descriptive migration names**
6. **Don't modify existing migrations** - create new ones instead

## Database Schema

### Users Table
- Primary key: id
- Unique constraints: username, email
- Indexes: username, email, is_active, created_at
- Check constraints: username length >= 3, email length >= 5

### Assets Table
- Primary key: id
- Unique constraints: symbol
- Indexes: symbol, category, is_active
- Check constraints: symbol length >= 1, name length >= 1

### Predictions Table
- Primary key: id
- Foreign keys: user_id → users.id (CASCADE)
- Indexes: user_id, symbol, created_at, composite indexes
- Check constraints: confidence between 0 and 1

### Alerts Table
- Primary key: id
- Foreign keys: user_id → users.id (CASCADE)
- Indexes: user_id, asset_id, is_active, is_triggered, created_at
- Check constraints: alert_type IN ('above', 'below', 'change'), notification_method IN ('email', 'sms', 'push')

### API Keys Table
- Primary key: id
- Foreign keys: user_id → users.id (CASCADE)
- Unique constraints: key_hash
- Indexes: user_id, key_hash, is_active, expires_at

### Audit Logs Table
- Primary key: id
- Foreign keys: user_id → users.id (SET NULL)
- Indexes: user_id, event_type, ip_address, created_at

## Environment Variables

Set `DATABASE_URL` environment variable:
```bash
export DATABASE_URL="postgresql://user:password@localhost:5432/dbname"
```

Or update `alembic.ini` with your database URL.

## Troubleshooting

### Migration fails with "relation already exists"
- The table may already exist. Check with `\dt` in psql.
- You may need to stamp the database: `alembic stamp head`

### Auto-generate doesn't detect changes
- Ensure models are imported in `env.py`
- Check that `target_metadata` is set correctly

### Can't connect to database
- Verify DATABASE_URL is correct
- Check database is running
- Verify credentials

## Production Deployment

1. **Backup database**:
```bash
pg_dump -U user -d dbname > backup_$(date +%Y%m%d_%H%M%S).sql
```

2. **Test migration in staging**:
```bash
alembic upgrade head
```

3. **Deploy to production**:
```bash
# Set production DATABASE_URL
export DATABASE_URL="postgresql://prod_user:prod_pass@prod_host:5432/prod_db"

# Run migration
alembic upgrade head
```

4. **Verify**:
```bash
alembic current
```

## Rollback Plan

If migration fails in production:

1. **Rollback migration**:
```bash
alembic downgrade -1
```

2. **Restore from backup** (if needed):
```bash
psql -U user -d dbname < backup_file.sql
```

3. **Investigate and fix**
4. **Test in staging again**
5. **Re-deploy**

