import Database from 'better-sqlite3';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = resolve(__dirname, './data/app.db');
mkdirSync(dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Assets to seed
const assets = [
  { name: 'Gold', symbol: 'GC=F', category: 'commodity' },
  { name: 'Bitcoin', symbol: 'BTC-USD', category: 'crypto' },
  { name: 'Ethereum', symbol: 'ETH-USD', category: 'crypto' },
  { name: 'TRY/USD', symbol: 'TRYUSD=X', category: 'currency' },
  { name: 'EGP/USD', symbol: 'EGPUSD=X', category: 'currency' },
  { name: 'Silver', symbol: 'SI=F', category: 'commodity' },
  { name: 'Oil', symbol: 'CL=F', category: 'commodity' },
  { name: 'EUR/USD', symbol: 'EURUSD=X', category: 'currency' },
  { name: 'GBP/USD', symbol: 'GBPUSD=X', category: 'currency' },
  { name: 'USD/JPY', symbol: 'JPY=X', category: 'currency' },
  { name: 'S&P 500', symbol: '^GSPC', category: 'stock' },
  { name: 'Dow Jones', symbol: '^DJI', category: 'stock' },
  { name: 'NASDAQ', symbol: '^IXIC', category: 'stock' },
  { name: 'Litecoin', symbol: 'LTC-USD', category: 'crypto' },
  { name: 'Ripple', symbol: 'XRP-USD', category: 'crypto' },
  { name: 'Cardano', symbol: 'ADA-USD', category: 'crypto' },
  { name: 'Polkadot', symbol: 'DOT-USD', category: 'crypto' },
];

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO assets (name, symbol, category, isActive, createdAt)
  VALUES (?, ?, ?, 1, ?)
`);

const now = Date.now();

assets.forEach((asset, index) => {
  try {
    insertStmt.run(asset.name, asset.symbol, asset.category, now);
    console.log(`✓ Added: ${asset.name} (${asset.symbol})`);
  } catch (error) {
    console.error(`✗ Error adding ${asset.name}:`, error.message);
  }
});

// Check total assets
const count = db.prepare('SELECT COUNT(*) as count FROM assets').get();
console.log(`\n✓ Total assets in database: ${count.count}`);

db.close();

