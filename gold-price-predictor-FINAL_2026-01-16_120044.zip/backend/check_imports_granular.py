
import sys
import os
import traceback

# Add backend to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

print("Starting granular import check...")

def check_import(module_name):
    try:
        print(f"Importing {module_name}...")
        __import__(module_name)
        print(f"✅ {module_name} imported successfully")
        return True
    except Exception as e:
        print(f"❌ Failed to import {module_name}")
        traceback.print_exc()
        return False

# 1. Check basic deps
check_import("app.config_secure")
check_import("app.database_enhanced")

# 2. Check Security Middleware Dependencies
check_import("app.middleware.csrf_protection")
check_import("app.middleware.structured_logging")

# 3. Check Input Sanitizer (Bleach dependency?)
check_import("app.middleware.input_sanitizer")

# 4. Check Upload Scanner (Magic dependency?)
check_import("app.middleware.upload_scanner")

# 5. Check Rate Limiter (Redis dependency?)
check_import("app.rate_limiter_redis")

# 6. Check Services
check_import("app.services.notification")

print("Granular check complete.")
