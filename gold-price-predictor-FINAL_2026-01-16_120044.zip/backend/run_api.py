"""
سكريبت تشغيل API
Run API Script
"""

import uvicorn
import sys
import os

# إضافة المسار الحالي
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    print("=" * 80)
    print("🚀 Starting Gold Price Predictor API...")
    print("=" * 80)
    print()
    print("📡 API will be available at:")
    print("   - Main: http://localhost:2005")
    print("   - Docs: http://localhost:2005/docs")
    print("   - ReDoc: http://localhost:2005/redoc")
    print()
    print("Press CTRL+C to stop the server")
    print("=" * 80)
    print()

    uvicorn.run(
        "api.main:app",
        host="0.0.0.0",
        port=2005,
        reload=True,
        log_level="info"
    )
