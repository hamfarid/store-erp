# File: /home/ubuntu/gold-price-predictor/config_secure.py
"""
إعدادات التطبيق الآمنة
"""
import secrets
import os
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """إعدادات التطبيق"""

    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", secrets.token_hex(32))
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # CORS
    ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "https://yourdomain.com"
    ]

    # Database
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql://gold_user:gold_password@localhost:5432/gold_predictor_db"
    )

    # Redis
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_ENABLED: bool = os.getenv("REDIS_ENABLED", "false").lower() == "true"

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60  # seconds

    # API Keys
    NEWS_API_KEY: Optional[str] = os.getenv("NEWS_API_KEY")
    FRED_API_KEY: Optional[str] = os.getenv("FRED_API_KEY")

    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = "app.log"

    class Config:
        env_file = ".env"
        case_sensitive = True


# إنشاء instance واحد من Settings
settings = Settings()


# التحقق من أن SECRET_KEY ليس القيمة الافتراضية
if settings.SECRET_KEY == "your-secret-key-change-this-in-production-use-env-variable":
    raise ValueError(
        "SECRET_KEY must be changed from default value! "
        "Set it in environment variables or .env file."
    )
