# File: /home/ubuntu/gold-price-predictor/backend/app/database_enhanced.py
"""
Enhanced Database Configuration with Indexes and Optimizations
PostgreSQL with SQLAlchemy ORM
"""
from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime, Float, Text, ForeignKey, Index, DECIMAL
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.pool import QueuePool
from datetime import datetime
import os

# Database URL from environment
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://gold_user:secure_password@localhost/gold_predictor_db"
)

# Create engine with connection pooling
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

# Create session
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()

# ==================== Models ====================


class User(Base):
    """Enhanced User model with 2FA and audit support"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)

    # Status
    is_active = Column(Boolean, default=True, index=True)
    is_admin = Column(Boolean, default=False)

    # 2FA fields
    is_2fa_enabled = Column(Boolean, default=False, index=True)
    totp_secret = Column(String(32), nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    # Relationships
    predictions = relationship(
        "Prediction",
        back_populates="user",
        cascade="all, delete-orphan")
    api_keys = relationship(
        "APIKey",
        back_populates="user",
        cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user")

    # Composite indexes
    __table_args__ = (
        Index('idx_users_username_email', 'username', 'email'),
        Index('idx_users_active_created', 'is_active', 'created_at'),
    )


class Prediction(Base):
    """Prediction model with comprehensive indexing"""
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(
        Integer,
        ForeignKey(
            "users.id",
            ondelete="CASCADE"),
        nullable=False,
        index=True)

    # Prediction data
    symbol = Column(String(20), nullable=False, index=True)
    horizon = Column(String(20), nullable=False)
    current_price = Column(DECIMAL(20, 8))
    predicted_price = Column(DECIMAL(20, 8))
    change_percent = Column(DECIMAL(10, 4))
    confidence = Column(DECIMAL(5, 4))

    # Model information
    model_used = Column(String(50))
    model_accuracy = Column(DECIMAL(5, 4))

    # Additional data
    sentiment_score = Column(DECIMAL(5, 4), nullable=True)
    economic_indicators = Column(JSONB, nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="predictions")

    # Composite indexes for common queries
    __table_args__ = (
        Index('idx_predictions_user_symbol', 'user_id', 'symbol'),
        Index('idx_predictions_symbol_created', 'symbol', 'created_at'),
        Index('idx_predictions_user_created', 'user_id', 'created_at'),
    )


class APIKey(Base):
    """API Key model for programmatic access"""
    __tablename__ = "api_keys"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(
        Integer,
        ForeignKey(
            "users.id",
            ondelete="CASCADE"),
        nullable=False,
        index=True)

    name = Column(String(100), nullable=False)
    key_hash = Column(String(255), unique=True, nullable=False, index=True)

    # Status
    is_active = Column(Boolean, default=True, index=True)

    # Usage tracking
    request_count = Column(Integer, default=0)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True, index=True)
    last_used_at = Column(DateTime, nullable=True)

    # Relationships
    user = relationship("User", back_populates="api_keys")

    # Indexes
    __table_args__ = (
        Index('idx_api_keys_user_active', 'user_id', 'is_active'),
        Index('idx_api_keys_expires', 'expires_at', 'is_active'),
    )


class AuditLog(Base):
    """Comprehensive audit logging"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(
        Integer,
        ForeignKey(
            "users.id",
            ondelete="SET NULL"),
        nullable=True,
        index=True)

    event_type = Column(String(50), nullable=False, index=True)
    ip_address = Column(String(45), index=True)
    user_agent = Column(Text, nullable=True)
    success = Column(Boolean, default=True, index=True)
    details = Column(JSONB, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship("User", back_populates="audit_logs")

    # Composite indexes for analytics
    __table_args__ = (
        Index('idx_audit_logs_user_event', 'user_id', 'event_type'),
        Index('idx_audit_logs_event_created', 'event_type', 'created_at'),
        Index('idx_audit_logs_ip_created', 'ip_address', 'created_at'),
    )


class Asset(Base):
    """Asset model for supported symbols"""
    __tablename__ = "assets"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    category = Column(String(50), index=True)
    description = Column(Text, nullable=True)

    # Status
    is_active = Column(Boolean, default=True, index=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow)

# ==================== Database Functions ====================


def get_db():
    """Get database session with automatic cleanup"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize all database tables"""
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables created successfully")


def drop_db():
    """Drop all database tables (use with caution!)"""
    Base.metadata.drop_all(bind=engine)
    print("⚠️ Database tables dropped")


def seed_data(db):
    """Seed initial data"""
    from auth_postgresql import hash_password

    # Seed admin user
    admin = db.query(User).filter(User.username == "admin").first()
    if not admin:
        admin = User(
            username="admin",
            email="admin@goldpredictor.com",
            hashed_password=hash_password("Admin@123"),
            is_admin=True
        )
        db.add(admin)
        db.commit()
        print("✅ Admin user created")

    # Seed assets
    assets = [
        {"symbol": "GOLD", "name": "Gold", "category": "Precious Metals"},
        {"symbol": "SILVER", "name": "Silver", "category": "Precious Metals"},
        {"symbol": "BTC", "name": "Bitcoin", "category": "Cryptocurrency"},
        {"symbol": "ETH", "name": "Ethereum", "category": "Cryptocurrency"},
        {"symbol": "EUR/USD", "name": "Euro to US Dollar", "category": "Forex"},
        {"symbol": "GBP/USD", "name": "British Pound to US Dollar", "category": "Forex"},
    ]

    for asset_data in assets:
        asset = db.query(Asset).filter(
            Asset.symbol == asset_data["symbol"]).first()
        if not asset:
            asset = Asset(**asset_data)
            db.add(asset)

    db.commit()
    print("✅ Assets seeded successfully")


if __name__ == "__main__":
    print("Initializing enhanced database...")
    init_db()

    db = SessionLocal()
    try:
        seed_data(db)
    finally:
        db.close()

    print("✅ Database setup completed!")
