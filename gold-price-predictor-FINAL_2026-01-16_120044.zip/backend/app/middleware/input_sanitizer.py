# File:
# /home/ubuntu/gold-price-predictor/backend/app/middleware/input_sanitizer.py
"""
Input Sanitization Middleware
Provides protection against XSS, SQL Injection, and other injection attacks
"""

import re
import html
import bleach
from typing import Any, Dict, List, Union
from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware
import logging

logger = logging.getLogger(__name__)


class InputSanitizer:
    """
    Input Sanitization Service

    Provides methods to sanitize different types of input:
    - HTML/XSS protection
    - SQL injection prevention
    - Path traversal prevention
    - Command injection prevention
    """

    # Dangerous patterns
    SQL_INJECTION_PATTERNS = [
        r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)",
        r"(--|;|\/\*|\*\/|xp_|sp_)",
        r"(\bUNION\b.*\bSELECT\b)",
        r"(\bOR\b.*=.*)",
    ]

    PATH_TRAVERSAL_PATTERNS = [
        r"\.\./",
        r"\.\.",
        r"%2e%2e",
        r"\.\.\\",
    ]

    COMMAND_INJECTION_PATTERNS = [
        r"[;&|`$()]",
        r"(\bcat\b|\bls\b|\brm\b|\bwget\b|\bcurl\b)",
    ]

    # Allowed HTML tags for rich text (if needed)
    ALLOWED_TAGS = ['p', 'br', 'strong', 'em', 'u', 'a', 'ul', 'ol', 'li']
    ALLOWED_ATTRIBUTES = {'a': ['href', 'title']}

    @classmethod
    def sanitize_html(cls, text: str, allow_tags: bool = False) -> str:
        """
        Sanitize HTML content to prevent XSS

        Args:
            text: Input text
            allow_tags: Whether to allow safe HTML tags

        Returns:
            Sanitized text
        """
        if not isinstance(text, str):
            return text

        if allow_tags:
            # Use bleach to allow only safe tags
            return bleach.clean(
                text,
                tags=cls.ALLOWED_TAGS,
                attributes=cls.ALLOWED_ATTRIBUTES,
                strip=True
            )
        else:
            # Escape all HTML
            return html.escape(text)

    @classmethod
    def check_sql_injection(cls, text: str) -> bool:
        """
        Check if text contains SQL injection patterns

        Args:
            text: Input text

        Returns:
            True if suspicious patterns found, False otherwise
        """
        if not isinstance(text, str):
            return False

        text_upper = text.upper()
        for pattern in cls.SQL_INJECTION_PATTERNS:
            if re.search(pattern, text_upper, re.IGNORECASE):
                logger.warning(f"Potential SQL injection detected: {pattern}")
                return True
        return False

    @classmethod
    def check_path_traversal(cls, text: str) -> bool:
        """
        Check if text contains path traversal patterns

        Args:
            text: Input text

        Returns:
            True if suspicious patterns found, False otherwise
        """
        if not isinstance(text, str):
            return False

        for pattern in cls.PATH_TRAVERSAL_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                logger.warning(f"Potential path traversal detected: {pattern}")
                return True
        return False

    @classmethod
    def check_command_injection(cls, text: str) -> bool:
        """
        Check if text contains command injection patterns

        Args:
            text: Input text

        Returns:
            True if suspicious patterns found, False otherwise
        """
        if not isinstance(text, str):
            return False

        for pattern in cls.COMMAND_INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                logger.warning(
                    f"Potential command injection detected: {pattern}")
                return True
        return False

    @classmethod
    def sanitize_string(cls, text: str, strict: bool = True) -> str:
        """
        Sanitize a string input

        Args:
            text: Input text
            strict: If True, reject suspicious patterns; if False, just sanitize

        Returns:
            Sanitized text

        Raises:
            HTTPException: If strict mode and suspicious patterns found
        """
        if not isinstance(text, str):
            return text

        # Check for injection attempts
        if strict:
            if cls.check_sql_injection(text):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid input: potential SQL injection detected"
                )
            if cls.check_path_traversal(text):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid input: potential path traversal detected"
                )
            if cls.check_command_injection(text):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid input: potential command injection detected")

        # Sanitize HTML
        return cls.sanitize_html(text, allow_tags=False)

    @classmethod
    def sanitize_dict(cls, data: Dict[str, Any],
                      strict: bool = True) -> Dict[str, Any]:
        """
        Recursively sanitize dictionary values

        Args:
            data: Input dictionary
            strict: If True, reject suspicious patterns

        Returns:
            Sanitized dictionary
        """
        if not isinstance(data, dict):
            return data

        sanitized = {}
        for key, value in data.items():
            if isinstance(value, str):
                sanitized[key] = cls.sanitize_string(value, strict=strict)
            elif isinstance(value, dict):
                sanitized[key] = cls.sanitize_dict(value, strict=strict)
            elif isinstance(value, list):
                sanitized[key] = cls.sanitize_list(value, strict=strict)
            else:
                sanitized[key] = value

        return sanitized

    @classmethod
    def sanitize_list(cls, data: List[Any], strict: bool = True) -> List[Any]:
        """
        Recursively sanitize list items

        Args:
            data: Input list
            strict: If True, reject suspicious patterns

        Returns:
            Sanitized list
        """
        if not isinstance(data, list):
            return data

        sanitized = []
        for item in data:
            if isinstance(item, str):
                sanitized.append(cls.sanitize_string(item, strict=strict))
            elif isinstance(item, dict):
                sanitized.append(cls.sanitize_dict(item, strict=strict))
            elif isinstance(item, list):
                sanitized.append(cls.sanitize_list(item, strict=strict))
            else:
                sanitized.append(item)

        return sanitized


class InputSanitizerMiddleware(BaseHTTPMiddleware):
    """
    Middleware to automatically sanitize all incoming requests
    """

    async def dispatch(self, request: Request, call_next):
        """
        Process request and sanitize input

        Args:
            request: FastAPI request
            call_next: Next middleware/handler

        Returns:
            Response
        """
        # Skip sanitization for certain paths (e.g., static files, docs)
        skip_paths = ['/docs', '/redoc', '/openapi.json', '/static']
        if any(request.url.path.startswith(path) for path in skip_paths):
            return await call_next(request)

        # Sanitize query parameters
        if request.query_params:
            try:
                sanitized_params = InputSanitizer.sanitize_dict(
                    dict(request.query_params),
                    strict=True
                )
                # Note: Can't modify request.query_params directly
                # This is for validation only
            except HTTPException as e:
                logger.warning(
                    f"Malicious query params detected: {request.url}")
                raise e

        # For POST/PUT requests, sanitize body
        if request.method in ['POST', 'PUT', 'PATCH']:
            try:
                # This is handled by Pydantic models in endpoints
                # But we can add additional validation here if needed
                pass
            except Exception as e:
                logger.error(f"Error sanitizing request body: {str(e)}")

        response = await call_next(request)
        return response


# Utility functions for use in endpoints
def sanitize_input(data: Union[str, Dict, List],
                   strict: bool = True) -> Union[str, Dict, List]:
    """
    Sanitize input data (string, dict, or list)

    Args:
        data: Input data
        strict: If True, reject suspicious patterns

    Returns:
        Sanitized data
    """
    if isinstance(data, str):
        return InputSanitizer.sanitize_string(data, strict=strict)
    elif isinstance(data, dict):
        return InputSanitizer.sanitize_dict(data, strict=strict)
    elif isinstance(data, list):
        return InputSanitizer.sanitize_list(data, strict=strict)
    else:
        return data
