# FILE: backend/app/middleware/csrf_protection.py | PURPOSE: CSRF protection middleware | OWNER: Security Team | RELATED: main.py, security_headers.py | LAST-AUDITED: 2025-01-18
"""
CSRF Protection Middleware for FastAPI
Implements CSRF token generation and validation for all state-changing operations
"""

from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Callable
import secrets
import hmac
import hashlib
import time
import logging

logger = logging.getLogger(__name__)

# CSRF Configuration
CSRF_TOKEN_LENGTH = 32
CSRF_TOKEN_TTL = 3600  # 1 hour
CSRF_HEADER_NAME = "X-CSRF-Token"
CSRF_COOKIE_NAME = "csrf_token"
CSRF_SECRET_KEY = secrets.token_urlsafe(32)  # Should be loaded from env in production

# Methods that require CSRF protection
CSRF_PROTECTED_METHODS = {"POST", "PUT", "DELETE", "PATCH"}

# Paths exempt from CSRF protection
CSRF_EXEMPT_PATHS = {
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/refresh",
    "/api/docs",
    "/api/redoc",
    "/api/openapi.json",
    "/health",
    "/metrics",
}


def generate_csrf_token() -> str:
    """
    Generate a new CSRF token

    Returns:
        str: CSRF token (base64 encoded)
    """
    timestamp = str(int(time.time()))
    random_bytes = secrets.token_bytes(CSRF_TOKEN_LENGTH)

    # Create HMAC signature
    message = f"{timestamp}:{random_bytes.hex()}"
    signature = hmac.new(
        CSRF_SECRET_KEY.encode(),
        message.encode(),
        hashlib.sha256
    ).hexdigest()

    # Combine timestamp, random bytes, and signature
    token = f"{timestamp}:{random_bytes.hex()}:{signature}"
    return token


def validate_csrf_token(token: str) -> bool:
    """
    Validate a CSRF token

    Args:
        token: CSRF token to validate

    Returns:
        bool: True if valid, False otherwise
    """
    try:
        parts = token.split(":")
        if len(parts) != 3:
            return False

        timestamp_str, random_hex, signature = parts
        timestamp = int(timestamp_str)

        # Check if token has expired
        current_time = int(time.time())
        if current_time - timestamp > CSRF_TOKEN_TTL:
            logger.warning("CSRF token expired: %ss old", current_time - timestamp)
            return False

        # Verify signature
        message = f"{timestamp_str}:{random_hex}"
        expected_signature = hmac.new(
            CSRF_SECRET_KEY.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(signature, expected_signature):
            logger.warning("CSRF token signature mismatch")
            return False

        return True
    except Exception as e:
        logger.error("CSRF token validation error: %s", e)
        return False


class CSRFProtectionMiddleware(BaseHTTPMiddleware):
    """
    CSRF Protection Middleware

    Validates CSRF tokens for all state-changing requests (POST, PUT, DELETE, PATCH)
    Exempts certain paths like login, register, and public endpoints
    """

    async def dispatch(self, request: Request, call_next: Callable):
        """
        Process request and validate CSRF token if required

        Args:
            request: FastAPI request object
            call_next: Next middleware/route handler

        Returns:
            Response from next handler or 403 Forbidden
        """
        # Skip CSRF check for safe methods
        if request.method not in CSRF_PROTECTED_METHODS:
            response = await call_next(request)

            # Add CSRF token to response for GET requests
            if request.method == "GET":
                csrf_token = generate_csrf_token()
                response.set_cookie(
                    key=CSRF_COOKIE_NAME,
                    value=csrf_token,
                    httponly=True,
                    secure=True,  # HTTPS only
                    samesite="strict",
                    max_age=CSRF_TOKEN_TTL
                )
                response.headers[CSRF_HEADER_NAME] = csrf_token

            return response

        # Check if path is exempt
        if request.url.path in CSRF_EXEMPT_PATHS:
            return await call_next(request)

        # Get CSRF token from header
        csrf_token_header = request.headers.get(CSRF_HEADER_NAME)

        # Get CSRF token from cookie
        csrf_token_cookie = request.cookies.get(CSRF_COOKIE_NAME)

        # Validate CSRF token
        if not csrf_token_header or not csrf_token_cookie:
            logger.warning("CSRF token missing for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={
                    "code": "CSRF_TOKEN_MISSING",
                    "message": "CSRF token is required for this operation",
                    "details": {
                        "method": request.method,
                        "path": request.url.path
                    }
                }
            )

        # Tokens must match
        if csrf_token_header != csrf_token_cookie:
            logger.warning("CSRF token mismatch for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={
                    "code": "CSRF_TOKEN_MISMATCH",
                    "message": "CSRF token mismatch",
                    "details": {
                        "method": request.method,
                        "path": request.url.path
                    }
                }
            )

        # Validate token
        if not validate_csrf_token(csrf_token_header):
            logger.warning("CSRF token invalid for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={
                    "code": "CSRF_TOKEN_INVALID",
                    "message": "CSRF token is invalid or expired",
                    "details": {
                        "method": request.method,
                        "path": request.url.path
                    }
                }
            )

        # CSRF token is valid, proceed with request
        response = await call_next(request)

        # Rotate CSRF token after successful state-changing operation
        new_csrf_token = generate_csrf_token()
        response.set_cookie(
            key=CSRF_COOKIE_NAME,
            value=new_csrf_token,
            httponly=True,
            secure=True,
            samesite="strict",
            max_age=CSRF_TOKEN_TTL
        )
        response.headers[CSRF_HEADER_NAME] = new_csrf_token

        return response
