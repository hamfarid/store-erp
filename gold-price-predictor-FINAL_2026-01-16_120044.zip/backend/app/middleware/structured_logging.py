# File:
# /home/ubuntu/gold-price-predictor/backend/app/middleware/structured_logging.py
"""
Structured Logging System with Correlation IDs
Provides comprehensive logging with request tracing
"""

import logging
import json
import uuid
from datetime import datetime
from typing import Any, Dict, Optional
from contextvars import ContextVar
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
import time

# Context variable for correlation ID (thread-safe)
correlation_id_var: ContextVar[Optional[str]] = ContextVar(
    'correlation_id', default=None)


class StructuredLogger:
    """
    Structured Logger with JSON output and correlation IDs

    Provides:
    - JSON-formatted logs
    - Correlation ID tracking
    - Contextual information
    - Performance metrics
    """

    def __init__(self, name: str):
        """
        Initialize structured logger

        Args:
            name: Logger name (usually module name)
        """
        self.logger = logging.getLogger(name)
        self.name = name

    def _get_correlation_id(self) -> Optional[str]:
        """Get current correlation ID from context"""
        return correlation_id_var.get()

    def _format_log(
        self,
        level: str,
        message: str,
        extra: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Format log entry as structured JSON

        Args:
            level: Log level (INFO, ERROR, etc.)
            message: Log message
            extra: Additional context

        Returns:
            Structured log dictionary
        """
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level,
            "logger": self.name,
            "message": message,
            "correlation_id": self._get_correlation_id()
        }

        if extra:
            log_entry.update(extra)

        return log_entry

    def info(self, message: str, **kwargs):
        """
        Log info message

        Args:
            message: Log message
            **kwargs: Additional context
        """
        log_entry = self._format_log("INFO", message, kwargs)
        self.logger.info(json.dumps(log_entry))

    def error(self, message: str, **kwargs):
        """
        Log error message

        Args:
            message: Log message
            **kwargs: Additional context (can include exception)
        """
        log_entry = self._format_log("ERROR", message, kwargs)
        self.logger.error(json.dumps(log_entry))

    def warning(self, message: str, **kwargs):
        """
        Log warning message

        Args:
            message: Log message
            **kwargs: Additional context
        """
        log_entry = self._format_log("WARNING", message, kwargs)
        self.logger.warning(json.dumps(log_entry))

    def debug(self, message: str, **kwargs):
        """
        Log debug message

        Args:
            message: Log message
            **kwargs: Additional context
        """
        log_entry = self._format_log("DEBUG", message, kwargs)
        self.logger.debug(json.dumps(log_entry))

    def critical(self, message: str, **kwargs):
        """
        Log critical message

        Args:
            message: Log message
            **kwargs: Additional context
        """
        log_entry = self._format_log("CRITICAL", message, kwargs)
        self.logger.critical(json.dumps(log_entry))

    def log_request(
        self,
        method: str,
        path: str,
        status_code: int,
        duration_ms: float,
        **kwargs
    ):
        """
        Log HTTP request

        Args:
            method: HTTP method
            path: Request path
            status_code: Response status code
            duration_ms: Request duration in milliseconds
            **kwargs: Additional context
        """
        log_entry = self._format_log(
            "INFO",
            "HTTP Request",
            {
                "http_method": method,
                "http_path": path,
                "http_status": status_code,
                "duration_ms": duration_ms,
                **kwargs
            }
        )
        self.logger.info(json.dumps(log_entry))

    def log_exception(self, exc: Exception, **kwargs):
        """
        Log exception with full context

        Args:
            exc: Exception object
            **kwargs: Additional context
        """
        log_entry = self._format_log(
            "ERROR",
            str(exc),
            {
                "exception_type": type(exc).__name__,
                "exception_message": str(exc),
                **kwargs
            }
        )
        self.logger.error(json.dumps(log_entry), exc_info=True)


class CorrelationIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware to add correlation IDs to all requests

    Correlation IDs help trace requests across services and logs
    """

    async def dispatch(self, request: Request, call_next):
        """
        Process request and add correlation ID

        Args:
            request: FastAPI request
            call_next: Next middleware/handler

        Returns:
            Response with correlation ID header
        """
        # Get or generate correlation ID
        correlation_id = request.headers.get('X-Correlation-ID')
        if not correlation_id:
            correlation_id = str(uuid.uuid4())

        # Set correlation ID in context
        correlation_id_var.set(correlation_id)

        # Add to request state for access in endpoints
        request.state.correlation_id = correlation_id

        # Track request timing
        start_time = time.time()

        # Process request
        response = await call_next(request)

        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000

        # Add correlation ID to response headers
        response.headers['X-Correlation-ID'] = correlation_id

        # Log request
        logger = StructuredLogger(__name__)
        logger.log_request(
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            duration_ms=round(duration_ms, 2),
            client_ip=request.client.host if request.client else None
        )

        return response


def get_correlation_id() -> Optional[str]:
    """
    Get current correlation ID

    Returns:
        Correlation ID string or None
    """
    return correlation_id_var.get()


def set_correlation_id(correlation_id: str):
    """
    Set correlation ID for current context

    Args:
        correlation_id: Correlation ID string
    """
    correlation_id_var.set(correlation_id)


# Utility function to get structured logger
def get_logger(name: str) -> StructuredLogger:
    """
    Get structured logger instance

    Args:
        name: Logger name (usually __name__)

    Returns:
        StructuredLogger instance
    """
    return StructuredLogger(name)


# Example usage in endpoints
def example_endpoint_logging():
    """Example of how to use structured logging in endpoints"""
    logger = get_logger(__name__)

    # Log info with context
    logger.info(
        "Processing prediction request",
        user_id=123,
        asset="gold",
        timeframe="1h"
    )

    try:
        # ... business logic ...
        pass
    except Exception as e:
        # Log exception with context
        logger.log_exception(
            e,
            user_id=123,
            operation="prediction"
        )

    # Log success
    logger.info(
        "Prediction completed successfully",
        user_id=123,
        result_count=10
    )
