#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# FILE: backend/app/real_ml_api.py | PURPOSE: Real ML API | OWNER: Backend | LAST-AUDITED: 2026-01-02
"""
Real ML API - Uses actual trained models
نظام API الحقيقي الذي يستخدم نماذج التعلم الآلي المدربة
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pickle
import json
import os
import yfinance as yf
from datetime import datetime, timedelta
import numpy as np
from health_monitor import get_basic_health, get_detailed_health, track_request

app = FastAPI(title="Asset Predictor API - Real ML")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Asset symbol mapping
ASSET_SYMBOLS = {
    1: ("GC=F", "Gold"),  # Gold
    2: ("SI=F", "Silver"),  # Silver
    3: ("CL=F", "Oil"),  # Oil WTI
    4: ("BZ=F", "Brent"),  # Brent
    5: ("PL=F", "Platinum"),  # Platinum
    6: ("PA=F", "Palladium"),  # Palladium
    7: ("HG=F", "Copper"),  # Copper
    8: ("NG=F", "Gas"),  # Natural Gas
    9: ("BTC-USD", "Bitcoin"),  # Bitcoin
    10: ("ETH-USD", "Ethereum"),  # Ethereum
    11: ("TRY=X", "TRY_USD"),  # Turkish Lira
    12: ("EGP=X", "EGP_USD"),  # Egyptian Pound
    13: ("EUR=X", "EUR"),  # Euro
    14: ("DX-Y.NYB", "DXY"),  # Dollar Index
    15: ("SAR=X", "SAR"),  # Saudi Riyal
    16: ("AED=X", "AED"),  # UAE Dirham
    17: ("OMR=X", "OMR"),  # Omani Rial
}

# Models directory
MODELS_DIR = "models"


class PredictionRequest(BaseModel):
    assetId: int
    horizon: str
    modelType: str
    confidenceLevel: float = 0.95


class PredictionResponse(BaseModel):
    currentPrice: float
    predictedPrice: float
    confidenceLower: float
    confidenceUpper: float
    accuracy: float
    targetDate: str
    daysAhead: int
    modelUsed: str
    featuresUsed: int


def load_model(asset_name):
    """Load trained model, scaler, and features for an asset"""
    try:
        # Try v5 models first
        model_path = os.path.join(MODELS_DIR, f"{asset_name}_model_v5.pkl")
        scaler_path = os.path.join(MODELS_DIR, f"{asset_name}_scaler_v5.pkl")
        features_path = os.path.join(MODELS_DIR, f"{asset_name}_features_v5.pkl")
        info_path = os.path.join(MODELS_DIR, f"{asset_name}_info_v5.json")

        # Fallback to non-v5 models
        if not os.path.exists(model_path):
            model_path = os.path.join(MODELS_DIR, f"{asset_name}_model.pkl")
            scaler_path = os.path.join(MODELS_DIR, f"{asset_name}_scaler.pkl")
            features_path = os.path.join(MODELS_DIR, f"{asset_name}_feature_names.pkl")
            info_path = os.path.join(MODELS_DIR, f"{asset_name}_info.json")

        if not os.path.exists(model_path):
            return None, None, None, None

        with open(model_path, 'rb') as f:
            model = pickle.load(f)

        with open(scaler_path, 'rb') as f:
            scaler = pickle.load(f)

        with open(features_path, 'rb') as f:
            features = pickle.load(f)

        info = None
        if os.path.exists(info_path):
            with open(info_path, 'r') as f:
                info = json.load(f)

        return model, scaler, features, info

    except Exception as e:
        print(f"Error loading model for {asset_name}: {e}")
        return None, None, None, None


def get_current_price(symbol):
    """Get current price for a symbol"""
    try:
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="5d")
        if data.empty:
            return None
        return float(data['Close'].iloc[-1])
    except Exception as e:
        print(f"Error getting price for {symbol}: {e}")
        return None


def prepare_features(symbol, asset_name, feature_names):
    """Prepare features for prediction"""
    try:
        # Download historical data
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="90d")

        if data.empty:
            return None

        # Calculate features
        features_dict = {}

        # Price lags
        for lag in [1, 2, 3, 7]:
            lag_col = f"{asset_name}_Price_lag{lag}"
            if lag_col in feature_names:
                if len(data) > lag:
                    features_dict[lag_col] = data['Close'].iloc[-lag - 1]
                else:
                    features_dict[lag_col] = data['Close'].iloc[0]

        # Moving averages
        for window in [7, 30]:
            ma_col = f"{asset_name}_Price_MA{window}"
            if ma_col in feature_names:
                if len(data) >= window:
                    features_dict[ma_col] = data['Close'].rolling(window=window).mean().iloc[-1]
                else:
                    features_dict[ma_col] = data['Close'].mean()

        # Volatility
        vol_col = f"{asset_name}_Price_Volatility"
        if vol_col in feature_names:
            if len(data) >= 30:
                features_dict[vol_col] = data['Close'].rolling(window=30).std().iloc[-1]
            else:
                features_dict[vol_col] = data['Close'].std()

        # Price change
        change_col = f"{asset_name}_Price_Change"
        if change_col in feature_names:
            if len(data) > 1:
                features_dict[change_col] = data['Close'].iloc[-1] - data['Close'].iloc[-2]
            else:
                features_dict[change_col] = 0

        # Percent change
        pct_col = f"{asset_name}_Price_PctChange"
        if pct_col in feature_names:
            if len(data) > 1:
                features_dict[pct_col] = (data['Close'].iloc[-1] - data['Close'].iloc[-2]) / data['Close'].iloc[-2]
            else:
                features_dict[pct_col] = 0

        # Other assets (simplified - use current price or 0)
        for feat in feature_names:
            if feat not in features_dict:
                # Try to get price for other assets
                if "Silver_Price" in feat:
                    price = get_current_price("SI=F")
                    features_dict[feat] = price if price else 0
                elif "Oil_Price" in feat:
                    price = get_current_price("CL=F")
                    features_dict[feat] = price if price else 0
                elif "DXY_Index" in feat:
                    price = get_current_price("DX-Y.NYB")
                    features_dict[feat] = price if price else 0
                elif "CPI" in feat:
                    features_dict[feat] = 300  # Approximate CPI value
                else:
                    features_dict[feat] = 0

        # Create feature array in correct order
        feature_array = np.array([features_dict.get(f, 0) for f in feature_names]).reshape(1, -1)

        return feature_array

    except Exception as e:
        print(f"Error preparing features: {e}")
        return None


@app.get("/")
def root():
    return {"status": "ok", "message": "Real ML Asset Predictor API", "using_real_models": True}


@app.get("/health")
def health():
    """Basic health check"""
    return get_basic_health()


@app.get("/health/detailed")
def detailed_health():
    """Detailed health check with system metrics"""
    return get_detailed_health()


@app.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest):
    """Generate prediction using real ML models"""
    track_request("/predict", True)

    try:
        # Get symbol and asset name
        if request.assetId not in ASSET_SYMBOLS:
            track_request("/predict", False)
            raise HTTPException(status_code=400, detail="Invalid asset ID")

        symbol, asset_name = ASSET_SYMBOLS[request.assetId]
        print(f"[predict] assetId={request.assetId}, symbol={symbol}, asset={asset_name}")

        # Load model
        model, scaler, features, info = load_model(asset_name)

        if model is None:
            # Fallback to simple prediction
            print(f"[predict] No model found for {asset_name}, using fallback")
            return fallback_prediction(symbol, request)

        print(f"[predict] Loaded model for {asset_name}, features: {len(features)}")

        # Get current price
        current_price = get_current_price(symbol)
        if current_price is None:
            track_request("/predict", False)
            raise HTTPException(status_code=500, detail="Failed to get current price")

        # Prepare features
        feature_array = prepare_features(symbol, asset_name, features)
        if feature_array is None:
            print("[predict] Failed to prepare features, using fallback")
            return fallback_prediction(symbol, request)

        # Scale features
        try:
            feature_array_scaled = scaler.transform(feature_array)
        except Exception as e:
            print(f"[predict] Scaling failed: {e}, using unscaled features")
            feature_array_scaled = feature_array

        # Make prediction
        predicted_price = float(model.predict(feature_array_scaled)[0])

        # Calculate confidence interval based on model info
        if info and 'test_rmse' in info:
            rmse = info['test_rmse']
        else:
            # Estimate RMSE as 1% of current price
            rmse = current_price * 0.01

        # Determine days ahead
        days_ahead = 1 if request.horizon == 'short' else (7 if request.horizon == 'medium' else 30)

        # Z-scores for confidence levels
        z_scores = {
            0.80: 1.282,
            0.90: 1.645,
            0.95: 1.96,
            0.99: 2.576
        }
        z_score = z_scores.get(request.confidenceLevel, 1.96)

        # Confidence interval (adjust for horizon)
        confidence_range = rmse * z_score * np.sqrt(days_ahead)
        confidence_lower = max(0, predicted_price - confidence_range)
        confidence_upper = predicted_price + confidence_range

        # Get accuracy from model info
        if info and 'test_r2' in info:
            accuracy = float(info['test_r2'])
        else:
            accuracy = 0.95  # Default

        # Calculate target date
        target_date = (datetime.now() + timedelta(days=days_ahead)).strftime("%Y-%m-%d")

        track_request("/predict", True)

        return PredictionResponse(
            currentPrice=current_price,
            predictedPrice=predicted_price,
            confidenceLower=confidence_lower,
            confidenceUpper=confidence_upper,
            accuracy=accuracy,
            targetDate=target_date,
            daysAhead=days_ahead,
            modelUsed=info.get('model_type', 'Unknown') if info else 'Unknown',
            featuresUsed=len(features)
        )

    except HTTPException:
        raise
    except Exception as e:
        track_request("/predict", False)
        print(f"[predict] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def fallback_prediction(symbol, request):
    """Fallback to simple prediction when model not available"""
    try:
        # Get current data
        data = yf.download(symbol, period="30d", progress=False, auto_adjust=True)

        if data.empty:
            raise ValueError("No data available")

        current_price = float(data['Close'].iloc[-1])

        # Simple trend-based prediction
        ma_7 = float(data['Close'].rolling(window=7).mean().iloc[-1])
        ma_30 = float(data['Close'].rolling(window=30).mean().iloc[-1])
        trend = (ma_7 - ma_30) / ma_30

        days_ahead = 1 if request.horizon == 'short' else (7 if request.horizon == 'medium' else 30)

        if request.horizon == 'short':
            predicted_price = current_price * (1 + trend * 0.01)
        elif request.horizon == 'medium':
            predicted_price = current_price * (1 + trend * 0.03)
        else:
            predicted_price = current_price * (1 + trend * 0.05)

        # Calculate volatility
        returns = data['Close'].pct_change().dropna()
        volatility = float(returns.std())

        z_scores = {0.80: 1.282, 0.90: 1.645, 0.95: 1.96, 0.99: 2.576}
        z_score = z_scores.get(request.confidenceLevel, 1.96)
        adjusted_volatility = volatility * np.sqrt(days_ahead)
        confidence_range = predicted_price * adjusted_volatility * z_score

        confidence_lower = max(0, predicted_price - confidence_range)
        confidence_upper = predicted_price + confidence_range

        target_date = (datetime.now() + timedelta(days=days_ahead)).strftime("%Y-%m-%d")

        return PredictionResponse(
            currentPrice=current_price,
            predictedPrice=predicted_price,
            confidenceLower=confidence_lower,
            confidenceUpper=confidence_upper,
            accuracy=0.90,  # Lower accuracy for fallback
            targetDate=target_date,
            daysAhead=days_ahead,
            modelUsed="Fallback (MA-based)",
            featuresUsed=0
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fallback prediction failed: {str(e)}")


@app.get("/current_prices")
def get_current_prices():
    """Get current prices for all assets"""
    track_request("/current_prices", True)

    try:
        prices = {}
        for asset_id, (symbol, _) in ASSET_SYMBOLS.items():
            try:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period="2d")
                if not hist.empty:
                    current = float(hist['Close'].iloc[-1])
                    prev = float(hist['Close'].iloc[-2]) if len(hist) > 1 else current
                    change = ((current - prev) / prev * 100) if prev != 0 else 0
                    prices[symbol] = {
                        "price": round(current, 2),
                        "change": round(change, 2)
                    }
            except Exception as e:
                print(f"Error getting price for {symbol}: {e}")
                continue

        track_request("/current_prices", True)
        return {"prices": prices, "timestamp": datetime.now().isoformat()}

    except Exception as e:
        track_request("/current_prices", False)
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=2005)
