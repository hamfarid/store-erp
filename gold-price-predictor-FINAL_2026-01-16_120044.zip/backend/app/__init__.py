# File: /home/ubuntu/gold-price-predictor/backend/app/__init__.py
"""
Backend Application Package
"""
