# FILE: backend/app/api_production.py | PURPOSE: Production-ready API | OWNER: Backend | LAST-AUDITED: 2026-01-02
"""
API Production-Ready مع جميع الإصلاحات الأمنية
"""
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from pydantic import BaseModel, validator
import logging
from datetime import datetime

from config_secure import settings
from database import get_db, User
from auth_postgresql import (
    authenticate_user,
    create_access_token,
    create_refresh_token,
    get_current_user,
    hash_password
)
from rate_limiter_redis import RateLimiter
from repositories.model_repository import ModelRepository
from services.prediction_service import PredictionService

# Logging
logging.basicConfig(
    level=settings.LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(settings.LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# FastAPI App
app = FastAPI(
    title="Gold & Assets Price Prediction API",
    description="Production-ready API for predicting gold and financial assets prices",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

# Rate Limiter
rate_limiter = RateLimiter(redis_url=settings.REDIS_URL if settings.REDIS_ENABLED else None)

# OAuth2
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


# Pydantic Models
class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str


class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    
    @validator('password')
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        return v


class PredictionRequest(BaseModel):
    symbol: str
    horizon: str = "short"
    
    @validator('symbol')
    def symbol_valid(cls, v):
        valid_symbols = [
            "GOLD", "BTC", "ETH", "EUR/USD", "GBP/USD", "USD/JPY",
            "AUD/USD", "USD/CAD", "NZD/USD", "USD/CHF", "USD/CNY",
            "TRY/USD", "EGP/USD", "SAR/USD", "AED/USD", "KWD/USD", "QAR/USD"
        ]
        if v.upper() not in valid_symbols:
            raise ValueError(f'Invalid symbol. Must be one of: {", ".join(valid_symbols)}')
        return v.upper()
    
    @validator('horizon')
    def horizon_valid(cls, v):
        if v not in ["short", "medium", "long"]:
            raise ValueError('Horizon must be one of: short, medium, long')
        return v


# Dependencies
async def get_current_active_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """الحصول على المستخدم النشط الحالي"""
    user = get_current_user(token, db)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


# Routes
@app.get("/")
async def root():
    """الصفحة الرئيسية"""
    return {
        "message": "Gold & Assets Price Prediction API",
        "version": "2.0.0",
        "status": "production"
    }


@app.get("/health")
async def health_check():
    """فحص صحة النظام"""
    return {"status": "healthy", "timestamp": "2025-10-21"}


@app.post("/auth/register", response_model=Token)
async def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """تسجيل مستخدم جديد"""
    # التحقق من عدم وجود المستخدم
    existing_user = db.query(User).filter(User.username == user_data.username).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    # إنشاء المستخدم
    hashed_password = hash_password(user_data.password)
    new_user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hashed_password
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # إنشاء Tokens
    access_token = create_access_token(data={"sub": new_user.username})
    refresh_token = create_refresh_token(data={"sub": new_user.username})
    
    logger.info(f"New user registered: {new_user.username}")
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }


@app.post("/auth/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """تسجيل الدخول"""
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        logger.warning(f"Failed login attempt for username: {form_data.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = create_access_token(data={"sub": user.username})
    refresh_token = create_refresh_token(data={"sub": user.username})
    
    logger.info(f"User logged in: {user.username}")
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }


@app.get("/assets")
async def get_assets(current_user: User = Depends(get_current_active_user)):
    """الحصول على قائمة الأصول المدعومة"""
    assets = [
        {"symbol": "GOLD", "name": "Gold", "category": "Commodity"},
        {"symbol": "BTC", "name": "Bitcoin", "category": "Cryptocurrency"},
        {"symbol": "ETH", "name": "Ethereum", "category": "Cryptocurrency"},
        {"symbol": "EUR/USD", "name": "Euro/US Dollar", "category": "Forex"},
        {"symbol": "GBP/USD", "name": "British Pound/US Dollar", "category": "Forex"},
    ]
    return assets


@app.post("/predict")
async def predict(
    request: PredictionRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """التنبؤ بسعر الأصل"""
    # Rate Limiting
    client_id = current_user.username
    if not rate_limiter.allow_request(client_id):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        # استخدام Service Layer
        model_repo = ModelRepository()
        prediction_service = PredictionService(model_repo)
        
        result = prediction_service.predict(request.symbol, request.horizon)
        
        logger.info(f"Prediction made for {request.symbol} by {current_user.username}")
        
        return result
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)

