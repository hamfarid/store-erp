"""
Model Training Tasks for Celery
"""

import logging
from datetime import datetime
from pathlib import Path

from app.core.celery_app import celery_app

logger = logging.getLogger(__name__)

MODELS_DIR = Path(__file__).parent.parent.parent.parent / "models"
DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"


@celery_app.task(bind=True, max_retries=3)
def train_model(self, model_type: str = "lstm"):
    """
    Train ML model (scheduled daily at midnight)
    
    Args:
        model_type: Type of model to train (lstm, gradient_boosting, etc.)
    """
    logger.info(f"Starting model training: {model_type}")
    
    try:
        from modules.model_trainer_extended import ExtendedModelTrainer
        
        trainer = ExtendedModelTrainer()
        results = trainer.train_all_assets()
        
        logger.info(f"Model training completed successfully: {results}")
        
        return {
            "status": "success",
            "model_type": model_type,
            "timestamp": datetime.utcnow().isoformat(),
            "results": results
        }
        
    except ImportError as e:
        logger.warning(f"Module not available: {e}, using fallback training")
        return _fallback_training(model_type)
        
    except Exception as e:
        logger.error(f"Model training failed: {e}")
        self.retry(exc=e, countdown=60 * 5)  # Retry in 5 minutes


def _fallback_training(model_type: str):
    """Fallback training using basic scikit-learn"""
    import pickle
    
    try:
        from sklearn.ensemble import GradientBoostingRegressor
        from sklearn.preprocessing import StandardScaler
        import pandas as pd
        
        # Load data
        data_path = DATA_DIR / "processed" / "merged_data.csv"
        if not data_path.exists():
            data_path = DATA_DIR / "extended_dataset_v2.csv"
        
        if not data_path.exists():
            return {"status": "error", "message": "No training data found"}
        
        df = pd.read_csv(data_path)
        
        assets = ["Gold", "Bitcoin", "Ethereum", "TRY_USD", "EGP_USD"]
        results = {}
        
        for asset in assets:
            target_col = f"{asset}_Price" if asset in ["Gold", "Bitcoin", "Ethereum"] else asset
            
            if target_col not in df.columns:
                continue
            
            # Simple feature engineering
            feature_cols = [c for c in df.columns if c != target_col and df[c].dtype in ['float64', 'int64']][:10]
            
            if len(feature_cols) < 3:
                continue
            
            X = df[feature_cols].dropna()
            y = df.loc[X.index, target_col]
            
            # Train model
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            model = GradientBoostingRegressor(n_estimators=100, random_state=42)
            model.fit(X_scaled, y)
            
            # Save model
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            
            model_path = MODELS_DIR / f"{asset}_model_v5.pkl"
            scaler_path = MODELS_DIR / f"{asset}_scaler_v5.pkl"
            
            with open(model_path, 'wb') as f:
                pickle.dump(model, f)
            with open(scaler_path, 'wb') as f:
                pickle.dump(scaler, f)
            
            results[asset] = {"status": "trained", "features": len(feature_cols)}
            logger.info(f"Trained model for {asset}")
        
        return {"status": "success", "results": results}
        
    except Exception as e:
        logger.error(f"Fallback training failed: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task
def retrain_specific_model(asset: str):
    """Retrain a specific asset model"""
    logger.info(f"Retraining model for: {asset}")
    
    try:
        from modules.model_trainer_extended import ExtendedModelTrainer
        
        trainer = ExtendedModelTrainer()
        result = trainer.train_asset_models(asset)
        trainer.save_model(asset)
        
        return {"status": "success", "asset": asset, "result": result}
        
    except Exception as e:
        logger.error(f"Retraining failed for {asset}: {e}")
        return {"status": "error", "asset": asset, "error": str(e)}

