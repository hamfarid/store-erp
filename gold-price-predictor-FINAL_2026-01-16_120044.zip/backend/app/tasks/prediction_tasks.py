"""
Prediction Tasks for Celery
"""

import logging
from datetime import datetime

from app.core.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task
def update_predictions():
    """
    Update predictions for all assets (scheduled hourly)
    """
    logger.info("Updating predictions for all assets")
    
    try:
        from modules.model_loader import load_model, predict
        
        assets = ["Gold", "Bitcoin", "Ethereum", "TRY_USD", "EGP_USD"]
        results = {}
        
        for asset in assets:
            try:
                model = load_model(asset)
                if model:
                    prediction = predict(model, asset)
                    results[asset] = {
                        "predicted_price": prediction,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                    logger.info(f"Updated prediction for {asset}: {prediction}")
            except Exception as e:
                logger.warning(f"Failed to update prediction for {asset}: {e}")
                results[asset] = {"error": str(e)}
        
        return {"status": "success", "predictions": results}
        
    except ImportError:
        logger.warning("Model loader not available, skipping prediction update")
        return {"status": "skipped", "reason": "Module not available"}
        
    except Exception as e:
        logger.error(f"Prediction update failed: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task
def generate_prediction(asset: str, days: int = 7):
    """Generate prediction for a specific asset"""
    logger.info(f"Generating {days}-day prediction for {asset}")
    
    try:
        import pickle
        from pathlib import Path

        MODELS_DIR = Path(__file__).parent.parent.parent.parent / "models"

        model_path = MODELS_DIR / f"{asset}_model_v5.pkl"

        if not model_path.exists():
            return {"status": "error", "message": f"Model not found for {asset}"}
        
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        
        # Generate mock prediction (replace with real features)
        prediction = model.predict([[0] * 10])[0]
        
        return {
            "status": "success",
            "asset": asset,
            "days": days,
            "prediction": float(prediction),
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Prediction generation failed: {e}")
        return {"status": "error", "message": str(e)}

