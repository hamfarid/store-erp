#!/usr/bin/env python3
# File: /home/ubuntu/gold-price-predictor/backend/app/backup_cli.py
"""
Backup CLI Tool
Command-line interface for database backup and restoration
"""

import click
import logging
from services.backup_service import BackupService
from tabulate import tabulate

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


@click.group()
def cli():
    """Database Backup Management CLI"""
    pass


@cli.command()
@click.option('--type', default='full', type=click.Choice(['full', 'schema']),
              help='Type of backup (full or schema-only)')
def backup(type):
    """Create a database backup"""
    click.echo(f"Creating {type} backup...")

    service = BackupService()
    backup_path = service.create_backup(backup_type=type)

    if backup_path:
        click.echo(click.style(f"✓ Backup created: {backup_path}", fg='green'))
    else:
        click.echo(click.style("✗ Backup failed", fg='red'))
        exit(1)


@cli.command()
@click.argument('backup_path')
@click.option('--clean/--no-clean', default=True,
              help='Drop existing objects before restore')
@click.confirmation_option(prompt='Are you sure you want to restore the database?')
def restore(backup_path, clean):
    """Restore database from backup"""
    click.echo(f"Restoring from: {backup_path}")

    service = BackupService()
    success = service.restore_backup(backup_path, clean=clean)

    if success:
        click.echo(click.style("✓ Database restored successfully", fg='green'))
    else:
        click.echo(click.style("✗ Restore failed", fg='red'))
        exit(1)


@cli.command()
@click.option('--location', default='local',
              type=click.Choice(['local', 's3']), help='Backup location')
def list(location):
    """List available backups"""
    service = BackupService()
    backups = service.list_backups(location=location)

    if not backups:
        click.echo(f"No backups found in {location}")
        return

    # Format backup data for display
    table_data = []
    for backup in backups:
        size_mb = backup['size'] / (1024 * 1024)
        table_data.append([
            backup['filename'],
            f"{size_mb:.2f} MB",
            backup['created'].strftime("%Y-%m-%d %H:%M:%S"),
            backup['location']
        ])

    headers = ['Filename', 'Size', 'Created', 'Location']
    click.echo(tabulate(table_data, headers=headers, tablefmt='grid'))


@cli.command()
@click.confirmation_option(prompt='Are you sure you want to delete old backups?')
def cleanup():
    """Remove old backups based on retention policy"""
    click.echo("Cleaning up old backups...")

    service = BackupService()
    deleted_count = service.cleanup_old_backups()

    click.echo(
        click.style(
            f"✓ Deleted {deleted_count} old backups",
            fg='green'))


@cli.command()
@click.option('--time', default='02:00', help='Backup time (HH:MM format)')
def schedule(time):
    """Start scheduled backup service"""
    click.echo(f"Starting scheduled backups at {time}...")

    service = BackupService()
    service.schedule_backups(time_str=time)


@cli.command()
def status():
    """Show backup service status"""
    service = BackupService()

    click.echo("Backup Service Status")
    click.echo("=" * 50)
    click.echo(f"Database: {service.db_name}")
    click.echo(f"Backup Directory: {service.backup_dir}")
    click.echo(f"S3 Bucket: {service.s3_bucket or 'Not configured'}")
    click.echo(f"Retention: {service.retention_days} days")
    click.echo()

    # Count local backups
    local_backups = service.list_backups(location='local')
    click.echo(f"Local Backups: {len(local_backups)}")

    # Count S3 backups
    if service.s3_client:
        s3_backups = service.list_backups(location='s3')
        click.echo(f"S3 Backups: {len(s3_backups)}")

    # Show latest backup
    if local_backups:
        latest = local_backups[0]
        click.echo()
        click.echo("Latest Backup:")
        click.echo(f"  File: {latest['filename']}")
        click.echo(f"  Size: {latest['size'] / (1024*1024):.2f} MB")
        click.echo(
            f"  Created: {latest['created'].strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == '__main__':
    cli()
