"""
Prometheus Metrics Exporter
File: /home/ubuntu/gold-price-predictor/backend/app/monitoring/prometheus_metrics.py

يوفر metrics للمراقبة باستخدام Prometheus
"""

from prometheus_client import Counter, Histogram, Gauge, Info, generate_latest, REGISTRY
from fastapi import Request, Response
from typing import Callable
import time
import psutil
import os


# ============================================================================
# Metrics Definitions
# ============================================================================

# Request Metrics
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint']
)

http_requests_in_progress = Gauge(
    'http_requests_in_progress',
    'HTTP requests currently in progress',
    ['method', 'endpoint']
)

# Prediction Metrics
predictions_total = Counter(
    'predictions_total',
    'Total number of predictions made',
    ['model', 'status']
)

prediction_duration_seconds = Histogram(
    'prediction_duration_seconds',
    'Prediction duration in seconds',
    ['model']
)

prediction_errors_total = Counter(
    'prediction_errors_total',
    'Total prediction errors',
    ['model', 'error_type']
)

# Authentication Metrics
auth_attempts_total = Counter(
    'auth_attempts_total',
    'Total authentication attempts',
    ['method', 'status']
)

auth_failures_total = Counter(
    'auth_failures_total',
    'Total authentication failures',
    ['method', 'reason']
)

active_sessions = Gauge(
    'active_sessions',
    'Number of active user sessions'
)

# API Key Metrics
api_key_requests_total = Counter(
    'api_key_requests_total',
    'Total API key requests',
    ['key_id', 'status']
)

api_key_rate_limit_exceeded = Counter(
    'api_key_rate_limit_exceeded',
    'API key rate limit exceeded count',
    ['key_id']
)

# Database Metrics
db_connections_active = Gauge(
    'db_connections_active',
    'Active database connections'
)

db_query_duration_seconds = Histogram(
    'db_query_duration_seconds',
    'Database query duration in seconds',
    ['query_type']
)

db_errors_total = Counter(
    'db_errors_total',
    'Total database errors',
    ['error_type']
)

# Cache Metrics
cache_hits_total = Counter(
    'cache_hits_total',
    'Total cache hits',
    ['cache_type']
)

cache_misses_total = Counter(
    'cache_misses_total',
    'Total cache misses',
    ['cache_type']
)

cache_size_bytes = Gauge(
    'cache_size_bytes',
    'Cache size in bytes',
    ['cache_type']
)

# System Metrics
system_cpu_usage = Gauge(
    'system_cpu_usage',
    'System CPU usage percentage'
)

system_memory_usage = Gauge(
    'system_memory_usage',
    'System memory usage percentage'
)

system_disk_usage = Gauge(
    'system_disk_usage',
    'System disk usage percentage'
)

# Application Info
app_info = Info(
    'app_info',
    'Application information'
)


# ============================================================================
# Middleware
# ============================================================================

class PrometheusMiddleware:
    """Prometheus Metrics Middleware"""
    
    def __init__(self, app):
        self.app = app
        
        # Set application info
        app_info.info({
            'version': '4.0',
            'name': 'Gold Price Predictor',
            'environment': os.getenv('ENVIRONMENT', 'production')
        })
    
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return
        
        method = scope['method']
        path = scope['path']
        
        # Skip metrics endpoint
        if path == '/metrics':
            await self.app(scope, receive, send)
            return
        
        # Track request in progress
        http_requests_in_progress.labels(method=method, endpoint=path).inc()
        
        start_time = time.time()
        status_code = 500
        
        try:
            # Process request
            async def send_wrapper(message):
                nonlocal status_code
                if message['type'] == 'http.response.start':
                    status_code = message['status']
                await send(message)
            
            await self.app(scope, receive, send_wrapper)
            
        finally:
            # Record metrics
            duration = time.time() - start_time
            
            http_requests_total.labels(
                method=method,
                endpoint=path,
                status=status_code
            ).inc()
            
            http_request_duration_seconds.labels(
                method=method,
                endpoint=path
            ).observe(duration)
            
            http_requests_in_progress.labels(
                method=method,
                endpoint=path
            ).dec()


# ============================================================================
# System Metrics Collector
# ============================================================================

class SystemMetricsCollector:
    """جمع metrics النظام"""
    
    @staticmethod
    def collect_system_metrics():
        """جمع metrics النظام"""
        try:
            # CPU Usage
            cpu_percent = psutil.cpu_percent(interval=1)
            system_cpu_usage.set(cpu_percent)
            
            # Memory Usage
            memory = psutil.virtual_memory()
            system_memory_usage.set(memory.percent)
            
            # Disk Usage
            disk = psutil.disk_usage('/')
            system_disk_usage.set(disk.percent)
            
        except Exception as e:
            print(f"Error collecting system metrics: {e}")


# ============================================================================
# Metrics Endpoint
# ============================================================================

async def metrics_endpoint(request: Request):
    """Endpoint لعرض metrics"""
    # Collect system metrics
    SystemMetricsCollector.collect_system_metrics()
    
    # Generate Prometheus metrics
    metrics = generate_latest(REGISTRY)
    
    return Response(
        content=metrics,
        media_type='text/plain; version=0.0.4; charset=utf-8'
    )


# ============================================================================
# Helper Functions
# ============================================================================

def track_prediction(model: str, duration: float, status: str = 'success'):
    """تتبع تنبؤ"""
    predictions_total.labels(model=model, status=status).inc()
    prediction_duration_seconds.labels(model=model).observe(duration)


def track_prediction_error(model: str, error_type: str):
    """تتبع خطأ تنبؤ"""
    prediction_errors_total.labels(model=model, error_type=error_type).inc()


def track_auth_attempt(method: str, status: str):
    """تتبع محاولة مصادقة"""
    auth_attempts_total.labels(method=method, status=status).inc()


def track_auth_failure(method: str, reason: str):
    """تتبع فشل مصادقة"""
    auth_failures_total.labels(method=method, reason=reason).inc()


def track_cache_hit(cache_type: str = 'redis'):
    """تتبع cache hit"""
    cache_hits_total.labels(cache_type=cache_type).inc()


def track_cache_miss(cache_type: str = 'redis'):
    """تتبع cache miss"""
    cache_misses_total.labels(cache_type=cache_type).inc()


def track_db_query(query_type: str, duration: float):
    """تتبع استعلام قاعدة بيانات"""
    db_query_duration_seconds.labels(query_type=query_type).observe(duration)


def track_db_error(error_type: str):
    """تتبع خطأ قاعدة بيانات"""
    db_errors_total.labels(error_type=error_type).inc()

