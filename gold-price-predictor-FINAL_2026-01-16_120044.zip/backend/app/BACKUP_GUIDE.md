# دليل النسخ الاحتياطي والاستعادة

## نظرة عامة

يوفر نظام النسخ الاحتياطي التلقائي حماية شاملة لبيانات منصة التنبؤ بأسعار الذهب من خلال:

- **نسخ احتياطي تلقائي يومي** لقاعدة البيانات PostgreSQL
- **تخزين محلي وسحابي** (Amazon S3)
- **تدوير تلقائي** للنسخ الاحتياطية القديمة
- **استعادة سريعة** في حالة فقدان البيانات
- **واجهة سطر أوامر (CLI)** سهلة الاستخدام

---

## المتطلبات

### البرامج المطلوبة

```bash
# PostgreSQL client tools
sudo apt-get install postgresql-client

# Python dependencies
pip install boto3 click schedule tabulate
```

### المتغيرات البيئية

```bash
# Database Configuration
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=gold_predictor
export DB_USER=postgres
export DB_PASSWORD=your_password

# S3 Configuration (Optional)
export S3_BACKUP_BUCKET=my-backup-bucket
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

---

## استخدام CLI

### 1. إنشاء نسخة احتياطية

```bash
# نسخة احتياطية كاملة (Full Backup)
python backup_cli.py backup --type full

# نسخة احتياطية للهيكل فقط (Schema Only)
python backup_cli.py backup --type schema
```

**الناتج:**
```
Creating full backup...
✓ Backup created: /backups/gold_predictor_full_20251021_120000.dump
```

### 2. عرض النسخ الاحتياطية المتاحة

```bash
# عرض النسخ المحلية
python backup_cli.py list --location local

# عرض النسخ في S3
python backup_cli.py list --location s3
```

**الناتج:**
```
+------------------------------------------+----------+---------------------+----------+
| Filename                                 | Size     | Created             | Location |
+==========================================+==========+=====================+==========+
| gold_predictor_full_20251021_120000.dump | 245.67 MB| 2025-10-21 12:00:00 | local    |
| gold_predictor_full_20251020_020000.dump | 243.12 MB| 2025-10-20 02:00:00 | local    |
+------------------------------------------+----------+---------------------+----------+
```

### 3. استعادة قاعدة البيانات

```bash
# استعادة من نسخة احتياطية محلية
python backup_cli.py restore /backups/gold_predictor_full_20251021_120000.dump

# استعادة بدون حذف البيانات الحالية
python backup_cli.py restore /backups/backup.dump --no-clean
```

**⚠️ تحذير:** سيتم حذف جميع البيانات الحالية واستبدالها بالنسخة الاحتياطية.

### 4. حذف النسخ القديمة

```bash
# حذف النسخ الأقدم من 30 يوم (حسب الإعدادات)
python backup_cli.py cleanup
```

### 5. جدولة النسخ الاحتياطي التلقائي

```bash
# بدء خدمة النسخ الاحتياطي التلقائي (يوميًا في الساعة 02:00)
python backup_cli.py schedule --time 02:00
```

### 6. عرض حالة النظام

```bash
python backup_cli.py status
```

**الناتج:**
```
Backup Service Status
==================================================
Database: gold_predictor
Backup Directory: /backups
S3 Bucket: my-backup-bucket
Retention: 30 days

Local Backups: 5
S3 Backups: 5

Latest Backup:
  File: gold_predictor_full_20251021_120000.dump
  Size: 245.67 MB
  Created: 2025-10-21 12:00:00
```

---

## الاستخدام البرمجي (Python API)

### إنشاء نسخة احتياطية

```python
from services.backup_service import BackupService

# Initialize service
service = BackupService(
    db_host='localhost',
    db_name='gold_predictor',
    backup_dir='/backups',
    s3_bucket='my-backup-bucket',
    retention_days=30
)

# Create backup
backup_path = service.create_backup(backup_type='full')
print(f"Backup created: {backup_path}")
```

### استعادة قاعدة البيانات

```python
# Restore from backup
success = service.restore_backup(
    backup_path='/backups/gold_predictor_full_20251021_120000.dump',
    clean=True
)

if success:
    print("Database restored successfully")
```

### عرض النسخ المتاحة

```python
# List local backups
backups = service.list_backups(location='local')

for backup in backups:
    print(f"{backup['filename']} - {backup['size'] / 1024**2:.2f} MB")
```

### حذف النسخ القديمة

```python
# Cleanup old backups
deleted_count = service.cleanup_old_backups()
print(f"Deleted {deleted_count} old backups")
```

---

## جدولة النسخ الاحتياطي مع Cron

### إعداد Cron Job

```bash
# تحرير crontab
crontab -e

# إضافة السطر التالي للنسخ الاحتياطي اليومي في الساعة 2 صباحًا
0 2 * * * cd /home/ubuntu/gold-price-predictor/backend/app && python backup_cli.py backup --type full >> /var/log/backup.log 2>&1

# حذف النسخ القديمة أسبوعيًا (يوم الأحد في الساعة 3 صباحًا)
0 3 * * 0 cd /home/ubuntu/gold-price-predictor/backend/app && python backup_cli.py cleanup >> /var/log/backup.log 2>&1
```

---

## التخزين السحابي (Amazon S3)

### إعداد S3 Bucket

```bash
# إنشاء bucket جديد
aws s3 mb s3://my-backup-bucket

# تفعيل التشفير
aws s3api put-bucket-encryption \
    --bucket my-backup-bucket \
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }'

# تفعيل Versioning
aws s3api put-bucket-versioning \
    --bucket my-backup-bucket \
    --versioning-configuration Status=Enabled
```

### سياسة دورة الحياة (Lifecycle Policy)

```json
{
  "Rules": [
    {
      "Id": "BackupRetention",
      "Status": "Enabled",
      "Transitions": [
        {
          "Days": 7,
          "StorageClass": "GLACIER"
        }
      ],
      "Expiration": {
        "Days": 90
      }
    }
  ]
}
```

تطبيق السياسة:
```bash
aws s3api put-bucket-lifecycle-configuration \
    --bucket my-backup-bucket \
    --lifecycle-configuration file://lifecycle.json
```

---

## استراتيجية النسخ الاحتياطي

### 1. النسخ الاحتياطي اليومي

- **التوقيت:** 02:00 صباحًا (وقت منخفض الاستخدام)
- **النوع:** Full Backup
- **الموقع:** Local + S3
- **الاحتفاظ:** 30 يومًا

### 2. النسخ الاحتياطي الأسبوعي

- **التوقيت:** يوم الأحد 03:00 صباحًا
- **النوع:** Full Backup
- **الموقع:** S3 (Glacier Storage)
- **الاحتفاظ:** 90 يومًا

### 3. النسخ الاحتياطي الشهري

- **التوقيت:** أول يوم من كل شهر
- **النوع:** Full Backup
- **الموقع:** S3 (Glacier Deep Archive)
- **الاحتفاظ:** 1 سنة

---

## استعادة البيانات في حالات الطوارئ

### السيناريو 1: فقدان بيانات جزئي (آخر ساعة)

```bash
# 1. إيقاف التطبيق
sudo systemctl stop gold-predictor-api

# 2. استعادة من آخر نسخة احتياطية
python backup_cli.py list --location local
python backup_cli.py restore /backups/latest_backup.dump

# 3. إعادة تشغيل التطبيق
sudo systemctl start gold-predictor-api
```

**الوقت المتوقع:** 15-30 دقيقة

### السيناريو 2: فشل كامل لقاعدة البيانات

```bash
# 1. إنشاء قاعدة بيانات جديدة
createdb -U postgres gold_predictor

# 2. استعادة من S3
aws s3 cp s3://my-backup-bucket/database-backups/latest.dump /tmp/
python backup_cli.py restore /tmp/latest.dump

# 3. التحقق من سلامة البيانات
psql -U postgres -d gold_predictor -c "SELECT COUNT(*) FROM users;"
```

**الوقت المتوقع:** 1-2 ساعة

---

## المراقبة والتنبيهات

### إعداد التنبيهات

```python
# إضافة إلى backup_service.py
def send_backup_notification(status: str, message: str):
    """إرسال تنبيه عن حالة النسخ الاحتياطي"""
    # يمكن استخدام البريد الإلكتروني، Slack، أو أي خدمة أخرى
    pass
```

### سجلات النسخ الاحتياطي

```bash
# عرض سجلات النسخ الاحتياطي
tail -f /var/log/backup.log

# البحث عن أخطاء
grep ERROR /var/log/backup.log
```

---

## الأسئلة الشائعة

### كم يستغرق النسخ الاحتياطي؟

- قاعدة بيانات 1 GB: ~2-3 دقائق
- قاعدة بيانات 10 GB: ~15-20 دقيقة
- قاعدة بيانات 100 GB: ~2-3 ساعات

### هل يؤثر النسخ الاحتياطي على الأداء؟

النسخ الاحتياطي يستخدم `pg_dump` الذي يقرأ البيانات فقط، لذا التأثير على الأداء ضئيل. يُنصح بجدولة النسخ الاحتياطي في أوقات منخفضة الاستخدام.

### كيف أتحقق من سلامة النسخة الاحتياطية؟

```bash
# اختبار استعادة في بيئة منفصلة
createdb -U postgres test_restore
python backup_cli.py restore /backups/backup.dump
psql -U postgres -d test_restore -c "\dt"
dropdb -U postgres test_restore
```

---

## المراجع

- [PostgreSQL Backup Documentation](https://www.postgresql.org/docs/current/backup.html)
- [AWS S3 Backup Best Practices](https://docs.aws.amazon.com/AmazonS3/latest/userguide/backup-best-practices.html)
- [Disaster Recovery Planning](https://www.postgresql.org/docs/current/backup-dump.html)

---

**تاريخ آخر تحديث:** 21 أكتوبر 2025
**المؤلف:** Manus AI

