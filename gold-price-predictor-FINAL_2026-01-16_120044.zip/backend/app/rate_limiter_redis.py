# /home/ubuntu/gold-price-predictor/rate_limiter_redis.py
"""
نظام Rate Limiting الموزع باستخدام Redis
Distributed Rate Limiting with Redis
"""

import redis
import time
from typing import Optional
from fastapi import HTTPException, Request
from functools import wraps
import os

# إعدادات Redis
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_DB = int(os.getenv("REDIS_DB", 0))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", None)

# الحدود الافتراضية
DEFAULT_RATE_LIMIT = 100  # عدد الطلبات
DEFAULT_WINDOW = 60  # النافذة الزمنية بالثواني

# الاتصال بـ Redis
try:
    redis_client = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_DB,
        password=REDIS_PASSWORD,
        decode_responses=True,
        socket_connect_timeout=5
    )
    # اختبار الاتصال
    redis_client.ping()
    REDIS_AVAILABLE = True
    print(f"✅ Connected to Redis at {REDIS_HOST}:{REDIS_PORT}")
except (redis.ConnectionError, redis.TimeoutError) as e:
    print(f"⚠️  Redis not available: {e}")
    print("⚠️  Falling back to in-memory rate limiting")
    redis_client = None
    REDIS_AVAILABLE = False


class RedisRateLimiter:
    """
    Rate Limiter موزع باستخدام Redis

    يستخدم خوارزمية Sliding Window Counter
    """

    def __init__(
        self,
        max_requests: int = DEFAULT_RATE_LIMIT,
        window_seconds: int = DEFAULT_WINDOW,
        key_prefix: str = "rate_limit"
    ):
        """
        تهيئة Rate Limiter

        Args:
            max_requests: الحد الأقصى للطلبات
            window_seconds: النافذة الزمنية بالثواني
            key_prefix: بادئة المفتاح في Redis
        """
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.key_prefix = key_prefix
        self.fallback_storage = {}  # تخزين مؤقت في حالة عدم توفر Redis

    def _get_key(self, identifier: str) -> str:
        """
        الحصول على مفتاح Redis

        Args:
            identifier: معرف المستخدم/IP

        Returns:
            str: مفتاح Redis
        """
        return f"{self.key_prefix}:{identifier}"

    def _check_redis(self, identifier: str) -> tuple[bool, int]:
        """
        فحص الحد باستخدام Redis

        Args:
            identifier: معرف المستخدم/IP

        Returns:
            tuple: (allowed, remaining)
        """
        key = self._get_key(identifier)
        current_time = int(time.time())
        window_start = current_time - self.window_seconds

        # استخدام pipeline لتحسين الأداء
        pipe = redis_client.pipeline()

        # إزالة الطلبات القديمة
        pipe.zremrangebyscore(key, 0, window_start)

        # عد الطلبات الحالية
        pipe.zcard(key)

        # إضافة الطلب الحالي
        pipe.zadd(key, {str(current_time): current_time})

        # تعيين انتهاء الصلاحية
        pipe.expire(key, self.window_seconds)

        # تنفيذ جميع الأوامر
        results = pipe.execute()

        current_count = results[1]  # عدد الطلبات بعد إزالة القديمة

        if current_count < self.max_requests:
            remaining = self.max_requests - current_count - 1
            return True, remaining
        else:
            remaining = 0
            return False, remaining

    def _check_fallback(self, identifier: str) -> tuple[bool, int]:
        """
        فحص الحد باستخدام التخزين المؤقت (fallback)

        Args:
            identifier: معرف المستخدم/IP

        Returns:
            tuple: (allowed, remaining)
        """
        current_time = time.time()

        if identifier not in self.fallback_storage:
            self.fallback_storage[identifier] = []

        # إزالة الطلبات القديمة
        self.fallback_storage[identifier] = [
            t for t in self.fallback_storage[identifier]
            if current_time - t < self.window_seconds
        ]

        current_count = len(self.fallback_storage[identifier])

        if current_count < self.max_requests:
            self.fallback_storage[identifier].append(current_time)
            remaining = self.max_requests - current_count - 1
            return True, remaining
        else:
            remaining = 0
            return False, remaining

    def check_rate_limit(self, identifier: str) -> tuple[bool, int]:
        """
        فحص الحد للمستخدم/IP

        Args:
            identifier: معرف المستخدم/IP

        Returns:
            tuple: (allowed, remaining)
        """
        if REDIS_AVAILABLE and redis_client:
            try:
                return self._check_redis(identifier)
            except Exception as e:
                print(f"⚠️  Redis error: {e}, falling back to in-memory")
                return self._check_fallback(identifier)
        else:
            return self._check_fallback(identifier)


# إنشاء Rate Limiters مختلفة
strict_limiter = RedisRateLimiter(
    max_requests=10,
    window_seconds=60,
    key_prefix="strict")
normal_limiter = RedisRateLimiter(
    max_requests=100,
    window_seconds=60,
    key_prefix="normal")
relaxed_limiter = RedisRateLimiter(
    max_requests=1000,
    window_seconds=3600,
    key_prefix="relaxed")


def get_client_ip(request: Request) -> str:
    """
    الحصول على IP العميل

    Args:
        request: طلب FastAPI

    Returns:
        str: عنوان IP
    """
    # التحقق من X-Forwarded-For (للخوادم خلف proxy)
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()

    # التحقق من X-Real-IP
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip

    # استخدام client.host
    return request.client.host if request.client else "unknown"


async def rate_limit_middleware(
        request: Request,
        limiter: RedisRateLimiter = normal_limiter):
    """
    Middleware للتحقق من Rate Limit

    Args:
        request: طلب FastAPI
        limiter: Rate Limiter المستخدم

    Raises:
        HTTPException: إذا تم تجاوز الحد
    """
    client_ip = get_client_ip(request)
    allowed, remaining = limiter.check_rate_limit(client_ip)

    # إضافة headers للاستجابة
    request.state.rate_limit_remaining = remaining
    request.state.rate_limit_limit = limiter.max_requests

    if not allowed:
        raise HTTPException(
            status_code=429,
            detail=f"Too many requests. Please try again in {limiter.window_seconds} seconds.",
            headers={
                "X-RateLimit-Limit": str(limiter.max_requests),
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": str(int(time.time()) + limiter.window_seconds),
                "Retry-After": str(limiter.window_seconds)
            }
        )


def rate_limit(limiter: RedisRateLimiter = normal_limiter):
    """
    Decorator للتحقق من Rate Limit

    Args:
        limiter: Rate Limiter المستخدم

    Returns:
        function: Decorator
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # البحث عن Request في args
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break

            if request:
                await rate_limit_middleware(request, limiter)

            return await func(*args, **kwargs)
        return wrapper
    return decorator


# دالة لمسح Rate Limit لمستخدم معين (للاستخدام الإداري)
def clear_rate_limit(identifier: str, key_prefix: str = "normal"):
    """
    مسح Rate Limit لمستخدم معين

    Args:
        identifier: معرف المستخدم/IP
        key_prefix: بادئة المفتاح
    """
    if REDIS_AVAILABLE and redis_client:
        key = f"{key_prefix}:{identifier}"
        redis_client.delete(key)
        print(f"✅ Rate limit cleared for {identifier}")
    else:
        print("⚠️  Redis not available, cannot clear rate limit")


# دالة للحصول على إحصائيات Rate Limit
def get_rate_limit_stats(identifier: str, key_prefix: str = "normal") -> dict:
    """
    الحصول على إحصائيات Rate Limit

    Args:
        identifier: معرف المستخدم/IP
        key_prefix: بادئة المفتاح

    Returns:
        dict: إحصائيات
    """
    if REDIS_AVAILABLE and redis_client:
        key = f"{key_prefix}:{identifier}"
        current_time = int(time.time())
        window_start = current_time - DEFAULT_WINDOW

        count = redis_client.zcount(key, window_start, current_time)
        ttl = redis_client.ttl(key)

        return {
            "identifier": identifier,
            "current_count": count,
            "max_requests": DEFAULT_RATE_LIMIT,
            "remaining": max(0, DEFAULT_RATE_LIMIT - count),
            "ttl": ttl,
            "redis_available": True
        }
    else:
        return {
            "identifier": identifier,
            "redis_available": False,
            "message": "Redis not available, using fallback"
        }
