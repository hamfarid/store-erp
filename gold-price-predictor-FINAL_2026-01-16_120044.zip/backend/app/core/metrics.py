"""
Prometheus metrics for monitoring
"""

from prometheus_client import Counter, Histogram, Gauge, Info

# HTTP Request metrics
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint'],
    buckets=(0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0, 7.5, 10.0)
)

# Business metrics
predictions_total = Counter(
    'predictions_total',
    'Total predictions made',
    ['model', 'status']
)

prediction_duration_seconds = Histogram(
    'prediction_duration_seconds',
    'Prediction duration in seconds',
    ['model'],
    buckets=(0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0)
)

prediction_accuracy = Gauge(
    'prediction_accuracy',
    'Model prediction accuracy',
    ['model']
)

# Database metrics
db_query_duration_seconds = Histogram(
    'db_query_duration_seconds',
    'Database query duration in seconds',
    ['query_type'],
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5, 1.0)
)

db_connections_active = Gauge(
    'db_connections_active',
    'Active database connections',
    ['pool']
)

db_connections_idle = Gauge(
    'db_connections_idle',
    'Idle database connections',
    ['pool']
)

# Cache metrics
cache_hits_total = Counter(
    'cache_hits_total',
    'Total cache hits',
    ['cache_type']
)

cache_misses_total = Counter(
    'cache_misses_total',
    'Total cache misses',
    ['cache_type']
)

cache_hit_rate = Gauge(
    'cache_hit_rate',
    'Cache hit rate (percentage)',
    ['cache_type']
)

# Model metrics
model_training_duration_seconds = Histogram(
    'model_training_duration_seconds',
    'Model training duration in seconds',
    ['model'],
    buckets=(60, 300, 600, 1800, 3600, 7200)
)

model_size_bytes = Gauge(
    'model_size_bytes',
    'Model size in bytes',
    ['model']
)

# Celery metrics
celery_tasks_total = Counter(
    'celery_tasks_total',
    'Total Celery tasks',
    ['task', 'status']
)

celery_task_duration_seconds = Histogram(
    'celery_task_duration_seconds',
    'Celery task duration in seconds',
    ['task'],
    buckets=(1, 5, 10, 30, 60, 120, 300, 600)
)

celery_queue_length = Gauge(
    'celery_queue_length',
    'Celery queue length',
    ['queue']
)

# System info
app_info = Info('app', 'Application information')
app_info.info({
    'name': 'gold-price-predictor',
    'version': '2.0.0',
    'environment': 'production'
})


def update_cache_hit_rate(cache_type: str, hits: int, misses: int):
    """Update cache hit rate metric"""
    total = hits + misses
    if total > 0:
        hit_rate = (hits / total) * 100
        cache_hit_rate.labels(cache_type=cache_type).set(hit_rate)


def record_http_request(method: str, endpoint: str, status: int, duration: float):
    """Record HTTP request metrics"""
    http_requests_total.labels(method=method, endpoint=endpoint, status=status).inc()
    http_request_duration_seconds.labels(method=method, endpoint=endpoint).observe(duration)


def record_prediction(model: str, status: str, duration: float):
    """Record prediction metrics"""
    predictions_total.labels(model=model, status=status).inc()
    prediction_duration_seconds.labels(model=model).observe(duration)


def record_db_query(query_type: str, duration: float):
    """Record database query metrics"""
    db_query_duration_seconds.labels(query_type=query_type).observe(duration)


def record_cache_access(cache_type: str, hit: bool):
    """Record cache access metrics"""
    if hit:
        cache_hits_total.labels(cache_type=cache_type).inc()
    else:
        cache_misses_total.labels(cache_type=cache_type).inc()


def record_celery_task(task: str, status: str, duration: float):
    """Record Celery task metrics"""
    celery_tasks_total.labels(task=task, status=status).inc()
    celery_task_duration_seconds.labels(task=task).observe(duration)

