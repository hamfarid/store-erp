"""
Celery configuration for async task processing
"""

import os
from celery import Celery
from celery.schedules import crontab

# Redis URL for Celery broker and backend
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# Create Celery app
celery_app = Celery(
    'gold_predictor',
    broker=f'{REDIS_URL}/1',  # Use database 1 for broker
    backend=f'{REDIS_URL}/2'  # Use database 2 for results
)

# Celery configuration
celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,  # 5 minutes max per task
    task_soft_time_limit=240,  # Soft limit at 4 minutes
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
    result_expires=3600,  # Results expire after 1 hour
    broker_connection_retry_on_startup=True,
)

# Scheduled tasks (Celery Beat)
celery_app.conf.beat_schedule = {
    # Train model daily at midnight
    'train-model-daily': {
        'task': 'app.tasks.model_tasks.train_model',
        'schedule': crontab(hour=0, minute=0),
        'args': ('lstm',)
    },
    
    # Update predictions every hour
    'update-predictions-hourly': {
        'task': 'app.tasks.prediction_tasks.update_predictions',
        'schedule': crontab(minute=0),
    },
    
    # Cleanup old data weekly
    'cleanup-old-data-weekly': {
        'task': 'app.tasks.maintenance_tasks.cleanup_old_data',
        'schedule': crontab(day_of_week=0, hour=2, minute=0),
    },
}


# Task routes (optional)
celery_app.conf.task_routes = {
    'app.tasks.model_tasks.*': {'queue': 'model_training'},
    'app.tasks.prediction_tasks.*': {'queue': 'predictions'},
    'app.tasks.email_tasks.*': {'queue': 'emails'},
    'app.tasks.maintenance_tasks.*': {'queue': 'maintenance'},
}


def get_celery_info():
    """Get Celery configuration info"""
    return {
        "broker": celery_app.conf.broker_url.split("@")[-1],  # Hide credentials
        "backend": celery_app.conf.result_backend.split("@")[-1],
        "scheduled_tasks": len(celery_app.conf.beat_schedule),
        "task_routes": len(celery_app.conf.task_routes) if celery_app.conf.task_routes else 0
    }

