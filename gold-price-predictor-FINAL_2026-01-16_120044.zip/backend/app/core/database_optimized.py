"""
Optimized Database Module with Read Replicas Support

This module provides database connection management with read/write splitting
for improved performance and scalability.

Features:
- Read/write splitting
- Connection pooling
- Read replica load balancing
- Automatic failover to master

Classes:
    DatabaseManager: Main database management class

Functions:
    get_write_db: Get write database session
    get_read_db: Get read database session (with replica support)

Example:
    >>> from backend.app.core.database import get_write_db, get_read_db
    >>> 
    >>> # Write operations
    >>> async with get_write_db() as db:
    ...     await db.execute("INSERT INTO users ...")
    >>> 
    >>> # Read operations (uses replicas)
    >>> async with get_read_db() as db:
    ...     result = await db.execute("SELECT * FROM users ...")
"""

import random
from typing import AsyncGenerator, Optional, List
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.pool import NullPool, QueuePool
import logging

from .config import settings

logger = logging.getLogger(__name__)


class DatabaseManager:
    """
    Database connection manager with read/write splitting.
    
    This class manages connections to the primary database and read replicas,
    providing automatic load balancing and failover capabilities.
    
    Attributes:
        write_engine: SQLAlchemy engine for write operations
        read_engines: List of SQLAlchemy engines for read operations
        write_session_factory: Session factory for write operations
        read_session_factories: Session factories for read operations
    
    Example:
        >>> manager = DatabaseManager()
        >>> await manager.initialize()
        >>> async with manager.get_write_session() as session:
        ...     await session.execute("INSERT INTO users ...")
    """
    
    def __init__(self):
        """Initialize database manager."""
        self.write_engine = None
        self.read_engines: List = []
        self.write_session_factory = None
        self.read_session_factories: List = []
        self._initialized = False
    
    async def initialize(self):
        """
        Initialize database connections.
        
        This method creates connection pools for the primary database and
        all configured read replicas.
        """
        if self._initialized:
            logger.warning("DatabaseManager already initialized")
            return
        
        # Create write engine (primary database)
        self.write_engine = create_async_engine(
            settings.DATABASE_URL,
            poolclass=QueuePool,
            pool_size=20,
            max_overflow=40,
            pool_pre_ping=True,
            pool_recycle=3600,
            echo=settings.DEBUG,
        )
        
        self.write_session_factory = async_sessionmaker(
            self.write_engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )
        
        logger.info("Initialized write database connection")
        
        # Create read engines (replicas)
        replica_urls = []
        if settings.DATABASE_READ_REPLICA_1_URL:
            replica_urls.append(settings.DATABASE_READ_REPLICA_1_URL)
        if settings.DATABASE_READ_REPLICA_2_URL:
            replica_urls.append(settings.DATABASE_READ_REPLICA_2_URL)
        
        for i, replica_url in enumerate(replica_urls, 1):
            try:
                engine = create_async_engine(
                    replica_url,
                    poolclass=QueuePool,
                    pool_size=20,
                    max_overflow=40,
                    pool_pre_ping=True,
                    pool_recycle=3600,
                    echo=settings.DEBUG,
                )
                
                session_factory = async_sessionmaker(
                    engine,
                    class_=AsyncSession,
                    expire_on_commit=False,
                )
                
                self.read_engines.append(engine)
                self.read_session_factories.append(session_factory)
                
                logger.info(f"Initialized read replica {i} connection")
            except Exception as e:
                logger.error(f"Failed to initialize read replica {i}: {e}")
        
        # If no replicas, use write engine for reads
        if not self.read_engines:
            logger.warning("No read replicas configured, using write database for reads")
            self.read_engines.append(self.write_engine)
            self.read_session_factories.append(self.write_session_factory)
        
        self._initialized = True
        logger.info(f"DatabaseManager initialized with {len(self.read_engines)} read replica(s)")
    
    async def close(self):
        """Close all database connections."""
        if self.write_engine:
            await self.write_engine.dispose()
            logger.info("Closed write database connection")
        
        for i, engine in enumerate(self.read_engines, 1):
            if engine != self.write_engine:  # Don't close write engine twice
                await engine.dispose()
                logger.info(f"Closed read replica {i} connection")
        
        self._initialized = False
    
    def get_write_session(self) -> AsyncSession:
        """
        Get a database session for write operations.
        
        Returns:
            AsyncSession for write operations
        
        Example:
            >>> async with manager.get_write_session() as session:
            ...     await session.execute("INSERT INTO users ...")
            ...     await session.commit()
        """
        if not self._initialized:
            raise RuntimeError("DatabaseManager not initialized. Call initialize() first.")
        
        return self.write_session_factory()
    
    def get_read_session(self) -> AsyncSession:
        """
        Get a database session for read operations.
        
        This method uses round-robin load balancing to distribute read
        queries across available read replicas.
        
        Returns:
            AsyncSession for read operations
        
        Example:
            >>> async with manager.get_read_session() as session:
            ...     result = await session.execute("SELECT * FROM users ...")
        """
        if not self._initialized:
            raise RuntimeError("DatabaseManager not initialized. Call initialize() first.")
        
        # Round-robin selection of read replica
        factory = random.choice(self.read_session_factories)
        return factory()


# Global database manager instance
db_manager = DatabaseManager()


async def get_write_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for write database sessions.
    
    This function is designed to be used with FastAPI's dependency injection
    system. It provides a database session for write operations and ensures
    proper cleanup.
    
    Yields:
        AsyncSession for write operations
    
    Example:
        >>> from fastapi import Depends
        >>> 
        >>> @app.post("/users")
        >>> async def create_user(db: AsyncSession = Depends(get_write_db)):
        ...     await db.execute("INSERT INTO users ...")
        ...     await db.commit()
    """
    if not db_manager._initialized:
        await db_manager.initialize()
    
    async with db_manager.get_write_session() as session:
        try:
            yield session
        except Exception as e:
            await session.rollback()
            logger.error(f"Database write error: {e}")
            raise
        finally:
            await session.close()


async def get_read_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for read database sessions.
    
    This function is designed to be used with FastAPI's dependency injection
    system. It provides a database session for read operations using read
    replicas when available.
    
    Yields:
        AsyncSession for read operations
    
    Example:
        >>> from fastapi import Depends
        >>> 
        >>> @app.get("/users")
        >>> async def list_users(db: AsyncSession = Depends(get_read_db)):
        ...     result = await db.execute("SELECT * FROM users ...")
        ...     return result.fetchall()
    """
    if not db_manager._initialized:
        await db_manager.initialize()
    
    async with db_manager.get_read_session() as session:
        try:
            yield session
        except Exception as e:
            logger.error(f"Database read error: {e}")
            raise
        finally:
            await session.close()


async def init_database():
    """
    Initialize database connections on application startup.
    
    This function should be called during application startup to establish
    database connections and connection pools.
    
    Example:
        >>> from fastapi import FastAPI
        >>> 
        >>> app = FastAPI()
        >>> 
        >>> @app.on_event("startup")
        >>> async def startup():
        ...     await init_database()
    """
    await db_manager.initialize()
    logger.info("Database initialized successfully")


async def close_database():
    """
    Close database connections on application shutdown.
    
    This function should be called during application shutdown to properly
    close all database connections and release resources.
    
    Example:
        >>> from fastapi import FastAPI
        >>> 
        >>> app = FastAPI()
        >>> 
        >>> @app.on_event("shutdown")
        >>> async def shutdown():
        ...     await close_database()
    """
    await db_manager.close()
    logger.info("Database connections closed")

