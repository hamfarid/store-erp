"""
Application Configuration with AWS Secrets Manager

This module provides application configuration using AWS Secrets Manager
for sensitive data instead of environment variables.

Classes:
    Settings: Application settings with secrets from AWS

Example:
    >>> from backend.app.core.config import settings
    >>> print(settings.DATABASE_URL)
    'postgresql://user:pass@host:5432/db'
"""

from typing import Optional
from pydantic import BaseSettings
from .secrets import secrets


class Settings(BaseSettings):
    """
    Application settings with AWS Secrets Manager integration.
    
    This class retrieves sensitive configuration from AWS Secrets Manager
    and combines it with environment variables for non-sensitive settings.
    
    Attributes:
        # Database Configuration
        DATABASE_URL: PostgreSQL connection string
        DATABASE_READ_REPLICA_1_URL: Read replica 1 connection string
        DATABASE_READ_REPLICA_2_URL: Read replica 2 connection string
        
        # JWT Configuration
        JWT_SECRET_KEY: Secret key for JWT token signing
        JWT_ALGORITHM: JWT algorithm (HS256, RS256, etc.)
        ACCESS_TOKEN_EXPIRE_MINUTES: Access token expiration time
        REFRESH_TOKEN_EXPIRE_DAYS: Refresh token expiration time
        
        # Redis Configuration
        REDIS_HOST: Redis server host
        REDIS_PORT: Redis server port
        REDIS_PASSWORD: Redis password
        REDIS_DB: Redis database number
        REDIS_CLUSTER_ENDPOINT: Redis cluster endpoint (if using cluster)
        
        # API Keys
        ALPHA_VANTAGE_API_KEY: Alpha Vantage API key for market data
        OPENAI_API_KEY: OpenAI API key for AI features
        
        # Application Configuration
        APP_NAME: Application name
        APP_VERSION: Application version
        DEBUG: Debug mode flag
        ALLOWED_HOSTS: List of allowed hosts
        CORS_ORIGINS: List of allowed CORS origins
    
    Example:
        >>> settings = Settings()
        >>> print(settings.DATABASE_URL)
        >>> print(settings.JWT_SECRET_KEY)
    """
    
    # Application Info
    APP_NAME: str = "Gold Price Predictor"
    APP_VERSION: str = "2.0.0"
    DEBUG: bool = False
    
    # Allowed Hosts & CORS
    ALLOWED_HOSTS: list = ["*"]
    CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:8000",
        "https://goldpredictor.com",
        "https://app.goldpredictor.com",
    ]
    
    # Database Configuration (from AWS Secrets Manager)
    DATABASE_URL: str
    DATABASE_READ_REPLICA_1_URL: Optional[str] = None
    DATABASE_READ_REPLICA_2_URL: Optional[str] = None
    
    # JWT Configuration (from AWS Secrets Manager)
    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Redis Configuration (from AWS Secrets Manager)
    REDIS_HOST: str
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: Optional[str] = None
    REDIS_DB: int = 0
    REDIS_CLUSTER_ENDPOINT: Optional[str] = None
    
    # API Keys (from AWS Secrets Manager)
    ALPHA_VANTAGE_API_KEY: Optional[str] = None
    OPENAI_API_KEY: Optional[str] = None
    
    def __init__(self, **kwargs):
        """
        Initialize settings by retrieving secrets from AWS Secrets Manager.
        
        This constructor fetches all required secrets and constructs the
        configuration object.
        """
        # Retrieve database secrets
        db_config = secrets.get_secret('gold-predictor/database')
        
        # Construct DATABASE_URL
        kwargs['DATABASE_URL'] = (
            f"postgresql://{db_config['user']}:{db_config['password']}"
            f"@{db_config['host']}:{db_config['port']}/{db_config['database']}"
        )
        
        # Construct read replica URLs if configured
        if 'read_replica_1_host' in db_config:
            kwargs['DATABASE_READ_REPLICA_1_URL'] = (
                f"postgresql://{db_config['user']}:{db_config['password']}"
                f"@{db_config['read_replica_1_host']}:{db_config['port']}/{db_config['database']}"
            )
        
        if 'read_replica_2_host' in db_config:
            kwargs['DATABASE_READ_REPLICA_2_URL'] = (
                f"postgresql://{db_config['user']}:{db_config['password']}"
                f"@{db_config['read_replica_2_host']}:{db_config['port']}/{db_config['database']}"
            )
        
        # Retrieve JWT secrets
        jwt_config = secrets.get_secret('gold-predictor/jwt')
        kwargs['JWT_SECRET_KEY'] = jwt_config['secret_key']
        kwargs['JWT_ALGORITHM'] = jwt_config.get('algorithm', 'HS256')
        kwargs['ACCESS_TOKEN_EXPIRE_MINUTES'] = jwt_config.get('access_token_expire_minutes', 15)
        kwargs['REFRESH_TOKEN_EXPIRE_DAYS'] = jwt_config.get('refresh_token_expire_days', 7)
        
        # Retrieve Redis secrets
        redis_config = secrets.get_secret('gold-predictor/redis')
        kwargs['REDIS_HOST'] = redis_config['host']
        kwargs['REDIS_PORT'] = redis_config.get('port', 6379)
        kwargs['REDIS_PASSWORD'] = redis_config.get('password')
        kwargs['REDIS_DB'] = redis_config.get('db', 0)
        kwargs['REDIS_CLUSTER_ENDPOINT'] = redis_config.get('cluster_endpoint')
        
        # Retrieve API keys (optional)
        try:
            api_keys = secrets.get_secret('gold-predictor/api-keys')
            kwargs['ALPHA_VANTAGE_API_KEY'] = api_keys.get('alpha_vantage')
            kwargs['OPENAI_API_KEY'] = api_keys.get('openai')
        except ValueError:
            # API keys secret doesn't exist yet (optional)
            pass
        
        # Initialize parent class
        super().__init__(**kwargs)
    
    class Config:
        """Pydantic configuration"""
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()

