"""
Multi-Factor Authentication (MFA) Module

This module provides TOTP-based Multi-Factor Authentication functionality
using pyotp library.

Classes:
    MFAManager: Main MFA management class

Functions:
    generate_secret: Generate a new TOTP secret
    generate_qr_code: Generate QR code for TOTP setup
    verify_token: Verify a TOTP token
    generate_backup_codes: Generate backup codes for MFA recovery

Example:
    >>> from backend.app.core.mfa import MFAManager
    >>> secret = MFAManager.generate_secret()
    >>> qr_code = MFAManager.generate_qr_code(secret, "user@example.com")
    >>> is_valid = MFAManager.verify_token(secret, "123456")
"""

import pyotp
import qrcode
from io import BytesIO
import base64
import secrets
from typing import List, Tuple


class MFAManager:
    """
    TOTP-based Multi-Factor Authentication manager.
    
    This class provides methods for generating TOTP secrets, QR codes,
    and verifying TOTP tokens for two-factor authentication.
    
    Example:
        >>> manager = MFAManager()
        >>> secret = manager.generate_secret()
        >>> qr_code = manager.generate_qr_code(secret, "user@example.com")
        >>> is_valid = manager.verify_token(secret, "123456")
    """
    
    @staticmethod
    def generate_secret() -> str:
        """
        Generate a new TOTP secret key.
        
        This generates a random base32-encoded secret that can be used
        for TOTP token generation.
        
        Returns:
            Base32-encoded secret string (32 characters)
        
        Example:
            >>> secret = MFAManager.generate_secret()
            >>> print(secret)
            'JBSWY3DPEHPK3PXP'
        """
        return pyotp.random_base32()
    
    @staticmethod
    def generate_qr_code(secret: str, email: str, issuer_name: str = "Gold Predictor") -> str:
        """
        Generate a QR code for TOTP setup.
        
        This creates a QR code image that can be scanned by authenticator
        apps like Google Authenticator or Authy.
        
        Args:
            secret: The TOTP secret key
            email: User's email address (displayed in authenticator app)
            issuer_name: Name of the service (defaults to "Gold Predictor")
        
        Returns:
            Base64-encoded PNG image of the QR code
        
        Example:
            >>> qr_code = MFAManager.generate_qr_code("JBSWY3DPEHPK3PXP", "user@example.com")
            >>> # Use in HTML: <img src="data:image/png;base64,{qr_code}" />
        """
        # Create TOTP URI
        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(name=email, issuer_name=issuer_name)
        
        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(uri)
        qr.make(fit=True)
        
        # Create image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        img_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        
        return img_base64
    
    @staticmethod
    def verify_token(secret: str, token: str, valid_window: int = 1) -> bool:
        """
        Verify a TOTP token.
        
        This checks if the provided token is valid for the given secret.
        The valid_window parameter allows for clock drift tolerance.
        
        Args:
            secret: The TOTP secret key
            token: The 6-digit TOTP token to verify
            valid_window: Number of time steps to check before/after current time.
                         Defaults to 1 (allows 30 seconds drift)
        
        Returns:
            True if token is valid, False otherwise
        
        Example:
            >>> is_valid = MFAManager.verify_token("JBSWY3DPEHPK3PXP", "123456")
            >>> if is_valid:
            ...     print("Token is valid!")
        """
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=valid_window)
    
    @staticmethod
    def generate_backup_codes(count: int = 10) -> List[str]:
        """
        Generate backup codes for MFA recovery.
        
        These codes can be used to access the account if the user loses
        access to their authenticator app.
        
        Args:
            count: Number of backup codes to generate (defaults to 10)
        
        Returns:
            List of backup codes (8 characters each)
        
        Example:
            >>> codes = MFAManager.generate_backup_codes(10)
            >>> print(codes[0])
            'A3F9-2K7M'
        """
        codes = []
        for _ in range(count):
            # Generate 8-character code
            code = secrets.token_hex(4).upper()
            # Format as XXXX-XXXX
            formatted_code = f"{code[:4]}-{code[4:]}"
            codes.append(formatted_code)
        return codes
    
    @staticmethod
    def verify_backup_code(stored_codes: List[str], provided_code: str) -> Tuple[bool, List[str]]:
        """
        Verify a backup code and remove it from the list.
        
        Backup codes are single-use only. After verification, the code
        is removed from the list.
        
        Args:
            stored_codes: List of valid backup codes
            provided_code: The backup code to verify
        
        Returns:
            Tuple of (is_valid, remaining_codes)
        
        Example:
            >>> codes = ['A3F9-2K7M', 'B8H4-9L2N']
            >>> is_valid, remaining = MFAManager.verify_backup_code(codes, 'A3F9-2K7M')
            >>> print(is_valid)  # True
            >>> print(remaining)  # ['B8H4-9L2N']
        """
        # Normalize input (remove spaces, convert to uppercase)
        provided_code = provided_code.replace(' ', '').replace('-', '').upper()
        
        for i, code in enumerate(stored_codes):
            # Normalize stored code
            normalized_stored = code.replace(' ', '').replace('-', '').upper()
            
            if normalized_stored == provided_code:
                # Code is valid, remove it
                remaining_codes = stored_codes[:i] + stored_codes[i+1:]
                return True, remaining_codes
        
        # Code not found
        return False, stored_codes
    
    @staticmethod
    def get_current_token(secret: str) -> str:
        """
        Get the current TOTP token for a secret.
        
        This is useful for testing or debugging.
        
        Args:
            secret: The TOTP secret key
        
        Returns:
            Current 6-digit TOTP token
        
        Example:
            >>> token = MFAManager.get_current_token("JBSWY3DPEHPK3PXP")
            >>> print(token)
            '123456'
        """
        totp = pyotp.TOTP(secret)
        return totp.now()

