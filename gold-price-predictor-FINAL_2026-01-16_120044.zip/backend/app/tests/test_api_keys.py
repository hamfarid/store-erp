# File: /home/ubuntu/gold-price-predictor/backend/app/tests/test_api_keys.py
"""
Unit Tests for API Key Management
Tests for creating, validating, and managing API keys
"""

from services.api_key_service import APIKeyService
from auth_postgresql import hash_password
from database_enhanced import Base, User, APIKey
from main import app, get_db
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_api_keys.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={
        "check_same_thread": False})
TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine)

# Override get_db dependency


def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

# Test client
client = TestClient(app)


@pytest.fixture(scope="function")
def test_db():
    """Create test database"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def test_user(test_db):
    """Create a test user"""
    db = TestingSessionLocal()
    user = User(
        username="apiuser",
        email="api@example.com",
        hashed_password=hash_password("Api@123"),
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    user_id = user.id
    db.close()
    return user_id


@pytest.fixture
def auth_token(test_db, test_user):
    """Get authentication token"""
    response = client.post(
        "/api/auth/login",
        data={
            "username": "apiuser",
            "password": "Api@123"
        }
    )
    return response.json()["access_token"]


class TestAPIKeyService:
    """Test API Key Service functions"""

    def test_generate_key(self):
        """Test API key generation"""
        key = APIKeyService.generate_key()
        assert len(key) > 0
        assert isinstance(key, str)

    def test_hash_key(self):
        """Test API key hashing"""
        key = "test_key_123"
        hash1 = APIKeyService.hash_key(key)
        hash2 = APIKeyService.hash_key(key)

        assert hash1 == hash2  # Same key produces same hash
        assert len(hash1) == 64  # SHA256 produces 64 char hex string

    def test_create_api_key(self, test_db, test_user):
        """Test creating an API key"""
        db = TestingSessionLocal()

        api_key, plain_key = APIKeyService.create_api_key(
            db,
            test_user,
            "Test Key",
            expires_in_days=30
        )

        assert api_key.id is not None
        assert api_key.name == "Test Key"
        assert api_key.is_active
        assert plain_key is not None

        db.close()

    def test_validate_api_key(self, test_db, test_user):
        """Test validating an API key"""
        db = TestingSessionLocal()

        # Create key
        api_key, plain_key = APIKeyService.create_api_key(
            db,
            test_user,
            "Valid Key"
        )

        # Validate key
        user = APIKeyService.validate_api_key(db, plain_key)
        assert user is not None
        assert user.id == test_user

        # Check request count incremented
        db.refresh(api_key)
        assert api_key.request_count == 1

        db.close()

    def test_validate_invalid_key(self, test_db):
        """Test validating an invalid API key"""
        db = TestingSessionLocal()

        user = APIKeyService.validate_api_key(db, "invalid_key_123")
        assert user is None

        db.close()

    def test_revoke_api_key(self, test_db, test_user):
        """Test revoking an API key"""
        db = TestingSessionLocal()

        # Create key
        api_key, plain_key = APIKeyService.create_api_key(
            db,
            test_user,
            "Revoke Test"
        )

        # Revoke key
        success = APIKeyService.revoke_api_key(db, api_key.id, test_user)
        assert success

        # Verify key is inactive
        db.refresh(api_key)
        assert api_key.is_active == False

        # Verify validation fails
        user = APIKeyService.validate_api_key(db, plain_key)
        assert user is None

        db.close()


class TestAPIKeyEndpoints:
    """Test API Key HTTP endpoints"""

    def test_create_api_key_endpoint(self, test_db, auth_token):
        """Test creating API key via endpoint"""
        response = client.post(
            "/api/keys",
            json={
                "name": "My API Key",
                "expires_in_days": 365
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "My API Key"
        assert "key" in data  # Plain key returned on creation
        assert data["is_active"]

    def test_list_api_keys(self, test_db, auth_token):
        """Test listing API keys"""
        # Create a key first
        client.post(
            "/api/keys",
            json={"name": "Test Key 1"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        # List keys
        response = client.get(
            "/api/keys",
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1
        assert data[0]["name"] == "Test Key 1"

    def test_revoke_api_key_endpoint(self, test_db, auth_token):
        """Test revoking API key via endpoint"""
        # Create a key
        create_response = client.post(
            "/api/keys",
            json={"name": "Key to Revoke"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        key_id = create_response.json()["id"]

        # Revoke it
        response = client.delete(
            f"/api/keys/{key_id}",
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        assert response.status_code == 200
        assert "revoked" in response.json()["message"].lower()

    def test_get_api_key_stats(self, test_db, auth_token):
        """Test getting API key statistics"""
        # Create some keys
        client.post(
            "/api/keys",
            json={"name": "Key 1"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        client.post(
            "/api/keys",
            json={"name": "Key 2"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        # Get stats
        response = client.get(
            "/api/keys/stats",
            headers={"Authorization": f"Bearer {auth_token}"}
        )

        assert response.status_code == 200
        data = response.json()
        assert data["total_keys"] >= 2
        assert data["active_keys"] >= 2

    def test_unauthorized_api_key_access(self, test_db):
        """Test accessing API key endpoints without auth"""
        response = client.get("/api/keys")
        assert response.status_code == 401


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
