# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_jwt_blacklist.py
"""
Unit Tests for JWT Blacklist Service
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from services.jwt_blacklist import JWTBlacklist
import redis


class TestJWTBlacklist:
    """Test JWT Blacklist functionality"""

    @pytest.fixture
    def mock_redis(self):
        """Mock Redis client"""
        with patch('redis.from_url') as mock:
            redis_mock = MagicMock()
            redis_mock.ping.return_value = True
            redis_mock.setex.return_value = True
            redis_mock.exists.return_value = 0
            redis_mock.delete.return_value = 1
            redis_mock.keys.return_value = []
            mock.return_value = redis_mock
            yield redis_mock

    def test_initialization_with_redis(self, mock_redis):
        """Test successful initialization with Redis"""
        blacklist = JWTBlacklist()
        assert blacklist.enabled
        assert blacklist.redis_client is not None

    def test_initialization_without_redis(self):
        """Test initialization when Redis is disabled"""
        with patch.dict('os.environ', {'REDIS_ENABLED': 'false'}):
            blacklist = JWTBlacklist()
            assert blacklist.enabled == False
            assert blacklist.redis_client is None

    def test_blacklist_token_success(self, mock_redis):
        """Test successfully blacklisting a token"""
        blacklist = JWTBlacklist()
        result = blacklist.blacklist_token("test_token", expires_in=3600)
        assert result
        mock_redis.setex.assert_called_once()

    def test_blacklist_token_when_disabled(self):
        """Test blacklisting when service is disabled"""
        with patch.dict('os.environ', {'REDIS_ENABLED': 'false'}):
            blacklist = JWTBlacklist()
            result = blacklist.blacklist_token("test_token")
            assert result == False

    def test_is_blacklisted_true(self, mock_redis):
        """Test checking if token is blacklisted (true case)"""
        mock_redis.exists.return_value = 1
        blacklist = JWTBlacklist()
        result = blacklist.is_blacklisted("blacklisted_token")
        assert result

    def test_is_blacklisted_false(self, mock_redis):
        """Test checking if token is blacklisted (false case)"""
        mock_redis.exists.return_value = 0
        blacklist = JWTBlacklist()
        result = blacklist.is_blacklisted("valid_token")
        assert result == False

    def test_blacklist_user_tokens(self, mock_redis):
        """Test blacklisting all tokens for a user"""
        blacklist = JWTBlacklist()
        result = blacklist.blacklist_user_tokens(user_id=123, expires_in=7200)
        assert result
        mock_redis.setex.assert_called_once()

    def test_is_user_blacklisted_true(self, mock_redis):
        """Test checking if user is blacklisted (true case)"""
        mock_redis.exists.return_value = 1
        blacklist = JWTBlacklist()
        result = blacklist.is_user_blacklisted(user_id=123)
        assert result

    def test_is_user_blacklisted_false(self, mock_redis):
        """Test checking if user is blacklisted (false case)"""
        mock_redis.exists.return_value = 0
        blacklist = JWTBlacklist()
        result = blacklist.is_user_blacklisted(user_id=456)
        assert result == False

    def test_clear_user_blacklist(self, mock_redis):
        """Test clearing user from blacklist"""
        blacklist = JWTBlacklist()
        result = blacklist.clear_user_blacklist(user_id=123)
        assert result
        mock_redis.delete.assert_called_once()

    def test_get_blacklist_stats(self, mock_redis):
        """Test getting blacklist statistics"""
        mock_redis.keys.side_effect = [
            ["blacklist:token:1", "blacklist:token:2"],
            ["blacklist:user:1"]
        ]
        blacklist = JWTBlacklist()
        stats = blacklist.get_blacklist_stats()

        assert stats["enabled"]
        assert stats["blacklisted_tokens"] == 2
        assert stats["blacklisted_users"] == 1
        assert stats["total_blacklisted"] == 3

    def test_get_blacklist_stats_when_disabled(self):
        """Test getting stats when service is disabled"""
        with patch.dict('os.environ', {'REDIS_ENABLED': 'false'}):
            blacklist = JWTBlacklist()
            stats = blacklist.get_blacklist_stats()
            assert stats["enabled"] == False

    def test_blacklist_token_redis_error(self, mock_redis):
        """Test handling Redis errors when blacklisting"""
        mock_redis.setex.side_effect = redis.RedisError("Connection failed")
        blacklist = JWTBlacklist()
        result = blacklist.blacklist_token("test_token")
        assert result == False

    def test_is_blacklisted_redis_error(self, mock_redis):
        """Test handling Redis errors when checking blacklist"""
        mock_redis.exists.side_effect = redis.RedisError("Connection failed")
        blacklist = JWTBlacklist()
        result = blacklist.is_blacklisted("test_token")
        assert result == False

    def test_token_expiration(self, mock_redis):
        """Test that tokens are set with correct expiration"""
        blacklist = JWTBlacklist()
        expires_in = 1800
        blacklist.blacklist_token("test_token", expires_in=expires_in)

        # Verify setex was called with correct expiration
        call_args = mock_redis.setex.call_args
        assert call_args[0][1] == expires_in  # Second argument is expires_in
