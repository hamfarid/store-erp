# File: /home/ubuntu/gold-price-predictor/backend/app/tests/test_auth.py
"""
Unit Tests for Authentication System
Tests for user registration, login, 2FA, and JWT tokens
"""

from auth_postgresql import hash_password
from database_enhanced import Base, User
from main import app, get_db
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={
        "check_same_thread": False})
TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine)

# Override get_db dependency


def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

# Test client
client = TestClient(app)


@pytest.fixture(scope="function")
def test_db():
    """Create test database"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def test_user(test_db):
    """Create a test user"""
    db = TestingSessionLocal()
    user = User(
        username="testuser",
        email="test@example.com",
        hashed_password=hash_password("Test@123"),
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    db.close()
    return user


class TestAuthentication:
    """Test authentication endpoints"""

    def test_register_success(self, test_db):
        """Test successful user registration"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "newuser",
                "email": "newuser@example.com",
                "password": "NewUser@123"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_register_weak_password(self, test_db):
        """Test registration with weak password"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "weakuser",
                "email": "weak@example.com",
                "password": "weak"
            }
        )
        assert response.status_code == 422  # Validation error

    def test_register_duplicate_username(self, test_db, test_user):
        """Test registration with duplicate username"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "testuser",
                "email": "different@example.com",
                "password": "Test@123"
            }
        )
        assert response.status_code == 400

    def test_login_success(self, test_db, test_user):
        """Test successful login"""
        response = client.post(
            "/api/auth/login",
            data={
                "username": "testuser",
                "password": "Test@123"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data

    def test_login_wrong_password(self, test_db, test_user):
        """Test login with wrong password"""
        response = client.post(
            "/api/auth/login",
            data={
                "username": "testuser",
                "password": "WrongPassword"
            }
        )
        assert response.status_code == 401

    def test_login_nonexistent_user(self, test_db):
        """Test login with nonexistent user"""
        response = client.post(
            "/api/auth/login",
            data={
                "username": "nonexistent",
                "password": "Test@123"
            }
        )
        assert response.status_code == 401

    def test_get_current_user(self, test_db, test_user):
        """Test getting current user info"""
        # Login first
        login_response = client.post(
            "/api/auth/login",
            data={
                "username": "testuser",
                "password": "Test@123"
            }
        )
        token = login_response.json()["access_token"]

        # Get user info
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == "testuser"
        assert data["email"] == "test@example.com"

    def test_unauthorized_access(self, test_db):
        """Test accessing protected endpoint without token"""
        response = client.get("/api/auth/me")
        assert response.status_code == 401


class TestTwoFactorAuth:
    """Test 2FA functionality"""

    def test_setup_2fa(self, test_db, test_user):
        """Test 2FA setup"""
        # Login first
        login_response = client.post(
            "/api/auth/login",
            data={
                "username": "testuser",
                "password": "Test@123"
            }
        )
        token = login_response.json()["access_token"]

        # Setup 2FA
        response = client.post(
            "/api/auth/2fa/setup",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "secret" in data
        assert "qr_code" in data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
