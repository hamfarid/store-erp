# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_api_versioning.py
"""
Unit Tests for API Versioning
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from api_versioning import APIVersion, setup_api_versioning
from unittest.mock import Mock, MagicMock


class TestAPIVersioning:
    """Test API Versioning functionality"""

    @pytest.fixture
    def app(self):
        """Create FastAPI app for testing"""
        return FastAPI()

    @pytest.fixture
    def api_version(self, app):
        """Create APIVersion instance"""
        return APIVersion(app)

    def test_initialization(self, api_version):
        """Test APIVersion initialization"""
        assert api_version.app is not None
        assert isinstance(api_version.routers, dict)
        assert len(api_version.routers) == 0

    def test_create_router_v1(self, api_version):
        """Test creating V1 router"""
        router = api_version.create_router("v1", tags=["Test V1"])
        assert router is not None
        assert router.prefix == "/api/v1"
        assert "v1" in api_version.routers

    def test_create_router_v2(self, api_version):
        """Test creating V2 router"""
        router = api_version.create_router(
            "v2", prefix="/test", tags=["Test V2"])
        assert router is not None
        assert router.prefix == "/api/v2/test"
        assert "v2" in api_version.routers

    def test_create_router_unsupported_version(self, api_version):
        """Test creating router with unsupported version"""
        with pytest.raises(ValueError) as exc_info:
            api_version.create_router("v99")
        assert "Unsupported API version" in str(exc_info.value)

    def test_get_router_existing(self, api_version):
        """Test getting existing router"""
        router = api_version.create_router("v1")
        retrieved = api_version.get_router("v1")
        assert retrieved is router

    def test_get_router_non_existing(self, api_version):
        """Test getting non-existing router"""
        retrieved = api_version.get_router("v99")
        assert retrieved is None

    def test_get_version_from_request_v1(self):
        """Test extracting version from request path (v1)"""
        mock_request = Mock()
        mock_request.url.path = "/api/v1/predictions"

        version = APIVersion.get_version_from_request(mock_request)
        assert version == "v1"

    def test_get_version_from_request_v2(self):
        """Test extracting version from request path (v2)"""
        mock_request = Mock()
        mock_request.url.path = "/api/v2/users/123"

        version = APIVersion.get_version_from_request(mock_request)
        assert version == "v2"

    def test_get_version_from_request_no_version(self):
        """Test extracting version when no version in path"""
        mock_request = Mock()
        mock_request.url.path = "/api/predictions"

        version = APIVersion.get_version_from_request(mock_request)
        assert version == APIVersion.DEFAULT_VERSION

    def test_is_deprecated_true(self):
        """Test checking if version is deprecated (true case)"""
        APIVersion.DEPRECATED_VERSIONS = ["v0"]
        assert APIVersion.is_deprecated("v0")

    def test_is_deprecated_false(self):
        """Test checking if version is deprecated (false case)"""
        APIVersion.DEPRECATED_VERSIONS = []
        assert APIVersion.is_deprecated("v1") == False

    def test_get_latest_version(self):
        """Test getting latest version"""
        latest = APIVersion.get_latest_version()
        assert latest == APIVersion.SUPPORTED_VERSIONS[-1]

    def test_register_all_routers(self, api_version, app):
        """Test registering all routers"""
        api_version.create_router("v1")
        api_version.create_router("v2")
        api_version.register_all_routers()

        # Check that routers were registered
        # (FastAPI doesn't provide direct access to registered routers)
        assert len(api_version.routers) == 2

    def test_setup_api_versioning(self, app):
        """Test complete API versioning setup"""
        api_version = setup_api_versioning(app)

        assert api_version is not None
        assert "v1" in api_version.routers
        assert "v2" in api_version.routers

    def test_v1_health_endpoint(self, app):
        """Test V1 health endpoint"""
        setup_api_versioning(app)
        client = TestClient(app)

        response = client.get("/api/v1/health")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "v1"
        assert data["status"] == "healthy"

    def test_v2_health_endpoint(self, app):
        """Test V2 health endpoint"""
        setup_api_versioning(app)
        client = TestClient(app)

        response = client.get("/api/v2/health")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "v2"
        assert data["status"] == "healthy"
        assert "features" in data

    def test_v1_info_endpoint(self, app):
        """Test V1 info endpoint"""
        setup_api_versioning(app)
        client = TestClient(app)

        response = client.get("/api/v1/info")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "v1"
        assert "supported_versions" in data
        assert "latest_version" in data

    def test_v2_info_endpoint(self, app):
        """Test V2 info endpoint"""
        setup_api_versioning(app)
        client = TestClient(app)

        response = client.get("/api/v2/info")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "v2"
        assert "changelog" in data
        assert "v1" in data["changelog"]
        assert "v2" in data["changelog"]

    def test_deprecated_router_creation(self, api_version):
        """Test creating deprecated router"""
        router = api_version.create_router("v1", deprecated=True)
        assert router.deprecated

    def test_supported_versions_list(self):
        """Test supported versions list"""
        assert isinstance(APIVersion.SUPPORTED_VERSIONS, list)
        assert len(APIVersion.SUPPORTED_VERSIONS) > 0
        assert "v1" in APIVersion.SUPPORTED_VERSIONS
        assert "v2" in APIVersion.SUPPORTED_VERSIONS
