# FILE: backend/app/tests/test_assets_crud.py | PURPOSE: Unit tests for Assets CRUD endpoints | OWNER: Backend Team | RELATED: routers/assets.py | LAST-AUDITED: 2025-01-18

import pytest

from app.database_enhanced import User, Asset
from app.auth_postgresql import hash_password

# NOTE: Using conftest.py fixtures (setup_database, client, admin_user, admin_token, sample_asset)
# No need to import main.py or create engine here


# ==================== CREATE Tests ====================

def test_create_asset_success(client, admin_token):
    """Test creating a new asset successfully"""
    response = client.post(
        "/api/assets",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "symbol": "BTC",
            "name": "Bitcoin",
            "category": "Cryptocurrency",
            "description": "Bitcoin cryptocurrency"
        }
    )
    assert response.status_code == 201
    data = response.json()
    assert data["symbol"] == "BTC"
    assert data["name"] == "Bitcoin"
    assert data["category"] == "Cryptocurrency"
    assert "id" in data


def test_create_asset_duplicate_symbol(client, admin_token, sample_asset):
    """Test creating asset with duplicate symbol fails"""
    response = client.post(
        "/api/assets",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "symbol": "GOLD",  # Already exists
            "name": "Gold 2",
            "category": "Precious Metals"
        }
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"].lower()


def test_create_asset_invalid_symbol(client, admin_token):
    """Test creating asset with invalid symbol fails"""
    response = client.post(
        "/api/assets",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "symbol": "",  # Empty symbol
            "name": "Test Asset",
            "category": "Test"
        }
    )
    assert response.status_code == 422  # Validation error


# ==================== READ Tests ====================

def test_get_assets_list(client, admin_token, sample_asset):
    """Test getting list of assets"""
    response = client.get(
        "/api/assets",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "total" in data
    assert len(data["items"]) >= 1


def test_get_assets_with_search(client, admin_token, sample_asset):
    """Test searching assets by symbol"""
    response = client.get(
        "/api/assets?search=GOLD",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["items"]) >= 1
    assert data["items"][0]["symbol"] == "GOLD"
