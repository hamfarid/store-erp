# FILE: backend/app/tests/test_account_lockout.py | PURPOSE: Test account lockout functionality | OWNER: Security Team | RELATED: services/account_lockout.py, main.py | LAST-AUDITED: 2025-01-18
"""
Tests for Account Lockout Service
"""

import pytest
from app.services.account_lockout import AccountLockoutService, MAX_FAILED_ATTEMPTS


@pytest.fixture
def lockout_service():
    """Create account lockout service instance"""
    return AccountLockoutService(redis_url=None)  # In-memory mode for testing


# Use client fixture from conftest.py

@pytest.fixture
def test_user(client):
    """Create a test user"""
    response = client.post(
        "/api/auth/register",
        json={
            "username": "lockout_test_user",
            "email": "lockout@example.com",
            "password": "TestPass123!"
        }
    )
    assert response.status_code == 200
    return response.json()


def test_record_failed_attempt(lockout_service):
    """Test recording failed login attempts"""
    username = "testuser"

    # First attempt
    attempts = lockout_service.record_failed_attempt(username)
    assert attempts == 1

    # Second attempt
    attempts = lockout_service.record_failed_attempt(username)
    assert attempts == 2

    # Third attempt
    attempts = lockout_service.record_failed_attempt(username)
    assert attempts == 3


def test_account_locked_after_max_attempts(lockout_service):
    """Test that account is locked after MAX_FAILED_ATTEMPTS"""
    username = "testuser2"

    # Record MAX_FAILED_ATTEMPTS failed attempts
    for i in range(MAX_FAILED_ATTEMPTS):
        lockout_service.record_failed_attempt(username)

    # Account should be locked
    assert lockout_service.is_account_locked(username) is True


def test_reset_failed_attempts(lockout_service):
    """Test resetting failed attempts counter"""
    username = "testuser3"

    # Record some failed attempts
    lockout_service.record_failed_attempt(username)
    lockout_service.record_failed_attempt(username)
    assert lockout_service.get_failed_attempts(username) == 2

    # Reset
    lockout_service.reset_failed_attempts(username)
    assert lockout_service.get_failed_attempts(username) == 0


def test_unlock_account(lockout_service):
    """Test manually unlocking an account"""
    username = "testuser4"

    # Lock account
    for i in range(MAX_FAILED_ATTEMPTS):
        lockout_service.record_failed_attempt(username)

    assert lockout_service.is_account_locked(username) is True

    # Unlock
    lockout_service.unlock_account(username)
    assert lockout_service.is_account_locked(username) is False


def test_login_with_wrong_password_increments_counter(client, test_user):
    """Test that failed login increments counter"""
    # Try to login with wrong password
    response = client.post(
        "/api/auth/login",
        data={
            "username": "lockout_test_user",
            "password": "WrongPassword123!"
        }
    )

    assert response.status_code == 401
    assert "attempts remaining" in response.json()["detail"].lower()


def test_account_locked_after_5_failed_logins(client, test_user):
    """Test that account is locked after 5 failed login attempts"""
    # Attempt 5 failed logins
    for i in range(5):
        response = client.post(
            "/api/auth/login",
            data={
                "username": "lockout_test_user",
                "password": f"WrongPassword{i}!"
            }
        )
        assert response.status_code in [401, 403]

    # 6th attempt should return 403 (locked)
    response = client.post(
        "/api/auth/login",
        data={
            "username": "lockout_test_user",
            "password": "WrongPassword!"
        }
    )

    assert response.status_code == 403
    assert "locked" in response.json()["detail"].lower()


def test_successful_login_resets_counter(client, test_user):
    """Test that successful login resets failed attempts counter"""
    # Record some failed attempts
    for i in range(2):
        client.post(
            "/api/auth/login",
            data={
                "username": "lockout_test_user",
                "password": "WrongPassword!"
            }
        )

    # Successful login
    response = client.post(
        "/api/auth/login",
        data={
            "username": "lockout_test_user",
            "password": "TestPass123!"
        }
    )

    assert response.status_code == 200

    # Counter should be reset, so we can fail 5 more times
    for i in range(4):
        client.post(
            "/api/auth/login",
            data={
                "username": "lockout_test_user",
                "password": "WrongPassword!"
            }
        )

    # Should still be able to login (not locked yet)
    response = client.post(
        "/api/auth/login",
        data={
            "username": "lockout_test_user",
            "password": "TestPass123!"
        }
    )

    assert response.status_code == 200


def test_unlock_endpoint_requires_admin(client, test_user):
    """Test that unlock endpoint requires admin role"""
    # Try to unlock as regular user
    response = client.post(
        "/api/auth/unlock/lockout_test_user",
        headers={"Authorization": "Bearer " + test_user['access_token']}
    )

    # Should fail (user is not admin)
    assert response.status_code == 403


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
