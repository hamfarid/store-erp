# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_backup_service.py
"""
Unit Tests for Backup Service
"""

import pytest
import os
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path
from datetime import datetime, timedelta
from services.backup_service import BackupService


class TestBackupService:
    """Test Backup Service functionality"""

    @pytest.fixture
    def backup_service(self, tmp_path):
        """Create backup service with temporary directory"""
        return BackupService(
            db_host='localhost',
            db_port='5432',
            db_name='test_db',
            db_user='test_user',
            db_password='test_pass',
            backup_dir=str(tmp_path),
            retention_days=7
        )

    @pytest.fixture
    def mock_subprocess(self):
        """Mock subprocess for pg_dump/pg_restore"""
        with patch('services.backup_service.subprocess') as mock:
            mock.run.return_value = MagicMock(returncode=0, stderr='')
            yield mock

    def test_initialization(self, backup_service, tmp_path):
        """Test service initialization"""
        assert backup_service.db_host == 'localhost'
        assert backup_service.db_name == 'test_db'
        assert backup_service.backup_dir == tmp_path
        assert backup_service.retention_days == 7

    def test_backup_directory_creation(self, tmp_path):
        """Test that backup directory is created"""
        backup_dir = tmp_path / "backups"
        service = BackupService(backup_dir=str(backup_dir))
        assert backup_dir.exists()

    def test_create_backup_full(self, backup_service, mock_subprocess):
        """Test creating full backup"""
        backup_path = backup_service.create_backup(backup_type='full')

        assert backup_path is not None
        assert 'test_db_full_' in backup_path
        assert backup_path.endswith('.dump')

        # Verify pg_dump was called
        assert mock_subprocess.run.called
        call_args = mock_subprocess.run.call_args[0][0]
        assert 'pg_dump' in call_args
        assert '-Fc' in call_args
        assert 'test_db' in call_args

    def test_create_backup_schema(self, backup_service, mock_subprocess):
        """Test creating schema-only backup"""
        backup_path = backup_service.create_backup(backup_type='schema')

        assert backup_path is not None
        assert 'test_db_schema_' in backup_path

        # Verify --schema-only flag was used
        call_args = mock_subprocess.run.call_args[0][0]
        assert '--schema-only' in call_args

    def test_create_backup_failure(self, backup_service, mock_subprocess):
        """Test backup failure handling"""
        mock_subprocess.run.return_value = MagicMock(
            returncode=1,
            stderr='Error: connection failed'
        )

        backup_path = backup_service.create_backup()
        assert backup_path is None

    def test_create_backup_timeout(self, backup_service, mock_subprocess):
        """Test backup timeout handling"""
        from subprocess import TimeoutExpired
        mock_subprocess.run.side_effect = TimeoutExpired('pg_dump', 3600)

        backup_path = backup_service.create_backup()
        assert backup_path is None

    def test_restore_backup(self, backup_service, mock_subprocess):
        """Test database restoration"""
        backup_path = '/tmp/test_backup.dump'
        success = backup_service.restore_backup(backup_path, clean=True)

        assert success is True

        # Verify pg_restore was called
        call_args = mock_subprocess.run.call_args[0][0]
        assert 'pg_restore' in call_args
        assert '--clean' in call_args
        assert backup_path in call_args

    def test_restore_backup_no_clean(self, backup_service, mock_subprocess):
        """Test restoration without clean"""
        backup_path = '/tmp/test_backup.dump'
        success = backup_service.restore_backup(backup_path, clean=False)

        assert success is True

        # Verify --clean flag was not used
        call_args = mock_subprocess.run.call_args[0][0]
        assert '--clean' not in call_args

    def test_restore_backup_failure(self, backup_service, mock_subprocess):
        """Test restore failure handling"""
        mock_subprocess.run.return_value = MagicMock(
            returncode=1,
            stderr='Error: invalid backup file'
        )

        success = backup_service.restore_backup('/tmp/backup.dump')
        assert success is False

    def test_list_local_backups(self, backup_service, tmp_path):
        """Test listing local backups"""
        # Create dummy backup files
        backup1 = tmp_path / "test_db_full_20251021_120000.dump"
        backup2 = tmp_path / "test_db_full_20251020_120000.dump"
        backup1.touch()
        backup2.touch()

        backups = backup_service.list_backups(location='local')

        assert len(backups) == 2
        assert backups[0]['filename'] in ['test_db_full_20251021_120000.dump',
                                          'test_db_full_20251020_120000.dump']
        assert backups[0]['location'] == 'local'
        assert 'size' in backups[0]
        assert 'created' in backups[0]

    def test_list_backups_sorted(self, backup_service, tmp_path):
        """Test that backups are sorted by date (newest first)"""
        # Create files with different timestamps
        old_backup = tmp_path / "old.dump"
        new_backup = tmp_path / "new.dump"

        old_backup.touch()
        # Wait a bit to ensure different timestamps
        import time
        time.sleep(0.1)
        new_backup.touch()

        backups = backup_service.list_backups(location='local')

        # Newest should be first
        assert backups[0]['filename'] == 'new.dump'
        assert backups[1]['filename'] == 'old.dump'

    def test_cleanup_old_backups(self, backup_service, tmp_path):
        """Test cleanup of old backups"""
        # Create old and new backup files
        old_backup = tmp_path / "old_backup.dump"
        new_backup = tmp_path / "new_backup.dump"

        old_backup.touch()
        new_backup.touch()

        # Set old file's modification time to 10 days ago
        old_time = (datetime.now() - timedelta(days=10)).timestamp()
        os.utime(old_backup, (old_time, old_time))

        # Cleanup (retention is 7 days)
        deleted_count = backup_service.cleanup_old_backups()

        assert deleted_count == 1
        assert not old_backup.exists()
        assert new_backup.exists()

    def test_cleanup_no_old_backups(self, backup_service, tmp_path):
        """Test cleanup when no old backups exist"""
        # Create recent backup
        recent_backup = tmp_path / "recent.dump"
        recent_backup.touch()

        deleted_count = backup_service.cleanup_old_backups()

        assert deleted_count == 0
        assert recent_backup.exists()

    @patch('services.backup_service.boto3')
    def test_s3_initialization(self, mock_boto3, tmp_path):
        """Test S3 client initialization"""
        service = BackupService(
            backup_dir=str(tmp_path),
            s3_bucket='test-bucket'
        )

        assert service.s3_bucket == 'test-bucket'
        assert mock_boto3.client.called

    @patch('services.backup_service.boto3')
    def test_upload_to_s3(self, mock_boto3, backup_service, tmp_path):
        """Test S3 upload"""
        # Setup S3 client mock
        backup_service.s3_client = MagicMock()
        backup_service.s3_bucket = 'test-bucket'

        # Create test file
        test_file = tmp_path / "test.dump"
        test_file.write_text("test data")

        # Upload
        success = backup_service._upload_to_s3(test_file, "test.dump")

        assert success is True
        assert backup_service.s3_client.upload_file.called

    @patch('services.backup_service.boto3')
    def test_list_s3_backups(self, mock_boto3, backup_service):
        """Test listing S3 backups"""
        # Setup S3 client mock
        backup_service.s3_client = MagicMock()
        backup_service.s3_bucket = 'test-bucket'

        backup_service.s3_client.list_objects_v2.return_value = {
            'Contents': [
                {
                    'Key': 'database-backups/backup1.dump',
                    'Size': 1024,
                    'LastModified': datetime.now()
                },
                {
                    'Key': 'database-backups/backup2.dump',
                    'Size': 2048,
                    'LastModified': datetime.now()
                }
            ]
        }

        backups = backup_service.list_backups(location='s3')

        assert len(backups) == 2
        assert backups[0]['location'] == 's3'
        assert 's3://' in backups[0]['path']
