from fastapi import status
from unittest.mock import patch

# Mock the rate limiter to avoid using actual Redis in tests if possible,
# or use the existing RedisRateLimiter if it supports a test mode.
# Since rate_limiter is a global instance in dependencies.py, we can mock its check_rate_limit method.


def test_rate_limiting_users_create(client, admin_token):
    """Test rate limiting on user creation"""
    # Mock the rate limiter to return False (limit exceeded)
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.post(
            "/api/users/",
            json={
                "username": "testuser",
                "email": "test@example.com",
                "password": "Password123!"
            },
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS
        assert response.json()["detail"] == "Rate limit exceeded. Please try again later."


def test_rate_limiting_users_update(client, admin_token, regular_user):
    """Test rate limiting on user update"""
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.put(
            f"/api/users/{regular_user.id}",
            json={"email": "updated@example.com"},
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS


def test_rate_limiting_users_delete(client, admin_token, regular_user):
    """Test rate limiting on user deletion"""
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.delete(
            f"/api/users/{regular_user.id}",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS


def test_rate_limiting_assets_create(client, admin_token):
    """Test rate limiting on asset creation"""
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.post(
            "/api/assets/",
            json={
                "symbol": "TEST",
                "name": "Test Asset",
                "category": "Stocks"
            },
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS


def test_rate_limiting_predictions_update(client, admin_token):
    """Test rate limiting on prediction update"""
    # We need a prediction first, but for rate limiting check, 429 should be returned before 404
    # However, depending on implementation order, it might check DB first.
    # In my implementation, check_rate_limit is called at the very beginning of the function.
    # So even if prediction doesn't exist, it should return 429.

    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.put(
            "/api/predictions/999",
            json={"sentiment_score": 0.5},
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS


def test_rate_limiting_alerts_create(client, user_token, sample_asset):
    """Test rate limiting on alert creation"""
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=False):
        response = client.post(
            "/api/alerts/",
            json={
                "asset_id": sample_asset.id,
                "alert_type": "above",
                "target_price": 2000.0,
                "notification_method": "email"
            },
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS


def test_rate_limiting_success(client, admin_token):
    """Test that requests are allowed when limit is not exceeded"""
    # Mock the rate limiter to return True (limit not exceeded)
    with patch("app.dependencies.rate_limiter.check_rate_limit", return_value=True):
        # We use a simple GET request or a POST that would fail validation to ensure we passed rate limit check
        # But wait, I only applied rate limiting to mutation endpoints.
        # So I should try a POST that would otherwise succeed or fail with 400/422.

        response = client.post(
            "/api/users/",
            json={
                "username": "testuser2",
                "email": "test2@example.com",
                "password": "Password123!"
            },
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        # Should NOT be 429. Could be 201 or 400 if user exists, etc.
        assert response.status_code != status.HTTP_429_TOO_MANY_REQUESTS
