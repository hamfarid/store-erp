# File: /home/ubuntu/gold-price-predictor/audit_logger.py
"""
Audit Logging System
Comprehensive logging of all security-relevant events
"""

import logging
from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum
import json


class AuditEventType(str, Enum):
    """Types of audit events"""
    LOGIN_SUCCESS = "login_success"
    LOGIN_FAILURE = "login_failure"
    LOGOUT = "logout"
    PASSWORD_CHANGE = "password_change"
    TWO_FA_ENABLED = "2fa_enabled"
    TWO_FA_DISABLED = "2fa_disabled"
    API_KEY_CREATED = "api_key_created"
    API_KEY_REVOKED = "api_key_revoked"
    PREDICTION_REQUEST = "prediction_request"
    DATA_ACCESS = "data_access"
    PERMISSION_CHANGE = "permission_change"
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    UNAUTHORIZED_ACCESS = "unauthorized_access"


class AuditLogger:
    """Handle audit logging operations"""

    def __init__(self, log_file: str = "audit.log"):
        """
        Initialize audit logger

        Args:
            log_file: Path to audit log file
        """
        self.logger = logging.getLogger("audit")
        self.logger.setLevel(logging.INFO)

        # File handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)

        # Format: timestamp | event_type | user_id | ip_address | details
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)

    def log_event(
        self,
        event_type: AuditEventType,
        user_id: Optional[int] = None,
        ip_address: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        success: bool = True
    ):
        """
        Log an audit event

        Args:
            event_type: Type of event
            user_id: User ID (if applicable)
            ip_address: IP address of the request
            details: Additional details about the event
            success: Whether the event was successful
        """
        log_data = {
            "event_type": event_type.value,
            "user_id": user_id,
            "ip_address": ip_address,
            "success": success,
            "timestamp": datetime.utcnow().isoformat(),
            "details": details or {}
        }

        log_message = json.dumps(log_data)

        if success:
            self.logger.info(log_message)
        else:
            self.logger.warning(log_message)

    def log_login_attempt(
        self,
        user_id: Optional[int],
        ip_address: str,
        success: bool,
        failure_reason: Optional[str] = None
    ):
        """Log a login attempt"""
        event_type = AuditEventType.LOGIN_SUCCESS if success else AuditEventType.LOGIN_FAILURE
        details = {
            "failure_reason": failure_reason} if failure_reason else None
        self.log_event(event_type, user_id, ip_address, details, success)

    def log_api_access(
        self,
        user_id: int,
        ip_address: str,
        endpoint: str,
        method: str,
        status_code: int
    ):
        """Log API access"""
        details = {
            "endpoint": endpoint,
            "method": method,
            "status_code": status_code
        }
        success = 200 <= status_code < 300
        self.log_event(
            AuditEventType.DATA_ACCESS,
            user_id,
            ip_address,
            details,
            success)

    def log_rate_limit_exceeded(
        self,
        user_id: Optional[int],
        ip_address: str,
        endpoint: str
    ):
        """Log rate limit exceeded event"""
        details = {"endpoint": endpoint}
        self.log_event(
            AuditEventType.RATE_LIMIT_EXCEEDED,
            user_id,
            ip_address,
            details,
            success=False
        )


# Global audit logger instance
audit_logger = AuditLogger()
