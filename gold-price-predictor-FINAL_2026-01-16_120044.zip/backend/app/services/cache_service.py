# File: /home/ubuntu/gold-price-predictor/backend/app/services/cache_service.py
"""
Redis Caching Service
خدمة التخزين المؤقت باستخدام Redis
"""

import json
import hashlib
from typing import Any, Optional, Callable
from datetime import timedelta
from functools import wraps
import pickle

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    print("⚠️ Redis not available. Install with: pip install redis")


class CacheService:
    """
    خدمة التخزين المؤقت مع Redis
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        default_ttl: int = 3600
    ):
        """
        Initialize Cache Service
        
        Args:
            host: Redis host
            port: Redis port
            db: Redis database number
            password: Redis password
            default_ttl: Default time-to-live in seconds
        """
        self.default_ttl = default_ttl
        self.enabled = REDIS_AVAILABLE
        
        if REDIS_AVAILABLE:
            try:
                self.redis_client = redis.Redis(
                    host=host,
                    port=port,
                    db=db,
                    password=password,
                    decode_responses=False  # We'll handle encoding
                )
                # Test connection
                self.redis_client.ping()
                print(f"✅ Redis connected: {host}:{port}")
            except Exception as e:
                print(f"❌ Redis connection failed: {e}")
                self.enabled = False
                self.redis_client = None
        else:
            self.redis_client = None
    
    def _generate_key(self, prefix: str, *args, **kwargs) -> str:
        """
        Generate cache key from function arguments
        
        Args:
            prefix: Key prefix
            *args: Positional arguments
            **kwargs: Keyword arguments
            
        Returns:
            Cache key string
        """
        # Create a unique key based on arguments
        key_data = f"{prefix}:{str(args)}:{str(sorted(kwargs.items()))}"
        key_hash = hashlib.md5(key_data.encode()).hexdigest()
        return f"cache:{prefix}:{key_hash}"
    
    def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None
        """
        if not self.enabled or not self.redis_client:
            return None
        
        try:
            value = self.redis_client.get(key)
            if value:
                return pickle.loads(value)
            return None
        except Exception as e:
            print(f"❌ Cache get error: {e}")
            return None
    
    def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """
        Set value in cache
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds (None = default)
            
        Returns:
            Success status
        """
        if not self.enabled or not self.redis_client:
            return False
        
        try:
            ttl = ttl or self.default_ttl
            serialized_value = pickle.dumps(value)
            self.redis_client.setex(key, ttl, serialized_value)
            return True
        except Exception as e:
            print(f"❌ Cache set error: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """
        Delete value from cache
        
        Args:
            key: Cache key
            
        Returns:
            Success status
        """
        if not self.enabled or not self.redis_client:
            return False
        
        try:
            self.redis_client.delete(key)
            return True
        except Exception as e:
            print(f"❌ Cache delete error: {e}")
            return False
    
    def delete_pattern(self, pattern: str) -> int:
        """
        Delete all keys matching pattern
        
        Args:
            pattern: Key pattern (e.g., "cache:predictions:*")
            
        Returns:
            Number of keys deleted
        """
        if not self.enabled or not self.redis_client:
            return 0
        
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            print(f"❌ Cache delete pattern error: {e}")
            return 0
    
    def clear_all(self) -> bool:
        """
        Clear all cache
        
        Returns:
            Success status
        """
        if not self.enabled or not self.redis_client:
            return False
        
        try:
            self.redis_client.flushdb()
            return True
        except Exception as e:
            print(f"❌ Cache clear error: {e}")
            return False
    
    def get_stats(self) -> dict:
        """
        Get cache statistics
        
        Returns:
            Statistics dictionary
        """
        if not self.enabled or not self.redis_client:
            return {"error": "Redis not available"}
        
        try:
            info = self.redis_client.info()
            return {
                'connected': True,
                'used_memory': info.get('used_memory_human'),
                'total_keys': self.redis_client.dbsize(),
                'hits': info.get('keyspace_hits', 0),
                'misses': info.get('keyspace_misses', 0),
                'hit_rate': self._calculate_hit_rate(
                    info.get('keyspace_hits', 0),
                    info.get('keyspace_misses', 0)
                )
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _calculate_hit_rate(self, hits: int, misses: int) -> float:
        """Calculate cache hit rate"""
        total = hits + misses
        if total == 0:
            return 0.0
        return round((hits / total) * 100, 2)
    
    def cached(
        self,
        ttl: Optional[int] = None,
        key_prefix: Optional[str] = None
    ):
        """
        Decorator for caching function results
        
        Args:
            ttl: Time-to-live in seconds
            key_prefix: Custom key prefix
            
        Example:
            @cache_service.cached(ttl=300, key_prefix="predictions")
            def get_prediction(asset_id: int):
                # Expensive operation
                return result
        """
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key
                prefix = key_prefix or func.__name__
                cache_key = self._generate_key(prefix, *args, **kwargs)
                
                # Try to get from cache
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    return cached_value
                
                # Execute function
                result = func(*args, **kwargs)
                
                # Store in cache
                self.set(cache_key, result, ttl)
                
                return result
            
            return wrapper
        return decorator


# Global cache service instance
cache_service = CacheService()


# Convenience decorators
def cached(ttl: int = 3600, key_prefix: Optional[str] = None):
    """
    Convenience decorator for caching
    
    Args:
        ttl: Time-to-live in seconds
        key_prefix: Custom key prefix
    """
    return cache_service.cached(ttl=ttl, key_prefix=key_prefix)


# Example usage
if __name__ == "__main__":
    print("🔄 Redis Caching Service")
    print("=" * 50)
    
    # Create cache service
    cache = CacheService()
    
    # Test basic operations
    print("\n📝 Testing basic operations...")
    cache.set("test_key", {"value": 123}, ttl=60)
    result = cache.get("test_key")
    print(f"   Cached value: {result}")
    
    # Test decorator
    print("\n🎯 Testing decorator...")
    
    @cache.cached(ttl=300, key_prefix="expensive")
    def expensive_operation(x: int, y: int):
        print(f"   Executing expensive operation: {x} + {y}")
        return x + y
    
    # First call (cache miss)
    result1 = expensive_operation(5, 3)
    print(f"   Result 1: {result1}")
    
    # Second call (cache hit)
    result2 = expensive_operation(5, 3)
    print(f"   Result 2: {result2}")
    
    # Get stats
    print("\n📊 Cache Statistics:")
    stats = cache.get_stats()
    for key, value in stats.items():
        print(f"   {key}: {value}")
    
    print("\n✅ Cache Service initialized successfully!")

