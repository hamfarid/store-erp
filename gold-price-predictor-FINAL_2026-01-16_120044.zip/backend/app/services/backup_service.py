# File:
# /home/ubuntu/gold-price-predictor/backend/app/services/backup_service.py
"""
Automated Backup Service
Provides automated database backup and restoration functionality
"""

import os
import subprocess
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path
import boto3
from botocore.exceptions import ClientError
import schedule
import time

logger = logging.getLogger(__name__)


class BackupService:
    """
    Automated Backup Service

    Features:
    - Automated PostgreSQL backups
    - Local and cloud storage (S3)
    - Backup rotation and cleanup
    - Restoration capabilities
    - Scheduled backups
    """

    def __init__(
        self,
        db_host: str = None,
        db_port: str = None,
        db_name: str = None,
        db_user: str = None,
        db_password: str = None,
        backup_dir: str = "/backups",
        s3_bucket: str = None,
        s3_prefix: str = "database-backups",
        retention_days: int = 30
    ):
        """
        Initialize Backup Service

        Args:
            db_host: Database host
            db_port: Database port
            db_name: Database name
            db_user: Database user
            db_password: Database password
            backup_dir: Local backup directory
            s3_bucket: S3 bucket name for cloud backups
            s3_prefix: S3 prefix for backup files
            retention_days: Number of days to retain backups
        """
        self.db_host = db_host or os.getenv('DB_HOST', 'localhost')
        self.db_port = db_port or os.getenv('DB_PORT', '5432')
        self.db_name = db_name or os.getenv('DB_NAME', 'gold_predictor')
        self.db_user = db_user or os.getenv('DB_USER', 'postgres')
        self.db_password = db_password or os.getenv('DB_PASSWORD', 'postgres')

        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

        self.s3_bucket = s3_bucket or os.getenv('S3_BACKUP_BUCKET')
        self.s3_prefix = s3_prefix
        self.retention_days = retention_days

        # Initialize S3 client if bucket is configured
        self.s3_client = None
        if self.s3_bucket:
            try:
                self.s3_client = boto3.client('s3')
                logger.info(f"S3 backup enabled: {self.s3_bucket}")
            except Exception as e:
                logger.error(f"Failed to initialize S3 client: {str(e)}")

    def create_backup(self, backup_type: str = "full") -> Optional[str]:
        """
        Create database backup

        Args:
            backup_type: Type of backup ("full" or "schema")

        Returns:
            Path to backup file or None if failed
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{self.db_name}_{backup_type}_{timestamp}.dump"
        backup_path = self.backup_dir / backup_filename

        try:
            logger.info(f"Starting {backup_type} backup: {backup_filename}")

            # Set password environment variable
            env = os.environ.copy()
            env['PGPASSWORD'] = self.db_password

            # Build pg_dump command
            cmd = [
                'pg_dump',
                '-h', self.db_host,
                '-p', self.db_port,
                '-U', self.db_user,
                '-Fc',  # Custom format (compressed)
                '-f', str(backup_path),
                self.db_name
            ]

            if backup_type == "schema":
                cmd.append('--schema-only')

            # Execute backup
            result = subprocess.run(
                cmd,
                env=env,
                capture_output=True,
                text=True,
                timeout=3600  # 1 hour timeout
            )

            if result.returncode != 0:
                logger.error(f"Backup failed: {result.stderr}")
                return None

            logger.info(f"Backup created successfully: {backup_path}")

            # Upload to S3 if configured
            if self.s3_client:
                self._upload_to_s3(backup_path, backup_filename)

            return str(backup_path)

        except subprocess.TimeoutExpired:
            logger.error("Backup timeout exceeded")
            return None
        except Exception as e:
            logger.error(f"Backup error: {str(e)}")
            return None

    def _upload_to_s3(self, local_path: Path, filename: str) -> bool:
        """
        Upload backup to S3

        Args:
            local_path: Local file path
            filename: S3 object key

        Returns:
            True if successful, False otherwise
        """
        try:
            s3_key = f"{self.s3_prefix}/{filename}"

            logger.info(f"Uploading to S3: s3://{self.s3_bucket}/{s3_key}")

            self.s3_client.upload_file(
                str(local_path),
                self.s3_bucket,
                s3_key,
                ExtraArgs={
                    'ServerSideEncryption': 'AES256',
                    'StorageClass': 'STANDARD_IA'  # Infrequent Access
                }
            )

            logger.info("S3 upload successful")
            return True

        except ClientError as e:
            logger.error(f"S3 upload failed: {str(e)}")
            return False

    def restore_backup(self, backup_path: str, clean: bool = True) -> bool:
        """
        Restore database from backup

        Args:
            backup_path: Path to backup file
            clean: Drop existing database objects before restore

        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info(f"Starting database restoration from: {backup_path}")

            # Set password environment variable
            env = os.environ.copy()
            env['PGPASSWORD'] = self.db_password

            # Build pg_restore command
            cmd = [
                'pg_restore',
                '-h', self.db_host,
                '-p', self.db_port,
                '-U', self.db_user,
                '-d', self.db_name,
                '-v'  # Verbose
            ]

            if clean:
                cmd.append('--clean')

            cmd.append(backup_path)

            # Execute restore
            result = subprocess.run(
                cmd,
                env=env,
                capture_output=True,
                text=True,
                timeout=3600
            )

            if result.returncode != 0:
                logger.error(f"Restore failed: {result.stderr}")
                return False

            logger.info("Database restored successfully")
            return True

        except subprocess.TimeoutExpired:
            logger.error("Restore timeout exceeded")
            return False
        except Exception as e:
            logger.error(f"Restore error: {str(e)}")
            return False

    def list_backups(self, location: str = "local") -> List[Dict[str, Any]]:
        """
        List available backups

        Args:
            location: "local" or "s3"

        Returns:
            List of backup information dictionaries
        """
        backups = []

        if location == "local":
            for backup_file in self.backup_dir.glob("*.dump"):
                backups.append({
                    "filename": backup_file.name,
                    "path": str(backup_file),
                    "size": backup_file.stat().st_size,
                    "created": datetime.fromtimestamp(backup_file.stat().st_mtime),
                    "location": "local"
                })

        elif location == "s3" and self.s3_client:
            try:
                response = self.s3_client.list_objects_v2(
                    Bucket=self.s3_bucket,
                    Prefix=self.s3_prefix
                )

                for obj in response.get('Contents', []):
                    backups.append({
                        "filename": obj['Key'].split('/')[-1],
                        "path": f"s3://{self.s3_bucket}/{obj['Key']}",
                        "size": obj['Size'],
                        "created": obj['LastModified'],
                        "location": "s3"
                    })
            except ClientError as e:
                logger.error(f"Failed to list S3 backups: {str(e)}")

        # Sort by creation date (newest first)
        backups.sort(key=lambda x: x['created'], reverse=True)
        return backups

    def cleanup_old_backups(self) -> int:
        """
        Remove backups older than retention period

        Returns:
            Number of backups deleted
        """
        deleted_count = 0
        cutoff_date = datetime.now() - timedelta(days=self.retention_days)

        # Cleanup local backups
        for backup_file in self.backup_dir.glob("*.dump"):
            file_date = datetime.fromtimestamp(backup_file.stat().st_mtime)
            if file_date < cutoff_date:
                try:
                    backup_file.unlink()
                    logger.info(f"Deleted old backup: {backup_file.name}")
                    deleted_count += 1
                except Exception as e:
                    logger.error(
                        f"Failed to delete {backup_file.name}: {str(e)}")

        # Cleanup S3 backups
        if self.s3_client:
            try:
                response = self.s3_client.list_objects_v2(
                    Bucket=self.s3_bucket,
                    Prefix=self.s3_prefix
                )

                for obj in response.get('Contents', []):
                    if obj['LastModified'].replace(tzinfo=None) < cutoff_date:
                        self.s3_client.delete_object(
                            Bucket=self.s3_bucket,
                            Key=obj['Key']
                        )
                        logger.info(f"Deleted old S3 backup: {obj['Key']}")
                        deleted_count += 1
            except ClientError as e:
                logger.error(f"Failed to cleanup S3 backups: {str(e)}")

        logger.info(f"Cleanup complete: {deleted_count} backups deleted")
        return deleted_count

    def schedule_backups(self, time_str: str = "02:00"):
        """
        Schedule daily backups

        Args:
            time_str: Time to run backup (HH:MM format)
        """
        schedule.every().day.at(time_str).do(self.create_backup)
        schedule.every().week.do(self.cleanup_old_backups)

        logger.info(f"Scheduled daily backups at {time_str}")

        # Run scheduler
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute


def backup_database_manual(backup_type: str = "full") -> Optional[str]:
    """
    Manual backup function for CLI usage

    Args:
        backup_type: Type of backup

    Returns:
        Path to backup file
    """
    service = BackupService()
    return service.create_backup(backup_type=backup_type)


def restore_database_manual(backup_path: str) -> bool:
    """
    Manual restore function for CLI usage

    Args:
        backup_path: Path to backup file

    Returns:
        True if successful
    """
    service = BackupService()
    return service.restore_backup(backup_path)
