
"""
Notification Service
Handles sending notifications via Email and SMS
Integrates with AWS SES and SNS (simulated in dev)
"""


import logging
import os
from typing import List, Optional

# from app.config_secure import settings  # Circular import risk? Use generic config or pass settings
# Best practice: use explicit config injection or get_secret

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Service for sending notifications
    Supports: EMAIL, SMS
    """

    def __init__(self):
        self.email_enabled = True  # os.getenv("EMAIL_ENABLED", "true").lower() == "true"
        self.sms_enabled = True    # os.getenv("SMS_ENABLED", "true").lower() == "true"
        self.aws_region = os.getenv("AWS_REGION", "us-east-1")

        # In production, initialize boto3 clients here
        self.ses_client = None
        self.sns_client = None

        logger.info("Notification Service initialized")

    async def send_email(self, recipient: str, subject: str, body: str) -> bool:
        """
        Send an email notification
        """
        if not self.email_enabled:
            logger.info(f"Email disabled. Mock send to {recipient}: {subject}")
            return True

        try:
            # Simulation for development
            logger.info(f"Sending EMAIL to {recipient}")
            logger.info(f"Subject: {subject}")
            logger.info(f"Body: {body[:100]}...")  # Log 100 chars

            # NOTE: Implement actual AWS SES send_email
            # if self.ses_client:
            #     response = self.ses_client.send_email(...)

            return True
        except Exception as e:
            logger.error(f"Failed to send email to {recipient}: {str(e)}")
            return False

    async def send_sms(self, phone_number: str, message: str) -> bool:
        """
        Send an SMS notification
        """
        if not self.sms_enabled:
            logger.info(f"SMS disabled. Mock send to {phone_number}")
            return True

        try:
            # Simulation for development
            logger.info(f"Sending SMS to {phone_number}: {message}")

            # NOTE: Implement actual AWS SNS publish
            # if self.sns_client:
            #     self.sns_client.publish(PhoneNumber=phone_number, Message=message)

            return True
        except Exception as e:
            logger.error(f"Failed to send SMS to {phone_number}: {str(e)}")
            return False

    async def send_alert(self, user_email: str, user_phone: Optional[str], alert_title: str, alert_message: str, methods: List[str]):
        """
        Send alert via preferred methods
        methods: e.g. ["EMAIL", "SMS"]
        """
        results = {}

        if "EMAIL" in methods and user_email:
            results["email"] = await self.send_email(user_email, alert_title, alert_message)

        if "SMS" in methods and user_phone:
            results["sms"] = await self.send_sms(user_phone, alert_message)

        return results


# Global instance
notification_service = NotificationService()
