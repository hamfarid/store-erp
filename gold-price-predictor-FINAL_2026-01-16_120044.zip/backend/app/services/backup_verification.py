# File: /home/ubuntu/gold-price-predictor/backend/app/services/backup_verification.py
"""
Backup Verification Service
خدمة التحقق من سلامة النسخ الاحتياطية
"""

import os
import hashlib
import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import tempfile
import shutil


class BackupVerificationService:
    """
    خدمة التحقق من سلامة النسخ الاحتياطية
    """
    
    def __init__(self, backup_dir: str = "/backups"):
        """
        Initialize Backup Verification Service
        
        Args:
            backup_dir: مسار مجلد النسخ الاحتياطية
        """
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self.verification_log_file = self.backup_dir / "verification_log.json"
        self.verification_log = self._load_verification_log()
    
    def _load_verification_log(self) -> List[Dict]:
        """Load verification log from file"""
        if self.verification_log_file.exists():
            with open(self.verification_log_file, 'r') as f:
                return json.load(f)
        return []
    
    def _save_verification_log(self):
        """Save verification log to file"""
        with open(self.verification_log_file, 'w') as f:
            json.dump(self.verification_log, f, indent=2, default=str)
    
    def calculate_checksum(self, file_path: Path, algorithm: str = "sha256") -> str:
        """
        Calculate checksum for a file
        
        Args:
            file_path: مسار الملف
            algorithm: خوارزمية الـ Hash (md5, sha1, sha256)
            
        Returns:
            Checksum string
        """
        hash_func = hashlib.new(algorithm)
        
        with open(file_path, 'rb') as f:
            # Read file in chunks to handle large files
            for chunk in iter(lambda: f.read(4096), b''):
                hash_func.update(chunk)
        
        return hash_func.hexdigest()
    
    def verify_backup_integrity(self, backup_path: Path) -> Dict:
        """
        Verify backup file integrity
        
        Args:
            backup_path: مسار ملف النسخة الاحتياطية
            
        Returns:
            Verification result dictionary
        """
        result = {
            'backup_path': str(backup_path),
            'timestamp': datetime.now().isoformat(),
            'checks': {}
        }
        
        # Check 1: File exists
        result['checks']['file_exists'] = backup_path.exists()
        
        if not result['checks']['file_exists']:
            result['status'] = 'failed'
            result['error'] = 'Backup file not found'
            return result
        
        # Check 2: File size
        file_size = backup_path.stat().st_size
        result['checks']['file_size'] = file_size
        result['checks']['file_size_mb'] = round(file_size / (1024 * 1024), 2)
        result['checks']['file_not_empty'] = file_size > 0
        
        # Check 3: Calculate checksum
        try:
            checksum = self.calculate_checksum(backup_path)
            result['checks']['checksum'] = checksum
            result['checks']['checksum_calculated'] = True
        except Exception as e:
            result['checks']['checksum_calculated'] = False
            result['checks']['checksum_error'] = str(e)
        
        # Check 4: Verify it's a valid dump file
        result['checks']['is_valid_dump'] = self._verify_dump_format(backup_path)
        
        # Overall status
        all_checks_passed = (
            result['checks']['file_exists'] and
            result['checks']['file_not_empty'] and
            result['checks']['checksum_calculated'] and
            result['checks']['is_valid_dump']
        )
        
        result['status'] = 'passed' if all_checks_passed else 'failed'
        
        # Save to log
        self.verification_log.append(result)
        self._save_verification_log()
        
        return result
    
    def _verify_dump_format(self, backup_path: Path) -> bool:
        """
        Verify that backup file is a valid PostgreSQL dump
        
        Args:
            backup_path: مسار ملف النسخة الاحتياطية
            
        Returns:
            True if valid dump format
        """
        try:
            # Read first few bytes to check format
            with open(backup_path, 'rb') as f:
                header = f.read(100)
            
            # Check for PostgreSQL dump signature
            # Custom format dumps start with 'PGDMP'
            if b'PGDMP' in header:
                return True
            
            # Plain text dumps contain SQL commands
            if b'CREATE' in header or b'INSERT' in header or b'--' in header:
                return True
            
            return False
        except Exception:
            return False
    
    def test_restore(
        self,
        backup_path: Path,
        test_db_name: str = "test_restore_db"
    ) -> Dict:
        """
        Test restore backup to a temporary database
        
        Args:
            backup_path: مسار ملف النسخة الاحتياطية
            test_db_name: اسم قاعدة البيانات المؤقتة للاختبار
            
        Returns:
            Test restore result dictionary
        """
        result = {
            'backup_path': str(backup_path),
            'test_db_name': test_db_name,
            'timestamp': datetime.now().isoformat(),
            'steps': {}
        }
        
        try:
            # Step 1: Create test database
            result['steps']['create_test_db'] = self._create_test_database(test_db_name)
            
            if not result['steps']['create_test_db']['success']:
                result['status'] = 'failed'
                return result
            
            # Step 2: Restore backup to test database
            result['steps']['restore_backup'] = self._restore_to_database(
                backup_path,
                test_db_name
            )
            
            if not result['steps']['restore_backup']['success']:
                result['status'] = 'failed'
                return result
            
            # Step 3: Verify tables exist
            result['steps']['verify_tables'] = self._verify_tables_exist(test_db_name)
            
            # Step 4: Verify data integrity
            result['steps']['verify_data'] = self._verify_data_integrity(test_db_name)
            
            # Overall status
            all_steps_passed = all(
                step.get('success', False)
                for step in result['steps'].values()
            )
            
            result['status'] = 'passed' if all_steps_passed else 'failed'
            
        except Exception as e:
            result['status'] = 'error'
            result['error'] = str(e)
        
        finally:
            # Step 5: Cleanup - drop test database
            result['steps']['cleanup'] = self._drop_test_database(test_db_name)
        
        # Save to log
        self.verification_log.append(result)
        self._save_verification_log()
        
        return result
    
    def _create_test_database(self, db_name: str) -> Dict:
        """Create temporary test database"""
        try:
            cmd = f"createdb {db_name}"
            subprocess.run(cmd, shell=True, check=True, capture_output=True)
            return {'success': True}
        except subprocess.CalledProcessError as e:
            return {'success': False, 'error': e.stderr.decode()}
    
    def _restore_to_database(self, backup_path: Path, db_name: str) -> Dict:
        """Restore backup to database"""
        try:
            cmd = f"pg_restore -d {db_name} {backup_path}"
            subprocess.run(cmd, shell=True, check=True, capture_output=True)
            return {'success': True}
        except subprocess.CalledProcessError as e:
            # pg_restore may return non-zero even on success
            # Check if database has tables
            return {'success': True, 'warning': 'Some warnings during restore'}
    
    def _verify_tables_exist(self, db_name: str) -> Dict:
        """Verify that tables exist in database"""
        try:
            cmd = f"psql -d {db_name} -c '\\dt' -t"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            tables = [line.strip() for line in result.stdout.split('\n') if line.strip()]
            
            return {
                'success': len(tables) > 0,
                'table_count': len(tables),
                'tables': tables[:10]  # First 10 tables
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _verify_data_integrity(self, db_name: str) -> Dict:
        """Verify data integrity in database"""
        try:
            # Count rows in main tables
            cmd = f"psql -d {db_name} -c 'SELECT COUNT(*) FROM users;' -t"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            user_count = int(result.stdout.strip()) if result.stdout.strip().isdigit() else 0
            
            return {
                'success': True,
                'user_count': user_count,
                'has_data': user_count > 0
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _drop_test_database(self, db_name: str) -> Dict:
        """Drop temporary test database"""
        try:
            cmd = f"dropdb {db_name}"
            subprocess.run(cmd, shell=True, check=True, capture_output=True)
            return {'success': True}
        except subprocess.CalledProcessError as e:
            return {'success': False, 'error': e.stderr.decode()}
    
    def verify_all_backups(self, run_restore_test: bool = False) -> List[Dict]:
        """
        Verify all backups in backup directory
        
        Args:
            run_restore_test: Whether to run restore test (slow)
            
        Returns:
            List of verification results
        """
        results = []
        
        # Find all backup files
        backup_files = list(self.backup_dir.glob("*.dump")) + \
                      list(self.backup_dir.glob("*.sql"))
        
        print(f"🔍 Found {len(backup_files)} backup files")
        
        for backup_file in backup_files:
            print(f"\n📋 Verifying: {backup_file.name}")
            
            # Integrity check
            integrity_result = self.verify_backup_integrity(backup_file)
            results.append(integrity_result)
            
            if integrity_result['status'] == 'passed':
                print(f"   ✅ Integrity check passed")
                
                # Restore test (optional, slow)
                if run_restore_test:
                    print(f"   🔄 Running restore test...")
                    restore_result = self.test_restore(backup_file)
                    results.append(restore_result)
                    
                    if restore_result['status'] == 'passed':
                        print(f"   ✅ Restore test passed")
                    else:
                        print(f"   ❌ Restore test failed")
            else:
                print(f"   ❌ Integrity check failed")
        
        return results
    
    def get_verification_report(self) -> Dict:
        """
        Generate comprehensive verification report
        
        Returns:
            Report dictionary
        """
        recent_verifications = self.verification_log[-20:]  # Last 20
        
        passed_count = sum(1 for v in recent_verifications if v.get('status') == 'passed')
        failed_count = sum(1 for v in recent_verifications if v.get('status') == 'failed')
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_verifications': len(self.verification_log),
            'recent_verifications': len(recent_verifications),
            'passed_count': passed_count,
            'failed_count': failed_count,
            'success_rate': round(passed_count / len(recent_verifications) * 100, 2) if recent_verifications else 0,
            'recent_results': recent_verifications
        }
        
        return report


# Example usage
if __name__ == "__main__":
    print("🔐 Backup Verification Service")
    print("=" * 50)
    
    # Create service
    service = BackupVerificationService(backup_dir="/backups")
    
    # Verify all backups
    print("\n🔍 Verifying all backups...")
    results = service.verify_all_backups(run_restore_test=False)
    
    # Generate report
    print("\n📊 Verification Report:")
    report = service.get_verification_report()
    print(f"   Total Verifications: {report['total_verifications']}")
    print(f"   Success Rate: {report['success_rate']}%")
    print(f"   Passed: {report['passed_count']}")
    print(f"   Failed: {report['failed_count']}")
    
    print("\n✅ Backup Verification Service initialized successfully!")

