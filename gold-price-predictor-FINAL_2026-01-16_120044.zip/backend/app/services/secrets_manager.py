# File:
# /home/ubuntu/gold-price-predictor/backend/app/services/secrets_manager.py
"""
Secrets Management Service
Provides unified interface for managing secrets across multiple backends
Supports: Environment Variables, HashiCorp Vault, AWS Secrets Manager
"""

import os
import logging
from typing import Optional, Dict, Any
from abc import ABC, abstractmethod
import json

logger = logging.getLogger(__name__)


class SecretsBackend(ABC):
    """Abstract base class for secrets backends"""

    @abstractmethod
    def get_secret(self, key: str) -> Optional[str]:
        """Get a secret value by key"""
        pass

    @abstractmethod
    def set_secret(self, key: str, value: str) -> bool:
        """Set a secret value"""
        pass

    @abstractmethod
    def delete_secret(self, key: str) -> bool:
        """Delete a secret"""
        pass

    @abstractmethod
    def list_secrets(self) -> list:
        """List all available secret keys"""
        pass


class EnvironmentBackend(SecretsBackend):
    """Environment variables backend"""

    def get_secret(self, key: str) -> Optional[str]:
        """Get secret from environment variable"""
        return os.getenv(key)

    def set_secret(self, key: str, value: str) -> bool:
        """Set environment variable (runtime only)"""
        os.environ[key] = value
        return True

    def delete_secret(self, key: str) -> bool:
        """Delete environment variable"""
        if key in os.environ:
            del os.environ[key]
            return True
        return False

    def list_secrets(self) -> list:
        """List all environment variables"""
        return list(os.environ.keys())


class VaultBackend(SecretsBackend):
    """HashiCorp Vault backend"""

    def __init__(
        self,
        vault_addr: str = None,
        vault_token: str = None,
        vault_namespace: str = None,
        mount_point: str = "secret"
    ):
        """
        Initialize Vault backend

        Args:
            vault_addr: Vault server address
            vault_token: Vault authentication token
            vault_namespace: Vault namespace (for Vault Enterprise)
            mount_point: KV secrets engine mount point
        """
        self.vault_addr = vault_addr or os.getenv(
            'VAULT_ADDR', 'http://localhost:8200')
        self.vault_token = vault_token or os.getenv('VAULT_TOKEN')
        self.vault_namespace = vault_namespace or os.getenv('VAULT_NAMESPACE')
        self.mount_point = mount_point

        try:
            import hvac
            self.client = hvac.Client(
                url=self.vault_addr,
                token=self.vault_token,
                namespace=self.vault_namespace
            )

            if not self.client.is_authenticated():
                logger.error("Vault authentication failed")
                self.client = None
            else:
                logger.info(f"Vault backend initialized: {self.vault_addr}")
        except ImportError:
            logger.warning(
                "hvac library not installed. Vault backend unavailable.")
            self.client = None
        except Exception as e:
            logger.error(f"Failed to initialize Vault: {str(e)}")
            self.client = None

    def get_secret(self, key: str) -> Optional[str]:
        """Get secret from Vault"""
        if not self.client:
            return None

        try:
            # Split key into path and field
            if '/' in key:
                path, field = key.rsplit('/', 1)
            else:
                path, field = 'app', key

            # Read secret from Vault
            response = self.client.secrets.kv.v2.read_secret_version(
                path=path,
                mount_point=self.mount_point
            )

            return response['data']['data'].get(field)
        except Exception as e:
            logger.error(f"Failed to get secret from Vault: {str(e)}")
            return None

    def set_secret(self, key: str, value: str) -> bool:
        """Set secret in Vault"""
        if not self.client:
            return False

        try:
            # Split key into path and field
            if '/' in key:
                path, field = key.rsplit('/', 1)
            else:
                path, field = 'app', key

            # Write secret to Vault
            self.client.secrets.kv.v2.create_or_update_secret(
                path=path,
                secret={field: value},
                mount_point=self.mount_point
            )

            logger.info(f"Secret set in Vault: {key}")
            return True
        except Exception as e:
            logger.error(f"Failed to set secret in Vault: {str(e)}")
            return False

    def delete_secret(self, key: str) -> bool:
        """Delete secret from Vault"""
        if not self.client:
            return False

        try:
            # Split key into path and field
            if '/' in key:
                path, _ = key.rsplit('/', 1)
            else:
                path = 'app'

            # Delete secret from Vault
            self.client.secrets.kv.v2.delete_metadata_and_all_versions(
                path=path,
                mount_point=self.mount_point
            )

            logger.info(f"Secret deleted from Vault: {key}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete secret from Vault: {str(e)}")
            return False

    def list_secrets(self) -> list:
        """List all secrets in Vault"""
        if not self.client:
            return []

        try:
            response = self.client.secrets.kv.v2.list_secrets(
                path='',
                mount_point=self.mount_point
            )
            return response['data']['keys']
        except Exception as e:
            logger.error(f"Failed to list secrets from Vault: {str(e)}")
            return []


class AWSSecretsBackend(SecretsBackend):
    """AWS Secrets Manager backend"""

    def __init__(self, region_name: str = None):
        """
        Initialize AWS Secrets Manager backend

        Args:
            region_name: AWS region name
        """
        self.region_name = region_name or os.getenv('AWS_REGION', 'us-east-1')

        try:
            import boto3
            self.client = boto3.client(
                'secretsmanager', region_name=self.region_name)
            logger.info(
                f"AWS Secrets Manager backend initialized: {self.region_name}")
        except ImportError:
            logger.warning(
                "boto3 library not installed. AWS backend unavailable.")
            self.client = None
        except Exception as e:
            logger.error(f"Failed to initialize AWS Secrets Manager: {str(e)}")
            self.client = None

    def get_secret(self, key: str) -> Optional[str]:
        """Get secret from AWS Secrets Manager"""
        if not self.client:
            return None

        try:
            response = self.client.get_secret_value(SecretId=key)

            # Handle both string and JSON secrets
            if 'SecretString' in response:
                secret = response['SecretString']
                try:
                    # Try to parse as JSON
                    secret_dict = json.loads(secret)
                    # If it's a dict with single key, return the value
                    if len(secret_dict) == 1:
                        return list(secret_dict.values())[0]
                    return secret
                except json.JSONDecodeError:
                    return secret
            else:
                # Binary secret
                return response['SecretBinary'].decode('utf-8')
        except Exception as e:
            logger.error(f"Failed to get secret from AWS: {str(e)}")
            return None

    def set_secret(self, key: str, value: str) -> bool:
        """Set secret in AWS Secrets Manager"""
        if not self.client:
            return False

        try:
            # Try to update existing secret first
            try:
                self.client.update_secret(
                    SecretId=key,
                    SecretString=value
                )
            except self.client.exceptions.ResourceNotFoundException:
                # Create new secret if it doesn't exist
                self.client.create_secret(
                    Name=key,
                    SecretString=value
                )

            logger.info(f"Secret set in AWS Secrets Manager: {key}")
            return True
        except Exception as e:
            logger.error(f"Failed to set secret in AWS: {str(e)}")
            return False

    def delete_secret(self, key: str) -> bool:
        """Delete secret from AWS Secrets Manager"""
        if not self.client:
            return False

        try:
            self.client.delete_secret(
                SecretId=key,
                ForceDeleteWithoutRecovery=True
            )
            logger.info(f"Secret deleted from AWS Secrets Manager: {key}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete secret from AWS: {str(e)}")
            return False

    def list_secrets(self) -> list:
        """List all secrets in AWS Secrets Manager"""
        if not self.client:
            return []

        try:
            response = self.client.list_secrets()
            return [secret['Name'] for secret in response['SecretList']]
        except Exception as e:
            logger.error(f"Failed to list secrets from AWS: {str(e)}")
            return []


class SecretsManager:
    """
    Unified Secrets Manager

    Provides a single interface for managing secrets across multiple backends
    with automatic fallback and caching
    """

    def __init__(
        self,
        backend: str = 'env',
        cache_enabled: bool = True,
        **backend_kwargs
    ):
        """
        Initialize Secrets Manager

        Args:
            backend: Backend type ('env', 'vault', 'aws')
            cache_enabled: Enable in-memory caching
            **backend_kwargs: Backend-specific configuration
        """
        self.cache_enabled = cache_enabled
        self.cache: Dict[str, str] = {}

        # Initialize backend
        if backend == 'vault':
            self.backend = VaultBackend(**backend_kwargs)
        elif backend == 'aws':
            self.backend = AWSSecretsBackend(**backend_kwargs)
        else:
            self.backend = EnvironmentBackend()

        # Fallback backend (always environment variables)
        self.fallback_backend = EnvironmentBackend()

        logger.info(f"Secrets Manager initialized with {backend} backend")

    def get(self, key: str, default: Any = None) -> Optional[str]:
        """
        Get secret value

        Args:
            key: Secret key
            default: Default value if secret not found

        Returns:
            Secret value or default
        """
        # Check cache first
        if self.cache_enabled and key in self.cache:
            return self.cache[key]

        # Try primary backend
        value = self.backend.get_secret(key)

        # Fallback to environment variables
        if value is None:
            value = self.fallback_backend.get_secret(key)

        # Use default if still None
        if value is None:
            value = default

        # Cache the value
        if value is not None and self.cache_enabled:
            self.cache[key] = value

        return value

    def set(self, key: str, value: str) -> bool:
        """
        Set secret value

        Args:
            key: Secret key
            value: Secret value

        Returns:
            True if successful
        """
        success = self.backend.set_secret(key, value)

        if success and self.cache_enabled:
            self.cache[key] = value

        return success

    def delete(self, key: str) -> bool:
        """
        Delete secret

        Args:
            key: Secret key

        Returns:
            True if successful
        """
        success = self.backend.delete_secret(key)

        if success and key in self.cache:
            del self.cache[key]

        return success

    def list(self) -> list:
        """
        List all secret keys

        Returns:
            List of secret keys
        """
        return self.backend.list_secrets()

    def clear_cache(self):
        """Clear the in-memory cache"""
        self.cache.clear()
        logger.info("Secrets cache cleared")


# Global secrets manager instance
_secrets_manager: Optional[SecretsManager] = None


def get_secrets_manager() -> SecretsManager:
    """
    Get global secrets manager instance

    Returns:
        SecretsManager instance
    """
    global _secrets_manager

    if _secrets_manager is None:
        # Determine backend from environment
        backend_type = os.getenv('SECRETS_BACKEND', 'env')
        _secrets_manager = SecretsManager(backend=backend_type)

    return _secrets_manager


def get_secret(key: str, default: Any = None) -> Optional[str]:
    """
    Convenience function to get a secret

    Args:
        key: Secret key
        default: Default value

    Returns:
        Secret value
    """
    return get_secrets_manager().get(key, default)
