# FILE: backend/app/services/input_sanitizer.py | PURPOSE: Input sanitization service wrapper | OWNER: Backend Team | RELATED: middleware/input_sanitizer.py | LAST-AUDITED: 2025-11-21

"""
Input Sanitizer Service
Wrapper for input sanitization functionality from middleware
"""

from backend.app.middleware.input_sanitizer import InputSanitizer, InputSanitizerMiddleware

__all__ = ['InputSanitizer', 'InputSanitizerMiddleware']
