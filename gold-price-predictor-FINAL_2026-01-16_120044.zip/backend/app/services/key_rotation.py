# File: /home/ubuntu/gold-price-predictor/backend/app/services/key_rotation.py
"""
Automatic Key Rotation Service
خدمة تدوير المفاتيح التلقائي
"""

import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import json
from pathlib import Path


class KeyRotationService:
    """
    خدمة تدوير المفاتيح التلقائي للأمان
    """
    
    def __init__(
        self,
        rotation_interval_days: int = 90,
        warning_days: int = 7,
        storage_path: str = "keys"
    ):
        """
        Initialize Key Rotation Service
        
        Args:
            rotation_interval_days: عدد الأيام قبل تدوير المفتاح
            warning_days: عدد الأيام للتحذير قبل انتهاء الصلاحية
            storage_path: مسار تخزين معلومات المفاتيح
        """
        self.rotation_interval = timedelta(days=rotation_interval_days)
        self.warning_threshold = timedelta(days=warning_days)
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.keys_metadata_file = self.storage_path / "keys_metadata.json"
        self.keys_metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict:
        """Load keys metadata from file"""
        if self.keys_metadata_file.exists():
            with open(self.keys_metadata_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_metadata(self):
        """Save keys metadata to file"""
        with open(self.keys_metadata_file, 'w') as f:
            json.dump(self.keys_metadata, f, indent=2, default=str)
    
    def generate_key(
        self,
        key_name: str,
        key_type: str = "api_key",
        length: int = 32
    ) -> Tuple[str, str]:
        """
        Generate a new cryptographically secure key
        
        Args:
            key_name: اسم المفتاح
            key_type: نوع المفتاح (api_key, secret_key, encryption_key)
            length: طول المفتاح بالبايتات
            
        Returns:
            (key, key_id) tuple
        """
        # Generate secure random key
        key = secrets.token_urlsafe(length)
        
        # Generate key ID (hash of key + timestamp)
        key_id = hashlib.sha256(
            f"{key}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]
        
        # Store metadata
        self.keys_metadata[key_name] = {
            'key_id': key_id,
            'key_type': key_type,
            'created_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + self.rotation_interval).isoformat(),
            'status': 'active',
            'rotation_count': self.keys_metadata.get(key_name, {}).get('rotation_count', 0) + 1
        }
        
        self._save_metadata()
        
        print(f"✅ تم إنشاء مفتاح جديد: {key_name} (ID: {key_id})")
        
        return key, key_id
    
    def rotate_key(self, key_name: str) -> Tuple[str, str]:
        """
        Rotate an existing key
        
        Args:
            key_name: اسم المفتاح المراد تدويره
            
        Returns:
            (new_key, new_key_id) tuple
        """
        if key_name not in self.keys_metadata:
            raise ValueError(f"Key not found: {key_name}")
        
        # Mark old key as rotated
        old_metadata = self.keys_metadata[key_name]
        old_metadata['status'] = 'rotated'
        old_metadata['rotated_at'] = datetime.now().isoformat()
        
        # Generate new key
        new_key, new_key_id = self.generate_key(
            key_name,
            key_type=old_metadata['key_type']
        )
        
        print(f"🔄 تم تدوير المفتاح: {key_name}")
        
        return new_key, new_key_id
    
    def check_expiration(self, key_name: str) -> Dict:
        """
        Check if key needs rotation
        
        Args:
            key_name: اسم المفتاح
            
        Returns:
            Dictionary with expiration status
        """
        if key_name not in self.keys_metadata:
            return {'error': 'Key not found'}
        
        metadata = self.keys_metadata[key_name]
        expires_at = datetime.fromisoformat(metadata['expires_at'])
        now = datetime.now()
        
        time_until_expiry = expires_at - now
        
        status = {
            'key_name': key_name,
            'expires_at': metadata['expires_at'],
            'days_until_expiry': time_until_expiry.days,
            'needs_rotation': time_until_expiry <= timedelta(0),
            'needs_warning': time_until_expiry <= self.warning_threshold,
            'status': metadata['status']
        }
        
        return status
    
    def check_all_keys(self) -> List[Dict]:
        """
        Check expiration status for all keys
        
        Returns:
            List of expiration statuses
        """
        results = []
        
        for key_name in self.keys_metadata.keys():
            status = self.check_expiration(key_name)
            results.append(status)
        
        return results
    
    def auto_rotate_expired_keys(self) -> List[Tuple[str, str, str]]:
        """
        Automatically rotate all expired keys
        
        Returns:
            List of (key_name, new_key, new_key_id) tuples
        """
        rotated_keys = []
        
        for key_name in list(self.keys_metadata.keys()):
            status = self.check_expiration(key_name)
            
            if status.get('needs_rotation') and status.get('status') == 'active':
                try:
                    new_key, new_key_id = self.rotate_key(key_name)
                    rotated_keys.append((key_name, new_key, new_key_id))
                    print(f"🔄 تم تدوير المفتاح المنتهي: {key_name}")
                except Exception as e:
                    print(f"❌ خطأ في تدوير {key_name}: {e}")
        
        return rotated_keys
    
    def get_rotation_schedule(self) -> List[Dict]:
        """
        Get rotation schedule for all keys
        
        Returns:
            List of keys with rotation dates
        """
        schedule = []
        
        for key_name, metadata in self.keys_metadata.items():
            if metadata['status'] == 'active':
                expires_at = datetime.fromisoformat(metadata['expires_at'])
                schedule.append({
                    'key_name': key_name,
                    'key_type': metadata['key_type'],
                    'expires_at': metadata['expires_at'],
                    'days_remaining': (expires_at - datetime.now()).days,
                    'rotation_count': metadata['rotation_count']
                })
        
        # Sort by expiration date (soonest first)
        schedule.sort(key=lambda x: x['expires_at'])
        
        return schedule
    
    def revoke_key(self, key_name: str):
        """
        Revoke a key immediately
        
        Args:
            key_name: اسم المفتاح
        """
        if key_name not in self.keys_metadata:
            raise ValueError(f"Key not found: {key_name}")
        
        self.keys_metadata[key_name]['status'] = 'revoked'
        self.keys_metadata[key_name]['revoked_at'] = datetime.now().isoformat()
        
        self._save_metadata()
        
        print(f"🚫 تم إلغاء المفتاح: {key_name}")
    
    def get_key_history(self, key_name: str) -> Dict:
        """
        Get history for a specific key
        
        Args:
            key_name: اسم المفتاح
            
        Returns:
            Key history dictionary
        """
        if key_name not in self.keys_metadata:
            return {'error': 'Key not found'}
        
        return self.keys_metadata[key_name]
    
    def generate_rotation_report(self) -> Dict:
        """
        Generate comprehensive rotation report
        
        Returns:
            Report dictionary
        """
        all_statuses = self.check_all_keys()
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_keys': len(self.keys_metadata),
            'active_keys': sum(1 for k in self.keys_metadata.values() if k['status'] == 'active'),
            'rotated_keys': sum(1 for k in self.keys_metadata.values() if k['status'] == 'rotated'),
            'revoked_keys': sum(1 for k in self.keys_metadata.values() if k['status'] == 'revoked'),
            'keys_needing_rotation': sum(1 for s in all_statuses if s.get('needs_rotation')),
            'keys_needing_warning': sum(1 for s in all_statuses if s.get('needs_warning')),
            'rotation_schedule': self.get_rotation_schedule(),
            'keys_status': all_statuses
        }
        
        return report


# Example usage and testing
if __name__ == "__main__":
    print("🔐 Key Rotation Service")
    print("=" * 50)
    
    # Create service
    service = KeyRotationService(
        rotation_interval_days=90,
        warning_days=7
    )
    
    # Generate some test keys
    print("\n📝 Generating test keys...")
    service.generate_key("jwt_secret", "secret_key")
    service.generate_key("api_master_key", "api_key")
    service.generate_key("encryption_key", "encryption_key")
    
    # Check expiration
    print("\n🔍 Checking key expiration...")
    schedule = service.get_rotation_schedule()
    for item in schedule:
        print(f"   {item['key_name']}: {item['days_remaining']} days remaining")
    
    # Generate report
    print("\n📊 Rotation Report:")
    report = service.generate_rotation_report()
    print(f"   Total Keys: {report['total_keys']}")
    print(f"   Active Keys: {report['active_keys']}")
    print(f"   Keys Needing Rotation: {report['keys_needing_rotation']}")
    print(f"   Keys Needing Warning: {report['keys_needing_warning']}")
    
    print("\n✅ Key Rotation Service initialized successfully!")

