# FILE: backend/app/services/structured_logging.py | PURPOSE: Structured logging service | OWNER: Backend Team | RELATED: audit_logger.py | LAST-AUDITED: 2025-11-21

"""
Structured Logging Service
Provides structured logging functionality
"""

import logging
import json
from datetime import datetime


class StructuredLogger:
    """Structured logging with JSON output"""

    def __init__(self, name: str = "app"):
        self.logger = logging.getLogger(name)

    def log(self, level: str, message: str, **kwargs):
        """Log structured message"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level.upper(),
            "message": message,
            **kwargs
        }

        log_func = getattr(self.logger, level.lower(), self.logger.info)
        log_func(json.dumps(log_entry))


__all__ = ['StructuredLogger']
