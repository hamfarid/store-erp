# FILE: backend/app/services/account_lockout.py | PURPOSE: Account lockout service | OWNER: Security Team | RELATED: auth_postgresql.py, main.py | LAST-AUDITED: 2025-01-18
"""
Account Lockout Service
Tracks failed login attempts and locks accounts after threshold is exceeded
"""

import redis
from typing import Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Configuration
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 30
FAILED_ATTEMPTS_TTL_MINUTES = 15  # Reset counter after 15 minutes of no attempts


class AccountLockoutService:
    """
    Service for managing account lockouts based on failed login attempts

    Uses Redis to track failed attempts and lockout status
    """

    def __init__(self, redis_url: Optional[str] = None):
        """
        Initialize account lockout service

        Args:
            redis_url: Redis connection URL (optional, uses in-memory if None)
        """
        self.redis_enabled = redis_url is not None

        if self.redis_enabled:
            try:
                self.redis_client = redis.from_url(redis_url, decode_responses=True)
                self.redis_client.ping()
                logger.info("Account lockout service initialized with Redis")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {e}")
                self.redis_enabled = False
                self._in_memory_store = {}
        else:
            self._in_memory_store = {}
            logger.warning("Account lockout service running in-memory mode (not production-ready)")

    def _get_failed_attempts_key(self, username: str) -> str:
        """Get Redis key for failed attempts counter"""
        return f"failed_attempts:{username}"

    def _get_lockout_key(self, username: str) -> str:
        """Get Redis key for lockout status"""
        return f"account_locked:{username}"

    def record_failed_attempt(self, username: str) -> int:
        """
        Record a failed login attempt

        Args:
            username: Username that failed to login

        Returns:
            int: Current number of failed attempts
        """
        key = self._get_failed_attempts_key(username)

        if self.redis_enabled:
            # Increment counter
            attempts = self.redis_client.incr(key)

            # Set TTL on first attempt
            if attempts == 1:
                self.redis_client.expire(key, FAILED_ATTEMPTS_TTL_MINUTES * 60)

            logger.info(f"Failed login attempt for {username}: {attempts}/{MAX_FAILED_ATTEMPTS}")

            # Lock account if threshold exceeded
            if attempts >= MAX_FAILED_ATTEMPTS:
                self.lock_account(username)

            return attempts
        else:
            # In-memory fallback
            if username not in self._in_memory_store:
                self._in_memory_store[username] = {"attempts": 0, "locked_until": None}

            self._in_memory_store[username]["attempts"] += 1
            attempts = self._in_memory_store[username]["attempts"]

            if attempts >= MAX_FAILED_ATTEMPTS:
                self.lock_account(username)

            return attempts

    def reset_failed_attempts(self, username: str):
        """
        Reset failed login attempts counter

        Args:
            username: Username to reset
        """
        key = self._get_failed_attempts_key(username)

        if self.redis_enabled:
            self.redis_client.delete(key)
            logger.info(f"Reset failed attempts for {username}")
        else:
            if username in self._in_memory_store:
                self._in_memory_store[username]["attempts"] = 0

    def lock_account(self, username: str):
        """
        Lock an account for LOCKOUT_DURATION_MINUTES

        Args:
            username: Username to lock
        """
        key = self._get_lockout_key(username)

        if self.redis_enabled:
            # Set lockout with TTL
            self.redis_client.setex(
                key,
                LOCKOUT_DURATION_MINUTES * 60,
                datetime.utcnow().isoformat()
            )
            logger.warning(f"Account locked: {username} for {LOCKOUT_DURATION_MINUTES} minutes")
        else:
            if username not in self._in_memory_store:
                self._in_memory_store[username] = {"attempts": 0, "locked_until": None}

            self._in_memory_store[username]["locked_until"] = (
                datetime.utcnow() + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
            )
            logger.warning(f"Account locked (in-memory): {username}")

    def is_account_locked(self, username: str) -> bool:
        """
        Check if an account is currently locked

        Args:
            username: Username to check

        Returns:
            bool: True if account is locked, False otherwise
        """
        key = self._get_lockout_key(username)

        if self.redis_enabled:
            locked = self.redis_client.exists(key) > 0
            if locked:
                logger.info(f"Account is locked: {username}")
            return locked
        else:
            if username in self._in_memory_store:
                locked_until = self._in_memory_store[username].get("locked_until")
                if locked_until and datetime.utcnow() < locked_until:
                    return True
                elif locked_until:
                    # Lockout expired, reset
                    self._in_memory_store[username]["locked_until"] = None
                    self._in_memory_store[username]["attempts"] = 0
            return False

    def unlock_account(self, username: str):
        """
        Manually unlock an account (admin action)

        Args:
            username: Username to unlock
        """
        lockout_key = self._get_lockout_key(username)
        attempts_key = self._get_failed_attempts_key(username)

        if self.redis_enabled:
            self.redis_client.delete(lockout_key)
            self.redis_client.delete(attempts_key)
            logger.info(f"Account manually unlocked: {username}")
        else:
            if username in self._in_memory_store:
                self._in_memory_store[username]["locked_until"] = None
                self._in_memory_store[username]["attempts"] = 0

    def get_failed_attempts(self, username: str) -> int:
        """
        Get current number of failed attempts

        Args:
            username: Username to check

        Returns:
            int: Number of failed attempts
        """
        key = self._get_failed_attempts_key(username)

        if self.redis_enabled:
            attempts = self.redis_client.get(key)
            return int(attempts) if attempts else 0
        else:
            if username in self._in_memory_store:
                return self._in_memory_store[username]["attempts"]
            return 0


# Global instance
account_lockout_service = None


def get_account_lockout_service(redis_url: Optional[str] = None) -> AccountLockoutService:
    """
    Get or create account lockout service instance

    Args:
        redis_url: Redis connection URL

    Returns:
        AccountLockoutService instance
    """
    global account_lockout_service

    if account_lockout_service is None:
        account_lockout_service = AccountLockoutService(redis_url)

    return account_lockout_service
