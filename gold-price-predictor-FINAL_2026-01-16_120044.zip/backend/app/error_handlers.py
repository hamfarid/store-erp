# FILE: backend/app/error_handlers.py | PURPOSE: Custom error pages and handlers | OWNER: Backend Team | RELATED: main.py | LAST-AUDITED: 2025-11-21

"""
Error Handlers and Custom Error Pages
Provides custom 404, 500, and other HTTP error responses
"""

import traceback
from datetime import datetime

from fastapi import Request, status
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.audit_logger import audit_logger, AuditEventType


# HTML Templates for error pages
ERROR_404_HTML = '''
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Not Found</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            max-width: 600px;
        }
        .error-code {
            font-size: 8rem;
            font-weight: bold;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .error-message {
            font-size: 1.5rem;
            margin-bottom: 2rem;
        }
        .error-details {
            font-size: 1rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        .back-button {
            display: inline-block;
            padding: 1rem 2rem;
            background: white;
            color: #667eea;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            transition: transform 0.3s ease;
        }
        .back-button:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-code">404</div>
        <div class="error-message">الصفحة غير موجودة</div>
        <div class="error-details">
            عذراً، الصفحة التي تبحث عنها غير موجودة.<br>
            قد يكون الرابط خاطئاً أو تم نقل الصفحة.
        </div>
        <a href="/" class="back-button">Go Back Home</a>
    </div>
</body>
</html>
'''

ERROR_500_HTML = '''
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Server Error</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            max-width: 600px;
        }
        .error-code {
            font-size: 8rem;
            font-weight: bold;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .error-message {
            font-size: 1.5rem;
            margin-bottom: 2rem;
        }
        .error-details {
            font-size: 1rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        .back-button {
            display: inline-block;
            padding: 1rem 2rem;
            background: white;
            color: #f5576c;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            transition: transform 0.3s ease;
            margin: 0.5rem;
        }
        .back-button:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-code">500</div>
        <div class="error-message">خطأ في الخادم</div>
        <div class="error-details">
            عذراً، حدث خطأ غير متوقع في الخادم.<br>
            فريقنا على علم بالمشكلة ويعمل على حلها.
        </div>
        <a href="/" class="back-button">Go Back Home</a>
        <a href="/api/health" class="back-button">Check Server Status</a>
    </div>
</body>
</html>
'''


async def not_found_error(request: Request, exc: StarletteHTTPException):
    """
    Custom 404 error handler
    Returns HTML for browser requests, JSON for API requests
    """
    # Log the 404
    audit_logger.log_event(
        AuditEventType.UNAUTHORIZED_ACCESS,
        details={
            "error": "404",
            "path": str(request.url.path),
            "method": request.method
        },
        success=False
    )

    # Check if request expects JSON (API request)
    accept_header = request.headers.get("accept", "")
    if "application/json" in accept_header or request.url.path.startswith("/api"):
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={
                "success": False,
                "code": "NOT_FOUND",
                "message": "المورد المطلوب غير موجود",
                "details": {
                    "path": str(request.url.path),
                    "method": request.method
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        )

    # Return HTML for browser requests
    return HTMLResponse(content=ERROR_404_HTML, status_code=404)


async def internal_server_error(request: Request, exc: Exception):
    """
    Custom 500 error handler
    Logs the error and returns appropriate response
    """
    # Log the error with full traceback
    error_details = {
        "error": "500",
        "path": str(request.url.path),
        "method": request.method,
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "traceback": traceback.format_exc()
    }

    audit_logger.log_event(
        AuditEventType.UNAUTHORIZED_ACCESS,  # Use available event type
        details=error_details,
        success=False
    )

    # Check if request expects JSON
    accept_header = request.headers.get("accept", "")
    if "application/json" in accept_header or request.url.path.startswith("/api"):
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "success": False,
                "code": "INTERNAL_SERVER_ERROR",
                "message": "حدث خطأ غير متوقع في الخادم",
                "details": {
                    "error_type": type(exc).__name__,
                    "timestamp": datetime.utcnow().isoformat()
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        )

    # Return HTML for browser requests
    return HTMLResponse(content=ERROR_500_HTML, status_code=500)


async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Handle Pydantic validation errors
    Returns detailed validation error information
    """
    # Sanitize errors to ensure JSON serialization (e.g. remove raw Exception objects in ctx)
    errors = exc.errors()
    for error in errors:
        if "ctx" in error:
            # Convert raw exception to string if present
            if "error" in error["ctx"]:
                error["ctx"]["error"] = str(error["ctx"]["error"])

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "code": "VALIDATION_ERROR",
            "message": "خطأ في التحقق من البيانات",
            "details": {
                "errors": errors,
                "body": str(exc.body)  # Convert body to string to handle FormData and other non-JSON types safe
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    )


def register_error_handlers(app):
    """
    Register all custom error handlers with the FastAPI app

    Usage in main.py:
        from app.error_handlers import register_error_handlers
        register_error_handlers(app)
    """
    app.add_exception_handler(StarletteHTTPException, not_found_error)
    app.add_exception_handler(Exception, internal_server_error)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)

    return app
