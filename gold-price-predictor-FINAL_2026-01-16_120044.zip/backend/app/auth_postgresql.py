# File: /home/ubuntu/gold-price-predictor/backend/app/auth_postgresql.py
"""
نظام المصادقة المحسّن مع PostgreSQL و JWT Blacklist
Enhanced Authentication System with PostgreSQL and JWT Blacklist
"""
from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from database import User, get_db
from config_secure import settings
import sys
import os

# Add services to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from services.jwt_blacklist import jwt_blacklist
    JWT_BLACKLIST_ENABLED = True
except ImportError:
    JWT_BLACKLIST_ENABLED = False
    print("Warning: JWT Blacklist not available")


# Argon2 Password Hasher
ph = PasswordHasher()


def hash_password(password: str) -> str:
    """
    تشفير كلمة المرور باستخدام Argon2
    Hash password using Argon2

    Args:
        password: Plain text password

    Returns:
        Hashed password string
    """
    return ph.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    التحقق من كلمة المرور
    Verify password against hash

    Args:
        plain_password: Plain text password
        hashed_password: Hashed password from database

    Returns:
        True if password matches, False otherwise
    """
    try:
        ph.verify(hashed_password, plain_password)
        return True
    except VerifyMismatchError:
        return False


def create_access_token(
        data: dict,
        expires_delta: Optional[timedelta] = None) -> str:
    """
    إنشاء Access Token
    Create JWT access token

    Args:
        data: Data to encode in token
        expires_delta: Optional custom expiration time

    Returns:
        Encoded JWT token
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({
        "exp": expire,
        "type": "access",
        "iat": datetime.utcnow()
    })
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict) -> str:
    """
    إنشاء Refresh Token
    Create JWT refresh token

    Args:
        data: Data to encode in token

    Returns:
        Encoded JWT refresh token
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({
        "exp": expire,
        "type": "refresh",
        "iat": datetime.utcnow()
    })
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM)
    return encoded_jwt


def authenticate_user(
        db: Session,
        username: str,
        password: str) -> Optional[User]:
    """
    مصادقة المستخدم
    Authenticate user with username and password

    Args:
        db: Database session
        username: Username
        password: Plain text password

    Returns:
        User object if authenticated, None otherwise
    """
    user = db.query(User).filter(User.username == username).first()
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


def get_current_user(token: str, db: Session) -> Optional[User]:
    """
    الحصول على المستخدم الحالي من Token مع فحص القائمة السوداء
    Get current user from JWT token with blacklist check

    Args:
        token: JWT access token
        db: Database session

    Returns:
        User object if valid, None otherwise

    Raises:
        HTTPException: If token is blacklisted or invalid
    """
    # Check if token is blacklisted
    if JWT_BLACKLIST_ENABLED and jwt_blacklist.is_blacklisted(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[
                settings.ALGORITHM])
        username: str = payload.get("sub")
        user_id: int = payload.get("user_id")

        if username is None:
            return None

        # Check if user is blacklisted (all tokens revoked)
        if JWT_BLACKLIST_ENABLED and user_id and jwt_blacklist.is_user_blacklisted(
                user_id):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User access has been revoked",
                headers={"WWW-Authenticate": "Bearer"},
            )

        user = db.query(User).filter(User.username == username).first()
        return user
    except JWTError:
        return None


def revoke_token(token: str, expires_in: int = 3600) -> bool:
    """
    إبطال توكن محدد
    Revoke a specific token

    Args:
        token: JWT token to revoke
        expires_in: Expiration time in seconds

    Returns:
        True if successfully revoked, False otherwise
    """
    if not JWT_BLACKLIST_ENABLED:
        return False
    return jwt_blacklist.blacklist_token(token, expires_in)


def revoke_user_tokens(user_id: int, expires_in: int = 3600) -> bool:
    """
    إبطال جميع توكنات المستخدم
    Revoke all tokens for a user (useful for password change, account suspension)

    Args:
        user_id: User ID
        expires_in: Expiration time in seconds

    Returns:
        True if successfully revoked, False otherwise
    """
    if not JWT_BLACKLIST_ENABLED:
        return False
    return jwt_blacklist.blacklist_user_tokens(user_id, expires_in)


def clear_user_revocation(user_id: int) -> bool:
    """
    إزالة المستخدم من القائمة السوداء
    Clear user revocation (allow new logins)

    Args:
        user_id: User ID

    Returns:
        True if successful, False otherwise
    """
    if not JWT_BLACKLIST_ENABLED:
        return False
    return jwt_blacklist.clear_user_blacklist(user_id)
