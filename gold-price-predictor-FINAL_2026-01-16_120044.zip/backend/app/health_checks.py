"""
Comprehensive Health Checks
File: /home/ubuntu/gold-price-predictor/backend/app/health_checks.py

فحوصات صحة شاملة للنظام
"""

from fastapi import APIRouter, Response, status
from typing import Dict, Any, List
import asyncio
import time
import psutil
import redis
from sqlalchemy import create_engine, text
from datetime import datetime
import os


router = APIRouter()


# ============================================================================
# Health Check Components
# ============================================================================

class HealthChecker:
    """فاحص الصحة الشامل"""
    
    def __init__(self):
        self.checks = []
        self.start_time = time.time()
    
    async def check_database(self) -> Dict[str, Any]:
        """فحص قاعدة البيانات"""
        try:
            db_url = os.getenv('DATABASE_URL', 'postgresql://localhost/goldpredictor')
            engine = create_engine(db_url)
            
            start = time.time()
            with engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()
            duration = time.time() - start
            
            return {
                'status': 'healthy',
                'response_time_ms': round(duration * 1000, 2),
                'message': 'Database connection successful'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'Database connection failed'
            }
    
    async def check_redis(self) -> Dict[str, Any]:
        """فحص Redis"""
        try:
            redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
            r = redis.from_url(redis_url)
            
            start = time.time()
            r.ping()
            duration = time.time() - start
            
            info = r.info()
            
            return {
                'status': 'healthy',
                'response_time_ms': round(duration * 1000, 2),
                'connected_clients': info.get('connected_clients', 0),
                'used_memory_human': info.get('used_memory_human', 'N/A'),
                'message': 'Redis connection successful'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'Redis connection failed'
            }
    
    async def check_disk_space(self) -> Dict[str, Any]:
        """فحص مساحة القرص"""
        try:
            disk = psutil.disk_usage('/')
            
            status = 'healthy'
            if disk.percent > 90:
                status = 'critical'
            elif disk.percent > 80:
                status = 'warning'
            
            return {
                'status': status,
                'total_gb': round(disk.total / (1024**3), 2),
                'used_gb': round(disk.used / (1024**3), 2),
                'free_gb': round(disk.free / (1024**3), 2),
                'percent': disk.percent,
                'message': f'Disk usage at {disk.percent}%'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'Disk space check failed'
            }
    
    async def check_memory(self) -> Dict[str, Any]:
        """فحص الذاكرة"""
        try:
            memory = psutil.virtual_memory()
            
            status = 'healthy'
            if memory.percent > 90:
                status = 'critical'
            elif memory.percent > 80:
                status = 'warning'
            
            return {
                'status': status,
                'total_gb': round(memory.total / (1024**3), 2),
                'available_gb': round(memory.available / (1024**3), 2),
                'used_gb': round(memory.used / (1024**3), 2),
                'percent': memory.percent,
                'message': f'Memory usage at {memory.percent}%'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'Memory check failed'
            }
    
    async def check_cpu(self) -> Dict[str, Any]:
        """فحص المعالج"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            status = 'healthy'
            if cpu_percent > 90:
                status = 'critical'
            elif cpu_percent > 80:
                status = 'warning'
            
            return {
                'status': status,
                'usage_percent': cpu_percent,
                'cpu_count': cpu_count,
                'message': f'CPU usage at {cpu_percent}%'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'CPU check failed'
            }
    
    async def check_external_api(self, url: str, name: str) -> Dict[str, Any]:
        """فحص API خارجي"""
        try:
            import httpx
            
            start = time.time()
            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=5.0)
            duration = time.time() - start
            
            status = 'healthy' if response.status_code == 200 else 'unhealthy'
            
            return {
                'status': status,
                'response_time_ms': round(duration * 1000, 2),
                'status_code': response.status_code,
                'message': f'{name} API is {"accessible" if status == "healthy" else "not accessible"}'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': f'{name} API check failed'
            }
    
    async def check_ml_model(self) -> Dict[str, Any]:
        """فحص نموذج التعلم الآلي"""
        try:
            # Check if model files exist
            model_path = '/home/ubuntu/gold-price-predictor/ml/models/'
            
            if not os.path.exists(model_path):
                return {
                    'status': 'warning',
                    'message': 'ML model directory not found'
                }
            
            model_files = os.listdir(model_path)
            
            if not model_files:
                return {
                    'status': 'warning',
                    'message': 'No ML model files found'
                }
            
            return {
                'status': 'healthy',
                'model_count': len(model_files),
                'message': f'Found {len(model_files)} ML model(s)'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'message': 'ML model check failed'
            }
    
    async def run_all_checks(self) -> Dict[str, Any]:
        """تشغيل جميع الفحوصات"""
        checks = await asyncio.gather(
            self.check_database(),
            self.check_redis(),
            self.check_disk_space(),
            self.check_memory(),
            self.check_cpu(),
            self.check_ml_model(),
            return_exceptions=True
        )
        
        results = {
            'database': checks[0],
            'redis': checks[1],
            'disk': checks[2],
            'memory': checks[3],
            'cpu': checks[4],
            'ml_model': checks[5]
        }
        
        # Overall status
        statuses = [v['status'] for v in results.values() if isinstance(v, dict)]
        
        if 'unhealthy' in statuses or 'critical' in statuses:
            overall_status = 'unhealthy'
        elif 'warning' in statuses:
            overall_status = 'degraded'
        else:
            overall_status = 'healthy'
        
        uptime_seconds = time.time() - self.start_time
        
        return {
            'status': overall_status,
            'timestamp': datetime.utcnow().isoformat(),
            'uptime_seconds': round(uptime_seconds, 2),
            'checks': results
        }


# ============================================================================
# Health Check Endpoints
# ============================================================================

@router.get('/health')
async def health_check():
    """Basic health check"""
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat()
    }


@router.get('/health/detailed')
async def detailed_health_check():
    """Detailed health check"""
    checker = HealthChecker()
    results = await checker.run_all_checks()
    
    # Set HTTP status code based on overall status
    status_code = status.HTTP_200_OK
    if results['status'] == 'degraded':
        status_code = status.HTTP_200_OK  # Still OK but with warnings
    elif results['status'] == 'unhealthy':
        status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    
    return Response(
        content=str(results),
        status_code=status_code,
        media_type='application/json'
    )


@router.get('/health/liveness')
async def liveness_check():
    """Kubernetes liveness probe"""
    return {'status': 'alive'}


@router.get('/health/readiness')
async def readiness_check():
    """Kubernetes readiness probe"""
    checker = HealthChecker()
    
    # Check critical components only
    db_check = await checker.check_database()
    redis_check = await checker.check_redis()
    
    if db_check['status'] == 'healthy' and redis_check['status'] == 'healthy':
        return {'status': 'ready'}
    else:
        return Response(
            content='{"status": "not ready"}',
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            media_type='application/json'
        )

