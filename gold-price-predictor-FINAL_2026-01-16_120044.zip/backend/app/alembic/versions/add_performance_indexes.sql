-- Add Performance Indexes
-- Migration: add_performance_indexes
-- Date: 2025-11-02
-- Purpose: Optimize query performance for frequently accessed data

-- Users table indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_users_last_signed_in ON users(last_signed_in DESC);

-- Predictions table indexes (assuming table exists)
CREATE INDEX IF NOT EXISTS idx_predictions_user_id ON predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_predictions_created_at ON predictions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_predictions_status ON predictions(status) WHERE status IN ('pending', 'processing');

-- Models table indexes
CREATE INDEX IF NOT EXISTS idx_models_name ON models(name);
CREATE INDEX IF NOT EXISTS idx_models_version ON models(version);
CREATE INDEX IF NOT EXISTS idx_models_is_active ON models(is_active) WHERE is_active = TRUE;

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_predictions_user_created ON predictions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_predictions_status_created ON predictions(status, created_at DESC);

-- Add comments for documentation
COMMENT ON INDEX idx_users_email IS 'Optimize user lookup by email during login';
COMMENT ON INDEX idx_users_created_at IS 'Optimize user list queries sorted by registration date';
COMMENT ON INDEX idx_predictions_user_id IS 'Optimize prediction queries by user';
COMMENT ON INDEX idx_predictions_created_at IS 'Optimize prediction list queries sorted by date';
COMMENT ON INDEX idx_predictions_user_created IS 'Optimize user prediction history queries';

-- Analyze tables to update statistics
ANALYZE users;
ANALYZE predictions;
ANALYZE models;
