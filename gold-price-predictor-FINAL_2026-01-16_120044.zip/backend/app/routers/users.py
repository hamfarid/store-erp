# FILE: backend/app/routers/users.py | PURPOSE: User CRUD endpoints | OWNER: Backend Team | RELATED: database_enhanced.py, auth_postgresql.py | LAST-AUDITED: 2025-01-18

"""
User CRUD Router
Provides endpoints for user management (create, read, update, delete)
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, EmailStr, field_validator
from datetime import datetime

from app.database_enhanced import User as DBUser, get_db
from app.auth_postgresql import hash_password
from app.audit_logger import audit_logger, AuditEventType
from app.dependencies import get_current_user_dep

router = APIRouter(prefix="/api/users", tags=["users"])


# ==================== Pydantic Models ====================

class UserCreate(BaseModel):
    """User creation request"""
    username: str
    email: EmailStr
    password: str
    is_admin: bool = False

    @field_validator('username')
    @classmethod
    def validate_username(cls, v):
        if len(v) < 3:
            raise ValueError('Username must be at least 3 characters')
        if len(v) > 50:
            raise ValueError('Username must be at most 50 characters')
        if not (v.replace('_', '').isalnum()):
            raise ValueError('Username must contain only alphanumeric characters and underscores')
        return v

    @field_validator('password')
    @classmethod
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class UserUpdate(BaseModel):
    """User update request"""
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None


class UserResponse(BaseModel):
    """User response"""
    id: int
    username: str
    email: str
    is_active: bool
    is_admin: bool
    is_2fa_enabled: bool
    created_at: datetime
    updated_at: datetime
    last_login: Optional[datetime] = None

    model_config = {"from_attributes": True}


# ==================== Endpoints ====================

@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(lambda: get_current_user_dep())
):
    """
    Create a new user (Admin only)

    **Permissions:** ADMIN
    **OSF Security:** Input validation, password hashing, audit logging
    """
    # Check admin permission
    if not current_user.is_admin:
        audit_logger.log_event(
            AuditEventType.UNAUTHORIZED_ACCESS,
            user_id=current_user.id,
            details={"action": "create_user", "reason": "not_admin"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can create users"
        )

    # Check if username already exists
    existing_user = db.query(DBUser).filter(DBUser.username == user_data.username).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already exists"
        )

    # Check if email already exists
    existing_email = db.query(DBUser).filter(DBUser.email == user_data.email).first()
    if existing_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already exists"
        )

    # Create new user
    new_user = DBUser(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        is_admin=user_data.is_admin,
        is_active=True
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Audit log
    audit_logger.log_event(
        AuditEventType.USER_CREATED,
        user_id=current_user.id,
        details={
            "created_user_id": new_user.id,
            "username": new_user.username,
            "is_admin": new_user.is_admin
        }
    )

    return new_user


@router.get("/", response_model=List[UserResponse])
async def list_users(
    skip: int = 0,
    limit: int = 100,
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_user_dep)
):
    """
    List all users (Admin only)

    **Permissions:** ADMIN
    **Pagination:** skip, limit
    **Filters:** is_active
    """
    # Check admin permission
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can list users"
        )

    query = db.query(DBUser)

    if is_active is not None:
        query = query.filter(DBUser.is_active == is_active)

    users = query.offset(skip).limit(limit).all()
    return users


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_user_dep)
):
    """
    Get user by ID

    **Permissions:** ADMIN or own user
    """
    # Check permission (admin or own user)
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only view your own user details"
        )

    user = db.query(DBUser).filter(DBUser.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    return user


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_user_dep)
):
    """
    Update user

    **Permissions:** ADMIN or own user (limited fields)
    **OSF Security:** Audit logging, permission checks
    """
    # Get user
    user = db.query(DBUser).filter(DBUser.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Check permission
    is_admin = current_user.is_admin
    is_own_user = current_user.id == user_id

    if not is_admin and not is_own_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only update your own user details"
        )

    # Non-admin users can only update email
    if not is_admin and (user_update.is_active is not None or user_update.is_admin is not None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can update user status and role"
        )

    # Update fields
    if user_update.email is not None:
        # Check if email already exists
        existing_email = db.query(DBUser).filter(
            DBUser.email == user_update.email,
            DBUser.id != user_id
        ).first()
        if existing_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already exists"
            )
        user.email = user_update.email

    if is_admin:
        if user_update.is_active is not None:
            user.is_active = user_update.is_active
        if user_update.is_admin is not None:
            user.is_admin = user_update.is_admin

    user.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(user)

    # Audit log
    audit_logger.log_event(
        AuditEventType.USER_UPDATED,
        user_id=current_user.id,
        details={
            "updated_user_id": user.id,
            "changes": user_update.model_dump(exclude_unset=True)
        }
    )

    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_user_dep)
):
    """
    Delete user (soft delete - set is_active=False)

    **Permissions:** ADMIN only
    **OSF Security:** Soft delete, audit logging
    """
    # Check admin permission
    if not current_user.is_admin:
        audit_logger.log_event(
            AuditEventType.UNAUTHORIZED_ACCESS,
            user_id=current_user.id,
            details={"action": "delete_user", "reason": "not_admin"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can delete users"
        )

    # Get user
    user = db.query(DBUser).filter(DBUser.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Prevent self-deletion
    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot delete your own account"
        )

    # Soft delete
    user.is_active = False
    user.updated_at = datetime.utcnow()
    db.commit()

    # Audit log
    audit_logger.log_event(
        AuditEventType.USER_DELETED,
        user_id=current_user.id,
        details={
            "deleted_user_id": user.id,
            "username": user.username
        }
    )

    return None
