
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    print("Attempting to import app.main...")
    from app.main import app
    print("Imports successful: app.main imported.")
    
    # Check if StructuredLogger middleware is present
    from app.middleware.structured_logging import CorrelationIDMiddleware
    found = False
    for middleware in app.user_middleware:
        if middleware.cls == CorrelationIDMiddleware:
            found = True
            break
    
    if found:
        print("Verification successful: CorrelationIDMiddleware found in app.")
    else:
        print("Verification failed: CorrelationIDMiddleware NOT found in app.")
        sys.exit(1)

except Exception as e:
    import traceback
    traceback.print_exc()
    sys.exit(1)
