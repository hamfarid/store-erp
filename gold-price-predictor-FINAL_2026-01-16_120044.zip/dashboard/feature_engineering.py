"""
Feature Engineering for Dashboard
توليد الميزات المطلوبة للنماذج
"""

import pandas as pd
import numpy as np

def create_lag_features(df, column, lags=[1, 2, 3, 7]):
    """إنشاء lag features"""
    df_copy = df.copy()
    for lag in lags:
        df_copy[f'{column}_lag{lag}'] = df_copy[column].shift(lag)
    return df_copy

def create_ma_features(df, column, windows=[7, 30]):
    """إنشاء Moving Average features"""
    df_copy = df.copy()
    for window in windows:
        df_copy[f'{column}_MA{window}'] = df_copy[column].rolling(window=window).mean()
    return df_copy

def create_volatility_feature(df, column, window=7):
    """إنشاء Volatility feature"""
    df_copy = df.copy()
    df_copy[f'{column}_Volatility'] = df_copy[column].rolling(window=window).std()
    return df_copy

def create_change_features(df, column):
    """إنشاء Change و PctChange features"""
    df_copy = df.copy()
    df_copy[f'{column}_Change'] = df_copy[column].diff()
    df_copy[f'{column}_PctChange'] = df_copy[column].pct_change()
    return df_copy

def prepare_features_for_gold(df):
    """تحضير الميزات لنموذج الذهب"""
    df_copy = df.copy()
    
    # إنشاء lag features
    df_copy = create_lag_features(df_copy, 'Gold_Price', [1, 2, 3, 7])
    
    # إنشاء MA features (إذا لم تكن موجودة)
    if 'Gold_Price_MA7' not in df_copy.columns:
        df_copy = create_ma_features(df_copy, 'Gold_Price', [7, 30])
    else:
        # استخدام الموجودة وإعادة تسميتها
        df_copy['Gold_Price_MA7'] = df_copy['Gold_MA7']
        df_copy['Gold_Price_MA30'] = df_copy['Gold_MA30']
    
    # إنشاء Volatility
    if 'Gold_Price_Volatility' not in df_copy.columns:
        df_copy = create_volatility_feature(df_copy, 'Gold_Price', 7)
    else:
        df_copy['Gold_Price_Volatility'] = df_copy['Gold_Volatility']
    
    # إنشاء Change features
    if 'Gold_Price_Change' not in df_copy.columns:
        df_copy = create_change_features(df_copy, 'Gold_Price')
    else:
        df_copy['Gold_Price_Change'] = df_copy['Gold_Daily_Change']
        if 'Gold_Price_PctChange' not in df_copy.columns:
            df_copy['Gold_Price_PctChange'] = df_copy['Gold_Price'].pct_change()
    
    # إصلاح أسماء الأعمدة الأخرى
    if 'Silver_Price' not in df_copy.columns:
        if 'Silver_Price_x' in df_copy.columns:
            df_copy['Silver_Price'] = df_copy['Silver_Price_x']
        elif 'Silver_Price_y' in df_copy.columns:
            df_copy['Silver_Price'] = df_copy['Silver_Price_y']
    
    if 'Oil_Price' not in df_copy.columns:
        if 'Oil_Price_x' in df_copy.columns:
            df_copy['Oil_Price'] = df_copy['Oil_Price_x']
        elif 'Oil_Price_y' in df_copy.columns:
            df_copy['Oil_Price'] = df_copy['Oil_Price_y']
    
    return df_copy

def prepare_features_for_btc(df):
    """تحضير الميزات لنموذج Bitcoin"""
    df_copy = df.copy()
    
    # إنشاء lag features
    df_copy = create_lag_features(df_copy, 'BTC_Price', [1, 2, 3, 7])
    
    # إنشاء MA features (إذا لم تكن موجودة)
    if 'BTC_Price_MA7' not in df_copy.columns:
        if 'BTC_MA7' in df_copy.columns:
            df_copy['BTC_Price_MA7'] = df_copy['BTC_MA7']
            df_copy['BTC_Price_MA30'] = df_copy['BTC_MA30']
        else:
            df_copy = create_ma_features(df_copy, 'BTC_Price', [7, 30])
    
    # إنشاء Volatility
    if 'BTC_Price_Volatility' not in df_copy.columns:
        if 'BTC_Volatility' in df_copy.columns:
            df_copy['BTC_Price_Volatility'] = df_copy['BTC_Volatility']
        else:
            df_copy = create_volatility_feature(df_copy, 'BTC_Price', 7)
    
    # إنشاء Change features
    if 'BTC_Price_Change' not in df_copy.columns:
        if 'BTC_Daily_Change' in df_copy.columns:
            df_copy['BTC_Price_Change'] = df_copy['BTC_Daily_Change']
        else:
            df_copy = create_change_features(df_copy, 'BTC_Price')
    
    if 'BTC_Price_PctChange' not in df_copy.columns:
        df_copy['BTC_Price_PctChange'] = df_copy['BTC_Price'].pct_change()
    
    return df_copy

def prepare_features_for_asset(df, asset):
    """تحضير الميزات لأي أصل"""
    if asset == 'gold':
        return prepare_features_for_gold(df)
    elif asset == 'btc':
        return prepare_features_for_btc(df)
    elif asset == 'eth':
        return prepare_features_for_eth(df)
    elif asset == 'try_usd':
        return prepare_features_for_try(df)
    elif asset == 'egp_usd':
        return prepare_features_for_egp(df)
    else:
        return df

def prepare_features_for_eth(df):
    """تحضير الميزات لنموذج Ethereum"""
    df_copy = df.copy()
    
    # مشابه لـ BTC
    df_copy = create_lag_features(df_copy, 'ETH_Price', [1, 2, 3, 7])
    
    if 'ETH_Price_MA7' not in df_copy.columns:
        if 'ETH_MA7' in df_copy.columns:
            df_copy['ETH_Price_MA7'] = df_copy['ETH_MA7']
            df_copy['ETH_Price_MA30'] = df_copy['ETH_MA30']
        else:
            df_copy = create_ma_features(df_copy, 'ETH_Price', [7, 30])
    
    if 'ETH_Price_Volatility' not in df_copy.columns:
        if 'ETH_Volatility' in df_copy.columns:
            df_copy['ETH_Price_Volatility'] = df_copy['ETH_Volatility']
        else:
            df_copy = create_volatility_feature(df_copy, 'ETH_Price', 7)
    
    if 'ETH_Price_Change' not in df_copy.columns:
        df_copy = create_change_features(df_copy, 'ETH_Price')
    
    if 'ETH_Price_PctChange' not in df_copy.columns:
        df_copy['ETH_Price_PctChange'] = df_copy['ETH_Price'].pct_change()
    
    return df_copy

def prepare_features_for_try(df):
    """تحضير الميزات لنموذج TRY/USD"""
    df_copy = df.copy()
    
    df_copy = create_lag_features(df_copy, 'TRY_USD', [1, 2, 3, 7])
    
    if 'TRY_USD_Price_MA7' not in df_copy.columns:
        if 'TRY_USD_MA7' in df_copy.columns:
            df_copy['TRY_USD_Price_MA7'] = df_copy['TRY_USD_MA7']
            df_copy['TRY_USD_Price_MA30'] = df_copy['TRY_USD_MA30']
        else:
            df_copy = create_ma_features(df_copy, 'TRY_USD', [7, 30])
    
    if 'TRY_USD_Volatility' not in df_copy.columns:
        df_copy = create_volatility_feature(df_copy, 'TRY_USD', 7)
    
    if 'TRY_USD_Change' not in df_copy.columns:
        df_copy = create_change_features(df_copy, 'TRY_USD')
    
    if 'TRY_USD_PctChange' not in df_copy.columns:
        df_copy['TRY_USD_PctChange'] = df_copy['TRY_USD'].pct_change()
    
    return df_copy

def prepare_features_for_egp(df):
    """تحضير الميزات لنموذج EGP/USD"""
    df_copy = df.copy()
    
    df_copy = create_lag_features(df_copy, 'EGP_USD', [1, 2, 3, 7])
    
    if 'EGP_USD_Price_MA7' not in df_copy.columns:
        if 'EGP_USD_MA7' in df_copy.columns:
            df_copy['EGP_USD_Price_MA7'] = df_copy['EGP_USD_MA7']
            df_copy['EGP_USD_Price_MA30'] = df_copy['EGP_USD_MA30']
        else:
            df_copy = create_ma_features(df_copy, 'EGP_USD', [7, 30])
    
    if 'EGP_USD_Volatility' not in df_copy.columns:
        df_copy = create_volatility_feature(df_copy, 'EGP_USD', 7)
    
    if 'EGP_USD_Change' not in df_copy.columns:
        df_copy = create_change_features(df_copy, 'EGP_USD')
    
    if 'EGP_USD_PctChange' not in df_copy.columns:
        df_copy['EGP_USD_PctChange'] = df_copy['EGP_USD'].pct_change()
    
    return df_copy

