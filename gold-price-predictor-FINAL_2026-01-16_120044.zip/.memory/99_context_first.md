# 📚 Context-First Document - Gold Price Predictor

**Project Type**: Adoption (Existing Project)  
**Version**: v4.0 (P0 Complete)  
**Last Updated**: 2026-01-15  
**Status**: Production Ready  

---

## 🎯 Project Context

### What Is This Project?
**Gold Price Predictor** is an intelligent financial prediction system that uses 4 AI models (LSTM, GRU, Transformer, Ensemble) to forecast gold prices and other asset prices. It features a comprehensive web dashboard, real-time updates via WebSockets, event analysis, and a self-learning system.

### Current State (Post-P0)
- ✅ **P0-1**: Bull/BullMQ job queue (production-grade, Redis-backed)
- ✅ **P0-2**: Helmet.js security headers (enterprise-grade)
- ✅ **P0-3**: Redis caching layer (high-performance)
- ✅ **P0-4**: Two-Factor Authentication (TOTP + backup codes)
- ✅ **Tests**: 92 unit + 200 performance = 292 passing (100%)
- ✅ **Performance**: 10.67ms avg response, 93.74 RPS
- ✅ **Grade**: A+ (97/100)

---

## 📖 Read This BEFORE Making Changes

### Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                     NGINX (Reverse Proxy)                │
└───────────┬─────────────────────────────────────────────┘
            │
    ┌───────┴────────┐
    │                │
┌───▼────┐      ┌────▼────┐
│Frontend│      │ Backend │
│React+TS│      │Node+tRPC│
└───┬────┘      └────┬────┘
    │                │
    │           ┌────┴────────────────┐
    │           │                     │
    │      ┌────▼────┐          ┌────▼─────┐
    │      │PostgreSQL│          │  Redis   │
    │      │Database │          │  Cache   │
    │      └─────────┘          └──┬───────┘
    │                              │
    │           ┌──────────────────┴───────────────┐
    │           │                                   │
    │      ┌────▼────┐                        ┌────▼────┐
    │      │Bull Queue│                       │Bull Queue│
    │      │Learning │                        │ Search  │
    │      └─────────┘                        └─────────┘
    │
    ├─────────────────────┐
    │                     │
┌───▼─────┐          ┌───▼──────┐
│ML Service│          │Events Svc│
│FastAPI  │          │FastAPI   │
└─────────┘          └──────────┘
```

### Tech Stack

**Frontend**:
- React 18 + TypeScript
- Vite (build tool)
- TailwindCSS + shadcn/ui
- tRPC client
- Socket.io client (WebSocket)
- i18n (Arabic-first RTL)

**Backend**:
- Node.js + Express
- tRPC (type-safe API)
- Drizzle ORM
- PostgreSQL 14+
- Redis (cache + Bull queues)
- Bull/BullMQ (job queues)
- Helmet.js (security)
- Speakeasy (2FA)

**ML/Events**:
- Python FastAPI
- TensorFlow/Keras (LSTM, GRU, Transformer)
- Ensemble learning
- News scraping & sentiment analysis

**Infrastructure**:
- Docker + Docker Compose
- Nginx (reverse proxy)
- WebSocket server (Socket.io)

---

## 🔍 Before You Code - VERIFY

### 1. Check File Registry
```bash
# Always check if file exists first
cat .memory/file_registry.json | grep "your-file-name"
```

### 2. Read Spec First
```bash
# P0 work is in specs/001-gold-predictor-core/
# Read the spec before implementing
cat specs/001-gold-predictor-core/spec.md
cat specs/001-gold-predictor-core/tasks.md
```

### 3. Swear the Verification Oath
Before every import or file creation:
```
"I swear to:
1. Check if this file/module exists
2. Read its documentation
3. Verify its API before using it
4. Not hallucinate functionality"
```

---

## 📁 Key File Locations

### Backend Entry Points
```
server/_core/index.ts          # Main server entry
server/routers.ts              # tRPC router definitions
server/db-compat.ts            # Database abstraction layer
```

### P0 Implementation Files
```
# Bull/BullMQ
server/cache/redis.ts          # Redis connection
server/jobs/bullQueues.ts      # Queue definitions
server/jobs/learningWorker.ts  # Learning worker
server/jobs/searchWorker.ts    # Search worker

# Helmet.js
server/_core/helmet.ts         # Security headers config

# Redis Caching
server/cache/cacheService.ts   # Cache service
server/middleware/caching.ts   # Cache middleware
server/routers/cache.ts        # Cache API

# 2FA
server/services/twoFactor.ts   # 2FA service
server/routers/twoFactor.ts    # 2FA API
drizzle/schema.ts              # Database schema (2FA columns)
```

### Frontend Key Files
```
frontend/src/main.tsx          # Entry point
frontend/src/App.tsx           # Root component
frontend/src/router.tsx        # Routing
frontend/src/components/       # Reusable components
frontend/src/pages/            # Page components
frontend/src/locales/          # i18n translations (ar, en)
```

### Database
```
drizzle/schema.ts              # Main schema
drizzle/schema-*.ts            # Feature-specific schemas
drizzle/migrations/            # SQL migrations
```

### Tests
```
server/__tests__/              # Backend unit tests
tests/e2e/                     # Playwright E2E tests
frontend/src/__tests__/        # Frontend tests (if any)
test-performance.js            # Performance test script
```

### Documentation
```
specs/001-gold-predictor-core/ # Speckit documentation
P0_*.md                        # P0 implementation docs
PERFORMANCE_TEST_REPORT.md    # Performance analysis
README.md                      # Main project readme
```

---

## 🛡️ Security Layers (DO NOT BREAK)

### 1. HTTP Security Headers (Helmet.js)
- Applied in `server/_core/index.ts`
- Configured in `server/_core/helmet.ts`
- **DO NOT REMOVE** middleware

### 2. Authentication
- JWT-based sessions
- 2FA with TOTP (optional but recommended)
- Role-based access control (RBAC)

### 3. Rate Limiting
- API rate limiting (Bull queues)
- Login attempt limiting
- 2FA verification limiting

### 4. Input Validation
- Zod schemas on all tRPC endpoints
- Input sanitization middleware
- SQL injection prevention (Drizzle ORM)

### 5. Data Protection
- Passwords hashed with bcrypt
- 2FA secrets encrypted
- Backup codes hashed with SHA-256
- Redis TLS support

### 6. Audit Logging
- Security events logged
- 2FA events tracked
- All mutations audited

### 7. Network Security
- CORS configured
- WebSocket authentication
- Redis authentication

### 8. Error Handling
- No sensitive data in errors
- Graceful degradation
- Comprehensive try-catch

---

## ⚡ Performance Considerations

### Caching Strategy
- **Redis cache**: Sub-millisecond reads
- **Cache-aside pattern**: Use `cacheService.getOrSet()`
- **TTL levels**: SHORT (1m), MEDIUM (5m), LONG (30m), HOUR, DAY, WEEK
- **Invalidation**: Pattern-based (e.g., `user:*`, `asset:*`)

### Database Optimization
- **Indexes**: Performance indexes applied
- **Connection pool**: Active (PostgreSQL)
- **Query caching**: Via Redis
- **Batch operations**: Use Drizzle's batch API

### Queue Management
- **Learning queue**: 5 concurrent, 10/sec rate limit
- **Search queue**: 3 concurrent, 5/sec rate limit
- **Job persistence**: Redis-backed
- **Retry logic**: 3 attempts, exponential backoff

### Frontend Optimization
- **Code splitting**: Vite automatic
- **Lazy loading**: React.lazy for routes
- **Asset optimization**: Vite handles
- **CDN**: Planned for Phase 10

---

## 🚫 What NOT to Do

### DO NOT:
1. ❌ Delete existing files without explicit authorization
2. ❌ Remove security middleware (Helmet, rate limiting)
3. ❌ Bypass authentication checks
4. ❌ Hardcode secrets or credentials
5. ❌ Disable TypeScript strict mode
6. ❌ Skip tests for new features
7. ❌ Ignore linter errors
8. ❌ Use `any` type in TypeScript
9. ❌ Create files without checking registry
10. ❌ Deploy without running tests

### ALWAYS:
1. ✅ Check file registry before creating files
2. ✅ Read spec before implementing
3. ✅ Write tests for new code
4. ✅ Update documentation with code
5. ✅ Use TypeScript strict mode
6. ✅ Follow existing patterns
7. ✅ Validate all inputs
8. ✅ Handle errors gracefully
9. ✅ Log security events
10. ✅ Verify before deploying

---

## 📝 Making Changes - The Process

### Step 1: Understand the Request
- What feature/fix is needed?
- Does it already exist?
- What files are involved?

### Step 2: Check File Registry
```bash
cat .memory/file_registry.json
```

### Step 3: Read Specifications
```bash
# Read relevant spec
cat specs/001-gold-predictor-core/spec.md
cat specs/001-gold-predictor-core/tasks.md
```

### Step 4: Read Existing Code
- Find related files
- Understand current implementation
- Identify patterns to follow

### Step 5: Plan Changes
- List files to create/modify
- Identify dependencies
- Plan tests

### Step 6: Implement
- Follow existing patterns
- Write tests alongside code
- Update documentation

### Step 7: Verify
- Run tests
- Check linter
- Verify functionality
- Update registry

---

## 🎯 Current Focus Areas

### ✅ Complete
- P0-1: Bull/BullMQ
- P0-2: Helmet.js
- P0-3: Redis Caching
- P0-4: 2FA

### ⏳ Phase 10 (Future)
- Kubernetes infrastructure
- CDN integration
- Database read replicas
- APM monitoring (DataDog)

---

## 📞 Getting Help

### Documentation
- **Main README**: `README.md`
- **P0 Docs**: `P0_*.md` files
- **Specs**: `specs/001-gold-predictor-core/`
- **API Docs**: `docs/API_REFERENCE.md`

### Code Examples
- **P0 Tests**: `server/__tests__/` (92 tests)
- **tRPC Patterns**: `server/routers/`
- **React Patterns**: `frontend/src/pages/`

---

## ⚠️ Common Pitfalls

### 1. **Hallucinating APIs**
- ❌ Assuming a function exists
- ✅ Verify in file_registry.json or read file

### 2. **Breaking Security**
- ❌ Removing middleware
- ✅ Keep all security layers intact

### 3. **Ignoring Cache**
- ❌ Direct DB queries everywhere
- ✅ Use cacheService.getOrSet()

### 4. **Skipping Tests**
- ❌ Code without tests
- ✅ Write tests alongside

### 5. **Poor Error Handling**
- ❌ Exposing sensitive errors
- ✅ Graceful error handling

---

## 🎓 Project Wisdom

### Learned During P0
1. **Bull/BullMQ** is far superior to SimpleQueue
2. **Helmet.js** adds <1ms overhead (worth it!)
3. **Redis caching** gives 20x speedup on cache hits
4. **2FA** adds ~50ms to login (acceptable trade-off)
5. **Performance testing** reveals real bottlenecks

### Best Practices Established
1. **Test-driven**: Write tests alongside code
2. **Type-safe**: 100% TypeScript strict mode
3. **Documented**: Inline comments + guides
4. **Cached**: Cache-aside pattern everywhere
5. **Secure**: 8-layer security model
6. **Monitored**: Logging + statistics
7. **Scalable**: Horizontal scaling ready

---

## 🏁 Quick Reference

### Start Development
```bash
npm run dev              # Start server on http://localhost:2507
```

### Run Tests
```bash
npm test                 # All unit tests
npm test helmet          # Helmet tests
npm test cache           # Cache tests
npm test twoFactor       # 2FA tests
npm test bullIntegration # Bull tests
node test-performance.js # Performance tests
```

### Check Status
```bash
git status                        # Git changes
cat .memory/file_registry.json   # File registry
npm run lint                      # Linter check
```

---

**Remember**: Read this file BEFORE making any changes. When in doubt, check the file registry and read existing code!

**Status**: ✅ Ready for development  
**Performance**: ⚡ A+ (97/100)  
**Production**: 🟢 Ready  

