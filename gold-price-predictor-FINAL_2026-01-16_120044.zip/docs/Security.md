# Security Architecture & Threat Model
<!-- cSpell:disable -->
**FILE**: docs/Security.md | **PURPOSE**: Security threat model, controls, and compliance | **OWNER**: Security Team | **RELATED**: ARCHITECTURE.md, API_Contracts.md, Permissions_Model.md | **LAST-AUDITED**: 2025-12-02

**Version**: 3.1.0  
**Last Updated**: 2025-12-02  
**Security Level**: HIGH  
**Compliance**: GDPR, SOC 2 Type II (in progress)

---

## Table of Contents
1. [Security Overview](#1-security-overview)
2. [Threat Model](#2-threat-model)
3. [Attack Surface Analysis](#3-attack-surface-analysis)
4. [Security Controls](#4-security-controls)
5. [Authentication & Authorization](#5-authentication--authorization)
6. [Data Security](#6-data-security)
7. [Network Security](#7-network-security)
8. [Application Security](#8-application-security)
9. [Infrastructure Security](#9-infrastructure-security)
10. [Security Monitoring](#10-security-monitoring)
11. [Incident Response](#11-incident-response)
12. [Compliance & Auditing](#12-compliance--auditing)
13. [Security Roadmap](#13-security-roadmap)

---

## 1. Security Overview

### 1.1 Security Posture

**Current OSF Security Score**: **9/10** (90%)

**Security Layers**:
```mermaid
graph TB
    A[Internet/Users] -->|HTTPS/TLS 1.3| B[WAF/DDoS Protection]
    B -->|Rate Limiting| C[Load Balancer]
    C -->|Security Headers| D[API Gateway/tRPC]
    D -->|JWT Validation| E[Application Layer]
    E -->|RBAC| F[Business Logic]
    F -->|Parameterized Queries| G[Database Layer]
    G -->|Encryption at Rest| H[Data Storage]
    
    I[Monitoring] -.->|Audit Logs| E
    I -.->|Security Alerts| F
    I -.->|Anomaly Detection| D
```

### 1.2 Security Principles

**Core Principles**:
1. **Defense in Depth**: Multiple security layers (7 layers)
2. **Least Privilege**: Minimal permissions by default
3. **Zero Trust**: Verify everything, trust nothing
4. **Secure by Default**: Fail closed, not open
5. **Privacy by Design**: GDPR compliance from ground up
6. **Security as Code**: All security configs in version control
7. **Continuous Monitoring**: Real-time threat detection

### 1.3 Security Metrics

| Metric | Current | Target | Status |
|--------|---------|--------|--------|
| JWT Token Rotation | ✅ 15min | 15min | Achieved |
| Password Hash Strength | ✅ bcrypt(12) | argon2id | Upgrade planned |
| TLS Version | ✅ 1.3 | 1.3 | Achieved |
| API Rate Limiting | ✅ 100/min | 100/min | Achieved |
| 2FA Adoption | 45% | 80% | In progress |
| Security Headers Score | ✅ A+ | A+ | Achieved |
| OWASP ZAP Score | ✅ 0 High | 0 High | Achieved |
| Vulnerability Scan | Weekly | Daily | Upgrade planned |

---

## 2. Threat Model

### 2.1 STRIDE Threat Analysis

**Spoofing**:
- **Threat**: Attacker impersonates legitimate user
- **Impact**: Unauthorized access to user data, predictions
- **Likelihood**: Medium (JWT tokens, 2FA mitigates)
- **Mitigation**: JWT + 2FA, short token expiry (15min), session monitoring

**Tampering**:
- **Threat**: Attacker modifies prediction data or prices
- **Impact**: Incorrect predictions, financial loss for users
- **Likelihood**: Low (database integrity, audit logs)
- **Mitigation**: Database constraints, audit logging, input validation

**Repudiation**:
- **Threat**: User denies performing action (e.g., API call)
- **Impact**: Disputes, legal issues
- **Likelihood**: Low (comprehensive audit logs)
- **Mitigation**: Immutable audit logs with traceId, timestamp, user context

**Information Disclosure**:
- **Threat**: Unauthorized access to user data, predictions, API keys
- **Impact**: Privacy breach, GDPR violation, competitive intelligence leak
- **Likelihood**: Medium (encrypted data, RBAC mitigates)
- **Mitigation**: Encryption at rest/transit, RBAC, data minimization

**Denial of Service**:
- **Threat**: Attacker overwhelms system with requests
- **Impact**: Service unavailable, revenue loss
- **Likelihood**: High (public API)
- **Mitigation**: Rate limiting (Redis), WAF, auto-scaling, circuit breakers

**Elevation of Privilege**:
- **Threat**: Normal user gains admin access
- **Impact**: Full system compromise
- **Likelihood**: Low (RBAC, input validation)
- **Mitigation**: RBAC with permission checks, input sanitization, parameterized queries

### 2.2 Attack Scenarios

**Scenario 1: Brute Force Login**
- **Attack Vector**: Attacker tries multiple passwords
- **Impact**: Account takeover
- **Probability**: Medium
- **Mitigation**:
  - Rate limiting: 5 attempts per minute per IP
  - Account lockout: 5 failed attempts → 15 min lockout
  - CAPTCHA after 3 failed attempts
  - Email notification on failed login

**Scenario 2: JWT Token Theft**
- **Attack Vector**: XSS attack steals JWT from localStorage
- **Impact**: Session hijacking
- **Probability**: Low (CSP mitigates)
- **Mitigation**:
  - HttpOnly cookies for tRPC (not accessible via JS)
  - Short token expiry (15 minutes)
  - Token rotation on refresh
  - CSP headers prevent XSS

**Scenario 3: SQL Injection**
- **Attack Vector**: Attacker injects SQL in API parameters
- **Impact**: Database compromise, data theft
- **Probability**: Very Low (parameterized queries)
- **Mitigation**:
  - 100% parameterized queries (SQLAlchemy ORM)
  - Input validation with Pydantic/Zod
  - Database user has minimal permissions (no DROP/ALTER)

**Scenario 4: API Key Leak**
- **Attack Vector**: API key committed to GitHub
- **Impact**: Unauthorized API access, rate limit exhaustion
- **Probability**: Medium (human error)
- **Mitigation**:
  - Secret scanning (TruffleHog, gitleaks)
  - API key rotation every 90 days
  - Key revocation on leak detection
  - Rate limiting per key

**Scenario 5: DDoS Attack**
- **Attack Vector**: Distributed bot network overwhelms API
- **Impact**: Service outage
- **Probability**: Medium (public API)
- **Mitigation**:
  - WAF with DDoS protection (Cloudflare)
  - Rate limiting (100-1000 req/min)
  - Auto-scaling (HPA in Kubernetes)
  - Circuit breakers (fail fast)

**Scenario 6: Insider Threat**
- **Attack Vector**: Malicious employee exports user data
- **Impact**: Data breach, GDPR violation
- **Probability**: Low (audit logs, RBAC)
- **Mitigation**:
  - RBAC with least privilege
  - Audit logging for all data exports
  - DLP (Data Loss Prevention) policies
  - Background checks for employees

---

## 3. Attack Surface Analysis

### 3.1 External Attack Surface

**Public Endpoints**:
```
├── Frontend (React SPA)
│   ├── Port: 5173 (dev), 443 (prod)
│   ├── Attack Vectors: XSS, CSRF, clickjacking
│   └── Exposure: High (public internet)
│
├── tRPC API Gateway
│   ├── Port: 5000 (dev), 443 (prod)
│   ├── Attack Vectors: JWT theft, session hijacking
│   └── Exposure: High (authenticated users)
│
├── FastAPI Backend
│   ├── Port: 8000 (internal), 443 (via proxy)
│   ├── Attack Vectors: SQL injection, API abuse
│   └── Exposure: Medium (behind tRPC/proxy)
│
└── Health Checks
    ├── Endpoints: /health, /ready
    ├── Attack Vectors: Information disclosure
    └── Exposure: Low (minimal info)
```

**Attack Surface Reduction**:
- ✅ No direct database access from internet
- ✅ ML engine internal only (not exposed)
- ✅ Redis internal only (no public access)
- ✅ Admin endpoints require ADMIN role
- ⚠️ Health endpoints public (minimal info only)

### 3.2 Internal Attack Surface

**Internal Services**:
```
├── PostgreSQL Database
│   ├── Port: 5432 (internal only)
│   ├── Auth: Password + SSL required
│   └── Exposure: None (internal network)
│
├── Redis Cache
│   ├── Port: 6379 (internal only)
│   ├── Auth: Password required
│   └── Exposure: None (internal network)
│
└── ML Prediction Engine
    ├── Port: Internal only
    ├── Auth: Service-to-service tokens
    └── Exposure: None (internal only)
```

**Network Segmentation**:
- Frontend tier: Public subnet
- Application tier: Private subnet
- Database tier: Isolated subnet
- No direct database access from application tier (via ORM only)

---

## 4. Security Controls

### 4.1 Preventive Controls

**Authentication Controls**:
- ✅ JWT with 15-minute access token expiry
- ✅ 7-day refresh token with rotation
- ✅ 2FA with TOTP (Google Authenticator)
- ✅ Password policy: min 8 chars, uppercase, lowercase, digit
- ✅ bcrypt password hashing (cost factor 12)
- 🔄 Upgrade to argon2id (planned)

**Authorization Controls**:
- ✅ RBAC with 4 roles (ADMIN, MANAGER, USER, GUEST)
- ✅ Permission checks on every API call
- ✅ Frontend + Backend authorization (defense in depth)
- ✅ API key-based access for external integrations

**Input Validation**:
- ✅ Pydantic models for FastAPI (strict type checking)
- ✅ Zod schemas for tRPC (TypeScript validation)
- ✅ SQL injection prevention (100% parameterized queries)
- ✅ XSS prevention (DOMPurify, CSP nonces)
- ✅ CSRF tokens for state-changing operations

**Rate Limiting**:
- ✅ Redis-backed rate limiter
- ✅ Per-user limits: 100 req/min, 1000 req/hour
- ✅ Per-IP limits: 10 req/min (anonymous)
- ✅ Per-API-key limits: 1000 req/min (paid tier)
- ✅ Exponential backoff on 429 errors

### 4.2 Detective Controls

**Audit Logging**:
```python
# All events logged to audit_logs table
audit_logger.log_event(
    user_id=user.id,
    action="LOGIN",
    resource="auth",
    ip_address=get_client_ip(request),
    user_agent=request.headers.get("user-agent"),
    outcome="success",
    severity="normal"
)
```

**Logged Events**:
- ✅ All authentication attempts (success + failure)
- ✅ All API calls (with traceId)
- ✅ All data exports
- ✅ All permission checks (denied attempts)
- ✅ All 2FA setup/disable actions
- ✅ All API key creation/deletion
- ✅ All prediction requests

**Monitoring & Alerting**:
- ✅ Failed login attempts (>5 in 5 min → alert)
- ✅ Permission denied attempts (>10 in 1 min → alert)
- ✅ Rate limit exceeded (>100 in 1 min → alert)
- ✅ Database connection errors
- ✅ Redis connection errors
- ⚠️ SIEM integration (planned)

### 4.3 Corrective Controls

**Incident Response**:
- Account lockout: 15-minute lockout after 5 failed attempts
- API key revocation: Immediate on leak detection
- Token invalidation: Blacklist compromised JWTs
- IP blocking: Block malicious IPs at WAF level
- Circuit breakers: Fail fast on service degradation

**Rollback Procedures**:
- Database backups: Daily full, hourly incremental
- Application rollback: Blue-green deployment
- Configuration rollback: Git-based, instant
- RTO: <1 hour, RPO: <15 minutes

---

## 5. Authentication & Authorization

### 5.1 Authentication Flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend
    participant T as tRPC API
    participant B as FastAPI Backend
    participant DB as PostgreSQL
    participant R as Redis
    
    U->>F: Login (username, password)
    F->>B: POST /api/auth/login
    B->>R: Check rate limit
    R-->>B: OK (not exceeded)
    B->>DB: Query user by username
    DB-->>B: User data (hashed password)
    B->>B: Verify password (bcrypt)
    
    alt 2FA Enabled
        B-->>F: 401 + 2FA_REQUIRED
        F->>U: Prompt for 2FA token
        U->>F: Enter 6-digit code
        F->>B: POST /api/auth/2fa/verify
        B->>B: Verify TOTP token (pyotp)
    end
    
    B->>B: Generate JWT tokens
    B->>R: Store refresh token
    B->>DB: Log audit event (LOGIN success)
    B-->>F: Access + Refresh tokens
    F->>F: Store in httpOnly cookie
    F-->>U: Redirect to dashboard
```

### 5.2 Authorization (RBAC)

**Role Hierarchy**:
```
ADMIN (superuser)
  ├── Full system access
  ├── User management
  ├── API key management
  ├── System settings
  └── Audit log access
  
MANAGER
  ├── Create/edit predictions
  ├── View all user predictions
  ├── Export data
  └── Alert management
  
USER (default)
  ├── Create own predictions
  ├── View own predictions
  ├── Create alerts
  └── View dashboard
  
GUEST (read-only)
  ├── View public predictions
  └── View public dashboard
```

**Permission Matrix**: See [Permissions_Model.md](./Permissions_Model.md)

### 5.3 Session Management

**JWT Token Configuration**:
```python
# Access Token (short-lived)
ACCESS_TOKEN_EXPIRE_MINUTES = 15
payload = {
    "sub": user.username,
    "user_id": user.id,
    "role": user.role,
    "exp": datetime.utcnow() + timedelta(minutes=15),
    "iat": datetime.utcnow(),
    "jti": str(uuid.uuid4())  # Unique token ID
}

# Refresh Token (long-lived)
REFRESH_TOKEN_EXPIRE_DAYS = 7
refresh_payload = {
    "sub": user.username,
    "type": "refresh",
    "exp": datetime.utcnow() + timedelta(days=7)
}
```

**Token Rotation**:
- Access token expires after 15 minutes
- Frontend auto-refreshes using refresh token
- Refresh token rotates on each use (one-time use)
- Old refresh token blacklisted in Redis

### 5.4 Session Middleware Security (v3.1.0)

**Implementation** (`server/_core/sessionMiddleware.ts`):
```typescript
// Session cookie with secure defaults
const sessionCookieOptions = {
  httpOnly: true,        // Prevent XSS access
  secure: isProduction,  // HTTPS only in production
  sameSite: 'lax',       // CSRF protection
  maxAge: ONE_YEAR_MS,   // 1 year persistence
  path: '/'              // All routes
};

// Session info attached to every request
req.sessionInfo = {
  userId: decodedToken?.userId || null,
  role: decodedToken?.role || 'guest',
  isAuthenticated: !!decodedToken,
  sessionId: sessionCookie
};
```

**Security Features**:
- ✅ HttpOnly cookies (prevents JavaScript access)
- ✅ Secure flag in production (HTTPS only)
- ✅ SameSite=Lax (CSRF protection)
- ✅ Session renewal on each request
- ✅ CORS with credential support for same-origin requests
- ✅ Request logging with session context

**Error Handling Security**:
- HTTP error pages (400-506) with sanitized error messages
- No stack traces exposed in production
- Rate limiting on error responses to prevent enumeration
- All errors logged with correlation IDs

---

## 6. Data Security

### 6.1 Data Classification

| Data Type | Classification | Encryption | Retention |
|-----------|---------------|------------|-----------|
| Passwords | Critical | bcrypt(12) | Permanent |
| API Keys | Critical | SHA-256 hash | Until revoked |
| JWT Tokens | Sensitive | Signed (HS256) | 15min/7days |
| User PII (email) | Sensitive | AES-256 (planned) | Account lifetime |
| Predictions | Confidential | TLS in transit | 12 months |
| Audit Logs | Confidential | TLS in transit | 12 months |
| Price Data | Public | None | Permanent |

### 6.2 Encryption

**Encryption at Rest**:
- ⚠️ Database: TDE (Transparent Data Encryption) - **planned**
- ⚠️ Backups: AES-256 encryption - **planned**
- ⚠️ User PII: Column-level encryption - **planned**
- ✅ Passwords: bcrypt (cost 12)
- ✅ API Keys: SHA-256 hash (plain key shown once)

**Encryption in Transit**:
- ✅ TLS 1.3 for all HTTPS connections
- ✅ Minimum cipher suite: TLS_AES_256_GCM_SHA384
- ✅ HSTS header: max-age=31536000
- ✅ Database connections: SSL required
- ✅ Redis connections: TLS enabled

### 6.3 Data Retention & Deletion

**Retention Policies**:
- Audit logs: 12 months → archive → delete after 7 years
- Predictions: 12 months → soft delete
- User accounts: Permanent (until user requests deletion)
- Backups: 30 days online, 1 year cold storage

**GDPR Right to Deletion**:
```python
def delete_user_data(user_id: int):
    """GDPR-compliant user data deletion"""
    # Soft delete user
    user.deleted_at = datetime.utcnow()
    user.email = f"deleted_{user.id}@deleted.local"
    user.username = f"deleted_{user.id}"
    
    # Delete all user predictions
    Prediction.query.filter_by(user_id=user_id).delete()
    
    # Delete all user alerts
    Alert.query.filter_by(user_id=user_id).delete()
    
    # Anonymize audit logs (keep for compliance)
    AuditLog.query.filter_by(user_id=user_id).update({
        "user_id": None,
        "username": "ANONYMIZED"
    })
```

---

## 7. Network Security

### 7.1 Network Architecture

**Production Network Topology**:
```
Internet
   │
   ├──[WAF/DDoS Protection (Cloudflare)]
   │
   ├──[Load Balancer (NGINX)]
   │      │
   │      ├─► Frontend (React SPA) - Public Subnet
   │      │
   │      └─► API Gateway (tRPC) - Public Subnet
   │             │
   │             └─► FastAPI Backend - Private Subnet
   │                    │
   │                    ├─► PostgreSQL - Isolated Subnet
   │                    ├─► Redis - Isolated Subnet
   │                    └─► ML Engine - Isolated Subnet
```

**Firewall Rules**:
```yaml
# Inbound Rules
- Port 443 (HTTPS): Allow from 0.0.0.0/0
- Port 80 (HTTP): Allow from 0.0.0.0/0 (redirect to 443)
- Port 22 (SSH): Allow from VPN only (10.0.0.0/8)
- Port 5432 (PostgreSQL): Deny from internet
- Port 6379 (Redis): Deny from internet

# Outbound Rules
- Port 443 (HTTPS): Allow (for external APIs)
- Port 80 (HTTP): Allow (for health checks)
- All other ports: Deny by default
```

### 7.2 Security Headers

**HTTP Security Headers** (backend/app/security_headers.py):
```python
SECURITY_HEADERS = {
    # Prevent XSS attacks
    "Content-Security-Policy": (
        "default-src 'self'; "
        "script-src 'self' 'nonce-{nonce}'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: https:; "
        "font-src 'self' data:; "
        "connect-src 'self' https://api.goldpredictor.com; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self';"
    ),
    
    # Force HTTPS
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    
    # Prevent clickjacking
    "X-Frame-Options": "DENY",
    
    # Prevent MIME sniffing
    "X-Content-Type-Options": "nosniff",
    
    # XSS protection
    "X-XSS-Protection": "1; mode=block",
    
    # Referrer policy
    "Referrer-Policy": "strict-origin-when-cross-origin",
    
    # Permissions policy
    "Permissions-Policy": (
        "geolocation=(), "
        "microphone=(), "
        "camera=(), "
        "payment=(), "
        "usb=(), "
        "magnetometer=()"
    )
}
```

**Security Headers Score**: **A+** (securityheaders.com)

---

## 8. Application Security

### 8.1 OWASP Top 10 Mitigations

**A01:2021 – Broken Access Control**:
- ✅ RBAC on every endpoint (backend + frontend)
- ✅ Resource ownership validation (user can only access own predictions)
- ✅ No IDOR vulnerabilities (UUIDs, not sequential IDs)

**A02:2021 – Cryptographic Failures**:
- ✅ TLS 1.3 for all connections
- ✅ bcrypt for passwords (cost 12)
- ⚠️ Column-level encryption for PII (planned)

**A03:2021 – Injection**:
- ✅ 100% parameterized queries (SQLAlchemy ORM)
- ✅ Input validation (Pydantic, Zod)
- ✅ Output encoding (DOMPurify)

**A04:2021 – Insecure Design**:
- ✅ Threat modeling (STRIDE)
- ✅ Security architecture review
- ✅ Defense in depth (7 layers)

**A05:2021 – Security Misconfiguration**:
- ✅ No default credentials
- ✅ Security headers configured
- ✅ Error messages don't leak info
- ✅ Unnecessary features disabled

**A06:2021 – Vulnerable Components**:
- ✅ Dependency scanning (Snyk, npm audit)
- ✅ Weekly dependency updates
- ✅ SBOM generation (planned)

**A07:2021 – Identification and Authentication Failures**:
- ✅ 2FA available
- ✅ Account lockout (5 failed attempts)
- ✅ Short session timeout (15 min)
- ✅ Password policy enforced

**A08:2021 – Software and Data Integrity Failures**:
- ✅ Code signing (planned)
- ✅ Integrity checks for ML models
- ✅ Immutable audit logs

**A09:2021 – Security Logging and Monitoring Failures**:
- ✅ Comprehensive audit logging
- ✅ Real-time monitoring (Prometheus + Grafana)
- ✅ Security alerts (Slack, PagerDuty)

**A10:2021 – Server-Side Request Forgery**:
- ✅ URL validation for external requests
- ✅ Allowlist for external APIs
- ✅ No user-controlled URLs

### 8.2 Secure Development Lifecycle

**Security Gates**:
```
Development
   ├─► Code Review (security checklist)
   ├─► SAST Scan (SonarQube)
   ├─► Dependency Scan (Snyk)
   └─► Unit Tests (80%+ coverage)
      ↓
Staging
   ├─► Integration Tests
   ├─► DAST Scan (OWASP ZAP)
   ├─► Penetration Testing (quarterly)
   └─► Security Review
      ↓
Production
   ├─► Blue-Green Deployment
   ├─► Smoke Tests
   ├─► Monitoring Active
   └─► Incident Response Ready
```

### 8.4 AI Memory & RAG Security (v3.1.0)

**AI Memory Isolation**:
The AI memory service (`server/ai-memory-service.ts`) implements strict user isolation:

```typescript
// Memory storage with user isolation
export class AIMemoryService {
  async storeMemory(userId: string, memory: MemoryEntry): Promise<void> {
    // Enforce user ownership at storage level
    const stmt = db.prepare(`
      INSERT INTO ai_memories (id, userId, type, content, keywords, importance, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(memoryId, userId, type, content, keywords, importance, Date.now());
  }

  async getMemories(userId: string): Promise<MemoryEntry[]> {
    // User can only access their own memories
    return db.prepare('SELECT * FROM ai_memories WHERE userId = ?').all(userId);
  }
}
```

**RAG Security Controls**:
- ✅ User-scoped memory queries (no cross-user data leakage)
- ✅ Input sanitization before storage
- ✅ Keyword extraction uses deterministic algorithms (no external API calls)
- ✅ Memory importance scoring with bounds checking
- ✅ Conversation history limited to last 10 messages (memory bounds)
- ✅ Token limits on AI context (4096 tokens max)

**AI Assistant Security**:
- ✅ Usage limits per user (10 requests/day, 100 requests/month)
- ✅ Admin users exempt from limits
- ✅ Context injection prevention (system prompts are immutable)
- ✅ Response sanitization before display
- ✅ Audit logging of all AI interactions

**Data Retention**:
- AI memories: User-controlled deletion
- Conversation logs: 30 days retention
- RAG vectors: Purged with user account deletion

---

## 9. Infrastructure Security

### 9.1 Container Security

**Docker Security Best Practices**:
```dockerfile
# Use minimal base image
FROM python:3.11-alpine

# Run as non-root user
RUN addgroup -g 1001 appgroup && \
    adduser -D -u 1001 -G appgroup appuser

USER appuser

# No secrets in image
# Use KMS/Vault instead

# Scan for vulnerabilities
# trivy image gold-predictor:latest
```

**Container Scanning**:
- ✅ Trivy scan on every build
- ✅ No HIGH/CRITICAL vulnerabilities allowed
- ✅ Base image updates weekly

### 9.2 Kubernetes Security

**Pod Security Standards** (restricted):
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: gold-predictor-api
spec:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 1001
    seccompProfile:
      type: RuntimeDefault
  containers:
  - name: api
    image: gold-predictor:3.0.0
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities:
        drop:
          - ALL
    resources:
      limits:
        cpu: "1000m"
        memory: "1Gi"
      requests:
        cpu: "250m"
        memory: "256Mi"
```

**Network Policies**:
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-network-policy
spec:
  podSelector:
    matchLabels:
      app: gold-predictor-api
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: gold-predictor-frontend
    ports:
    - protocol: TCP
      port: 8000
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: postgres
    ports:
    - protocol: TCP
      port: 5432
```

---

## 10. Security Monitoring

### 10.1 Metrics & Alerts

**Security Metrics Dashboard**:
```
┌─────────────────────────────────────┐
│  Security Metrics (Last 24 Hours)  │
├─────────────────────────────────────┤
│ Failed Login Attempts:    42        │
│ Rate Limit Violations:    128       │
│ Permission Denied:        15        │
│ 2FA Failures:            8          │
│ API Key Revocations:     2          │
│ Anomalous Requests:      0          │
└─────────────────────────────────────┘
```

**Alert Rules** (Prometheus):
```yaml
groups:
- name: security_alerts
  rules:
  - alert: HighFailedLoginRate
    expr: rate(failed_login_attempts[5m]) > 10
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "High failed login rate detected"
      
  - alert: RateLimitAbuse
    expr: rate(rate_limit_exceeded[1m]) > 100
    for: 1m
    labels:
      severity: critical
    annotations:
      summary: "Rate limit abuse detected"
```

### 10.2 Anomaly Detection

**Behavioral Analysis** (planned):
- Unusual API call patterns
- Login from new geolocation
- Unusual data access patterns
- Mass data export attempts
- Spike in failed predictions

---

## 11. Incident Response

### 11.1 Incident Classification

| Severity | Definition | Response Time | Examples |
|----------|------------|---------------|----------|
| **P0 - Critical** | Active breach, data leak | <15 min | Database compromise, API key leak on GitHub |
| **P1 - High** | Potential breach, high risk | <1 hour | Repeated failed login from single IP |
| **P2 - Medium** | Security violation, medium risk | <4 hours | Rate limit exceeded, permission denied |
| **P3 - Low** | Minor security event | <24 hours | Single failed login |

### 11.2 Incident Response Plan

**Phase 1: Detection & Analysis** (0-30 min)
1. Alert received (Prometheus, SIEM, manual report)
2. Incident commander assigned
3. Severity classification (P0-P3)
4. Initial analysis (logs, metrics, user reports)
5. Contain if P0/P1 (isolate affected systems)

**Phase 2: Containment** (30min-2h)
1. Isolate compromised systems/accounts
2. Revoke compromised credentials (API keys, JWT tokens)
3. Block malicious IPs at WAF level
4. Enable enhanced monitoring
5. Preserve forensic evidence

**Phase 3: Eradication** (2h-8h)
1. Identify root cause
2. Remove malicious code/access
3. Patch vulnerabilities
4. Update security controls
5. Verify eradication

**Phase 4: Recovery** (8h-24h)
1. Restore services from clean backups
2. Reset credentials for affected users
3. Gradual rollout with monitoring
4. User notifications (if required by GDPR)

**Phase 5: Post-Incident** (24h-1 week)
1. Blameless post-mortem
2. Update runbooks
3. Implement preventive controls
4. Security training if needed
5. Report to stakeholders

### 11.3 Communication Plan

**Internal Communication**:
- Incident commander → Engineering team (Slack #security-incidents)
- Engineering → Management (email + Slack)
- Management → Board (if P0)

**External Communication**:
- Users affected by breach: Email within 72 hours (GDPR requirement)
- Public status page update (status.goldpredictor.com)
- Blog post if major incident (transparency)

---

## 12. Compliance & Auditing

### 12.1 GDPR Compliance

**Data Subject Rights**:
- ✅ Right to access: GET /api/user/data API endpoint
- ✅ Right to rectification: PUT /api/user/profile
- ✅ Right to erasure: DELETE /api/user/account (soft delete)
- ✅ Right to portability: GET /api/user/export (JSON format)
- ⚠️ Right to object: Opt-out mechanism (planned)
- ⚠️ Consent management: Cookie consent banner (planned)

**Legal Basis for Processing**:
- Contract performance (predictions for users)
- Legitimate interest (fraud prevention, security)
- Consent (marketing emails)

**Data Protection Officer**: security@goldpredictor.com

### 12.2 SOC 2 Type II (In Progress)

**Trust Service Criteria**:
- **CC1.1 - Organization**: Security policies documented
- **CC2.1 - Communication**: Security training for all employees
- **CC3.1 - Risk Assessment**: Annual threat modeling
- **CC4.1 - Monitoring**: Real-time security monitoring
- **CC5.1 - Control Activities**: 50+ security controls implemented
- **CC6.1 - Logical Access**: RBAC + 2FA
- **CC7.1 - System Operations**: Incident response plan
- **CC8.1 - Change Management**: Controlled deployments
- **CC9.1 - Risk Mitigation**: Backup + DR plan

**Audit Timeline**: Q2 2026 (target)

### 12.3 Audit Logging

**Immutable Audit Log** (PostgreSQL audit_logs table):
```sql
CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
    trace_id UUID NOT NULL,
    user_id INTEGER REFERENCES users(id),
    username VARCHAR(100),
    action VARCHAR(50) NOT NULL,  -- LOGIN, PREDICT, EXPORT, etc.
    resource VARCHAR(100),         -- auth, predictions, alerts
    ip_address VARCHAR(45),
    user_agent TEXT,
    request_method VARCHAR(10),    -- GET, POST, PUT, DELETE
    request_path TEXT,
    outcome VARCHAR(20),           -- success, failure, denied
    severity VARCHAR(20),          -- normal, warning, critical
    details JSONB,
    
    -- Prevent tampering
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    -- No updated_at (append-only)
    
    CONSTRAINT audit_logs_immutable CHECK (false)  -- No updates allowed
);

-- Indexes for fast queries
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_outcome ON audit_logs(outcome);
```

**Retention**: 12 months online, 7 years archive (compliance requirement)

---

## 13. Security Roadmap

### 13.1 Short-Term (Next 3 Months)

**P0 - Critical**:
- [ ] Upgrade password hashing: bcrypt → argon2id
- [ ] Implement SIEM integration (Splunk/ELK)
- [ ] Add column-level encryption for PII
- [ ] Enable database TDE (Transparent Data Encryption)
- [ ] Implement API request signing (HMAC-SHA256)

**P1 - High**:
- [ ] Penetration testing (external firm)
- [ ] Bug bounty program launch
- [ ] Security training for all developers
- [ ] SBOM (Software Bill of Materials) generation
- [ ] Kubernetes pod security policies

### 13.2 Medium-Term (3-6 Months)

**P1 - High**:
- [ ] Secrets management (HashiCorp Vault)
- [ ] Code signing for all releases
- [ ] DLP (Data Loss Prevention) policies
- [ ] WAF custom rules (OWASP CRS)
- [ ] Anomaly detection with ML

**P2 - Medium**:
- [ ] Biometric authentication (Face ID, Touch ID)
- [ ] SSO integration (SAML, OAuth)
- [ ] Advanced threat protection (ATP)
- [ ] Security chaos engineering
- [ ] Compliance automation (SOC 2, ISO 27001)

### 13.3 Long-Term (6-12 Months)

**P2 - Medium**:
- [ ] Zero Trust architecture (BeyondCorp)
- [ ] Quantum-resistant encryption
- [ ] Homomorphic encryption for predictions
- [ ] Hardware security modules (HSM)
- [ ] Blockchain audit trail

---

## Appendix A: Security Checklist

**Pre-Deployment Checklist**:
- [ ] All secrets in KMS/Vault (not .env files)
- [ ] HTTPS enforced (HTTP redirects)
- [ ] Security headers configured (A+ rating)
- [ ] Rate limiting enabled
- [ ] RBAC on all endpoints
- [ ] Input validation (Pydantic/Zod)
- [ ] SQL injection prevented (parameterized queries)
- [ ] XSS prevented (DOMPurify, CSP)
- [ ] CSRF tokens on forms
- [ ] Audit logging active
- [ ] Monitoring & alerting configured
- [ ] Backups automated & tested
- [ ] Incident response plan documented
- [ ] Security contact published

---

## Appendix B: Security Contacts

**Security Team**:
- Security Lead: security-lead@goldpredictor.com
- Security Team: security@goldpredictor.com
- Bug Bounty: bugbounty@goldpredictor.com
- Incident Response: incidents@goldpredictor.com

**External Resources**:
- HackerOne Bug Bounty: https://hackerone.com/goldpredictor
- Security Advisory: https://goldpredictor.com/security
- Status Page: https://status.goldpredictor.com

---

**Last Updated**: 2025-12-02  
**Next Review**: 2026-03-02 (quarterly review)  
**Version**: 3.1.0  
**Owner**: Security Team

---

## Changelog

### v3.1.0 (2025-12-02)
- Added Section 5.4: Session Middleware Security
- Added Section 8.4: AI Memory & RAG Security
- Updated security audit date
- Added error handling security documentation
- Added database performance indexes (002 migration)
