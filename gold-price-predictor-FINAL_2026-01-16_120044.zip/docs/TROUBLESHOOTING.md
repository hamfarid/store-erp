# 🔧 استكشاف الأخطاء وإصلاحها - Troubleshooting

## 🔐 مشاكل تسجيل الدخول

### ❌ "Zero-length key is not supported"

**السبب**: مفتاح JWT غير موجود في `.env`

**الحل**:
1. افتح ملف `.env`
2. أضف السطر التالي:
```env
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production-min-32-chars
```
3. أعد تشغيل السيرفر

**ملاحظة**: يجب أن يكون المفتاح 32 حرف على الأقل للأمان.

---

### ❌ "Invalid email or password"

**الأسباب المحتملة**:

#### 1. بيانات الدخول خاطئة
- تحقق من البريد الإلكتروني وكلمة المرور
- استخدم بيانات Admin الافتراضية:
  - Email: `admin@example.com`
  - Password: `Admin@123`

#### 2. المستخدم غير موجود
```bash
# تحقق من المستخدمين
npx tsx server/scripts/check-users.ts

# إنشاء مستخدم admin
npx tsx server/scripts/create-admin.ts
```

#### 3. المستخدم يستخدم OAuth
- إذا كان المستخدم مسجل عبر OAuth، لا يمكن تسجيل الدخول بكلمة مرور
- الرسالة: "This account uses OAuth. Please login with OAuth."

#### 4. كلمة المرور غير مشفرة بشكل صحيح
```bash
# أعد إنشاء المستخدم
npx tsx server/scripts/create-admin.ts
```

---

## 🌐 مشاكل السيرفر

### ❌ port 2505 مشغول

**الحل التلقائي**: السيرفر سيبحث عن منفذ متاح (3000-3020)

**الحل اليدوي**:
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Linux/Mac
lsof -i :3000
kill -9 <PID>
```

---

### ❌ "Cannot find module"

**الحل**:
```bash
npm install --legacy-peer-deps
```

---

### ❌ TypeScript Errors

**الحل**:
```bash
npm run check
```

---

## 💾 مشاكل قاعدة البيانات

### ❌ "no such column: passwordHash"

**السبب**: Migration لم يتم تشغيله

**الحل**:
```bash
npx tsx server/migrations/001_add_password_to_users.ts
```

أو أعد تشغيل السيرفر (Migration يعمل تلقائياً)

---

### ❌ "database is locked"

**السبب**: عملية أخرى تستخدم قاعدة البيانات

**الحل**:
1. أغلق جميع العمليات التي تستخدم قاعدة البيانات
2. أعد تشغيل السيرفر

---

## 🎨 مشاكل Frontend

### ❌ صفحة بيضاء فارغة

**الحل**:
1. افتح Console (F12)
2. تحقق من الأخطاء
3. امسح الكاش (Ctrl+Shift+Delete)
4. Hard Refresh (Ctrl+F5)

---

### ❌ "Failed to fetch"

**السبب**: السيرفر لا يعمل

**الحل**:
```bash
npx tsx server/_core/index.ts
```

---

## 🔍 أدوات التشخيص

### التحقق من المستخدمين
```bash
npx tsx server/scripts/check-users.ts
```

### إنشاء مستخدم Admin
```bash
npx tsx server/scripts/create-admin.ts
```

### فحص TypeScript
```bash
npm run check
```

### سجلات السيرفر
- تحقق من Terminal حيث يعمل السيرفر
- ابحث عن رسائل الخطأ باللون الأحمر

---

## 📞 الحصول على المساعدة

إذا لم تحل المشكلة:

1. **تحقق من السجلات**:
   - سجلات السيرفر في Terminal
   - Console في المتصفح (F12)

2. **جمع المعلومات**:
   - رسالة الخطأ الكاملة
   - الخطوات التي أدت للخطأ
   - نسخة Node.js: `node --version`

3. **راجع التوثيق**:
   - [دليل الإعداد](LOCAL_AUTH_SETUP.md)
   - [دليل البدء السريع](../QUICK_START_WEB.md)

---

## ✅ قائمة التحقق السريعة

قبل طلب المساعدة، تحقق من:

- [ ] السيرفر يعمل (`http://localhost:2505/`)
- [ ] `.env` يحتوي على `JWT_SECRET`
- [ ] قاعدة البيانات تحتوي على عمود `passwordHash`
- [ ] مستخدم Admin موجود
- [ ] بيانات الدخول صحيحة
- [ ] Console لا يحتوي على أخطاء
- [ ] الكاش تم مسحه

---

**آخر تحديث**: 2025-11-20

