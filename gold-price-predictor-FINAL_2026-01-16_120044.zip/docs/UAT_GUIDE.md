# User Acceptance Testing (UAT) Guide

**Purpose:** Validate Gold Price Predictor meets business requirements  
**Date:** 2025-01-18  
**Owner:** QA Team & Product Owner

---

## Table of Contents

1. [Overview](#overview)
2. [UAT Participants](#uat-participants)
3. [Test Scenarios](#test-scenarios)
4. [Feedback Collection](#feedback-collection)
5. [Acceptance Criteria](#acceptance-criteria)

---

## Overview

User Acceptance Testing (UAT) validates that the application meets business requirements and is ready for production deployment.

**UAT Environment:** https://staging.goldpredictor.com  
**Duration:** 5 business days  
**Participants:** 10-15 users (admins, traders, analysts)

---

## UAT Participants

### Roles

**1. Admin Users (3 users)**
- Test user management
- Test asset management
- Test system configuration
- Test audit logs

**2. Trader Users (5 users)**
- Test price predictions
- Test alerts
- Test portfolio tracking
- Test real-time data

**3. Analyst Users (3 users)**
- Test historical data
- Test charts and visualizations
- Test export functionality
- Test reporting

**4. Guest Users (2 users)**
- Test public pages
- Test registration
- Test password reset

### Test Accounts

| Username | Password | Role | Email |
|----------|----------|------|-------|
| uat_admin1 | UAT@Admin1 | Admin | uat_admin1@test.com |
| uat_admin2 | UAT@Admin2 | Admin | uat_admin2@test.com |
| uat_admin3 | UAT@Admin3 | Admin | uat_admin3@test.com |
| uat_trader1 | UAT@Trader1 | User | uat_trader1@test.com |
| uat_trader2 | UAT@Trader2 | User | uat_trader2@test.com |
| uat_trader3 | UAT@Trader3 | User | uat_trader3@test.com |
| uat_trader4 | UAT@Trader4 | User | uat_trader4@test.com |
| uat_trader5 | UAT@Trader5 | User | uat_trader5@test.com |
| uat_analyst1 | UAT@Analyst1 | User | uat_analyst1@test.com |
| uat_analyst2 | UAT@Analyst2 | User | uat_analyst2@test.com |
| uat_analyst3 | UAT@Analyst3 | User | uat_analyst3@test.com |

---

## Test Scenarios

### Day 1: Authentication & User Management

**Scenario 1.1: User Registration**
1. Navigate to https://staging.goldpredictor.com/register
2. Fill in registration form
3. Verify email confirmation
4. Login with new credentials
5. **Expected:** Successful registration and login

**Scenario 1.2: Password Reset**
1. Click "Forgot Password"
2. Enter email address
3. Check email for reset link
4. Click link and set new password
5. Login with new password
6. **Expected:** Password reset successful

**Scenario 1.3: Account Lockout**
1. Attempt login with wrong password 5 times
2. **Expected:** Account locked for 30 minutes
3. Wait 30 minutes
4. Login with correct password
5. **Expected:** Login successful

**Scenario 1.4: User Management (Admin)**
1. Login as admin
2. Navigate to Users page
3. Create new user
4. Edit user details
5. Deactivate user
6. Activate user
7. Delete user
8. **Expected:** All CRUD operations successful

### Day 2: Asset Management & Predictions

**Scenario 2.1: View Assets**
1. Login as trader
2. Navigate to Assets page
3. View list of assets
4. Search for "Gold"
5. Filter by category "Precious Metals"
6. **Expected:** Assets displayed correctly

**Scenario 2.2: Create Prediction**
1. Select asset (e.g., Gold)
2. Choose prediction horizon (1 day, 1 week, 1 month)
3. Click "Predict"
4. View prediction results
5. **Expected:** Prediction generated with confidence score

**Scenario 2.3: View Historical Predictions**
1. Navigate to Predictions page
2. View list of past predictions
3. Filter by asset
4. Filter by date range
5. **Expected:** Historical predictions displayed

**Scenario 2.4: Asset Management (Admin)**
1. Login as admin
2. Navigate to Assets page
3. Create new asset
4. Edit asset details
5. Deactivate asset
6. Delete asset
7. **Expected:** All CRUD operations successful

### Day 3: Alerts & Notifications

**Scenario 3.1: Create Price Alert**
1. Login as trader
2. Navigate to Alerts page
3. Click "Create Alert"
4. Select asset (e.g., Gold)
5. Set alert type "Above"
6. Set target price (e.g., $2000)
7. Select notification method (email)
8. **Expected:** Alert created successfully

**Scenario 3.2: Create Change Alert**
1. Create alert with type "Change"
2. Set change percent (e.g., 5%)
3. **Expected:** Alert created successfully

**Scenario 3.3: Alert Triggering**
1. Wait for price to reach target
2. **Expected:** Email notification received

**Scenario 3.4: Manage Alerts**
1. View list of alerts
2. Edit alert
3. Deactivate alert
4. Delete alert
5. **Expected:** All operations successful

### Day 4: Charts, Reports & Export

**Scenario 4.1: View Charts**
1. Login as analyst
2. Navigate to Dashboard
3. View price charts
4. Change time range (1 day, 1 week, 1 month)
5. Change chart type (line, candlestick)
6. **Expected:** Charts display correctly

**Scenario 4.2: Export Data**
1. Navigate to Predictions page
2. Click "Export"
3. Select format (CSV, Excel, PDF)
4. Download file
5. **Expected:** File downloaded successfully

**Scenario 4.3: Generate Report**
1. Navigate to Reports page
2. Select report type (Predictions, Alerts, Activity)
3. Select date range
4. Click "Generate"
5. **Expected:** Report generated and displayed

### Day 5: Performance & Usability

**Scenario 5.1: Page Load Time**
1. Navigate to each page
2. Measure load time
3. **Expected:** All pages load within 3 seconds

**Scenario 5.2: Mobile Responsiveness**
1. Access site on mobile device
2. Test all features
3. **Expected:** All features work on mobile

**Scenario 5.3: Browser Compatibility**
1. Test on Chrome, Firefox, Safari, Edge
2. **Expected:** Works on all browsers

**Scenario 5.4: Concurrent Users**
1. Have 10 users login simultaneously
2. Perform various operations
3. **Expected:** No performance degradation

---

## Feedback Collection

### Feedback Form

**For each scenario, collect:**

1. **Scenario ID:** (e.g., 1.1, 2.3)
2. **Status:** Pass / Fail / Partial
3. **Severity:** Critical / High / Medium / Low
4. **Description:** What worked / What didn't work
5. **Steps to Reproduce:** (if failed)
6. **Expected Behavior:** What should happen
7. **Actual Behavior:** What actually happened
8. **Screenshots:** (if applicable)
9. **Suggestions:** Improvements or enhancements

### Feedback Submission

**Google Form:** https://forms.gle/UAT-FEEDBACK-FORM  
**Email:** uat-feedback@goldpredictor.com  
**Slack Channel:** #uat-feedback

---

## Acceptance Criteria

### Must Pass (Critical)

- [ ] All authentication scenarios pass
- [ ] All CRUD operations work correctly
- [ ] Predictions generate successfully
- [ ] Alerts trigger correctly
- [ ] No critical bugs
- [ ] No data loss
- [ ] Security features work (CSRF, JWT, account lockout)

### Should Pass (High Priority)

- [ ] Charts display correctly
- [ ] Export functionality works
- [ ] Email notifications sent
- [ ] Mobile responsiveness acceptable
- [ ] Page load times < 3 seconds
- [ ] No high-severity bugs

### Nice to Have (Medium Priority)

- [ ] Advanced filtering works
- [ ] Keyboard shortcuts work
- [ ] Accessibility features work
- [ ] No medium-severity bugs

### UAT Sign-Off

**Criteria for Production Deployment:**
- ✅ 100% of critical scenarios pass
- ✅ 90% of high-priority scenarios pass
- ✅ 80% of medium-priority scenarios pass
- ✅ No critical or high-severity bugs
- ✅ All stakeholders approve

**Sign-Off Form:**

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Product Owner | __________ | __________ | ______ |
| QA Lead | __________ | __________ | ______ |
| Dev Lead | __________ | __________ | ______ |
| Business Analyst | __________ | __________ | ______ |

---

## UAT Schedule

| Day | Date | Activities | Participants |
|-----|------|------------|--------------|
| Day 1 | 2025-01-20 | Authentication & User Management | All |
| Day 2 | 2025-01-21 | Asset Management & Predictions | Traders, Analysts |
| Day 3 | 2025-01-22 | Alerts & Notifications | Traders |
| Day 4 | 2025-01-23 | Charts, Reports & Export | Analysts |
| Day 5 | 2025-01-24 | Performance & Usability | All |
| Day 6 | 2025-01-27 | Bug Fixes & Re-testing | QA Team |
| Day 7 | 2025-01-28 | Final Sign-Off | Stakeholders |

---

## Post-UAT Actions

### If UAT Passes
1. Document all feedback
2. Create backlog for enhancements
3. Schedule production deployment
4. Prepare rollback plan

### If UAT Fails
1. Document all issues
2. Prioritize fixes
3. Fix critical and high-severity bugs
4. Re-run failed scenarios
5. Schedule UAT round 2

---

**Status:** Ready for UAT  
**Last Updated:** 2025-01-18

