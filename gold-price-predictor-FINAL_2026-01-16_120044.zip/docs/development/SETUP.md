# Development Setup

## Prerequisites

- Python 3.11+
- Docker & Docker Compose
- PostgreSQL 14+
- Redis 7+

## Installation

```bash
# Clone repository
git clone https://github.com/hamfarid/gold-price-predictor.git
cd gold-price-predictor

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup environment variables (see README)

# Run migrations
alembic upgrade head

# Start services
docker-compose up -d

# Run application
uvicorn backend.app.main:app --reload
```

## Running Tests

```bash
pytest tests/ -v --cov=backend
```

**Version:** 1.0
