# Contributing Guide
# دليل المساهمة

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Getting Started

1. Fork the repository
2. Clone your fork
3. Create a feature branch
4. Make your changes
5. Run tests
6. Submit a pull request

---

## Code Style

### Python

```python
# Use Black formatter
black backend/

# Use flake8 linter
flake8 backend/

# Use mypy type checker
mypy backend/
```

### Commit Messages

```
feat: Add new prediction model
fix: Fix authentication bug
docs: Update API documentation
test: Add unit tests for auth
refactor: Simplify database queries
```

---

## Pull Request Process

1. Update documentation
2. Add tests for new features
3. Ensure all tests pass
4. Update CHANGELOG.md
5. Request review from maintainers

---

**Document Version:** 1.0
