# دليل استخدام API
# API Usage Guide

---

## 📚 جدول المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [التثبيت والتشغيل](#التثبيت-والتشغيل)
3. [Endpoints](#endpoints)
4. [أمثلة الاستخدام](#أمثلة-الاستخدام)
5. [المصادقة والأمان](#المصادقة-والأمان)
6. [معالجة الأخطاء](#معالجة-الأخطاء)

---

## 🌐 نظرة عامة

Gold Price Predictor API هو REST API مبني على FastAPI يوفر إمكانية التنبؤ بأسعار 13 أصل مالي مختلف بدقة 99%+.

### الميزات الرئيسية

- ✅ **RESTful API** - معيار صناعي
- ✅ **FastAPI** - أداء عالي وسرعة فائقة
- ✅ **OpenAPI/Swagger** - توثيق تلقائي
- ✅ **Pydantic** - التحقق من البيانات
- ✅ **CORS** - دعم الطلبات من مصادر مختلفة
- ✅ **Async** - معالجة متزامنة

### الأصول المدعومة

| الكود | الاسم |
|------|------|
| `gold` | الذهب |
| `btc` | بيتكوين |
| `eth` | إيثيريوم |
| `try_usd` | ليرة تركي/دولار |
| `egp_usd` | جنيه مصري/دولار |

---

## 🚀 التثبيت والتشغيل

### المتطلبات

```bash
pip install fastapi uvicorn pydantic
```

### التشغيل المحلي

```bash
# الطريقة 1: باستخدام Python
cd api
python main.py

# الطريقة 2: باستخدام uvicorn مباشرة
uvicorn api.main:app --reload --host 0.0.0.0 --port 8000
```

### الوصول إلى API

- **API Base URL**: http://localhost:8000
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

---

## 📡 Endpoints

### 1. الصفحة الرئيسية

```http
GET /
```

**الاستجابة:**
```json
{
  "message": "Welcome to Gold Price Predictor API",
  "version": "2.0.0",
  "docs": "/docs",
  "health": "/health",
  "supported_assets": ["gold", "btc", "eth", "try_usd", "egp_usd"]
}
```

---

### 2. فحص الصحة

```http
GET /health
```

**الاستجابة:**
```json
{
  "status": "healthy",
  "timestamp": "2025-10-19T15:00:00",
  "models_loaded": 5,
  "api_version": "2.0.0"
}
```

---

### 3. قائمة الأصول

```http
GET /assets
```

**الاستجابة:**
```json
[
  {
    "code": "gold",
    "name": "Gold",
    "current_price": null,
    "model_accuracy": null,
    "last_updated": null
  },
  {
    "code": "btc",
    "name": "Bitcoin",
    "current_price": null,
    "model_accuracy": null,
    "last_updated": null
  }
]
```

---

### 4. معلومات أصل محدد

```http
GET /assets/{asset}
```

**مثال:**
```http
GET /assets/gold
```

**الاستجابة:**
```json
{
  "code": "gold",
  "name": "Gold",
  "current_price": 4213.30,
  "model_accuracy": 0.9992,
  "last_updated": "2025-10-19T15:00:00"
}
```

---

### 5. التنبؤ بالسعر

```http
POST /predict
```

**الطلب:**
```json
{
  "asset": "gold",
  "features": {
    "Silver_Price": 50.10,
    "Oil_Price": 57.15,
    "SP500": 6664.01,
    "CPI": 237.45,
    "Interest_Rate": 1.24,
    "BTC_Price": 107198.27,
    "ETH_Price": 3890.35,
    "TRY_USD": 0.0293,
    "EGP_USD": 0.0204,
    "EUR_USD": 1.1655,
    "DXY": 98.54
  }
}
```

**الاستجابة:**
```json
{
  "asset": "gold",
  "predicted_price": 4208.96,
  "confidence": 0.95,
  "timestamp": "2025-10-19T15:00:00",
  "model_version": "2.0"
}
```

---

### 6. التنبؤ بأحدث البيانات

```http
GET /predict/{asset}/latest
```

**مثال:**
```http
GET /predict/gold/latest
```

**الاستجابة:**
```json
{
  "asset": "gold",
  "predicted_price": 4208.96,
  "confidence": 0.95,
  "timestamp": "2025-10-19T15:00:00",
  "model_version": "2.0"
}
```

---

### 7. التنبؤ بدفعة

```http
POST /predict/batch
```

**الطلب:**
```json
[
  {
    "asset": "gold",
    "features": {...}
  },
  {
    "asset": "btc",
    "features": {...}
  }
]
```

**الاستجابة:**
```json
[
  {
    "asset": "gold",
    "predicted_price": 4208.96,
    "confidence": 0.95,
    "timestamp": "2025-10-19T15:00:00",
    "model_version": "2.0"
  },
  {
    "asset": "btc",
    "predicted_price": 107278.34,
    "confidence": 0.95,
    "timestamp": "2025-10-19T15:00:00",
    "model_version": "2.0"
  }
]
```

---

### 8. قائمة النماذج

```http
GET /models
```

**الاستجابة:**
```json
[
  {
    "asset": "gold",
    "name": "Gold",
    "status": "loaded",
    "version": "2.0"
  },
  {
    "asset": "btc",
    "name": "Bitcoin",
    "status": "loaded",
    "version": "2.0"
  }
]
```

---

### 9. إعادة تحميل نموذج

```http
POST /models/{asset}/reload
```

**مثال:**
```http
POST /models/gold/reload
```

**الاستجابة:**
```json
{
  "message": "Model for gold reloaded successfully",
  "timestamp": "2025-10-19T15:00:00"
}
```

---

## 💻 أمثلة الاستخدام

### Python

```python
import requests

# Base URL
BASE_URL = "http://localhost:8000"

# 1. فحص الصحة
response = requests.get(f"{BASE_URL}/health")
print(response.json())

# 2. قائمة الأصول
response = requests.get(f"{BASE_URL}/assets")
assets = response.json()
print(f"Supported assets: {len(assets)}")

# 3. التنبؤ بسعر الذهب
data = {
    "asset": "gold",
    "features": {
        "Silver_Price": 50.10,
        "Oil_Price": 57.15,
        "SP500": 6664.01,
        "CPI": 237.45,
        "Interest_Rate": 1.24,
        "BTC_Price": 107198.27,
        "ETH_Price": 3890.35,
        "TRY_USD": 0.0293,
        "EGP_USD": 0.0204,
        "EUR_USD": 1.1655,
        "DXY": 98.54
    }
}

response = requests.post(f"{BASE_URL}/predict", json=data)
result = response.json()

print(f"Predicted price: ${result['predicted_price']:.2f}")
print(f"Confidence: {result['confidence']:.2%}")

# 4. التنبؤ بأحدث البيانات
response = requests.get(f"{BASE_URL}/predict/gold/latest")
result = response.json()
print(f"Latest prediction: ${result['predicted_price']:.2f}")
```

---

### JavaScript (Node.js)

```javascript
const axios = require('axios');

const BASE_URL = 'http://localhost:8000';

// 1. فحص الصحة
async function checkHealth() {
  const response = await axios.get(`${BASE_URL}/health`);
  console.log(response.data);
}

// 2. التنبؤ بسعر الذهب
async function predictGoldPrice() {
  const data = {
    asset: 'gold',
    features: {
      Silver_Price: 50.10,
      Oil_Price: 57.15,
      SP500: 6664.01,
      CPI: 237.45,
      Interest_Rate: 1.24,
      BTC_Price: 107198.27,
      ETH_Price: 3890.35,
      TRY_USD: 0.0293,
      EGP_USD: 0.0204,
      EUR_USD: 1.1655,
      DXY: 98.54
    }
  };
  
  const response = await axios.post(`${BASE_URL}/predict`, data);
  const result = response.data;
  
  console.log(`Predicted price: $${result.predicted_price.toFixed(2)}`);
  console.log(`Confidence: ${(result.confidence * 100).toFixed(2)}%`);
}

// تشغيل
checkHealth();
predictGoldPrice();
```

---

### cURL

```bash
# 1. فحص الصحة
curl http://localhost:8000/health

# 2. قائمة الأصول
curl http://localhost:8000/assets

# 3. التنبؤ بسعر الذهب
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "asset": "gold",
    "features": {
      "Silver_Price": 50.10,
      "Oil_Price": 57.15,
      "SP500": 6664.01,
      "CPI": 237.45,
      "Interest_Rate": 1.24,
      "BTC_Price": 107198.27,
      "ETH_Price": 3890.35,
      "TRY_USD": 0.0293,
      "EGP_USD": 0.0204,
      "EUR_USD": 1.1655,
      "DXY": 98.54
    }
  }'

# 4. التنبؤ بأحدث البيانات
curl http://localhost:8000/predict/gold/latest
```

---

### PHP

```php
<?php

$baseUrl = 'http://localhost:8000';

// 1. فحص الصحة
$response = file_get_contents("$baseUrl/health");
$data = json_decode($response, true);
print_r($data);

// 2. التنبؤ بسعر الذهب
$data = [
    'asset' => 'gold',
    'features' => [
        'Silver_Price' => 50.10,
        'Oil_Price' => 57.15,
        'SP500' => 6664.01,
        'CPI' => 237.45,
        'Interest_Rate' => 1.24,
        'BTC_Price' => 107198.27,
        'ETH_Price' => 3890.35,
        'TRY_USD' => 0.0293,
        'EGP_USD' => 0.0204,
        'EUR_USD' => 1.1655,
        'DXY' => 98.54
    ]
];

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data)
    ]
];

$context  = stream_context_create($options);
$response = file_get_contents("$baseUrl/predict", false, $context);
$result = json_decode($response, true);

echo "Predicted price: $" . number_format($result['predicted_price'], 2) . "\n";
echo "Confidence: " . ($result['confidence'] * 100) . "%\n";

?>
```

---

## 🔐 المصادقة والأمان

### إضافة API Key

```python
# في api/main.py
from fastapi import Security, HTTPException
from fastapi.security.api_key import APIKeyHeader

API_KEY = "your-secret-api-key"
api_key_header = APIKeyHeader(name="X-API-Key")

def get_api_key(api_key: str = Security(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(
            status_code=403,
            detail="Invalid API Key"
        )
    return api_key

# إضافة المصادقة للـ endpoints
@app.post("/predict")
async def predict(
    request: PredictionRequest,
    api_key: str = Depends(get_api_key)
):
    # ... الكود
```

### الاستخدام مع API Key

```python
import requests

headers = {
    "X-API-Key": "your-secret-api-key"
}

response = requests.post(
    "http://localhost:8000/predict",
    json=data,
    headers=headers
)
```

---

## ⚠️ معالجة الأخطاء

### رموز الحالة (Status Codes)

| الكود | المعنى | الوصف |
|------|--------|-------|
| 200 | OK | الطلب نجح |
| 400 | Bad Request | خطأ في البيانات المرسلة |
| 403 | Forbidden | غير مصرح |
| 404 | Not Found | المورد غير موجود |
| 500 | Internal Server Error | خطأ في الخادم |
| 503 | Service Unavailable | الخدمة غير متاحة |

### أمثلة الأخطاء

#### 1. أصل غير مدعوم

```json
{
  "detail": "Asset 'xyz' not supported. Supported assets: ['gold', 'btc', 'eth', 'try_usd', 'egp_usd']"
}
```

#### 2. ميزات مفقودة

```json
{
  "detail": "Missing required features: ['Silver_Price', 'Oil_Price']"
}
```

#### 3. نموذج غير متاح

```json
{
  "detail": "Model for asset 'gold' is not available"
}
```

### معالجة الأخطاء في Python

```python
import requests

try:
    response = requests.post(
        "http://localhost:8000/predict",
        json=data,
        timeout=10
    )
    response.raise_for_status()
    result = response.json()
    print(f"Success: {result}")
    
except requests.exceptions.HTTPError as e:
    print(f"HTTP Error: {e}")
    print(f"Response: {e.response.json()}")
    
except requests.exceptions.ConnectionError:
    print("Connection Error: Could not connect to API")
    
except requests.exceptions.Timeout:
    print("Timeout Error: Request took too long")
    
except Exception as e:
    print(f"Error: {e}")
```

---

## 🚀 النشر (Deployment)

### Docker

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["uvicorn", "api.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
# بناء الصورة
docker build -t gold-price-predictor-api .

# تشغيل الحاوية
docker run -d -p 8000:8000 gold-price-predictor-api
```

### Heroku

```bash
# تسجيل الدخول
heroku login

# إنشاء تطبيق
heroku create gold-price-predictor-api

# نشر
git push heroku main

# فتح التطبيق
heroku open
```

### AWS Lambda

استخدم Mangum لتشغيل FastAPI على AWS Lambda:

```python
from mangum import Mangum

handler = Mangum(app)
```

---

## 📚 الموارد الإضافية

### التوثيق التفاعلي
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### الأدوات الموصى بها
- **Postman**: لاختبار API
- **Insomnia**: بديل لـ Postman
- **HTTPie**: أداة سطر أوامر

---

**آخر تحديث:** 2025-10-19  
**الإصدار:** 2.0.0

