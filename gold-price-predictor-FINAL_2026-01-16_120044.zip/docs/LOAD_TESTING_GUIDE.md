# Load Testing Guide

**Purpose:** Comprehensive load testing for Gold Price Predictor  
**Date:** 2025-01-18  
**Owner:** QA Team

---

## Table of Contents

1. [Overview](#overview)
2. [Test Scenarios](#test-scenarios)
3. [Performance Targets](#performance-targets)
4. [Running Load Tests](#running-load-tests)
5. [Analyzing Results](#analyzing-results)
6. [Optimization](#optimization)

---

## Overview

Load testing ensures the application can handle expected traffic and identifies performance bottlenecks.

**Tools Used:**
- Locust (Python-based load testing)
- k6 (JavaScript-based load testing)
- Apache JMeter (GUI-based load testing)

**Test Environment:** Staging (https://staging-api.goldpredictor.com)

---

## Test Scenarios

### Scenario 1: Normal Load (Baseline)
- **Users:** 100 concurrent users
- **Duration:** 10 minutes
- **Ramp-up:** 10 users/second
- **Purpose:** Establish baseline performance

### Scenario 2: Peak Load
- **Users:** 500 concurrent users
- **Duration:** 15 minutes
- **Ramp-up:** 50 users/second
- **Purpose:** Test peak traffic (e.g., market open)

### Scenario 3: Stress Test
- **Users:** 1000 concurrent users
- **Duration:** 20 minutes
- **Ramp-up:** 100 users/second
- **Purpose:** Find breaking point

### Scenario 4: Spike Test
- **Users:** 0 → 500 → 0 (sudden spike)
- **Duration:** 5 minutes
- **Purpose:** Test auto-scaling and recovery

### Scenario 5: Endurance Test
- **Users:** 200 concurrent users
- **Duration:** 2 hours
- **Purpose:** Test for memory leaks and degradation

---

## Performance Targets

### Response Time (p95)
- **GET requests:** < 200ms
- **POST/PUT/DELETE requests:** < 500ms
- **Predictions (ML):** < 2000ms
- **Database queries:** < 100ms

### Throughput
- **Minimum:** 100 requests/second
- **Target:** 500 requests/second
- **Maximum:** 1000 requests/second

### Error Rate
- **Maximum:** 1% (under normal load)
- **Maximum:** 5% (under stress)

### Resource Usage
- **CPU:** < 70% (normal), < 90% (peak)
- **Memory:** < 80% (normal), < 95% (peak)
- **Database connections:** < 80% of pool

---

## Running Load Tests

### Using Locust (Recommended)

**1. Install Locust**
```bash
pip install locust
```

**2. Run Basic Load Test**
```bash
cd performance
locust -f locustfile.py --host=https://staging-api.goldpredictor.com
```

**3. Open Web UI**
- Navigate to http://localhost:8089
- Set number of users: 100
- Set spawn rate: 10
- Click "Start swarming"

**4. Run Headless (CI/CD)**
```bash
# Normal load test
locust -f locustfile.py \
  --host=https://staging-api.goldpredictor.com \
  --headless \
  --users 100 \
  --spawn-rate 10 \
  --run-time 10m \
  --html report.html \
  --csv results

# Peak load test
locust -f locustfile.py \
  --host=https://staging-api.goldpredictor.com \
  --headless \
  --users 500 \
  --spawn-rate 50 \
  --run-time 15m \
  --html peak-report.html \
  --csv peak-results

# Stress test
locust -f locustfile.py \
  --host=https://staging-api.goldpredictor.com \
  --headless \
  --users 1000 \
  --spawn-rate 100 \
  --run-time 20m \
  --html stress-report.html \
  --csv stress-results
```

### Using k6

**1. Install k6**
```bash
# macOS
brew install k6

# Windows
choco install k6

# Linux
sudo apt-get install k6
```

**2. Create k6 Test Script**

Create `performance/k6-load-test.js`:

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '2m', target: 100 }, // Ramp up to 100 users
    { duration: '5m', target: 100 }, // Stay at 100 users
    { duration: '2m', target: 200 }, // Ramp up to 200 users
    { duration: '5m', target: 200 }, // Stay at 200 users
    { duration: '2m', target: 0 },   // Ramp down to 0 users
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% of requests must complete below 500ms
    http_req_failed: ['rate<0.01'],   // Error rate must be below 1%
  },
};

const BASE_URL = 'https://staging-api.goldpredictor.com';

export default function () {
  // Login
  let loginRes = http.post(`${BASE_URL}/api/auth/login`, JSON.stringify({
    username: 'admin',
    password: 'Admin@123'
  }), {
    headers: { 'Content-Type': 'application/json' },
  });

  check(loginRes, {
    'login successful': (r) => r.status === 200,
  });

  let token = loginRes.json('access_token');

  // Get users list
  let usersRes = http.get(`${BASE_URL}/api/users`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });

  check(usersRes, {
    'users list retrieved': (r) => r.status === 200,
  });

  // Get assets list
  let assetsRes = http.get(`${BASE_URL}/api/assets`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });

  check(assetsRes, {
    'assets list retrieved': (r) => r.status === 200,
  });

  sleep(1);
}
```

**3. Run k6 Test**
```bash
k6 run performance/k6-load-test.js
```

---

## Analyzing Results

### Locust Results

**1. View HTML Report**
```bash
open report.html  # macOS
xdg-open report.html  # Linux
start report.html  # Windows
```

**2. Key Metrics to Check**
- **Total Requests:** Total number of requests made
- **Failures:** Number of failed requests
- **Median Response Time:** 50th percentile
- **95th Percentile:** 95% of requests completed within this time
- **Requests/s:** Throughput
- **Failures/s:** Error rate

**3. CSV Results**
```bash
# View statistics
cat results_stats.csv

# View failures
cat results_failures.csv

# View response time distribution
cat results_stats_history.csv
```

### k6 Results

**1. Console Output**
```
checks.........................: 100.00% ✓ 12000 ✗ 0
data_received..................: 24 MB   40 kB/s
data_sent......................: 12 MB   20 kB/s
http_req_blocked...............: avg=1.2ms   min=0s   med=0s   max=100ms  p(90)=0s   p(95)=0s
http_req_duration..............: avg=150ms   min=50ms med=120ms max=2s     p(90)=250ms p(95)=350ms
http_req_failed................: 0.00%   ✓ 0    ✗ 12000
http_reqs......................: 12000   200/s
```

**2. Export to JSON**
```bash
k6 run --out json=results.json performance/k6-load-test.js
```

---

## Optimization

### If Response Time is High

1. **Add Database Indexes**
```sql
-- Check slow queries
SELECT query, mean_exec_time FROM pg_stat_statements 
ORDER BY mean_exec_time DESC LIMIT 10;

-- Add indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_assets_symbol ON assets(symbol);
```

2. **Enable Caching**
```python
# Add Redis caching for frequently accessed data
@cache.cached(timeout=300, key_prefix='users_list')
def get_users_list():
    return db.query(User).all()
```

3. **Optimize Queries**
```python
# Use select_related to reduce N+1 queries
users = db.query(User).options(
    selectinload(User.predictions),
    selectinload(User.alerts)
).all()
```

### If Error Rate is High

1. **Increase Connection Pool**
```python
# database.py
engine = create_engine(
    DATABASE_URL,
    pool_size=20,  # Increase from 10
    max_overflow=40  # Increase from 20
)
```

2. **Add Rate Limiting**
```python
# Increase rate limits for authenticated users
@limiter.limit("200 per minute")
def get_users():
    pass
```

3. **Enable Auto-Scaling**
```yaml
# k8s/deployment.yaml
spec:
  replicas: 3
  autoscaling:
    minReplicas: 3
    maxReplicas: 10
    targetCPUUtilizationPercentage: 70
```

---

## Load Testing Checklist

- [ ] Baseline test completed (100 users)
- [ ] Peak load test completed (500 users)
- [ ] Stress test completed (1000 users)
- [ ] Spike test completed
- [ ] Endurance test completed (2 hours)
- [ ] Response times within targets
- [ ] Error rate < 1%
- [ ] Resource usage acceptable
- [ ] Database performance acceptable
- [ ] Cache hit rate > 80%
- [ ] Results documented
- [ ] Optimizations applied (if needed)
- [ ] Re-test after optimizations

---

**Status:** Ready for load testing  
**Last Updated:** 2025-01-18

