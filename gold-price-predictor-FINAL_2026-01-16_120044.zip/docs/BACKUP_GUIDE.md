# 📦 Backup & Restore Guide

**Version**: 1.0  
**Created**: 2026-01-15  
**Last Updated**: 2026-01-15  

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Backup Strategy](#backup-strategy)
4. [Daily Backup](#daily-backup)
5. [Restore Procedures](#restore-procedures)
6. [Scheduling](#scheduling)
7. [S3 Integration](#s3-integration)
8. [Monitoring](#monitoring)
9. [Troubleshooting](#troubleshooting)

---

## Overview

The Gold Price Predictor uses a comprehensive backup strategy to ensure data safety:

| Backup Type | Frequency | Retention | RPO | RTO |
|-------------|-----------|-----------|-----|-----|
| Daily Full | Every day at 2 AM | 30 days | 24 hours | 1-2 hours |
| Hourly WAL | Every hour | 7 days | 1 hour | 30 min |

**Key Metrics:**
- **RPO (Recovery Point Objective)**: Maximum 1 hour of data loss
- **RTO (Recovery Time Objective)**: 1-2 hours to full recovery

---

## Quick Start

### Run a Backup Now

**Linux/macOS:**
```bash
cd /path/to/gold-price-predictor
./scripts/backup/backup-daily.sh
```

**Windows PowerShell:**
```powershell
cd D:\Ai_Project\2-gold-price-predictor
.\scripts\backup\backup-daily.ps1
```

### Restore from Backup

**Linux/macOS:**
```bash
./scripts/backup/restore.sh /backups/daily/backup_gold_price_predictor_20260115_020000.dump
```

---

## Backup Strategy

### 1. Full Daily Backups

Full database dumps using `pg_dump` in custom format:

```
/backups/
└── daily/
    ├── backup_gold_price_predictor_20260115_020000.dump
    ├── backup_gold_price_predictor_20260114_020000.dump
    └── ...
```

**Format**: PostgreSQL custom format (`-Fc`)
- Compressed automatically
- Supports selective restore
- Parallel restore capability

### 2. WAL Archiving (Future)

PostgreSQL Write-Ahead Logs for point-in-time recovery:

```
/backups/
└── wal/
    ├── 000000010000000000000001
    ├── 000000010000000000000002
    └── ...
```

---

## Daily Backup

### Configuration

Set environment variables before running:

```bash
# Required
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=gold_price_predictor
export DB_USER=postgres
export DB_PASSWORD=your_password

# Optional
export BACKUP_DIR=/backups
export BACKUP_RETENTION_DAYS=30
export S3_BUCKET=your-backup-bucket
export SLACK_WEBHOOK=https://hooks.slack.com/...
```

### Script Location

```
scripts/backup/
├── backup-daily.sh     # Linux/macOS
├── backup-daily.ps1    # Windows PowerShell
└── restore.sh          # Restore script
```

### Running Manual Backup

```bash
# Full command with all options
DB_HOST=localhost \
DB_PORT=5432 \
DB_NAME=gold_price_predictor \
DB_USER=postgres \
DB_PASSWORD=secret \
BACKUP_DIR=/backups \
./scripts/backup/backup-daily.sh
```

### Backup Output

```
[2026-01-15 02:00:00] ============================================
[2026-01-15 02:00:00] Gold Price Predictor - Daily Backup
[2026-01-15 02:00:00] ============================================
[2026-01-15 02:00:01] Creating backup directory: /backups/daily
[2026-01-15 02:00:01] Starting database backup: gold_price_predictor
[2026-01-15 02:00:01] Backup file: /backups/daily/backup_gold_price_predictor_20260115_020000.dump
[2026-01-15 02:00:15] Backup completed successfully. Size: 45M
[2026-01-15 02:00:16] Verifying backup integrity...
[2026-01-15 02:00:17] Backup verification passed
[2026-01-15 02:00:18] Cleaning up backups older than 30 days
[2026-01-15 02:00:18] Cleanup completed
[2026-01-15 02:00:18] ============================================
[2026-01-15 02:00:18] Backup process completed successfully
[2026-01-15 02:00:18] ============================================
```

---

## Restore Procedures

### Full Restore

```bash
# Interactive restore with confirmation
./scripts/backup/restore.sh /backups/daily/backup_gold_price_predictor_20260115_020000.dump
```

The script will:
1. Verify backup file integrity
2. Ask for confirmation
3. Drop existing database
4. Create fresh database
5. Restore all data
6. Verify restore success

### Selective Restore

Restore only specific tables:

```bash
# List available items in backup
pg_restore -l backup.dump > backup.list

# Edit backup.list to comment out unwanted items
# Then restore with the list
pg_restore -L backup.list -d gold_price_predictor backup.dump
```

### Restore to Different Database

```bash
# Create new database
psql -U postgres -c "CREATE DATABASE gold_price_predictor_test;"

# Restore to test database
pg_restore -d gold_price_predictor_test backup.dump
```

---

## Scheduling

### Linux (Cron)

Edit crontab:
```bash
crontab -e
```

Add daily backup at 2 AM:
```
0 2 * * * /path/to/gold-price-predictor/scripts/backup/backup-daily.sh >> /var/log/backup.log 2>&1
```

### Windows (Task Scheduler)

1. Open Task Scheduler
2. Create Basic Task
3. Trigger: Daily at 2:00 AM
4. Action: Start a program
5. Program: `powershell.exe`
6. Arguments: `-ExecutionPolicy Bypass -File "D:\Ai_Project\2-gold-price-predictor\scripts\backup\backup-daily.ps1"`

### Docker

Add to docker-compose.yml:
```yaml
services:
  backup:
    image: postgres:14-alpine
    environment:
      - DB_HOST=db
      - DB_NAME=gold_price_predictor
      - DB_USER=postgres
      - DB_PASSWORD=${DB_PASSWORD}
      - BACKUP_DIR=/backups
    volumes:
      - ./scripts/backup:/scripts
      - backup_data:/backups
    command: /scripts/backup-daily.sh
    depends_on:
      - db

volumes:
  backup_data:
```

---

## S3 Integration

### Setup

1. Install AWS CLI:
```bash
pip install awscli
aws configure
```

2. Create S3 bucket:
```bash
aws s3 mb s3://gold-predictor-backups
```

3. Set environment variables:
```bash
export S3_BUCKET=gold-predictor-backups
export S3_PREFIX=backups/daily
```

### Lifecycle Policy

Set up automatic transition to Glacier for cost savings:

```json
{
  "Rules": [
    {
      "ID": "Move to Glacier after 30 days",
      "Status": "Enabled",
      "Filter": {
        "Prefix": "backups/"
      },
      "Transitions": [
        {
          "Days": 30,
          "StorageClass": "GLACIER"
        }
      ],
      "Expiration": {
        "Days": 365
      }
    }
  ]
}
```

Apply policy:
```bash
aws s3api put-bucket-lifecycle-configuration \
  --bucket gold-predictor-backups \
  --lifecycle-configuration file://lifecycle.json
```

---

## Monitoring

### Slack Notifications

Set webhook URL:
```bash
export SLACK_WEBHOOK=https://hooks.slack.com/services/xxx/yyy/zzz
```

You'll receive notifications for:
- ✅ Backup completed successfully
- ❌ Backup failed (with error details)

### Log Files

Backup logs are written to stdout. Redirect to file:
```bash
./scripts/backup/backup-daily.sh >> /var/log/gold-predictor-backup.log 2>&1
```

### Health Check

Verify latest backup:
```bash
# Check latest backup file
ls -la /backups/daily/ | tail -5

# Check backup size trend
du -sh /backups/daily/*.dump | tail -10

# Verify backup integrity
pg_restore -l /backups/daily/latest.dump
```

---

## Troubleshooting

### Common Issues

#### 1. Connection refused

```
pg_dump: error: connection to server failed
```

**Solution:**
- Check `DB_HOST` and `DB_PORT`
- Verify PostgreSQL is running
- Check pg_hba.conf allows connections

#### 2. Permission denied

```
pg_dump: error: permission denied
```

**Solution:**
- Check `DB_USER` has backup privileges
- Grant necessary permissions:
```sql
GRANT pg_read_all_data TO backup_user;
```

#### 3. Disk space full

```
pg_dump: error: could not write to file
```

**Solution:**
- Check available space: `df -h`
- Clean up old backups
- Increase disk space

#### 4. Backup file corrupted

```
pg_restore: error: invalid format
```

**Solution:**
- Check disk for errors
- Re-run backup
- Use a different backup file

### Recovery Scenarios

#### Scenario 1: Accidental Data Deletion

1. Identify the most recent backup before deletion
2. Restore to a test database
3. Extract needed data:
```sql
-- On test database
\COPY (SELECT * FROM users WHERE deleted = false) TO '/tmp/users.csv' CSV HEADER;
```
4. Import to production:
```sql
\COPY users FROM '/tmp/users.csv' CSV HEADER;
```

#### Scenario 2: Complete Database Corruption

1. Stop all applications
2. Run full restore:
```bash
./scripts/backup/restore.sh /backups/daily/latest.dump
```
3. Verify data integrity
4. Restart applications

#### Scenario 3: Ransomware/Security Incident

1. Isolate affected systems
2. Restore from S3 (off-site backup):
```bash
aws s3 cp s3://gold-predictor-backups/backups/daily/latest.dump /backups/
./scripts/backup/restore.sh /backups/latest.dump
```
3. Investigate and patch vulnerability

---

## Best Practices

1. **Test restores regularly** - Monthly restore tests to verify backups work
2. **Monitor backup sizes** - Unusual changes may indicate issues
3. **Keep off-site copies** - Always have S3/cloud backups
4. **Document everything** - Keep runbooks updated
5. **Automate notifications** - Never miss a backup failure
6. **Encrypt sensitive data** - Use GPG or AWS KMS for backup encryption

---

## File Reference

| File | Purpose |
|------|---------|
| `scripts/backup/backup-daily.sh` | Linux/macOS backup script |
| `scripts/backup/backup-daily.ps1` | Windows backup script |
| `scripts/backup/restore.sh` | Database restore script |
| `docs/BACKUP_GUIDE.md` | This documentation |

---

**Last verified**: 2026-01-15  
**Maintained by**: DevOps Team  

