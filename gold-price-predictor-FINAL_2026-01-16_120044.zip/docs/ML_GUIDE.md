# دليل Machine Learning الشامل
# Complete Machine Learning Guide

---

## 📚 جدول المحتويات

1. [كيف يعمل Machine Learning](#كيف-يعمل-machine-learning)
2. [دورة حياة النموذج](#دورة-حياة-النموذج)
3. [الحفاظ على النماذج](#الحفاظ-على-النماذج)
4. [المراقبة والتقييم](#المراقبة-والتقييم)
5. [إعادة التدريب](#إعادة-التدريب)
6. [أفضل الممارسات](#أفضل-الممارسات)

---

## 🤖 كيف يعمل Machine Learning

### المفهوم الأساسي

Machine Learning هو عملية تعليم الكمبيوتر للتعلم من البيانات بدلاً من برمجته مباشرة. في مشروعنا، نستخدم ML للتنبؤ بأسعار الأصول المالية.

### العملية الكاملة

```
البيانات الخام → المعالجة → استخراج الميزات → التدريب → النموذج → التنبؤ
```

#### 1. جمع البيانات (Data Collection)

```python
# مثال: جمع بيانات الذهب
from modules.data_collector_extended import collect_all_data

data = collect_all_data()
# النتيجة: 20,000+ نقطة بيانات من 2015-2025
```

**المصادر:**
- Yahoo Finance (أسعار الأصول)
- FRED API (المؤشرات الاقتصادية)
- World Bank (بيانات التضخم)

#### 2. معالجة البيانات (Data Processing)

```python
# مثال: معالجة ودمج البيانات
from modules.data_merger_extended import merge_all_data

merged_data = merge_all_data()
# النتيجة: 2,485 صف × 31 عمود
```

**خطوات المعالجة:**
- تنظيف البيانات (إزالة القيم المفقودة)
- توحيد التواريخ
- دمج المصادر المختلفة
- إنشاء المؤشرات الفنية

#### 3. استخراج الميزات (Feature Engineering)

```python
# المؤشرات الفنية
features = {
    'MA7': المتوسط المتحرك لـ 7 أيام,
    'MA30': المتوسط المتحرك لـ 30 يوم,
    'Volatility': التقلب (الانحراف المعياري),
    'Daily_Change': التغير اليومي,
    'Price_Momentum': زخم السعر
}
```

#### 4. تقسيم البيانات (Data Splitting)

```python
# تقسيم 80/20
train_data = 80% من البيانات (للتدريب)
test_data = 20% من البيانات (للاختبار)
```

#### 5. التدريب (Training)

```python
from sklearn.ensemble import GradientBoostingRegressor

# إنشاء النموذج
model = GradientBoostingRegressor(
    n_estimators=200,
    learning_rate=0.05,
    max_depth=5,
    random_state=42
)

# التدريب
model.fit(X_train, y_train)
```

**الخوارزميات المستخدمة:**
1. **Gradient Boosting** - الأفضل (دقة 99%+)
2. **Random Forest** - جيد جداً (دقة 99%+)
3. **SVR** - جيد (دقة 95%+)

#### 6. التقييم (Evaluation)

```python
from sklearn.metrics import r2_score, mean_squared_error

# التنبؤ
predictions = model.predict(X_test)

# التقييم
r2 = r2_score(y_test, predictions)
rmse = mean_squared_error(y_test, predictions, squared=False)

print(f"R² Score: {r2:.4f}")  # مثال: 0.9992 (99.92%)
print(f"RMSE: {rmse:.2f}")    # مثال: 15.30
```

**مقاييس الأداء:**
- **R² Score**: مدى توافق التنبؤات مع البيانات الفعلية (0-1، الأعلى أفضل)
- **RMSE**: متوسط الخطأ (الأقل أفضل)
- **MAE**: متوسط الخطأ المطلق (الأقل أفضل)

#### 7. الحفظ (Saving)

```python
import joblib

# حفظ النموذج
joblib.dump(model, 'models/by_asset/gold/best_model.pkl')
joblib.dump(scaler, 'models/by_asset/gold/scaler.pkl')
joblib.dump(features, 'models/by_asset/gold/feature_names.pkl')
```

#### 8. التنبؤ (Prediction)

```python
# تحميل النموذج
model = joblib.load('models/by_asset/gold/best_model.pkl')
scaler = joblib.load('models/by_asset/gold/scaler.pkl')

# إعداد البيانات
new_data = {
    'Silver_Price': 50.10,
    'Oil_Price': 57.15,
    # ... باقي الميزات
}

# التنبؤ
predicted_price = model.predict(scaled_data)
print(f"السعر المتوقع: ${predicted_price[0]:.2f}")
```

---

## 🔄 دورة حياة النموذج

### المراحل الأساسية

```
1. التطوير → 2. التدريب → 3. التقييم → 4. النشر → 5. المراقبة → 6. إعادة التدريب
     ↑                                                                            ↓
     └────────────────────────────────────────────────────────────────────────────┘
```

### 1. مرحلة التطوير (Development)

**المدة:** 1-2 أسبوع

**المهام:**
- جمع البيانات
- استكشاف البيانات (EDA)
- اختيار الميزات
- تجربة خوارزميات مختلفة

**الأدوات:**
- Jupyter Notebook
- pandas, numpy
- matplotlib, seaborn

### 2. مرحلة التدريب (Training)

**المدة:** 1-3 ساعات (حسب حجم البيانات)

**المهام:**
- تدريب النماذج المختلفة
- ضبط المعاملات (Hyperparameter Tuning)
- اختيار أفضل نموذج

**الكود:**
```python
from modules.model_trainer_extended import train_all_models

# تدريب جميع النماذج
results = train_all_models()

# اختيار الأفضل
best_model = max(results, key=lambda x: x['r2_score'])
```

### 3. مرحلة التقييم (Evaluation)

**المدة:** 1-2 ساعة

**المهام:**
- اختبار النموذج على بيانات جديدة
- حساب مقاييس الأداء
- تحليل الأخطاء

**الكود:**
```python
from modules.model_evaluator import evaluate_model

# تقييم النموذج
metrics = evaluate_model(model, test_data)

print(f"R²: {metrics['r2']:.4f}")
print(f"RMSE: {metrics['rmse']:.2f}")
print(f"MAE: {metrics['mae']:.2f}")
```

### 4. مرحلة النشر (Deployment)

**المدة:** 1-2 يوم

**المهام:**
- حفظ النموذج
- إنشاء API
- اختبار الإنتاج

**الكود:**
```python
# حفظ النموذج للإنتاج
import joblib

joblib.dump(model, 'models/production/gold_model.pkl')
```

### 5. مرحلة المراقبة (Monitoring)

**المدة:** مستمرة

**المهام:**
- مراقبة الأداء
- تتبع الأخطاء
- جمع البيانات الجديدة

**الكود:**
```python
from modules.model_monitor import ModelMonitor

monitor = ModelMonitor('gold')
monitor.track_prediction(actual, predicted)
monitor.check_performance()
```

### 6. مرحلة إعادة التدريب (Retraining)

**المدة:** 1-3 ساعات

**التكرار:** أسبوعياً أو شهرياً

**المهام:**
- جمع بيانات جديدة
- إعادة تدريب النموذج
- مقارنة الأداء

---

## 🛡️ الحفاظ على النماذج

### 1. نظام التحكم في الإصدارات (Versioning)

```python
# هيكل المجلدات
models/
├── production/
│   ├── gold_v1.0.pkl      # النموذج الحالي
│   ├── gold_v1.1.pkl      # النموذج الجديد
│   └── metadata.json      # معلومات الإصدارات
├── archive/
│   ├── gold_v0.9.pkl      # نماذج قديمة
│   └── gold_v0.8.pkl
└── experiments/
    └── gold_test_*.pkl    # نماذج تجريبية
```

**ملف metadata.json:**
```json
{
  "model_name": "gold_v1.0",
  "version": "1.0",
  "created_at": "2025-10-19",
  "accuracy": {
    "r2_score": 0.9992,
    "rmse": 15.30,
    "mae": 10.96
  },
  "training_data": {
    "start_date": "2015-11-30",
    "end_date": "2025-10-17",
    "samples": 2485
  },
  "features": ["Silver_Price", "Oil_Price", ...],
  "status": "production"
}
```

### 2. النسخ الاحتياطي (Backup)

```python
import shutil
from datetime import datetime

def backup_model(model_name):
    """نسخ احتياطي للنموذج"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    source = f'models/production/{model_name}.pkl'
    backup = f'models/backup/{model_name}_{timestamp}.pkl'
    
    shutil.copy(source, backup)
    print(f"تم النسخ الاحتياطي: {backup}")

# استخدام
backup_model('gold_model')
```

**جدول النسخ الاحتياطي:**
- يومياً: نسخ تلقائي
- أسبوعياً: نسخ يدوي
- شهرياً: أرشفة كاملة

### 3. التحقق من الصحة (Validation)

```python
def validate_model(model_path):
    """التحقق من صحة النموذج"""
    try:
        # تحميل النموذج
        model = joblib.load(model_path)
        
        # اختبار التنبؤ
        test_data = np.random.rand(1, 10)
        prediction = model.predict(test_data)
        
        # التحقق من النتيجة
        assert prediction is not None
        assert not np.isnan(prediction).any()
        
        print("✅ النموذج صحيح")
        return True
        
    except Exception as e:
        print(f"❌ خطأ في النموذج: {e}")
        return False

# استخدام
validate_model('models/production/gold_model.pkl')
```

### 4. الحماية من التلف (Corruption Protection)

```python
import hashlib

def calculate_checksum(file_path):
    """حساب checksum للملف"""
    with open(file_path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def verify_model_integrity(model_path, expected_checksum):
    """التحقق من سلامة النموذج"""
    actual_checksum = calculate_checksum(model_path)
    
    if actual_checksum == expected_checksum:
        print("✅ النموذج سليم")
        return True
    else:
        print("❌ النموذج تالف!")
        return False

# حفظ checksum
checksum = calculate_checksum('models/production/gold_model.pkl')
with open('models/production/gold_model.checksum', 'w') as f:
    f.write(checksum)

# التحقق لاحقاً
with open('models/production/gold_model.checksum', 'r') as f:
    expected = f.read()
verify_model_integrity('models/production/gold_model.pkl', expected)
```

---

## 📊 المراقبة والتقييم

### 1. مراقبة الأداء (Performance Monitoring)

```python
class ModelMonitor:
    """نظام مراقبة النماذج"""
    
    def __init__(self, model_name):
        self.model_name = model_name
        self.predictions = []
        self.actuals = []
        
    def track_prediction(self, actual, predicted):
        """تتبع التنبؤات"""
        self.actuals.append(actual)
        self.predictions.append(predicted)
        
        # حفظ في قاعدة البيانات
        self.save_to_db(actual, predicted)
        
    def calculate_metrics(self):
        """حساب المقاييس"""
        from sklearn.metrics import r2_score, mean_squared_error
        
        r2 = r2_score(self.actuals, self.predictions)
        rmse = mean_squared_error(self.actuals, self.predictions, squared=False)
        
        return {'r2': r2, 'rmse': rmse}
        
    def check_performance(self, threshold=0.95):
        """التحقق من الأداء"""
        metrics = self.calculate_metrics()
        
        if metrics['r2'] < threshold:
            print(f"⚠️ تحذير: الأداء منخفض (R²={metrics['r2']:.4f})")
            self.send_alert()
            return False
        
        print(f"✅ الأداء جيد (R²={metrics['r2']:.4f})")
        return True
        
    def send_alert(self):
        """إرسال تنبيه"""
        # إرسال بريد إلكتروني أو إشعار
        pass
```

### 2. تتبع الانحراف (Drift Detection)

```python
def detect_data_drift(current_data, training_data):
    """كشف الانحراف في البيانات"""
    from scipy.stats import ks_2samp
    
    drifts = {}
    
    for column in current_data.columns:
        # اختبار Kolmogorov-Smirnov
        statistic, p_value = ks_2samp(
            training_data[column],
            current_data[column]
        )
        
        if p_value < 0.05:
            drifts[column] = {
                'statistic': statistic,
                'p_value': p_value,
                'status': 'drift_detected'
            }
    
    if drifts:
        print(f"⚠️ تم اكتشاف انحراف في {len(drifts)} ميزة")
        return drifts
    else:
        print("✅ لا يوجد انحراف")
        return None
```

### 3. لوحة المراقبة (Dashboard)

```python
import matplotlib.pyplot as plt

def create_monitoring_dashboard(monitor):
    """إنشاء لوحة مراقبة"""
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # 1. الأداء عبر الزمن
    axes[0, 0].plot(monitor.get_r2_over_time())
    axes[0, 0].set_title('R² Score Over Time')
    axes[0, 0].axhline(y=0.95, color='r', linestyle='--')
    
    # 2. توزيع الأخطاء
    errors = np.array(monitor.actuals) - np.array(monitor.predictions)
    axes[0, 1].hist(errors, bins=50)
    axes[0, 1].set_title('Error Distribution')
    
    # 3. التنبؤات مقابل القيم الفعلية
    axes[1, 0].scatter(monitor.actuals, monitor.predictions, alpha=0.5)
    axes[1, 0].plot([min(monitor.actuals), max(monitor.actuals)],
                    [min(monitor.actuals), max(monitor.actuals)], 'r--')
    axes[1, 0].set_title('Predictions vs Actuals')
    
    # 4. عدد التنبؤات اليومية
    axes[1, 1].bar(range(len(monitor.daily_counts)), monitor.daily_counts)
    axes[1, 1].set_title('Daily Prediction Count')
    
    plt.tight_layout()
    plt.savefig('monitoring_dashboard.png')
    print("✅ تم إنشاء لوحة المراقبة")
```

---

## 🔄 إعادة التدريب

### 1. متى يجب إعادة التدريب؟

**المؤشرات:**
- ✅ انخفاض الأداء (R² < 0.95)
- ✅ اكتشاف انحراف في البيانات
- ✅ مرور فترة زمنية (أسبوع/شهر)
- ✅ توفر بيانات جديدة كافية (>100 نقطة)

### 2. عملية إعادة التدريب

```python
def retrain_model(model_name, force=False):
    """إعادة تدريب النموذج"""
    
    # 1. التحقق من الحاجة لإعادة التدريب
    if not force:
        monitor = ModelMonitor(model_name)
        if monitor.check_performance(threshold=0.95):
            print("✅ الأداء جيد، لا حاجة لإعادة التدريب")
            return
    
    print("🔄 بدء إعادة التدريب...")
    
    # 2. جمع البيانات الجديدة
    new_data = collect_latest_data()
    
    # 3. دمج مع البيانات القديمة
    all_data = merge_old_and_new_data(new_data)
    
    # 4. إعادة التدريب
    new_model = train_model(all_data)
    
    # 5. التقييم
    metrics = evaluate_model(new_model, test_data)
    
    # 6. المقارنة مع النموذج القديم
    old_model = load_model(f'models/production/{model_name}.pkl')
    old_metrics = evaluate_model(old_model, test_data)
    
    if metrics['r2'] > old_metrics['r2']:
        print(f"✅ النموذج الجديد أفضل (R²: {metrics['r2']:.4f} vs {old_metrics['r2']:.4f})")
        
        # 7. نسخ احتياطي للنموذج القديم
        backup_model(model_name)
        
        # 8. نشر النموذج الجديد
        deploy_model(new_model, model_name)
    else:
        print(f"⚠️ النموذج القديم أفضل، لن يتم التحديث")

# جدولة إعادة التدريب الأسبوعية
import schedule

schedule.every().sunday.at("02:00").do(retrain_model, 'gold')
```

### 3. التدريب المتزايد (Incremental Learning)

```python
from sklearn.linear_model import SGDRegressor

class IncrementalModel:
    """نموذج يدعم التعلم المتزايد"""
    
    def __init__(self):
        self.model = SGDRegressor()
        self.is_fitted = False
        
    def partial_fit(self, X, y):
        """تدريب على دفعة جديدة"""
        if not self.is_fitted:
            self.model.partial_fit(X, y)
            self.is_fitted = True
        else:
            self.model.partial_fit(X, y)
            
    def update_with_new_data(self, new_data):
        """تحديث بالبيانات الجديدة"""
        X, y = prepare_data(new_data)
        self.partial_fit(X, y)
        print(f"✅ تم التحديث بـ {len(X)} نقطة بيانات جديدة")
```

---

## ✅ أفضل الممارسات

### 1. إدارة البيانات

```python
# ✅ جيد: حفظ البيانات مع timestamp
data.to_csv(f'data/raw/gold_{datetime.now().strftime("%Y%m%d")}.csv')

# ❌ سيء: الكتابة فوق البيانات القديمة
data.to_csv('data/raw/gold.csv')
```

### 2. التوثيق

```python
# ✅ جيد: توثيق شامل
def train_model(data, target, **params):
    """
    تدريب نموذج Gradient Boosting
    
    Args:
        data: DataFrame يحتوي على الميزات
        target: اسم العمود المستهدف
        **params: معاملات النموذج
        
    Returns:
        model: النموذج المدرب
        metrics: مقاييس الأداء
        
    Example:
        >>> model, metrics = train_model(df, 'Gold_Price')
        >>> print(metrics['r2'])
        0.9992
    """
    pass

# ❌ سيء: بدون توثيق
def train(d, t):
    pass
```

### 3. الاختبار

```python
import pytest

def test_model_prediction():
    """اختبار التنبؤ"""
    model = load_model('gold')
    test_data = create_test_data()
    
    prediction = model.predict(test_data)
    
    assert prediction is not None
    assert len(prediction) == len(test_data)
    assert not np.isnan(prediction).any()
    assert prediction[0] > 0  # السعر يجب أن يكون موجباً

def test_model_performance():
    """اختبار الأداء"""
    model = load_model('gold')
    test_data, test_labels = load_test_data()
    
    predictions = model.predict(test_data)
    r2 = r2_score(test_labels, predictions)
    
    assert r2 > 0.95  # الدقة يجب أن تكون أعلى من 95%
```

### 4. الأمان

```python
# ✅ جيد: التحقق من المدخلات
def predict_price(model, data):
    """التنبؤ بالسعر مع التحقق"""
    # التحقق من نوع البيانات
    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a DataFrame")
    
    # التحقق من الأعمدة المطلوبة
    required_features = model.feature_names_
    missing = set(required_features) - set(data.columns)
    if missing:
        raise ValueError(f"Missing features: {missing}")
    
    # التحقق من القيم
    if data.isnull().any().any():
        raise ValueError("Data contains null values")
    
    # التنبؤ
    return model.predict(data)

# ❌ سيء: بدون تحقق
def predict(m, d):
    return m.predict(d)
```

### 5. الأداء

```python
# ✅ جيد: استخدام vectorization
import numpy as np

def calculate_moving_average_vectorized(prices, window=7):
    """حساب المتوسط المتحرك (سريع)"""
    return np.convolve(prices, np.ones(window)/window, mode='valid')

# ❌ سيء: استخدام loops
def calculate_moving_average_slow(prices, window=7):
    """حساب المتوسط المتحرك (بطيء)"""
    result = []
    for i in range(len(prices) - window + 1):
        result.append(sum(prices[i:i+window]) / window)
    return result
```

---

## 📚 المراجع والموارد

### كتب موصى بها
1. **Hands-On Machine Learning** - Aurélien Géron
2. **The Hundred-Page Machine Learning Book** - Andriy Burkov
3. **Machine Learning Yearning** - Andrew Ng

### دورات مجانية
1. **Coursera**: Machine Learning by Andrew Ng
2. **Fast.ai**: Practical Deep Learning
3. **Kaggle Learn**: ML courses

### أدوات مفيدة
1. **MLflow**: تتبع التجارب
2. **Weights & Biases**: مراقبة النماذج
3. **TensorBoard**: تصور التدريب

---

**آخر تحديث:** 2025-10-19  
**الإصدار:** 1.0

