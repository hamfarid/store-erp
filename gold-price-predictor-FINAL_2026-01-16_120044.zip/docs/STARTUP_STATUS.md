# حالة بدء النظام - Startup Status

**التاريخ**: 2025-01-27  
**الحالة**: ✅ **جميع الخدمات تعمل**

---

## ✅ الخدمات النشطة

### 🐳 الحاويات (Docker Containers)

| الخدمة | الحالة | المنفذ | الوصول |
|--------|--------|--------|---------|
| **Backend (FastAPI)** | ✅ Healthy | `2005` | `http://localhost:2005` |
| **PostgreSQL** | ✅ Healthy | `4510` | `localhost:4510` |
| **Redis** | ✅ Healthy | `2605` | `localhost:2605` |
| **ML Service** | ✅ Healthy | `2105` | `http://localhost:2105` |
| **Grafana** | ✅ Healthy | `3001` | `http://localhost:3001` |
| **Prometheus** | ✅ Healthy | `9090` | `http://localhost:9090` |

### 🚀 السيرفر (Node.js + tRPC)

- **المنفذ**: `2505`
- **الحالة**: ✅ **يعمل**
- **الوصول**: `http://localhost:2505`
- **API**: `http://localhost:2505/api/trpc`
- **WebSocket**: `ws://localhost:2505/ws`

---

## 📊 الوصول إلى الخدمات

### الواجهة الرئيسية
```
http://localhost:2505
```

### Backend API
```
http://localhost:2005
http://localhost:2005/health
http://localhost:2005/docs (Swagger)
```

### المراقبة
```
Grafana: http://localhost:3001
  - المستخدم: admin
  - كلمة المرور: admin123

Prometheus: http://localhost:9090
```

### ML Service
```
http://localhost:2105
http://localhost:2105/health
```

---

## ⚠️ ملاحظات

1. **Frontend Container**: فشل البناء بسبب `tsconfig.json`، لكن السيرفر يعمل في وضع التطوير
2. **Portainer**: لم يبدأ بعد (فشل بسبب Frontend build)

---

## 🔧 الأوامر المفيدة

### عرض حالة الحاويات
```bash
docker compose -f docker-compose.production.yml ps
```

### عرض Logs
```bash
docker compose -f docker-compose.production.yml logs -f [service-name]
```

### إيقاف الحاويات
```bash
docker compose -f docker-compose.production.yml down
```

### إعادة تشغيل خدمة
```bash
docker compose -f docker-compose.production.yml restart [service-name]
```

---

**آخر تحديث**: 2025-01-27

