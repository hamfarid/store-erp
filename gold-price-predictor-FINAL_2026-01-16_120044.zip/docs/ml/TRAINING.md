# Model Training Guide
# دليل تدريب النماذج

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Training Schedule

**Frequency:** Weekly (every Sunday at 2:00 AM UTC)

---

## Training Process

### 1. Data Collection

```python
# Collect last 5 years of data
start_date = datetime.now() - timedelta(days=5*365)
end_date = datetime.now()

data = fetch_gold_prices(start_date, end_date)
```

### 2. Data Preprocessing

```python
# Clean data
data = remove_outliers(data)
data = fill_missing_values(data)

# Normalize
scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data)
```

### 3. Feature Engineering

```python
# Create features
features = create_features(data_scaled)
# - Lagged values (1-60 days)
# - Moving averages (7, 14, 30 days)
# - RSI, MACD, Bollinger Bands
```

### 4. Train-Test Split

```python
train_size = int(len(data) * 0.8)
train_data = data[:train_size]
test_data = data[train_size:]
```

### 5. Model Training

```python
# Train all 8 models
for model_name in ['arima', 'lstm', 'xgboost', ...]:
    model = train_model(model_name, train_data)
    save_model(model, f'models/{model_name}.pkl')
```

### 6. Evaluation

```python
# Evaluate on test set
for model in models:
    predictions = model.predict(test_data)
    accuracy = calculate_accuracy(predictions, test_data)
    print(f"{model.name}: {accuracy:.2%}")
```

---

## Hyperparameter Tuning

### Grid Search

```python
from sklearn.model_selection import GridSearchCV

param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, 30],
    'learning_rate': [0.01, 0.1, 0.3]
}

grid_search = GridSearchCV(
    XGBRegressor(),
    param_grid,
    cv=5,
    scoring='neg_mean_squared_error'
)

grid_search.fit(X_train, y_train)
best_params = grid_search.best_params_
```

---

**Document Version:** 1.0
