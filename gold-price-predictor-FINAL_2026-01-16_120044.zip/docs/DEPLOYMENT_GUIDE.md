# Deployment Guide - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/DEPLOYMENT_GUIDE.md | **PURPOSE**: Complete deployment guide for all environments | **OWNER**: DevOps Team | **RELATED**: ARCHITECTURE.md, Security.md, TESTING_STRATEGY.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Deployment Strategy**: Blue-Green  
**Target RTO**: <1 hour  
**Target RPO**: <15 minutes

---

## Table of Contents
1. [Deployment Overview](#1-deployment-overview)
2. [Prerequisites](#2-prerequisites)
3. [Local Development Setup](#3-local-development-setup)
4. [Docker Deployment](#4-docker-deployment)
5. [Kubernetes Deployment](#5-kubernetes-deployment)
6. [Environment Configuration](#6-environment-configuration)
7. [Database Migration](#7-database-migration)
8. [Blue-Green Deployment](#8-blue-green-deployment)
9. [Scaling Strategies](#9-scaling-strategies)
10. [Monitoring & Logging](#10-monitoring--logging)
11. [Backup & Disaster Recovery](#11-backup--disaster-recovery)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Deployment Overview

### 1.1 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        PRODUCTION                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────┐      ┌──────────────────┐                    │
│  │  CDN     │──────│  Load Balancer   │                    │
│  │ (Static) │      │   (NGINX/ALB)    │                    │
│  └──────────┘      └────────┬─────────┘                    │
│                              │                               │
│               ┌──────────────┴──────────────┐               │
│               │                             │               │
│        ┌──────▼──────┐             ┌───────▼─────┐         │
│        │  Blue Env   │             │  Green Env  │         │
│        ├─────────────┤             ├─────────────┤         │
│        │ Frontend x3 │             │ Frontend x3 │         │
│        │ Backend x4  │             │ Backend x4  │         │
│        │ tRPC x2     │             │ tRPC x2     │         │
│        └─────────────┘             └─────────────┘         │
│                                                              │
│        ┌─────────────────────────────────────┐             │
│        │         Data Layer                   │             │
│        ├──────────┬──────────┬───────────────┤             │
│        │PostgreSQL│  Redis   │ ML Models     │             │
│        │  (RDS)   │ (Elastic │ (S3/EFS)      │             │
│        │ Primary  │  Cache)  │               │             │
│        │ + Replica│          │               │             │
│        └──────────┴──────────┴───────────────┘             │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Deployment Environments

| Environment | Purpose | Auto-Deploy | Approval |
|-------------|---------|-------------|----------|
| **Local** | Development | N/A | N/A |
| **Docker** | Local integration | Manual | Developer |
| **Staging** | Pre-production testing | ✅ Auto (on merge to main) | QA Team |
| **Production** | Live system | ❌ Manual | Tech Lead + PM |

### 1.3 Deployment Frequency

- **Staging**: Multiple times per day (CI/CD)
- **Production**: Weekly (planned) + Hotfixes (as needed)
- **Rollback Time**: <5 minutes (blue-green switch)

---

## 2. Prerequisites

### 2.1 Required Software

**Development**:
- Python 3.11+ (with pip)
- Node.js 22+ (with npm/pnpm)
- Git 2.30+
- VS Code (recommended)

**Production**:
- Docker 24.0+
- Docker Compose 2.20+
- Kubernetes 1.28+ (kubectl)
- Helm 3.12+
- PostgreSQL 15+
- Redis 7+

### 2.2 Required Accounts & Access

- **AWS/GCP/Azure**: Cloud provider account
- **GitHub**: Repository access (SSH key configured)
- **Docker Hub/ECR**: Container registry
- **Secrets Manager**: AWS Secrets Manager / Vault
- **Monitoring**: Prometheus, Grafana, Sentry

### 2.3 Hardware Requirements

**Local Development**:
- CPU: 4+ cores
- RAM: 16 GB
- Disk: 50 GB free

**Production (per node)**:
- CPU: 8+ cores (16 recommended)
- RAM: 32 GB (64 GB recommended)
- Disk: 500 GB SSD
- Network: 10 Gbps

---

## 3. Local Development Setup

### 3.1 Clone Repository

```bash
# Clone via SSH (recommended)
git clone git@github.com:your-org/gold-price-predictor.git
cd gold-price-predictor

# Or via HTTPS
git clone https://github.com/your-org/gold-price-predictor.git
cd gold-price-predictor
```

### 3.2 Backend Setup (Python)

```powershell
# Create virtual environment
python -m venv .venv311

# Activate virtual environment (Windows)
.\.venv311\Scripts\Activate.ps1

# Install dependencies
pip install -r backend/app/requirements-dev.txt

# Configure environment
Copy-Item .env.example .env
# Edit .env with your settings (PostgreSQL, Redis URLs)

# Initialize database
alembic upgrade head

# Run development server
python backend/wsgi.py
# Server runs at http://localhost:2005
```

### 3.3 Frontend Setup (Node.js)

```bash
# Install dependencies
cd client
npm install
# or
pnpm install

# Configure environment
cp .env.example .env.local
# Edit .env.local with API URL

# Run development server
npm run dev
# Server runs at http://localhost:2505
```

### 3.4 tRPC Server Setup

```bash
# Install dependencies (from project root)
npm install

# Run tRPC server
npm run dev
# Server runs at http://localhost:5000
```

### 3.5 Verify Setup

```bash
# Test backend health
curl http://localhost:2005/api/health

# Test tRPC health
curl http://localhost:5000/health

# Test frontend (open browser)
# Navigate to http://localhost:2505
```

---

## 4. Docker Deployment

### 4.1 Docker Compose (Local/Dev)

**File**: `docker-compose.yml`

```yaml
version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: gold-predictor-db
    environment:
      POSTGRES_USER: golduser
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: goldpredictor
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backend/app/migrations:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U golduser"]
      interval: 10s
      timeout: 5s
      retries: 5
  
  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: gold-predictor-redis
    command: redis-server --requirepass ${REDIS_PASSWORD}
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
  
  # FastAPI Backend
  backend:
    build:
      context: .
      dockerfile: backend/Dockerfile
    container_name: gold-predictor-api
    environment:
      DATABASE_URL: postgresql://golduser:${DB_PASSWORD}@postgres:5432/goldpredictor
      REDIS_URL: redis://:${REDIS_PASSWORD}@redis:6379/0
      SECRET_KEY: ${SECRET_KEY}
      JWT_SECRET_KEY: ${JWT_SECRET_KEY}
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./ml_models:/app/ml_models
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:2005/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
  
  # tRPC Server
  trpc-server:
    build:
      context: .
      dockerfile: server/Dockerfile
    container_name: gold-predictor-trpc
    environment:
      DATABASE_URL: file:/app/data/app.db
      API_BASE_URL: http://backend:2005
    ports:
      - "5000:5000"
    depends_on:
      - backend
    volumes:
      - ./data:/app/data
  
  # React Frontend
  frontend:
    build:
      context: .
      dockerfile: client/Dockerfile
    container_name: gold-predictor-frontend
    environment:
      VITE_API_URL: http://localhost:2005
      VITE_TRPC_URL: http://localhost:5000
    ports:
      - "5173:80"
    depends_on:
      - backend
      - trpc-server

volumes:
  postgres_data:
  redis_data:
```

### 4.2 Backend Dockerfile (Multi-Stage)

**File**: `backend/Dockerfile`

```dockerfile
# Stage 1: Builder
FROM python:3.11-slim as builder

WORKDIR /app

# Install build dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    g++ \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY backend/app/requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim

WORKDIR /app

# Install runtime dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    libpq5 \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Copy Python packages from builder
COPY --from=builder /root/.local /root/.local
ENV PATH=/root/.local/bin:$PATH

# Create non-root user
RUN useradd -m -u 1000 appuser && \
    chown -R appuser:appuser /app

# Copy application code
COPY --chown=appuser:appuser backend/app /app
COPY --chown=appuser:appuser ml_models /app/ml_models

# Switch to non-root user
USER appuser

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
  CMD curl -f http://localhost:2005/api/health || exit 1

# Run application
CMD ["gunicorn", "main:app", \
     "--workers", "4", \
     "--worker-class", "uvicorn.workers.UvicornWorker", \
     "--bind", "0.0.0.0:8000", \
     "--access-logfile", "-", \
     "--error-logfile", "-"]
```

### 4.3 Frontend Dockerfile (NGINX)

**File**: `client/Dockerfile`

```dockerfile
# Stage 1: Build
FROM node:22-alpine as builder

WORKDIR /app

# Copy package files
COPY client/package*.json ./
RUN npm ci

# Copy source code
COPY client/ .

# Build production bundle
RUN npm run build

# Stage 2: NGINX
FROM nginx:1.25-alpine

# Copy build output
COPY --from=builder /app/dist /usr/share/nginx/html

# Copy NGINX configuration
COPY client/nginx.conf /etc/nginx/conf.d/default.conf

# Security: run as non-root
RUN chown -R nginx:nginx /usr/share/nginx/html && \
    chmod -R 755 /usr/share/nginx/html

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

### 4.4 Running with Docker Compose

```bash
# Build and start all services
docker-compose up -d --build

# View logs
docker-compose logs -f

# Stop all services
docker-compose down

# Stop and remove volumes (data wipe)
docker-compose down -v
```

---

## 5. Kubernetes Deployment

### 5.1 Namespace

**File**: `k8s/namespace.yaml`

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: gold-predictor
  labels:
    name: gold-predictor
    environment: production
```

### 5.2 ConfigMap

**File**: `k8s/configmap.yaml`

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: gold-predictor-config
  namespace: gold-predictor
data:
  API_PORT: "8000"
  TRPC_PORT: "5000"
  LOG_LEVEL: "info"
  REDIS_HOST: "redis-service"
  REDIS_PORT: "6379"
  POSTGRES_HOST: "postgres-service"
  POSTGRES_PORT: "5432"
  POSTGRES_DB: "goldpredictor"
```

### 5.3 Secrets (Sealed Secrets)

**File**: `k8s/secrets.yaml`

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: gold-predictor-secrets
  namespace: gold-predictor
type: Opaque
data:
  SECRET_KEY: <base64-encoded>
  JWT_SECRET_KEY: <base64-encoded>
  DB_PASSWORD: <base64-encoded>
  REDIS_PASSWORD: <base64-encoded>
```

**Create Secret**:
```bash
kubectl create secret generic gold-predictor-secrets \
  --from-literal=SECRET_KEY='your-secret-key' \
  --from-literal=JWT_SECRET_KEY='your-jwt-secret' \
  --from-literal=DB_PASSWORD='your-db-password' \
  --from-literal=REDIS_PASSWORD='your-redis-password' \
  --namespace=gold-predictor
```

### 5.4 Backend Deployment

**File**: `k8s/backend-deployment.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  namespace: gold-predictor
  labels:
    app: backend
    version: v3.0.0
spec:
  replicas: 4
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
        version: v3.0.0
    spec:
      containers:
      - name: backend
        image: your-registry/gold-predictor-backend:v3.0.0
        ports:
        - containerPort: 8000
          name: http
        env:
        - name: DATABASE_URL
          value: "postgresql://$(POSTGRES_USER):$(DB_PASSWORD)@$(POSTGRES_HOST):$(POSTGRES_PORT)/$(POSTGRES_DB)"
        - name: REDIS_URL
          value: "redis://:$(REDIS_PASSWORD)@$(REDIS_HOST):$(REDIS_PORT)/0"
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: gold-predictor-secrets
              key: SECRET_KEY
        - name: JWT_SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: gold-predictor-secrets
              key: JWT_SECRET_KEY
        envFrom:
        - configMapRef:
            name: gold-predictor-config
        resources:
          requests:
            cpu: "500m"
            memory: "1Gi"
          limits:
            cpu: "2000m"
            memory: "4Gi"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /api/health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 2
        volumeMounts:
        - name: ml-models
          mountPath: /app/ml_models
          readOnly: true
      volumes:
      - name: ml-models
        persistentVolumeClaim:
          claimName: ml-models-pvc
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000
```

### 5.5 Backend Service

**File**: `k8s/backend-service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: backend-service
  namespace: gold-predictor
  labels:
    app: backend
spec:
  type: ClusterIP
  ports:
  - port: 8000
    targetPort: 8000
    protocol: TCP
    name: http
  selector:
    app: backend
```

### 5.6 Horizontal Pod Autoscaler

**File**: `k8s/backend-hpa.yaml`

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: backend-hpa
  namespace: gold-predictor
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: backend
  minReplicas: 4
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 0
      policies:
      - type: Percent
        value: 100
        periodSeconds: 30
      - type: Pods
        value: 4
        periodSeconds: 30
      selectPolicy: Max
```

### 5.7 Ingress (NGINX)

**File**: `k8s/ingress.yaml`

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: gold-predictor-ingress
  namespace: gold-predictor
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - api.goldpredictor.com
    - app.goldpredictor.com
    secretName: gold-predictor-tls
  rules:
  - host: api.goldpredictor.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: backend-service
            port:
              number: 8000
  - host: app.goldpredictor.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: frontend-service
            port:
              number: 80
```

### 5.8 Deploy to Kubernetes

```bash
# Create namespace
kubectl apply -f k8s/namespace.yaml

# Apply ConfigMap and Secrets
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secrets.yaml

# Deploy backend
kubectl apply -f k8s/backend-deployment.yaml
kubectl apply -f k8s/backend-service.yaml
kubectl apply -f k8s/backend-hpa.yaml

# Deploy frontend
kubectl apply -f k8s/frontend-deployment.yaml
kubectl apply -f k8s/frontend-service.yaml

# Deploy Ingress
kubectl apply -f k8s/ingress.yaml

# Verify deployments
kubectl get all -n gold-predictor

# Check pod status
kubectl get pods -n gold-predictor -w

# View logs
kubectl logs -f deployment/backend -n gold-predictor
```

---

## 6. Environment Configuration

### 6.1 Environment Variables (.env)

**Backend** (`.env`):
```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/goldpredictor
POSTGRES_USER=golduser
POSTGRES_PASSWORD=secure_password
POSTGRES_DB=goldpredictor

# Redis
REDIS_URL=redis://:redis_password@localhost:6379/0
REDIS_PASSWORD=redis_password

# Security
SECRET_KEY=your-secret-key-min-32-chars
JWT_SECRET_KEY=your-jwt-secret-key-min-32-chars
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=15
JWT_REFRESH_TOKEN_EXPIRE_DAYS=7

# API Keys
YFINANCE_API_KEY=your-yfinance-key
ALPHA_VANTAGE_API_KEY=your-alpha-vantage-key

# Features
REDIS_ENABLED=true
RATE_LIMITING_ENABLED=true
AUDIT_LOGGING_ENABLED=true

# Monitoring
SENTRY_DSN=https://your-sentry-dsn
LOG_LEVEL=info
```

**Frontend** (`.env.local`):
```bash
VITE_API_URL=http://localhost:2005
VITE_TRPC_URL=http://localhost:5000
VITE_ENVIRONMENT=development
```

### 6.2 Environment-Specific Settings

| Variable | Development | Staging | Production |
|----------|-------------|---------|------------|
| **LOG_LEVEL** | debug | info | warning |
| **DATABASE_URL** | SQLite | PostgreSQL (RDS) | PostgreSQL (RDS) |
| **REDIS_ENABLED** | false | true | true |
| **SENTRY_DSN** | - | staging-dsn | prod-dsn |
| **CORS_ORIGINS** | * | staging.com | goldpredictor.com |

---

## 7. Database Migration

### 7.1 Alembic Migration (Backend)

```bash
# Create migration
cd backend/app
alembic revision --autogenerate -m "Add new table"

# Apply migration (local)
alembic upgrade head

# Apply migration (production)
kubectl exec -it deployment/backend -n gold-predictor -- \
  alembic upgrade head

# Rollback migration
alembic downgrade -1
```

### 7.2 Drizzle Migration (tRPC)

```bash
# Generate migration
npm run db:generate

# Apply migration
npm run db:migrate

# Push schema (dev only)
npm run db:push
```

---

## 8. Blue-Green Deployment

### 8.1 Strategy

```
┌─────────────────────────────────────┐
│       Load Balancer (NGINX)         │
│  (Routes 100% traffic to active)    │
└──────────┬──────────────────────────┘
           │
    ┌──────┴──────┐
    │             │
┌───▼────┐   ┌───▼────┐
│ Blue   │   │ Green  │
│ (v3.0) │   │ (v3.1) │
│ ACTIVE │   │ STANDBY│
└────────┘   └────────┘
```

### 8.2 Deployment Steps

**Step 1: Deploy to Green (Standby)**
```bash
# Update green deployment
kubectl set image deployment/backend-green \
  backend=your-registry/gold-predictor-backend:v3.1.0 \
  -n gold-predictor

# Wait for green to be ready
kubectl rollout status deployment/backend-green -n gold-predictor
```

**Step 2: Run Smoke Tests**
```bash
# Test green endpoint (internal)
kubectl port-forward deployment/backend-green 8001:8000 -n gold-predictor
curl http://localhost:8001/api/health

# Run E2E tests against green
BACKEND_URL=http://localhost:8001 npm run test:e2e
```

**Step 3: Switch Traffic to Green**
```bash
# Update service selector to green
kubectl patch service backend-service \
  -p '{"spec":{"selector":{"version":"v3.1.0"}}}' \
  -n gold-predictor
```

**Step 4: Monitor**
```bash
# Monitor metrics for 15 minutes
# Check error rate, latency, throughput
```

**Step 5: Rollback (if needed)**
```bash
# Revert service selector to blue
kubectl patch service backend-service \
  -p '{"spec":{"selector":{"version":"v3.0.0"}}}' \
  -n gold-predictor
```

---

## 9. Scaling Strategies

### 9.1 Horizontal Scaling (HPA)

**Metrics**:
- CPU: >70% → scale up
- Memory: >80% → scale up
- Request rate: >1000 req/s → scale up

**Configuration** (see Section 5.6)

### 9.2 Vertical Scaling

**Resource Adjustment**:
```yaml
resources:
  requests:
    cpu: "1000m"  # Increased from 500m
    memory: "2Gi" # Increased from 1Gi
  limits:
    cpu: "4000m"  # Increased from 2000m
    memory: "8Gi" # Increased from 4Gi
```

### 9.3 Database Scaling

**Read Replicas**:
```yaml
# PostgreSQL StatefulSet with replica
replicas: 3  # 1 primary + 2 read replicas

# Application connection pooling
SQLALCHEMY_POOL_SIZE=20
SQLALCHEMY_MAX_OVERFLOW=10
```

---

## 10. Monitoring & Logging

### 10.1 Prometheus Metrics

**Expose Metrics**:
```python
# backend/app/main.py
from prometheus_fastapi_instrumentator import Instrumentator

@app.on_event("startup")
async def startup():
    Instrumentator().instrument(app).expose(app)
```

**Prometheus Configuration**:
```yaml
# k8s/prometheus-config.yaml
scrape_configs:
  - job_name: 'gold-predictor-backend'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
            - gold-predictor
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_label_app]
        action: keep
        regex: backend
```

### 10.2 Grafana Dashboards

**Import Dashboard**:
- Dashboard ID: 12227 (FastAPI)
- Custom: See `monitoring/grafana-dashboard.json`

---

## 11. Backup & Disaster Recovery

### 11.1 Database Backup

**Automated Backup (PostgreSQL)**:
```bash
# CronJob for daily backups
apiVersion: batch/v1
kind: CronJob
metadata:
  name: postgres-backup
  namespace: gold-predictor
spec:
  schedule: "0 3 * * *"  # 3 AM daily
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: backup
            image: postgres:15-alpine
            command:
            - /bin/sh
            - -c
            - |
              pg_dump -h postgres-service -U golduser goldpredictor | \
              gzip > /backup/goldpredictor-$(date +%Y%m%d).sql.gz
            volumeMounts:
            - name: backup
              mountPath: /backup
          volumes:
          - name: backup
            persistentVolumeClaim:
              claimName: backup-pvc
          restartPolicy: OnFailure
```

### 11.2 Disaster Recovery

**RTO**: <1 hour  
**RPO**: <15 minutes

**Recovery Steps**:
1. Provision new infrastructure (Terraform)
2. Restore database from latest backup
3. Deploy application (Helm charts)
4. Switch DNS to new environment

---

## 12. Troubleshooting

### 12.1 Common Issues

**Issue**: Backend pods crashing
```bash
# Check logs
kubectl logs -f deployment/backend -n gold-predictor

# Check events
kubectl describe pod <pod-name> -n gold-predictor

# Common causes:
# - Database connection failed: Check DATABASE_URL
# - Out of memory: Increase resources
# - Missing secrets: Check secret exists
```

**Issue**: High latency
```bash
# Check HPA status
kubectl get hpa -n gold-predictor

# Check resource usage
kubectl top pods -n gold-predictor

# Check database connections
# - Connection pool exhausted: Increase SQLALCHEMY_POOL_SIZE
```

**Issue**: 502 Bad Gateway
```bash
# Check ingress
kubectl describe ingress gold-predictor-ingress -n gold-predictor

# Check backend service
kubectl get endpoints backend-service -n gold-predictor

# Verify pods are ready
kubectl get pods -n gold-predictor | grep Running
```

---

**Last Updated**: 2025-11-17  
**Next Review**: 2026-02-17  
**Version**: 3.0.0  
**Owner**: DevOps Team
