# Authentication Guide
# دليل المصادقة

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Overview

النظام يستخدم **JWT (JSON Web Tokens)** مع **2FA (Two-Factor Authentication)** لتوفير أمان متعدد الطبقات.

---

## Authentication Flow

### 1. Registration

```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "full_name": "John Doe"
}
```

**Response:**
```json
{
  "user_id": "uuid",
  "email": "user@example.com",
  "created_at": "2025-10-28T10:00:00Z"
}
```

### 2. Login

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "token_type": "bearer",
  "expires_in": 86400
}
```

### 3. Using Access Token

```http
GET /api/v1/predictions
Authorization: Bearer eyJhbGc...
```

---

## 2FA Setup

### Enable 2FA

```http
POST /api/v1/auth/2fa/setup
Authorization: Bearer eyJhbGc...
```

**Response:**
```json
{
  "secret": "JBSWY3DPEHPK3PXP",
  "qr_code": "data:image/png;base64,...",
  "backup_codes": ["12345678", "87654321"]
}
```

### Verify 2FA

```http
POST /api/v1/auth/2fa/verify
Authorization: Bearer eyJhbGc...
Content-Type: application/json

{
  "code": "123456"
}
```

---

## Token Refresh

```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGc..."
}
```

**Response:**
```json
{
  "access_token": "eyJhbGc...",
  "token_type": "bearer",
  "expires_in": 86400
}
```

---

## Security Features

- **Password Hashing:** bcrypt with salt
- **JWT Expiration:** 24 hours
- **Refresh Token:** 30 days
- **Rate Limiting:** 5 attempts per minute
- **2FA:** TOTP (Time-based One-Time Password)
- **Blacklist:** Redis-based JWT blacklist

---

**Document Version:** 1.0
