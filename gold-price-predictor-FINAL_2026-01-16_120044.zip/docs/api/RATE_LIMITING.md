# Rate Limiting
# تحديد معدل الطلبات

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Rate Limits

### Default Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| /api/v1/auth/login | 5 req | 1 min |
| /api/v1/auth/register | 3 req | 1 hour |
| /api/v1/predictions | 100 req | 1 min |
| /api/v1/* (general) | 1000 req | 1 hour |

### Premium Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| /api/v1/predictions | 500 req | 1 min |
| /api/v1/* (general) | 10000 req | 1 hour |

---

## Rate Limit Headers

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1635427200
```

---

## Error Response

```json
{
  "status": "error",
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests",
    "retry_after": 60
  }
}
```

---

**Document Version:** 1.0
