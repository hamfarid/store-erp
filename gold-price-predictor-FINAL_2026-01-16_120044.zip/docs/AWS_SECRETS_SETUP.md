# AWS Secrets Manager Setup Guide

## Overview

The Gold Price Predictor application now uses AWS Secrets Manager for secure secret storage in production environments. This guide explains how to set up and use AWS Secrets Manager.

---

## Prerequisites

- AWS account with admin access
- AWS CLI installed and configured
- Python 3.9+ with boto3
- Current `.env` file with secrets

---

## Step 1: Install Dependencies

```bash
# Install boto3 (AWS SDK for Python)
pip install boto3

# Or add to requirements.txt
echo "boto3>=1.28.0" >> requirements.txt
pip install -r requirements.txt
```

---

## Step 2: Configure AWS CLI

```bash
# Install AWS CLI (if not installed)
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure credentials
aws configure

# Enter:
# - AWS Access Key ID
# - AWS Secret Access Key
# - Default region (e.g., us-east-1)
# - Default output format (json)

# Verify configuration
aws sts get-caller-identity
```

---

## Step 3: Create Secrets in AWS Secrets Manager

### 3.1 Create Secrets via AWS CLI

```bash
# Create SECRET_KEY
aws secretsmanager create-secret \
  --name gold-predictor/SECRET_KEY \
  --description "JWT secret key for Gold Price Predictor" \
  --secret-string "your-secret-key-here"

# Create DATABASE_URL
aws secretsmanager create-secret \
  --name gold-predictor/DATABASE_URL \
  --description "PostgreSQL database connection string" \
  --secret-string "postgresql://user:password@host:5432/dbname"

# Create REDIS_URL
aws secretsmanager create-secret \
  --name gold-predictor/REDIS_URL \
  --description "Redis connection string" \
  --secret-string "redis://localhost:6379/0"

# Create NEWS_API_KEY
aws secretsmanager create-secret \
  --name gold-predictor/NEWS_API_KEY \
  --description "News API key" \
  --secret-string "your-news-api-key"

# Create FRED_API_KEY
aws secretsmanager create-secret \
  --name gold-predictor/FRED_API_KEY \
  --description "FRED API key" \
  --secret-string "your-fred-api-key"
```

### 3.2 Verify Secrets

```bash
# List all secrets
aws secretsmanager list-secrets

# Get specific secret
aws secretsmanager get-secret-value \
  --secret-id gold-predictor/SECRET_KEY \
  --query SecretString \
  --output text
```

---

## Step 4: Configure Application

### 4.1 Set Environment Variables

```bash
# Set environment to production
export ENVIRONMENT=production

# Set AWS region
export AWS_REGION=us-east-1

# Set secrets backend
export SECRETS_BACKEND=aws
```

### 4.2 Update .env File (for production)

```bash
# .env.production
ENVIRONMENT=production
SECRETS_BACKEND=aws
AWS_REGION=us-east-1

# AWS credentials (use IAM role in production)
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key
```

---

## Step 5: IAM Permissions

### 5.1 Create IAM Policy

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret"
      ],
      "Resource": "arn:aws:secretsmanager:us-east-1:*:secret:gold-predictor/*"
    }
  ]
}
```

### 5.2 Attach Policy to IAM Role

```bash
# Create policy
aws iam create-policy \
  --policy-name GoldPredictorSecretsRead \
  --policy-document file://secrets-policy.json

# Attach to role (for EC2/ECS)
aws iam attach-role-policy \
  --role-name GoldPredictorAppRole \
  --policy-arn arn:aws:iam::ACCOUNT_ID:policy/GoldPredictorSecretsRead
```

---

## Step 6: Testing

### 6.1 Test Locally

```python
# test_secrets.py
from services.secrets_manager import get_secret

# Test secret retrieval
secret_key = get_secret("SECRET_KEY")
print(f"SECRET_KEY retrieved: {secret_key[:10]}...")

database_url = get_secret("DATABASE_URL")
print(f"DATABASE_URL retrieved: {database_url[:20]}...")
```

```bash
# Run test
python test_secrets.py
```

### 6.2 Test in Production

```bash
# Set environment
export ENVIRONMENT=production

# Start application
python backend/app/main.py

# Check logs for:
# "AWS Secrets Manager backend initialized: us-east-1"
```

---

## Security Best Practices

1. **Never commit secrets to Git**
   - Add `.env*` to `.gitignore`
   - Use AWS Secrets Manager in production

2. **Use IAM roles instead of access keys**
   - For EC2: attach IAM role to instance
   - For ECS: attach IAM role to task
   - For Lambda: attach IAM role to function

3. **Rotate secrets regularly**
   - Use AWS Secrets Manager rotation (90 days)
   - Update application to handle rotation

4. **Audit secret access**
   - Enable CloudTrail logging
   - Monitor secret access patterns

5. **Use least privilege**
   - Only grant `GetSecretValue` permission
   - Restrict to specific secret ARNs

---

## Troubleshooting

### Error: "boto3 library not installed"

```bash
pip install boto3
```

### Error: "AWS credentials not found"

```bash
# Configure AWS CLI
aws configure

# Or set environment variables
export AWS_ACCESS_KEY_ID=your-key
export AWS_SECRET_ACCESS_KEY=your-secret
```

### Error: "Secret not found"

```bash
# Verify secret exists
aws secretsmanager list-secrets

# Check secret name format
# Should be: gold-predictor/SECRET_KEY
```

### Fallback to Environment Variables

If AWS Secrets Manager is unavailable, the application automatically falls back to environment variables from `.env` file.

---

## Cost Estimation

AWS Secrets Manager pricing (as of 2025):
- $0.40 per secret per month
- $0.05 per 10,000 API calls

For 5 secrets with moderate usage:
- Monthly cost: ~$2-3

---

## Next Steps

1. ✅ Install boto3
2. ✅ Configure AWS CLI
3. ✅ Create secrets in AWS Secrets Manager
4. ✅ Set environment variables
5. ✅ Test secret retrieval
6. ✅ Deploy to production

---

**Last Updated:** 2025-01-18
**Owner:** Security Team
**Related:** `backend/app/services/secrets_manager.py`, `backend/app/config_secure.py`

