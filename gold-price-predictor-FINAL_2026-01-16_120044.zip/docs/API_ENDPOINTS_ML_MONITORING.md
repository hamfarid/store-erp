# FILE: docs/API_ENDPOINTS_ML_MONITORING.md | PURPOSE: Quick reference for new ML and monitoring endpoints | OWNER: API Team | LAST-AUDITED: 2025-11-21

# ML & Monitoring API Endpoints Quick Reference

## 🤖 ML Prediction Endpoints

### Base URL: `/api/ml`

---

### 1. GET `/api/ml/`

**Get ML API Information**

**Authentication**: Not required  
**Response**:

```json
{
  "success": true,
  "api": "Gold Price Predictor ML API",
  "version": "3.0.0",
  "models": ["LSTM", "GRU", "Transformer", "Ensemble"],
  "available_assets": ["GOLD", "SILVER", "BTC", "ETH", "EUR", "JPY"],
  "endpoints": {...}
}
```

---

### 2. POST `/api/ml/predict`

**Single Prediction**

**Authentication**: Required (JWT token)  
**Request Body**:

```json
{
  "asset": "GOLD",
  "features": [1950.5, 1948.3, 1952.1, ...],
  "model_type": "ensemble"
}
```

**Response**:

```json
{
  "success": true,
  "asset": "GOLD",
  "prediction": 1975.2,
  "confidence": 0.95,
  "model_type": "ensemble",
  "timestamp": "2025-11-21T12:00:00Z"
}
```

**Model Types**:

- `lstm` - LSTM model (98.5% accuracy)
- `gru` - GRU model (98.2% accuracy)
- `transformer` - Transformer model (98.8% accuracy)
- `ensemble` - Ensemble model (99.03% accuracy) **[RECOMMENDED]**

---

### 3. POST `/api/ml/predict/batch`

**Batch Predictions**

**Authentication**: Required  
**Request Body**:

```json
{
  "asset": "GOLD",
  "features_list": [
    [1950.5, 1948.3, ...],
    [1952.1, 1950.0, ...],
    [1954.5, 1953.2, ...]
  ],
  "model_type": "ensemble"
}
```

**Response**:

```json
{
  "success": true,
  "asset": "GOLD",
  "predictions": [1975.2, 1978.5, 1980.1],
  "model_type": "ensemble",
  "timestamp": "2025-11-21T12:00:00Z"
}
```

---

### 4. POST `/api/ml/predict/future`

**Multi-Day Forecast**

**Authentication**: Required  
**Request Body**:

```json
{
  "asset": "GOLD",
  "last_sequence": [
    [1950.5, 1948.3, ...],
    [1952.1, 1950.0, ...],
    ...
  ],
  "n_days": 7,
  "model_type": "ensemble"
}
```

**Parameters**:

- `n_days`: 1-30 (number of days to predict)

**Response**:

```json
{
  "success": true,
  "asset": "GOLD",
  "predictions": [
    {"day": 1, "prediction": 1975.20},
    {"day": 2, "prediction": 1978.50},
    {"day": 3, "prediction": 1980.10},
    ...
  ],
  "model_type": "ensemble",
  "timestamp": "2025-11-21T12:00:00Z"
}
```

---

### 5. GET `/api/ml/models`

**Get All Models Information**

**Authentication**: Not required  
**Response**:

```json
{
  "success": true,
  "models": {
    "lstm": {
      "name": "LSTM (Long Short-Term Memory)",
      "type": "Deep Learning",
      "description": "Recurrent neural network for time series prediction",
      "accuracy": "High",
      "speed": "Medium"
    },
    "gru": {...},
    "transformer": {...},
    "ensemble": {
      "name": "Ensemble Model",
      "type": "Meta Model",
      "description": "Combines LSTM (40%), GRU (30%), Transformer (30%)",
      "accuracy": "Highest (99.03%)",
      "speed": "Slow",
      "recommended": true
    }
  },
  "available_assets": ["GOLD", "SILVER", "BTC", "ETH", "EUR", "JPY"],
  "capabilities": {
    "single_prediction": true,
    "batch_prediction": true,
    "future_forecast": true,
    "max_forecast_days": 30
  }
}
```

---

### 6. GET `/api/ml/models/{asset}`

**Get Asset-Specific Model Info**

**Authentication**: Not required  
**Parameters**:

- `asset`: Asset symbol (GOLD, SILVER, BTC, ETH, EUR, JPY)

**Example**: `GET /api/ml/models/GOLD`

**Response**:

```json
{
  "success": true,
  "asset": "GOLD",
  "models_available": ["lstm", "gru", "transformer", "ensemble"],
  "recommended_model": "ensemble",
  "model_status": {
    "lstm": "trained",
    "gru": "trained",
    "transformer": "trained",
    "ensemble": "trained"
  },
  "last_trained": "2025-11-01T00:00:00Z",
  "accuracy": {
    "lstm": "98.5%",
    "gru": "98.2%",
    "transformer": "98.8%",
    "ensemble": "99.03%"
  }
}
```

---

## 📊 Monitoring Endpoints

### Base URL: `/api`

---

### 1. GET `/api/health`

**Basic Health Check**

**Authentication**: Not required  
**Use Case**: Load balancer health check

**Response**:

```json
{
  "status": "healthy",
  "timestamp": "2025-11-21T12:00:00Z",
  "service": "Gold Price Predictor API"
}
```

**HTTP Status Codes**:

- `200 OK` - Service is healthy
- `503 Service Unavailable` - Service is down

---

### 2. GET `/api/ready`

**Readiness Check**

**Authentication**: Not required  
**Use Case**: Kubernetes readiness probe

**Response**:

```json
{
  "status": "ready",
  "timestamp": "2025-11-21T12:00:00Z",
  "checks": {
    "database": {
      "status": "ready",
      "message": "PostgreSQL connected"
    },
    "redis": {
      "status": "ready",
      "message": "Redis connected"
    }
  }
}
```

**Status Values**:

- `ready` - All dependencies available
- `not_ready` - One or more dependencies unavailable

---

### 3. GET `/api/metrics`

**System Metrics**

**Authentication**: Not required (can be restricted)  
**Use Case**: Prometheus scraping, monitoring dashboards

**Response**:

```json
{
  "timestamp": "2025-11-21T12:00:00Z",
  "cpu": {
    "percent": 45.2,
    "count": 8
  },
  "memory": {
    "total_mb": 16384.0,
    "available_mb": 8192.0,
    "used_mb": 8192.0,
    "percent": 50.0
  },
  "disk": {
    "total_gb": 500.0,
    "used_gb": 250.0,
    "free_gb": 250.0,
    "percent": 50.0
  },
  "application": {
    "uptime_seconds": 3600.0,
    "total_requests": 1000,
    "successful_requests": 950,
    "failed_requests": 50,
    "success_rate": 95.0
  }
}
```

---

### 4. GET `/api/stats`

**Application Statistics**

**Authentication**: Required (Admin only)  
**Use Case**: Admin dashboard, reporting

**Response**:

```json
{
  "timestamp": "2025-11-21T12:00:00Z",
  "statistics": {
    "total_users": 150,
    "active_api_keys": 75,
    "predictions_24h": 1250,
    "audit_logs_24h": 5000
  }
}
```

**Error Response** (non-admin):

```json
{
  "success": false,
  "message": "Admin access required"
}
```

---

### 5. GET `/api/logs`

**Recent Audit Logs**

**Authentication**: Required (Admin only)  
**Query Parameters**:

- `limit` (optional): Number of logs to return (default: 50)

**Example**: `GET /api/logs?limit=100`

**Response**:

```json
{
  "timestamp": "2025-11-21T12:00:00Z",
  "count": 50,
  "logs": [
    {
      "id": 1234,
      "event_type": "login",
      "username": "john_doe",
      "success": true,
      "timestamp": "2025-11-21T11:59:00Z",
      "details": {...}
    },
    ...
  ]
}
```

---

## 🚨 Error Responses

### 404 Not Found

**Browser Request**: Beautiful HTML error page  
**API Request**:

```json
{
  "success": false,
  "code": "NOT_FOUND",
  "message": "المورد المطلوب غير موجود",
  "details": {
    "path": "/api/nonexistent",
    "method": "GET"
  },
  "timestamp": "2025-11-21T12:00:00Z"
}
```

---

### 500 Internal Server Error

**Browser Request**: Beautiful HTML error page  
**API Request**:

```json
{
  "success": false,
  "code": "INTERNAL_SERVER_ERROR",
  "message": "حدث خطأ غير متوقع في الخادم",
  "details": {
    "error_type": "ValueError",
    "timestamp": "2025-11-21T12:00:00Z"
  },
  "timestamp": "2025-11-21T12:00:00Z"
}
```

---

### 422 Validation Error

```json
{
  "success": false,
  "code": "VALIDATION_ERROR",
  "message": "خطأ في التحقق من البيانات",
  "details": {
    "errors": [
      {
        "loc": ["body", "asset"],
        "msg": "field required",
        "type": "value_error.missing"
      }
    ],
    "body": {...}
  },
  "timestamp": "2025-11-21T12:00:00Z"
}
```

---

## 🔐 Authentication

All ML prediction endpoints require JWT authentication.

**Headers**:

```
Authorization: Bearer <access_token>
```

**Get Token**:

```bash
POST /api/token
Content-Type: application/x-www-form-urlencoded

username=john_doe&password=secure_password
```

**Response**:

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer"
}
```

---

## 📝 Usage Examples

### Python Example (ML Prediction)

```python
import requests

# Login
token_response = requests.post(
    "http://localhost:2005/api/token",
    data={"username": "john_doe", "password": "password"}
)
access_token = token_response.json()["access_token"]

# Make prediction
headers = {"Authorization": f"Bearer {access_token}"}
prediction_response = requests.post(
    "http://localhost:2005/api/ml/predict",
    json={
        "asset": "GOLD",
        "features": [1950.5, 1948.3, 1952.1, ...],
        "model_type": "ensemble"
    },
    headers=headers
)

prediction = prediction_response.json()
print(f"Predicted price: ${prediction['prediction']:.2f}")
```

### cURL Example (Health Check)

```bash
# Health check
curl http://localhost:2005/api/health

# System metrics
curl http://localhost:2005/api/metrics

# Logs (admin)
curl -H "Authorization: Bearer <token>" \
     http://localhost:2005/api/logs?limit=10
```

### JavaScript Example (Batch Prediction)

```javascript
// Get token
const tokenResponse = await fetch('http://localhost:2005/api/token', {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  body: 'username=john_doe&password=password'
});
const { access_token } = await tokenResponse.json();

// Batch prediction
const predictionResponse = await fetch('http://localhost:2005/api/ml/predict/batch', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${access_token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    asset: 'GOLD',
    features_list: [
      [1950.5, 1948.3, ...],
      [1952.1, 1950.0, ...]
    ],
    model_type: 'ensemble'
  })
});

const predictions = await predictionResponse.json();
console.log(predictions);
```

---

## 🎯 Best Practices

1. **Always use Ensemble model** for highest accuracy (99.03%)
2. **Use batch predictions** when predicting multiple data points
3. **Monitor `/api/health`** for service availability
4. **Check `/api/metrics`** for performance issues
5. **Use admin endpoints** only when necessary (security)
6. **Handle errors gracefully** (all endpoints return structured errors)
7. **Cache predictions** if making repeated requests for same data
8. **Rate limit** your requests (100 req/min default)

---

## 📚 Additional Resources

- **Full API Documentation**: http://localhost:2005/api/docs
- **ReDoc**: http://localhost:2005/api/redoc
- **Implementation Status**: `docs/IMPLEMENTATION_STATUS_PHASE13.md`
- **OSF Framework**: `docs/GLOBAL_GUIDELINES.md`

---

**Document Version**: 1.0  
**Last Updated**: 2025-11-21  
**API Version**: 3.0.0
