# Database Schema Documentation

**Project:** Gold Price Predictor  
**Last Updated:** 2025-01-18  
**Database Type:** MySQL (with SQLite fallback)

---

## Overview

The project uses **Drizzle ORM** with support for both **MySQL** and **SQLite** databases. The database type is determined by the `DATABASE_URL` environment variable:
- If `DATABASE_URL` starts with `file:`, SQLite is used
- Otherwise, MySQL/TiDB is used

---

## Schema Files

The database schema is organized into multiple files:

1. `drizzle/schema.ts` - Core schema (users, assets, predictions, alerts, historicalPrices)
2. `drizzle/schema-learning-control.ts` - **NEW** Learning & Search Control Dashboard tables
3. `drizzle/schema-logs.ts` - Logging tables (errorLogs, mlTrainingLogs, predictionLogs, apiRequestLogs)
4. `drizzle/schema-notifications.ts` - Notifications system
5. `drizzle/schema-trading.ts` - Trading signals and breakout points
6. `drizzle/schema-permissions.ts` - Permissions and user permissions
7. `drizzle/schema-ai.ts` - AI assistants and conversations
8. `drizzle/schema-ai-tasks.ts` - AI scheduled tasks
9. `drizzle/schema-portfolio.ts` - Portfolio management
10. `drizzle/schema-enhancements.ts` - Enhanced features (notifications, activity logs, risk profiles)
11. `drizzle/schema-learning.ts` - Learning path optimization (SQLite)
12. `drizzle/schema-drift.ts` - Drift detection (SQLite)
13. `drizzle/schema-opinions.ts` - Expert opinions (SQLite)
14. `drizzle/schema-email.ts` - Email settings

---

## Learning Control Schema (NEW)

### Tables Overview

The Learning Control Dashboard uses 5 new tables for managing learning operations and search functionality:

1. **search_keywords** - Manages search keywords with categories and priorities
2. **search_sources** - Manages search sources (engines, news sites, APIs)
3. **learning_operations** - Tracks learning operations (prediction comparison, pattern detection, etc.)
4. **search_operations** - Tracks search operations (keyword search, event discovery, etc.)
5. **operation_logs** - Logs for all operations

---

### Table: search_keywords

**Purpose:** Stores search keywords used for event discovery and news scraping

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier |
| keyword | VARCHAR(255) | NOT NULL, UNIQUE | The search keyword |
| category | ENUM | NOT NULL | Category: political, economic, geopolitical, monetary_policy, market, commodity, general |
| priority | ENUM | DEFAULT 'medium' | Priority: low, medium, high, critical |
| enabled | BOOLEAN | DEFAULT TRUE | Whether keyword is active |
| search_count | INT | DEFAULT 0 | Number of times used |
| last_used | TIMESTAMP | NULL | Last usage timestamp |
| results_found | INT | DEFAULT 0 | Total results found |
| created_by | VARCHAR(64) | NULL | User who created it |
| created_at | TIMESTAMP | DEFAULT NOW | Creation timestamp |
| updated_at | TIMESTAMP | DEFAULT NOW, ON UPDATE NOW | Last update timestamp |

**Indexes:**
- `idx_category` on `category`
- `idx_priority` on `priority`
- `idx_enabled` on `enabled`

---

### Table: search_sources

**Purpose:** Stores search sources (search engines, news sites, APIs) with performance metrics

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier |
| name | VARCHAR(255) | NOT NULL | Source name |
| type | ENUM | NOT NULL | Type: search_engine, news_site, financial_site, government_site, social_media, api |
| url | TEXT | NOT NULL | Source URL |
| enabled | BOOLEAN | DEFAULT TRUE | Whether source is active |
| config | JSON | NULL | Source-specific configuration |
| headers | JSON | NULL | HTTP headers for requests |
| rate_limit | INT | DEFAULT 60 | Requests per minute limit |
| request_count | INT | DEFAULT 0 | Total requests made |
| success_count | INT | DEFAULT 0 | Successful requests |
| error_count | INT | DEFAULT 0 | Failed requests |
| last_used | TIMESTAMP | NULL | Last usage timestamp |
| last_error | TEXT | NULL | Last error message |
| avg_response_time | INT | NULL | Average response time (ms) |
| reliability | INT | DEFAULT 100 | Reliability percentage (0-100) |
| created_by | VARCHAR(64) | NULL | User who created it |
| created_at | TIMESTAMP | DEFAULT NOW | Creation timestamp |
| updated_at | TIMESTAMP | DEFAULT NOW, ON UPDATE NOW | Last update timestamp |

**Indexes:**
- `idx_type` on `type`
- `idx_enabled` on `enabled`

---

### Table: learning_operations

**Purpose:** Tracks learning operations (prediction comparison, pattern detection, etc.)

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | VARCHAR(64) | PRIMARY KEY | Unique operation ID (nanoid) |
| type | ENUM | NOT NULL | Type: prediction_comparison, pattern_detection, correlation_analysis, model_training, insight_generation, adjustment_application |
| status | ENUM | DEFAULT 'pending' | Status: pending, running, completed, failed, cancelled |
| progress | INT | DEFAULT 0 | Progress percentage (0-100) |
| current_step | VARCHAR(255) | NULL | Current step description |
| total_steps | INT | NULL | Total number of steps |
| input | JSON | NULL | Operation input data |
| output | JSON | NULL | Operation output data |
| error | TEXT | NULL | Error message if failed |
| started_at | TIMESTAMP | NULL | Start timestamp |
| completed_at | TIMESTAMP | NULL | Completion timestamp |
| duration | INT | NULL | Duration in seconds |
| results_count | INT | DEFAULT 0 | Number of results |
| insights_generated | INT | DEFAULT 0 | Number of insights generated |
| adjustments_proposed | INT | DEFAULT 0 | Number of adjustments proposed |
| triggered_by | VARCHAR(64) | NULL | User who triggered it |
| created_at | TIMESTAMP | DEFAULT NOW | Creation timestamp |
| updated_at | TIMESTAMP | DEFAULT NOW, ON UPDATE NOW | Last update timestamp |

**Indexes:**
- `idx_type` on `type`
- `idx_status` on `status`
- `idx_created_at` on `created_at`

---

### Table: search_operations

**Purpose:** Tracks search operations (keyword search, event discovery, etc.)

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | VARCHAR(64) | PRIMARY KEY | Unique operation ID (nanoid) |
| type | ENUM | NOT NULL | Type: keyword_search, event_discovery, news_scraping, sentiment_analysis, entity_extraction |
| status | ENUM | DEFAULT 'pending' | Status: pending, running, completed, failed, cancelled |
| keywords | JSON | NOT NULL | Array of keywords to search |
| sources | JSON | NOT NULL | Array of source IDs to use |
| date_range | JSON | NULL | Date range for search |
| progress | INT | DEFAULT 0 | Progress percentage (0-100) |
| current_source | VARCHAR(255) | NULL | Current source being processed |
| sources_processed | INT | DEFAULT 0 | Number of sources processed |
| total_sources | INT | NULL | Total number of sources |
| results_found | INT | DEFAULT 0 | Number of results found |
| events_created | INT | DEFAULT 0 | Number of events created |
| error | TEXT | NULL | Error message if failed |
| started_at | TIMESTAMP | NULL | Start timestamp |
| completed_at | TIMESTAMP | NULL | Completion timestamp |
| duration | INT | NULL | Duration in seconds |
| triggered_by | VARCHAR(64) | NULL | User who triggered it |
| created_at | TIMESTAMP | DEFAULT NOW | Creation timestamp |
| updated_at | TIMESTAMP | DEFAULT NOW, ON UPDATE NOW | Last update timestamp |

**Indexes:**
- `idx_type` on `type`
- `idx_status` on `status`
- `idx_created_at` on `created_at`

---

### Table: operation_logs

**Purpose:** Logs for all learning and search operations

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier |
| operation_id | VARCHAR(64) | NOT NULL | Reference to operation |
| operation_type | ENUM | NOT NULL | Type: learning, search |
| level | ENUM | NOT NULL | Log level: debug, info, warning, error |
| message | TEXT | NOT NULL | Log message |
| data | JSON | NULL | Additional log data |
| timestamp | TIMESTAMP | DEFAULT NOW | Log timestamp |

**Indexes:**
- `idx_operation_id` on `operation_id`
- `idx_level` on `level`
- `idx_timestamp` on `timestamp`

---

## Relationships

### Learning Operations Flow

```
search_keywords (1) ─── (N) search_operations
search_sources (1) ─── (N) search_operations
learning_operations (1) ─── (N) operation_logs
search_operations (1) ─── (N) operation_logs
```

---

## Migration Status

**Last Migration:** 2025-01-18  
**New Tables Added:** 5 tables (search_keywords, search_sources, learning_operations, search_operations, operation_logs)

### Migration Commands

For **MySQL:**
```bash
# Generate migration
pnpm drizzle-kit generate

# Apply migration (if using migrations)
pnpm drizzle-kit migrate

# Or use push (direct schema sync)
pnpm db:push
```

For **SQLite:**
```bash
# Migrations run automatically on server start
# Or manually:
pnpm setup:db
```

---

## Backup

**Backup Location:** `backups/schema_backup_20250118.sql`  
**Backup Contains:** SQL CREATE TABLE statements for all 5 new tables

---

## Notes

1. **JSON Columns:** The schema uses JSON columns for flexible data storage (config, headers, input, output, keywords, sources, date_range, data)

2. **Timestamps:** All tables use `TIMESTAMP` with `DEFAULT NOW()` and `ON UPDATE NOW()` for automatic timestamp management

3. **Indexes:** All frequently queried columns have indexes for performance

4. **Soft Deletes:** Not implemented in learning-control tables (hard deletes only)

5. **Foreign Keys:** No explicit foreign keys defined (rely on application logic)

---

**Last Updated:** 2025-01-18

