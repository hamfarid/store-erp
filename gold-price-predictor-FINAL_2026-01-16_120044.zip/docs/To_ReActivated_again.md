# To Be Reactivated

> Features or components that have been disabled but should be restored later.

| Feature | Reason for Deactivation | Reactivation Plan |
|---------|-------------------------|-------------------|
| | | |
