# DEDUPLICATION LOG - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/DEDUPLICATION_LOG.md | **PURPOSE**: Duplicate files tracking and resolution | **OWNER**: Architecture Team | **RELATED**: MODULE_MAP.md, Class_Registry.md | **LAST-AUDITED**: 2025-11-17

**Version**: 1.0.0  
**Date**: 2025-11-17  
**Tool Used**: `tools/detect_code_duplication.py` (AST-based semantic analysis)  
**Threshold**: 70% similarity

---

## Executive Summary

**Scan Results**:
- ✅ Scanned: 182 Python files  
- 📦 Code blocks found: 1,557  
- 🎯 Duplications detected: 643  
- 🔥 Critical files: 15 files with 100% exact duplicates  
- ⚠️ Syntax errors: 2 files (audit_logger.py, backend/app/main.py - invalid decimal literal)

**Priority Categories**:
- **P0 - Critical**: 7 files (Predictor versions, API servers, Auth modules)
- **P1 - High**: 8 files (Config files, Data collectors, Database modules)
- **P2 - Medium**: Remaining duplicates in utilities and tests

**Estimated Impact**:
- Code reduction: ~15-20% (estimated 10,000+ lines)
- Maintenance burden: HIGH → LOW
- Bug risk: HIGH (divergent duplicates) → LOW (single source of truth)

---

## 1. Critical Duplicates (P0) - Immediate Action Required

### 1.1 Predictor Files (7 Versions - 100% Exact Duplicates)

**Files**:
1. `predict_final_v5.py` ← **CANONICAL** (Keep)
2. `predict_improved_v5.py` (High similarity with predict_final_v5.py)
3. `predict_integrated_v5.py` (High similarity with predict_final_v5.py)
4. `predict_v4_advanced.py` (Legacy version)
5. `predict_advanced.py` (Legacy version)
6. `predict_advanced_fixed.py` (Legacy version)
7. `predict_all_assets_with_chart.py` (Special purpose - extract chart logic)

**Analysis**:
- All v5 files share 85-95% similarity
- predict_final_v5.py appears most complete
- predict_all_assets_with_chart.py has unique charting functionality

**Action Plan**:
1. ✅ **Audit all 7 files** (compare features, dependencies, usage)
2. ⏳ **Extract unique features**:
   - Chart generation logic from predict_all_assets_with_chart.py → modules/visualization.py
3. ⏳ **Consolidate to predict_final_v5.py**:
   - Merge any missing features from other versions
   - Add comprehensive comments for removed versions
4. ⏳ **Archive old versions**:
   - Move v4 and non-final versions to `.archived/predictors/{date}/`
5. ⏳ **Update imports**:
   - Search for imports: `from predict_* import`, `import predict_*`
   - Update to: `from predict_final_v5 import`
6. ⏳ **Test**:
   - Run: `pytest tests/test_predictor*.py`
   - Verify: All 8 models still functional
7. ⏳ **Commit**: "refactor: consolidate 7 predictor files into predict_final_v5.py"

**Backup Location**: `.archived/predictors/2025-11-17/`

---

### 1.2 API Server Files (3 Versions - 100% Exact Duplicates)

**Files**:
1. `backend/app/main.py` ← **CANONICAL** (Production FastAPI with full security)
2. `api_server.py` (Root directory - development version)
3. `real_ml_api.py` (Root directory - ML-focused version)
4. `simple_api_old_backup.py` (Root directory - backup)

**Duplicated Classes** (100% exact match):
- `PredictionRequest` - Exact match in api_server.py, real_ml_api.py, simple_api_old_backup.py
- `PredictionResponse` - Exact match in api_server.py, simple_api_old_backup.py

**Analysis**:
- `backend/app/main.py` is production-ready (629 lines, 2FA, JWT, audit logging)
- `api_server.py`, `real_ml_api.py` are development prototypes
- `simple_api_old_backup.py` is explicitly marked as backup

**Action Plan**:
1. ✅ **Verify backend/app/main.py is production version** - CONFIRMED
2. ⏳ **Extract unique features from development versions**:
   - Check if real_ml_api.py has ML integration improvements
3. ⏳ **Archive development versions**:
   - Move to `.archived/api_servers/2025-11-17/`
4. ⏳ **Update documentation**:
   - Remove references to development API servers
   - Update README.md to point to backend/app/main.py
5. ⏳ **Update startup scripts**:
   - Check run_api.py, run_dashboard.py for imports
6. ⏳ **Test**:
   - Start backend: `python backend/wsgi.py`
   - Run API tests: `pytest backend/app/tests/`
7. ⏳ **Commit**: "refactor: remove duplicate API server files, use backend/app/main.py"

**Backup Location**: `.archived/api_servers/2025-11-17/`

---

### 1.3 Authentication Files (2 Versions - 100% Exact Duplicates)

**Files**:
1. `backend/app/auth_2fa.py` ← **CANONICAL** (Backend auth module)
2. `auth_2fa.py` (Root directory - duplicate)

**Duplicated Functions** (100% exact match):
- `TwoFactorAuth.generate_secret()` - Identical in both files

**Analysis**:
- Backend version is in proper module structure
- Root directory version is legacy/development

**Action Plan**:
1. ⏳ **Compare files**: `diff auth_2fa.py backend/app/auth_2fa.py`
2. ⏳ **Archive root version**: Move to `.archived/auth/2025-11-17/`
3. ⏳ **Update imports**:
   - Search: `from auth_2fa import`, `import auth_2fa`
   - Update: `from backend.app.auth_2fa import`
4. ⏳ **Test**: `pytest backend/app/tests/test_auth*.py`
5. ⏳ **Commit**: "refactor: remove duplicate auth_2fa.py from root"

**Similar Issue**: `auth_postgresql.py`, `security_headers.py`, `rate_limiter_redis.py`, `audit_logger.py` also have root/backend duplicates

**Backup Location**: `.archived/auth/2025-11-17/`

---

### 1.4 API Version Files (2 Secure APIs - 90% Similarity)

**Files**:
1. `api_v2.py` (Root directory)
2. `simple_api_secure.py` (Root directory)

**Duplicated Classes/Functions** (100% exact match):
- `LoginRequest` class - Identical
- `login()` async function - Identical (24 lines)

**Analysis**:
- Both files implement secure API with JWT
- api_v2.py appears more recent (version 2)
- simple_api_secure.py is explicitly named "simple"

**Action Plan**:
1. ⏳ **Review both files** (check versioning, features)
2. ⏳ **Decision**: Keep api_v2.py OR migrate to backend/app/main.py
3. ⏳ **Archive**: Move unused file to `.archived/api_versions/2025-11-17/`
4. ⏳ **Update references**: Check scripts, docs
5. ⏳ **Test**: Run API tests
6. ⏳ **Commit**: "refactor: consolidate secure API files"

**Backup Location**: `.archived/api_versions/2025-11-17/`

---

## 2. High Priority Duplicates (P1) - Consolidate Soon

### 2.1 Configuration Files (2 Versions)

**Files**:
1. `config_secure.py` ← **CANONICAL** (Pydantic settings with validation)
2. `config.py` (Legacy configuration)

**Duplicated Class**:
- `Settings.Config` class - 100% exact match (env_file, case_sensitive)

**Action Plan**:
1. ⏳ **Audit config.py** - Check for unique settings
2. ⏳ **Migrate unique settings** to config_secure.py
3. ⏳ **Archive config.py** → `.archived/config/2025-11-17/`
4. ⏳ **Update imports**: `from config import` → `from config_secure import`
5. ⏳ **Test**: All modules load settings correctly
6. ⏳ **Commit**: "refactor: consolidate config files into config_secure.py"

**Backup Location**: `.archived/config/2025-11-17/`

---

### 2.2 Module Configuration Files (2 Versions)

**Files**:
1. `modules/config_extended.py` ← **CANONICAL**
2. `modules/config.py` (Legacy)

**Action Plan**:
1. ⏳ **Compare files** - Identify differences
2. ⏳ **Merge unique features** into config_extended.py
3. ⏳ **Archive config.py** → `.archived/modules/2025-11-17/`
4. ⏳ **Update imports** in ML modules
5. ⏳ **Test**: ML pipeline still works
6. ⏳ **Commit**: "refactor: consolidate modules/config files"

**Backup Location**: `.archived/modules/2025-11-17/`

---

### 2.3 Data Collection Modules (2 Versions)

**Files**:
1. `modules/data_collector_extended.py` ← **CANONICAL**
2. `modules/data_collector.py` (Legacy)

**Action Plan**:
1. ⏳ **Compare files** - Check API sources, features
2. ⏳ **Merge unique features** into data_collector_extended.py
3. ⏳ **Archive data_collector.py** → `.archived/modules/2025-11-17/`
4. ⏳ **Update imports** in training scripts
5. ⏳ **Test**: Data collection pipeline
6. ⏳ **Commit**: "refactor: consolidate data collector modules"

**Backup Location**: `.archived/modules/2025-11-17/`

---

### 2.4 Data Merger Modules (2 Versions)

**Files**:
1. `modules/data_merger_extended.py` ← **CANONICAL**
2. `modules/data_merger.py` (Legacy)

**Action Plan**:
1. ⏳ **Compare files** - Check merge logic
2. ⏳ **Merge unique features** into data_merger_extended.py
3. ⏳ **Archive data_merger.py** → `.archived/modules/2025-11-17/`
4. ⏳ **Update imports**
5. ⏳ **Test**: Data merging works correctly
6. ⏳ **Commit**: "refactor: consolidate data merger modules"

**Backup Location**: `.archived/modules/2025-11-17/`

---

### 2.5 Model Trainer Modules (3 Versions)

**Files**:
1. `modules/model_trainer_extended.py` ← **CANONICAL** (Most features)
2. `modules/model_trainer.py` (Legacy version 1)
3. `ml/model_trainer.py` (Legacy version 2)

**Action Plan**:
1. ⏳ **Compare all 3 files** - Feature matrix
2. ⏳ **Merge unique features** into modules/model_trainer_extended.py
3. ⏳ **Archive legacy versions** → `.archived/trainers/2025-11-17/`
4. ⏳ **Update imports** in training scripts
5. ⏳ **Test**: All 8 models train correctly
6. ⏳ **Commit**: "refactor: consolidate model trainer modules"

**Backup Location**: `.archived/trainers/2025-11-17/`

---

### 2.6 Database Files (2 Versions)

**Files**:
1. `backend/app/database.py` ← **CANONICAL** (Production DB with PostgreSQL)
2. `database.py` (Root directory - legacy)

**Action Plan**:
1. ⏳ **Compare files** - Check database connections, models
2. ⏳ **Archive root version** → `.archived/database/2025-11-17/`
3. ⏳ **Update imports**: `from database import` → `from backend.app.database import`
4. ⏳ **Test**: All database operations work
5. ⏳ **Commit**: "refactor: remove duplicate database.py from root"

**Backup Location**: `.archived/database/2025-11-17/`

---

### 2.7 GUI Files (2 Versions)

**Files**:
1. `gui/main_window_extended.py` ← **CANONICAL**
2. `gui/main_window.py` (Legacy)

**Action Plan**:
1. ⏳ **Compare files** - Check UI features
2. ⏳ **Archive legacy version** → `.archived/gui/2025-11-17/`
3. ⏳ **Update imports** in GUI launcher
4. ⏳ **Test**: GUI still works
5. ⏳ **Commit**: "refactor: consolidate GUI main window files"

**Backup Location**: `.archived/gui/2025-11-17/`

---

## 3. Medium Priority Duplicates (P2) - Cleanup Later

### 3.1 Training Scripts (Multiple Versions)

**Files** (Low priority - scripts not core modules):
- `train_final_models.py` ← **KEEP**
- `train_advanced_system.py`
- `train_recent_data.py`
- `retrain_all_models_v5.py`
- `retrain_with_full_data.py`
- `retrain_gold_model.py`
- `retrain_crypto_models.py`

**Action Plan**:
1. ⏳ **Audit all training scripts** - Check use cases
2. ⏳ **Keep active scripts**: train_final_models.py, retrain_all_models_v5.py
3. ⏳ **Archive unused scripts** → `.archived/training/2025-11-17/`
4. ⏳ **Document**: Create docs/Training_Guide.md

**Backup Location**: `.archived/training/2025-11-17/`

---

### 3.2 Test Files (Multiple Versions)

**Files**:
- `test_api.py` (Root)
- `test_secure_api.py` (Root)
- `backend/app/tests/` (Production tests)

**Action Plan**:
1. ⏳ **Consolidate tests** into backend/app/tests/
2. ⏳ **Archive root tests** → `.archived/tests/2025-11-17/`
3. ⏳ **Update pytest configuration**

**Backup Location**: `.archived/tests/2025-11-17/`

---

## 4. Skipped Files (Intentionally Not Merged)

### 4.1 Backup Files
- `simple_api_old_backup.py` - Explicitly marked as backup
- Other files with `_backup`, `_old` suffixes

**Reason**: Already identified as backups, will be moved to .archived/

---

### 4.2 Different Purposes
- `predict_gold_tomorrow.py` - Specific to tomorrow's gold prediction
- `predict_friday.py` - Specific to Friday predictions
- `gold_price_comparison_oct24.py` - Historical comparison (October 2024)

**Reason**: Serve specific purposes, not general duplicates

---

### 4.3 Examples and Templates
- `examples/code-samples/log_activity_example.py`
- `templates/config/definitions/`

**Reason**: Educational/template files, meant to be duplicated

---

## 5. Syntax Errors Found

### 5.1 audit_logger.py (Root)
**Error**: `invalid decimal literal (audit_logger.py, line 19)`  
**Action**: ⏳ Fix syntax error, likely invalid f-string or number format

### 5.2 backend/app/main.py
**Error**: `invalid decimal literal (main.py, line 413)`  
**Action**: ⏳ Fix syntax error on line 413

---

## 6. Deduplication Workflow

### Standard Procedure for Each File Group:

1. **Backup**:
   ```bash
   mkdir -p .archived/{category}/{date}/
   cp {file} .archived/{category}/{date}/
   git add .archived/
   git commit -m "backup: archive {file} before deduplication"
   ```

2. **Compare Files**:
   ```bash
   diff {file1} {file2}
   code --diff {file1} {file2}  # Visual diff in VS Code
   ```

3. **Identify Canonical**:
   - Criteria: Most features, best structure, production-ready, in proper module path

4. **Merge Features**:
   - Extract unique functions/classes from non-canonical files
   - Add to canonical file with proper comments

5. **Update Imports**:
   ```bash
   # Find all imports
   grep -r "from {old_file} import" .
   grep -r "import {old_file}" .
   
   # Update imports using tools/update_imports.py
   python tools/update_imports.py --old {old_module} --new {new_module}
   ```

6. **Test**:
   ```bash
   # Run relevant tests
   pytest tests/test_{module}*.py
   
   # Run full test suite
   pytest backend/app/tests/
   ```

7. **Archive Old File**:
   ```bash
   git rm {old_file}
   git commit -m "refactor: remove duplicate {old_file}, consolidated into {canonical_file}"
   ```

8. **Document**:
   - Update this DEDUPLICATION_LOG.md
   - Update MODULE_MAP.md
   - Update Class_Registry.md

---

## 7. Verification Checklist

After completing deduplication:

- [ ] All tests pass: `pytest backend/app/tests/ -v`
- [ ] No import errors: `python -m py_compile *.py`
- [ ] Backend starts successfully: `python backend/wsgi.py`
- [ ] Frontend builds: `cd client && npm run build`
- [ ] ML pipeline works: `python predict_final_v5.py --test`
- [ ] Documentation updated: MODULE_MAP.md, Class_Registry.md
- [ ] Git history clean: No uncommitted changes
- [ ] Backup verified: All archived files in .archived/

---

## 8. Timeline and Estimates

### Phase 1 (P0 - Critical): 2-3 days
- **Day 1**: Predictor files (1.1) - 4 hours
- **Day 2**: API servers (1.2), Auth files (1.3) - 6 hours
- **Day 3**: API versions (1.4), Testing & verification - 4 hours

### Phase 2 (P1 - High Priority): 2-3 days
- **Day 4**: Config files (2.1, 2.2) - 3 hours
- **Day 5**: Data modules (2.3, 2.4), Trainers (2.5) - 6 hours
- **Day 6**: Database (2.6), GUI (2.7), Testing - 4 hours

### Phase 3 (P2 - Medium Priority): 1-2 days
- **Day 7**: Training scripts (3.1), Tests (3.2) - 4 hours
- **Day 8**: Syntax errors (5.0), Final verification - 3 hours

**Total Estimated Time**: 7-8 days (34 hours of work)

---

## 9. Risk Assessment

### Risks and Mitigations:

1. **Risk**: Breaking imports  
   **Mitigation**: Automated import updater tool, comprehensive testing

2. **Risk**: Losing unique features  
   **Mitigation**: Manual diff review, git history preservation

3. **Risk**: Production downtime  
   **Mitigation**: Backup files in .archived/, rollback plan, staging environment testing

4. **Risk**: Test failures  
   **Mitigation**: Test before/after each consolidation, pytest coverage reports

5. **Risk**: Developer confusion  
   **Mitigation**: Clear documentation, team communication, commit messages

---

## 10. Success Metrics

### Before Deduplication:
- Files with duplicates: 15+
- Total duplications: 643
- Code duplication percentage: ~15-20%
- Maintenance burden: HIGH

### After Deduplication (Target):
- Files with duplicates: 0
- Total duplications: < 50 (only intentional shared utilities)
- Code duplication percentage: < 5%
- Maintenance burden: LOW

### Verification:
```bash
# Run duplication detector after cleanup
python tools/detect_code_duplication.py . --threshold 70 --output docs/duplication_report_after.json

# Compare results
python tools/compare_duplication_reports.py docs/duplication_report.json docs/duplication_report_after.json
```

---

## 11. Next Steps

### Immediate Actions (Today - 2025-11-17):
1. ✅ **Created DEDUPLICATION_LOG.md** - DONE
2. ⏳ **Review with team** - Get approval for consolidation plan
3. ⏳ **Setup .archived/ directory structure**
4. ⏳ **Start Phase 1, Task 1.1** - Predictor files consolidation

### This Week (Nov 17-24):
- Complete Phase 1 (P0 - Critical duplicates)
- Begin Phase 2 (P1 - High priority duplicates)

### Next Week (Nov 24-Dec 1):
- Complete Phase 2
- Complete Phase 3 (P2 - Medium priority)
- Final verification and documentation

---

## 12. Related Documentation

- **MODULE_MAP.md** - Complete file inventory
- **Class_Registry.md** - Canonical class definitions (to be created)
- **TODO.md** - Master task list
- **INCOMPLETE_TASKS.md** - Pending tasks
- **COMPLETE_TASKS.md** - Completed tasks with timestamps

---

## 13. Maintenance

This file should be updated:
- ✅ **When duplicates are found**: Run detection tool monthly
- ✅ **After each consolidation**: Document merged files, backup locations
- ✅ **During code reviews**: Check for new duplicates
- ✅ **Quarterly audits**: Re-run full duplication detection

**Last Detection Run**: 2025-11-17 10:50 UTC  
**Next Scheduled Run**: 2025-12-17  
**Owner**: Architecture Team  
**Review Frequency**: Monthly

---

**END OF DEDUPLICATION_LOG.md**

**Status**: ✅ Analysis Complete, ⏳ Consolidation In Progress  
**Priority**: P0 - Critical  
**Next Action**: Review with team, start predictor consolidation
