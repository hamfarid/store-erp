# مرجع الدوال - Function Reference
# File: /home/ubuntu/gold_price_predictor/docs/function_reference.md

## نظرة عامة
هذا الملف يحتوي على توثيق شامل لجميع الدوال والوحدات المستخدمة في المشروع.

---

## الوحدات المكتملة

### 1. config.py
**الوصف:** ملف الإعدادات والثوابت المركزية للمشروع

**الثوابت الرئيسية:**
- `PROJECT_NAME`: اسم المشروع
- `PROJECT_VERSION`: رقم الإصدار
- `DATA_DIR`: مسار مجلد البيانات
- `MODELS_DIR`: مسار مجلد النماذج
- `COLUMN_*`: أسماء الأعمدة الموحدة

**الألوان:**
- `PRIMARY_COLOR`: اللون الأساسي (#2c3e50)
- `GOLD_COLOR`: لون الذهب (#FFD700)
- `SUCCESS_COLOR`: لون النجاح (#10b981)

---

### 2. data_collector.py
**الوصف:** وحدة جمع البيانات من مصادر متعددة

#### Class: DataCollector

##### `fetch_gold_prices(start_date, end_date)`
- **الوصف:** جلب أسعار الذهب التاريخية من Yahoo Finance
- **المعاملات:**
  - `start_date` (str): تاريخ البدء
  - `end_date` (str): تاريخ النهاية
- **الإرجاع:** DataFrame يحتوي على التاريخ وسعر الذهب

##### `fetch_cpi_data()`
- **الوصف:** جلب بيانات التضخم (CPI) من World Bank API
- **الإرجاع:** DataFrame يحتوي على التاريخ ومؤشر CPI

##### `collect_all_data()`
- **الوصف:** جمع جميع البيانات من جميع المصادر
- **الإرجاع:** dict يحتوي على جميع DataFrames

---

### 3. data_merger.py
**الوصف:** وحدة دمج ومعالجة البيانات

#### Class: DataMerger

##### `merge_all_data()`
- **الوصف:** دمج جميع مصادر البيانات في DataFrame واحد
- **الإرجاع:** DataFrame مدمج

##### `clean_data(df)`
- **الوصف:** تنظيف البيانات ومعالجة القيم المفقودة
- **المعاملات:** `df` (DataFrame)
- **الإرجاع:** DataFrame منظف

##### `add_technical_indicators(df)`
- **الوصف:** إضافة المؤشرات الفنية
- **المؤشرات:** Gold_MA7, Gold_MA30, Gold_Daily_Change, Gold_Volatility

---

### 4. sentiment_analyzer.py
**الوصف:** وحدة تحليل المشاعر من الأخبار

#### Class: SentimentAnalyzer

##### `load_sentiment_model()`
- **الوصف:** تحميل نموذج BERT لتحليل المشاعر
- **النموذج:** distilbert-base-uncased-finetuned-sst-2-english

##### `analyze_text_sentiment(text)`
- **الوصف:** تحليل مشاعر نص معين
- **المعاملات:** `text` (str)
- **الإرجاع:** float (-1 إلى 1)

##### `generate_sample_news_data(start_date, end_date)`
- **الوصف:** إنشاء بيانات أخبار تجريبية
- **الإرجاع:** DataFrame

---

### 5. model_trainer.py
**الوصف:** وحدة تدريب وتقييم نماذج تعلم الآلة

#### Class: ModelTrainer

##### `train_random_forest()`
- **الوصف:** تدريب نموذج Random Forest
- **الإرجاع:** dict (نتائج التدريب)

##### `train_gradient_boosting()`
- **الوصف:** تدريب نموذج Gradient Boosting
- **الإرجاع:** dict (نتائج التدريب)

##### `train_svr()`
- **الوصف:** تدريب نموذج SVR
- **الإرجاع:** dict (نتائج التدريب)

##### `compare_models()`
- **الوصف:** مقارنة أداء جميع النماذج
- **الإرجاع:** DataFrame (جدول المقارنة)

##### `save_best_model()`
- **الوصف:** حفظ أفضل نموذج
- **الملفات:** best_model_*.pkl, scaler.pkl, feature_names.pkl

---

### 6. main_window.py (GUI)
**الوصف:** الواجهة الرسومية الرئيسية

#### Class: GoldPricePredictorGUI

##### `init_ui()`
- **الوصف:** إنشاء عناصر الواجهة الرسومية

##### `create_dashboard_tab()`
- **الوصف:** إنشاء تبويب لوحة التحكم

##### `create_prediction_tab()`
- **الوصف:** إنشاء تبويب التنبؤ

##### `predict_price()`
- **الوصف:** التنبؤ بسعر الذهب

---

**آخر تحديث:** 2025-10-19

