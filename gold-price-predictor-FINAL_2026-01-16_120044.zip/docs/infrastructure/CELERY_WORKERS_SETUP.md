# Celery Workers Setup Guide
# دليل إعداد Celery Workers

**Component:** Async Task Queue  
**Estimated Time:** 45 minutes  
**Cost:** Included in EC2 costs  
**Difficulty:** Intermediate

---

## Overview

Setup Celery workers for async task processing.

**Benefits:**
- ✅ Async task processing
- ✅ Background jobs
- ✅ Scheduled tasks
- ✅ Scalable workers

---

## Step 1: Install Celery

```bash
pip install celery[redis]
```

---

## Step 2: Configure Celery

### 2.1 Create Celery App

```python
# backend/app/core/celery.py

from celery import Celery
from celery.schedules import crontab

celery_app = Celery(
    'gold_predictor',
    broker='redis://redis:6379/1',
    backend='redis://redis:6379/2'
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
)

# Scheduled tasks
celery_app.conf.beat_schedule = {
    'train-model-daily': {
        'task': 'app.tasks.train_model',
        'schedule': crontab(hour=0, minute=0),
    },
}
```

### 2.2 Create Tasks

```python
# backend/app/tasks.py

from app.core.celery import celery_app

@celery_app.task
def train_model(model_name: str):
    """Train ML model (async)"""
    # Training logic
    pass

@celery_app.task
def send_email(to: str, subject: str, body: str):
    """Send email (async)"""
    # Email logic
    pass

@celery_app.task
def generate_report(user_id: int):
    """Generate report (async)"""
    # Report logic
    pass
```

---

## Step 3: Start Workers

### 3.1 Start Worker

```bash
# Start worker
celery -A app.core.celery worker --loglevel=info --concurrency=8

# Start beat (scheduler)
celery -A app.core.celery beat --loglevel=info
```

### 3.2 Docker Compose

```yaml
# docker-compose.yml

services:
  celery-worker:
    build: .
    command: celery -A app.core.celery worker --loglevel=info --concurrency=8
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - redis
      - postgres
  
  celery-beat:
    build: .
    command: celery -A app.core.celery beat --loglevel=info
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - redis
```

---

## Step 4: Use Tasks in API

```python
# backend/app/api/endpoints.py

from app.tasks import train_model, send_email

@app.post("/api/models/train")
async def train_model_endpoint(model_name: str):
    """Trigger model training"""
    task = train_model.delay(model_name)
    return {"task_id": task.id, "status": "pending"}

@app.get("/api/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Get task status"""
    task = celery_app.AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": task.status,
        "result": task.result if task.ready() else None
    }
```

---

**Last Updated:** 2025-10-29  
**Component:** Async Task Queue  
**Status:** Ready for implementation
