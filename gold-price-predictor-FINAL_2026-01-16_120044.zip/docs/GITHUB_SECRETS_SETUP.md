# 🔐 GitHub Secrets Configuration Guide

**Version**: 1.0  
**Created**: 2026-01-16  
**Project**: Gold Price Predictor

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Required Secrets](#required-secrets)
3. [Setup Instructions](#setup-instructions)
4. [Environment Configuration](#environment-configuration)
5. [Secret Management Best Practices](#secret-management-best-practices)
6. [Troubleshooting](#troubleshooting)

---

## Overview

This guide explains how to configure GitHub Secrets for the Gold Price Predictor CI/CD pipelines. Secrets are used for:

- 🔑 Database connections
- 🐳 Docker registry authentication
- 🚀 Deployment server access
- 📧 Notifications

---

## Required Secrets

### 🔴 Critical (Required for CI)

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/db` |
| `REDIS_URL` | Redis connection string | `redis://localhost:6379` |
| `JWT_SECRET` | JWT signing secret (min 32 chars) | `your-super-secret-jwt-key-min-32-chars` |

### 🟡 Deployment (Required for CD)

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `STAGING_SSH_KEY` | SSH private key for staging | `-----BEGIN OPENSSH PRIVATE KEY-----...` |
| `STAGING_HOST` | Staging server hostname/IP | `staging.goldpredictor.app` |
| `STAGING_USER` | Staging server username | `deploy` |
| `PROD_SSH_KEY` | SSH private key for production | `-----BEGIN OPENSSH PRIVATE KEY-----...` |
| `PROD_HOST` | Production server hostname/IP | `goldpredictor.app` |
| `PROD_USER` | Production server username | `deploy` |

### 🟢 Optional (Enhanced Features)

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `DOCKER_USERNAME` | Docker Hub username | `yourusername` |
| `DOCKER_PASSWORD` | Docker Hub password/token | `dckr_pat_xxx` |
| `SLACK_WEBHOOK` | Slack notification webhook | `https://hooks.slack.com/...` |
| `CODECOV_TOKEN` | Codecov upload token | `abc123-xxx-yyy` |
| `SENTRY_DSN` | Sentry error tracking | `https://xxx@sentry.io/xxx` |
| `AWS_ACCESS_KEY_ID` | AWS access key | `AKIAIOSFODNN7EXAMPLE` |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key | `wJalrXUtnFEMI/K7MDENG/...` |
| `S3_BUCKET` | S3 bucket for backups | `gold-predictor-backups` |

---

## Setup Instructions

### Step 1: Navigate to Repository Settings

1. Go to your GitHub repository
2. Click **Settings** tab
3. In the left sidebar, click **Secrets and variables** → **Actions**

![GitHub Secrets Location](https://docs.github.com/assets/cb-28266/images/help/repository/repo-actions-secrets.png)

### Step 2: Add Repository Secrets

Click **New repository secret** and add each secret:

#### Database URL
```
Name: DATABASE_URL
Value: postgresql://postgres:your_password@db.yourhost.com:5432/gold_predictor
```

#### JWT Secret
```
Name: JWT_SECRET
Value: your-super-secret-jwt-key-that-is-at-least-32-characters-long
```

#### SSH Keys (for deployment)

Generate a new SSH key pair for deployments:

```bash
# Generate SSH key (no passphrase for automation)
ssh-keygen -t ed25519 -C "github-deploy" -f deploy_key -N ""

# Copy private key content to GitHub secret
cat deploy_key
# → Paste entire content as STAGING_SSH_KEY or PROD_SSH_KEY

# Add public key to server's authorized_keys
cat deploy_key.pub
# → Add to ~/.ssh/authorized_keys on your server
```

### Step 3: Configure Environments

For deployment protection, create GitHub Environments:

1. Go to **Settings** → **Environments**
2. Create **staging** environment
   - Add required reviewers (optional)
   - Add deployment branch rules
3. Create **production** environment
   - Require manual approval
   - Add required reviewers
   - Restrict to `main` branch only

### Step 4: Add Environment-Specific Secrets

For each environment, you can add environment-specific secrets:

1. Click on the environment name (e.g., `production`)
2. Scroll to **Environment secrets**
3. Add secrets that are specific to that environment

---

## Environment Configuration

### Local Development (`.env`)

Create a `.env` file for local development:

```bash
# Database
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/gold_predictor

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT
JWT_SECRET=dev-secret-key-not-for-production

# Server
PORT=2507
NODE_ENV=development
```

### Staging Environment

Staging secrets in GitHub:

| Secret | Description |
|--------|-------------|
| `DATABASE_URL` | Staging database |
| `REDIS_URL` | Staging Redis |
| `JWT_SECRET` | Staging JWT (different from prod!) |

### Production Environment

Production secrets in GitHub:

| Secret | Description |
|--------|-------------|
| `DATABASE_URL` | Production database (read replica supported) |
| `REDIS_URL` | Production Redis cluster |
| `JWT_SECRET` | Production JWT (rotated regularly) |

---

## Secret Management Best Practices

### ✅ DO

1. **Use strong secrets** - Min 32 characters, random
2. **Rotate regularly** - Especially JWT_SECRET (quarterly)
3. **Use environment-specific secrets** - Different for staging/prod
4. **Limit access** - Only required team members
5. **Audit usage** - Review secret access logs
6. **Use short-lived tokens** - Prefer tokens over passwords

### ❌ DON'T

1. **Never commit secrets** - Use `.gitignore`
2. **Never log secrets** - Mask in CI/CD output
3. **Never share secrets** - Use secret managers
4. **Never use default secrets** - Change all defaults
5. **Never use same secret** - Across environments

### 🔄 Rotation Schedule

| Secret | Rotation Frequency |
|--------|-------------------|
| JWT_SECRET | Every 90 days |
| Database passwords | Every 180 days |
| SSH keys | Every 365 days |
| API keys | When compromised |

---

## Troubleshooting

### Secret Not Found Error

```
Error: Input required and not supplied: secret_name
```

**Solution**: Ensure the secret is added in GitHub Settings → Secrets

### SSH Connection Refused

```
ssh: connect to host xxx port 22: Connection refused
```

**Solutions**:
1. Verify `STAGING_HOST` / `PROD_HOST` is correct
2. Check if SSH port is open (firewall)
3. Verify the public key is in `authorized_keys`

### Docker Login Failed

```
Error: Cannot perform an interactive login from a non TTY device
```

**Solution**: Ensure `DOCKER_USERNAME` and `DOCKER_PASSWORD` secrets are set

### Database Connection Error

```
error: password authentication failed for user "postgres"
```

**Solutions**:
1. Verify `DATABASE_URL` format is correct
2. Check database credentials
3. Ensure database allows connections from GitHub Actions IPs

### JWT Verification Failed

```
JsonWebTokenError: invalid signature
```

**Solution**: Ensure `JWT_SECRET` is the same across all services

---

## Quick Reference

### Generating Secure Secrets

```bash
# Generate random 32-character secret
openssl rand -base64 32

# Generate UUID
uuidgen

# Generate random hex
openssl rand -hex 32
```

### Testing Secrets Locally

```bash
# Test database connection
psql "$DATABASE_URL" -c "SELECT 1"

# Test Redis connection
redis-cli -u "$REDIS_URL" ping

# Test SSH connection
ssh -i deploy_key user@host "echo 'Connected!'"
```

### Masking Secrets in Logs

GitHub automatically masks secrets in logs. For custom secrets:

```yaml
- name: Use secret
  run: |
    echo "::add-mask::${{ secrets.CUSTOM_SECRET }}"
    ./script.sh "${{ secrets.CUSTOM_SECRET }}"
```

---

## 📝 Checklist

Before deploying, ensure you have configured:

- [ ] `DATABASE_URL` - Database connection
- [ ] `JWT_SECRET` - JWT signing key
- [ ] `STAGING_SSH_KEY` - Staging SSH access
- [ ] `STAGING_HOST` - Staging server
- [ ] `STAGING_USER` - Staging username
- [ ] `PROD_SSH_KEY` - Production SSH access (if deploying)
- [ ] `PROD_HOST` - Production server (if deploying)
- [ ] `PROD_USER` - Production username (if deploying)
- [ ] Created `staging` environment in GitHub
- [ ] Created `production` environment with approval rules

---

**Last Updated**: 2026-01-16  
**Maintained by**: DevOps Team
