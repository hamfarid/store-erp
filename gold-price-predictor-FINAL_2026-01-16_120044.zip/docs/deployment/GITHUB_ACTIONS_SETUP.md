# GitHub Actions Workflow Activation Guide
# دليل تفعيل GitHub Actions

**Status:** Manual activation required  
**Estimated Time:** 15-20 minutes  
**Difficulty:** Easy

---

## Overview

هذا الدليل يشرح كيفية تفعيل GitHub Actions workflows للمشروع، بما في ذلك CI/CD pipelines، security scanning، و code quality checks.

---

## Prerequisites

- GitHub account with admin access to repository
- GitHub Secrets access
- Accounts for:
  - Snyk (security scanning)
  - Codecov (code coverage)
  - Docker Hub (container registry)

---

## Step 1: Copy Workflow Files

### Option A: Via GitHub Web UI

1. **Navigate to repository:**
   - Go to https://github.com/hamfarid/gold-price-predictor

2. **Create workflows directory:**
   - Click "Add file" → "Create new file"
   - Type: `.github/workflows/ci.yml`
   - This will create the directory structure

3. **Copy CI workflow:**
   - Open `workflows_templates/ci.yml` in repository
   - Copy entire content
   - Paste into `.github/workflows/ci.yml`
   - Commit: "ci: Add CI workflow"

4. **Copy CD workflow:**
   - Click "Add file" → "Create new file"
   - Type: `.github/workflows/cd.yml`
   - Open `workflows_templates/cd.yml` in repository
   - Copy entire content
   - Paste into `.github/workflows/cd.yml`
   - Commit: "ci: Add CD workflow"

### Option B: Via Local Git

```bash
# Clone repository
git clone https://github.com/hamfarid/gold-price-predictor.git
cd gold-price-predictor

# Create workflows directory
mkdir -p .github/workflows

# Copy workflow files
cp workflows_templates/ci.yml .github/workflows/
cp workflows_templates/cd.yml .github/workflows/

# Commit and push
git add .github/workflows/
git commit -m "ci: Add GitHub Actions workflows"
git push origin main
```

---

## Step 2: Setup Snyk (Security Scanning)

### Create Snyk Account

1. **Sign up:**
   - Go to https://snyk.io/
   - Click "Sign up free"
   - Choose "Sign up with GitHub"

2. **Add repository:**
   - Click "Add project"
   - Select "GitHub"
   - Find and select `hamfarid/gold-price-predictor`
   - Click "Add selected repositories"

3. **Get Snyk Token:**
   - Click on your profile (top right)
   - Click "Account settings"
   - Scroll to "API Token"
   - Click "Show" and copy the token

4. **Add to GitHub Secrets:**
   - Go to repository settings
   - Click "Secrets and variables" → "Actions"
   - Click "New repository secret"
   - Name: `SNYK_TOKEN`
   - Value: Paste your Snyk token
   - Click "Add secret"

---

## Step 3: Setup Codecov (Code Coverage)

### Create Codecov Account

1. **Sign up:**
   - Go to https://codecov.io/
   - Click "Sign up with GitHub"
   - Authorize Codecov

2. **Add repository:**
   - Click "Add new repository"
   - Find `hamfarid/gold-price-predictor`
   - Click "Setup repo"

3. **Get Codecov Token:**
   - After adding repo, you'll see the token
   - Copy the token (format: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

4. **Add to GitHub Secrets:**
   - Go to repository settings
   - Click "Secrets and variables" → "Actions"
   - Click "New repository secret"
   - Name: `CODECOV_TOKEN`
   - Value: Paste your Codecov token
   - Click "Add secret"

---

## Step 4: Setup Docker Hub (Container Registry)

### Create Docker Hub Account

1. **Sign up:**
   - Go to https://hub.docker.com/
   - Click "Sign up"
   - Create account

2. **Create Access Token:**
   - Click on your username (top right)
   - Click "Account Settings"
   - Click "Security"
   - Click "New Access Token"
   - Description: "GitHub Actions"
   - Access permissions: "Read, Write, Delete"
   - Click "Generate"
   - **Copy the token immediately** (you won't see it again)

3. **Add to GitHub Secrets:**
   
   **Username:**
   - Go to repository settings
   - Click "Secrets and variables" → "Actions"
   - Click "New repository secret"
   - Name: `DOCKERHUB_USERNAME`
   - Value: Your Docker Hub username
   - Click "Add secret"
   
   **Token:**
   - Click "New repository secret"
   - Name: `DOCKERHUB_TOKEN`
   - Value: Paste your Docker Hub token
   - Click "Add secret"

---

## Step 5: Verify GitHub Secrets

### Check All Secrets

Go to: https://github.com/hamfarid/gold-price-predictor/settings/secrets/actions

**Required Secrets:**
- ✅ `SNYK_TOKEN` - Snyk API token
- ✅ `CODECOV_TOKEN` - Codecov upload token
- ✅ `DOCKERHUB_USERNAME` - Docker Hub username
- ✅ `DOCKERHUB_TOKEN` - Docker Hub access token

**Optional Secrets (for CD):**
- `AWS_ACCESS_KEY_ID` - AWS access key (for deployment)
- `AWS_SECRET_ACCESS_KEY` - AWS secret key (for deployment)
- `PRODUCTION_HOST` - Production server hostname
- `SSH_PRIVATE_KEY` - SSH key for deployment

---

## Step 6: Test Workflows

### Trigger CI Workflow

1. **Make a small change:**
   ```bash
   # Edit README.md
   echo "\n<!-- Test CI -->" >> README.md
   
   # Commit and push
   git add README.md
   git commit -m "test: Trigger CI workflow"
   git push origin main
   ```

2. **Check workflow:**
   - Go to https://github.com/hamfarid/gold-price-predictor/actions
   - You should see "CI" workflow running
   - Wait for it to complete (2-3 minutes)

3. **Verify results:**
   - All jobs should pass (green checkmarks)
   - Check Codecov report
   - Check Snyk security scan

### Trigger CD Workflow

CD workflow triggers on:
- Push to `main` branch with tag (e.g., `v1.0.0`)
- Manual workflow dispatch

**Manual trigger:**
1. Go to https://github.com/hamfarid/gold-price-predictor/actions
2. Click "CD" workflow
3. Click "Run workflow"
4. Select branch: `main`
5. Click "Run workflow"

---

## Step 7: Configure Branch Protection

### Protect Main Branch

1. **Go to settings:**
   - Repository → Settings → Branches
   - Click "Add rule"

2. **Configure rule:**
   - Branch name pattern: `main`
   - ✅ Require a pull request before merging
   - ✅ Require status checks to pass before merging
   - Select: "CI / lint", "CI / test", "CI / security"
   - ✅ Require branches to be up to date before merging
   - Click "Create"

---

## Workflow Details

### CI Workflow (ci.yml)

**Triggers:**
- Push to any branch
- Pull request to `main`

**Jobs:**
1. **Lint** (2-3 min)
   - flake8 (PEP 8 compliance)
   - black (code formatting)
   - mypy (type checking)

2. **Test** (3-4 min)
   - Unit tests (pytest)
   - Integration tests
   - Code coverage report
   - Upload to Codecov

3. **Security** (2-3 min)
   - Snyk vulnerability scan
   - Dependency check
   - Security report

**Total Time:** ~8-10 minutes

### CD Workflow (cd.yml)

**Triggers:**
- Push to `main` with tag
- Manual workflow dispatch

**Jobs:**
1. **Build** (3-4 min)
   - Build Docker image
   - Tag: latest, version, commit SHA

2. **Push** (1-2 min)
   - Push to Docker Hub
   - Multi-tag strategy

3. **Deploy Staging** (2-3 min)
   - Auto-deploy to staging
   - Run smoke tests

4. **Deploy Production** (manual approval)
   - Manual approval required
   - Deploy to production
   - Health checks

**Total Time:** ~10-15 minutes

---

## Troubleshooting

### Workflow Fails

**Check logs:**
1. Go to Actions tab
2. Click on failed workflow
3. Click on failed job
4. Expand failed step
5. Read error message

**Common issues:**

**1. Missing secrets:**
```
Error: Secret SNYK_TOKEN not found
```
**Solution:** Add secret in repository settings

**2. Docker Hub authentication failed:**
```
Error: denied: requested access to the resource is denied
```
**Solution:** Check DOCKERHUB_USERNAME and DOCKERHUB_TOKEN

**3. Tests failed:**
```
Error: 5 tests failed
```
**Solution:** Fix failing tests locally first

**4. Snyk scan failed:**
```
Error: 3 high severity vulnerabilities found
```
**Solution:** Update dependencies or add exceptions

### Codecov Upload Failed

**Error:**
```
Error: Failed to upload coverage report
```

**Solution:**
1. Check CODECOV_TOKEN is correct
2. Verify repository is added in Codecov
3. Check coverage file exists: `coverage.xml`

### Docker Build Failed

**Error:**
```
Error: failed to solve: process "/bin/sh -c pip install -r requirements.txt" did not complete successfully
```

**Solution:**
1. Check requirements.txt is valid
2. Test Docker build locally:
   ```bash
   docker build -t test .
   ```

---

## Verification Checklist

After setup, verify:

- [ ] Workflows visible in Actions tab
- [ ] All secrets added correctly
- [ ] CI workflow runs on push
- [ ] All CI jobs pass
- [ ] Codecov report uploaded
- [ ] Snyk scan completes
- [ ] Docker image builds successfully
- [ ] Branch protection enabled

---

## Next Steps

After workflows are active:

1. **Monitor workflow runs:**
   - Check Actions tab regularly
   - Fix failing workflows immediately

2. **Review security reports:**
   - Check Snyk dashboard weekly
   - Update vulnerable dependencies

3. **Monitor code coverage:**
   - Check Codecov dashboard
   - Maintain 85%+ coverage

4. **Setup notifications:**
   - Enable email notifications for failures
   - Setup Slack integration (optional)

---

## Resources

- **GitHub Actions Docs:** https://docs.github.com/en/actions
- **Snyk Docs:** https://docs.snyk.io/
- **Codecov Docs:** https://docs.codecov.com/
- **Docker Hub Docs:** https://docs.docker.com/docker-hub/

---

**Last Updated:** 2025-10-28  
**Status:** Ready for activation  
**Estimated Setup Time:** 15-20 minutes

