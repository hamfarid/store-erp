# Module Map

## Project: Gold Price Predictor
**Type:** Full-Stack  
**Framework:** React + TypeScript + Vite (Frontend) | Express + tRPC (Backend) | Python + TensorFlow (ML Service)  
**Database:** SQLite (Dev) / PostgreSQL / MySQL (Production)  
**Last Updated:** 2026-01-01

## Architecture Overview

This is a comprehensive full-stack gold and asset price prediction application using:
- **Frontend:** React 19 + TypeScript + TailwindCSS + Radix UI + tRPC Client
- **Backend:** Node.js + Express + tRPC + Drizzle ORM
- **ML Service:** Python + TensorFlow + scikit-learn + FastAPI
- **Database:** SQLite for development, PostgreSQL/MySQL for production

---

## Directory Structure

```
gold-price-predictor/
├── frontend/                    # React Frontend Application
│   ├── src/
│   │   ├── components/         # Reusable UI Components
│   │   ├── pages/              # Page Components (Routes)
│   │   ├── hooks/              # Custom React Hooks
│   │   ├── contexts/           # React Context Providers
│   │   ├── lib/                # Utility Functions
│   │   ├── store/              # Redux Store
│   │   ├── api/                # API Client
│   │   └── styles/             # CSS Styles
│   ├── public/                 # Static Assets
│   └── index.html              # Entry HTML
├── server/                      # Node.js Backend
│   ├── _core/                  # Core Server Setup
│   ├── routers/                # tRPC Routers
│   ├── services/               # Business Logic Services
│   ├── middleware/             # Express Middleware
│   ├── migrations/             # Database Migrations
│   └── ml/                     # ML Service Integration
├── backend/                     # Python ML Backend
│   ├── app/                    # FastAPI Application
│   ├── ml/                     # Machine Learning Code
│   ├── alembic/                # Database Migrations
│   └── tests/                  # Python Tests
├── shared/                      # Shared TypeScript Types
├── drizzle/                     # Drizzle ORM Schemas
├── data/                        # SQLite Database
├── models/                      # Trained ML Models
├── scripts/                     # Utility Scripts
├── tests/                       # Test Files
└── docs/                        # Documentation
```

---

## Frontend Modules

### Pages

| Page | Path | Route | Components Used | API Calls |
|------|------|-------|-----------------|----------|
| Home | `pages/Home.tsx` | `/` | Hero, PriceTicker, Features, CTA | `GET /api/assets` |
| Login | `pages/Login.tsx` | `/login` | LoginForm | `POST /api/auth/login` |
| Register | `pages/Register.tsx` | `/register` | RegisterForm | `POST /api/auth/register` |
| Dashboard | `pages/DashboardEnhanced.tsx` | `/dashboard` | Charts, Stats, Predictions | `GET /api/dashboard/stats` |
| Assets List | `pages/AssetsList.tsx` | `/assets` | AssetsTable, Pagination | `GET /api/assets` |
| Asset Create | `pages/AssetsCreate.tsx` | `/assets/create` | AssetForm | `POST /api/assets` |
| Asset Edit | `pages/AssetsEdit.tsx` | `/assets/edit/:id` | AssetForm | `PUT /api/assets/:id` |
| Asset View | `pages/AssetsView.tsx` | `/assets/view/:id` | AssetDetails | `GET /api/assets/:id` |
| Predictions | `pages/Predictions.tsx` | `/predictions` | PredictionChart | `GET /api/predictions` |
| Alerts | `pages/Alerts.tsx` | `/alerts` | AlertsList | `GET /api/alerts` |
| Portfolio | `pages/Portfolio.tsx` | `/portfolio` | PortfolioSummary | `GET /api/portfolio` |
| Trading Signals | `pages/TradingSignals.tsx` | `/trading-signals` | SignalsTable | `GET /api/signals` |
| Admin Dashboard | `pages/AdminDashboard.tsx` | `/admin` | AdminStats | `GET /api/admin/stats` |
| Admin Users | `pages/AdminUsers.tsx` | `/admin/users` | UsersTable | `GET /api/admin/users` |
| Admin Assets | `pages/AdminAssets.tsx` | `/admin/assets` | AssetsManagement | `GET /api/admin/assets` |
| Settings | `pages/Settings.tsx` | `/settings` | SettingsForm | `GET /api/settings` |
| Profile | `pages/UserProfile.tsx` | `/profile` | ProfileForm | `GET /api/users/profile` |

### Components

| Component | Path | Used By | Props |
|-----------|------|---------|-------|
| Navigation | `components/Navigation.tsx` | All pages | `user` |
| MobileNav | `components/MobileNav.tsx` | All pages (mobile) | - |
| ChatWidget | `components/AIAssistant/ChatWidget.tsx` | All pages | `userId` |
| PredictionChart | `components/PredictionChart.tsx` | Dashboard, Predictions | `assetId`, `data` |
| PriceChart | `components/PriceChart.tsx` | Asset pages | `assetId`, `data` |
| TradingViewChart | `components/TradingViewChart.tsx` | Trading pages | `symbol` |
| AlertCard | `components/AlertCard.tsx` | Alerts page | `alert` |
| StatisticsCard | `components/StatisticsCard.tsx` | Dashboard | `title`, `value`, `change` |
| ErrorBoundary | `components/ErrorBoundary.tsx` | App wrapper | `children` |
| ProtectedRoute | `components/ProtectedRoute.tsx` | Protected pages | `children` |
| AdminRoute | `components/AdminRoute.tsx` | Admin pages | `children` |

### Services

| Service | Path | Purpose | Methods |
|---------|------|---------|---------|
| tRPC Client | `lib/trpc.ts` | API Communication | All tRPC calls |
| API Client | `api/client.ts` | HTTP Client | `get()`, `post()`, `put()`, `delete()` |
| Toast Utils | `lib/toast-utils.ts` | Notifications | `success()`, `error()` |
| Utils | `lib/utils.ts` | Helper Functions | `cn()`, `formatCurrency()`, `formatDate()` |

### Hooks

| Hook | Path | Purpose |
|------|------|---------|
| useAuth | `_core/hooks/useAuth.ts` | Authentication state |
| useWebSocket | `hooks/useWebSocket.ts` | Real-time updates |
| useErrorHandler | `hooks/useErrorHandler.ts` | Error handling |
| useMobile | `hooks/useMobile.tsx` | Mobile detection |
| usePersistFn | `hooks/usePersistFn.ts` | Persist function reference |

---

## Backend Modules

### tRPC Routers

| Router | Path | Methods | Purpose |
|--------|------|---------|---------|
| Auth Router | `routers/auth.ts` | `login`, `register`, `logout`, `me` | Authentication |
| Users Router | `routers/users.ts` | `list`, `get`, `create`, `update`, `delete` | User management |
| Assets Router | `routers/assets.ts` | `list`, `get`, `create`, `update`, `delete` | Asset management |
| Predictions Router | `routers/predictions.ts` | `list`, `get`, `create` | Price predictions |
| Alerts Router | `routers/alerts.ts` | `list`, `get`, `create`, `update`, `delete` | Alert management |
| Portfolio Router | `routers/portfolio.ts` | `list`, `get`, `create`, `update` | Portfolio management |
| Trading Signals Router | `routers/trading-signals.ts` | `list`, `get` | Trading signals |
| Admin Router | `routers/admin.ts` | `stats`, `users`, `logs` | Admin operations |
| Settings Router | `routers/settings.ts` | `get`, `update` | Settings management |

### Services

| Service | Path | Purpose |
|---------|------|---------|
| Auth Service | `services/auth.ts` | Authentication logic |
| Email Service | `email-service.ts` | Email notifications |
| News Service | `news-service.ts` | News aggregation |
| AI Assistant | `ai-assistant.ts` | AI chat functionality |
| AI Scheduler | `ai-scheduler.ts` | Scheduled AI tasks |
| Price Updater | `services/realtime-price-updater.ts` | Real-time price updates |
| Backup Service | `backup-utils.ts` | Database backups |
| Report Generator | `report-generators.ts` | Report generation |

### Middleware

| Middleware | Path | Purpose |
|------------|------|---------|
| Session Middleware | `_core/sessionMiddleware.ts` | Session management |
| Rate Limiter | `_core/rateLimiter.ts` | API rate limiting |
| Security | `_core/security.ts` | Security headers |
| Error Handler | `_core/errorHandler.ts` | Error handling |
| Input Sanitization | `middleware/input-sanitization.ts` | XSS protection |
| CSRF Protection | `middleware/csrf.ts` | CSRF validation |

---

## Database Schema

### Tables

| Table | Columns | Indexes | Foreign Keys |
|-------|---------|---------|-------------|
| users | id, name, email, passwordHash, role, createdAt, lastSignedIn | email (unique) | - |
| assets | id, symbol, name, category, currentPrice, isActive | symbol, category | - |
| predictions | id, assetId, predictedPrice, predictionDate, accuracy | assetId, createdAt | assetId → assets |
| alerts | id, userId, assetId, alertType, targetPrice, isActive | userId, assetId | userId → users, assetId → assets |
| portfolios | id, userId, name, totalValue | userId | userId → users |
| transactions | id, portfolioId, assetId, type, quantity, price | portfolioId, assetId | portfolioId → portfolios, assetId → assets |
| notifications | id, userId, title, message, isRead | userId | userId → users |
| trading_signals | id, assetId, signalType, strength, confidence | assetId | assetId → assets |
| historical_prices | id, assetId, date, price, high, low, volume | assetId, date | assetId → assets |
| system_logs | id, level, message, timestamp | timestamp | - |
| security_events | id, eventType, userId, ipAddress, timestamp | userId, timestamp | userId → users |

### Relationships

```
users (1) ─── (N) portfolios
users (1) ─── (N) alerts
users (1) ─── (N) notifications
portfolios (1) ─── (N) transactions
assets (1) ─── (N) predictions
assets (1) ─── (N) alerts
assets (1) ─── (N) transactions
assets (1) ─── (N) trading_signals
assets (1) ─── (N) historical_prices
```

---

## Data Flow

### Example: User Login

```
[User] → [Frontend: LoginForm]
  ↓
  [Submit Button Click]
  ↓
  [Frontend: tRPC client.auth.login()]
  ↓
  [API Call: POST /api/trpc/auth.login]
  ↓
  [Backend: auth.router.ts]
  ↓
  [Backend: Validate credentials]
  ↓
  [Backend: Generate JWT token]
  ↓
  [Backend: Set session cookie]
  ↓
  [Response: User data + session]
  ↓
  [Frontend: Update auth context]
  ↓
  [Navigate to /dashboard]
```

### Example: Get Predictions

```
[User] → [Dashboard Page]
  ↓
  [useQuery: predictions.list]
  ↓
  [tRPC: GET /api/trpc/predictions.list]
  ↓
  [Backend: predictions.router.ts]
  ↓
  [Backend: Query database]
  ↓
  [Backend: Call ML service (optional)]
  ↓
  [Response: Predictions array]
  ↓
  [Frontend: Update UI with charts]
```

---

## Environment Variables

| Variable | Purpose | Default |
|----------|---------|---------|
| NODE_ENV | Environment mode | development |
| PORT | Server port | 2505 |
| DATABASE_URL | Database connection | file:./data/asset_predictor.db |
| JWT_SECRET | JWT signing key | (required) |
| ML_SERVICE_URL | ML service endpoint | http://localhost:2105 |
| SMTP_HOST | Email server | smtp.gmail.com |
| REDIS_URL | Redis connection | redis://localhost:6379 |

---

## API Endpoints Summary

### Authentication
- `POST /api/trpc/auth.login` - User login
- `POST /api/trpc/auth.register` - User registration
- `POST /api/trpc/auth.logout` - User logout
- `GET /api/trpc/auth.me` - Get current user

### Assets
- `GET /api/trpc/assets.list` - List all assets
- `GET /api/trpc/assets.get` - Get single asset
- `POST /api/trpc/assets.create` - Create asset
- `PUT /api/trpc/assets.update` - Update asset
- `DELETE /api/trpc/assets.delete` - Delete asset

### Predictions
- `GET /api/trpc/predictions.list` - List predictions
- `GET /api/trpc/predictions.get` - Get single prediction
- `POST /api/trpc/predictions.generate` - Generate new prediction

### Alerts
- `GET /api/trpc/alerts.list` - List user alerts
- `POST /api/trpc/alerts.create` - Create alert
- `PUT /api/trpc/alerts.update` - Update alert
- `DELETE /api/trpc/alerts.delete` - Delete alert

---

## Missing Files Checklist

### Frontend
- [x] All pages have corresponding routes
- [x] All components are documented
- [x] All services are implemented
- [x] All API calls are defined

### Backend
- [x] All routes have controllers
- [x] All controllers have services
- [x] All services have models
- [x] All models have migrations

### Database
- [x] All tables have migrations
- [x] All foreign keys are defined
- [x] All indexes are created

---

## Version Information

- **Node.js:** v24.12.0
- **React:** 19.x
- **TypeScript:** 5.9.x
- **Vite:** 7.x
- **tRPC:** 11.x
- **Drizzle ORM:** 0.44.x
- **TailwindCSS:** 4.x
- **Python:** 3.11+
- **TensorFlow:** 2.15+
