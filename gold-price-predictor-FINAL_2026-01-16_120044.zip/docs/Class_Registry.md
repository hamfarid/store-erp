# Class & Type Canonical Registry

**FILE:** docs/Class_Registry.md | **PURPOSE:** Single source of truth for all classes/types | **OWNER:** Lead Architect | **RELATED:** ARCHITECTURE.md, DB_Schema.md | **LAST-AUDITED:** 2025-01-18

**Project:** Gold Price Predictor  
**Framework:** GLOBAL_GUIDELINES v3.0  
**Registry Version:** 1.0

---

## Purpose

This registry serves as the **single source of truth** for all classes, types, and models in the Gold Price Predictor project. It prevents duplication, tracks relationships, and maintains migration history.

**Workflow:**
1. Before creating a new class: **search this registry**
2. If exists: **reuse canonical**
3. If new: **add entry to this registry**
4. CI: **block PRs without registry update**

---

## Backend Models (SQLAlchemy - PostgreSQL)

### UserDB

- **CanonicalName**: UserDB
- **Location**: `backend/app/database.py` (lines 30-44)
- **DomainContext**: Authentication & Authorization
- **Purpose**: Represents system users in PostgreSQL database
- **Fields**:
  - id: Integer (PK, indexed)
  - username: String (unique, indexed, not null)
  - email: String (unique, indexed)
  - full_name: String
  - hashed_password: String (not null)
  - disabled: Boolean (default: False)
  - created_at: DateTime (default: utcnow)
  - updated_at: DateTime (default: utcnow, onupdate: utcnow)
- **Relations**:
  - has_many: predictions (via user_id)
- **Invariants**:
  - username must be unique
  - email must be unique
  - hashed_password never null
- **Visibility**: Internal (not exposed directly in API)
- **Lifecycle**: Active users can be soft-deleted via disabled flag
- **DTO/API**: UserResponse in `client/src/api/client.ts`
- **FE Mapping**: User type in `drizzle/schema.ts`
- **DB Mapping**: `users` table (PostgreSQL)
- **Tests**: `backend/tests/test_auth.py`
- **Aliases**: None
- **Migration Notes**: Initial version

---

### PredictionDB

- **CanonicalName**: PredictionDB
- **Location**: `backend/app/database.py` (lines 48-60)
- **DomainContext**: ML Predictions
- **Purpose**: Stores price predictions for assets
- **Fields**:
  - id: Integer (PK, indexed)
  - user_id: Integer (indexed, FK to users)
  - symbol: String (indexed, not null)
  - horizon: String (not null) - "1d", "7d", "30d"
  - predicted_price: Float (not null)
  - confidence_level: Float (default: 0.95)
  - model_used: String
  - model_accuracy: Float
  - created_at: DateTime (default: utcnow, indexed)
- **Relations**:
  - belongs_to: user (via user_id)
  - belongs_to: asset (via symbol)
- **Invariants**:
  - predicted_price > 0
  - confidence_level between 0 and 1
  - horizon in ["1d", "7d", "30d"]
- **Visibility**: Internal
- **Lifecycle**: Immutable after creation (no updates)
- **DTO/API**: PredictionResponse in `client/src/api/client.ts`, `python-ml-service/app.py`
- **FE Mapping**: Prediction type in `drizzle/schema.ts`
- **DB Mapping**: `predictions` table (PostgreSQL)
- **Tests**: `backend/tests/test_predictions.py`
- **Aliases**: None
- **Migration Notes**: Initial version

---

### AssetDB

- **CanonicalName**: AssetDB
- **Location**: `backend/app/database.py` (lines 64-77)
- **DomainContext**: Asset Management
- **Purpose**: Represents tradable assets (gold, crypto, currencies)
- **Fields**:
  - id: Integer (PK, indexed)
  - symbol: String (unique, indexed, not null)
  - name: String (not null)
  - category: String (indexed) - "commodity", "crypto", "currency", "stock"
  - description: String
  - created_at: DateTime (default: utcnow)
  - updated_at: DateTime (default: utcnow, onupdate: utcnow)
- **Relations**:
  - has_many: predictions (via symbol)
  - has_many: historical_prices
- **Invariants**:
  - symbol must be unique
  - category must be valid enum value
- **Visibility**: Public (exposed in API)
- **Lifecycle**: Active assets can be deactivated
- **DTO/API**: Asset in `server/python-api-client.ts`, `client/src/api/client.ts`
- **FE Mapping**: Asset type in `drizzle/schema.ts`
- **DB Mapping**: `assets` table (PostgreSQL)
- **Tests**: `backend/tests/test_assets.py`
- **Aliases**: None
- **Migration Notes**: Initial version

---

## Frontend Types (TypeScript - Drizzle ORM)

### User

- **CanonicalName**: User
- **Location**: `drizzle/schema.ts` (lines 14-22, 24)
- **DomainContext**: Authentication & Authorization
- **Purpose**: User type for tRPC/Drizzle
- **Fields**:
  - id: varchar(64) (PK)
  - name: text
  - email: varchar(320)
  - loginMethod: varchar(64)
  - role: enum("user", "admin") (default: "user", not null)
  - createdAt: timestamp (default: now)
  - lastSignedIn: timestamp (default: now)
- **Relations**:
  - has_many: notifications
  - has_many: ai_conversations
  - has_many: portfolio_items
- **Invariants**:
  - role must be "user" or "admin"
  - email must be valid format
- **Visibility**: Internal
- **Lifecycle**: Active users
- **Backend Mapping**: UserDB in `backend/app/database.py`
- **API**: UserResponse in `client/src/api/client.ts`
- **DB Mapping**: `users` table (MySQL/Drizzle)
- **Tests**: `client/src/__tests__/auth.test.ts`
- **Aliases**: InsertUser (for inserts)
- **Migration Notes**: Initial version

---

### Asset

- **CanonicalName**: Asset
- **Location**: `drizzle/schema.ts` (lines 51-66, 68)
- **DomainContext**: Asset Management
- **Purpose**: Asset type for tRPC/Drizzle
- **Fields**:
  - id: int (PK, autoincrement)
  - name: varchar(255) (not null)
  - symbol: varchar(50) (not null, indexed)
  - type: varchar(50)
  - yahooSymbol: varchar(50)
  - description: text
  - category: enum("commodity", "crypto", "currency", "stock") (not null, indexed)
  - currentPrice: decimal(20, 8)
  - isActive: boolean (default: true, not null)
  - createdAt: timestamp (default: now)
  - updatedAt: timestamp (default: now)
- **Relations**:
  - has_many: predictions
  - has_many: trading_signals
  - has_many: portfolio_items
- **Invariants**:
  - category must be valid enum
  - currentPrice >= 0
- **Visibility**: Public
- **Lifecycle**: Active assets
- **Backend Mapping**: AssetDB in `backend/app/database.py`
- **API**: Asset in `server/python-api-client.ts`
- **DB Mapping**: `assets` table (MySQL/Drizzle)
- **Tests**: `client/src/__tests__/assets.test.ts`
- **Aliases**: InsertAsset (for inserts)
- **Migration Notes**: Initial version

---

### Prediction

- **CanonicalName**: Prediction
- **Location**: `drizzle/schema.ts` (lines 93-100+)
- **DomainContext**: ML Predictions
- **Purpose**: Prediction type for tRPC/Drizzle
- **Fields**:
  - id: int (PK, autoincrement)
  - assetId: int (not null, FK to assets)
  - predictionDate: timestamp (not null)
  - targetDate: timestamp (not null)
  - daysAhead: int (not null)
  - currentPrice: decimal(20, 8) (not null)
  - predictedPrice: decimal(20, 8) (not null)
  - (additional fields in full schema)
- **Relations**:
  - belongs_to: asset (via assetId)
- **Invariants**:
  - predictedPrice > 0
  - daysAhead > 0
  - targetDate > predictionDate
- **Visibility**: Internal
- **Lifecycle**: Immutable
- **Backend Mapping**: PredictionDB in `backend/app/database.py`
- **API**: PredictionResponse in `client/src/api/client.ts`
- **DB Mapping**: `predictions` table (MySQL/Drizzle)
- **Tests**: `client/src/__tests__/predictions.test.ts`
- **Aliases**: InsertPrediction (for inserts)
- **Migration Notes**: Initial version

---

## API DTOs (Request/Response Types)

### PredictionRequest

- **CanonicalName**: PredictionRequest
- **Location**: `python-ml-service/app.py` (lines 27-35)
- **DomainContext**: ML API
- **Purpose**: Request payload for ML prediction endpoint
- **Fields**:
  - asset_id: int
  - asset_symbol: str
  - historical_prices: List[Dict]
  - technical_indicators: Optional[Dict]
  - sentiment_score: Optional[float]
  - related_assets: Optional[Dict]
  - horizon: str (default: "1d") - "1d", "7d", "30d"
  - model_type: str (default: "lstm") - "lstm", "gru", "transformer"
- **Validation**: Pydantic BaseModel
- **Used By**: `/predict` endpoint
- **Related**: PredictionResponse
- **Tests**: `python-ml-service/tests/test_api.py`

---

### PredictionResponse

- **CanonicalName**: PredictionResponse
- **Location**: Multiple locations (canonical: `python-ml-service/app.py` lines 37-47)
- **DomainContext**: ML API
- **Purpose**: Response payload for ML prediction endpoint
- **Fields**:
  - asset_id: int
  - asset_symbol: str
  - predicted_price: float
  - confidence_level: float
  - prediction_date: str
  - model_type: str
  - horizon: str
  - lower_bound: float
  - upper_bound: float
  - features_used: List[str]
- **Validation**: Pydantic BaseModel
- **Used By**: `/predict` endpoint
- **Related**: PredictionRequest
- **Aliases**: PredictionResponse in `client/src/api/client.ts` (slightly different schema)
- **Tests**: `python-ml-service/tests/test_api.py`
- **Migration Notes**: Frontend version has different fields (symbol, current_price, change_percent, confidence, timestamp, sentiment_score, economic_indicators)

---

## Duplicate Detection

**Known Duplicates:**
1. **PredictionResponse**: 2 versions
   - Python ML Service: `python-ml-service/app.py` (canonical)
   - Frontend API Client: `client/src/api/client.ts` (different schema)
   - **Action**: Document differences, consider unifying

2. **Asset**: 2 versions
   - Backend (SQLAlchemy): `backend/app/database.py`
   - Frontend (Drizzle): `drizzle/schema.ts`
   - **Action**: Expected (different ORMs), keep both

3. **User**: 2 versions
   - Backend (SQLAlchemy): `backend/app/database.py`
   - Frontend (Drizzle): `drizzle/schema.ts`
   - **Action**: Expected (different ORMs), keep both

---

## Registry Maintenance

**Last Updated:** 2025-01-18  
**Next Review:** 2025-02-18  
**Owner:** Lead Architect

**Pending Additions:**
- Alert model
- Notification model
- Portfolio model
- Historical Price model
- Trading Signal model
- AI Conversation model
- AI Task model

**CI Enforcement:**
- Pre-commit hook: check for new classes
- CI pipeline: verify registry is updated
- Auto-generate registry from code (future)

---

**Total Classes Registered:** 9  
**Total Duplicates:** 3 (documented)  
**Coverage:** ~40% (need to add remaining models)

