# Frontend Routes - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/Routes_FE.md | **PURPOSE**: Complete frontend routing documentation | **OWNER**: Frontend Team | **RELATED**: ARCHITECTURE.md, Permissions_Model.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Router**: Wouter (React)  
**Base URL**: `http://localhost:5573`

---

## Table of Contents
1. [Routing Overview](#1-routing-overview)
2. [Public Routes](#2-public-routes)
3. [Protected Routes](#3-protected-routes)
4. [Admin Routes](#4-admin-routes)
5. [Route Guards](#5-route-guards)
6. [Navigation Flow](#6-navigation-flow)
7. [Lazy Loading](#7-lazy-loading)
8. [404 Handling](#8-404-handling)

---

## 1. Routing Overview

### 1.1 Router Configuration

**Framework**: Wouter (lightweight React Router alternative)

**Installation**:
```bash
npm install wouter
```

**File**: `client/src/App.tsx`

```typescript
import { Route, Switch, Redirect } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { ProtectedRoute } from '@/components/ProtectedRoute';

// Lazy-loaded pages
const Home = lazy(() => import('@/pages/Home'));
const Login = lazy(() => import('@/pages/Login'));
const Register = lazy(() => import('@/pages/Register'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Predict = lazy(() => import('@/pages/Predict'));
const History = lazy(() => import('@/pages/History'));
const Alerts = lazy(() => import('@/pages/Alerts'));
const Settings = lazy(() => import('@/pages/Settings'));
const Logs = lazy(() => import('@/pages/Logs'));
const Admin = lazy(() => import('@/pages/Admin'));

function App() {
  const { isAuthenticated } = useAuth();
  
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Switch>
        {/* Public Routes */}
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        
        {/* Protected Routes */}
        <Route path="/dashboard">
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        </Route>
        
        <Route path="/predict">
          <ProtectedRoute requiredPermission="predictions.create">
            <Predict />
          </ProtectedRoute>
        </Route>
        
        <Route path="/history">
          <ProtectedRoute requiredPermission="predictions.view">
            <History />
          </ProtectedRoute>
        </Route>
        
        <Route path="/alerts">
          <ProtectedRoute requiredPermission="alerts.list">
            <Alerts />
          </ProtectedRoute>
        </Route>
        
        <Route path="/settings">
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        </Route>
        
        <Route path="/logs">
          <ProtectedRoute requiredPermission="logs.view">
            <Logs />
          </ProtectedRoute>
        </Route>
        
        {/* Admin Routes */}
        <Route path="/admin/*">
          <ProtectedRoute requiredRole="ADMIN">
            <Admin />
          </ProtectedRoute>
        </Route>
        
        {/* 404 */}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}
```

---

## 2. Public Routes

### 2.1 Home Page

**Path**: `/`

**Component**: `client/src/pages/Home.tsx`

**Purpose**: Landing page with product overview

**Features**:
- Hero section with CTA
- Feature highlights (8 ML models, 99.03% accuracy)
- Asset coverage (Gold, Silver, Crude Oil, Bitcoin, S&P 500)
- Testimonials
- Pricing plans

**Access**: Public (no authentication required)

**Navigation**:
- Login button → `/login`
- Register button → `/register`
- Demo button → `/predict` (requires authentication)

### 2.2 Login Page

**Path**: `/login`

**Component**: `client/src/pages/Login.tsx`

**Purpose**: User authentication

**Features**:
- Username/email + password form
- "Remember me" checkbox
- 2FA token input (if enabled)
- "Forgot password" link
- Social login (Google, GitHub) - planned

**Form Fields**:
```typescript
interface LoginForm {
  username: string;        // or email
  password: string;
  remember_me?: boolean;
  totp_token?: string;     // 2FA token (if enabled)
}
```

**API Endpoint**: `POST /api/auth/login`

**Success**:
- Store JWT tokens (localStorage or httpOnly cookies)
- Redirect to `/dashboard`

**Validation**:
- Username/email required
- Password required (min 8 chars)
- 2FA token required (if user has 2FA enabled)

### 2.3 Register Page

**Path**: `/register`

**Component**: `client/src/pages/Register.tsx`

**Purpose**: User registration

**Features**:
- Username, email, password fields
- Password strength meter
- Terms & conditions checkbox
- Email verification (sent after registration)

**Form Fields**:
```typescript
interface RegisterForm {
  username: string;        // 3-50 chars, alphanumeric + underscore
  email: string;           // Valid email format
  password: string;        // Min 8 chars, complexity requirements
  confirm_password: string;
  agree_to_terms: boolean;
}
```

**API Endpoint**: `POST /api/auth/register`

**Success**:
- Show success message
- Redirect to `/login`
- Send verification email

**Validation**:
- Username: 3-50 chars, unique
- Email: Valid format, unique
- Password: Min 8 chars, uppercase, lowercase, number
- Passwords match
- Terms accepted

---

## 3. Protected Routes

### 3.1 Dashboard

**Path**: `/dashboard`

**Component**: `client/src/pages/Dashboard.tsx`

**Purpose**: User dashboard with overview and quick actions

**Access**: Authenticated users (USER+)

**Required Permission**: None (accessible to all authenticated users)

**Features**:
- Recent predictions (last 10)
- Active alerts summary
- Asset price widgets (Gold, Silver, Bitcoin)
- Quick prediction button
- Performance metrics (prediction accuracy)

**API Calls**:
- `GET /api/predictions/history?limit=10`
- `GET /api/alerts?active=true`
- `GET /api/assets/prices`

### 3.2 Predict Page

**Path**: `/predict`

**Component**: `client/src/pages/Predict.tsx`

**Purpose**: Create new price prediction

**Access**: Authenticated users (USER+)

**Required Permission**: `predictions.create`

**Features**:
- Asset selection (dropdown: GOLD, SILVER, CRUDE_OIL, BITCOIN, SP500)
- Horizon selection (short/medium/long)
- Model selection (ARIMA, LSTM, Ensemble)
- Prediction result display (price, confidence, chart)
- Save to history button

**Form Fields**:
```typescript
interface PredictionForm {
  symbol: string;          // GOLD, SILVER, CRUDE_OIL, BITCOIN, SP500
  horizon: string;         // short (7d), medium (30d), long (90d)
  model?: string;          // Optional: arima, lstm, ensemble (default)
}
```

**API Endpoint**: `POST /api/predict`

**Response**:
```typescript
interface PredictionResponse {
  id: string;
  symbol: string;
  current_price: number;
  predicted_price: number;
  confidence: number;       // 0.0-1.0
  horizon: string;
  model_used: string;
  created_at: string;
  chart_data?: ChartPoint[];
}
```

### 3.3 History Page

**Path**: `/history`

**Component**: `client/src/pages/History.tsx`

**Purpose**: View past predictions

**Access**: Authenticated users (USER+)

**Required Permission**: `predictions.view`

**Features**:
- Table of predictions (paginated)
- Filters: asset, horizon, date range, model
- Sort: date, accuracy, confidence
- Export to CSV (MANAGER+)
- Delete prediction (own predictions or MANAGER+)

**Columns**:
- Date
- Asset
- Current Price
- Predicted Price
- Actual Price (if available)
- Accuracy
- Confidence
- Horizon
- Actions (view, delete)

**API Endpoint**: `GET /api/predictions/history?page=1&limit=20`

### 3.4 Alerts Page

**Path**: `/alerts`

**Component**: `client/src/pages/Alerts.tsx`

**Purpose**: Manage price alerts

**Access**: Authenticated users (USER+)

**Required Permission**: `alerts.list`

**Features**:
- Create new alert
- List active alerts
- Edit/delete alerts
- Alert notifications (email, push)
- Alert history

**Alert Form**:
```typescript
interface AlertForm {
  symbol: string;
  condition: 'above' | 'below';
  target_price: number;
  notification_method: 'email' | 'push' | 'both';
  expires_at?: string;
}
```

**API Endpoints**:
- `GET /api/alerts` - List alerts
- `POST /api/alerts` - Create alert
- `PUT /api/alerts/:id` - Update alert
- `DELETE /api/alerts/:id` - Delete alert

### 3.5 Settings Page

**Path**: `/settings`

**Component**: `client/src/pages/Settings.tsx`

**Purpose**: User account settings

**Access**: Authenticated users (USER+)

**Required Permission**: None (own settings)

**Features**:
- Profile settings (username, email, avatar)
- Password change
- 2FA setup (enable/disable)
- API key management
- Notification preferences
- Theme (light/dark mode)

**Sections**:
1. **Profile**: Username, email, avatar
2. **Security**: Password, 2FA, sessions
3. **API Keys**: Generate, view, revoke
4. **Notifications**: Email, push preferences
5. **Preferences**: Theme, language, timezone

**API Endpoints**:
- `GET /api/users/me` - Get current user
- `PUT /api/users/me` - Update profile
- `POST /api/auth/change-password` - Change password
- `POST /api/auth/2fa/enable` - Enable 2FA
- `GET /api/auth/api-keys` - List API keys

### 3.6 Logs Page

**Path**: `/logs`

**Component**: `client/src/pages/Logs.tsx`

**Purpose**: View activity logs

**Access**: Own logs (USER+) or all logs (MANAGER+)

**Required Permission**: `logs.view`

**Features**:
- Activity log table (login, predictions, exports)
- Filters: action, date range
- Export to CSV (MANAGER+)

**API Endpoint**: `GET /api/logs?user_id=current` (USER) or `GET /api/logs` (MANAGER+)

---

## 4. Admin Routes

### 4.1 Admin Dashboard

**Path**: `/admin`

**Component**: `client/src/pages/Admin/Dashboard.tsx`

**Access**: ADMIN only

**Required Role**: `ADMIN`

**Features**:
- System metrics (users, predictions, API calls)
- Recent activity
- System health
- Quick actions (manage users, assets)

### 4.2 User Management

**Path**: `/admin/users`

**Component**: `client/src/pages/Admin/Users.tsx`

**Access**: ADMIN only

**Required Permission**: `users.list`

**Features**:
- User list (paginated)
- Search users
- Edit user (role, status)
- Delete user
- View user activity

**API Endpoints**:
- `GET /api/admin/users`
- `PUT /api/admin/users/:id`
- `DELETE /api/admin/users/:id`

### 4.3 Asset Management

**Path**: `/admin/assets`

**Component**: `client/src/pages/Admin/Assets.tsx`

**Access**: ADMIN only

**Required Permission**: `assets.create`, `assets.update`, `assets.delete`

**Features**:
- Asset list
- Add new asset
- Edit asset (name, symbol, data source)
- Delete asset
- Test data connection

### 4.4 System Settings

**Path**: `/admin/settings`

**Component**: `client/src/pages/Admin/Settings.tsx`

**Access**: ADMIN only

**Required Permission**: `settings.system`

**Features**:
- System configuration
- Feature flags
- Rate limits
- Email settings
- Backup/restore

---

## 5. Route Guards

### 5.1 Protected Route Component

**File**: `client/src/components/ProtectedRoute.tsx`

See `Permissions_Model.md` Section 6.1 for full implementation.

**Usage**:
```typescript
<Route path="/predict">
  <ProtectedRoute requiredPermission="predictions.create">
    <Predict />
  </ProtectedRoute>
</Route>
```

### 5.2 Authentication Check

**Checks**:
1. Is user authenticated? (JWT token valid)
2. Does user have required role?
3. Does user have required permission?

**Redirect Logic**:
- Not authenticated → `/login?redirect=/predict`
- Insufficient permissions → `/unauthorized`

### 5.3 Permission Hook

**File**: `client/src/hooks/usePermission.ts`

See `Permissions_Model.md` Section 6.2 for full implementation.

---

## 6. Navigation Flow

### 6.1 Unauthenticated User Flow

```
Home (/)
  ↓ Click "Get Started"
Register (/register)
  ↓ Submit form
Login (/login)
  ↓ Enter credentials
Dashboard (/dashboard)
```

### 6.2 Authenticated User Flow

```
Dashboard (/dashboard)
  ├→ Predict (/predict) → Create prediction → History (/history)
  ├→ Alerts (/alerts) → Create alert
  ├→ Settings (/settings) → Update profile
  └→ Logs (/logs) → View activity
```

### 6.3 Admin User Flow

```
Dashboard (/dashboard)
  └→ Admin (/admin)
      ├→ Users (/admin/users)
      ├→ Assets (/admin/assets)
      └→ Settings (/admin/settings)
```

---

## 7. Lazy Loading

### 7.1 Code Splitting

**Implementation**:
```typescript
import { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Predict = lazy(() => import('@/pages/Predict'));

<Suspense fallback={<LoadingSpinner />}>
  <Route path="/dashboard" component={Dashboard} />
</Suspense>
```

**Benefits**:
- Reduced initial bundle size
- Faster initial load
- Load pages on-demand

**Bundle Sizes** (estimated):
- Home: 50 KB
- Dashboard: 120 KB
- Predict: 150 KB (includes chart library)
- Admin: 80 KB

---

## 8. 404 Handling

### 8.1 Not Found Page

**Path**: `*` (catch-all)

**Component**: `client/src/pages/NotFound.tsx`

**Features**:
- 404 message
- Search functionality
- Link to home
- Recent pages (if logged in)

**Implementation**:
```typescript
<Route component={NotFound} />  // Catch-all at the end
```

---

**Route Summary Table**:

| Path | Component | Access | Required Permission |
|------|-----------|--------|---------------------|
| `/` | Home | Public | None |
| `/login` | Login | Public | None |
| `/register` | Register | Public | None |
| `/dashboard` | Dashboard | USER+ | None |
| `/predict` | Predict | USER+ | predictions.create |
| `/history` | History | USER+ | predictions.view |
| `/alerts` | Alerts | USER+ | alerts.list |
| `/settings` | Settings | USER+ | None (own) |
| `/logs` | Logs | USER+ | logs.view |
| `/admin` | Admin Dashboard | ADMIN | None |
| `/admin/users` | User Management | ADMIN | users.list |
| `/admin/assets` | Asset Management | ADMIN | assets.create |
| `/admin/settings` | System Settings | ADMIN | settings.system |

---

**Last Updated**: 2025-11-17  
**Next Review**: 2026-02-17  
**Version**: 3.0.0  
**Owner**: Frontend Team
