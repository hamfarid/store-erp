# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.0.x   | :white_check_mark: |
| 1.x.x   | :x:                |

## Reporting a Vulnerability

Please report security vulnerabilities to: security@goldpredictor.com

**Response Time:** Within 48 hours

## Security Measures

- ✅ JWT Authentication
- ✅ 2FA (TOTP)
- ✅ Rate Limiting (100 req/min)
- ✅ Input Sanitization
- ✅ Security Headers (CSP, HSTS)
- ✅ Audit Logging
- ✅ Secrets Management

**Version:** 1.0
