# Secrets Management
# إدارة الأسرار

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Current Implementation

### Environment Variables

All secrets stored in `.env` file (not committed to Git):

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost/db

# JWT
JWT_SECRET_KEY=<random-256-bit-key>
JWT_ALGORITHM=HS256

# Redis
REDIS_URL=redis://localhost:6379

# External APIs
GOLD_API_KEY=<api-key>
NEWS_API_KEY=<api-key>
```

---

## Best Practices

1. **Never commit secrets to Git**
2. **Use strong random keys** (256-bit minimum)
3. **Rotate secrets regularly** (90 days)
4. **Use different secrets per environment**
5. **Encrypt secrets at rest**

---

## Future: AWS Secrets Manager

```python
import boto3

client = boto3.client('secretsmanager')
secret = client.get_secret_value(SecretId='gold-predictor/jwt')
JWT_SECRET = secret['SecretString']
```

---

**Document Version:** 1.0
