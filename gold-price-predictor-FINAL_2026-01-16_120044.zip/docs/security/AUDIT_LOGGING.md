# Audit Logging
# سجلات التدقيق

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Logged Events

### Authentication Events

- User registration
- Login attempts (success/failure)
- Logout
- 2FA setup/verification
- Password changes
- Token refresh

### Authorization Events

- Permission denied
- Role changes
- API key creation/deletion

### Data Events

- Prediction requests
- Database queries
- Data exports

### Security Events

- Rate limit exceeded
- Suspicious activity
- Failed authentication
- JWT blacklist additions

---

## Log Format

```json
{
  "timestamp": "2025-10-28T10:00:00Z",
  "level": "INFO",
  "event_type": "user.login",
  "user_id": "uuid",
  "ip_address": "192.168.1.1",
  "user_agent": "Mozilla/5.0...",
  "request_id": "uuid",
  "details": {
    "success": true,
    "2fa_used": true
  }
}
```

---

## Retention Policy

| Log Type | Retention | Archive |
|----------|-----------|---------|
| Authentication | 90 days | 1 year |
| Authorization | 90 days | 1 year |
| Data Events | 30 days | 90 days |
| Security Events | 1 year | 5 years |

---

**Document Version:** 1.0
