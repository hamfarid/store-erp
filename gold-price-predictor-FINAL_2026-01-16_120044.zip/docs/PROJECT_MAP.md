# 🗺️ Gold Price Predictor - Complete Project Map

## 📁 Project Structure Overview

```
gold-price-predictor/
├── client/                    # Frontend (React + Vite)
├── server/                    # Backend (Express + tRPC)
├── scripts/                   # Setup & Admin Scripts
├── e2e/                       # Playwright E2E Tests
├── drizzle/                   # Database Schema (Drizzle ORM)
├── config/                    # Configuration Files
├── docs/                      # Documentation
├── ml_backend/                # Python ML Backend
└── data/                      # SQLite Database
```

---

## 🔧 Backend Modules

### Core Server (`server/_core/`)
| File | Purpose | Status |
|------|---------|--------|
| `index.ts` | Main server entry point | ✅ |
| `trpc.ts` | tRPC router setup | ✅ |
| `context.ts` | Request context creation | ✅ |
| `cookies.ts` | Cookie configuration | ✅ |
| `sessionMiddleware.ts` | Session handling | ✅ |
| `security.ts` | Session hijacking protection | ✅ |
| `rateLimiter.ts` | API rate limiting | ✅ |
| `auth-local.ts` | Local authentication | ✅ |
| `oauth.ts` | OAuth authentication | ✅ |
| `sdk.ts` | OAuth SDK integration | ✅ |
| `env.ts` | Environment variables | ✅ |
| `errorHandler.ts` | Error handling | ✅ |
| `systemRouter.ts` | System health endpoints | ✅ |
| `llm.ts` | LLM integration | ✅ |
| `validation.ts` | Input validation | ✅ |
| `vite.ts` | Vite dev server | ✅ |

### Database (`server/db*.ts`)
| File | Purpose | Status |
|------|---------|--------|
| `db-sqlite.ts` | SQLite database layer (130+ functions) | ✅ |
| `db.ts` | MySQL/Drizzle ORM layer | ✅ |
| `db-python.ts` | Python ML API client | ✅ |
| `db-portfolio.ts` | Portfolio database functions | ✅ |
| `db-ai-tasks.ts` | AI tasks database functions | ✅ |

### Routers (`server/routers/` + `server/routers*.ts`)

| Router | File | Procedures | Frontend Page |
|--------|------|------------|---------------|
| `auth` | `routers.ts` | me, logout, register, login | `/login`, `/register` |
| `assets` | `routers.ts` | getAll, list, getById, getCurrentPrices, create, update, delete | `/assets` |
| `predictions` | `routers.ts` | generate, getHistory, getById, update, delete, getAccuracyComparison | `/predictions` |
| `alerts` | `routers.ts` | getAll, create, list, update, delete, getById | `/alerts` |
| `users` | `routers.ts` | list, getById, updateRole, delete | `/admin/users` |
| `backup` | `routers.ts` | 13 procedures (export, import, backup, restore) | `/backup` |
| `aiLearning` | `routers.ts` | getStatistics, searchExamples, getExamplesByCategory, etc. | `/admin/ai-learning` |
| `monitoring` | `routers.ts` | getLearningTrends, getAuditLogs, getPriceAnalytics, etc. | `/analytics-monitoring` |
| `permissions` | `routers.ts` | getUserPermissions, create, revoke, check | `/admin/users/:id/permissions` |
| `historicalPrices` | `routers.ts` | list, getByAsset, getLatest | `/historical-prices` |
| `tradingSignals` | `routers.ts` | calculate, list, getByAsset | `/trading-signals` |
| `breakoutPoints` | `routers.ts` | calculate, list | `/price-points` |
| `breakEvenPoints` | `routers.ts` | calculate, list, delete | `/break-even-calculator` |
| `inflectionPoints` | `routers.ts` | calculate, list | `/price-points` |
| `performance` | `routers.ts` | getModelComparison, getAccuracyHistory | `/admin/model-performance` |
| `system` | `systemRouter.ts` | health, notifyOwner | `/api/health` |
| `export` | `routers-export.ts` | export procedures | `/admin/backup` |
| `logs` | `routers-logs.ts` | logError, getErrors, getMLTrainingHistory, etc. | `/system-health` |
| `dashboard` | `dashboard-router.ts` | getLivePrices, getRecentPredictions, getOverview | `/dashboard` |
| `notifications` | `notifications.ts` | getUserNotifications, getUnreadCount, markAsRead, etc. | `/notifications` |
| `ai` | `ai-router.ts` | chat, getConversations, getMemories, etc. | AI Widget |
| `portfolio` | `portfolio-router.ts` | create, list, get, update, delete, transactions, etc. | `/portfolio` |
| `aiTasks` | `ai-tasks-router.ts` | create, list, get, update, delete, getResults, etc. | `/ai-tasks` |
| `settings` | `settings-router.ts` | get, update, testEmail, reset, export, import | `/settings` |
| `reports` | `reports-router.ts` | portfolioReport, accuracyReport, exportCSV, etc. | `/reports` |
| `admin` | `admin-router.ts` | stats, users.*, assets.*, logs.*, database.*, config.* | `/admin` |
| `technicalIndicators` | `technical-indicators-router.ts` | calculate, getAll, getByType, etc. | `/technical-analysis` |
| `predictionsAdvanced` | `predictions-router.ts` | generate, generateThreeLevels, generateBatch | `/predictions/three-level` |
| `drift` | `drift.ts` | getDetections, createAlert, resolve | `/drift-detection` |
| `learningPath` | `learning-path.ts` | getUserPaths, create, update, delete, optimize | `/learning-path` |
| `expertOpinions` | `expert-opinions.ts` | list, create, scrapeUrl, getSocialSentiment | `/expert-opinions` |
| `security` | `security-router.ts` | getEvents, getSummary, forceLogout, etc. | `/security` |
| `models` | `models.ts` | list, getInfo, predict, healthCheck | `/ml-models` |
| `fearGreed` | `fear-greed-router.ts` | getCurrent, getHistory, getAnalysis, getSignal | `/fear-greed` |
| `newsSentiment` | `news-sentiment-router.ts` | getAssetSentiment, getLatestNews, analyzeText | `/news-sentiment` |
| `comprehensive` | `comprehensive-router.ts` | notifications.*, reports.*, kpis.*, activities.*, etc. | `/comprehensive` |

### Services (`server/services/`)
| Service | Purpose | Status |
|---------|---------|--------|
| `fear-greed-index.ts` | Fear & Greed Index API | ✅ |
| `news-sentiment.ts` | News sentiment analysis | ✅ |
| `social-sentiment.ts` | Social media sentiment | ✅ |
| `technical-indicators.ts` | Technical analysis | ✅ |
| `price-aggregator.ts` | Price data aggregation | ✅ |
| `realtime-price-updater.ts` | Live price updates | ✅ |
| `expert-opinion-analyzer.ts` | Expert opinion analysis | ✅ |
| `web-scraper.ts` | Web scraping | ✅ |
| `evaluation-metrics.ts` | ML model evaluation | ✅ |
| `ml-backend-client.ts` | ML API client | ✅ |
| `email-service.ts` | Email notifications | ✅ |

---

## 🎨 Frontend Pages

### Public Pages
| Path | Component | Backend Router |
|------|-----------|----------------|
| `/` | `Home.tsx` | - |
| `/login` | `Login.tsx` | `auth.login` |
| `/register` | `Register.tsx` | `auth.register` |
| `/about` | `About.tsx` | - |
| `/help` | `Help.tsx` | - |

### Protected Pages (User)
| Path | Component | Backend Router |
|------|-----------|----------------|
| `/dashboard` | `DashboardEnhanced.tsx` | `dashboard.*` |
| `/profile` | `UserProfile.tsx` | `auth.me` |
| `/assets` | `AssetsList.tsx` | `assets.*` |
| `/assets/create` | `AssetsCreate.tsx` | `assets.create` |
| `/assets/edit/:id` | `AssetsEdit.tsx` | `assets.update` |
| `/assets/view/:id` | `AssetsView.tsx` | `assets.getById` |
| `/predictions` | `Predictions.tsx` | `predictions.*` |
| `/predictions/three-level` | `ThreeLevelPredictions.tsx` | `predictionsAdvanced.*` |
| `/predict/:id` | `Predict.tsx` | `predictions.generate` |
| `/history` | `PredictionHistory.tsx` | `predictions.getHistory` |
| `/alerts` | `Alerts.tsx` | `alerts.*` |
| `/notifications` | `Notifications.tsx` | `notifications.*` |
| `/technical-analysis` | `TechnicalAnalysis.tsx` | `technicalIndicators.*` |
| `/trading-signals` | `TradingSignals.tsx` | `tradingSignals.*` |
| `/price-points` | `PricePoints.tsx` | `breakoutPoints.*, inflectionPoints.*` |
| `/break-even-calculator` | `BreakEvenCalculator.tsx` | `breakEvenPoints.*` |
| `/portfolio` | `Portfolio.tsx` | `portfolio.*` |
| `/settings` | `Settings.tsx` | `settings.*` |
| `/reports` | `Reports.tsx` | `reports.*` |
| `/fear-greed` | `FearGreedIndex.tsx` | `fearGreed.*` |
| `/news-sentiment` | `NewsSentiment.tsx` | `newsSentiment.*` |
| `/expert-opinions` | `ExpertOpinions.tsx` | `expertOpinions.*` |
| `/drift-detection` | `DriftDetection.tsx` | `drift.*` |
| `/learning` | `Learning.tsx` | - |
| `/learning-path` | `LearningPathOptimizer.tsx` | `learningPath.*` |
| `/ml-models` | `MLModels.tsx` | `models.*` |
| `/system-health` | `SystemHealth.tsx` | `logs.*` |
| `/ai-tasks` | `AITasks.tsx` | `aiTasks.*` |
| `/analytics-monitoring` | `AnalyticsMonitoring.tsx` | `monitoring.*` |

### Admin Pages
| Path | Component | Backend Router |
|------|-----------|----------------|
| `/admin` | `AdminDashboard.tsx` | `admin.stats` |
| `/admin/users` | `AdminUsers.tsx` | `admin.users.*` |
| `/admin/assets` | `AdminAssets.tsx` | `admin.assets.*` |
| `/admin/logs` | `AdminLogs.tsx` | `admin.logs.*` |
| `/admin/backup` | `BackupManagementAdvanced.tsx` | `backup.*` |
| `/admin/ai-learning` | `AILearningManagement.tsx` | `aiLearning.*` |
| `/admin/train-models` | `ModelTraining.tsx` | `models.*` |
| `/admin/model-performance` | `ModelPerformance.tsx` | `performance.*` |
| `/security` | `SecurityDashboard.tsx` | `security.*` |
| `/comprehensive` | `ComprehensiveManagement.tsx` | `comprehensive.*` |

### Error Pages
| Path | Component |
|------|-----------|
| `/error/400` | `Error400.tsx` |
| `/error/401` | `Error401.tsx` |
| `/error/402` | `Error402.tsx` |
| `/error/403` | `Error403.tsx` |
| `/error/404` | `NotFound.tsx` |
| `/error/405` | `Error405.tsx` |
| `/error/500` | `Error500.tsx` |
| `/error/501` | `Error501.tsx` |
| `/error/502` | `Error502.tsx` |
| `/error/503` | `Error503.tsx` |
| `/error/504` | `Error504.tsx` |
| `/error/505` | `Error505.tsx` |
| `/error/506` | `Error506.tsx` |
| `/maintenance` | `Maintenance.tsx` |

---

## 🗃️ Database Tables

| Table | Purpose | Indexes |
|-------|---------|---------|
| `users` | User accounts | email, role |
| `user_permissions` | User permissions | userId |
| `user_settings` | User preferences | userId |
| `assets` | Asset definitions | symbol |
| `historical_prices` | Price history | assetId, date |
| `predictions` | ML predictions | assetId, userId |
| `alerts` | Price alerts | userId, assetId |
| `notifications` | User notifications | userId, isRead |
| `portfolios` | User portfolios | userId |
| `transactions` | Portfolio transactions | portfolioId |
| `system_logs` | System logs | timestamp |
| `system_config` | System configuration | key |
| `saved_reports` | Saved reports | userId |
| `ai_conversations` | AI chat history | userId |
| `ai_memories` | AI RAG memories | userId |
| `expert_opinions` | Expert opinions | assetId |
| `drift_detections` | ML drift alerts | - |
| `learning_paths` | Learning paths | userId |
| `trading_signals` | Trading signals | assetId |
| `technical_indicators` | Technical indicators | assetId |
| `model_performance` | ML model metrics | modelType |
| `security_events` | Security audit | userId, eventType, timestamp |
| `breakout_points` | Price breakouts | assetId |
| `inflection_points` | Price inflections | assetId |
| `break_even_points` | Break-even prices | userId |

---

## 🔐 Security Features

| Feature | Implementation | Status |
|---------|----------------|--------|
| Session Hijacking Protection | IP + User-Agent binding | ✅ |
| CSRF Protection | Token-based validation | ✅ |
| Rate Limiting | 5 attempts / 15 min | ✅ |
| Brute Force Protection | 30 min lockout | ✅ |
| Security Headers | X-Frame, XSS, CSP, HSTS | ✅ |
| Session Timeout | 30 min inactivity | ✅ |
| Security Audit Log | All events logged | ✅ |
| Password Hashing | Argon2 | ✅ |
| JWT Sessions | HS256 signed | ✅ |

---

## 📊 Total Counts

- **Backend Routers**: 27
- **API Procedures**: 200+
- **Frontend Pages**: 70+
- **Database Functions**: 130+
- **Database Tables**: 25
- **Services**: 15+
- **Security Functions**: 17

---

## 📝 Testing Checklist

### Backend Tests
- [ ] All router procedures respond correctly
- [ ] Database functions work with SQLite
- [ ] Security middleware blocks attacks
- [ ] Rate limiting works correctly
- [ ] Session validation works

### Frontend Tests
- [ ] All pages render correctly
- [ ] Navigation links work
- [ ] Forms submit correctly
- [ ] Error pages display correctly
- [ ] Protected routes redirect

### Integration Tests
- [ ] Login/Register flow
- [ ] CRUD operations
- [ ] Real-time updates
- [ ] Error handling
- [ ] Session persistence

---

*Last Updated: December 2, 2025*

