# دليل تشغيل الاختبارات - Test Execution Guide

**التاريخ**: 2025-01-27

---

## 🚀 الخطوات السريعة

### الطريقة 1: استخدام السكريبت (موصى بها)

```powershell
# في PowerShell
.\scripts\run-e2e-tests.ps1
```

### الطريقة 2: يدوياً

```powershell
# Terminal 1: تشغيل السيرفر
npm run dev

# Terminal 2: تشغيل الاختبارات
npx playwright test e2e/tests/comprehensive-pages-test.spec.ts --project=chromium
```

---

## 📋 الاختبارات المتاحة

### 1. اختبار شامل لجميع الصفحات
```bash
npx playwright test e2e/tests/comprehensive-pages-test.spec.ts --project=chromium
```

**ما يختبره:**
- ✅ جميع الصفحات العامة (5 صفحات)
- ✅ جميع الصفحات المحمية (30+ صفحة)
- ✅ جميع صفحات المدير (10+ صفحة)
- ✅ جميع الأزرار والتفاعلات
- ✅ لقطات شاشة لكل صفحة

### 2. تحليل الأخطاء
```bash
npx playwright test e2e/tests/error-analysis.spec.ts --project=chromium
```

**ما يختبره:**
- ✅ Console errors
- ✅ Page errors
- ✅ Failed requests
- ✅ Broken links
- ✅ Loading states

### 3. اختبار الأزرار
```bash
npx playwright test e2e/tests/all-buttons-screenshots.spec.ts --project=chromium
```

**ما يختبره:**
- ✅ جميع الأزرار في جميع الصفحات
- ✅ حالات الأزرار (hover, click, disabled)
- ✅ لقطات شاشة للأزرار

---

## ⚙️ خيارات التشغيل

### تشغيل مع UI (headed mode)
```bash
npx playwright test --headed
```

### تشغيل في متصفح محدد
```bash
# Chrome
npx playwright test --project=chromium

# Firefox
npx playwright test --project=firefox

# Safari
npx playwright test --project=webkit
```

### تشغيل اختبار محدد
```bash
npx playwright test --grep "Home Page"
```

### تشغيل مع timeout أطول
```bash
npx playwright test --timeout=300000
```

---

## 📊 عرض النتائج

### تقرير HTML
```bash
npx playwright show-report
```

### لقطات الشاشة
- **المسار**: `screenshots/`
- **التنسيق**: PNG
- **الاسم**: `{PageName}-{suffix}.png`

---

## 🔧 استكشاف الأخطاء

### السيرفر لا يعمل
```bash
# تحقق من المنفذ
netstat -ano | findstr ":2505"

# تحقق من العملية
Get-Process | Where-Object { $_.ProcessName -eq "node" }
```

### الاختبارات تفشل
```bash
# شغل مع debug
DEBUG=pw:api npx playwright test

# شغل مع trace
npx playwright test --trace on
```

### Timeout errors
```bash
# زيادة timeout في playwright.config.ts
timeout: 180 * 1000  // 3 دقائق
```

---

## 📝 ملاحظات

1. **السيرفر يحتاج 10-15 ثانية للبدء**
2. **بعض الصفحات تحتاج تسجيل دخول**
3. **جميع لقطات الشاشة تُحفظ تلقائياً**
4. **التقارير تُنشأ في `playwright-report/`**

---

## ✅ Checklist

- [ ] السيرفر يعمل على `http://localhost:2505`
- [ ] جميع الحاويات Docker نشطة
- [ ] قاعدة البيانات متصلة
- [ ] Playwright مثبت (`npx playwright --version`)
- [ ] مجلد `screenshots/` موجود

---

**آخر تحديث**: 2025-01-27

