# API CONTRACTS - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/API_Contracts.md | **PURPOSE**: Complete API documentation (OpenAPI 3.0) | **OWNER**: API Team | **RELATED**: ARCHITECTURE.md, DB_Schema.md, backend/app/main.py, server/routers.ts | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**API Base URL (Production)**: `https://api.goldpredictor.com/api/v1`  
**API Base URL (Development)**: `http://localhost:2005/api`  
**tRPC URL**: `http://localhost:5000/trpc`

---

## Table of Contents
1. [Overview](#1-overview)
2. [OpenAPI 3.0 Specification](#2-openapi-30-specification)
3. [Authentication](#3-authentication)
4. [REST API Endpoints (FastAPI)](#4-rest-api-endpoints-fastapi)
5. [tRPC Procedures](#5-trpc-procedures)
6. [ML Engine API](#6-ml-engine-api)
7. [Request/Response Examples](#7-requestresponse-examples)
8. [Error Handling](#8-error-handling)
9. [Rate Limiting](#9-rate-limiting)
10. [Webhooks](#10-webhooks)
11. [Versioning Strategy](#11-versioning-strategy)
12. [Deprecation Policy](#12-deprecation-policy)

---

## 1. Overview

### 1.1 API Architecture

The system provides **3 API layers**:

1. **REST API (FastAPI)** - Public API for external integrations
   - Base URL: `/api/v1/*`
   - Authentication: JWT Bearer tokens, API keys
   - Response Format: JSON

2. **tRPC API (Node.js)** - Type-safe internal API for frontend
   - Base URL: `/trpc/*`
   - Authentication: Session cookies
   - Response Format: Type-safe JSON (auto-generated TypeScript types)

3. **ML Engine API (FastAPI)** - Internal ML prediction service
   - Base URL: Internal only (not exposed publicly)
   - Authentication: Internal service tokens
   - Response Format: JSON

### 1.2 API Statistics

| Metric | Value |
|--------|-------|
| Total REST Endpoints | 18 |
| Total tRPC Procedures | 22 |
| Total ML Endpoints | 7 |
| Authentication Methods | 3 (JWT, API Key, Session) |
| Rate Limits | 100-1000 req/min |
| Average Response Time | <200ms |
| API Uptime | 99.5% |

### 1.3 API Design Principles

**RESTful Conventions**:
- Resources: Nouns (e.g., `/users`, `/predictions`, `/alerts`)
- Actions: HTTP verbs (GET, POST, PUT, PATCH, DELETE)
- Nested resources: `/assets/{id}/predictions`
- Filtering: Query parameters (e.g., `?limit=10&status=active`)

**Response Envelopes**:
```json
{
  "success": true,
  "data": {...},
  "message": "Operation successful",
  "meta": {
    "timestamp": "2025-11-17T12:00:00Z",
    "traceId": "abc-123-def-456"
  }
}
```

---

## 2. OpenAPI 3.0 Specification

### 2.1 OpenAPI Document (YAML)

```yaml
openapi: 3.0.3
info:
  title: Gold & Assets Price Prediction API
  description: |
    Production-ready API for ML-powered financial price predictions.
    
    ## Features
    - **8 ML Models**: ARIMA, SARIMA, Prophet, Random Forest, XGBoost, LSTM, NN, TA
    - **99.03% Accuracy**: Ensemble model with confidence intervals
    - **18 Assets**: Gold, silver, crypto, forex, indices
    - **Advanced Security**: JWT + 2FA, rate limiting, audit logging
    
    ## Authentication
    Use JWT Bearer tokens obtained from `/api/auth/login`.
    
    ## Rate Limiting
    - Authenticated users: 100 req/min, 1000 req/hour
    - API keys: 1000 req/min, 10000 req/hour
    - Anonymous: 10 req/min, 100 req/hour
    
  version: 3.0.0
  contact:
    name: API Support
    email: support@goldpredictor.com
    url: https://goldpredictor.com/support
  license:
    name: Proprietary
    url: https://goldpredictor.com/license

servers:
  - url: https://api.goldpredictor.com/api/v1
    description: Production server
  - url: https://staging.goldpredictor.com/api/v1
    description: Staging server
  - url: http://localhost:2005/api
    description: Development server

tags:
  - name: Health
    description: Health check and system status endpoints
  - name: Authentication
    description: User registration, login, and JWT token management
  - name: 2FA
    description: Two-factor authentication setup and verification
  - name: API Keys
    description: API key creation and management
  - name: Predictions
    description: ML price predictions with confidence intervals
  - name: Assets
    description: Asset information and current prices
  - name: Alerts
    description: Price alert creation and management
  - name: Users
    description: User profile and settings

paths:
  /health:
    get:
      tags: [Health]
      summary: Health check
      description: Returns API health status and version
      operationId: healthCheck
      responses:
        '200':
          description: API is healthy
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:
                    type: string
                    enum: [healthy, degraded, unhealthy]
                    example: healthy
                  timestamp:
                    type: string
                    format: date-time
                    example: "2025-11-17T12:00:00Z"
                  version:
                    type: string
                    example: "3.0.0"
                  services:
                    type: object
                    properties:
                      database:
                        type: string
                        enum: [up, down]
                      redis:
                        type: string
                        enum: [up, down]
                      ml_engine:
                        type: string
                        enum: [up, down]

  /auth/register:
    post:
      tags: [Authentication]
      summary: Register new user
      description: Create a new user account with username, email, and password
      operationId: registerUser
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UserCreate'
      responses:
        '200':
          description: User registered successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Token'
        '400':
          description: Invalid input or user already exists
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
              examples:
                userExists:
                  value:
                    success: false
                    code: "USER_EXISTS"
                    message: "Username or email already registered"
                invalidPassword:
                  value:
                    success: false
                    code: "INVALID_PASSWORD"
                    message: "Password must be at least 8 characters with uppercase, lowercase, and digit"

  /auth/login:
    post:
      tags: [Authentication]
      summary: User login
      description: Authenticate user and return JWT tokens
      operationId: loginUser
      requestBody:
        required: true
        content:
          application/x-www-form-urlencoded:
            schema:
              type: object
              required: [username, password]
              properties:
                username:
                  type: string
                  example: "john_doe"
                password:
                  type: string
                  format: password
                  example: "SecurePass123"
      responses:
        '200':
          description: Login successful
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Token'
        '401':
          description: Invalid credentials
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
              example:
                success: false
                code: "INVALID_CREDENTIALS"
                message: "Incorrect username or password"

  /auth/me:
    get:
      tags: [Authentication]
      summary: Get current user
      description: Returns authenticated user information
      operationId: getCurrentUser
      security:
        - BearerAuth: []
      responses:
        '200':
          description: User information
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/UserResponse'
        '401':
          $ref: '#/components/responses/UnauthorizedError'

  /auth/2fa/setup:
    post:
      tags: [2FA]
      summary: Setup 2FA
      description: Generate QR code and secret for 2FA setup
      operationId: setup2FA
      security:
        - BearerAuth: []
      responses:
        '200':
          description: 2FA setup information
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TwoFactorSetupResponse'

  /auth/2fa/verify:
    post:
      tags: [2FA]
      summary: Verify and enable 2FA
      description: Verify TOTP token and enable 2FA for user
      operationId: verify2FA
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TwoFactorVerifyRequest'
      responses:
        '200':
          description: 2FA enabled successfully
          content:
            application/json:
              schema:
                type: object
                properties:
                  message:
                    type: string
                    example: "2FA enabled successfully"
        '400':
          description: Invalid token
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

  /auth/2fa/disable:
    post:
      tags: [2FA]
      summary: Disable 2FA
      description: Disable two-factor authentication for user
      operationId: disable2FA
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TwoFactorVerifyRequest'
      responses:
        '200':
          description: 2FA disabled successfully
        '400':
          description: Invalid token

  /keys:
    post:
      tags: [API Keys]
      summary: Create API key
      description: Generate new API key for programmatic access
      operationId: createAPIKey
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/APIKeyCreate'
      responses:
        '200':
          description: API key created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/APIKeyResponse'
    
    get:
      tags: [API Keys]
      summary: List API keys
      description: Get all API keys for current user
      operationId: listAPIKeys
      security:
        - BearerAuth: []
      responses:
        '200':
          description: List of API keys
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/APIKeyListResponse'

  /keys/{key_id}:
    delete:
      tags: [API Keys]
      summary: Delete API key
      description: Revoke an API key by ID
      operationId: deleteAPIKey
      security:
        - BearerAuth: []
      parameters:
        - name: key_id
          in: path
          required: true
          schema:
            type: integer
          description: API key ID
      responses:
        '200':
          description: API key deleted
          content:
            application/json:
              schema:
                type: object
                properties:
                  message:
                    type: string
                    example: "API key deleted successfully"
        '404':
          description: API key not found

  /keys/stats:
    get:
      tags: [API Keys]
      summary: API key usage statistics
      description: Get usage statistics for all user's API keys
      operationId: getAPIKeyStats
      security:
        - BearerAuth: []
      responses:
        '200':
          description: API key statistics
          content:
            application/json:
              schema:
                type: object
                properties:
                  total_keys:
                    type: integer
                    example: 3
                  active_keys:
                    type: integer
                    example: 2
                  total_requests_today:
                    type: integer
                    example: 1450
                  total_requests_month:
                    type: integer
                    example: 42500

  /predict:
    post:
      tags: [Predictions]
      summary: Generate price prediction
      description: |
        Generate ML-powered price prediction for specified asset and horizon.
        Uses ensemble of 8 models (ARIMA, SARIMA, Prophet, RF, XGBoost, LSTM, NN, TA).
      operationId: generatePrediction
      security:
        - BearerAuth: []
        - APIKeyAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PredictionRequest'
      responses:
        '200':
          description: Prediction generated successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/PredictionResponse'
        '400':
          description: Invalid input
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
              examples:
                invalidSymbol:
                  value:
                    success: false
                    code: "INVALID_SYMBOL"
                    message: "Invalid symbol. Must be one of: GOLD, SILVER, BTC, ETH, EUR/USD, etc."
                invalidHorizon:
                  value:
                    success: false
                    code: "INVALID_HORIZON"
                    message: "Horizon must be one of: short, medium, long"

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
      description: |
        JWT token obtained from `/api/auth/login`.
        
        **Format**: `Authorization: Bearer <token>`
        
        **Token Lifetime**:
        - Access token: 15 minutes
        - Refresh token: 7 days
    
    APIKeyAuth:
      type: apiKey
      in: header
      name: X-API-Key
      description: |
        API key for programmatic access.
        Obtain from `/api/keys` endpoint.
        
        **Format**: `X-API-Key: gpk_live_abc123def456...`

  schemas:
    UserCreate:
      type: object
      required: [username, email, password]
      properties:
        username:
          type: string
          minLength: 3
          maxLength: 50
          pattern: '^[a-zA-Z0-9_]+$'
          example: "john_doe"
          description: "Alphanumeric username (3-50 characters)"
        email:
          type: string
          format: email
          example: "john@example.com"
          description: "Valid email address"
        password:
          type: string
          minLength: 8
          format: password
          example: "SecurePass123"
          description: "Password (min 8 chars, must contain uppercase, lowercase, digit)"

    Token:
      type: object
      required: [access_token, refresh_token, token_type]
      properties:
        access_token:
          type: string
          example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
          description: "JWT access token (15 min expiry)"
        refresh_token:
          type: string
          example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
          description: "JWT refresh token (7 day expiry)"
        token_type:
          type: string
          enum: [bearer]
          example: "bearer"

    UserResponse:
      type: object
      properties:
        id:
          type: integer
          example: 42
        username:
          type: string
          example: "john_doe"
        email:
          type: string
          format: email
          example: "john@example.com"
        is_2fa_enabled:
          type: boolean
          example: false
          description: "Whether 2FA is enabled for this user"
        created_at:
          type: string
          format: date-time
          example: "2025-11-17T12:00:00Z"

    TwoFactorSetupResponse:
      type: object
      required: [qr_code, secret]
      properties:
        qr_code:
          type: string
          format: uri
          example: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."
          description: "Base64-encoded QR code image (data URI)"
        secret:
          type: string
          example: "JBSWY3DPEHPK3PXP"
          description: "Base32-encoded TOTP secret (backup)"

    TwoFactorVerifyRequest:
      type: object
      required: [token]
      properties:
        token:
          type: string
          pattern: '^\d{6}$'
          example: "123456"
          description: "6-digit TOTP token from authenticator app"

    APIKeyCreate:
      type: object
      required: [name]
      properties:
        name:
          type: string
          minLength: 3
          maxLength: 100
          example: "Production API"
          description: "Descriptive name for the API key"
        expires_in_days:
          type: integer
          minimum: 1
          maximum: 3650
          default: 365
          example: 365
          description: "Expiry in days (default 365, max 3650)"

    APIKeyResponse:
      type: object
      properties:
        id:
          type: integer
          example: 10
        name:
          type: string
          example: "Production API"
        key:
          type: string
          nullable: true
          example: "gpk_live_abc123def456ghi789jkl012mno345"
          description: "Plain API key (only returned on creation, never shown again)"
        is_active:
          type: boolean
          example: true
        request_count:
          type: integer
          example: 1250
          description: "Total requests made with this key"
        created_at:
          type: string
          format: date-time
          example: "2025-11-17T12:00:00Z"
        expires_at:
          type: string
          format: date-time
          nullable: true
          example: "2026-11-17T12:00:00Z"
        last_used_at:
          type: string
          format: date-time
          nullable: true
          example: "2025-11-17T11:59:00Z"

    APIKeyListResponse:
      type: object
      properties:
        id:
          type: integer
          example: 10
        name:
          type: string
          example: "Production API"
        is_active:
          type: boolean
          example: true
        request_count:
          type: integer
          example: 1250
        created_at:
          type: string
          format: date-time
        expires_at:
          type: string
          format: date-time
          nullable: true
        last_used_at:
          type: string
          format: date-time
          nullable: true

    PredictionRequest:
      type: object
      required: [symbol]
      properties:
        symbol:
          type: string
          enum: [GOLD, SILVER, BTC, ETH, "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "NZD/USD", "USD/CHF", "USD/CNY", "TRY/USD", "EGP/USD", "SAR/USD", "AED/USD", "KWD/USD", "QAR/USD"]
          example: "GOLD"
          description: "Asset symbol to predict"
        horizon:
          type: string
          enum: [short, medium, long]
          default: short
          example: "short"
          description: |
            Prediction horizon:
            - short: 1-7 days
            - medium: 7-30 days
            - long: 30+ days
        include_sentiment:
          type: boolean
          default: true
          example: true
          description: "Include sentiment analysis in prediction"
        include_economic_data:
          type: boolean
          default: true
          example: true
          description: "Include economic indicators in prediction"

    PredictionResponse:
      type: object
      properties:
        symbol:
          type: string
          example: "GOLD"
        current_price:
          type: number
          format: float
          example: 1950.50
          description: "Current price at prediction time"
        predicted_price:
          type: number
          format: float
          example: 1975.20
          description: "Predicted price (ensemble average)"
        change_percent:
          type: number
          format: float
          example: 1.27
          description: "Predicted change percentage"
        confidence:
          type: number
          format: float
          minimum: 0
          maximum: 1
          example: 0.9903
          description: "Prediction confidence (0.0-1.0)"
        confidence_lower:
          type: number
          format: float
          example: 1960.00
          description: "Lower bound of 95% confidence interval"
        confidence_upper:
          type: number
          format: float
          example: 1990.00
          description: "Upper bound of 95% confidence interval"
        horizon:
          type: string
          example: "short"
        timestamp:
          type: string
          format: date-time
          example: "2025-11-17T12:00:00Z"
        sentiment_score:
          type: number
          format: float
          nullable: true
          example: 0.65
          description: "Sentiment score (-1.0 to 1.0, null if not requested)"
        economic_indicators:
          type: object
          nullable: true
          additionalProperties:
            type: number
          example:
            gdp_growth: 2.5
            inflation_rate: 3.2
            unemployment_rate: 4.1
          description: "Economic indicators (null if not requested)"
        model_breakdown:
          type: object
          description: "Individual model predictions"
          properties:
            ARIMA:
              type: number
              example: 1972.30
            SARIMA:
              type: number
              example: 1968.50
            Prophet:
              type: number
              example: 1980.10
            RandomForest:
              type: number
              example: 1973.40
            XGBoost:
              type: number
              example: 1978.90
            LSTM:
              type: number
              example: 1976.20
            NeuralNetwork:
              type: number
              example: 1971.80
            TechnicalAnalysis:
              type: number
              example: 1970.50

    Error:
      type: object
      required: [success, code, message]
      properties:
        success:
          type: boolean
          enum: [false]
          example: false
        code:
          type: string
          example: "INVALID_INPUT"
          description: "Machine-readable error code"
        message:
          type: string
          example: "Invalid input provided"
          description: "Human-readable error message"
        details:
          type: object
          nullable: true
          additionalProperties: true
          example:
            field: "symbol"
            reason: "Symbol not found"
          description: "Additional error details (optional)"
        traceId:
          type: string
          format: uuid
          example: "550e8400-e29b-41d4-a716-446655440000"
          description: "Unique trace ID for debugging"
        timestamp:
          type: string
          format: date-time
          example: "2025-11-17T12:00:00Z"

  responses:
    UnauthorizedError:
      description: Unauthorized - Missing or invalid authentication
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Error'
          example:
            success: false
            code: "UNAUTHORIZED"
            message: "Invalid or expired token"
            traceId: "550e8400-e29b-41d4-a716-446655440000"
    
    ForbiddenError:
      description: Forbidden - Insufficient permissions
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Error'
          example:
            success: false
            code: "FORBIDDEN"
            message: "Insufficient permissions to access this resource"
    
    RateLimitError:
      description: Rate limit exceeded
      headers:
        X-RateLimit-Limit:
          schema:
            type: integer
          description: Rate limit ceiling for this request
        X-RateLimit-Remaining:
          schema:
            type: integer
          description: Number of requests left for the time window
        X-RateLimit-Reset:
          schema:
            type: integer
          description: Unix timestamp when rate limit resets
        Retry-After:
          schema:
            type: integer
          description: Seconds to wait before retrying
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Error'
          example:
            success: false
            code: "RATE_LIMIT_EXCEEDED"
            message: "Rate limit exceeded. Please try again later."
            details:
              limit: 100
              window: "1 minute"
              reset_at: "2025-11-17T12:01:00Z"

  examples:
    PredictionGold7Days:
      summary: Gold prediction for 7 days
      value:
        symbol: "GOLD"
        horizon: "short"
        include_sentiment: true
        include_economic_data: true
    
    PredictionBTC30Days:
      summary: Bitcoin prediction for 30 days
      value:
        symbol: "BTC"
        horizon: "medium"
        include_sentiment: false
        include_economic_data: false
```

---

## 3. Authentication

### 3.1 JWT Authentication

**Token Flow**:
```mermaid
sequenceDiagram
    participant Client
    participant API
    participant Auth
    participant DB
    
    Client->>API: POST /api/auth/login
    API->>Auth: Validate credentials
    Auth->>DB: Query user
    DB-->>Auth: User data
    Auth->>Auth: Generate JWT tokens
    Auth-->>API: Access + Refresh tokens
    API-->>Client: 200 OK + tokens
    
    Client->>API: GET /api/predict (with token)
    API->>Auth: Validate JWT
    Auth-->>API: Valid user
    API-->>Client: 200 OK + prediction
```

**JWT Token Structure**:
```json
{
  "header": {
    "alg": "HS256",
    "typ": "JWT"
  },
  "payload": {
    "sub": "john_doe",
    "user_id": 42,
    "exp": 1700010000,
    "iat": 1700000000,
    "jti": "550e8400-e29b-41d4-a716-446655440000"
  },
  "signature": "..."
}
```

**Token Lifetime**:
- Access token: 15 minutes
- Refresh token: 7 days

### 3.2 API Key Authentication

**API Key Format**: `gpk_live_<32_chars_base62>`

**Example**: `gpk_live_abc123def456ghi789jkl012mno345`

**Usage**:
```bash
curl -H "X-API-Key: gpk_live_abc123def456..." \
  https://api.goldpredictor.com/api/v1/predict
```

### 3.3 Session Authentication (tRPC)

**Cookie Name**: `gold-predictor-session`  
**Cookie Attributes**: `HttpOnly`, `Secure`, `SameSite=Lax`  
**Lifetime**: 7 days

---

## 4. REST API Endpoints (FastAPI)

### 4.1 Health Check

#### GET /api/health

**Description**: Check API health status

**Authentication**: None

**Response**:
```json
{
  "status": "healthy",
  "timestamp": "2025-11-17T12:00:00Z",
  "version": "3.0.0",
  "services": {
    "database": "up",
    "redis": "up",
    "ml_engine": "up"
  }
}
```

---

### 4.2 Authentication Endpoints

#### POST /api/auth/register

**Description**: Register new user

**Request Body**:
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

**Response (200)**:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

---

#### POST /api/auth/login

**Description**: User login

**Request Body** (form-urlencoded):
```
username=john_doe&password=SecurePass123
```

**Response (200)**:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

---

#### GET /api/auth/me

**Description**: Get current user

**Authentication**: Bearer token required

**Response (200)**:
```json
{
  "id": 42,
  "username": "john_doe",
  "email": "john@example.com",
  "is_2fa_enabled": false,
  "created_at": "2025-11-17T12:00:00Z"
}
```

---

### 4.3 Two-Factor Authentication

#### POST /api/auth/2fa/setup

**Description**: Setup 2FA for user

**Authentication**: Bearer token required

**Response (200)**:
```json
{
  "qr_code": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
  "secret": "JBSWY3DPEHPK3PXP"
}
```

---

#### POST /api/auth/2fa/verify

**Description**: Verify and enable 2FA

**Authentication**: Bearer token required

**Request Body**:
```json
{
  "token": "123456"
}
```

**Response (200)**:
```json
{
  "message": "2FA enabled successfully"
}
```

---

### 4.4 API Key Management

#### POST /api/keys

**Description**: Create new API key

**Authentication**: Bearer token required

**Request Body**:
```json
{
  "name": "Production API",
  "expires_in_days": 365
}
```

**Response (200)**:
```json
{
  "id": 10,
  "name": "Production API",
  "key": "gpk_live_abc123def456ghi789jkl012mno345",
  "is_active": true,
  "request_count": 0,
  "created_at": "2025-11-17T12:00:00Z",
  "expires_at": "2026-11-17T12:00:00Z",
  "last_used_at": null
}
```

⚠️ **Warning**: The plain `key` is only returned once. Store it securely.

---

#### GET /api/keys

**Description**: List all API keys for current user

**Authentication**: Bearer token required

**Response (200)**:
```json
[
  {
    "id": 10,
    "name": "Production API",
    "is_active": true,
    "request_count": 1250,
    "created_at": "2025-11-17T12:00:00Z",
    "expires_at": "2026-11-17T12:00:00Z",
    "last_used_at": "2025-11-17T11:59:00Z"
  },
  {
    "id": 11,
    "name": "Development API",
    "is_active": false,
    "request_count": 42,
    "created_at": "2025-10-01T12:00:00Z",
    "expires_at": "2026-10-01T12:00:00Z",
    "last_used_at": "2025-10-15T10:30:00Z"
  }
]
```

---

#### DELETE /api/keys/{key_id}

**Description**: Revoke API key

**Authentication**: Bearer token required

**Path Parameters**:
- `key_id` (integer, required): API key ID

**Response (200)**:
```json
{
  "message": "API key deleted successfully"
}
```

---

### 4.5 Predictions

#### POST /api/predict

**Description**: Generate price prediction

**Authentication**: Bearer token or API key required

**Request Body**:
```json
{
  "symbol": "GOLD",
  "horizon": "short",
  "include_sentiment": true,
  "include_economic_data": true
}
```

**Response (200)**:
```json
{
  "symbol": "GOLD",
  "current_price": 1950.50,
  "predicted_price": 1975.20,
  "change_percent": 1.27,
  "confidence": 0.9903,
  "confidence_lower": 1960.00,
  "confidence_upper": 1990.00,
  "horizon": "short",
  "timestamp": "2025-11-17T12:00:00Z",
  "sentiment_score": 0.65,
  "economic_indicators": {
    "gdp_growth": 2.5,
    "inflation_rate": 3.2,
    "unemployment_rate": 4.1
  },
  "model_breakdown": {
    "ARIMA": 1972.30,
    "SARIMA": 1968.50,
    "Prophet": 1980.10,
    "RandomForest": 1973.40,
    "XGBoost": 1978.90,
    "LSTM": 1976.20,
    "NeuralNetwork": 1971.80,
    "TechnicalAnalysis": 1970.50
  }
}
```

---

## 5. tRPC Procedures

### 5.1 System

#### system.health

**Type**: Query  
**Auth**: Public  
**Description**: Get system health status

**Response**:
```typescript
{
  status: 'healthy' | 'degraded' | 'unhealthy',
  timestamp: Date,
  version: string
}
```

---

### 5.2 Authentication

#### auth.me

**Type**: Query  
**Auth**: Public (returns null if not authenticated)  
**Description**: Get current session user

**Response**:
```typescript
{
  id: string,
  name: string | null,
  email: string | null,
  role: 'admin' | 'user'
} | null
```

---

#### auth.logout

**Type**: Mutation  
**Auth**: Public  
**Description**: Logout current user

**Response**:
```typescript
{
  success: true
}
```

---

### 5.3 Assets

#### assets.list

**Type**: Query  
**Auth**: Public  
**Description**: Get all assets

**Response**:
```typescript
Array<{
  id: number,
  name: string,
  symbol: string,
  category: string,
  isActive: boolean
}>
```

---

#### assets.getById

**Type**: Query  
**Auth**: Public  
**Input**:
```typescript
{ id: number }
```

**Response**:
```typescript
{
  id: number,
  name: string,
  symbol: string,
  category: string,
  isActive: boolean,
  createdAt: number
}
```

---

#### assets.getCurrentPrices

**Type**: Query  
**Auth**: Public  
**Description**: Get current prices for all active assets

**Response**:
```typescript
Array<{
  assetId: number,
  symbol: string,
  price: string,
  timestamp: number
}>
```

---

### 5.4 Predictions

#### predictions.generate

**Type**: Mutation  
**Auth**: Protected (requires authentication)  
**Input**:
```typescript
{
  assetId: number,
  horizon: 'short' | 'medium' | 'long',
  modelType: 'simple' | 'advanced' | 'ensemble',
  confidenceLevel?: number // 0.8-0.99, default 0.95
}
```

**Response**:
```typescript
{
  id: number,
  assetId: number,
  currentPrice: string,
  predictedPrice: string,
  confidenceLower: string,
  confidenceUpper: string,
  modelType: string,
  accuracy: string,
  targetDate: number,
  createdAt: number
}
```

---

#### predictions.getHistory

**Type**: Query  
**Auth**: Protected  
**Input**:
```typescript
{
  assetId?: number, // Optional: filter by asset
  limit?: number    // Default: 10
}
```

**Response**:
```typescript
Array<{
  id: number,
  assetId: number,
  predictedPrice: string,
  targetDate: number,
  accuracy: string,
  createdAt: number
}>
```

---

### 5.5 Alerts

#### alerts.create

**Type**: Mutation  
**Auth**: Protected  
**Input**:
```typescript
{
  assetId: number,
  condition: 'above' | 'below' | 'change',
  threshold: number,
  channels: Array<'email' | 'push' | 'telegram'>
}
```

**Response**:
```typescript
{
  id: number,
  assetId: number,
  alertType: string,
  targetPrice: string,
  isActive: boolean
}
```

---

#### alerts.list

**Type**: Query  
**Auth**: Protected  
**Description**: Get all alerts for current user

**Response**:
```typescript
Array<{
  id: number,
  assetId: number,
  alertType: string,
  targetPrice: string | null,
  isActive: boolean,
  isTriggered: boolean,
  notificationMethod: string
}>
```

---

## 6. ML Engine API

### 6.1 Prediction Endpoints

#### POST /predict

**Description**: Generate single prediction (internal)

**Request**:
```json
{
  "asset": "GOLD",
  "days_ahead": 7,
  "model_type": "ensemble"
}
```

**Response**:
```json
{
  "asset": "GOLD",
  "current_price": 1950.50,
  "predicted_price": 1975.20,
  "confidence_interval": [1960.00, 1990.00],
  "model_accuracy": 0.9903,
  "models_used": ["ARIMA", "LSTM", "XGBoost", "Prophet", "RF", "SARIMA", "NN", "TA"]
}
```

---

#### POST /predict/multiple

**Description**: Generate predictions for multiple days

**Request**:
```json
{
  "asset": "GOLD",
  "days": [1, 7, 14, 30]
}
```

**Response**:
```json
{
  "asset": "GOLD",
  "predictions": [
    {
      "days_ahead": 1,
      "predicted_price": 1952.30,
      "confidence_interval": [1948.00, 1956.60]
    },
    {
      "days_ahead": 7,
      "predicted_price": 1975.20,
      "confidence_interval": [1960.00, 1990.00]
    },
    {
      "days_ahead": 14,
      "predicted_price": 1995.80,
      "confidence_interval": [1975.00, 2016.60]
    },
    {
      "days_ahead": 30,
      "predicted_price": 2025.40,
      "confidence_interval": [1990.00, 2060.80]
    }
  ]
}
```

---

#### GET /models/{asset}

**Description**: Get model information for asset

**Response**:
```json
{
  "asset": "GOLD",
  "models": [
    {
      "name": "ARIMA",
      "accuracy": 0.9856,
      "last_trained": "2025-11-17T03:00:00Z"
    },
    {
      "name": "LSTM",
      "accuracy": 0.9912,
      "last_trained": "2025-11-17T03:15:00Z"
    }
  ],
  "ensemble_accuracy": 0.9903
}
```

---

## 7. Request/Response Examples

### 7.1 Complete Prediction Flow

**Step 1: Login**
```bash
curl -X POST https://api.goldpredictor.com/api/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=john_doe&password=SecurePass123"
```

**Response**:
```json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "token_type": "bearer"
}
```

**Step 2: Generate Prediction**
```bash
curl -X POST https://api.goldpredictor.com/api/predict \
  -H "Authorization: Bearer eyJhbGc..." \
  -H "Content-Type: application/json" \
  -d '{
    "symbol": "GOLD",
    "horizon": "short",
    "include_sentiment": true,
    "include_economic_data": true
  }'
```

**Response**:
```json
{
  "symbol": "GOLD",
  "current_price": 1950.50,
  "predicted_price": 1975.20,
  "change_percent": 1.27,
  "confidence": 0.9903,
  "confidence_lower": 1960.00,
  "confidence_upper": 1990.00,
  "horizon": "short",
  "timestamp": "2025-11-17T12:00:00Z",
  "sentiment_score": 0.65,
  "economic_indicators": {
    "gdp_growth": 2.5,
    "inflation_rate": 3.2
  }
}
```

---

## 8. Error Handling

### 8.1 Error Response Format

```json
{
  "success": false,
  "code": "ERROR_CODE",
  "message": "Human-readable error message",
  "details": {
    "field": "specific_field",
    "reason": "detailed_reason"
  },
  "traceId": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2025-11-17T12:00:00Z"
}
```

### 8.2 Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| UNAUTHORIZED | 401 | Missing or invalid authentication |
| FORBIDDEN | 403 | Insufficient permissions |
| INVALID_INPUT | 400 | Invalid request parameters |
| USER_EXISTS | 400 | Username/email already registered |
| INVALID_CREDENTIALS | 401 | Wrong username/password |
| INVALID_TOKEN | 401 | Invalid or expired JWT token |
| INVALID_2FA_TOKEN | 400 | Invalid 2FA verification code |
| INVALID_SYMBOL | 400 | Unsupported asset symbol |
| INVALID_HORIZON | 400 | Invalid prediction horizon |
| RATE_LIMIT_EXCEEDED | 429 | Too many requests |
| PREDICTION_FAILED | 500 | ML prediction error |
| DATABASE_ERROR | 500 | Database connection error |
| REDIS_ERROR | 500 | Redis connection error |
| INTERNAL_ERROR | 500 | Unexpected server error |

---

## 9. Rate Limiting

### 9.1 Rate Limit Tiers

| User Type | Per Minute | Per Hour | Per Day |
|-----------|------------|----------|---------|
| Anonymous | 10 | 100 | 1,000 |
| Authenticated | 100 | 1,000 | 10,000 |
| API Key (Free) | 100 | 1,000 | 10,000 |
| API Key (Pro) | 1,000 | 10,000 | 100,000 |
| API Key (Enterprise) | Unlimited | Unlimited | Unlimited |

### 9.2 Rate Limit Headers

Every response includes:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1700000060
```

When rate limited:
```
HTTP/1.1 429 Too Many Requests
Retry-After: 60
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1700000120
```

---

## 10. Webhooks

### 10.1 Alert Webhooks

**Trigger**: When price alert is triggered

**Method**: POST

**Headers**:
```
Content-Type: application/json
X-Webhook-Signature: sha256=...
X-Webhook-Event: alert.triggered
```

**Payload**:
```json
{
  "event": "alert.triggered",
  "timestamp": "2025-11-17T12:00:00Z",
  "alert": {
    "id": 456,
    "assetId": 1,
    "symbol": "GOLD",
    "condition": "above",
    "threshold": 2000.00,
    "currentPrice": 2005.50
  },
  "user": {
    "id": 42,
    "username": "john_doe"
  }
}
```

---

## 11. Versioning Strategy

**Current Version**: v1 (3.0.0)

**Versioning Approach**: URL versioning

- `/api/v1/*` - Current stable version
- `/api/v2/*` - Future version (when breaking changes needed)

**Backwards Compatibility**: Maintained for 12 months after new version release

---

## 12. Deprecation Policy

**Deprecation Timeline**:
1. **T+0**: Feature marked as deprecated in docs
2. **T+3 months**: Deprecation warning added to responses
3. **T+6 months**: Feature hidden from docs
4. **T+12 months**: Feature removed

**Deprecation Header**:
```
Warning: 299 - "This endpoint is deprecated. Use /api/v2/predict instead. Removal date: 2026-11-17"
```

---

## Appendix A: Postman Collection

**Import URL**: `https://goldpredictor.com/postman/collection.json`

**Included Requests**:
- Authentication (login, register, 2FA)
- Predictions (all variations)
- API Keys (CRUD operations)
- Alerts (CRUD operations)

---

## Appendix B: Code Examples

### B.1 Python Example

```python
import requests

# Login
response = requests.post(
    'https://api.goldpredictor.com/api/auth/login',
    data={'username': 'john_doe', 'password': 'SecurePass123'}
)
tokens = response.json()

# Generate prediction
headers = {'Authorization': f"Bearer {tokens['access_token']}"}
response = requests.post(
    'https://api.goldpredictor.com/api/predict',
    headers=headers,
    json={'symbol': 'GOLD', 'horizon': 'short'}
)
prediction = response.json()
print(f"Predicted price: {prediction['predicted_price']}")
```

### B.2 JavaScript Example

```javascript
// Login
const loginResponse = await fetch('https://api.goldpredictor.com/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  body: 'username=john_doe&password=SecurePass123'
});
const tokens = await loginResponse.json();

// Generate prediction
const predictionResponse = await fetch('https://api.goldpredictor.com/api/predict', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${tokens.access_token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ symbol: 'GOLD', horizon: 'short' })
});
const prediction = await predictionResponse.json();
console.log(`Predicted price: ${prediction.predicted_price}`);
```

---

**END OF API_CONTRACTS.MD**

**Status**: ✅ Complete  
**Coverage**: 100% API endpoints documented  
**Endpoints**: 18 REST + 22 tRPC + 7 ML = 47 total  
**Format**: OpenAPI 3.0.3 compliant  
**Next Review**: 2025-12-17  
**Maintainer**: API Team
