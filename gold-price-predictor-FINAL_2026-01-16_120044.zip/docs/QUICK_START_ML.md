# FILE: docs/QUICK_START_ML.md | PURPOSE: Quick start guide for ML services | OWNER: ML Team | LAST-AUDITED: 2025-11-25

# 🚀 Quick Start Guide - ML & AI Services

## ⚡ 5-Minute Setup

### 1️⃣ Start All Services
```bash
# From project root
docker-compose up -d

# Wait for services to be healthy (30-60 seconds)
docker-compose ps
```

### 2️⃣ Verify ML Service
```bash
# Check health
curl http://localhost:8000/health

# Expected response:
# {
#   "status": "healthy",
#   "timestamp": "2025-11-25T14:00:00Z",
#   "version": "1.0.0",
#   "models_loaded": 0
# }
```

### 3️⃣ Make Your First Prediction
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "symbol": "GC=F",
    "days": 7
  }'
```

### 4️⃣ View API Documentation
Open in browser:
- **ML Service Docs**: http://localhost:8000/docs
- **Elasticsearch**: http://localhost:9200
- **Kibana**: http://localhost:5601

---

## 📊 Service Ports

| Service | Port | URL |
|---------|------|-----|
| Backend | 2505 | http://localhost:2505 |
| ML Service | 8000 | http://localhost:8000 |
| Elasticsearch | 9200 | http://localhost:9200 |
| Kibana | 5601 | http://localhost:5601 |
| Prometheus | 9090 | http://localhost:9090 |
| Grafana | 2505 | http://localhost:2505 |

---

## 🧪 Testing

### Test ML Service
```bash
# Using Node.js script
npx tsx scripts/test-ml-service.ts

# Using curl
curl http://localhost:8000/health
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"symbol": "GC=F", "days": 7}'
```

### Test from Frontend
```typescript
// In your React component
import { trpc } from '@/lib/trpc';

function PredictionComponent() {
  const predictMutation = trpc.ml.predict.useMutation();

  const handlePredict = async () => {
    const result = await predictMutation.mutateAsync({
      symbol: 'GC=F',
      days: 7
    });
    console.log('Predictions:', result.data.predictions);
  };

  return <button onClick={handlePredict}>Predict</button>;
}
```

---

## 🔧 Common Commands

### View Logs
```bash
# All services
docker-compose logs -f

# ML service only
docker-compose logs -f ml-service

# Last 100 lines
docker-compose logs --tail=100 ml-service
```

### Restart Services
```bash
# Restart all
docker-compose restart

# Restart ML service only
docker-compose restart ml-service
```

### Rebuild After Code Changes
```bash
# Rebuild ML service
docker-compose build ml-service
docker-compose up -d ml-service

# Rebuild all
docker-compose build
docker-compose up -d
```

### Stop Services
```bash
# Stop all
docker-compose down

# Stop and remove volumes (⚠️ deletes data)
docker-compose down -v
```

---

## 🐛 Troubleshooting

### ML Service Not Starting
```bash
# Check logs
docker-compose logs ml-service

# Common issues:
# 1. Port 8000 already in use
#    Solution: Change port in docker-compose.yml

# 2. Out of memory
#    Solution: Increase Docker memory limit

# 3. TensorFlow errors
#    Solution: Use CPU-only version in requirements.txt
```

### Elasticsearch Yellow/Red Status
```bash
# Check cluster health
curl http://localhost:9200/_cluster/health?pretty

# Common issues:
# 1. Not enough memory
#    Solution: Increase ES_JAVA_OPTS in docker-compose.yml

# 2. Disk space low
#    Solution: Clean up old indices
```

### Cannot Connect to Services
```bash
# Check if services are running
docker-compose ps

# Check network
docker network ls
docker network inspect gold-price-predictor_gold-predictor-network

# Restart networking
docker-compose down
docker-compose up -d
```

---

## 📈 Next Steps

1. ✅ Services running
2. ⏳ Train your first model
3. ⏳ Integrate with frontend
4. ⏳ Set up monitoring
5. ⏳ Deploy to production

### Train Your First Model
```bash
# Via API (requires admin auth)
curl -X POST http://localhost:8000/train \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "symbol": "GC=F",
    "data_source": "database",
    "model_type": "lstm"
  }'
```

---

## 📚 Documentation

- [Full ML/AI Documentation](./ML_AI_SERVICES.md)
- [ML Service README](../ml-service/README.md)
- [API Reference](http://localhost:8000/docs)

---

## 💡 Tips

1. **Development**: Use `docker-compose up` (without `-d`) to see logs in real-time
2. **Production**: Always use `-d` flag and monitor logs separately
3. **Performance**: Adjust `WORKERS` in ML service for better throughput
4. **Memory**: Monitor with `docker stats` and adjust limits as needed

---

**🎉 You're all set! Start making predictions!**

