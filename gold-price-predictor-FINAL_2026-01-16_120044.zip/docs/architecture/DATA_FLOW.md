# Data Flow - Gold Price Predictor
# تدفق البيانات - نظام التنبؤ بأسعار الذهب

**Version:** 1.0  
**Last Updated:** 2025-10-24

---

## Overview

هذا المستند يوضح كيفية تدفق البيانات عبر مكونات نظام التنبؤ بأسعار الذهب المختلفة، من طلب المستخدم إلى الاستجابة النهائية.

---

## Main Data Flows

### 1. Prediction Request Flow

```mermaid
graph LR
    A[Client] -->|1. POST /predictions| B[API Gateway]
    B -->|2. Validate JWT| C[Auth Service]
    C -->|3. Check cache| D[Redis Cache]
    D -->|4. Cache miss| E[ML Engine]
    E -->|5. Get historical data| F[PostgreSQL]
    F -->|6. Return data| E
    E -->|7. Run models| E
    E -->|8. Ensemble| E
    E -->|9. Return prediction| B
    B -->|10. Cache result| D
    B -->|11. Save to DB| F
    B -->|12. Return JSON| A
```

**Steps:**

1. **Client Request:** المستخدم يرسل طلب تنبؤ عبر API
2. **JWT Validation:** التحقق من صحة رمز JWT
3. **Cache Check:** فحص وجود النتيجة في الذاكرة المؤقتة
4. **Cache Miss:** إذا لم توجد، ننتقل إلى ML Engine
5. **Historical Data:** جلب البيانات التاريخية من قاعدة البيانات
6. **Data Return:** إرجاع البيانات إلى ML Engine
7. **Model Execution:** تشغيل 8 نماذج ML
8. **Ensemble:** دمج النتائج باستخدام weighted average
9. **Prediction Return:** إرجاع التنبؤ إلى API
10. **Cache Storage:** تخزين النتيجة في Cache (TTL: 1 hour)
11. **Database Storage:** حفظ التنبؤ في قاعدة البيانات
12. **Client Response:** إرجاع JSON للمستخدم

---

### 2. Authentication Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant A as API
    participant Auth as Auth Service
    participant DB as PostgreSQL
    participant R as Redis
    
    C->>A: POST /auth/login
    A->>Auth: Validate credentials
    Auth->>DB: SELECT user WHERE email=?
    DB-->>Auth: User data
    Auth->>Auth: Verify bcrypt password
    Auth->>Auth: Check 2FA if enabled
    Auth->>Auth: Generate JWT (exp: 24h)
    Auth->>R: Store session (TTL: 24h)
    Auth-->>A: JWT + Refresh token
    A-->>C: {access_token, refresh_token}
```

**Steps:**

1. **Login Request:** المستخدم يرسل email و password
2. **Credential Validation:** التحقق من البيانات
3. **Database Query:** البحث عن المستخدم في قاعدة البيانات
4. **User Data:** إرجاع بيانات المستخدم
5. **Password Verification:** التحقق من كلمة المرور باستخدام bcrypt
6. **2FA Check:** التحقق من 2FA إذا كان مفعلاً
7. **JWT Generation:** إنشاء رمز JWT (صلاحية 24 ساعة)
8. **Session Storage:** تخزين الجلسة في Redis
9. **Token Return:** إرجاع access_token و refresh_token
10. **Client Response:** المستخدم يحصل على الرموز

---

### 3. Data Collection Flow

```mermaid
graph TB
    A[Scheduled Job] -->|Every 1 hour| B[Data Collector]
    B -->|Fetch prices| C[External APIs]
    C -->|GoldAPI.io| D[Gold Price Data]
    C -->|NewsAPI| E[News Data]
    C -->|Market Data| F[Market Indicators]
    D --> G[Data Validator]
    E --> G
    F --> G
    G -->|Validate & Clean| H[Data Transformer]
    H -->|Transform to schema| I[PostgreSQL]
    I -->|Store| J[gold_prices table]
    I -->|Store| K[news table]
    I -->|Store| L[market_data table]
```

**Steps:**

1. **Scheduled Job:** مهمة مجدولة تعمل كل ساعة
2. **Data Collector:** خدمة جمع البيانات
3. **External APIs:** استدعاء APIs خارجية
4. **Gold Price Data:** الحصول على أسعار الذهب
5. **News Data:** الحصول على الأخبار
6. **Market Indicators:** الحصول على مؤشرات السوق
7. **Data Validator:** التحقق من صحة البيانات
8. **Data Transformer:** تحويل البيانات إلى schema
9. **PostgreSQL Storage:** تخزين في قاعدة البيانات

---

### 4. ML Training Flow

```mermaid
graph LR
    A[Training Scheduler] -->|Weekly| B[Training Service]
    B -->|Get data| C[PostgreSQL]
    C -->|Historical prices| D[Data Preprocessor]
    D -->|Clean & normalize| E[Feature Engineering]
    E -->|Create features| F[Model Trainer]
    F -->|Train ARIMA| G[ARIMA Model]
    F -->|Train LSTM| H[LSTM Model]
    F -->|Train Prophet| I[Prophet Model]
    F -->|Train XGBoost| J[XGBoost Model]
    G --> K[Model Evaluator]
    H --> K
    I --> K
    J --> K
    K -->|Evaluate accuracy| L[Model Registry]
    L -->|Save best models| M[Model Storage]
```

**Steps:**

1. **Training Scheduler:** مجدول أسبوعي لإعادة التدريب
2. **Training Service:** خدمة التدريب
3. **Data Retrieval:** جلب البيانات التاريخية
4. **Data Preprocessing:** تنظيف وتطبيع البيانات
5. **Feature Engineering:** إنشاء الميزات
6. **Model Training:** تدريب جميع النماذج (8 models)
7. **Model Evaluation:** تقييم دقة النماذج
8. **Model Registry:** تسجيل النماذج
9. **Model Storage:** حفظ أفضل النماذج

---

### 5. Caching Strategy

```mermaid
graph TB
    A[API Request] -->|Check| B{Redis Cache}
    B -->|Hit| C[Return cached result]
    B -->|Miss| D[ML Engine]
    D -->|Generate prediction| E[Store in cache]
    E -->|TTL: 1 hour| B
    E -->|Return| F[API Response]
    C -->|Return| F
```

**Cache Layers:**

**L1: Application Cache (In-Memory)**
- TTL: 5 minutes
- Size: 100 MB
- Hit Rate: 45%

**L2: Redis Cache (Distributed)**
- TTL: 1 hour
- Size: 1 GB
- Hit Rate: 78%

**Cache Invalidation:**
- Time-based (TTL)
- Event-based (new data)
- Manual (admin action)

---

### 6. Monitoring Data Flow

```mermaid
graph LR
    A[Application] -->|Metrics| B[Prometheus]
    A -->|Logs| C[Log Aggregator]
    B -->|Scrape every 15s| D[Metrics Storage]
    C -->|Stream| E[Log Storage]
    D -->|Query| F[Grafana]
    E -->|Query| F
    F -->|Visualize| G[Dashboards]
    F -->|Alert| H[Alert Manager]
    H -->|Notify| I[Slack/Email]
```

**Metrics Collected:**
- Request count and latency
- Prediction accuracy
- Cache hit rate
- Database query time
- Error rate
- Resource usage (CPU, RAM, Disk)

---

### 7. Backup & Recovery Flow

```mermaid
graph TB
    A[Backup Scheduler] -->|Daily 2 AM| B[Backup Service]
    B -->|Dump database| C[pg_dump]
    C -->|Compress| D[gzip]
    D -->|Encrypt| E[AES-256]
    E -->|Upload| F[S3 Storage]
    F -->|Retention: 30 days| G[Backup Archive]
    
    H[Recovery Request] -->|Download| F
    F -->|Decrypt| I[AES-256]
    I -->|Decompress| J[gunzip]
    J -->|Restore| K[pg_restore]
    K -->|Verify| L[Database]
```

**Backup Strategy:**
- Full backup: Daily at 2 AM
- Incremental backup: Every 6 hours
- Retention: 30 days
- Storage: AWS S3
- Encryption: AES-256

---

## Data Models

### Prediction Data Model

```json
{
  "id": "uuid",
  "user_id": "uuid",
  "model_type": "ensemble",
  "input_data": {
    "timeframe": "7d",
    "current_price": 1850.50,
    "historical_days": 90
  },
  "prediction": {
    "price": 1875.30,
    "confidence": 0.99,
    "trend": "up",
    "models_used": ["ARIMA", "LSTM", "Prophet", ...]
  },
  "created_at": "2025-10-24T10:30:00Z",
  "cached": true,
  "cache_ttl": 3600
}
```

### User Data Model

```json
{
  "id": "uuid",
  "email": "user@example.com",
  "password_hash": "bcrypt_hash",
  "2fa_enabled": true,
  "2fa_secret": "encrypted_secret",
  "role": "user",
  "api_key": "encrypted_key",
  "created_at": "2025-01-01T00:00:00Z",
  "last_login": "2025-10-24T10:00:00Z"
}
```

### Gold Price Data Model

```json
{
  "id": "uuid",
  "timestamp": "2025-10-24T10:00:00Z",
  "price_usd": 1850.50,
  "price_eur": 1720.30,
  "volume": 1500000,
  "source": "GoldAPI.io",
  "verified": true
}
```

---

## Data Validation

### Input Validation

**Prediction Request:**
```python
class PredictionRequest(BaseModel):
    timeframe: str = Field(..., regex="^(1d|7d|30d|90d)$")
    model_type: str = Field(..., regex="^(arima|lstm|ensemble)$")
    
    @validator('timeframe')
    def validate_timeframe(cls, v):
        if v not in ['1d', '7d', '30d', '90d']:
            raise ValueError('Invalid timeframe')
        return v
```

**Data Sanitization:**
- Remove SQL injection patterns
- Remove XSS patterns
- Validate data types
- Check ranges
- Normalize formats

---

## Error Handling

### Error Flow

```mermaid
graph TB
    A[Error Occurs] -->|Catch| B[Error Handler]
    B -->|Log error| C[Structured Logger]
    C -->|Store| D[Log Storage]
    B -->|Check severity| E{Severity}
    E -->|Critical| F[Alert Team]
    E -->|Warning| G[Log Only]
    E -->|Info| G
    F -->|Notify| H[Slack/Email]
    B -->|Return| I[Error Response]
    I -->|JSON| J[Client]
```

**Error Response Format:**
```json
{
  "error": {
    "code": "PREDICTION_FAILED",
    "message": "Failed to generate prediction",
    "details": "Insufficient historical data",
    "timestamp": "2025-10-24T10:30:00Z",
    "request_id": "uuid"
  }
}
```

---

## Performance Optimization

### Query Optimization

**Before:**
```sql
SELECT * FROM predictions WHERE user_id = 'uuid';
```

**After:**
```sql
SELECT id, model_type, prediction, created_at 
FROM predictions 
WHERE user_id = 'uuid' 
AND created_at > NOW() - INTERVAL '30 days'
ORDER BY created_at DESC
LIMIT 100;
```

**Indexes:**
```sql
CREATE INDEX idx_predictions_user_created 
ON predictions(user_id, created_at DESC);

CREATE INDEX idx_gold_prices_timestamp 
ON gold_prices(timestamp DESC);
```

---

## Data Retention

### Retention Policies

| Data Type | Retention | Archive |
|-----------|-----------|---------|
| **Predictions** | 90 days | 1 year |
| **Gold Prices** | Forever | N/A |
| **Logs** | 30 days | 90 days |
| **Audit Logs** | 1 year | 5 years |
| **Backups** | 30 days | N/A |

---

**Document Version:** 1.0  
**Last Review:** 2025-10-24  
**Next Review:** 2026-01-24

