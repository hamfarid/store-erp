# Deployment Architecture
# معمارية النشر

**Version:** 1.0  
**Last Updated:** 2025-10-24

---

## Current Deployment (Docker Compose)

### Architecture

```
┌─────────────────────────────────────────┐
│         Docker Host Server              │
│                                         │
│  ┌──────────┐  ┌──────────┐  ┌───────┐│
│  │  FastAPI │  │PostgreSQL│  │ Redis ││
│  │  Backend │  │ Database │  │ Cache ││
│  └──────────┘  └──────────┘  └───────┘│
│                                         │
│  ┌──────────┐  ┌──────────┐           │
│  │Prometheus│  │ Grafana  │           │
│  │ Metrics  │  │Dashboard │           │
│  └──────────┘  └──────────┘           │
└─────────────────────────────────────────┘
```

### Components

- **FastAPI Backend:** Port 8000
- **PostgreSQL:** Port 5432
- **Redis:** Port 6379
- **Prometheus:** Port 9090
- **Grafana:** Port 3000

### Deployment Steps

1. Clone repository
2. Configure environment variables
3. Run `docker-compose up -d`
4. Run database migrations
5. Verify health checks

---

## Future Deployment (Kubernetes)

### Architecture

```
┌─────────────────────────────────────────┐
│         Kubernetes Cluster              │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │      Ingress Controller          │  │
│  └──────────────────────────────────┘  │
│           │                             │
│  ┌────────▼────────┐  ┌──────────────┐ │
│  │  API Deployment │  │ ML Deployment│ │
│  │  (3 replicas)   │  │ (2 replicas) │ │
│  └─────────────────┘  └──────────────┘ │
│                                         │
│  ┌──────────────┐  ┌─────────────────┐ │
│  │ PostgreSQL   │  │  Redis Cluster  │ │
│  │ StatefulSet  │  │  (3 nodes)      │ │
│  └──────────────┘  └─────────────────┘ │
└─────────────────────────────────────────┘
```

### Features

- **Auto-scaling:** HPA based on CPU/Memory
- **High Availability:** 99.9% uptime
- **Rolling Updates:** Zero-downtime deployments
- **Health Checks:** Liveness and readiness probes

---

**Document Version:** 1.0
