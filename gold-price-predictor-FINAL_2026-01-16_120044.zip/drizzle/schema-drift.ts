/**
 * FILE: drizzle/schema-drift.ts
 * PURPOSE: Database schema for drift detection system
 * OWNER: ML Team
 * RELATED: server/ml/drift-detection/, ml_backend/
 * LAST-AUDITED: 2025-01-18
 */

import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

/**
 * Drift Detection Records
 * Stores results from PSI, KS Test, and Autoencoder drift detectors
 */
export const driftDetections = sqliteTable("drift_detections", {
  id: text("id").primaryKey(),
  symbol: text("symbol", { length: 20 }).notNull(),
  detectorType: text("detectorType", { enum: ["psi", "ks_test", "autoencoder"] }).notNull(),
  driftScore: real("driftScore").notNull(),
  severity: text("severity", { enum: ["none", "low", "medium", "high"] }).notNull(),
  details: text("details"), // JSON string
  actionTaken: text("actionTaken", { length: 255 }),
  detectedAt: integer("detectedAt", { mode: "timestamp" }).default(sql`(unixepoch())`),
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

/**
 * Drift Metrics History
 * Tracks drift metrics over time for visualization
 */
export const driftMetricsHistory = sqliteTable("drift_metrics_history", {
  id: text("id").primaryKey(),
  symbol: text("symbol", { length: 20 }).notNull(),
  detectorType: text("detectorType", { enum: ["psi", "ks_test", "autoencoder"] }).notNull(),
  metricName: text("metricName", { length: 100 }).notNull(),
  metricValue: real("metricValue").notNull(),
  threshold: real("threshold"),
  timestamp: integer("timestamp", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

/**
 * Drift Alerts
 * Stores alerts triggered by drift detection
 */
export const driftAlerts = sqliteTable("drift_alerts", {
  id: text("id").primaryKey(),
  driftDetectionId: text("driftDetectionId").notNull(),
  severity: text("severity", { enum: ["low", "medium", "high", "critical"] }).notNull(),
  message: text("message").notNull(),
  acknowledged: integer("acknowledged", { mode: "boolean" }).default(false),
  acknowledgedBy: text("acknowledgedBy"),
  acknowledgedAt: integer("acknowledgedAt", { mode: "timestamp" }),
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

/**
 * Model Retraining Log
 * Tracks when models are retrained due to drift
 */
export const modelRetrainingLog = sqliteTable("model_retraining_log", {
  id: text("id").primaryKey(),
  symbol: text("symbol", { length: 20 }).notNull(),
  modelType: text("modelType", { length: 50 }).notNull(),
  reason: text("reason").notNull(), // e.g., "High drift detected"
  driftDetectionId: text("driftDetectionId"),
  status: text("status", { enum: ["pending", "in_progress", "completed", "failed"] }).default("pending"),
  startedAt: integer("startedAt", { mode: "timestamp" }),
  completedAt: integer("completedAt", { mode: "timestamp" }),
  metrics: text("metrics"), // JSON string with new model metrics
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

/**
 * Data Quality Metrics
 * Tracks data quality indicators
 */
export const dataQualityMetrics = sqliteTable("data_quality_metrics", {
  id: text("id").primaryKey(),
  symbol: text("symbol", { length: 20 }).notNull(),
  metricType: text("metricType", { enum: ["completeness", "consistency", "accuracy", "timeliness"] }).notNull(),
  score: real("score").notNull(), // 0.0 to 1.0
  details: text("details"), // JSON string
  timestamp: integer("timestamp", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

// Export types for TypeScript
export type DriftDetection = typeof driftDetections.$inferSelect;
export type NewDriftDetection = typeof driftDetections.$inferInsert;

export type DriftMetricsHistory = typeof driftMetricsHistory.$inferSelect;
export type NewDriftMetricsHistory = typeof driftMetricsHistory.$inferInsert;

export type DriftAlert = typeof driftAlerts.$inferSelect;
export type NewDriftAlert = typeof driftAlerts.$inferInsert;

export type ModelRetrainingLog = typeof modelRetrainingLog.$inferSelect;
export type NewModelRetrainingLog = typeof modelRetrainingLog.$inferInsert;

export type DataQualityMetrics = typeof dataQualityMetrics.$inferSelect;
export type NewDataQualityMetrics = typeof dataQualityMetrics.$inferInsert;

