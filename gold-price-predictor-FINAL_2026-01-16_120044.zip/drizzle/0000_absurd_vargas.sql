CREATE TABLE `access_codes` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`code` text NOT NULL,
	`userId` text,
	`usedAt` integer,
	`createdAt` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `access_codes_code_unique` ON `access_codes` (`code`);--> statement-breakpoint
CREATE TABLE `alerts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`userId` text NOT NULL,
	`assetId` integer NOT NULL,
	`alertType` text NOT NULL,
	`targetPrice` text,
	`changePercent` text,
	`isActive` integer DEFAULT true NOT NULL,
	`isTriggered` integer DEFAULT false NOT NULL,
	`triggeredAt` integer,
	`notificationMethod` text DEFAULT 'email' NOT NULL,
	`createdAt` integer
);
--> statement-breakpoint
CREATE TABLE `assets` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`symbol` text NOT NULL,
	`category` text NOT NULL,
	`isActive` integer DEFAULT true NOT NULL,
	`createdAt` integer
);
--> statement-breakpoint
CREATE TABLE `email_settings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`userId` text NOT NULL,
	`recipientEmail` text NOT NULL,
	`smtpHost` text,
	`smtpPort` integer,
	`smtpUser` text,
	`smtpPassword` text,
	`fromEmail` text,
	`fromName` text,
	`enabled` integer DEFAULT true,
	`createdAt` integer,
	`updatedAt` integer
);
--> statement-breakpoint
CREATE TABLE `historicalPrices` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assetId` integer NOT NULL,
	`date` integer NOT NULL,
	`price` text NOT NULL,
	`volume` text,
	`createdAt` integer
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assetId` integer NOT NULL,
	`predictionDate` integer NOT NULL,
	`targetDate` integer NOT NULL,
	`daysAhead` integer NOT NULL,
	`currentPrice` text NOT NULL,
	`predictedPrice` text NOT NULL,
	`confidenceLower` text,
	`confidenceUpper` text,
	`modelType` text NOT NULL,
	`accuracy` text,
	`createdAt` integer
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text,
	`email` text,
	`loginMethod` text,
	`role` text DEFAULT 'user' NOT NULL,
	`createdAt` integer,
	`lastSignedIn` integer
);
--> statement-breakpoint
CREATE TABLE `api_request_logs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`timestamp` integer NOT NULL,
	`method` text,
	`endpoint` text,
	`userId` text,
	`statusCode` integer,
	`responseTime` integer,
	`ipAddress` text,
	`userAgent` text,
	`errorMessage` text
);
--> statement-breakpoint
CREATE TABLE `error_logs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`timestamp` integer NOT NULL,
	`level` text DEFAULT 'error' NOT NULL,
	`source` text,
	`component` text,
	`message` text,
	`stack` text,
	`userId` text,
	`metadata` text
);
--> statement-breakpoint
CREATE TABLE `ml_training_logs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`timestamp` integer NOT NULL,
	`assetId` integer,
	`modelType` text,
	`trainingDuration` integer,
	`trainScore` text,
	`testScore` text,
	`mape` text,
	`hyperparameters` text,
	`datasetSize` integer,
	`status` text DEFAULT 'started' NOT NULL,
	`errorMessage` text
);
--> statement-breakpoint
CREATE TABLE `prediction_logs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`timestamp` integer NOT NULL,
	`predictionId` integer,
	`assetId` integer,
	`modelType` text,
	`inputData` text,
	`outputData` text,
	`executionTime` integer,
	`userId` text,
	`status` text DEFAULT 'success' NOT NULL,
	`errorMessage` text
);
