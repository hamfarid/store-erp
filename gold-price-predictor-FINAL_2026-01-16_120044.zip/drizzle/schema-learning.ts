/**
 * FILE: drizzle/schema-learning.ts
 * PURPOSE: Database schema for learning path optimization system
 * OWNER: ML Team
 * RELATED: server/ml/learning-path/, server/routers/learning-path.ts
 * LAST-AUDITED: 2025-01-18
 */

import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

/**
 * Learning Paths Table
 * Stores optimized learning paths for ML models
 */
export const learningPaths = sqliteTable("learning_paths", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  modelType: text("model_type").notNull(), // lstm, gru, transformer, ensemble
  optimizerType: text("optimizer_type").notNull(), // aco, rl, hybrid
  pathConfig: text("path_config").notNull(), // JSON: hyperparameters, features, etc.
  score: real("score").notNull(), // Fitness score
  accuracy: real("accuracy"), // Model accuracy
  trainingTime: integer("training_time"), // Training time in seconds
  status: text("status").notNull().default("pending"), // pending, training, completed, failed
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
  completedAt: integer("completed_at", { mode: "timestamp" }),
});

/**
 * Learning Progress Table
 * Tracks progress of learning path optimization
 */
export const learningProgress = sqliteTable("learning_progress", {
  id: text("id").primaryKey(),
  pathId: text("path_id")
    .notNull()
    .references(() => learningPaths.id),
  iteration: integer("iteration").notNull(),
  optimizerType: text("optimizer_type").notNull(), // aco, rl
  currentScore: real("current_score").notNull(),
  bestScore: real("best_score").notNull(),
  parameters: text("parameters").notNull(), // JSON: current parameters
  metrics: text("metrics"), // JSON: additional metrics
  timestamp: integer("timestamp", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

/**
 * Path Evaluations Table
 * Stores evaluation results for learning paths
 */
export const pathEvaluations = sqliteTable("path_evaluations", {
  id: text("id").primaryKey(),
  pathId: text("path_id")
    .notNull()
    .references(() => learningPaths.id),
  evaluationType: text("evaluation_type").notNull(), // validation, test, production
  accuracy: real("accuracy").notNull(),
  precision: real("precision"),
  recall: real("recall"),
  f1Score: real("f1_score"),
  mae: real("mae"), // Mean Absolute Error
  rmse: real("rmse"), // Root Mean Squared Error
  metrics: text("metrics"), // JSON: additional metrics
  evaluatedAt: integer("evaluated_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

/**
 * ACO Pheromone Table
 * Stores pheromone trails for Ant Colony Optimization
 */
export const acoPheromones = sqliteTable("aco_pheromones", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  modelType: text("model_type").notNull(),
  featurePath: text("feature_path").notNull(), // JSON: feature combination
  pheromoneLevel: real("pheromone_level").notNull().default(1.0),
  visitCount: integer("visit_count").notNull().default(0),
  avgScore: real("avg_score"),
  lastUpdated: integer("last_updated", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

/**
 * RL States Table
 * Stores states and Q-values for Reinforcement Learning
 */
export const rlStates = sqliteTable("rl_states", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  modelType: text("model_type").notNull(),
  state: text("state").notNull(), // JSON: state representation
  action: text("action").notNull(), // JSON: action taken
  qValue: real("q_value").notNull(),
  reward: real("reward").notNull(),
  nextState: text("next_state"), // JSON: next state
  episode: integer("episode").notNull(),
  step: integer("step").notNull(),
  timestamp: integer("timestamp", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

// TypeScript types
export type LearningPath = typeof learningPaths.$inferSelect;
export type InsertLearningPath = typeof learningPaths.$inferInsert;

export type LearningProgress = typeof learningProgress.$inferSelect;
export type InsertLearningProgress = typeof learningProgress.$inferInsert;

export type PathEvaluation = typeof pathEvaluations.$inferSelect;
export type InsertPathEvaluation = typeof pathEvaluations.$inferInsert;

export type AcoPheromone = typeof acoPheromones.$inferSelect;
export type InsertAcoPheromone = typeof acoPheromones.$inferInsert;

export type RlState = typeof rlStates.$inferSelect;
export type InsertRlState = typeof rlStates.$inferInsert;

