-- Migration: Add Performance Indexes
-- Created: 2025-11-15
-- Purpose: Improve query performance by adding indexes on frequently queried columns

-- Assets table indexes
CREATE INDEX IF NOT EXISTS `idx_assets_symbol` ON `assets` (`symbol`);
CREATE INDEX IF NOT EXISTS `idx_assets_category` ON `assets` (`category`);

-- Predictions table indexes (no userId in this table)
CREATE INDEX IF NOT EXISTS `idx_predictions_assetId` ON `predictions` (`assetId`);
CREATE INDEX IF NOT EXISTS `idx_predictions_createdAt` ON `predictions` (`createdAt`);
CREATE INDEX IF NOT EXISTS `idx_predictions_targetDate` ON `predictions` (`targetDate`);

-- Alerts table indexes
CREATE INDEX IF NOT EXISTS `idx_alerts_assetId` ON `alerts` (`assetId`);
CREATE INDEX IF NOT EXISTS `idx_alerts_userId` ON `alerts` (`userId`);
CREATE INDEX IF NOT EXISTS `idx_alerts_isActive` ON `alerts` (`isActive`);

-- Historical Prices table indexes
CREATE INDEX IF NOT EXISTS `idx_historicalPrices_assetId` ON `historicalPrices` (`assetId`);
CREATE INDEX IF NOT EXISTS `idx_historicalPrices_date` ON `historicalPrices` (`date`);

-- Notifications table indexes
CREATE INDEX IF NOT EXISTS `idx_notifications_userId` ON `notifications` (`userId`);
CREATE INDEX IF NOT EXISTS `idx_notifications_isRead` ON `notifications` (`isRead`);

