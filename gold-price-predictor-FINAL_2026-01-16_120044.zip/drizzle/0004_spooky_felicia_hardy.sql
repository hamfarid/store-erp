CREATE TABLE `data_quality_metrics` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text(20) NOT NULL,
	`metricType` text NOT NULL,
	`score` real NOT NULL,
	`details` text,
	`timestamp` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `drift_alerts` (
	`id` text PRIMARY KEY NOT NULL,
	`driftDetectionId` text NOT NULL,
	`severity` text NOT NULL,
	`message` text NOT NULL,
	`acknowledged` integer DEFAULT false,
	`acknowledgedBy` text,
	`acknowledgedAt` integer,
	`createdAt` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `drift_detections` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text(20) NOT NULL,
	`detectorType` text NOT NULL,
	`driftScore` real NOT NULL,
	`severity` text NOT NULL,
	`details` text,
	`actionTaken` text(255),
	`detectedAt` integer DEFAULT (unixepoch()),
	`createdAt` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `drift_metrics_history` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text(20) NOT NULL,
	`detectorType` text NOT NULL,
	`metricName` text(100) NOT NULL,
	`metricValue` real NOT NULL,
	`threshold` real,
	`timestamp` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `model_retraining_log` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text(20) NOT NULL,
	`modelType` text(50) NOT NULL,
	`reason` text NOT NULL,
	`driftDetectionId` text,
	`status` text DEFAULT 'pending',
	`startedAt` integer,
	`completedAt` integer,
	`metrics` text,
	`createdAt` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `aco_pheromones` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`model_type` text NOT NULL,
	`feature_path` text NOT NULL,
	`pheromone_level` real DEFAULT 1 NOT NULL,
	`visit_count` integer DEFAULT 0 NOT NULL,
	`avg_score` real,
	`last_updated` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `learning_paths` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`model_type` text NOT NULL,
	`optimizer_type` text NOT NULL,
	`path_config` text NOT NULL,
	`score` real NOT NULL,
	`accuracy` real,
	`training_time` integer,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	`completed_at` integer
);
--> statement-breakpoint
CREATE TABLE `learning_progress` (
	`id` text PRIMARY KEY NOT NULL,
	`path_id` text NOT NULL,
	`iteration` integer NOT NULL,
	`optimizer_type` text NOT NULL,
	`current_score` real NOT NULL,
	`best_score` real NOT NULL,
	`parameters` text NOT NULL,
	`metrics` text,
	`timestamp` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`path_id`) REFERENCES `learning_paths`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `path_evaluations` (
	`id` text PRIMARY KEY NOT NULL,
	`path_id` text NOT NULL,
	`evaluation_type` text NOT NULL,
	`accuracy` real NOT NULL,
	`precision` real,
	`recall` real,
	`f1_score` real,
	`mae` real,
	`rmse` real,
	`metrics` text,
	`evaluated_at` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`path_id`) REFERENCES `learning_paths`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `rl_states` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`model_type` text NOT NULL,
	`state` text NOT NULL,
	`action` text NOT NULL,
	`q_value` real NOT NULL,
	`reward` real NOT NULL,
	`next_state` text,
	`episode` integer NOT NULL,
	`step` integer NOT NULL,
	`timestamp` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `expert_opinions` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`source` text NOT NULL,
	`source_url` text,
	`expert_name` text,
	`expert_credibility` real DEFAULT 0.5,
	`opinion_text` text NOT NULL,
	`sentiment` text NOT NULL,
	`sentiment_score` real NOT NULL,
	`confidence` real,
	`target_price` real,
	`timeframe` text,
	`tags` text,
	`language` text DEFAULT 'en',
	`scraped_at` integer DEFAULT (unixepoch()) NOT NULL,
	`analyzed_at` integer
);
--> statement-breakpoint
CREATE TABLE `opinion_analysis_cache` (
	`id` text PRIMARY KEY NOT NULL,
	`opinion_id` text NOT NULL,
	`analysis_type` text NOT NULL,
	`result` text NOT NULL,
	`model` text,
	`tokens_used` integer,
	`cached_at` integer DEFAULT (unixepoch()) NOT NULL,
	`expires_at` integer,
	FOREIGN KEY (`opinion_id`) REFERENCES `expert_opinions`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `scraping_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`job_type` text NOT NULL,
	`sources` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`items_scraped` integer DEFAULT 0,
	`items_failed` integer DEFAULT 0,
	`error_message` text,
	`started_at` integer,
	`completed_at` integer,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sentiment_trends` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`date` text NOT NULL,
	`expert_sentiment` real,
	`social_sentiment` real,
	`news_sentiment` real,
	`overall_sentiment` real NOT NULL,
	`bullish_percentage` real,
	`bearish_percentage` real,
	`volume_score` real,
	`confidence_score` real,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `social_sentiment` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`platform` text NOT NULL,
	`timeframe` text NOT NULL,
	`bullish_count` integer DEFAULT 0 NOT NULL,
	`bearish_count` integer DEFAULT 0 NOT NULL,
	`neutral_count` integer DEFAULT 0 NOT NULL,
	`total_mentions` integer DEFAULT 0 NOT NULL,
	`sentiment_score` real NOT NULL,
	`volume_change` real,
	`trending_score` real,
	`top_keywords` text,
	`influencer_opinions` text,
	`collected_at` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
DROP TABLE `access_codes`;--> statement-breakpoint
DROP TABLE `alerts`;--> statement-breakpoint
DROP TABLE `assets`;--> statement-breakpoint
DROP TABLE `email_settings`;--> statement-breakpoint
DROP TABLE `historicalPrices`;--> statement-breakpoint
DROP TABLE `predictions`;--> statement-breakpoint
DROP TABLE `users`;--> statement-breakpoint
DROP TABLE `api_request_logs`;--> statement-breakpoint
DROP TABLE `error_logs`;--> statement-breakpoint
DROP TABLE `ml_training_logs`;--> statement-breakpoint
DROP TABLE `prediction_logs`;--> statement-breakpoint
DROP TABLE `notifications`;--> statement-breakpoint
DROP TABLE `breakEvenPoints`;--> statement-breakpoint
DROP TABLE `breakoutPoints`;--> statement-breakpoint
DROP TABLE `inflectionPoints`;--> statement-breakpoint
DROP TABLE `tradingSignals`;