/**
 * Enhanced Database Schema for New Features
 * Includes: Notifications, Reports, Activity Log, Risk Management, AI Recommendations
 */

import {
  mysqlTable,
  varchar,
  text,
  int,
  decimal,
  datetime,
  boolean,
  mysqlEnum,
  json,
  index,
} from "drizzle-orm/mysql-core";

/**
 * Notifications Table
 * Store all types of notifications (push, email, telegram)
 */
export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    type: mysqlEnum("type", ["push", "email", "telegram", "in_app"]).notNull(),
    channel: varchar("channel", { length: 50 }), // e.g., "alert_triggered", "daily_report"
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message").notNull(),
    data: json("data"), // Additional metadata
    status: mysqlEnum("status", ["pending", "sent", "failed", "read"]).default("pending").notNull(),
    sentAt: datetime("sentAt"),
    readAt: datetime("readAt"),
    createdAt: datetime("createdAt").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("idx_notifications_userId").on(table.userId),
    statusIdx: index("idx_notifications_status").on(table.status),
    createdAtIdx: index("idx_notifications_createdAt").on(table.createdAt),
  })
);

/**
 * Notification Preferences Table
 * User preferences for different notification channels
 */
export const notificationPreferences = mysqlTable("notification_preferences", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull().unique(),
  pushEnabled: boolean("pushEnabled").default(true).notNull(),
  emailEnabled: boolean("emailEnabled").default(true).notNull(),
  telegramEnabled: boolean("telegramEnabled").default(false).notNull(),
  telegramChatId: varchar("telegramChatId", { length: 100 }),
  alertsEnabled: boolean("alertsEnabled").default(true).notNull(),
  reportsEnabled: boolean("reportsEnabled").default(true).notNull(),
  newsEnabled: boolean("newsEnabled").default(true).notNull(),
  updatedAt: datetime("updatedAt").notNull().defaultNow(),
});

/**
 * Scheduled Reports Table
 * Configuration for automated report generation
 */
export const scheduledReports = mysqlTable(
  "scheduled_reports",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    type: mysqlEnum("type", ["portfolio", "price_analysis", "predictions", "alerts", "custom"]).notNull(),
    format: mysqlEnum("format", ["pdf", "excel", "csv"]).notNull(),
    frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly", "custom"]).notNull(),
    schedule: varchar("schedule", { length: 100 }), // Cron expression for custom frequency
    recipients: json("recipients"), // Array of email addresses
    parameters: json("parameters"), // Report-specific parameters
    enabled: boolean("enabled").default(true).notNull(),
    lastRunAt: datetime("lastRunAt"),
    nextRunAt: datetime("nextRunAt"),
    createdAt: datetime("createdAt").notNull().defaultNow(),
    updatedAt: datetime("updatedAt").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("idx_scheduled_reports_userId").on(table.userId),
    nextRunAtIdx: index("idx_scheduled_reports_nextRunAt").on(table.nextRunAt),
  })
);

/**
 * Activity Log Table
 * Comprehensive logging of all user activities
 */
export const activityLog = mysqlTable(
  "activity_log",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    action: varchar("action", { length: 100 }).notNull(), // e.g., "create", "update", "delete", "view"
    entityType: varchar("entityType", { length: 50 }).notNull(), // e.g., "asset", "alert", "prediction"
    entityId: varchar("entityId", { length: 100 }),
    description: text("description"),
    ipAddress: varchar("ipAddress", { length: 45 }),
    userAgent: text("userAgent"),
    metadata: json("metadata"), // Additional context
    timestamp: datetime("timestamp").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("idx_activity_log_userId").on(table.userId),
    entityTypeIdx: index("idx_activity_log_entityType").on(table.entityType),
    timestampIdx: index("idx_activity_log_timestamp").on(table.timestamp),
  })
);

/**
 * Change Tracking Table
 * Track all changes to entities with before/after values
 */
export const changeTracking = mysqlTable(
  "change_tracking",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    entityType: varchar("entityType", { length: 50 }).notNull(),
    entityId: varchar("entityId", { length: 100 }).notNull(),
    field: varchar("field", { length: 100 }).notNull(),
    oldValue: text("oldValue"),
    newValue: text("newValue"),
    timestamp: datetime("timestamp").notNull().defaultNow(),
  },
  (table) => ({
    entityIdx: index("idx_change_tracking_entity").on(table.entityType, table.entityId),
    timestampIdx: index("idx_change_tracking_timestamp").on(table.timestamp),
  })
);

/**
 * Risk Profiles Table
 * Store risk assessment for assets and portfolios
 */
export const riskProfiles = mysqlTable(
  "risk_profiles",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    assetId: int("assetId"),
    riskScore: decimal("riskScore", { precision: 5, scale: 2 }).notNull(), // 0-100
    riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high", "critical"]).notNull(),
    volatility: decimal("volatility", { precision: 10, scale: 4 }),
    beta: decimal("beta", { precision: 10, scale: 4 }),
    sharpeRatio: decimal("sharpeRatio", { precision: 10, scale: 4 }),
    maxDrawdown: decimal("maxDrawdown", { precision: 10, scale: 4 }),
    valueAtRisk: decimal("valueAtRisk", { precision: 15, scale: 2 }), // VaR
    recommendations: json("recommendations"), // Array of risk mitigation recommendations
    calculatedAt: datetime("calculatedAt").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("idx_risk_profiles_userId").on(table.userId),
    assetIdIdx: index("idx_risk_profiles_assetId").on(table.assetId),
  })
);

/**
 * Stop Loss Orders Table
 * Automated stop-loss configuration
 */
export const stopLossOrders = mysqlTable(
  "stop_loss_orders",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    assetId: int("assetId").notNull(),
    triggerPrice: decimal("triggerPrice", { precision: 15, scale: 2 }).notNull(),
    quantity: decimal("quantity", { precision: 15, scale: 4 }).notNull(),
    type: mysqlEnum("type", ["fixed", "trailing", "percentage"]).notNull(),
    trailingAmount: decimal("trailingAmount", { precision: 10, scale: 2 }), // For trailing stop-loss
    status: mysqlEnum("status", ["active", "triggered", "cancelled", "expired"]).default("active").notNull(),
    triggeredAt: datetime("triggeredAt"),
    createdAt: datetime("createdAt").notNull().defaultNow(),
    expiresAt: datetime("expiresAt"),
  },
  (table) => ({
    userIdIdx: index("idx_stop_loss_userId").on(table.userId),
    assetIdIdx: index("idx_stop_loss_assetId").on(table.assetId),
    statusIdx: index("idx_stop_loss_status").on(table.status),
  })
);

/**
 * AI Recommendations Table
 * Store AI-generated recommendations
 */
export const aiRecommendations = mysqlTable(
  "ai_recommendations",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    type: mysqlEnum("type", ["buy", "sell", "hold", "diversify", "risk_alert"]).notNull(),
    assetId: int("assetId"),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description").notNull(),
    confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(), // 0-100
    reasoning: text("reasoning"), // Explanation of the recommendation
    data: json("data"), // Supporting data
    status: mysqlEnum("status", ["pending", "accepted", "rejected", "expired"]).default("pending").notNull(),
    expiresAt: datetime("expiresAt"),
    createdAt: datetime("createdAt").notNull().defaultNow(),
    respondedAt: datetime("respondedAt"),
  },
  (table) => ({
    userIdIdx: index("idx_ai_recommendations_userId").on(table.userId),
    statusIdx: index("idx_ai_recommendations_status").on(table.status),
    createdAtIdx: index("idx_ai_recommendations_createdAt").on(table.createdAt),
  })
);

/**
 * Sentiment Analysis Table
 * Store sentiment analysis results for news
 */
export const sentimentAnalysis = mysqlTable(
  "sentiment_analysis",
  {
    id: int("id").primaryKey().autoincrement(),
    newsId: int("newsId"),
    assetId: int("assetId"),
    source: varchar("source", { length: 255 }),
    title: varchar("title", { length: 500 }),
    content: text("content"),
    sentiment: mysqlEnum("sentiment", ["very_negative", "negative", "neutral", "positive", "very_positive"]).notNull(),
    score: decimal("score", { precision: 5, scale: 2 }).notNull(), // -100 to +100
    keywords: json("keywords"), // Array of extracted keywords
    entities: json("entities"), // Named entities (companies, people, locations)
    analyzedAt: datetime("analyzedAt").notNull().defaultNow(),
  },
  (table) => ({
    assetIdIdx: index("idx_sentiment_analysis_assetId").on(table.assetId),
    sentimentIdx: index("idx_sentiment_analysis_sentiment").on(table.sentiment),
    analyzedAtIdx: index("idx_sentiment_analysis_analyzedAt").on(table.analyzedAt),
  })
);

/**
 * KPI Metrics Table
 * Store calculated KPI metrics for executive dashboard
 */
export const kpiMetrics = mysqlTable(
  "kpi_metrics",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    period: varchar("period", { length: 20 }).notNull(), // e.g., "2024-11", "2024-Q4", "2024"
    totalValue: decimal("totalValue", { precision: 15, scale: 2 }).notNull(),
    totalInvested: decimal("totalInvested", { precision: 15, scale: 2 }).notNull(),
    totalProfit: decimal("totalProfit", { precision: 15, scale: 2 }).notNull(),
    totalLoss: decimal("totalLoss", { precision: 15, scale: 2 }).notNull(),
    roi: decimal("roi", { precision: 10, scale: 4 }).notNull(), // Return on Investment %
    winRate: decimal("winRate", { precision: 5, scale: 2 }).notNull(), // % of profitable trades
    avgProfit: decimal("avgProfit", { precision: 15, scale: 2 }),
    avgLoss: decimal("avgLoss", { precision: 15, scale: 2 }),
    profitFactor: decimal("profitFactor", { precision: 10, scale: 4 }), // Total profit / Total loss
    sharpeRatio: decimal("sharpeRatio", { precision: 10, scale: 4 }),
    maxDrawdown: decimal("maxDrawdown", { precision: 10, scale: 4 }),
    calculatedAt: datetime("calculatedAt").notNull().defaultNow(),
  },
  (table) => ({
    userIdPeriodIdx: index("idx_kpi_metrics_userId_period").on(table.userId, table.period),
  })
);

/**
 * User Behavior Analytics Table
 * Track user behavior patterns for insights
 */
export const userBehaviorAnalytics = mysqlTable(
  "user_behavior_analytics",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    date: datetime("date").notNull(),
    loginCount: int("loginCount").default(0).notNull(),
    pageViews: int("pageViews").default(0).notNull(),
    alertsCreated: int("alertsCreated").default(0).notNull(),
    predictionsViewed: int("predictionsViewed").default(0).notNull(),
    reportsGenerated: int("reportsGenerated").default(0).notNull(),
    tradesExecuted: int("tradesExecuted").default(0).notNull(),
    avgSessionDuration: int("avgSessionDuration"), // in seconds
    mostViewedAssets: json("mostViewedAssets"), // Array of asset IDs
    peakActivityHour: int("peakActivityHour"), // 0-23
  },
  (table) => ({
    userIdDateIdx: index("idx_user_behavior_userId_date").on(table.userId, table.date),
  })
);

// Type exports
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = typeof notificationPreferences.$inferInsert;

export type ScheduledReport = typeof scheduledReports.$inferSelect;
export type InsertScheduledReport = typeof scheduledReports.$inferInsert;

export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = typeof activityLog.$inferInsert;

export type ChangeTracking = typeof changeTracking.$inferSelect;
export type InsertChangeTracking = typeof changeTracking.$inferInsert;

export type RiskProfile = typeof riskProfiles.$inferSelect;
export type InsertRiskProfile = typeof riskProfiles.$inferInsert;

export type StopLossOrder = typeof stopLossOrders.$inferSelect;
export type InsertStopLossOrder = typeof stopLossOrders.$inferInsert;

export type AIRecommendation = typeof aiRecommendations.$inferSelect;
export type InsertAIRecommendation = typeof aiRecommendations.$inferInsert;

export type SentimentAnalysis = typeof sentimentAnalysis.$inferSelect;
export type InsertSentimentAnalysis = typeof sentimentAnalysis.$inferInsert;

export type KPIMetric = typeof kpiMetrics.$inferSelect;
export type InsertKPIMetric = typeof kpiMetrics.$inferInsert;

export type UserBehaviorAnalytic = typeof userBehaviorAnalytics.$inferSelect;
export type InsertUserBehaviorAnalytic = typeof userBehaviorAnalytics.$inferInsert;

