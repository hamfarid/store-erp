<!--
===========================================
SYNC IMPACT REPORT
===========================================
Version Change: 0.0.0 → 1.0.0 (MAJOR - Initial Constitution)
Modified Principles: N/A (New document)
Added Sections:
  - Core Principles (7 principles)
  - Technical Standards
  - Security Requirements
  - Development Workflow
  - Governance

Templates Requiring Updates:
  ✅ plan-template.md - Constitution Check section aligned
  ✅ spec-template.md - Requirements section aligned
  ✅ tasks-template.md - Task categories aligned

Follow-up TODOs: None
===========================================
-->

# نظام التنبؤ الذكي بأسعار الذهب والأصول - Constitution

# Gold Price Predictor - Premium Edition Constitution

## Core Principles

### I. Arabic-First with RTL Excellence (الأولوية للعربية)

All user-facing interfaces MUST support Arabic language with proper Right-to-Left (RTL) rendering. This is NON-NEGOTIABLE.

- Every UI component MUST render correctly in RTL mode
- Text, numbers, and charts MUST display properly for Arabic users
- Error messages, notifications, and alerts MUST be available in Arabic
- Date/time formats MUST follow Arabic conventions when locale is Arabic
- Currency displays MUST support SAR, USD, and local formats

**Rationale**: The primary target audience is Arabic-speaking users. A premium experience requires native language support throughout.

### II. Type-Safety First (TypeScript Mandatory)

All code MUST be written in TypeScript with strict mode enabled. No `any` types allowed except with explicit justification.

- tRPC procedures MUST have fully typed inputs and outputs using Zod schemas
- Database queries via Drizzle ORM MUST maintain type safety
- API responses MUST conform to defined TypeScript interfaces
- Frontend components MUST have typed props

**Rationale**: Type safety prevents runtime errors, improves developer experience, and ensures API contract reliability.

### III. Security by Design (الأمان أولاً)

Security is embedded in every layer, not added as an afterthought.

- Authentication MUST use JWT with secure token rotation
- All API endpoints MUST validate input using Zod schemas
- Sensitive data MUST be encrypted at rest and in transit
- Session management MUST include hijacking protection
- Rate limiting MUST be enforced on all public endpoints
- CSRF protection MUST be active for state-changing operations

**Rationale**: Financial prediction systems are high-value targets. Security breaches destroy user trust permanently.

### IV. ML Model Integrity (دقة التنبؤات)

Machine learning predictions MUST be transparent, versioned, and validated.

- All ML models MUST have documented accuracy metrics
- Predictions MUST include confidence intervals and uncertainty measures
- Model versions MUST be tracked and reproducible
- Fallback mechanisms MUST exist when ML services are unavailable
- Historical prediction accuracy MUST be logged and reviewable

**Rationale**: Users make financial decisions based on predictions. Transparency about accuracy is essential for trust.

### V. Test-Driven Quality (TDD for Critical Paths)

Critical paths MUST follow Test-Driven Development; all features MUST have adequate test coverage.

- Authentication and authorization: Unit + Integration tests REQUIRED
- Payment/financial calculations: Unit tests with edge cases REQUIRED
- ML prediction pipeline: Integration tests REQUIRED
- E2E tests via Playwright for critical user journeys REQUIRED
- Minimum 80% code coverage for server-side code

**Rationale**: Financial applications have zero tolerance for calculation errors or security vulnerabilities.

### VI. Real-Time Data Reliability (موثوقية البيانات)

Price data MUST be accurate, timely, and gracefully degraded when sources fail.

- Primary data source: Yahoo Finance API with caching
- Fallback mechanisms MUST exist for API failures
- Data staleness MUST be clearly indicated to users
- Cache invalidation strategy MUST be documented
- WebSocket connections for real-time updates where applicable

**Rationale**: Users depend on accurate price information for decision-making. Stale or incorrect data causes financial harm.

### VII. Progressive Enhancement (Performance & Accessibility)

The application MUST be fast, accessible, and work across devices.

- Lighthouse Performance score MUST be ≥ 80
- Lighthouse Accessibility score MUST be ≥ 90
- First Contentful Paint MUST be < 2 seconds
- Time to Interactive MUST be < 4 seconds
- Mobile-responsive design is MANDATORY
- Keyboard navigation MUST be fully supported

**Rationale**: Premium user experience requires performance and accessibility for all users.

## Technical Standards

### Stack Requirements

| Layer | Technology | Version |
|-------|------------|---------|
| Frontend | React + TypeScript | 19.x |
| Styling | TailwindCSS + shadcn/ui | 4.x |
| API | tRPC | 11.x |
| ORM | Drizzle | Latest |
| Database | PostgreSQL (prod) / SQLite (dev) | 14+ / 3.x |
| ML Service | Python FastAPI | 3.11+ |
| Testing | Vitest (unit) + Playwright (E2E) | Latest |

### Code Organization

```
/
├── client/              # React frontend (if separate)
├── frontend/            # Alternative frontend location
├── server/              # tRPC + Express backend
│   ├── _core/          # Server entry point
│   ├── routes/         # tRPC routers
│   ├── services/       # Business logic
│   └── db/             # Drizzle schema & migrations
├── shared/              # Shared types and utilities
├── ml/                  # Python ML service
├── e2e/                 # Playwright E2E tests
└── tests/               # Unit tests
```

### Naming Conventions

- Files: `kebab-case.ts` for utilities, `PascalCase.tsx` for components
- Variables/Functions: `camelCase`
- Types/Interfaces: `PascalCase`
- Constants: `SCREAMING_SNAKE_CASE`
- Database tables: `snake_case`

## Security Requirements

### Authentication & Authorization

- Password hashing: bcrypt with cost factor ≥ 12
- JWT expiration: Access tokens ≤ 15 minutes, Refresh tokens ≤ 7 days
- Session storage: Secure, HttpOnly cookies
- Role-based access control (RBAC) for admin features

### Data Protection

- PII encryption at rest using AES-256
- TLS 1.3 for all communications
- Input sanitization for XSS prevention
- SQL injection prevention via parameterized queries (Drizzle handles this)

### Audit & Compliance

- All security events MUST be logged
- Login attempts (success/failure) MUST be recorded
- Administrative actions MUST be auditable
- Data export functionality for GDPR compliance

## Development Workflow

### Git Workflow

- Branch naming: `feature/###-description`, `fix/###-description`, `hotfix/###-description`
- Commit messages: Conventional Commits format (`feat:`, `fix:`, `docs:`, `refactor:`)
- Pull requests MUST pass all CI checks before merge
- Code review REQUIRED for all changes to `main`

### CI/CD Pipeline

1. **Lint**: ESLint + TypeScript check
2. **Test**: Vitest unit tests
3. **E2E**: Playwright tests on staging
4. **Build**: Vite production build
5. **Deploy**: Docker container to production

### Quality Gates

- No TypeScript errors (`tsc --noEmit`)
- No ESLint errors/warnings
- All tests passing
- Build succeeds without errors

## Governance

This Constitution supersedes all other development practices for the Gold Price Predictor project. All contributions MUST comply with these principles.

### Amendment Process

1. Propose amendment via documented issue
2. Review impact on existing code and templates
3. Update Constitution with version increment
4. Update dependent templates (plan, spec, tasks)
5. Communicate changes to all contributors

### Version Policy

- **MAJOR**: Principle removal, redefinition, or backward-incompatible changes
- **MINOR**: New principle added, section expanded, or guidance enhanced
- **PATCH**: Clarifications, typo fixes, non-semantic refinements

### Compliance

- All PRs MUST verify Constitution compliance before merge
- Complexity additions MUST be justified against Principle VII (Progressive Enhancement)
- Security exceptions MUST be documented and approved by project lead

**Version**: 1.0.0 | **Ratified**: 2026-01-14 | **Last Amended**: 2026-01-14
