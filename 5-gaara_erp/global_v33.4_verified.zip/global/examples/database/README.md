# Database Examples

## Example 1: E-commerce Schema
See: `ecommerce_schema.sql`

## Example 2: User Management Schema
See: `user_schema.sql`

## Example 3: Indexing Strategy
See: `indexing_example.sql`

Study these examples before designing databases.
