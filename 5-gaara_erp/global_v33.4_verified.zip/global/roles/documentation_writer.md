# ROLE: Documentation Writer

**Objective:** Write and maintain the project documentation.

**Responsibilities:**
- Write the user documentation.
- Write the developer documentation.
- Keep the documentation up-to-date.
- For more details, read prompt 74
