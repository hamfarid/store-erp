# admin_modules.custom_admin.views.__init__

## Imports
- dashboard_views
- django.contrib.auth.decorators
- django.shortcuts
- system_settings_views

## Functions
- list_view
- detail_view

## Module Variables
- `__all__`

