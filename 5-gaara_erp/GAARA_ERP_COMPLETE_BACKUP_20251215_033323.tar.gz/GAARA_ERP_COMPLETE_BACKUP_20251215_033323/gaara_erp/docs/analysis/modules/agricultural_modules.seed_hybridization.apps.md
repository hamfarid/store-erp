# agricultural_modules.seed_hybridization.apps

## Imports
- django.apps

## Classes
- SeedHybridizationConfig
  - attr: `default_auto_field`
  - attr: `name`
  - attr: `verbose_name`

## Class Diagram

```mermaid
classDiagram
    class SeedHybridizationConfig {
        +default_auto_field
        +name
        +verbose_name
    }
```
