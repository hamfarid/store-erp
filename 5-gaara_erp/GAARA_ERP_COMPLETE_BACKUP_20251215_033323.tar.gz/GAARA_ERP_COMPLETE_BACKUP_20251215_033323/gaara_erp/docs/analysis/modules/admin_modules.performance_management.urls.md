# admin_modules.performance_management.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

