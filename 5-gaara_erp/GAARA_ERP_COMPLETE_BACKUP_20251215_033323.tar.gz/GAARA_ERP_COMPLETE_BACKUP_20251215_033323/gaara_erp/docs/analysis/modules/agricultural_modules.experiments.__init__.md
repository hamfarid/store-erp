# agricultural_modules.experiments.__init__

## Module Variables
- `default_app_config`

