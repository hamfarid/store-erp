# admin_modules.reports.__init__

## Module Variables
- `default_app_config`

