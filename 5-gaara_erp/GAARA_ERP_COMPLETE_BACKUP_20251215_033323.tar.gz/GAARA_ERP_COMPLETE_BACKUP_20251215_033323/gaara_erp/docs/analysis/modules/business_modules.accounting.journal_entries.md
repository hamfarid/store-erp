# business_modules.accounting.journal_entries

## Imports
- django.db

