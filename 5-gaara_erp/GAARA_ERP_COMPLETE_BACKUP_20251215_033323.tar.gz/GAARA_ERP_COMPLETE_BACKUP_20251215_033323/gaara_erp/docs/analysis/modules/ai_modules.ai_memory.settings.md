# ai_modules.ai_memory.settings

## Imports
- django.conf

## Functions
- get_setting

## Module Variables
- `AI_MEMORY_SETTINGS`
- `CELERY_TASK_ROUTES`
- `CELERY_BEAT_SCHEDULE`
- `DATABASE_INDEXES`
- `CACHE_SETTINGS`
- `LOGGING_CONFIG`
- `SECURITY_SETTINGS`
- `EXTERNAL_SERVICES`
- `TEST_SETTINGS`

