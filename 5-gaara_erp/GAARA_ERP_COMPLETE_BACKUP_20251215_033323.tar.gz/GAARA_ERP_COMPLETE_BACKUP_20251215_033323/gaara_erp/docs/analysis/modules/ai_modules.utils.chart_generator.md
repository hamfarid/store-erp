# ai_modules.utils.chart_generator

## Imports
- logging
- matplotlib.pyplot
- os

## Functions
- generate_comparison_charts

## Module Variables
- `logger`

