# admin_modules.internal_diagnosis_module.filters

## Imports
- django_filters

