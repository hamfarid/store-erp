# admin_modules.dashboard.urls

## Imports
- django.urls
- views

## Module Variables
- `app_name`
- `urlpatterns`

