# api_server.src.routes.user

## Imports
- flask
- src.models.user

## Functions
- get_users
- create_user
- get_user
- update_user
- delete_user

## Module Variables
- `user_bp`

