# admin_modules.system_monitoring.urls

## Imports
- django.urls
- rest_framework.routers
- views

## Module Variables
- `router`
- `urlpatterns`

