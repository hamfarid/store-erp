# admin_modules.system_monitoring.__init__

## Module Variables
- `default_app_config`

