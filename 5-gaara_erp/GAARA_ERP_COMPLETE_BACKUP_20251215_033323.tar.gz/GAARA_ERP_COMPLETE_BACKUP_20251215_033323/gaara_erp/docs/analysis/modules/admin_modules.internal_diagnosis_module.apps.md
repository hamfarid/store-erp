# admin_modules.internal_diagnosis_module.apps

## Imports
- django.apps

## Classes
- InternalDiagnosisModuleConfig
  - attr: `default_auto_field`
  - attr: `name`
  - attr: `verbose_name`

## Class Diagram

```mermaid
classDiagram
    class InternalDiagnosisModuleConfig {
        +default_auto_field
        +name
        +verbose_name
    }
```
