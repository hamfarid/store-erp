# admin_modules.setup_wizard.urls

## Imports
- django.urls
- views

## Module Variables
- `urlpatterns`

