# agricultural_modules.plant_diagnosis.apps

## Imports
- django.apps

## Classes
- PlantDiagnosisConfig
  - attr: `default_auto_field`
  - attr: `name`
  - attr: `verbose_name`

## Class Diagram

```mermaid
classDiagram
    class PlantDiagnosisConfig {
        +default_auto_field
        +name
        +verbose_name
    }
```
