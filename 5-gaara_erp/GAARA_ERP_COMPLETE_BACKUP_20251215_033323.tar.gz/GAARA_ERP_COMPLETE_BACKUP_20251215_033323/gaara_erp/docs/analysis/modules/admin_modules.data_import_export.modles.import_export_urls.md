# admin_modules.data_import_export.modles.import_export_urls

## Imports
- django.urls
- rest_framework.decorators
- rest_framework.response
- rest_framework.routers

## Functions
- api_info

## Module Variables
- `app_name`
- `router`
- `file_patterns`
- `admin_patterns`
- `urlpatterns`

