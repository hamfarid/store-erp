# admin_modules.communication.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

