# admin_modules.internal_diagnosis_module.admin

## Imports
- django.contrib

