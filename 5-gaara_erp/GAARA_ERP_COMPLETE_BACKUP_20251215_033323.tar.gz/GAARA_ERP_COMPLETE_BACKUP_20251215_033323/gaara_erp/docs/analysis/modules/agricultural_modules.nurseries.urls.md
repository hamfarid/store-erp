# agricultural_modules.nurseries.urls

## Imports
- api_views
- django.urls
- rest_framework.routers

## Module Variables
- `router`
- `urlpatterns`

