# agricultural_modules.variety_trials.__init__

