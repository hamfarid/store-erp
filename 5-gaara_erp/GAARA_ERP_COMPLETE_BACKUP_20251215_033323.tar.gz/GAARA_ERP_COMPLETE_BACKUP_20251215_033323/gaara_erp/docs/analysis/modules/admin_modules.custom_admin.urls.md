# admin_modules.custom_admin.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

