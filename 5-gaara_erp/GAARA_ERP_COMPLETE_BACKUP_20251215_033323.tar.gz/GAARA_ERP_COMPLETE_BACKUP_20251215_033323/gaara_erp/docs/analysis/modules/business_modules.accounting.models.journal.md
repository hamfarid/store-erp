# business_modules.accounting.models.journal

## Imports
- business_modules.accounting

## Module Variables
- `Journal`
- `JournalEntry`
- `JournalItem`

