# ai_modules.models.disease_mappings

## Module Variables
- `plant_diseases_mapping`

