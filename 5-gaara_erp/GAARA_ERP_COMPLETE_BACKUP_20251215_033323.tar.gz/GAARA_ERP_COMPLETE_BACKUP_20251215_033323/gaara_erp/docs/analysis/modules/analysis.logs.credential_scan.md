# analysis.logs.credential_scan

## Imports
- json
- pathlib
- re

## Functions
- scan_for_credentials
- is_likely_real_credential
- get_severity

