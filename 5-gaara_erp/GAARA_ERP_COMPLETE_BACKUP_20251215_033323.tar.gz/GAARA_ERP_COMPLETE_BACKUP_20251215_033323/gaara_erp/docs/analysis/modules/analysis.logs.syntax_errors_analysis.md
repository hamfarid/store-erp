# analysis.logs.syntax_errors_analysis

## Imports
- ast
- json
- pathlib

## Functions
- analyze_syntax_errors

