# admin_modules.internal_diagnosis_module.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

