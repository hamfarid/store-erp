# agricultural_modules.seed_hybridization.merged.urls

## Imports
- django.urls
- rest_framework.routers

## Module Variables
- `app_name`
- `router`
- `urlpatterns`

