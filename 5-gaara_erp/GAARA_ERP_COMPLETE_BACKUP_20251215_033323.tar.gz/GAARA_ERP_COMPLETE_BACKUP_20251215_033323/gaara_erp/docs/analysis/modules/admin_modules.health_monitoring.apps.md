# admin_modules.health_monitoring.apps

## Imports
- django.apps

## Classes
- HealthMonitoringConfig
  - attr: `default_auto_field`
  - attr: `name`

## Class Diagram

```mermaid
classDiagram
    class HealthMonitoringConfig {
        +default_auto_field
        +name
    }
```
