# admin_modules.notifications.backup_files.signals

## Imports
- django.conf
- django.db.models.signals
- django.dispatch
- logging
- models
- telegram_bot.services

## Functions
- send_important_notification_via_telegram

## Module Variables
- `logger`

