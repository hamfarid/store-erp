# analysis.logs.frontend_security_scan

## Imports
- json
- pathlib
- re

## Functions
- scan_frontend_security
- check_react_security
- get_severity

