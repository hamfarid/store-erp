# admin_modules.system_backups.apps

## Imports
- django.apps

## Classes
- SystemBackupsConfig
  - attr: `default_auto_field`
  - attr: `name`

## Class Diagram

```mermaid
classDiagram
    class SystemBackupsConfig {
        +default_auto_field
        +name
    }
```
