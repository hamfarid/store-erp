# admin_modules.setup_wizard.views

## Imports
- django.http
- django.shortcuts
- rest_framework.decorators
- rest_framework.response

## Functions
- check_setup_status
- list_view
- detail_view

