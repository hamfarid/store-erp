# admin_modules.setup_wizard.apps

## Imports
- django.apps

## Classes
- SetupConfig
  - attr: `default_auto_field`
  - attr: `name`

## Class Diagram

```mermaid
classDiagram
    class SetupConfig {
        +default_auto_field
        +name
    }
```
