# agricultural_modules.experiments.urls

## Imports
- django.urls
- rest_framework.routers
- views

## Module Variables
- `router`
- `app_name`
- `urlpatterns`

