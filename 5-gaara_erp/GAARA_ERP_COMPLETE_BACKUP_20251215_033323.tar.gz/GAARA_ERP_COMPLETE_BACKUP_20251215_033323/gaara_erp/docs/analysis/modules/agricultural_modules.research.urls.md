# agricultural_modules.research.urls

## Imports
- django.urls
- rest_framework.routers
- views

## Module Variables
- `router`
- `app_name`
- `urlpatterns`

