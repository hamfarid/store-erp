# admin_modules.internal_diagnosis_module.__init__

## Module Variables
- `default_app_config`

