# agricultural_modules.farms.integration_assets

## Imports
- business_modules.assets.models
- django.contrib.auth
- django.db
- django.shortcuts
- django.utils
- models

## Functions
- link_equipment_to_farm_activity
- assign_assets_to_farm
- transfer_asset_between_farms
- record_asset_maintenance_activity

