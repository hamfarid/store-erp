# business_modules.accounting.models.tax

## Imports
- business_modules.accounting

## Module Variables
- `Tax`
- `TaxGroup`
- `TaxGroupLine`

