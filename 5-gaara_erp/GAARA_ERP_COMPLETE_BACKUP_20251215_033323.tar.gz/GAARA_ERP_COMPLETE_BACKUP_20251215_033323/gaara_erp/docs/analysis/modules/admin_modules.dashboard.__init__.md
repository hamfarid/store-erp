# admin_modules.dashboard.__init__

## Module Variables
- `default_app_config`

