# agricultural_modules.seed_hybridization.urls

## Imports
- django.urls
- rest_framework
- rest_framework.routers

## Module Variables
- `app_name`
- `router`
- `urlpatterns`

