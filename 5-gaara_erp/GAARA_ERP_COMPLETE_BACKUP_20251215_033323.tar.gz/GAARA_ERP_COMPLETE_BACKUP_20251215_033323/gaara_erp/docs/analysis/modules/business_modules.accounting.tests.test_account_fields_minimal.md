# business_modules.accounting.tests.test_account_fields_minimal

## Imports
- business_modules.accounting.models
- core_modules.core.models
- django.contrib.auth
- django.db
- pytest

## Functions
- test_account_model_has_currency_field
- test_account_table_has_user_tracking_columns
- test_create_account_and_set_user_tracking

## Module Variables
- `pytestmark`

