# admin_modules.communication.views

## Imports
- django.http
- django.shortcuts
- rest_framework.decorators
- rest_framework.response

## Functions
- list_view
- detail_view

