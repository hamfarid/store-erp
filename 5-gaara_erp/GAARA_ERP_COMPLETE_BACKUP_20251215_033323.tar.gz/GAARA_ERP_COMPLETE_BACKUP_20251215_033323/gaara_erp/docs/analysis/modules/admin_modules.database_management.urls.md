# admin_modules.database_management.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

