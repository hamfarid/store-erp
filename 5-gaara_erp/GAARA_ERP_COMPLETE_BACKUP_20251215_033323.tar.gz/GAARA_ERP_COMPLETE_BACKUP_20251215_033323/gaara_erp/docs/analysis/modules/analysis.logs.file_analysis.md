# analysis.logs.file_analysis

## Imports
- collections
- csv
- datetime
- json
- os
- pathlib

## Functions
- analyze_files

