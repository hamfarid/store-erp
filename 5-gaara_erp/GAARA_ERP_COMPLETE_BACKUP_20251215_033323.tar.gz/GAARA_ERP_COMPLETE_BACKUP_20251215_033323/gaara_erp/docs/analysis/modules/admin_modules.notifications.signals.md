# admin_modules.notifications.signals

## Imports
- django.conf
- django.db.models.signals
- django.dispatch
- logging
- models

## Functions
- log_notification_creation

## Module Variables
- `logger`

