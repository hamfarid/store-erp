# admin_modules.notifications.urls

## Imports
- django.urls

## Module Variables
- `urlpatterns`
- `app_name`

