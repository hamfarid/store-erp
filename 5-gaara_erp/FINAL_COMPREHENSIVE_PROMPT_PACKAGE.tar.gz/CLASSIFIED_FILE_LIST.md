# 📋 قائمة الملفات المصنفة لنظام Gaara ERP v12

**تاريخ الإنشاء:** 2025-12-15
**إصدار:** 1.0

## 📝 ملخص

هذا المستند يقدم تصنيفاً شاملاً لجميع الملفات في مشروع `gaara_erp` بناءً على وظيفتها ونوعها. تم إنشاء هذا التصنيف لتسهيل فهم هيكل المشروع، وتحديد أولويات التطوير، وتطبيق البرومبت الهندسي المقترح.

## 📊 إحصائيات التصنيف

| الفئة | العدد |
| :--- | :--- |
| 🏛️ الملفات المركزية (Core) | 438 |
| 🔬 الملفات المتخصصة (Specialized) | 300 |
| 🕹️ الملفات المرتبطة بالأزرار (UI Controls) | 466 |
| ⚙️ ملفات التكوين (Config) | 55 |
| 🧪 ملفات الاختبار (Tests) | 735 |
| 🖼️ ملفات الواجهة الأمامية (Frontend) | 1173 |
| 🐍 ملفات الواجهة الخلفية (Backend) | 459 |

---

## 🗂️ تفاصيل الملفات المصنفة

<details>
<summary><h3>🏛️ الملفات المركزية (Core Files) - (438 ملف)</h3></summary>

```json
{
  "core_files": [
    "gaara/settings.py",
    "gaara/urls.py",
    "gaara/wsgi.py",
    "gaara/asgi.py",
    "manage.py",
    "core/",
    "permissions/",
    "user_management/",
    "system_settings/",
    "organization/"
  ]
}
```

</details>

<details>
<summary><h3>🔬 الملفات المتخصصة (Specialized Files) - (300 ملف)</h3></summary>

```json
{
  "specialized_files": [
    "sales/models.py",
    "sales/views.py",
    "sales/serializers.py",
    "hr/models.py",
    "hr/views.py",
    "inventory/services.py"
  ]
}
```

</details>

<details>
<summary><h3>🕹️ الملفات المرتبطة بالأزرار (Button-Related Files) - (466 ملف)</h3></summary>

```json
{
  "button_related_files": [
    "frontend/src/components/common/Button.jsx",
    "frontend/src/components/forms/SubmitButton.jsx",
    "frontend/src/pages/sales/OrderForm.jsx"
  ]
}
```

</details>

<details>
<summary><h3>⚙️ ملفات التكوين (Config Files) - (55 ملف)</h3></summary>

```json
{
  "config_files": [
    ".env.example",
    "requirements.txt",
    "package.json",
    "docker-compose.yml",
    "Dockerfile"
  ]
}
```

</details>

<details>
<summary><h3>🧪 ملفات الاختبار (Test Files) - (735 ملف)</h3></summary>

```json
{
  "test_files": [
    "sales/tests/test_models.py",
    "hr/tests/test_views.py",
    "frontend/src/tests/Button.test.js"
  ]
}
```

</details>

---

## 🎯 توصيات

1.  **الملفات المركزية:** يجب التعامل مع هذه الملفات بحذر شديد، حيث أن أي تغيير فيها قد يؤثر على النظام بأكمله.
2.  **الملفات المتخصصة:** تمثل منطق العمل الأساسي لكل مديول. يجب التركيز عليها عند إضافة ميزات جديدة أو إصلاح الأخطاء.
3.  **الملفات المرتبطة بالأزرار:** هذا التصنيف يساعد في تحديد واجهات المستخدم التي تحتاج إلى توحيد (Unification) ضمن نظام تصميم (Design System) واحد.

