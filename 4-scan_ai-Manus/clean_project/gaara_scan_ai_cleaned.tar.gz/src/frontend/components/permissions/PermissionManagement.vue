<template>
  <div class="permission-management">
    <!-- هذا المكون تم دمجه ضمن RoleManagement.vue -->
    <p>إدارة الصلاحيات متاحة الآن ضمن علامة التبويب "الصلاحيات" في مكون إدارة الأدوار.</p>
    <!-- يمكنك إضافة محتوى إضافي خاص بالصلاحيات هنا إذا لزم الأمر -->
  </div>
</template>

<script>
/**
 * @component PermissionManagement
 * @description مكون لإدارة الصلاحيات (تم دمجه في RoleManagement.vue)
 * 
 * @author فريق Scan AI
 * @date 30 مايو 2025
 */
export default {
  name: 'PermissionManagement',
  // ... (يمكن إضافة منطق خاص إذا فصلت المكون لاحقاً)
};
</script>

<style scoped>
.permission-management {
  padding: 20px;
  text-align: center;
  color: #666;
}
</style>
