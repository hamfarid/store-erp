"""
مسار الملف: /home/ubuntu/gaara_scan_ai_final_4.2/src/modules/activity_log/api.py
الوصف: واجهة برمجة التطبيقات لمديول سجل النشاط
المؤلف: فريق Gaara ERP
تاريخ الإنشاء: 29 مايو 2025
"""

from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

from fastapi import APIRouter, Depends, BackgroundTasks, Query, Response
from sqlalchemy.orm import Session

from src.database import get_db
from src.modules.auth.service import get_current_user, get_current_active_user, check_permission
from src.modules.activity_log import schemas, service

# تعريف الثوابت
MODULE_ID_DESC = "معرف المديول"
ACTION_ID_DESC = "معرف الإجراء"

router = APIRouter(
    prefix="/api/activity-log",
    tags=["activity_log"],
    responses={404: {"description": "Not found"}},
)


@router.post("/", response_model=schemas.ActivityLogResponse)
async def create_activity_log(
    log_data: schemas.ActivityLogCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    إنشاء سجل نشاط جديد

    Args:
        log_data (schemas.ActivityLogCreate): بيانات سجل النشاط
        background_tasks (BackgroundTasks): مهام خلفية
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogResponse: سجل النشاط المنشأ
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "create")

    # إنشاء سجل النشاط
    activity_log = await service.create_activity_log(db, log_data, background_tasks)

    return activity_log


@router.get("/", response_model=schemas.PaginatedActivityLogs)
async def get_activity_logs(
    log_type: Optional[str] = Query(None, description="نوع السجل (system, user, ai)"),
    module_id: Optional[str] = Query(None, description=MODULE_ID_DESC),
    action_id: Optional[str] = Query(None, description=ACTION_ID_DESC),
    user_id: Optional[int] = Query(None, description="معرف المستخدم"),
    status: Optional[str] = Query(None, description="حالة السجل"),
    start_date: Optional[str] = Query(None, description="تاريخ البداية (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="تاريخ النهاية (YYYY-MM-DD)"),
    search: Optional[str] = Query(None, description="نص البحث"),
    page: int = Query(1, description="رقم الصفحة"),
    page_size: int = Query(20, description="حجم الصفحة"),
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على سجلات النشاط مع التصفية

    Args:
        log_type (Optional[str]): نوع السجل (system, user, ai)
        module_id (Optional[str]): معرف المديول
        action_id (Optional[str]): معرف الإجراء
        user_id (Optional[int]): معرف المستخدم
        status (Optional[str]): حالة السجل
        start_date (Optional[str]): تاريخ البداية (YYYY-MM-DD)
        end_date (Optional[str]): تاريخ النهاية (YYYY-MM-DD)
        search (Optional[str]): نص البحث
        page (int): رقم الصفحة
        page_size (int): حجم الصفحة
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.PaginatedActivityLogs: سجلات النشاط المقسمة إلى صفحات
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # تحويل التواريخ إلى كائنات datetime إذا كانت موجودة
    start_date_obj = None
    end_date_obj = None

    if start_date:
        start_date_obj = datetime.strptime(start_date, "%Y-%m-%d")

    if end_date:
        end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")
        # إضافة يوم كامل لتضمين اليوم الأخير
        end_date_obj = end_date_obj + timedelta(days=1)

    # إنشاء كائن التصفية
    filters = schemas.ActivityLogFilter(
        log_type=log_type,
        module_id=module_id,
        action_id=action_id,
        user_id=user_id,
        status=status,
        start_date=start_date_obj,
        end_date=end_date_obj,
        search=search,
        page=page,
        page_size=page_size
    )

    # الحصول على سجلات النشاط
    logs, total = await service.get_activity_logs(db, filters)

    # حساب إجمالي الصفحات
    total_pages = (total + page_size - 1) // page_size

    return schemas.PaginatedActivityLogs(
        items=logs,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/{log_id}", response_model=schemas.ActivityLogResponse)
async def get_activity_log(
    log_id: int,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على سجل نشاط بواسطة المعرف

    Args:
        log_id (int): معرف سجل النشاط
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogResponse: سجل النشاط
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على سجل النشاط
    log = await service.get_activity_log_by_id(db, log_id)

    return log


@router.get("/system/{activity_log_id}", response_model=schemas.SystemLogResponse)
async def get_system_log(
    activity_log_id: int,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على سجل النظام بواسطة معرف سجل النشاط

    Args:
        activity_log_id (int): معرف سجل النشاط
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.SystemLogResponse: سجل النظام
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على سجل النظام
    log = await service.get_system_log_by_activity_id(db, activity_log_id)

    return log


@router.get("/user/{activity_log_id}", response_model=schemas.UserLogResponse)
async def get_user_log(
    activity_log_id: int,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على سجل المستخدم بواسطة معرف سجل النشاط

    Args:
        activity_log_id (int): معرف سجل النشاط
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.UserLogResponse: سجل المستخدم
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على سجل المستخدم
    log = await service.get_user_log_by_activity_id(db, activity_log_id)

    return log


@router.get("/ai/{activity_log_id}", response_model=schemas.AILogResponse)
async def get_ai_log(
    activity_log_id: int,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على سجل الذكاء الاصطناعي بواسطة معرف سجل النشاط

    Args:
        activity_log_id (int): معرف سجل النشاط
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.AILogResponse: سجل الذكاء الاصطناعي
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على سجل الذكاء الاصطناعي
    log = await service.get_ai_log_by_activity_id(db, activity_log_id)

    return log


@router.get("/modules", response_model=List[schemas.LogModuleResponse])
async def get_log_modules(
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على مديولات السجل

    Args:
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        List[schemas.LogModuleResponse]: مديولات السجل
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على مديولات السجل
    modules = await service.get_log_modules(db)

    return modules


@router.get("/actions", response_model=List[schemas.LogActionResponse])
async def get_log_actions(
    module_id: Optional[str] = Query(None, description="معرف المديول"),
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على إجراءات السجل

    Args:
        module_id (Optional[str]): معرف المديول
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        List[schemas.LogActionResponse]: إجراءات السجل
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على إجراءات السجل
    actions = await service.get_log_actions(db, module_id)

    return actions


@router.get("/statistics", response_model=schemas.ActivityLogStatistics)
async def get_activity_log_statistics(
    days: int = Query(30, description="عدد الأيام"),
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    الحصول على إحصائيات سجل النشاط

    Args:
        days (int): عدد الأيام
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogStatistics: إحصائيات سجل النشاط
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "view")

    # الحصول على إحصائيات سجل النشاط
    statistics = await service.get_activity_log_statistics(db, days)

    return statistics


@router.post("/export")
async def export_activity_logs(
    export_data: schemas.ActivityLogExport,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    تصدير سجلات النشاط

    Args:
        export_data (schemas.ActivityLogExport): بيانات التصدير
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        Response: ملف التصدير
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "export")

    # تصدير سجلات النشاط
    export_bytes = await service.export_activity_logs(db, export_data)

    # تحديد نوع المحتوى
    content_type = "text/csv"
    if export_data.export_format == "xlsx":
        content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif export_data.export_format == "pdf":
        content_type = "application/pdf"

    # إنشاء اسم الملف
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"activity_logs_{timestamp}.{export_data.export_format}"

    # إنشاء الاستجابة
    response = Response(content=export_bytes)
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    response.headers["Content-Type"] = content_type

    return response


@router.post("/cleanup")
async def cleanup_old_logs(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    تنظيف السجلات القديمة

    Args:
        background_tasks (BackgroundTasks): مهام خلفية
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        Dict[str, Any]: نتيجة التنظيف
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "manage")

    # تنظيف السجلات القديمة
    result = await service.cleanup_old_logs(db, background_tasks)

    return result


# واجهات برمجة التطبيقات للتكامل مع المديولات الأخرى

@router.post("/system-event", response_model=schemas.ActivityLogResponse)
async def log_system_event(
    component: str = Query(..., description="المكون"),
    event_type: str = Query(..., description="نوع الحدث"),
    severity: str = Query(..., description="مستوى الخطورة"),
    message: str = Query(..., description="الرسالة"),
    details: Optional[Dict[str, Any]] = None,
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    تسجيل حدث نظام

    Args:
        component (str): المكون
        event_type (str): نوع الحدث
        severity (str): مستوى الخطورة
        message (str): الرسالة
        details (Optional[Dict[str, Any]]): تفاصيل إضافية
        background_tasks (BackgroundTasks): مهام خلفية
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogResponse: سجل النشاط المنشأ
    """
    # تسجيل حدث النظام
    log = await service.log_system_event(
        db,
        component,
        event_type,
        severity,
        message,
        details,
        background_tasks
    )

    return log


@router.post("/user-action", response_model=schemas.ActivityLogResponse)
async def log_user_action(
    action_data: schemas.UserActionLogCreate,
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    تسجيل إجراء مستخدم

    Args:
        action_data (schemas.UserActionLogCreate): بيانات إجراء المستخدم
        background_tasks (BackgroundTasks): مهام خلفية
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogResponse: سجل النشاط
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "create")

    # إنشاء سجل النشاط
    log = await service.create_user_action_log(db, action_data, background_tasks)

    return log


@router.post("/ai-interaction", response_model=schemas.ActivityLogResponse)
async def log_ai_interaction(
    interaction_data: schemas.AIInteractionLogCreate,
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    تسجيل تفاعل الذكاء الاصطناعي

    Args:
        interaction_data (schemas.AIInteractionLogCreate): بيانات تفاعل الذكاء الاصطناعي
        background_tasks (BackgroundTasks): مهام خلفية
        db (Session): جلسة قاعدة البيانات
        current_user (Dict[str, Any]): المستخدم الحالي

    Returns:
        schemas.ActivityLogResponse: سجل النشاط
    """
    # التحقق من الصلاحيات
    await check_permission(current_user, "activity_log", "create")

    # إنشاء سجل النشاط
    log = await service.create_ai_interaction_log(db, interaction_data, background_tasks)

    return log
