# File: /home/ubuntu/gaara_scan_ai_final_4.2/src/modules/feedback/__init__.py
"""
وحدة التغذية الراجعة (Feedback Module)
توفر هذه الوحدة آليات لجمع وإدارة التغذية الراجعة من المستخدمين
"""

from .service import feedback_service

__all__ = ['feedback_service']
