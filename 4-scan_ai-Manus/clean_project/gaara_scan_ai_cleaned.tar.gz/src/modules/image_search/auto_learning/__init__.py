# /home/ubuntu/image_search_integration/auto_learning/__init__.py
"""
مديول البحث الذاتي الذكي (Auto Learning Module)

هذا المديول مسؤول عن إدارة الكلمات المفتاحية والمصادر الموثوقة ومحركات البحث
لتحسين عمليات البحث الذاتي عن صور الإصابات والآفات النباتية.
"""

__author__ = 'Gaara ERP Development Team'
