# from flask import Flask, request, jsonify, g  # Removed: unused imports
# from flask_cors import CORS  # Removed: unused import
# from functools import wraps  # Removed: unused import
# File: /home/ubuntu/ai_web_organized/src/modules/disease_diagnosis/api.py

"""
واجهة برمجة التطبيقات لتشخيص الأمراض النباتية
توفر هذه الوحدة واجهات برمجية للتعامل مع المحاصيل والأمراض النباتية وتشخيصها
"""

import os
import json
import logging
from datetime import datetime
import shutil
from typing import List, Optional, Dict, Any

import yaml
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query
from fastapi.responses import JSONResponse

from src.modules.auth.api import get_current_user, check_permission
from . import db_service
from .diagnosis_engine import DiagnosisEngine

# Constants
CROP_NOT_FOUND = 'المحصول غير موجود'
DISEASE_NOT_FOUND = 'المرض غير موجود'

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# إنشاء موجه API
router = APIRouter(
    prefix="/api/disease-diagnosis",
    tags=["disease-diagnosis"],
    responses={404: {"description": "Not found"}},
)

# تهيئة محرك التشخيص
diagnosis_engine = DiagnosisEngine()

# مسار حفظ الصور
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# واجهات برمجية للمحاصيل


@router.get("/crops")
async def get_crops(current_user: dict = Depends(get_current_user)):
    """الحصول على قائمة المحاصيل"""
    try:
        crops = db_service.get_all_crops()
        return {"status": "success", "data": crops}
    except Exception as e:
        logger.error("خطأ في الحصول على المحاصيل: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/crops/{crop_id}")
async def get_crop(crop_id: int, current_user: dict = Depends(get_current_user)):
    """الحصول على محصول بواسطة المعرف"""
    try:
        crop = db_service.get_crop_by_id(crop_id)
        if not crop:
            raise HTTPException(status_code=404, detail=CROP_NOT_FOUND)
        return {"status": "success", "data": crop}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في الحصول على المحصول %s: %s", crop_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/crops")
async def create_crop(
    crop_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    """إنشاء محصول جديد"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_crops"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لإنشاء محاصيل جديدة")

    try:
        # التحقق من صحة البيانات
        if not crop_data.get("name"):
            raise HTTPException(status_code=400, detail="اسم المحصول مطلوب")

        crop = db_service.create_crop(crop_data)
        if not crop:
            raise HTTPException(status_code=400, detail="فشل إنشاء المحصول، قد يكون موجوداً بالفعل")

        return {"status": "success", "data": crop, "message": "تم إنشاء المحصول بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في إنشاء محصول جديد: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/crops/{crop_id}")
async def update_crop(
    crop_id: int,
    crop_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    """تحديث محصول موجود"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_crops"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لتحديث المحاصيل")

    try:
        crop = db_service.update_crop(crop_id, crop_data)
        if not crop:
            raise HTTPException(status_code=404, detail=CROP_NOT_FOUND)

        return {"status": "success", "data": crop, "message": "تم تحديث المحصول بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في تحديث المحصول %s: %s", crop_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/crops/{crop_id}")
async def delete_crop(
    crop_id: int,
    current_user: dict = Depends(get_current_user)
):
    """حذف محصول"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_crops"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لحذف المحاصيل")

    try:
        result = db_service.delete_crop(crop_id)
        if result is None:
            raise HTTPException(status_code=404, detail=CROP_NOT_FOUND)
        if result is False:
            raise HTTPException(status_code=400, detail="لا يمكن حذف المحصول لأنه مرتبط بأمراض")

        return {"status": "success", "data": result, "message": "تم حذف المحصول بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في حذف المحصول %s: %s", crop_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجية للأمراض


@router.get("/diseases")
async def get_diseases(
    crop_id: Optional[int] = None,
    current_user: dict = Depends(get_current_user)
):
    """الحصول على قائمة الأمراض"""
    try:
        if crop_id:
            diseases = db_service.get_diseases_by_crop(crop_id)
        else:
            diseases = db_service.get_all_diseases()

        return {"status": "success", "data": diseases}
    except Exception as e:
        logger.error("خطأ في الحصول على الأمراض: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/diseases/{disease_id}")
async def get_disease(
    disease_id: int,
    current_user: dict = Depends(get_current_user)
):
    """الحصول على مرض بواسطة المعرف"""
    try:
        disease = db_service.get_disease_by_id(disease_id)
        if not disease:
            raise HTTPException(status_code=404, detail=DISEASE_NOT_FOUND)

        return {"status": "success", "data": disease}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في الحصول على المرض %s: %s", disease_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/diseases")
async def create_disease(
    disease_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    """إنشاء مرض جديد"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_diseases"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لإنشاء أمراض جديدة")

    try:
        # التحقق من صحة البيانات
        if not disease_data.get("name"):
            raise HTTPException(status_code=400, detail="اسم المرض مطلوب")
        if not disease_data.get("cropId"):
            raise HTTPException(status_code=400, detail="معرف المحصول مطلوب")

        disease = db_service.create_disease(disease_data)
        if not disease:
            raise HTTPException(status_code=400, detail="فشل إنشاء المرض، قد يكون موجوداً بالفعل")

        return {"status": "success", "data": disease, "message": "تم إنشاء المرض بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في إنشاء مرض جديد: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/diseases/{disease_id}")
async def update_disease(
    disease_id: int,
    disease_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    """تحديث مرض موجود"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_diseases"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لتحديث الأمراض")

    try:
        disease = db_service.update_disease(disease_id, disease_data)
        if not disease:
            raise HTTPException(status_code=404, detail=DISEASE_NOT_FOUND)

        return {"status": "success", "data": disease, "message": "تم تحديث المرض بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في تحديث المرض %s: %s", disease_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/diseases/{disease_id}")
async def delete_disease(
    disease_id: int,
    current_user: dict = Depends(get_current_user)
):
    """حذف مرض"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_diseases"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لحذف الأمراض")

    try:
        result = db_service.delete_disease(disease_id)
        if result is None:
            raise HTTPException(status_code=404, detail=DISEASE_NOT_FOUND)
        if result is False:
            raise HTTPException(status_code=400, detail="لا يمكن حذف المرض لأنه مرتبط ببيانات أخرى")

        return {"status": "success", "data": result, "message": "تم حذف المرض بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في حذف المرض %s: %s", disease_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/diagnose")
async def diagnose_disease(
    symptoms: Optional[str] = Form(None),
    crop_id: Optional[int] = Form(None),
    image: Optional[UploadFile] = File(None),
    current_user: dict = Depends(get_current_user)
):
    """تشخيص مرض النبات"""
    try:
        # التحقق من وجود بيانات للتشخيص
        if not symptoms and not image:
            raise HTTPException(status_code=400, detail="يجب توفير الأعراض أو صورة للتشخيص")

        # معالجة الصورة إذا تم رفعها
        image_path = None
        if image:
            # التحقق من نوع الملف
            if not image.content_type.startswith('image/'):
                raise HTTPException(status_code=400, detail="يجب أن يكون الملف صورة")

            # حفظ الصورة
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"diagnosis_{timestamp}_{image.filename}"
            image_path = os.path.join(UPLOAD_DIR, filename)

            with open(image_path, "wb") as buffer:
                shutil.copyfileobj(image.file, buffer)

        # الحصول على نوع المحصول
        crop_type = None
        if crop_id:
            crop_data = db_service.get_crop_by_id(crop_id)
            if crop_data:
                crop_type = crop_data.get("name")

        # إجراء التشخيص
        diagnosis_result = diagnosis_engine.diagnose(
            symptoms=symptoms.split(',') if symptoms else None,
            crop_type=crop_type
        )

        # حفظ نتيجة التشخيص في قاعدة البيانات
        diagnosis_data = {
            "userId": current_user.get("id"),
            "symptoms": symptoms,
            "cropId": crop_id,
            "imagePath": image_path,
            "result": json.dumps(diagnosis_result, ensure_ascii=False),
            "confidence": diagnosis_result.get("confidence", 0.0),
            "diagnosisDate": datetime.now()
        }

        saved_diagnosis = db_service.create_diagnosis(diagnosis_data)

        return {
            "status": "success",
            "data": {
                "diagnosis_id": saved_diagnosis["id"],
                "result": diagnosis_result
            },
            "message": "تم التشخيص بنجاح"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في تشخيص المرض: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/diagnoses")
async def get_diagnoses(
    user_id: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    """الحصول على قائمة التشخيصات"""
    try:
        # التحقق من الصلاحيات للوصول إلى تشخيصات المستخدمين الآخرين
        if user_id and user_id != current_user.get("id") and not check_permission(current_user, "view_all_diagnoses"):
            raise HTTPException(status_code=403, detail="ليس لديك صلاحية لعرض تشخيصات المستخدمين الآخرين")

        # استخدام معرف المستخدم الحالي إذا لم يتم تحديد معرف آخر
        target_user_id = user_id or current_user.get("id")

        diagnoses = db_service.get_diagnoses_by_user(target_user_id)

        return {"status": "success", "data": diagnoses}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في الحصول على التشخيصات: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/diagnoses/{diagnosis_id}")
async def get_diagnosis(
    diagnosis_id: int,
    current_user: dict = Depends(get_current_user)
):
    """الحصول على تشخيص بواسطة المعرف"""
    try:
        diagnosis = db_service.get_diagnosis_by_id(diagnosis_id)
        if not diagnosis:
            raise HTTPException(status_code=404, detail="التشخيص غير موجود")

        # التحقق من الصلاحيات للوصول إلى تشخيصات المستخدمين الآخرين
        if diagnosis["userId"] != current_user.get("id") and not check_permission(current_user, "view_all_diagnoses"):
            raise HTTPException(status_code=403, detail="ليس لديك صلاحية لعرض هذا التشخيص")

        return {"status": "success", "data": diagnosis}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في الحصول على التشخيص %s: %s", diagnosis_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/diagnoses/{diagnosis_id}")
async def delete_diagnosis(
    diagnosis_id: int,
    current_user: dict = Depends(get_current_user)
):
    """حذف تشخيص"""
    try:
        diagnosis = db_service.get_diagnosis_by_id(diagnosis_id)
        if not diagnosis:
            raise HTTPException(status_code=404, detail="التشخيص غير موجود")

        # التحقق من الصلاحيات لحذف تشخيصات المستخدمين الآخرين
        if diagnosis["userId"] != current_user.get("id") and not check_permission(current_user, "manage_all_diagnoses"):
            raise HTTPException(status_code=403, detail="ليس لديك صلاحية لحذف هذا التشخيص")

        result = db_service.delete_diagnosis(diagnosis_id)
        if not result:
            raise HTTPException(status_code=500, detail="فشل حذف التشخيص")

        return {"status": "success", "data": result, "message": "تم حذف التشخيص بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في حذف التشخيص %s: %s", diagnosis_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجية للبحث


@router.get("/search")
async def search_diseases_api(
    query: str,
    crop_id: Optional[int] = None,
    current_user: dict = Depends(get_current_user)
):
    """البحث عن الأمراض"""
    try:
        diseases = db_service.search_diseases(query, crop_id)
        return {"status": "success", "data": diseases}
    except Exception as e:
        logger.error("خطأ في البحث عن الأمراض: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/search-by-symptoms")
async def search_by_symptoms_api(
    symptoms: List[str],
    crop_id: Optional[int] = None,
    current_user: dict = Depends(get_current_user)
):
    """البحث عن الأمراض بواسطة الأعراض"""
    try:
        if not symptoms:
            raise HTTPException(status_code=400, detail="يجب توفير قائمة الأعراض للبحث")

        results = db_service.search_by_symptoms(symptoms, crop_id)
        return {"status": "success", "data": results}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في البحث عن الأمراض بواسطة الأعراض: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجية لإدارة قاعدة المعرفة


@router.post("/import-knowledge-base")
async def import_knowledge_base(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """استيراد قاعدة المعرفة من ملف"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_knowledge_base"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لاستيراد قاعدة المعرفة")

    try:
        # التحقق من صيغة الملف
        filename = file.filename.lower()
        if not (filename.endswith('.yaml') or filename.endswith('.yml') or filename.endswith('.json')):
            raise HTTPException(status_code=400, detail="صيغة الملف غير مدعومة. يجب أن تكون YAML أو JSON")

        # حفظ الملف مؤقتاً
        temp_file = os.path.join(UPLOAD_DIR, f"temp_{filename}")
        with open(temp_file, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # قراءة الملف
        if filename.endswith('.json'):
            with open(temp_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:  # YAML
            with open(temp_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)

        # استيراد البيانات
        session = db_service.Session()
        success = db_service.import_from_knowledge_base(data, session)

        # حذف الملف المؤقت
        os.remove(temp_file)

        if not success:
            raise HTTPException(status_code=500, detail="فشل استيراد قاعدة المعرفة")

        return {"status": "success", "message": "تم استيراد قاعدة المعرفة بنجاح"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ في استيراد قاعدة المعرفة: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/export-knowledge-base")
async def export_knowledge_base(
    export_format: str = Query("json", regex="^(json|yaml)$"),
    current_user: dict = Depends(get_current_user)
):
    """تصدير قاعدة المعرفة إلى ملف"""
    # التحقق من الصلاحيات
    if not check_permission(current_user, "manage_knowledge_base"):
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لتصدير قاعدة المعرفة")

    try:
        # الحصول على جميع المحاصيل والأمراض
        crops_data = db_service.get_all_crops()

        # بناء قاعدة المعرفة
        knowledge_base = {"crops": []}

        for crop_data in crops_data:
            crop_id = crop_data["id"]
            diseases_data = db_service.get_diseases_by_crop(crop_id)

            crop_entry = {
                "name": crop_data["name"],
                "scientific_name": crop_data["scientificName"],
                "diseases": []
            }

            for disease_data in diseases_data:
                disease_entry = {
                    "name": disease_data["name"],
                    "scientific_name": disease_data["scientificName"],
                    "symptoms": disease_data["symptoms"],
                    "conditions": disease_data["conditions"],
                    "treatments": disease_data["treatments"],
                    "prevention": disease_data["preventions"],
                    "images": [img["filePath"] for img in disease_data["images"]]
                }

                crop_entry["diseases"].append(disease_entry)

            knowledge_base["crops"].append(crop_entry)

        # تحديد نوع المحتوى والملف
        if export_format == "json":
            content = json.dumps(knowledge_base, ensure_ascii=False, indent=2)
            media_type = "application/json"
            filename = "disease_knowledge.json"
        else:  # yaml
            content = yaml.dump(knowledge_base, allow_unicode=True, default_flow_style=False)
            media_type = "application/x-yaml"
            filename = "disease_knowledge.yaml"

        # إرجاع الملف للتنزيل
        return JSONResponse(
            content=content,
            media_type=media_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        logger.error("خطأ في تصدير قاعدة المعرفة: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e
