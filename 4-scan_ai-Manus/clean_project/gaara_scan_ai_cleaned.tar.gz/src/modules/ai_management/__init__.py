"""
from flask import g
مديول إدارة الذكاء الصناعي
يوفر هذا المديول وظائف لإدارة وكلاء الذكاء الصناعي وإحصائياتهم وإعداداتهم وصلاحياتهم
"""

__all__ = [
    # keep other exports, but remove 'register_api'
]
