import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Body

from src.modules.ai_management.db_service import (
    get_all_agents, get_agent_by_id, create_agent, update_agent, delete_agent,
    change_agent_status, get_ai_stats, get_model_stats, get_daily_stats,
    get_agent_stats, get_ai_settings, update_ai_settings, get_all_permissions,
    get_roles, get_user_roles, get_agent_roles, update_permissions,
    get_user_conversations, get_conversation, create_conversation,
    add_message, end_conversation
)

from src.modules.auth.auth_service import get_current_user

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI router
router = APIRouter(prefix="/api/ai", tags=["ai_management"])

# Define constants for repeated error messages
UNAUTHORIZED_MSG = "Unauthorized access to conversation"
CONVERSATION_NOT_FOUND_MSG = "Conversation not found"

# واجهات برمجة التطبيقات للوكلاء


@router.get("/agents", response_model=List[dict])
async def get_agents_api(current_user: dict = Depends(get_current_user)):
    """الحصول على قائمة وكلاء الذكاء الصناعي"""
    try:
        agents = get_all_agents()
        return agents
    except Exception as e:
        logger.error("خطأ أثناء استرجاع الوكلاء: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/agents/{agent_id}", response_model=dict)
async def get_agent_api(agent_id: int, current_user: dict = Depends(get_current_user)):
    """الحصول على تفاصيل وكيل محدد"""
    try:
        agent = get_agent_by_id(agent_id)

        if agent:
            return agent
        else:
            raise HTTPException(status_code=404, detail="Agent not found")
    except Exception as e:
        logger.error("خطأ أثناء استرجاع الوكيل %s: %s", agent_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/agents", response_model=dict)
async def create_agent_api(new_agent: dict = Body(...), current_user: dict = Depends(get_current_user)):
    """إنشاء وكيل جديد"""
    try:
        result = create_agent(new_agent)

        if result:
            return result
        else:
            raise HTTPException(status_code=500, detail="Failed to create agent")
    except Exception as e:
        logger.error("خطأ أثناء إنشاء وكيل جديد: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/agents/{agent_id}", response_model=dict)
async def update_agent_api(agent_id: int, updated_agent: dict = Body(...), current_user: dict = Depends(get_current_user)):
    """تحديث وكيل موجود"""
    try:
        result = update_agent(agent_id, updated_agent)

        if result:
            return result
        else:
            raise HTTPException(status_code=404, detail="Agent not found or update failed")
    except Exception as e:
        logger.error("خطأ أثناء تحديث الوكيل %s: %s", agent_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/agents/{agent_id}", response_model=dict)
async def delete_agent_api(agent_id: int, current_user: dict = Depends(get_current_user)):
    """حذف وكيل"""
    try:
        result = delete_agent(agent_id)

        if result:
            return {"message": "Agent deleted successfully", "agent": result}
        else:
            raise HTTPException(status_code=404, detail="Agent not found or delete failed")
    except Exception as e:
        logger.error("خطأ أثناء حذف الوكيل %s: %s", agent_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/agents/{agent_id}/status", response_model=dict)
async def change_agent_status_api(agent_id: int, status: dict = Body(...), current_user: dict = Depends(get_current_user)):
    """تغيير حالة وكيل"""
    try:
        if status.get('status') not in ['active', 'suspended', 'stopped']:
            raise HTTPException(status_code=400, detail="Invalid status. Must be 'active', 'suspended', or 'stopped'")

        result = change_agent_status(agent_id, status.get('status'))

        if result:
            return {"message": f"Agent status changed to {status.get('status')}", "agent": result}
        else:
            raise HTTPException(status_code=404, detail="Agent not found or status change failed")
    except Exception as e:
        logger.error("خطأ أثناء تغيير حالة الوكيل %s: %s", agent_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجة التطبيقات للإحصائيات


@router.get("/stats", response_model=dict)
async def get_stats_api(current_user: dict = Depends(get_current_user)):
    """الحصول على إحصائيات الذكاء الصناعي"""
    try:
        stats = get_ai_stats()

        if stats:
            return stats
        else:
            raise HTTPException(status_code=404, detail="Stats not found")
    except Exception as e:
        logger.error("خطأ أثناء استرجاع إحصائيات الذكاء الصناعي: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/model_stats", response_model=dict)
async def get_model_stats_api(current_user: dict = Depends(get_current_user)):
    """الحصول على إحصائيات استخدام النماذج"""
    try:
        model_stats = get_model_stats()
        return model_stats
    except Exception as e:
        logger.error("خطأ أثناء استرجاع إحصائيات النماذج: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/daily_stats", response_model=dict)
async def get_daily_stats_api(current_user: dict = Depends(get_current_user)):
    """الحصول على إحصائيات الاستخدام اليومي"""
    try:
        daily_stats = get_daily_stats()
        return daily_stats
    except Exception as e:
        logger.error("خطأ أثناء استرجاع إحصائيات الاستخدام اليومي: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/agents/{agent_id}/stats", response_model=dict)
async def get_agent_stats_api(agent_id: int, current_user: dict = Depends(get_current_user)):
    """الحصول على إحصائيات وكيل محدد"""
    try:
        agent_stats = get_agent_stats(agent_id)
        return agent_stats
    except Exception as e:
        logger.error("خطأ أثناء استرجاع إحصائيات الوكيل %s: %s", agent_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجة التطبيقات للإعدادات


@router.get("/settings", response_model=dict)
async def get_settings_api(current_user: dict = Depends(get_current_user)):
    """الحصول على إعدادات الذكاء الصناعي"""
    try:
        settings = get_ai_settings()

        if settings:
            return settings
        else:
            raise HTTPException(status_code=404, detail="Settings not found")
    except Exception as e:
        logger.error("خطأ أثناء استرجاع إعدادات الذكاء الصناعي: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/settings", response_model=dict)
async def update_settings_api(updated_settings: dict = Body(...), current_user: dict = Depends(get_current_user)):
    """تحديث إعدادات الذكاء الصناعي"""
    try:
        result = update_ai_settings(updated_settings)

        if result:
            return result
        else:
            raise HTTPException(status_code=500, detail="Failed to update settings")
    except Exception as e:
        logger.error("خطأ أثناء تحديث إعدادات الذكاء الصناعي: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجة التطبيقات للصلاحيات


@router.get("/permissions", response_model=List[dict])
async def get_permissions_api(current_user: dict = Depends(get_current_user)):
    """الحصول على قائمة الصلاحيات"""
    try:
        permissions = get_all_permissions()

        if permissions:
            return permissions
        else:
            raise HTTPException(status_code=404, detail="Permissions not found")
    except Exception as e:
        logger.error("خطأ أثناء استرجاع الصلاحيات: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/permissions", response_model=dict)
async def update_permissions_api(updated_permissions: dict = Body(...), current_user: dict = Depends(get_current_user)):
    """تحديث الصلاحيات"""
    try:
        result = update_permissions(updated_permissions)

        if result:
            return result
        else:
            raise HTTPException(status_code=500, detail="Failed to update permissions")
    except Exception as e:
        logger.error("خطأ أثناء تحديث الصلاحيات: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/roles", response_model=List[dict])
async def get_roles_api(current_user: dict = Depends(get_current_user)):
    """الحصول على قائمة الأدوار"""
    try:
        roles = get_roles()
        return roles
    except Exception as e:
        logger.error("خطأ أثناء استرجاع الأدوار: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/user_roles", response_model=List[dict])
async def get_user_roles_api(current_user: dict = Depends(get_current_user)):
    """الحصول على أدوار المستخدم"""
    try:
        user_roles = get_user_roles()
        return user_roles
    except Exception as e:
        logger.error("خطأ أثناء استرجاع أدوار المستخدم: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/agent_roles", response_model=List[dict])
async def get_agent_roles_api(current_user: dict = Depends(get_current_user)):
    """الحصول على أدوار الوكلاء"""
    try:
        agent_roles = get_agent_roles()
        return agent_roles
    except Exception as e:
        logger.error("خطأ أثناء استرجاع أدوار الوكلاء: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# واجهات برمجة التطبيقات للمحادثات


@router.get("/user_conversations", response_model=List[dict])
async def get_user_conversations_api(current_user: dict = Depends(get_current_user)):
    """الحصول على محادثات المستخدم"""
    try:
        conversations = get_user_conversations(current_user.get('id'))
        return conversations
    except Exception as e:
        logger.error("خطأ أثناء استرجاع محادثات المستخدم: %s", str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/conversations/{conversation_id}", response_model=dict)
async def get_conversation_api(conversation_id: int, current_user: dict = Depends(get_current_user)):
    """الحصول على تفاصيل محادثة محددة"""
    try:
        conversation = get_conversation(conversation_id)

        if not conversation:
            raise HTTPException(status_code=404, detail=CONVERSATION_NOT_FOUND_MSG)

        # التحقق من صلاحية الوصول للمحادثة
        if conversation.get('user_id') != current_user.get('id'):
            raise HTTPException(status_code=403, detail=UNAUTHORIZED_MSG)

        return conversation
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ أثناء استرجاع المحادثة %s: %s", conversation_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/conversations", response_model=dict)
async def create_conversation_api(
        current_user: dict = Depends(get_current_user),
        agent_id: str = Body(...)):
    """إنشاء محادثة جديدة"""
    try:
        user_id = current_user.get('id')

        result = create_conversation(user_id, agent_id)

        if result:
            return result
        else:
            raise HTTPException(status_code=500, detail="Failed to create conversation")
    except Exception as e:
        logger.error("خطأ أثناء إنشاء محادثة جديدة للمستخدم %s: %s",
                     current_user.get('id'), str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/conversations/{conversation_id}/messages", response_model=dict)
async def add_message_api(
        conversation_id: int,
        current_user: dict = Depends(get_current_user),
        message_type: str = Body(...),
        content: str = Body(...),
        tokens: int = Body(0)):
    """إضافة رسالة إلى محادثة"""
    try:
        # التحقق من وجود المحادثة وصلاحية الوصول
        conversation = get_conversation(conversation_id)
        if not conversation:
            raise HTTPException(status_code=404, detail=CONVERSATION_NOT_FOUND_MSG)

        if conversation.get('user_id') != current_user.get('id'):
            raise HTTPException(status_code=403, detail=UNAUTHORIZED_MSG)

        result = add_message(conversation_id, message_type, content, tokens)

        if result:
            return result
        else:
            raise HTTPException(status_code=500, detail="Failed to add message")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ أثناء إضافة رسالة للمحادثة %s: %s", conversation_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/conversations/{conversation_id}", response_model=dict)
async def end_conversation_api(conversation_id: int, current_user: dict = Depends(get_current_user)):
    """إنهاء محادثة"""
    try:
        # التحقق من وجود المحادثة وصلاحية الوصول
        conversation = get_conversation(conversation_id)
        if not conversation:
            raise HTTPException(status_code=404, detail=CONVERSATION_NOT_FOUND_MSG)

        if conversation.get('user_id') != current_user.get('id'):
            raise HTTPException(status_code=403, detail=UNAUTHORIZED_MSG)

        result = end_conversation(conversation_id)

        if result:
            return {"message": "Conversation ended successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to end conversation")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("خطأ أثناء إنهاء المحادثة %s: %s", conversation_id, str(e))
        raise HTTPException(status_code=500, detail=str(e)) from e

# تسجيل البلوبرنت في التطبيق
