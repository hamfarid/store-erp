# File: /home/ubuntu/ai_web_organized/src/modules/ai_management/ai_connectors/__init__.py
"""
from flask import g
حزمة موصلات وكلاء الذكاء الاصطناعي
توفر هذه الحزمة موصلات لمختلف أنواع وكلاء الذكاء الاصطناعي
"""

from .base_connector import BaseConnector

__all__ = ['BaseConnector']
