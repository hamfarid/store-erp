"""
/home/ubuntu/implemented_files/v3/src/modules/ai_agent/api.py

ملف واجهة برمجة التطبيقات (API) لمديول وكلاء الذكاء الاصطناعي

يوفر هذا الملف واجهة برمجة التطبيقات (API) لمديول وكلاء الذكاء الاصطناعي لنظام Gaara ERP، بما في ذلك:
- نقاط نهاية لإدارة الوكلاء
- نقاط نهاية لإدارة المهام
- نقاط نهاية لإدارة المحادثات
- نقاط نهاية للتفاعل مع الوكلاء
- نقاط نهاية للإحصائيات والتقييمات
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from sqlalchemy.orm import Session

from src.modules.ai_agent.schemas import (
    AIAgentCreate, AIAgentUpdate, AIAgentResponse, AIAgentList,
    AIAgentSearch, AgentTaskCreate, AgentTaskResponse,
    AgentConversationCreate, AgentConversationUpdate, AgentConversationResponse,
    AgentConversationDetailResponse, AgentConversationList,
    AgentMessageRequest, AgentMessageResponse,
    AgentTaskRequest, AgentTaskResultResponse,
    AgentFeedbackCreate, AgentFeedbackResponse,
    AgentStatsResponse
)
from src.modules.ai_agent.service import AIAgentService
from src.modules.permissions.service import PermissionService
from src.modules.database import get_db
from src.modules.auth import get_current_user_id, get_optional_current_user_id

# Constants
AGENT_ID_DESC = "معرف الوكيل"
AGENT_NOT_FOUND_MSG = "الوكيل غير موجود أو ليس لديك صلاحية الوصول إليه"
TASK_ID_DESC = "معرف المهمة"
CONVERSATION_ID_DESC = "معرف المحادثة"

# إنشاء موجه API
router = APIRouter(
    prefix="/api/v1/ai-agents",
    tags=["AI Agents"],
    responses={404: {"description": "Not found"}},
)


# ==================== نقاط نهاية إدارة الوكلاء ====================


@router.post("/", response_model=AIAgentResponse, status_code=status.HTTP_201_CREATED)
async def create_agent(
    agent_data: AIAgentCreate,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    إنشاء وكيل ذكاء اصطناعي جديد

    المعلمات:
        agent_data (AIAgentCreate): بيانات الوكيل المراد إنشاؤه
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AIAgentResponse: بيانات الوكيل المنشأ
    """
    # التحقق من صلاحيات إنشاء الوكلاء
    permission_service = PermissionService(db)
    if not permission_service.check_permission("ai_agent", "create_agent", current_user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="ليس لديك صلاحية إنشاء وكلاء الذكاء الاصطناعي"
        )

    # إنشاء الوكيل
    agent_service = AIAgentService(db)
    try:
        agent = agent_service.create_agent(agent_data, current_user_id)
        return agent
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"فشل إنشاء الوكيل: {str(e)}"
        ) from e


@router.get("/{agent_id}", response_model=AIAgentResponse)
async def get_agent(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: Optional[str] = Depends(get_optional_current_user_id)
):
    """
    استرجاع وكيل ذكاء اصطناعي بواسطة المعرف

    المعلمات:
        agent_id (str): معرف الوكيل
        db (Session): جلسة قاعدة البيانات
        current_user_id (Optional[str]): معرف المستخدم الحالي (اختياري)

    العوائد:
        AIAgentResponse: بيانات الوكيل
    """
    agent_service = AIAgentService(db)
    agent = agent_service.get_agent(agent_id, current_user_id)

    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=AGENT_NOT_FOUND_MSG
        )

    return agent


@router.put("/{agent_id}", response_model=AIAgentResponse)
async def update_agent(
    agent_data: AIAgentUpdate,
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    تحديث وكيل ذكاء اصطناعي

    المعلمات:
        agent_data (AIAgentUpdate): بيانات التحديث
        agent_id (str): معرف الوكيل
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AIAgentResponse: بيانات الوكيل المحدث
    """
    agent_service = AIAgentService(db)
    agent = agent_service.update_agent(agent_id, agent_data, current_user_id)

    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=AGENT_NOT_FOUND_MSG
        )

    return agent


@router.delete("/{agent_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_agent(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    حذف وكيل ذكاء اصطناعي

    المعلمات:
        agent_id (str): معرف الوكيل
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي
    """
    agent_service = AIAgentService(db)
    success = agent_service.delete_agent(agent_id, current_user_id)

    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=AGENT_NOT_FOUND_MSG
        )


@router.post("/search", response_model=AIAgentList)
async def search_agents(
    search_params: AIAgentSearch,
    db: Session = Depends(get_db),
    current_user_id: Optional[str] = Depends(get_optional_current_user_id)
):
    """
    البحث في وكلاء الذكاء الاصطناعي

    المعلمات:
        search_params (AIAgentSearch): معلمات البحث
        db (Session): جلسة قاعدة البيانات
        current_user_id (Optional[str]): معرف المستخدم الحالي (اختياري)

    العوائد:
        AIAgentList: قائمة الوكلاء المطابقة لمعلمات البحث
    """
    agent_service = AIAgentService(db)
    return agent_service.search_agents(search_params, current_user_id)


# ==================== نقاط نهاية إدارة المهام ====================


@router.post("/tasks", response_model=AgentTaskResponse, status_code=status.HTTP_201_CREATED)
async def create_task(
    task_data: AgentTaskCreate,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    إنشاء مهمة جديدة

    المعلمات:
        task_data (AgentTaskCreate): بيانات المهمة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentTaskResponse: بيانات المهمة المنشأة
    """
    agent_service = AIAgentService(db)
    return agent_service.create_task(task_data, current_user_id)


@router.get("/tasks/{task_id}", response_model=AgentTaskResponse)
async def get_task(
    task_id: str = Path(..., description=TASK_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع مهمة بواسطة المعرف

    المعلمات:
        task_id (str): معرف المهمة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentTaskResponse: بيانات المهمة
    """
    agent_service = AIAgentService(db)
    task = agent_service.get_task(task_id, current_user_id)

    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="المهمة غير موجودة أو ليس لديك صلاحية الوصول إليها"
        )

    return task


@router.post("/execute", response_model=AgentTaskResultResponse)
async def execute_task(
    task_request: AgentTaskRequest,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    تنفيذ مهمة

    المعلمات:
        task_request (AgentTaskRequest): طلب تنفيذ المهمة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentTaskResultResponse: نتيجة تنفيذ المهمة
    """
    agent_service = AIAgentService(db)
    return agent_service.execute_task(task_request, current_user_id)


# ==================== نقاط نهاية إدارة المحادثات ====================


@router.post("/conversations", response_model=AgentConversationResponse, status_code=status.HTTP_201_CREATED)
async def create_conversation(
    conversation_data: AgentConversationCreate,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    إنشاء محادثة جديدة

    المعلمات:
        conversation_data (AgentConversationCreate): بيانات المحادثة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentConversationResponse: بيانات المحادثة المنشأة
    """
    agent_service = AIAgentService(db)
    return agent_service.create_conversation(conversation_data, current_user_id)


@router.get("/conversations/{conversation_id}", response_model=AgentConversationDetailResponse)
async def get_conversation(
    conversation_id: str = Path(..., description=CONVERSATION_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع محادثة بواسطة المعرف

    المعلمات:
        conversation_id (str): معرف المحادثة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentConversationDetailResponse: بيانات المحادثة
    """
    agent_service = AIAgentService(db)
    conversation = agent_service.get_conversation(conversation_id, current_user_id)

    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="المحادثة غير موجودة أو ليس لديك صلاحية الوصول إليها"
        )

    return conversation


@router.put("/conversations/{conversation_id}", response_model=AgentConversationResponse)
async def update_conversation(
    conversation_data: AgentConversationUpdate,
    conversation_id: str = Path(..., description=CONVERSATION_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    تحديث محادثة

    المعلمات:
        conversation_data (AgentConversationUpdate): بيانات التحديث
        conversation_id (str): معرف المحادثة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentConversationResponse: بيانات المحادثة المحدثة
    """
    agent_service = AIAgentService(db)
    conversation = agent_service.update_conversation(conversation_id, conversation_data, current_user_id)

    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="المحادثة غير موجودة أو ليس لديك صلاحية تحديثها"
        )

    return conversation


@router.get("/agents/{agent_id}/conversations", response_model=AgentConversationList)
async def get_agent_conversations(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    page: int = Query(1, ge=1, description="رقم الصفحة"),
    page_size: int = Query(10, ge=1, le=100, description="حجم الصفحة"),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع محادثات وكيل

    المعلمات:
        agent_id (str): معرف الوكيل
        page (int): رقم الصفحة
        page_size (int): حجم الصفحة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentConversationList: قائمة محادثات الوكيل
    """
    agent_service = AIAgentService(db)
    return agent_service.get_agent_conversations(agent_id, page, page_size, current_user_id)


# ==================== نقاط نهاية التفاعل مع الوكلاء ====================


@router.post("/message", response_model=AgentMessageResponse)
async def send_message(
    message_request: AgentMessageRequest,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    إرسال رسالة إلى وكيل

    المعلمات:
        message_request (AgentMessageRequest): طلب إرسال الرسالة
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentMessageResponse: استجابة الوكيل
    """
    agent_service = AIAgentService(db)
    return agent_service.send_message(message_request, current_user_id)


# ==================== نقاط نهاية الإحصائيات والتقييمات ====================


@router.get("/agents/{agent_id}/stats", response_model=List[AgentStatsResponse])
async def get_agent_stats(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    start_date: Optional[datetime] = Query(None, description="تاريخ البداية"),
    end_date: Optional[datetime] = Query(None, description="تاريخ النهاية"),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع إحصائيات وكيل

    المعلمات:
        agent_id (str): معرف الوكيل
        start_date (Optional[datetime]): تاريخ البداية
        end_date (Optional[datetime]): تاريخ النهاية
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        List[AgentStatsResponse]: قائمة إحصائيات الوكيل
    """
    agent_service = AIAgentService(db)
    return agent_service.get_agent_stats(agent_id, start_date, end_date, current_user_id)


@router.post("/feedback", response_model=AgentFeedbackResponse, status_code=status.HTTP_201_CREATED)
async def create_feedback(
    feedback_data: AgentFeedbackCreate,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    إنشاء تقييم جديد

    المعلمات:
        feedback_data (AgentFeedbackCreate): بيانات التقييم
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        AgentFeedbackResponse: بيانات التقييم المنشأ
    """
    agent_service = AIAgentService(db)
    return agent_service.create_feedback(feedback_data, current_user_id)


@router.get("/agents/{agent_id}/feedback", response_model=List[AgentFeedbackResponse])
async def get_agent_feedback(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    limit: int = Query(10, ge=1, le=100, description="الحد الأقصى لعدد التقييمات"),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع تقييمات وكيل

    المعلمات:
        agent_id (str): معرف الوكيل
        limit (int): الحد الأقصى لعدد التقييمات
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        List[AgentFeedbackResponse]: قائمة تقييمات الوكيل
    """
    agent_service = AIAgentService(db)
    return agent_service.get_agent_feedback(agent_id, limit, current_user_id)


@router.get("/agents/{agent_id}/satisfaction", response_model=float)
async def get_agent_satisfaction(
    agent_id: str = Path(..., description=AGENT_ID_DESC),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id)
):
    """
    استرجاع درجة رضا المستخدمين عن وكيل

    المعلمات:
        agent_id (str): معرف الوكيل
        db (Session): جلسة قاعدة البيانات
        current_user_id (str): معرف المستخدم الحالي

    العوائد:
        float: درجة رضا المستخدمين
    """
    agent_service = AIAgentService(db)
    return agent_service.get_agent_satisfaction(agent_id, current_user_id)
