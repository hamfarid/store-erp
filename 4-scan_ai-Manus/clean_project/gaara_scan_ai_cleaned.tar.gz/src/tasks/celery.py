"""
تطبيق Celery للمهام المجدولة
"""
from src.celery_app import app as celery_app

# تصدير التطبيق للاستخدام في الجدولة
app = celery_app
