# خريطة وحدات نظام Gaara AI

**التاريخ:** 2025-11-15  
**الإصدار:** 1.1

---

## مقدمة

توفر هذه الوثيقة خريطة شاملة لجميع الوحدات (Modules) في نظام **Gaara AI**. الهدف هو توضيح بنية المشروع، وتحديد الغرض من كل وحدة، وتتبع حالتها. تم تصنيف الوحدات بناءً على وظائفها الرئيسية داخل النظام.

---

## تصنيفات الوحدات

تم تقسيم الوحدات إلى الفئات التالية لتسهيل الفهم والتنقل:

1.  **الوحدات الأساسية (Core Modules):** تشكل العمود الفقري للنظام وتوفر الوظائف الأساسية.
2.  **وحدات الأعمال (Business Modules):** تتعامل مع العمليات التجارية الرئيسية مثل المبيعات والمشتريات.
3.  **الوحدات الزراعية (Agricultural Modules):** مخصصة للوظائف الزراعية الذكية.
4.  **وحدات الذكاء الاصطناعي (AI Modules):** تحتوي على محركات ونماذج الذكاء الاصطناعي.
5.  **وحدات الإدارة والمراقبة (Admin & Monitoring):** أدوات لإدارة النظام ومراقبته.
6.  **وحدات الواجهة الأمامية (Frontend Modules):** مكونات وصفحات واجهة المستخدم.

---

## خريطة الوحدات التفصيلية

| اسم الوحدة (Module Name) | المسار الرئيسي | الملفات الرئيسية | الغرض الرئيسي | الحالة |
|---|---|---|---|---|
| **الوحدات الأساسية** | | | | |
| `main_api` | `backend/` | `main_api.py`, `app.py`, `config.py` | نقطة الدخول الرئيسية للواجهة الخلفية، وإعدادات التطبيق | ✅ مكتمل |
| `database` | `backend/` | `database.py`, `models.py` | إدارة اتصالات قاعدة البيانات وتعريف النماذج (SQLAlchemy) | ✅ مكتمل |
| `security` | `backend/` | `security_middleware.py`, `secure_config.py` | طبقة الأمان (JWT, CSRF, Rate Limiting) | ✅ مكتمل |
| `permissions` | `backend/` | `permissions.py`, `permissions_complete.py` | نظام إدارة الأدوار والصلاحيات | ✅ مكتمل |
| `routing` | `backend/` | `routes.py`, `routes_complete.py` | تعريف جميع مسارات API | ✅ مكتمل |
| **وحدات الأعمال** | | | | |
| `inventory_management` | `backend/` | `inventory_management_system.py` | إدارة المخزون والمنتجات والمستودعات | ✅ مكتمل |
| `equipment_management` | `backend/` | `equipment_management_system.py` | تتبع وإدارة المعدات والأصول | ✅ مكتمل |
| `hr_management` | `backend/` | `hr_management_system.py` | إدارة الموظفين والرواتب والحضور | ✅ مكتمل |
| `ecommerce_system` | `backend/` | `ecommerce_system.py` | منصة التجارة الإلكترونية لبيع المنتجات | ✅ مكتمل |
| **الوحدات الزراعية** | | | | |
| `farm_management` | `backend/` | `farm_management_advanced.py` | إدارة المزارع، الحقول، والمحاصيل | ✅ مكتمل |
| `iot_sensors` | `backend/` | `iot_sensors_system.py`, `iot_sensors_system_advanced.py` | التكامل مع حساسات إنترنت الأشياء وجمع البيانات | ✅ مكتمل |
| **وحدات الذكاء الاصطناعي** | | | | |
| `ai_diagnosis` | `backend/` | `ai_diagnosis.py`, `ai_plant_diagnosis_engine.py` | محرك تشخيص أمراض النباتات باستخدام الذكاء الاصطناعي | ✅ مكتمل |
| `predictive_analytics` | `backend/` | `predictive_analytics_system.py` | التحليلات التنبؤية للمحاصيل والطقس | ✅ مكتمل |
| `ai_agents` | `backend/` | `ai_agents_system.py` | وكلاء الذكاء الاصطناعي للمساعدة في اتخاذ القرار | ✅ مكتمل |
| **وحدات الإدارة والمراقبة** | | | | |
| `advanced_analytics` | `backend/` | `advanced_analytics_system.py` | نظام التحليلات المتقدمة ولوحات المعلومات | ✅ مكتمل |
| `advanced_reporting` | `backend/` | `advanced_reporting_system.py` | إنشاء تقارير ديناميكية وشاملة | ✅ مكتمل |
| `security_monitoring` | `backend/` | `advanced_security_monitoring.py` | مراقبة الأنشطة الأمنية وتسجيلها | ✅ مكتمل |
| **وحدات الواجهة الأمامية** | | | | |
| `App` | `frontend/src/` | `App.jsx`, `main.jsx` | المكون الرئيسي للتطبيق وإعدادات العرض | ✅ مكتمل |
| `Router` | `frontend/src/components/Router/` | `AppRouter.jsx` | نظام التوجيه وإدارة المسارات في الواجهة الأمامية | ✅ مكتمل |
| `Layout` | `frontend/src/components/Layout/` | `Sidebar.jsx`, `Navbar.jsx`, `Footer.jsx` | مكونات التخطيط الرئيسية (الشريط الجانبي، العلوي، التذييل) | ✅ مكتمل |
| `Dashboard` | `frontend/src/pages/Dashboard/` | `EnhancedDashboard.jsx` | صفحة لوحة التحكم الرئيسية | ✅ مكتمل |
| `Services` | `frontend/src/services/` | `ApiServiceEnhanced.js` | طبقة الاتصال مع الواجهة الخلفية (API) | ✅ مكتمل |
| `UI Components` | `frontend/src/components/ui/` | `button.jsx`, `card.jsx`, `table.jsx`... | مكتبة مكونات واجهة المستخدم القابلة لإعادة الاستخدام | ✅ مكتمل |

---

## ملاحظات

*   تمثل هذه الخريطة الوضع الحالي للمشروع. سيتم تحديثها باستمرار مع إضافة وحدات جديدة أو تعديل الوحدات الحالية.
*   جميع الوحدات المذكورة أعلاه تعتبر مكتملة من حيث الوظائف الأساسية والتكامل الأولي.
*   المرحلة التالية ستركز على ملء التفاصيل الدقيقة في ملفات التوثيق الأخرى بناءً على هذه الخريطة.
