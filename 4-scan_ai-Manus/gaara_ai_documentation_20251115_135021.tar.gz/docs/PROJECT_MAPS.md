# خرائط مشروع نظام Gaara AI

## نظرة عامة على المشروع

*   **اسم المشروع:** Gaara AI Smart Agriculture System
*   **النوع:** Full-Stack
*   **الواجهة الأمامية:** React, Vite, Tailwind CSS
*   **الواجهة الخلفية:** Python, Flask
*   **قاعدة البيانات:** SQLite / PostgreSQL

## الخرائط

### خريطة الواجهة الخلفية (Backend)

*   **خريطة الكلاسات (Class Map):** (سيتم إنشاؤها برمجياً)
*   **خريطة الاستيراد/التصدير (Import/Export Map):** (سيتم إنشاؤها برمجياً)
*  ### خريطة علاقات قاعدة البيانات (Database Relation Map)

تم إنشاء خريطة علاقات قاعدة البيانات باستخدام Mermaid لتمثيل الروابط بين النماذج الرئيسية في النظام.

```mermaid
erDiagram
    USER {
        int id PK
        string username
        string email
        string password_hash
        string role
    }

    COMPANY {
        int id PK
        string name
        string email
        string phone
    }

    FARM {
        int id PK
        string name
        string location
        int owner_id FK
        int company_id FK
    }

    FIELD {
        int id PK
        string name
        float area
        int farm_id FK
    }

    PLANT {
        int id PK
        string name
        string scientific_name
    }

    DISEASE {
        int id PK
        string name
        string description
    }

    DIAGNOSIS {
        int id PK
        string image_url
        string result
        int user_id FK
        int plant_id FK
    }

    SENSOR {
        int id PK
        string type
        string location
        int field_id FK
    }

    SENSOR_DATA {
        int id PK
        json value
        datetime timestamp
        int sensor_id FK
    }

    EQUIPMENT {
        int id PK
        string name
        string type
        int farm_id FK
    }

    INVENTORY_ITEM {
        int id PK
        string name
        int quantity
        int farm_id FK
    }

    PERMISSION {
        int id PK
        string name
        string module
    }

    USER ||--o{ FARM : owner
    USER ||--o{ DIAGNOSIS : user
    USER }o--o{ PERMISSION : user_permissions

    COMPANY ||--o{ USER : company
    COMPANY ||--o{ FARM : company

    FARM ||--o{ FIELD : farm
    FARM ||--o{ EQUIPMENT : farm
    FARM ||--o{ INVENTORY_ITEM : farm

    FIELD ||--o{ SENSOR : field
    FIELD ||--o{ CROP : field

    SENSOR ||--o{ SENSOR_DATA : sensor

    PLANT }o--o{ DISEASE : plant_diseases
    PLANT ||--o{ CROP : plant

```

### خريطة الواجهة الأمامية (Frontend)

*  ### هرمية المكونات (Component Hierarchy)

تم إنشاء هرمية المكونات باستخدام Mermaid لتمثيل بنية الواجهة الأمامية.

```mermaid
graph TD
    A[App] --> B(ErrorBoundary);
    B --> C(QueryClientProvider);
    C --> D(AuthProvider);
    D --> E(AppProvider);
    E --> F(Router);
    F --> G(Layout);
    G --> H{Routes};

    G --> I[Navbar];
    G --> J[Sidebar];
    G --> K[Footer];

    H --> L(Login);
    H --> M(ProtectedRoute);
    M --> N(Dashboard);
    M --> O(Profile);
    M --> P(Farms);
    M --> Q(Plants);
    M --> R(Diseases);
    M --> S(Diagnosis);
    M --> T(Crops);
    M --> U(Sensors);
    M --> V(Reports);
    M --> W(Analytics);
    M --> X(Users);
    M --> Y(Settings);

    subgraph "Pages"
        N; O; P; Q; R; S; T; U; V; W; X; Y;
    end

    subgraph "Layout Components"
        I; J; K;
    end

    subgraph "Providers"
        C; D; E;
    end
```
### تدفق الحالة (State Flow)

يتم إدارة الحالة في التطبيق عبر React Context API، مقسمة إلى سياقين رئيسيين:

1.  **AuthProvider:** لإدارة حالة المصادقة والمستخدم.
2.  **AppProvider:** لإدارة حالة التطبيق العامة (الثيم، اللغة، إلخ).

```mermaid
graph TD
    subgraph AuthProvider
        A1[user];
        A2[isAuthenticated];
        A3[loading];
        A4[login()];
        A5[logout()];
        A6[updateProfile()];
    end

    subgraph AppProvider
        B1[theme];
        B2[language];
        B3[sidebarOpen];
        B4[notifications];
        B5[toggleTheme()];
        B6[changeLanguage()];
        B7[toggleSidebar()];
    end

    subgraph Components
        C1[Login Page] -- calls --> A4;
        C2[Navbar] -- calls --> A5;
        C2 -- calls --> B5;
        C2 -- calls --> B6;
        C3[Sidebar] -- calls --> B7;
        C4[Profile Page] -- calls --> A6;
    end

    AuthProvider --> Components;
    AppProvider --> Components;
```

### خريطة استدعاءات الواجهة البرمجية (API Call Map)

تمثل هذه الخريطة كيفية تفاعل مكونات الواجهة الأمامية مع الواجهة الخلفية عبر `ApiServiceEnhanced`.

```mermaid
graph TD
    subgraph "Frontend Components"
        A[Login Page]
        B[Dashboard]
        C[Farms Page]
        D[Plants Page]
        E[Diagnosis Page]
        F[Sensors Page]
        G[Reports Page]
        H[Users Page]
    end

    subgraph "ApiServiceEnhanced"
        S1[login]
        S2[getDashboardData]
        S3[getFarms]
        S4[getPlants]
        S5[diagnoseImage]
        S6[getSensors]
        S7[getReports]
        S8[getUsers]
    end

    subgraph "Backend API Endpoints"
        E1[/api/auth/login]
        E2[/api/analytics/dashboard]
        E3[/api/farms]
        E4[/api/plants]
        E5[/api/diagnosis/image]
        E6[/api/sensors]
        E7[/api/reports]
        E8[/api/users]
    end

    A -- calls --> S1;
    B -- calls --> S2;
    C -- calls --> S3;
    D -- calls --> S4;
    E -- calls --> S5;
    F -- calls --> S6;
    G -- calls --> S7;
    H -- calls --> S8;

    S1 -- "POST" --> E1;
    S2 -- "GET" --> E2;
    S3 -- "GET" --> E3;
    S4 -- "GET" --> E4;
    S5 -- "POST" --> E5;
    S6 -- "GET" --> E6;
    S7 -- "GET" --> E7;
    S8 -- "GET" --> E8;
```

