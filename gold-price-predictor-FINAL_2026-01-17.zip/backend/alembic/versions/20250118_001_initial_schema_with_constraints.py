"""Initial schema with constraints and indexes

Revision ID: 001_initial
Revises: 
Create Date: 2025-01-18 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '001_initial'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Create all tables with proper constraints and indexes
    """
    
    # Create users table
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('username', sa.String(length=50), nullable=False),
        sa.Column('email', sa.String(length=100), nullable=False),
        sa.Column('hashed_password', sa.String(length=255), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=True),
        sa.Column('is_2fa_enabled', sa.Boolean(), nullable=True),
        sa.Column('totp_secret', sa.String(length=32), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('last_login', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('username', name='uq_users_username'),
        sa.UniqueConstraint('email', name='uq_users_email'),
        sa.CheckConstraint('length(username) >= 3', name='ck_users_username_length'),
        sa.CheckConstraint('length(email) >= 5', name='ck_users_email_length'),
    )
    op.create_index('idx_users_username', 'users', ['username'])
    op.create_index('idx_users_email', 'users', ['email'])
    op.create_index('idx_users_is_active', 'users', ['is_active'])
    op.create_index('idx_users_is_2fa_enabled', 'users', ['is_2fa_enabled'])
    op.create_index('idx_users_created_at', 'users', ['created_at'])
    op.create_index('idx_users_username_email', 'users', ['username', 'email'])
    op.create_index('idx_users_active_created', 'users', ['is_active', 'created_at'])

    # Create assets table
    op.create_table(
        'assets',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('category', sa.String(length=50), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('symbol', name='uq_assets_symbol'),
        sa.CheckConstraint('length(symbol) >= 1', name='ck_assets_symbol_length'),
        sa.CheckConstraint('length(name) >= 1', name='ck_assets_name_length'),
    )
    op.create_index('idx_assets_symbol', 'assets', ['symbol'])
    op.create_index('idx_assets_category', 'assets', ['category'])
    op.create_index('idx_assets_is_active', 'assets', ['is_active'])

    # Create predictions table
    op.create_table(
        'predictions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('horizon', sa.String(length=20), nullable=False),
        sa.Column('current_price', sa.DECIMAL(precision=20, scale=8), nullable=True),
        sa.Column('predicted_price', sa.DECIMAL(precision=20, scale=8), nullable=True),
        sa.Column('change_percent', sa.DECIMAL(precision=10, scale=4), nullable=True),
        sa.Column('confidence', sa.DECIMAL(precision=5, scale=4), nullable=True),
        sa.Column('model_used', sa.String(length=50), nullable=True),
        sa.Column('model_accuracy', sa.DECIMAL(precision=5, scale=4), nullable=True),
        sa.Column('sentiment_score', sa.DECIMAL(precision=5, scale=4), nullable=True),
        sa.Column('economic_indicators', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name='fk_predictions_user_id', ondelete='CASCADE'),
        sa.CheckConstraint('confidence >= 0 AND confidence <= 1', name='ck_predictions_confidence_range'),
    )
    op.create_index('idx_predictions_user_id', 'predictions', ['user_id'])
    op.create_index('idx_predictions_symbol', 'predictions', ['symbol'])
    op.create_index('idx_predictions_created_at', 'predictions', ['created_at'])
    op.create_index('idx_predictions_user_symbol', 'predictions', ['user_id', 'symbol'])
    op.create_index('idx_predictions_symbol_created', 'predictions', ['symbol', 'created_at'])
    op.create_index('idx_predictions_user_created', 'predictions', ['user_id', 'created_at'])

    # Create alerts table
    op.create_table(
        'alerts',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('asset_id', sa.Integer(), nullable=False),
        sa.Column('alert_type', sa.String(length=20), nullable=False),
        sa.Column('target_price', sa.DECIMAL(precision=20, scale=8), nullable=True),
        sa.Column('change_percent', sa.DECIMAL(precision=10, scale=4), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_triggered', sa.Boolean(), nullable=True),
        sa.Column('triggered_at', sa.DateTime(), nullable=True),
        sa.Column('notification_method', sa.String(length=20), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name='fk_alerts_user_id', ondelete='CASCADE'),
        sa.CheckConstraint("alert_type IN ('above', 'below', 'change')", name='ck_alerts_type'),
        sa.CheckConstraint("notification_method IN ('email', 'sms', 'push')", name='ck_alerts_notification'),
    )
    op.create_index('idx_alerts_user_id', 'alerts', ['user_id'])
    op.create_index('idx_alerts_asset_id', 'alerts', ['asset_id'])
    op.create_index('idx_alerts_is_active', 'alerts', ['is_active'])
    op.create_index('idx_alerts_is_triggered', 'alerts', ['is_triggered'])
    op.create_index('idx_alerts_created_at', 'alerts', ['created_at'])
    op.create_index('idx_alerts_user_asset', 'alerts', ['user_id', 'asset_id'])
    op.create_index('idx_alerts_active_triggered', 'alerts', ['is_active', 'is_triggered'])


def downgrade() -> None:
    """
    Drop all tables
    """
    op.drop_table('alerts')
    op.drop_table('predictions')
    op.drop_table('assets')
    op.drop_table('users')

