import Database from 'better-sqlite3';
import { readFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = resolve(__dirname, './data/app.db');
mkdirSync(dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Read and execute migration
const migrationSQL = readFileSync(resolve(__dirname, './drizzle/0000_absurd_vargas.sql'), 'utf-8');
const statements = migrationSQL.split(';').filter(s => s.trim());

statements.forEach(statement => {
  if (statement.trim()) {
    try {
      db.exec(statement);
      console.log('✓ Executed:', statement.substring(0, 50) + '...');
    } catch (error) {
      console.error('✗ Error:', error.message);
    }
  }
});

console.log('\n✓ Migration completed!');
db.close();
