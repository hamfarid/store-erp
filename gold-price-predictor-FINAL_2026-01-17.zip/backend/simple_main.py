# Simplified Backend for Testing
"""
Simplified FastAPI application for quick testing
"""
from app.auth_postgresql import hash_password, verify_password, create_access_token, create_refresh_token
from app.database_enhanced import get_db, Base, engine, User
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from pydantic import BaseModel
import os
import sys
import uuid
import logging
from collections import defaultdict
import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Logging Configuration حسب البرومبت
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - [TraceId: %(traceId)s] - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('logs/app.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# Ensure logs directory exists
os.makedirs('logs', exist_ok=True)

# Create tables
Base.metadata.create_all(bind=engine)

# FastAPI App
app = FastAPI(
    title="Gold & Assets Price Prediction API - Simplified",
    description="Simplified backend for testing",
    version="3.0.0-simple"
)

# CORS - استخدام ALLOWED_ORIGINS من البيئة
allowed_origins = os.getenv("ALLOWED_ORIGINS", "*")
if allowed_origins != "*":
    try:
        import json
        allowed_origins = json.loads(allowed_origins)
    except:
        allowed_origins = ["http://localhost:2505", "http://localhost:2005"]
else:
    allowed_origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security Headers Middleware حسب البرومبت (Security 35%)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        # CSP - Content Security Policy
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';"
        # HSTS - HTTP Strict Transport Security
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        # X-Frame-Options
        response.headers["X-Frame-Options"] = "DENY"
        # X-Content-Type-Options
        response.headers["X-Content-Type-Options"] = "nosniff"
        # Referrer-Policy
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # Permissions-Policy
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        return response


app.add_middleware(SecurityHeadersMiddleware)

# Rate Limiting Middleware حسب البرومبت (100 req/min default)


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_requests: int = 100, window: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window = window
        self.requests = defaultdict(list)

    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host
        current_time = time.time()

        # Clean old requests
        self.requests[client_ip] = [
            req_time for req_time in self.requests[client_ip]
            if current_time - req_time < self.window
        ]

        # Check rate limit
        if len(self.requests[client_ip]) >= self.max_requests:
            trace_id = str(uuid.uuid4())
            logger.warning(f"Rate limit exceeded for {client_ip}", extra={'traceId': trace_id})
            return JSONResponse(
                status_code=429,
                content={
                    "success": False,
                    "code": "RATE_LIMIT_EXCEEDED",
                    "message": "Too many requests. Please try again later.",
                    "traceId": trace_id,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            )

        # Add current request
        self.requests[client_ip].append(current_time)
        response = await call_next(request)
        return response


rate_limit_enabled = os.getenv("RATE_LIMIT_ENABLED", "true").lower() == "true"
if rate_limit_enabled:
    max_requests = int(os.getenv("RATE_LIMIT_REQUESTS", "100"))
    window = int(os.getenv("RATE_LIMIT_PERIOD", "60"))
    app.add_middleware(RateLimitMiddleware, max_requests=max_requests, window=window)
    logger.info(f"Rate limiting enabled: {max_requests} requests per {window} seconds", extra={'traceId': 'startup'})

# Request Logging Middleware مع traceId


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        trace_id = str(uuid.uuid4())
        request.state.trace_id = trace_id

        start_time = time.time()
        logger.info(
            f"{request.method} {request.url.path} - Client: {request.client.host}",
            extra={'traceId': trace_id}
        )

        response = await call_next(request)

        process_time = time.time() - start_time
        logger.info(
            f"{request.method} {request.url.path} - Status: {response.status_code} - Time: {process_time:.3f}s",
            extra={'traceId': trace_id}
        )

        return response


app.add_middleware(RequestLoggingMiddleware)

# Exception Handler عالمي حسب البرومبت


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """معالج الأخطاء العالمي - يرجع شكل موحد للأخطاء"""
    trace_id = str(uuid.uuid4())
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "code": f"HTTP_{exc.status_code}",
            "message": exc.detail,
            "traceId": trace_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """معالج للأخطاء العامة"""
    trace_id = str(uuid.uuid4())
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "code": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected error occurred",
            "traceId": trace_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    )

# Health endpoint


@app.get("/api/health")
async def health_check():
    """Health check endpoint - شكل موحد حسب البرومبت"""
    return {
        "success": True,
        "data": {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "version": "3.0.0-simple"
        },
        "message": "Backend is running",
        "traceId": str(uuid.uuid4())
    }

# Root endpoint


@app.get("/")
async def root():
    """Root endpoint - شكل موحد حسب البرومبت"""
    return {
        "success": True,
        "data": {
            "name": "Gold & Assets Price Prediction API",
            "version": "3.0.0-simple",
            "docs": "/docs",
            "health": "/api/health"
        },
        "message": "API is operational",
        "traceId": str(uuid.uuid4())
    }


# Pydantic models for request/response
class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    success: bool = True
    data: dict
    message: str
    traceId: str


# Login endpoint
@app.post("/api/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    """Login endpoint - accepts email and password"""
    # Find user by email
    user = db.query(User).filter(User.email == request.email).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )

    # Verify password
    if not verify_password(request.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )

    # Check if user is active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is disabled"
        )

    # Create tokens
    access_token = create_access_token(data={"sub": user.username, "user_id": user.id})
    refresh_token = create_refresh_token(data={"sub": user.username, "user_id": user.id})

    return LoginResponse(
        success=True,
        data={
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "is_admin": user.is_admin
            }
        },
        message="Login successful",
        traceId=str(uuid.uuid4())
    )


# Alternative login endpoint (username/password)
@app.post("/api/auth/token")
async def login_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """OAuth2 compatible login endpoint"""
    # Try username first
    user = db.query(User).filter(User.username == form_data.username).first()

    # If not found, try email
    if not user:
        user = db.query(User).filter(User.email == form_data.username).first()

    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is disabled"
        )

    access_token = create_access_token(data={"sub": user.username, "user_id": user.id})
    refresh_token = create_refresh_token(data={"sub": user.username, "user_id": user.id})

    return {
        "success": True,
        "data": {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer"
        },
        "message": "Login successful",
        "traceId": str(uuid.uuid4())
    }


# Seed default admin user - run immediately, not in startup event
try:
    db = next(get_db())
    admin = db.query(User).filter(User.username == "admin").first()
    if not admin:
        admin = User(
            username="admin",
            email="admin@goldpredictor.com",
            hashed_password=hash_password("admin123"),
            is_admin=True,
            is_active=True
        )
        db.add(admin)
        db.commit()
        print("✅ Default admin user created: admin/admin123")
    else:
        print("✅ Admin user already exists")
    db.close()
except Exception as e:
    print(f"⚠️  Could not create admin user: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=2005)
