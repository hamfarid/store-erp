"""
سكريبت اختبار API
API Testing Script
"""

import requests
import json
from datetime import datetime

# Base URL
BASE_URL = "http://localhost:8000"

def print_section(title):
    """طباعة عنوان القسم"""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")

def test_health():
    """اختبار صحة API"""
    print_section("1. Health Check")
    
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        response.raise_for_status()
        
        data = response.json()
        print(f"✅ Status: {data['status']}")
        print(f"✅ Models Loaded: {data['models_loaded']}")
        print(f"✅ API Version: {data['api_version']}")
        print(f"✅ Timestamp: {data['timestamp']}")
        return True
        
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: API is not running")
        print("   Please start the API first: python run_api.py")
        return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_list_assets():
    """اختبار قائمة الأصول"""
    print_section("2. List Assets")
    
    try:
        response = requests.get(f"{BASE_URL}/assets", timeout=5)
        response.raise_for_status()
        
        assets = response.json()
        print(f"✅ Found {len(assets)} assets:")
        
        for asset in assets:
            print(f"   - {asset['code']}: {asset['name']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_predict_gold():
    """اختبار التنبؤ بسعر الذهب"""
    print_section("3. Predict Gold Price")
    
    data = {
        "asset": "gold",
        "features": {
            "Silver_Price": 50.10,
            "Oil_Price": 57.15,
            "SP500": 6664.01,
            "CPI": 237.45,
            "Interest_Rate": 1.24,
            "BTC_Price": 107198.27,
            "ETH_Price": 3890.35,
            "TRY_USD": 0.0293,
            "EGP_USD": 0.0204,
            "EUR_USD": 1.1655,
            "DXY": 98.54
        }
    }
    
    try:
        print("📤 Sending prediction request...")
        print(f"   Asset: {data['asset']}")
        print(f"   Features: {len(data['features'])} values")
        
        response = requests.post(
            f"{BASE_URL}/predict",
            json=data,
            timeout=10
        )
        response.raise_for_status()
        
        result = response.json()
        
        print(f"\n✅ Prediction successful!")
        print(f"   Asset: {result['asset']}")
        print(f"   Predicted Price: ${result['predicted_price']:.2f}")
        print(f"   Confidence: {result['confidence']:.2%}")
        print(f"   Model Version: {result['model_version']}")
        print(f"   Timestamp: {result['timestamp']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_predict_latest():
    """اختبار التنبؤ بأحدث البيانات"""
    print_section("4. Predict with Latest Data")
    
    try:
        print("📤 Requesting latest prediction for gold...")
        
        response = requests.get(
            f"{BASE_URL}/predict/gold/latest",
            timeout=10
        )
        response.raise_for_status()
        
        result = response.json()
        
        print(f"\n✅ Prediction successful!")
        print(f"   Predicted Price: ${result['predicted_price']:.2f}")
        print(f"   Confidence: {result['confidence']:.2%}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_predict_multiple():
    """اختبار التنبؤ بأصول متعددة"""
    print_section("5. Predict Multiple Assets")
    
    assets = ['gold', 'btc', 'eth']
    
    features = {
        "Silver_Price": 50.10,
        "Oil_Price": 57.15,
        "SP500": 6664.01,
        "CPI": 237.45,
        "Interest_Rate": 1.24,
        "BTC_Price": 107198.27,
        "ETH_Price": 3890.35,
        "TRY_USD": 0.0293,
        "EGP_USD": 0.0204,
        "EUR_USD": 1.1655,
        "DXY": 98.54
    }
    
    try:
        print(f"📤 Predicting prices for {len(assets)} assets...")
        
        for asset in assets:
            response = requests.post(
                f"{BASE_URL}/predict",
                json={"asset": asset, "features": features},
                timeout=10
            )
            response.raise_for_status()
            
            result = response.json()
            print(f"   ✅ {asset.upper()}: ${result['predicted_price']:.2f}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_error_handling():
    """اختبار معالجة الأخطاء"""
    print_section("6. Error Handling")
    
    # اختبار 1: أصل غير مدعوم
    print("Test 1: Unsupported asset")
    try:
        response = requests.post(
            f"{BASE_URL}/predict",
            json={"asset": "xyz", "features": {}},
            timeout=5
        )
        
        if response.status_code == 400:
            print("   ✅ Correctly returned 400 Bad Request")
        else:
            print(f"   ⚠️ Unexpected status code: {response.status_code}")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # اختبار 2: ميزات مفقودة
    print("\nTest 2: Missing features")
    try:
        response = requests.post(
            f"{BASE_URL}/predict",
            json={"asset": "gold", "features": {}},
            timeout=5
        )
        
        if response.status_code == 400:
            print("   ✅ Correctly returned 400 Bad Request")
        else:
            print(f"   ⚠️ Unexpected status code: {response.status_code}")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    return True

def main():
    """الدالة الرئيسية"""
    print("\n" + "=" * 80)
    print("  🧪 Gold Price Predictor API Testing")
    print("=" * 80)
    print(f"\n📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🔗 API URL: {BASE_URL}")
    
    # تشغيل الاختبارات
    tests = [
        ("Health Check", test_health),
        ("List Assets", test_list_assets),
        ("Predict Gold", test_predict_gold),
        ("Predict Latest", test_predict_latest),
        ("Predict Multiple", test_predict_multiple),
        ("Error Handling", test_error_handling)
    ]
    
    results = []
    
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"❌ Test '{name}' failed with exception: {e}")
            results.append((name, False))
    
    # ملخص النتائج
    print_section("Test Summary")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")
    
    print(f"\n📊 Results: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("\n🎉 All tests passed!")
    else:
        print(f"\n⚠️ {total - passed} test(s) failed")
    
    print("\n" + "=" * 80 + "\n")

if __name__ == "__main__":
    main()

