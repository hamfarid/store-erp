
import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

# Import the middlewares to test
from app.middleware.input_sanitizer import InputSanitizerMiddleware
from app.middleware.upload_scanner import UploadScannerMiddleware
from app.rate_limiter_redis import RedisRateLimiter, rate_limit_middleware

# Create a standalone app for testing purposes
# This avoids importing the heavy 'main.py' which triggers ML dependencies and crashes
def create_test_app():
    app = FastAPI()

    # Add middlewares
    app.add_middleware(InputSanitizerMiddleware)
    app.add_middleware(UploadScannerMiddleware)
    
    # Simple rate limiter middleware wrapper for testing
    rate_limiter = RedisRateLimiter(max_requests=5, window_seconds=1, key_prefix="test")
    
    @app.middleware("http")
    async def global_rate_limit_middleware(request: Request, call_next):
        try:
            # Mock client ip for testing
            # (In real app, rate_limiter checks client.host)
            await rate_limit_middleware(request, limiter=rate_limiter)
        except Exception as e:
             if hasattr(e, 'status_code'):
                 return JSONResponse(status_code=e.status_code, content={"detail": e.detail})
             raise e
        return await call_next(request)

    @app.get("/")
    async def root(q: str = None):
        return {"message": "ok", "q": q}

    @app.post("/upload")
    async def upload(request: Request):
        return {"message": "uploaded"}

    return app

client = TestClient(create_test_app())

def test_input_sanitizer_sql_injection():
    """Test that potential SQL injection in query params is blocked"""
    # Note: the input sanitizer middleware checks query params
    response = client.get("/?q=SELECT * FROM users")
    assert response.status_code == 400
    assert "potential SQL injection" in response.json().get("detail", "")

def test_upload_size_limit():
    """Test that large uploads are rejected by middleware"""
    # Mock a large content-length
    large_size = 10 * 1024 * 1024 + 1
    headers = {"Content-Length": str(large_size), "Content-Type": "multipart/form-data; boundary=boundary"}
    response = client.post("/upload", headers=headers) 
    assert response.status_code == 413
    assert "File too large" in response.json().get("detail", "")

def test_upload_scanner_valid_content():
    # Unit test for the static method
    png_content = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR'
    assert UploadScannerMiddleware.validate_file_content(png_content, "image.png") is True

def test_upload_scanner_invalid_content():
    # Unit test for the static method
    invalid_content = b'randombytes'
    assert UploadScannerMiddleware.validate_file_content(invalid_content, "image.png") is False
