
import sys
import os

# Add backend to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def check_import(module_name):
    try:
        __import__(module_name)
        print(f"✅ {module_name} imported successfully")
        return True
    except ImportError as e:
        print(f"❌ Failed to import {module_name}: {e}")
        return False

dependencies = [
    "celery",
    "pyotp",
    "qrcode",
    "jose",
    "argon2",
    "sqlalchemy.orm",
    "pydantic",
    "fastapi"
]

print("Verifying critical dependencies...")
all_passed = True
for dep in dependencies:
    if not check_import(dep):
        all_passed = False

if all_passed:
    print("\nALL SYSTEM DEPENDENCIES VERIFIED.")
else:
    print("\nSOME DEPENDENCIES FAILED.")
    sys.exit(1)
