#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train Models with Recent Data Only
تدريب النماذج باستخدام البيانات الحديثة فقط

Strategy:
- Use only last 2 years of data
- Add more lag features
- Use simpler models to avoid overfitting
"""

import os
import sys
import pickle
import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import json
from datetime import datetime, timedelta

warnings.filterwarnings('ignore')


def add_lag_features(df, col, lags=[1, 2, 3, 7, 14, 30]):
    """
    إضافة ميزات التأخير (lag features)
    """
    for lag in lags:
        df[f'{col}_lag{lag}'] = df[col].shift(lag)
    return df


def prepare_data_with_lags(df, target_col, lookback_days=730):
    """
    تحضير البيانات مع ميزات التأخير
    """
    # استخدام البيانات الحديثة فقط
    cutoff_date = df['Date'].max() - timedelta(days=lookback_days)
    df_recent = df[df['Date'] >= cutoff_date].copy()
    
    print(f"📅 Using data from {df_recent['Date'].min()} to {df_recent['Date'].max()}")
    print(f"📊 {len(df_recent)} rows")
    
    # إضافة ميزات التأخير
    df_recent = add_lag_features(df_recent, target_col, lags=[1, 2, 3, 7])
    
    # إضافة ميزات المتوسط المتحرك
    df_recent[f'{target_col}_MA7'] = df_recent[target_col].rolling(window=7, min_periods=1).mean()
    df_recent[f'{target_col}_MA30'] = df_recent[target_col].rolling(window=30, min_periods=1).mean()
    
    # إضافة ميزات التقلب
    df_recent[f'{target_col}_Volatility'] = df_recent[target_col].rolling(window=7, min_periods=1).std()
    
    # إضافة ميزات التغير
    df_recent[f'{target_col}_Change'] = df_recent[target_col].diff()
    df_recent[f'{target_col}_PctChange'] = df_recent[target_col].pct_change()
    
    return df_recent


def select_features_for_asset(df, target_col):
    """
    اختيار الميزات لكل أصل
    """
    # الميزات الأساسية
    lag_features = [f'{target_col}_lag{i}' for i in [1, 2, 3, 7] if f'{target_col}_lag{i}' in df.columns]
    
    ma_features = [
        f'{target_col}_MA7',
        f'{target_col}_MA30'
    ]
    
    vol_features = [
        f'{target_col}_Volatility',
        f'{target_col}_Change',
        f'{target_col}_PctChange'
    ]
    
    # ميزات خارجية
    external_features = []
    
    if target_col == 'Gold_Price':
        external_features = ['Silver_Price', 'Oil_Price', 'DXY_Index', 'CPI']
    elif target_col in ['BTC_Price', 'ETH_Price']:
        if target_col == 'BTC_Price' and 'ETH_Price' in df.columns:
            external_features = ['ETH_Price', 'Gold_Price', 'DXY_Index']
        elif target_col == 'ETH_Price' and 'BTC_Price' in df.columns:
            external_features = ['BTC_Price', 'Gold_Price', 'DXY_Index']
    elif target_col in ['TRY_USD', 'EGP_USD']:
        external_features = ['DXY_Index', 'Gold_Price', 'EUR_USD']
    
    # دمج جميع الميزات
    all_features = lag_features + ma_features + vol_features + external_features
    
    # التأكد من وجود الميزات
    features = [f for f in all_features if f in df.columns and f != target_col]
    
    return features


def train_model_recent(df, asset_name, target_col, lookback_days=730):
    """
    تدريب نموذج باستخدام البيانات الحديثة
    """
    print(f"\n{'='*80}")
    print(f"🔧 Training {asset_name} (Recent {lookback_days} days)")
    print(f"{'='*80}")
    
    # تحضير البيانات
    df_recent = prepare_data_with_lags(df, target_col, lookback_days)
    
    # اختيار الميزات
    features = select_features_for_asset(df_recent, target_col)
    
    print(f"🔧 Selected {len(features)} features")
    print(f"   Features: {', '.join(features[:5])}...")
    
    # تنظيف البيانات
    df_clean = df_recent[[target_col] + features].dropna()
    
    if len(df_clean) < 50:
        print(f"❌ Not enough data: {len(df_clean)} rows")
        return None
    
    print(f"📊 Clean data: {len(df_clean)} rows")
    
    X = df_clean[features].values
    y = df_clean[target_col].values
    
    # Time series split
    split_idx = int(0.8 * len(X))
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"📊 Train: {len(X_train)}, Test: {len(X_test)}")
    
    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب عدة نماذج واختيار الأفضل
    models = {
        'GradientBoosting': GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.05,
            max_depth=3,
            min_samples_split=10,
            subsample=0.8,
            random_state=42
        ),
        'Ridge': Ridge(alpha=1.0)
    }
    
    best_model = None
    best_score = -np.inf
    best_name = None
    
    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        score = r2_score(y_test, model.predict(X_test_scaled))
        
        if score > best_score:
            best_score = score
            best_model = model
            best_name = name
    
    print(f"🏆 Best model: {best_name}")
    
    # التقييم
    y_train_pred = best_model.predict(X_train_scaled)
    y_test_pred = best_model.predict(X_test_scaled)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mae = mean_absolute_error(y_test, y_test_pred)
    test_mape = np.mean(np.abs((y_test - y_test_pred) / (y_test + 1e-10))) * 100
    
    print(f"\n📊 Performance:")
    print(f"   Train R²: {train_r2:.4f}")
    print(f"   Test R²: {test_r2:.4f}")
    print(f"   RMSE: {test_rmse:.4f}")
    print(f"   MAE: {test_mae:.4f}")
    print(f"   MAPE: {test_mape:.2f}%")
    
    # حفظ النموذج
    os.makedirs('models', exist_ok=True)
    
    model_path = f'models/{asset_name}_model_v5.pkl'
    scaler_path = f'models/{asset_name}_scaler_v5.pkl'
    features_path = f'models/{asset_name}_features_v5.pkl'
    
    with open(model_path, 'wb') as f:
        pickle.dump(best_model, f, protocol=2)
    
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f, protocol=2)
    
    with open(features_path, 'wb') as f:
        pickle.dump(features, f, protocol=2)
    
    print(f"✅ Saved to {model_path}")
    
    # حفظ معلومات النموذج
    info = {
        'asset': asset_name,
        'target_col': target_col,
        'model_type': best_name,
        'features': features,
        'n_features': len(features),
        'train_r2': float(train_r2),
        'test_r2': float(test_r2),
        'test_rmse': float(test_rmse),
        'test_mae': float(test_mae),
        'test_mape': float(test_mape),
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'lookback_days': lookback_days,
        'timestamp': datetime.now().isoformat()
    }
    
    info_path = f'models/{asset_name}_info_v5.json'
    with open(info_path, 'w') as f:
        json.dump(info, f, indent=2)
    
    return info


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🚀 Training with Recent Data Only")
    print("="*80)
    
    # تحميل البيانات
    data_path = 'data/extended_dataset.csv'
    
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return
    
    print(f"📂 Loading data...")
    df = pd.read_csv(data_path)
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    
    print(f"📊 Total data: {len(df)} rows")
    
    # تدريب النماذج
    assets = {
        'Gold': 'Gold_Price',
        'Bitcoin': 'BTC_Price',
        'Ethereum': 'ETH_Price',
        'TRY_USD': 'TRY_USD',
        'EGP_USD': 'EGP_USD'
    }
    
    results = {}
    
    for asset_name, target_col in assets.items():
        if target_col in df.columns:
            # استخدام آخر سنتين فقط
            info = train_model_recent(df, asset_name, target_col, lookback_days=730)
            if info:
                results[asset_name] = info
        else:
            print(f"⚠️ Column {target_col} not found")
    
    # حفظ ملخص
    summary_path = 'models/training_summary_v5_recent.json'
    with open(summary_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*80}")
    print("✅ Training completed!")
    print(f"💾 Summary: {summary_path}")
    print(f"{'='*80}")
    
    # عرض ملخص
    print(f"\n📊 Final Results:")
    print(f"{'Asset':<15} {'R²':<10} {'RMSE':<12} {'MAPE':<10} {'Status':<15}")
    print(f"{'-'*65}")
    
    for asset, info in results.items():
        r2 = info['test_r2']
        rmse = info['test_rmse']
        mape = info['test_mape']
        
        if r2 >= 0.90:
            status = "✅ Excellent"
        elif r2 >= 0.75:
            status = "✅ Good"
        elif r2 >= 0.50:
            status = "⚠️ Fair"
        else:
            status = "❌ Poor"
        
        print(f"{asset:<15} {r2:<10.4f} {rmse:<12.2f} {mape:<10.2f}% {status:<15}")


if __name__ == '__main__':
    main()

