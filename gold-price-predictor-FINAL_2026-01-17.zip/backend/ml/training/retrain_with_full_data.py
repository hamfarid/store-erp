#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Retrain Models with Full Extended Dataset
إعادة تدريب النماذج باستخدام البيانات الكاملة
"""

import os
import sys
import pickle
import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import json

warnings.filterwarnings('ignore')


def select_features(df: pd.DataFrame, target_col: str) -> list:
    """
    اختيار الميزات المناسبة لكل أصل
    """
    # الميزات الأساسية المشتركة
    base_features = [
        'Gold_Price', 'Silver_Price', 'Oil_Price', 'SP500',
        'CPI', 'Interest_Rate', 'DXY_Index'
    ]
    
    # ميزات خاصة بالذهب
    gold_features = [
        'Gold_MA7', 'Gold_MA30', 'Gold_Daily_Change', 'Gold_Volatility'
    ]
    
    # ميزات خاصة بالعملات المشفرة
    crypto_features = [
        'BTC_Price', 'ETH_Price', 'BNB_Price',
        'BTC_MA7', 'BTC_MA30', 'BTC_Volatility', 'BTC_Daily_Change',
        'ETH_MA7', 'ETH_MA30', 'ETH_Volatility'
    ]
    
    # ميزات خاصة بالعملات
    currency_features = [
        'TRY_USD', 'EGP_USD', 'EUR_USD',
        'TRY_USD_MA7', 'TRY_USD_MA30',
        'EGP_USD_MA7', 'EGP_USD_MA30'
    ]
    
    # اختيار الميزات حسب الأصل
    if target_col == 'Gold_Price':
        features = base_features + gold_features + ['EUR_USD']
    elif target_col == 'BTC_Price':
        features = base_features + crypto_features[:3] + [
            'BTC_MA7', 'BTC_MA30', 'BTC_Volatility'
        ]
    elif target_col == 'ETH_Price':
        features = base_features + ['BTC_Price', 'ETH_MA7', 'ETH_MA30', 'ETH_Volatility']
    elif target_col == 'TRY_USD':
        features = base_features + ['TRY_USD_MA7', 'TRY_USD_MA30', 'EUR_USD']
    elif target_col == 'EGP_USD':
        features = base_features + ['EGP_USD_MA7', 'EGP_USD_MA30', 'EUR_USD']
    else:
        features = base_features
    
    # إزالة العمود المستهدف من الميزات
    features = [f for f in features if f != target_col and f in df.columns]
    
    return features


def train_model(df: pd.DataFrame, asset_name: str, target_col: str):
    """
    تدريب نموذج لأصل معين
    """
    print(f"\n{'='*80}")
    print(f"🔧 Training model for {asset_name}")
    print(f"{'='*80}")
    
    # اختيار الميزات
    feature_names = select_features(df, target_col)
    
    print(f"🔧 Selected {len(feature_names)} features")
    print(f"   Features: {', '.join(feature_names[:5])}...")
    
    # تحضير البيانات
    df_clean = df[[target_col] + feature_names].copy()
    df_clean = df_clean.dropna()
    
    if len(df_clean) < 100:
        print(f"❌ Not enough data for {asset_name} ({len(df_clean)} rows)")
        return None
    
    print(f"📊 Using {len(df_clean)} rows")
    
    X = df_clean[feature_names].values
    y = df_clean[target_col].values
    
    # تقسيم البيانات
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )
    
    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب النموذج
    print(f"🚀 Training GradientBoostingRegressor...")
    model = GradientBoostingRegressor(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=5,
        min_samples_split=10,
        min_samples_leaf=5,
        random_state=42,
        verbose=0
    )
    
    model.fit(X_train_scaled, y_train)
    
    # التقييم
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mae = mean_absolute_error(y_test, y_test_pred)
    
    # حساب MAPE
    test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test)) * 100
    
    print(f"\n📊 Model Performance:")
    print(f"   Train R²: {train_r2:.4f}")
    print(f"   Test R²: {test_r2:.4f}")
    print(f"   Test RMSE: {test_rmse:.4f}")
    print(f"   Test MAE: {test_mae:.4f}")
    print(f"   Test MAPE: {test_mape:.2f}%")
    
    # حفظ النموذج
    os.makedirs('models', exist_ok=True)
    
    model_path = f'models/{asset_name}_model_v5.pkl'
    scaler_path = f'models/{asset_name}_scaler_v5.pkl'
    features_path = f'models/{asset_name}_features_v5.pkl'
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f, protocol=2)
    
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f, protocol=2)
    
    with open(features_path, 'wb') as f:
        pickle.dump(feature_names, f, protocol=2)
    
    print(f"✅ Model saved to {model_path}")
    
    # حفظ معلومات النموذج
    info = {
        'asset': asset_name,
        'target_col': target_col,
        'features': feature_names,
        'n_features': len(feature_names),
        'train_r2': float(train_r2),
        'test_r2': float(test_r2),
        'test_rmse': float(test_rmse),
        'test_mae': float(test_mae),
        'test_mape': float(test_mape),
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'model_type': 'GradientBoostingRegressor',
        'timestamp': pd.Timestamp.now().isoformat()
    }
    
    info_path = f'models/{asset_name}_info_v5.json'
    with open(info_path, 'w') as f:
        json.dump(info, f, indent=2)
    
    return info


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🚀 Retraining Models with Full Extended Dataset")
    print("="*80)
    
    # تحميل البيانات
    data_path = 'data/extended_dataset.csv'
    
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return
    
    print(f"📂 Loading data from {data_path}...")
    df = pd.read_csv(data_path)
    
    print(f"📊 Loaded {len(df)} rows, {len(df.columns)} columns")
    print(f"📅 Date range: {df['Date'].min()} to {df['Date'].max()}")
    
    # تحويل Date إلى datetime
    df['Date'] = pd.to_datetime(df['Date'])
    
    # تدريب النماذج
    assets = {
        'Gold': 'Gold_Price',
        'Bitcoin': 'BTC_Price',
        'Ethereum': 'ETH_Price',
        'TRY_USD': 'TRY_USD',
        'EGP_USD': 'EGP_USD'
    }
    
    results = {}
    
    for asset_name, target_col in assets.items():
        if target_col in df.columns:
            info = train_model(df, asset_name, target_col)
            if info:
                results[asset_name] = info
        else:
            print(f"⚠️ Column {target_col} not found for {asset_name}")
    
    # حفظ ملخص النتائج
    summary_path = 'models/training_summary_v5.json'
    with open(summary_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*80}")
    print("✅ All models trained successfully!")
    print(f"💾 Summary saved to {summary_path}")
    print(f"{'='*80}")
    
    # عرض ملخص
    print(f"\n📊 Training Summary:")
    print(f"{'Asset':<15} {'R² Score':<12} {'RMSE':<12} {'MAPE':<12} {'Features':<10}")
    print(f"{'-'*65}")
    for asset, info in results.items():
        r2 = info['test_r2']
        rmse = info['test_rmse']
        mape = info['test_mape']
        n_feat = info['n_features']
        
        # تحديد الحالة
        if r2 >= 0.95:
            status = "✅"
        elif r2 >= 0.80:
            status = "⚠️"
        else:
            status = "❌"
        
        print(f"{status} {asset:<13} {r2:<12.4f} {rmse:<12.4f} {mape:<12.2f}% {n_feat:<10}")


if __name__ == '__main__':
    main()

