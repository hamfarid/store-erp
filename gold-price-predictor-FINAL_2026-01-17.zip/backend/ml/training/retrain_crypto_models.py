#!/usr/bin/env python3
"""
إعادة تدريب نماذج العملات الرقمية (BTC, ETH)
"""

import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib
import warnings
warnings.filterwarnings('ignore')

def retrain_crypto_model(asset_name, price_column, feature_columns):
    """إعادة تدريب نموذج العملة الرقمية"""
    print(f"\n{'='*80}")
    print(f"🔄 Retraining {asset_name} Model")
    print(f"{'='*80}")
    
    # تحميل البيانات
    df = pd.read_csv('data/extended_dataset.csv')
    df = df.dropna(subset=[price_column] + feature_columns)
    
    print(f"✅ Data loaded: {len(df)} rows")
    print(f"✅ Features: {feature_columns}")
    print(f"✅ Target: {price_column}")
    
    # تحضير البيانات
    X = df[feature_columns].values
    y = df[price_column].values
    
    # تقسيم البيانات
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )
    
    print(f"✅ Train size: {len(X_train)}, Test size: {len(X_test)}")
    
    # تطبيع البيانات
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # تدريب النموذج
    print("🔄 Training model...")
    model = GradientBoostingRegressor(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=5,
        random_state=42,
        verbose=0
    )
    
    model.fit(X_train_scaled, y_train)
    
    # التقييم
    y_pred = model.predict(X_test_scaled)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    
    print(f"\n📊 Model Performance:")
    print(f"   RMSE: {rmse:.2f}")
    print(f"   R²: {r2:.4f} ({r2*100:.2f}%)")
    print(f"   MAE: {mae:.2f}")
    
    # حفظ النموذج
    os.makedirs('models', exist_ok=True)
    
    model_file = f'models/{asset_name}_model.pkl'
    scaler_file = f'models/{asset_name}_scaler.pkl'
    features_file = f'models/{asset_name}_feature_names.pkl'
    
    joblib.dump(model, model_file)
    joblib.dump(scaler, scaler_file)
    joblib.dump(feature_columns, features_file)
    
    print(f"\n✅ Model saved:")
    print(f"   {model_file}")
    print(f"   {scaler_file}")
    print(f"   {features_file}")
    
    return model, scaler, rmse, r2, mae


def main():
    """الدالة الرئيسية"""
    print("="*80)
    print("🔄 Retraining Cryptocurrency Models")
    print("="*80)
    
    # تحميل البيانات للفحص
    df = pd.read_csv('data/extended_dataset.csv')
    print(f"\n✅ Dataset loaded: {len(df)} rows, {len(df.columns)} columns")
    
    # تعريف النماذج
    models_config = {
        'Bitcoin': {
            'price_column': 'BTC_Price',
            'features': ['ETH_Price', 'DXY_Index', 'BTC_MA7', 'BTC_MA30', 'BTC_Volatility', 'BTC_Daily_Change']
        },
        'Ethereum': {
            'price_column': 'ETH_Price',
            'features': ['BTC_Price', 'DXY_Index', 'ETH_MA7', 'ETH_MA30', 'ETH_Volatility']
        }
    }
    
    results = {}
    
    # إعادة تدريب كل نموذج
    for asset_name, config in models_config.items():
        try:
            model, scaler, rmse, r2, mae = retrain_crypto_model(
                asset_name,
                config['price_column'],
                config['features']
            )
            
            results[asset_name] = {
                'success': True,
                'rmse': rmse,
                'r2': r2,
                'mae': mae
            }
        except Exception as e:
            print(f"\n❌ Error retraining {asset_name}: {str(e)}")
            results[asset_name] = {
                'success': False,
                'error': str(e)
            }
    
    # طباعة الملخص
    print("\n" + "="*80)
    print("📊 Retraining Summary")
    print("="*80)
    
    for asset_name, result in results.items():
        if result['success']:
            print(f"\n✅ {asset_name}:")
            print(f"   RMSE: {result['rmse']:.2f}")
            print(f"   R²: {result['r2']:.4f} ({result['r2']*100:.2f}%)")
            print(f"   MAE: {result['mae']:.2f}")
        else:
            print(f"\n❌ {asset_name}: {result['error']}")
    
    print("\n" + "="*80)
    print("✅ Retraining completed!")
    print("="*80)


if __name__ == '__main__':
    main()

