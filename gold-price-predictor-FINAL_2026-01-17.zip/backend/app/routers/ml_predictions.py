# FILE: backend/app/routers/ml_predictions.py | PURPOSE: ML model prediction endpoints | OWNER: ML Team | RELATED: modules/ml_api.py, ml_backend/models/ | LAST-AUDITED: 2025-11-21

"""
ML Predictions API Router
Integrates existing ML models (LSTM, GRU, Transformer, Ensemble) with FastAPI backend
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.audit_logger import AuditEventType, audit_logger
from app.dependencies import get_current_user_dep
from app.database_enhanced import User
from app.services.ml_model_loader import model_loader

router = APIRouter(prefix="/api/ml", tags=["ml-predictions"])


# Request/Response Models
class PredictionRequest(BaseModel):
    """Single prediction request"""
    asset: str = Field(..., description="Asset symbol (e.g., GOLD, SILVER, BTC)")
    features: List[float] = Field(..., description="Feature vector for prediction")
    model_type: str = Field(default="ensemble", description="Model type: lstm, gru, transformer, ensemble")


class BatchPredictionRequest(BaseModel):
    """Batch prediction request"""
    asset: str
    features_list: List[List[float]] = Field(..., description="List of feature vectors")
    model_type: str = Field(default="ensemble")


class FuturePredictionRequest(BaseModel):
    """Future multi-day prediction request"""
    asset: str
    last_sequence: List[List[float]] = Field(..., description="Last sequence of features")
    n_days: int = Field(default=7, ge=1, le=30, description="Number of days to predict")
    model_type: str = Field(default="ensemble")


class PredictionResponse(BaseModel):
    """Prediction response"""
    success: bool
    asset: str
    prediction: float
    confidence: Optional[float] = None
    model_type: str
    timestamp: str


class BatchPredictionResponse(BaseModel):
    """Batch prediction response"""
    success: bool
    asset: str
    predictions: List[float]
    model_type: str
    timestamp: str


class FuturePredictionResponse(BaseModel):
    """Future prediction response"""
    success: bool
    asset: str
    predictions: List[Dict[str, Any]]
    model_type: str
    timestamp: str


# Model loader is imported from services
@router.get("/")
async def ml_api_info():
    """
    ML API information endpoint
    Returns API version and available models
    """
    return {
        "success": True,
        "api": "Gold Price Predictor ML API",
        "version": "3.0.0",
        "models": ["LSTM", "GRU", "Transformer", "Ensemble"],
        "available_assets": model_loader.available_assets,
        "endpoints": {
            "predict": "POST /api/ml/predict - Single prediction",
            "predict_batch": "POST /api/ml/predict/batch - Batch predictions",
            "predict_future": "POST /api/ml/predict/future - Multi-day forecast",
            "models": "GET /api/ml/models - Model information"
        }
    }


@router.post("/predict", response_model=PredictionResponse)
async def predict(
    request: PredictionRequest,
    current_user: User = Depends(get_current_user_dep)
):
    """
    Single prediction endpoint
    Makes a prediction for given asset using specified model
    """
    try:
        # Validate asset
        if request.asset.upper() not in model_loader.available_assets:
            available = model_loader.available_assets
            detail = f"Asset {request.asset} not supported. Available: {available}"
            raise HTTPException(status_code=400, detail=detail)

        # Make prediction
        prediction = model_loader.predict(
            asset=request.asset.upper(),
            features=request.features,
            model_type=request.model_type
        )

        # Log prediction
        # Log prediction
        audit_logger.log_event(
            AuditEventType.PREDICTION_REQUEST,
            user_id=current_user.id,
            details={
                "asset": request.asset,
                "model_type": request.model_type,
                "prediction": float(prediction),
                "username": current_user.username
            },
            success=True
        )

        return PredictionResponse(
            success=True,
            asset=request.asset.upper(),
            prediction=float(prediction),
            model_type=request.model_type,
            timestamp=datetime.utcnow().isoformat()
        )

    except Exception as e:
        audit_logger.log_event(
            AuditEventType.PREDICTION_REQUEST,
            user_id=current_user.id,
            details={"error": str(e), "username": current_user.username},
            success=False
        )
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@router.post("/predict/batch", response_model=BatchPredictionResponse)
async def predict_batch(
    request: BatchPredictionRequest,
    current_user: User = Depends(get_current_user_dep)
):
    """
    Batch prediction endpoint
    Makes multiple predictions for given asset
    """
    try:
        # Validate asset
        if request.asset.upper() not in model_loader.available_assets:
            raise HTTPException(
                status_code=400,
                detail=f"Asset {request.asset} not supported"
            )

        # Make predictions
        predictions = model_loader.predict_batch(
            asset=request.asset.upper(),
            features_list=request.features_list,
            model_type=request.model_type
        )

        # Log prediction
        # Log prediction
        audit_logger.log_event(
            AuditEventType.PREDICTION_REQUEST,
            user_id=current_user.id,
            details={
                "asset": request.asset,
                "model_type": request.model_type,
                "batch_size": len(predictions),
                "username": current_user.username
            },
            success=True
        )

        return BatchPredictionResponse(
            success=True,
            asset=request.asset.upper(),
            predictions=[float(p) for p in predictions],
            model_type=request.model_type,
            timestamp=datetime.utcnow().isoformat()
        )

    except Exception as e:
        detail = f"Batch prediction failed: {str(e)}"
        raise HTTPException(status_code=500, detail=detail) from e


@router.post("/predict/future", response_model=FuturePredictionResponse)
async def predict_future(
    request: FuturePredictionRequest,
    current_user: User = Depends(get_current_user_dep)
):
    """
    Future prediction endpoint
    Makes multi-day forecast for given asset
    """
    try:
        # Validate asset
        if request.asset.upper() not in model_loader.available_assets:
            raise HTTPException(
                status_code=400,
                detail=f"Asset {request.asset} not supported"
            )

        # Make future predictions
        predictions = model_loader.predict_future(
            asset=request.asset.upper(),
            last_sequence=request.last_sequence,
            n_days=request.n_days,
            model_type=request.model_type
        )

        # Format predictions with dates
        formatted_predictions = []
        for i, pred in enumerate(predictions):
            formatted_predictions.append({
                "day": i + 1,
                "prediction": float(pred)
            })

        # Log prediction
        # Log prediction
        audit_logger.log_event(
            AuditEventType.PREDICTION_REQUEST,
            user_id=current_user.id,
            details={
                "asset": request.asset,
                "model_type": request.model_type,
                "forecast_days": request.n_days,
                "username": current_user.username
            },
            success=True
        )

        return FuturePredictionResponse(
            success=True,
            asset=request.asset.upper(),
            predictions=formatted_predictions,
            model_type=request.model_type,
            timestamp=datetime.utcnow().isoformat()
        )

    except Exception as e:
        detail = f"Future prediction failed: {str(e)}"
        raise HTTPException(status_code=500, detail=detail) from e


@router.get("/models")
async def get_models_info():
    """
    Get information about available models
    Returns model types, assets, and capabilities
    """
    return {
        "success": True,
        "models": {
            "lstm": {
                "name": "LSTM (Long Short-Term Memory)",
                "type": "Deep Learning",
                "description": "Recurrent neural network for time series prediction",
                "accuracy": "High",
                "speed": "Medium"
            },
            "gru": {
                "name": "GRU (Gated Recurrent Unit)",
                "type": "Deep Learning",
                "description": "Simplified LSTM variant with faster training",
                "accuracy": "High",
                "speed": "Fast"
            },
            "transformer": {
                "name": "Transformer",
                "type": "Deep Learning",
                "description": "Attention-based model for sequence prediction",
                "accuracy": "Very High",
                "speed": "Slow"
            },
            "ensemble": {
                "name": "Ensemble Model",
                "type": "Meta Model",
                "description": "Combines LSTM (40%), GRU (30%), Transformer (30%)",
                "accuracy": "Highest (99.03%)",
                "speed": "Slow",
                "recommended": True
            }
        },
        "available_assets": model_loader.available_assets,
        "capabilities": {
            "single_prediction": True,
            "batch_prediction": True,
            "future_forecast": True,
            "max_forecast_days": 30
        }
    }


@router.get("/models/{asset}")
async def get_asset_model_info(asset: str):
    """
    Get model information for specific asset
    """
    asset = asset.upper()

    if asset not in model_loader.available_assets:
        raise HTTPException(
            status_code=404,
            detail=f"Asset {asset} not found. Available: {model_loader.available_assets}"
        )

    return {
        "success": True,
        "asset": asset,
        "models_available": ["lstm", "gru", "transformer", "ensemble"],
        "recommended_model": "ensemble",
        "model_status": {
            "lstm": "trained",
            "gru": "trained",
            "transformer": "trained",
            "ensemble": "trained"
        },
        "last_trained": "2025-11-01T00:00:00Z",  # FIXME: Get from model metadata
        "accuracy": {
            "lstm": "98.5%",
            "gru": "98.2%",
            "transformer": "98.8%",
            "ensemble": "99.03%"
        }
    }
