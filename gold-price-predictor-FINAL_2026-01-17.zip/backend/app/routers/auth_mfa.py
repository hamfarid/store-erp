"""
MFA Authentication Endpoints

This module provides API endpoints for Multi-Factor Authentication setup,
verification, and management.

Endpoints:
    POST /api/v1/auth/mfa/setup - Setup MFA for current user
    POST /api/v1/auth/mfa/verify - Verify and enable MFA
    POST /api/v1/auth/mfa/disable - Disable MFA
    POST /api/v1/auth/login/mfa - Complete login with MFA token
    POST /api/v1/auth/mfa/backup-codes - Generate new backup codes
    POST /api/v1/auth/mfa/verify-backup - Verify backup code

Example:
    # Setup MFA
    POST /api/v1/auth/mfa/setup
    Response: {"qr_code": "base64...", "secret": "JBSWY3DPEHPK3PXP", "backup_codes": [...]}
    
    # Verify and enable
    POST /api/v1/auth/mfa/verify
    Body: {"token": "123456"}
    Response: {"message": "MFA enabled successfully"}
"""

from typing import Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.mfa import MFAManager
from ..core.database import get_write_db, get_read_db
from ..core.auth import get_current_user, create_access_token, create_temp_token, verify_temp_token
from ..models.user import User


router = APIRouter(prefix="/auth/mfa", tags=["auth", "mfa"])


class MFASetupResponse(BaseModel):
    """Response model for MFA setup"""
    qr_code: str
    secret: str
    backup_codes: List[str]


class MFAVerifyRequest(BaseModel):
    """Request model for MFA verification"""
    token: str


class MFALoginRequest(BaseModel):
    """Request model for MFA login"""
    temp_token: str
    mfa_token: str


class BackupCodeVerifyRequest(BaseModel):
    """Request model for backup code verification"""
    code: str


@router.post("/setup", response_model=MFASetupResponse)
async def setup_mfa(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_write_db)
) -> Dict[str, Any]:
    """
    Setup MFA for the current user.
    
    This endpoint generates a new TOTP secret and QR code for the user
    to scan with their authenticator app. It also generates backup codes.
    
    MFA is not enabled until the user verifies a token using /verify endpoint.
    
    Args:
        current_user: The authenticated user
        db: Database session
    
    Returns:
        Dictionary containing QR code, secret, and backup codes
    
    Raises:
        HTTPException: If MFA is already enabled
    
    Example:
        POST /api/v1/auth/mfa/setup
        Headers: {"Authorization": "Bearer <token>"}
        
        Response:
        {
            "qr_code": "iVBORw0KGgoAAAANSUhEUgAA...",
            "secret": "JBSWY3DPEHPK3PXP",
            "backup_codes": ["A3F9-2K7M", "B8H4-9L2N", ...]
        }
    """
    # Check if MFA is already enabled
    if current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already enabled for this account"
        )
    
    # Generate new secret
    secret = MFAManager.generate_secret()
    
    # Generate QR code
    qr_code = MFAManager.generate_qr_code(secret, current_user.email)
    
    # Generate backup codes
    backup_codes = MFAManager.generate_backup_codes(count=10)
    
    # Save secret and backup codes (not enabled yet)
    await db.execute(
        """
        UPDATE users 
        SET mfa_secret = $1, mfa_backup_codes = $2
        WHERE id = $3
        """,
        secret,
        backup_codes,
        current_user.id
    )
    await db.commit()
    
    return {
        "qr_code": qr_code,
        "secret": secret,
        "backup_codes": backup_codes
    }


@router.post("/verify")
async def verify_mfa(
    request: MFAVerifyRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_write_db)
) -> Dict[str, str]:
    """
    Verify TOTP token and enable MFA.
    
    This endpoint verifies that the user has correctly set up their
    authenticator app by checking the provided TOTP token.
    
    Args:
        request: MFA verification request with token
        current_user: The authenticated user
        db: Database session
    
    Returns:
        Success message
    
    Raises:
        HTTPException: If token is invalid or MFA not set up
    
    Example:
        POST /api/v1/auth/mfa/verify
        Headers: {"Authorization": "Bearer <token>"}
        Body: {"token": "123456"}
        
        Response:
        {
            "message": "MFA enabled successfully"
        }
    """
    # Get user's MFA secret
    result = await db.execute(
        "SELECT mfa_secret FROM users WHERE id = $1",
        current_user.id
    )
    row = result.fetchone()
    
    if not row or not row['mfa_secret']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA setup not initiated. Please call /setup first."
        )
    
    # Verify token
    is_valid = MFAManager.verify_token(row['mfa_secret'], request.token)
    
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid MFA token"
        )
    
    # Enable MFA
    await db.execute(
        "UPDATE users SET mfa_enabled = TRUE WHERE id = $1",
        current_user.id
    )
    await db.commit()
    
    return {"message": "MFA enabled successfully"}


@router.post("/disable")
async def disable_mfa(
    request: MFAVerifyRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_write_db)
) -> Dict[str, str]:
    """
    Disable MFA for the current user.
    
    This endpoint disables MFA after verifying the current TOTP token.
    
    Args:
        request: MFA verification request with token
        current_user: The authenticated user
        db: Database session
    
    Returns:
        Success message
    
    Raises:
        HTTPException: If token is invalid or MFA not enabled
    
    Example:
        POST /api/v1/auth/mfa/disable
        Headers: {"Authorization": "Bearer <token>"}
        Body: {"token": "123456"}
        
        Response:
        {
            "message": "MFA disabled successfully"
        }
    """
    if not current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    # Verify token before disabling
    is_valid = MFAManager.verify_token(current_user.mfa_secret, request.token)
    
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid MFA token"
        )
    
    # Disable MFA and clear secret
    await db.execute(
        """
        UPDATE users 
        SET mfa_enabled = FALSE, mfa_secret = NULL, mfa_backup_codes = NULL
        WHERE id = $1
        """,
        current_user.id
    )
    await db.commit()
    
    return {"message": "MFA disabled successfully"}


@router.post("/login")
async def login_with_mfa(
    request: MFALoginRequest,
    db: AsyncSession = Depends(get_read_db)
) -> Dict[str, str]:
    """
    Complete login with MFA token.
    
    This endpoint is called after initial login when MFA is required.
    It verifies the MFA token and returns a full access token.
    
    Args:
        request: MFA login request with temp token and MFA token
        db: Database session
    
    Returns:
        Dictionary containing access token
    
    Raises:
        HTTPException: If tokens are invalid
    
    Example:
        POST /api/v1/auth/login/mfa
        Body: {
            "temp_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "mfa_token": "123456"
        }
        
        Response:
        {
            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "token_type": "bearer"
        }
    """
    # Verify temp token
    user_id = verify_temp_token(request.temp_token)
    
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired temporary token"
        )
    
    # Get user's MFA secret
    result = await db.execute(
        "SELECT mfa_secret, mfa_enabled FROM users WHERE id = $1",
        user_id
    )
    row = result.fetchone()
    
    if not row or not row['mfa_enabled']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    # Verify MFA token
    is_valid = MFAManager.verify_token(row['mfa_secret'], request.mfa_token)
    
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid MFA token"
        )
    
    # Create full access token
    access_token = create_access_token(user_id)
    
    return {
        "access_token": access_token,
        "token_type": "bearer"
    }


@router.post("/backup-codes", response_model=Dict[str, List[str]])
async def regenerate_backup_codes(
    request: MFAVerifyRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_write_db)
) -> Dict[str, List[str]]:
    """
    Generate new backup codes.
    
    This endpoint generates new backup codes after verifying the current
    MFA token. Old backup codes are invalidated.
    
    Args:
        request: MFA verification request with token
        current_user: The authenticated user
        db: Database session
    
    Returns:
        Dictionary containing new backup codes
    
    Raises:
        HTTPException: If token is invalid or MFA not enabled
    
    Example:
        POST /api/v1/auth/mfa/backup-codes
        Headers: {"Authorization": "Bearer <token>"}
        Body: {"token": "123456"}
        
        Response:
        {
            "backup_codes": ["A3F9-2K7M", "B8H4-9L2N", ...]
        }
    """
    if not current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    # Verify token
    is_valid = MFAManager.verify_token(current_user.mfa_secret, request.token)
    
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid MFA token"
        )
    
    # Generate new backup codes
    backup_codes = MFAManager.generate_backup_codes(count=10)
    
    # Save new backup codes
    await db.execute(
        "UPDATE users SET mfa_backup_codes = $1 WHERE id = $2",
        backup_codes,
        current_user.id
    )
    await db.commit()
    
    return {"backup_codes": backup_codes}


@router.post("/verify-backup")
async def verify_backup_code(
    request: BackupCodeVerifyRequest,
    temp_token: str,
    db: AsyncSession = Depends(get_write_db)
) -> Dict[str, str]:
    """
    Verify backup code for MFA recovery.
    
    This endpoint allows users to log in using a backup code if they
    lose access to their authenticator app.
    
    Args:
        request: Backup code verification request
        temp_token: Temporary token from initial login
        db: Database session
    
    Returns:
        Dictionary containing access token
    
    Raises:
        HTTPException: If backup code is invalid
    
    Example:
        POST /api/v1/auth/mfa/verify-backup
        Body: {
            "code": "A3F9-2K7M",
            "temp_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
        }
        
        Response:
        {
            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "token_type": "bearer",
            "remaining_codes": 9
        }
    """
    # Verify temp token
    user_id = verify_temp_token(temp_token)
    
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired temporary token"
        )
    
    # Get user's backup codes
    result = await db.execute(
        "SELECT mfa_backup_codes FROM users WHERE id = $1",
        user_id
    )
    row = result.fetchone()
    
    if not row or not row['mfa_backup_codes']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No backup codes available"
        )
    
    # Verify backup code
    is_valid, remaining_codes = MFAManager.verify_backup_code(
        row['mfa_backup_codes'],
        request.code
    )
    
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid backup code"
        )
    
    # Update backup codes (remove used code)
    await db.execute(
        "UPDATE users SET mfa_backup_codes = $1 WHERE id = $2",
        remaining_codes,
        user_id
    )
    await db.commit()
    
    # Create access token
    access_token = create_access_token(user_id)
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "remaining_codes": len(remaining_codes)
    }

