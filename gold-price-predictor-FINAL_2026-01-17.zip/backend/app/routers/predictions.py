# FILE: backend/app/routers/predictions.py | PURPOSE: Prediction CRUD endpoints | OWNER: Backend Team | RELATED: database_enhanced.py | LAST-AUDITED: 2025-01-18

"""
Prediction CRUD Router
Provides endpoints for prediction management (read, update, delete)
Note: Create is handled by the ML prediction endpoint
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.audit_logger import AuditEventType, audit_logger
from app.dependencies import get_current_user_dep
from app.database_enhanced import Prediction, User, get_db

router = APIRouter(prefix="/api/predictions", tags=["predictions"])


# ==================== Pydantic Models ====================

class PredictionUpdate(BaseModel):
    """Prediction update request (limited fields)"""
    sentiment_score: Optional[Decimal] = None
    economic_indicators: Optional[dict] = None


class PredictionResponse(BaseModel):
    """Prediction response"""
    id: int
    user_id: int
    symbol: str
    horizon: str
    current_price: Optional[Decimal] = None
    predicted_price: Optional[Decimal] = None
    change_percent: Optional[Decimal] = None
    confidence: Optional[Decimal] = None
    model_used: Optional[str] = None
    model_accuracy: Optional[Decimal] = None
    sentiment_score: Optional[Decimal] = None
    economic_indicators: Optional[dict] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ==================== Endpoints ====================

@router.get("/", response_model=List[PredictionResponse])
async def list_predictions(
    skip: int = 0,
    limit: int = 100,
    symbol: Optional[str] = None,
    horizon: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    List predictions

    **Permissions:** Own predictions or ADMIN for all
    **Pagination:** skip, limit
    **Filters:** symbol, horizon
    """
    query = db.query(Prediction)

    # Non-admin users can only see their own predictions
    if not current_user.is_admin:
        query = query.filter(Prediction.user_id == current_user.id)

    if symbol is not None:
        query = query.filter(Prediction.symbol == symbol)

    if horizon is not None:
        query = query.filter(Prediction.horizon == horizon)

    predictions = query.order_by(
        Prediction.created_at.desc()
    ).offset(skip).limit(limit).all()
    return predictions


@router.get("/{prediction_id}", response_model=PredictionResponse)
async def get_prediction(
    prediction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Get prediction by ID

    **Permissions:** Own prediction or ADMIN
    """
    prediction = db.query(Prediction).filter(Prediction.id == prediction_id).first()
    if not prediction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction not found"
        )

    # Check permission (admin or own prediction)
    if not current_user.is_admin and prediction.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only view your own predictions"
        )

    return prediction


@router.put("/{prediction_id}", response_model=PredictionResponse)
async def update_prediction(
    prediction_id: int,
    prediction_data: PredictionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Update prediction (limited fields)

    **Permissions:** Own prediction or ADMIN
    **OSF Security:** Audit logging, permission checks
    **Note:** Only sentiment_score and economic_indicators can be updated
    """
    # Get prediction
    prediction = db.query(Prediction).filter(Prediction.id == prediction_id).first()
    if not prediction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction not found"
        )

    # Check permission (admin or own prediction)
    if not current_user.is_admin and prediction.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only update your own predictions"
        )

    # Update fields
    if prediction_data.sentiment_score is not None:
        prediction.sentiment_score = prediction_data.sentiment_score
    if prediction_data.economic_indicators is not None:
        prediction.economic_indicators = prediction_data.economic_indicators

    prediction.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(prediction)

    # Audit log
    audit_logger.log_event(
        AuditEventType.PREDICTION_UPDATED,
        user_id=current_user.id,
        details={
            "prediction_id": prediction.id,
            "symbol": prediction.symbol,
            "changes": prediction_data.dict(exclude_unset=True)
        }
    )

    return prediction


@router.delete("/{prediction_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_prediction(
    prediction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Delete prediction (hard delete)

    **Permissions:** Own prediction or ADMIN
    **OSF Security:** Audit logging, permission checks
    """
    # Get prediction
    prediction = db.query(Prediction).filter(Prediction.id == prediction_id).first()
    if not prediction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction not found"
        )

    # Check permission (admin or own prediction)
    if not current_user.is_admin and prediction.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only delete your own predictions"
        )

    # Store details for audit log
    prediction_details = {
        "prediction_id": prediction.id,
        "symbol": prediction.symbol,
        "horizon": prediction.horizon,
        "user_id": prediction.user_id
    }

    # Hard delete
    db.delete(prediction)
    db.commit()

    # Audit log
    audit_logger.log_event(
        AuditEventType.PREDICTION_DELETED,
        user_id=current_user.id,
        details=prediction_details
    )

    return None
