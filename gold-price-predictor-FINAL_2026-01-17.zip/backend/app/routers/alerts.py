# FILE: backend/app/routers/alerts.py | PURPOSE: Alert CRUD endpoints | OWNER: Backend Team | RELATED: database_enhanced.py | LAST-AUDITED: 2025-01-18

"""
Alert CRUD Router
Provides endpoints for alert management (create, read, update, delete)
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, field_validator
from sqlalchemy.orm import Session

from app.audit_logger import AuditEventType, audit_logger
from app.dependencies import get_current_user_dep
from app.database_enhanced import Alert, User, get_db

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


# ==================== Pydantic Models ====================

class AlertCreate(BaseModel):
    """Alert creation request"""
    asset_id: int
    alert_type: str
    target_price: Optional[Decimal] = None
    change_percent: Optional[Decimal] = None
    notification_method: str = "email"

    @field_validator('alert_type')
    @classmethod
    def validate_alert_type(cls, v):
        valid_types = ["above", "below", "change"]
        if v not in valid_types:
            valid_str = ", ".join(valid_types)
            raise ValueError(f'Alert type must be one of: {valid_str}')
        return v

    @field_validator('notification_method')
    @classmethod
    def validate_notification_method(cls, v):
        valid_methods = ["email", "push", "both"]
        if v not in valid_methods:
            valid_str = ", ".join(valid_methods)
            raise ValueError(f'Notification method must be one of: {valid_str}')
        return v

    @field_validator('target_price')
    @classmethod
    def validate_target_price(cls, v, info):
        alert_type = info.data.get('alert_type') if info.data else None
        if alert_type in ['above', 'below'] and v is None:
            msg = 'target_price is required for "above" and "below" alert types'
            raise ValueError(msg)
        return v

    @field_validator('change_percent')
    @classmethod
    def validate_change_percent(cls, v, info):
        alert_type = info.data.get('alert_type') if info.data else None
        if alert_type == 'change' and v is None:
            raise ValueError('change_percent is required for "change" alert type')
        return v


class AlertUpdate(BaseModel):
    """Alert update request"""
    target_price: Optional[Decimal] = None
    change_percent: Optional[Decimal] = None
    is_active: Optional[bool] = None
    notification_method: Optional[str] = None


class AlertResponse(BaseModel):
    """Alert response"""
    id: int
    user_id: int
    asset_id: int
    alert_type: str
    target_price: Optional[Decimal] = None
    change_percent: Optional[Decimal] = None
    is_active: bool
    is_triggered: bool
    triggered_at: Optional[datetime] = None
    notification_method: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ==================== Endpoints ====================

@router.post("/", response_model=AlertResponse, status_code=status.HTTP_201_CREATED)
async def create_alert(
    alert_data: AlertCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Create a new alert

    **Permissions:** Authenticated user
    **OSF Security:** Input validation, audit logging
    """
    # Create new alert
    new_alert = Alert(
        user_id=current_user.id,
        asset_id=alert_data.asset_id,
        alert_type=alert_data.alert_type,
        target_price=alert_data.target_price,
        change_percent=alert_data.change_percent,
        notification_method=alert_data.notification_method,
        is_active=True,
        is_triggered=False
    )

    db.add(new_alert)
    db.commit()
    db.refresh(new_alert)

    # Audit log
    audit_logger.log_event(
        AuditEventType.ALERT_CREATED,
        user_id=current_user.id,
        details={
            "alert_id": new_alert.id,
            "asset_id": new_alert.asset_id,
            "alert_type": new_alert.alert_type
        }
    )

    return new_alert


@router.get("/", response_model=List[AlertResponse])
async def list_alerts(
    skip: int = 0,
    limit: int = 100,
    asset_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    is_triggered: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    List alerts

    **Permissions:** Own alerts or ADMIN for all
    **Pagination:** skip, limit
    **Filters:** asset_id, is_active, is_triggered
    """
    query = db.query(Alert)

    # Non-admin users can only see their own alerts
    if not current_user.is_admin:
        query = query.filter(Alert.user_id == current_user.id)

    if asset_id is not None:
        query = query.filter(Alert.asset_id == asset_id)

    if is_active is not None:
        query = query.filter(Alert.is_active == is_active)

    if is_triggered is not None:
        query = query.filter(Alert.is_triggered == is_triggered)

    alerts = query.order_by(
        Alert.created_at.desc()
    ).offset(skip).limit(limit).all()
    return alerts


@router.get("/{alert_id}", response_model=AlertResponse)
async def get_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Get alert by ID

    **Permissions:** Own alert or ADMIN
    """
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )

    # Check permission (admin or own alert)
    if not current_user.is_admin and alert.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only view your own alerts"
        )

    return alert


@router.put("/{alert_id}", response_model=AlertResponse)
async def update_alert(
    alert_id: int,
    alert_data: AlertUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Update alert

    **Permissions:** Own alert or ADMIN
    **OSF Security:** Audit logging, permission checks
    """
    # Get alert
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )

    # Check permission (admin or own alert)
    if not current_user.is_admin and alert.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only update your own alerts"
        )

    # Update fields
    if alert_data.target_price is not None:
        alert.target_price = alert_data.target_price
    if alert_data.change_percent is not None:
        alert.change_percent = alert_data.change_percent
    if alert_data.is_active is not None:
        alert.is_active = alert_data.is_active
    if alert_data.notification_method is not None:
        alert.notification_method = alert_data.notification_method

    db.commit()
    db.refresh(alert)

    # Audit log
    audit_logger.log_event(
        AuditEventType.ALERT_UPDATED,
        user_id=current_user.id,
        details={
            "alert_id": alert.id,
            "asset_id": alert.asset_id,
            "changes": alert_data.dict(exclude_unset=True)
        }
    )

    return alert


@router.delete("/{alert_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Delete alert (hard delete)

    **Permissions:** Own alert or ADMIN
    **OSF Security:** Audit logging, permission checks
    """
    # Get alert
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )

    # Check permission (admin or own alert)
    if not current_user.is_admin and alert.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only delete your own alerts"
        )

    # Store details for audit log
    alert_details = {
        "alert_id": alert.id,
        "asset_id": alert.asset_id,
        "alert_type": alert.alert_type,
        "user_id": alert.user_id
    }

    # Hard delete
    db.delete(alert)
    db.commit()

    # Audit log
    audit_logger.log_event(
        AuditEventType.ALERT_DELETED,
        user_id=current_user.id,
        details=alert_details
    )

    return None
