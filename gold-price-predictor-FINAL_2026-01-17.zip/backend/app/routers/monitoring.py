# FILE: backend/app/routers/monitoring.py | PURPOSE: Monitoring and health check endpoints | OWNER: Backend Team | RELATED: main.py | LAST-AUDITED: 2025-11-21

"""
Monitoring and Health Check Endpoints
Provides system health, metrics, and statistics endpoints
"""

import time
from datetime import datetime
from typing import Any, Dict

import psutil
import redis
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.dependencies import get_current_user_dep
from app.database_enhanced import User, get_db
from app.config_secure import settings

router = APIRouter(prefix="/api", tags=["monitoring"])

# Track request statistics
request_stats = {
    "total_requests": 0,
    "successful_requests": 0,
    "failed_requests": 0,
    "start_time": time.time()
}


@router.get("/health")
async def health_check():
    """
    Basic health check endpoint
    Returns 200 if service is running
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "Gold Price Predictor API"
    }


@router.get("/ready")
async def readiness_check(db: Session = Depends(get_db)):
    """
    Readiness check with database and Redis connectivity
    Returns 200 if all dependencies are ready
    """
    checks = {}
    all_ready = True

    # Check database
    try:
        db.execute(text("SELECT 1"))
        checks["database"] = {
            "status": "ready",
            "message": "PostgreSQL connected"
        }
    except Exception as db_error:
        checks["database"] = {
            "status": "not_ready",
            "error": str(db_error)
        }
        all_ready = False

    # Check Redis
    try:
        r = redis.Redis.from_url(settings.REDIS_URL, decode_responses=True)
        r.ping()
        checks["redis"] = {"status": "ready", "message": "Redis connected"}
    except Exception as redis_error:
        checks["redis"] = {
            "status": "not_ready",
            "error": str(redis_error)
        }
        all_ready = False

    return {
        "status": "ready" if all_ready else "not_ready",
        "timestamp": datetime.utcnow().isoformat(),
        "checks": checks
    }


@router.get("/metrics")
async def system_metrics():
    """
    System metrics endpoint
    Returns CPU, memory, disk, and application metrics
    """
    # CPU metrics
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_count = psutil.cpu_count()

    # Memory metrics
    memory = psutil.virtual_memory()
    memory_metrics = {
        "total_mb": round(memory.total / (1024 * 1024), 2),
        "available_mb": round(memory.available / (1024 * 1024), 2),
        "used_mb": round(memory.used / (1024 * 1024), 2),
        "percent": memory.percent
    }

    # Disk metrics
    disk = psutil.disk_usage('/')
    disk_metrics = {
        "total_gb": round(disk.total / (1024 ** 3), 2),
        "used_gb": round(disk.used / (1024 ** 3), 2),
        "free_gb": round(disk.free / (1024 ** 3), 2),
        "percent": disk.percent
    }

    # Application metrics
    uptime_seconds = time.time() - request_stats["start_time"]
    app_metrics = {
        "uptime_seconds": round(uptime_seconds, 2),
        "total_requests": request_stats["total_requests"],
        "successful_requests": request_stats["successful_requests"],
        "failed_requests": request_stats["failed_requests"],
        "success_rate": round(
            (
                request_stats["successful_requests"]
                / request_stats["total_requests"] * 100
            ) if request_stats["total_requests"] > 0 else 0,
            2
        )
    }

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "cpu": {
            "percent": cpu_percent,
            "count": cpu_count
        },
        "memory": memory_metrics,
        "disk": disk_metrics,
        "application": app_metrics
    }


@router.get("/stats")
async def application_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
) -> Dict[str, Any]:
    """
    Application statistics (requires authentication)
    Returns database statistics and user activity
    """
    # Ensure user is admin
    if not current_user.is_admin:
        return {
            "success": False,
            "message": "Admin access required"
        }

    stats = {}

    # Users count
    try:
        result = db.execute(text("SELECT COUNT(*) as count FROM users"))
        stats["total_users"] = result.scalar()
    except Exception:  # noqa: BLE001
        stats["total_users"] = "N/A"

    # API keys count
    try:
        query = text("SELECT COUNT(*) as count FROM api_keys WHERE revoked = false")
        result = db.execute(query)
        stats["active_api_keys"] = result.scalar()
    except Exception:  # noqa: BLE001
        stats["active_api_keys"] = "N/A"

    # Predictions count (last 24 hours)
    try:
        query = text("""
            SELECT COUNT(*) as count FROM predictions
            WHERE created_at > NOW() - INTERVAL '24 hours'
        """)
        result = db.execute(query)
        stats["predictions_24h"] = result.scalar()
    except Exception:  # noqa: BLE001
        stats["predictions_24h"] = "N/A"

    # Audit logs count (last 24 hours)
    try:
        query = text("""
            SELECT COUNT(*) as count FROM audit_logs
            WHERE timestamp > NOW() - INTERVAL '24 hours'
        """)
        result = db.execute(query)
        stats["audit_logs_24h"] = result.scalar()
    except Exception:  # noqa: BLE001
        stats["audit_logs_24h"] = "N/A"

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "statistics": stats
    }


@router.get("/logs")
async def recent_logs(
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
) -> Dict[str, Any]:
    """
    Recent application logs (admin only)
    Returns last N audit log entries
    """
    # Ensure user is admin
    if not current_user.is_admin:
        return {
            "success": False,
            "message": "Admin access required"
        }

    try:
        query = text("""
            SELECT id, event_type, username, success, timestamp, details
            FROM audit_logs
            ORDER BY timestamp DESC
            LIMIT :limit
        """)
        result = db.execute(query, {"limit": limit})

        logs = []
        for row in result:
            logs.append({
                "id": row[0],
                "event_type": row[1],
                "username": row[2],
                "success": row[3],
                "timestamp": row[4].isoformat() if row[4] else None,
                "details": row[5]
            })

        return {
            "timestamp": datetime.utcnow().isoformat(),
            "count": len(logs),
            "logs": logs
        }
    except Exception as log_error:  # noqa: BLE001
        return {
            "success": False,
            "message": f"Error fetching logs: {str(log_error)}"
        }


def increment_request_stats(success: bool = True):
    """
    Helper function to increment request statistics
    Call this from middleware or endpoint handlers
    """
    request_stats["total_requests"] += 1
    if success:
        request_stats["successful_requests"] += 1
    else:
        request_stats["failed_requests"] += 1
