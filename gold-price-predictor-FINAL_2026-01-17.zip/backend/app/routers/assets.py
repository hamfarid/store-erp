# FILE: backend/app/routers/assets.py | PURPOSE: Asset CRUD endpoints | OWNER: Backend Team | RELATED: database_enhanced.py | LAST-AUDITED: 2025-01-18

"""
Asset CRUD Router
Provides endpoints for asset management (create, read, update, delete)
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, field_validator
from sqlalchemy.orm import Session

from app.audit_logger import AuditEventType, audit_logger
from app.dependencies import get_current_user_dep
from app.database_enhanced import Asset, User, get_db

router = APIRouter(prefix="/api/assets", tags=["assets"])


# ==================== Pydantic Models ====================

class AssetCreate(BaseModel):
    """Asset creation request"""
    symbol: str
    name: str
    category: str
    description: Optional[str] = None

    @field_validator('symbol')
    @classmethod
    def validate_symbol(cls, v):
        if len(v) < 1 or len(v) > 20:
            raise ValueError('Symbol must be between 1 and 20 characters')
        return v.upper()

    @field_validator('name')
    @classmethod
    def validate_name(cls, v):
        if len(v) < 1 or len(v) > 100:
            raise ValueError('Name must be between 1 and 100 characters')
        return v

    @field_validator('category')
    @classmethod
    def validate_category(cls, v):
        valid_categories = [
            "Precious Metals",
            "Energy",
            "Industrial Metals",
            "Cryptocurrency",
            "Currency",
            "Index",
            "Stocks",
            "Commodities"
        ]
        if v not in valid_categories:
            valid_str = ", ".join(valid_categories)
            raise ValueError(f'Category must be one of: {valid_str}')
        return v


class AssetUpdate(BaseModel):
    """Asset update request"""
    name: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class AssetResponse(BaseModel):
    """Asset response"""
    id: int
    symbol: str
    name: str
    category: str
    description: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ==================== Endpoints ====================

@router.post("/", response_model=AssetResponse, status_code=status.HTTP_201_CREATED)
async def create_asset(
    asset_data: AssetCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Create a new asset (Admin only)

    **Permissions:** ADMIN
    **OSF Security:** Input validation, audit logging
    """
    # Check admin permission
    if not current_user.is_admin:
        audit_logger.log_event(
            AuditEventType.UNAUTHORIZED_ACCESS,
            user_id=current_user.id,
            details={"action": "create_asset", "reason": "not_admin"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can create assets"
        )

    # Check if symbol already exists
    existing_asset = db.query(Asset).filter(Asset.symbol == asset_data.symbol).first()
    if existing_asset:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Asset with this symbol already exists"
        )

    # Create new asset
    new_asset = Asset(
        symbol=asset_data.symbol,
        name=asset_data.name,
        category=asset_data.category,
        description=asset_data.description,
        is_active=True
    )

    db.add(new_asset)
    db.commit()
    db.refresh(new_asset)

    # Audit log
    audit_logger.log_event(
        AuditEventType.ASSET_CREATED,
        user_id=current_user.id,
        details={
            "asset_id": new_asset.id,
            "symbol": new_asset.symbol,
            "name": new_asset.name
        }
    )

    return new_asset


@router.get("/", response_model=List[AssetResponse])
async def list_assets(
    skip: int = 0,
    limit: int = 100,
    category: Optional[str] = None,
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """
    List all assets (Public endpoint)

    **Pagination:** skip, limit
    **Filters:** category, is_active
    """
    query = db.query(Asset)

    if category is not None:
        query = query.filter(Asset.category == category)

    if is_active is not None:
        query = query.filter(Asset.is_active == is_active)

    assets = query.offset(skip).limit(limit).all()
    return assets


@router.get("/{asset_id}", response_model=AssetResponse)
async def get_asset(
    asset_id: int,
    db: Session = Depends(get_db)
):
    """
    Get asset by ID (Public endpoint)
    """
    asset = db.query(Asset).filter(Asset.id == asset_id).first()
    if not asset:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Asset not found"
        )

    return asset


@router.put("/{asset_id}", response_model=AssetResponse)
async def update_asset(
    asset_id: int,
    asset_data: AssetUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Update asset (Admin only)

    **Permissions:** ADMIN
    **OSF Security:** Audit logging, permission checks
    """
    # Check admin permission
    if not current_user.is_admin:
        audit_logger.log_event(
            AuditEventType.UNAUTHORIZED_ACCESS,
            user_id=current_user.id,
            details={"action": "update_asset", "reason": "not_admin"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can update assets"
        )

    # Get asset
    asset = db.query(Asset).filter(Asset.id == asset_id).first()
    if not asset:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Asset not found"
        )

    # Update fields
    if asset_data.name is not None:
        asset.name = asset_data.name
    if asset_data.category is not None:
        asset.category = asset_data.category
    if asset_data.description is not None:
        asset.description = asset_data.description
    if asset_data.is_active is not None:
        asset.is_active = asset_data.is_active

    asset.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(asset)

    # Audit log
    audit_logger.log_event(
        AuditEventType.ASSET_UPDATED,
        user_id=current_user.id,
        details={
            "asset_id": asset.id,
            "symbol": asset.symbol,
            "changes": asset_data.dict(exclude_unset=True)
        }
    )

    return asset


@router.delete("/{asset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_asset(
    asset_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """
    Delete asset (soft delete - set is_active=False) (Admin only)

    **Permissions:** ADMIN
    **OSF Security:** Soft delete, audit logging
    """
    # Check admin permission
    if not current_user.is_admin:
        audit_logger.log_event(
            AuditEventType.UNAUTHORIZED_ACCESS,
            user_id=current_user.id,
            details={"action": "delete_asset", "reason": "not_admin"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can delete assets"
        )

    # Get asset
    asset = db.query(Asset).filter(Asset.id == asset_id).first()
    if not asset:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Asset not found"
        )

    # Soft delete
    asset.is_active = False
    asset.updated_at = datetime.utcnow()
    db.commit()

    # Audit log
    audit_logger.log_event(
        AuditEventType.ASSET_DELETED,
        user_id=current_user.id,
        details={
            "asset_id": asset.id,
            "symbol": asset.symbol
        }
    )

    return None
