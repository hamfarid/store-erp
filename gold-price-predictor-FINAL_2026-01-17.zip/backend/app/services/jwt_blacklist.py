# File: /home/ubuntu/gold-price-predictor/backend/app/services/jwt_blacklist.py
"""
JWT Blacklist Service
Implements token revocation using Redis for security
"""

import redis
from typing import Optional
from datetime import datetime, timedelta
import os
import logging

logger = logging.getLogger(__name__)


class JWTBlacklist:
    """
    JWT Blacklist Service using Redis

    Provides functionality to:
    - Blacklist tokens (logout, password change, etc.)
    - Check if a token is blacklisted
    - Auto-expire blacklisted tokens
    """

    def __init__(self, redis_url: Optional[str] = None):
        """
        Initialize JWT Blacklist with Redis connection

        Args:
            redis_url: Redis connection URL (default from env)
        """
        self.redis_url = redis_url or os.getenv(
            'REDIS_URL', 'redis://localhost:6379/0')
        self.enabled = os.getenv('REDIS_ENABLED', 'true').lower() == 'true'

        if self.enabled:
            try:
                self.redis_client = redis.from_url(
                    self.redis_url,
                    decode_responses=True,
                    socket_connect_timeout=5
                )
                # Test connection
                self.redis_client.ping()
                logger.info("JWT Blacklist initialized with Redis")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {str(e)}")
                self.enabled = False
                self.redis_client = None
        else:
            self.redis_client = None
            logger.warning("JWT Blacklist disabled (Redis not enabled)")

    def blacklist_token(self, token: str, expires_in: int = 3600) -> bool:
        """
        Add a token to the blacklist

        Args:
            token: JWT token to blacklist
            expires_in: Expiration time in seconds (default: 1 hour)

        Returns:
            True if successfully blacklisted, False otherwise
        """
        if not self.enabled or not self.redis_client:
            logger.warning("JWT Blacklist not available")
            return False

        try:
            key = f"blacklist:token:{token}"
            self.redis_client.setex(
                key,
                expires_in,
                datetime.utcnow().isoformat()
            )
            logger.info(
                f"Token blacklisted successfully (expires in {expires_in}s)")
            return True
        except Exception as e:
            logger.error(f"Failed to blacklist token: {str(e)}")
            return False

    def is_blacklisted(self, token: str) -> bool:
        """
        Check if a token is blacklisted

        Args:
            token: JWT token to check

        Returns:
            True if blacklisted, False otherwise
        """
        if not self.enabled or not self.redis_client:
            return False

        try:
            key = f"blacklist:token:{token}"
            return self.redis_client.exists(key) > 0
        except Exception as e:
            logger.error(f"Failed to check blacklist: {str(e)}")
            return False

    def blacklist_user_tokens(
            self,
            user_id: int,
            expires_in: int = 3600) -> bool:
        """
        Blacklist all tokens for a specific user
        Useful for password changes, account suspension, etc.

        Args:
            user_id: User ID
            expires_in: Expiration time in seconds

        Returns:
            True if successful, False otherwise
        """
        if not self.enabled or not self.redis_client:
            return False

        try:
            key = f"blacklist:user:{user_id}"
            self.redis_client.setex(
                key,
                expires_in,
                datetime.utcnow().isoformat()
            )
            logger.info(f"All tokens for user {user_id} blacklisted")
            return True
        except Exception as e:
            logger.error(f"Failed to blacklist user tokens: {str(e)}")
            return False

    def is_user_blacklisted(self, user_id: int) -> bool:
        """
        Check if all tokens for a user are blacklisted

        Args:
            user_id: User ID

        Returns:
            True if user is blacklisted, False otherwise
        """
        if not self.enabled or not self.redis_client:
            return False

        try:
            key = f"blacklist:user:{user_id}"
            return self.redis_client.exists(key) > 0
        except Exception as e:
            logger.error(f"Failed to check user blacklist: {str(e)}")
            return False

    def clear_user_blacklist(self, user_id: int) -> bool:
        """
        Remove user from blacklist

        Args:
            user_id: User ID

        Returns:
            True if successful, False otherwise
        """
        if not self.enabled or not self.redis_client:
            return False

        try:
            key = f"blacklist:user:{user_id}"
            self.redis_client.delete(key)
            logger.info(f"User {user_id} removed from blacklist")
            return True
        except Exception as e:
            logger.error(f"Failed to clear user blacklist: {str(e)}")
            return False

    def get_blacklist_stats(self) -> dict:
        """
        Get statistics about blacklisted tokens

        Returns:
            Dictionary with statistics
        """
        if not self.enabled or not self.redis_client:
            return {"enabled": False}

        try:
            token_keys = self.redis_client.keys("blacklist:token:*")
            user_keys = self.redis_client.keys("blacklist:user:*")

            return {
                "enabled": True,
                "blacklisted_tokens": len(token_keys),
                "blacklisted_users": len(user_keys),
                "total_blacklisted": len(token_keys) + len(user_keys)
            }
        except Exception as e:
            logger.error(f"Failed to get blacklist stats: {str(e)}")
            return {"enabled": True, "error": str(e)}


# Global instance
jwt_blacklist = JWTBlacklist()
