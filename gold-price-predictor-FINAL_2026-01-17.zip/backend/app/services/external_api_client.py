# File:
# /home/ubuntu/gold-price-predictor/backend/app/services/external_api_client.py
"""
External API Client with Circuit Breaker Protection
Example usage of circuit breaker pattern for external service calls
"""

import httpx
import logging
from typing import Dict, Any, Optional
from services.circuit_breaker import circuit_breaker, CircuitBreakerError, register_circuit_breaker, CircuitBreaker

logger = logging.getLogger(__name__)


class ExternalAPIClient:
    """
    Client for external API calls with circuit breaker protection

    Example: Gold price API, Market data API, etc.
    """

    def __init__(self, base_url: str, timeout: int = 10):
        """
        Initialize API client

        Args:
            base_url: Base URL for API
            timeout: Request timeout in seconds
        """
        self.base_url = base_url
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)

        # Create and register circuit breaker
        self.circuit_breaker = CircuitBreaker(
            name=f"external_api_{base_url}",
            failure_threshold=3,
            recovery_timeout=30,
            expected_exception=httpx.HTTPError
        )
        register_circuit_breaker(self.circuit_breaker)

    async def get_gold_price(
            self, symbol: str = "XAU/USD") -> Optional[Dict[str, Any]]:
        """
        Get current gold price from external API with circuit breaker

        Args:
            symbol: Gold symbol (default: XAU/USD)

        Returns:
            Price data or None if circuit is open
        """
        try:
            result = await self.circuit_breaker.call_async(
                self._fetch_gold_price,
                symbol
            )
            return result
        except CircuitBreakerError as e:
            logger.error(f"Circuit breaker open: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error fetching gold price: {str(e)}")
            return None

    async def _fetch_gold_price(self, symbol: str) -> Dict[str, Any]:
        """
        Internal method to fetch gold price

        Args:
            symbol: Gold symbol

        Returns:
            Price data

        Raises:
            httpx.HTTPError: If request fails
        """
        url = f"{self.base_url}/gold/price"
        params = {"symbol": symbol}

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        return response.json()

    async def get_market_data(self, asset: str) -> Optional[Dict[str, Any]]:
        """
        Get market data with circuit breaker protection

        Args:
            asset: Asset symbol

        Returns:
            Market data or None if circuit is open
        """
        try:
            result = await self.circuit_breaker.call_async(
                self._fetch_market_data,
                asset
            )
            return result
        except CircuitBreakerError as e:
            logger.error(f"Circuit breaker open: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error fetching market data: {str(e)}")
            return None

    async def _fetch_market_data(self, asset: str) -> Dict[str, Any]:
        """
        Internal method to fetch market data

        Args:
            asset: Asset symbol

        Returns:
            Market data

        Raises:
            httpx.HTTPError: If request fails
        """
        url = f"{self.base_url}/market/{asset}"

        response = await self.client.get(url)
        response.raise_for_status()

        return response.json()

    def get_circuit_state(self) -> Dict[str, Any]:
        """
        Get current circuit breaker state

        Returns:
            Circuit breaker state information
        """
        return self.circuit_breaker.get_state()

    def reset_circuit(self):
        """Manually reset circuit breaker"""
        self.circuit_breaker.reset()
        logger.info(f"Circuit breaker reset for {self.base_url}")

    async def close(self):
        """Close HTTP client"""
        await self.client.aclose()


# Example: Synchronous function with circuit breaker decorator
@circuit_breaker(
    name="database_backup",
    failure_threshold=3,
    recovery_timeout=120
)
def backup_database(db_name: str) -> bool:
    """
    Backup database with circuit breaker protection

    Args:
        db_name: Database name

    Returns:
        True if successful

    Raises:
        Exception: If backup fails
    """
    # Simulated backup operation
    logger.info(f"Backing up database: {db_name}")
    # ... actual backup logic ...
    return True


# Example: Async function with circuit breaker decorator
@circuit_breaker(
    name="external_prediction_api",
    failure_threshold=5,
    recovery_timeout=60
)
async def call_prediction_api(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Call external prediction API with circuit breaker

    Args:
        data: Prediction input data

    Returns:
        Prediction result

    Raises:
        httpx.HTTPError: If API call fails
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.example.com/predict",
            json=data,
            timeout=10
        )
        response.raise_for_status()
        return response.json()
