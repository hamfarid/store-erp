# FILE: backend/app/services/cache.py | PURPOSE: Redis caching service with decorators | OWNER: Backend Team | RELATED: main.py, rate_limiter_redis.py | LAST-AUDITED: 2025-11-28

import json
import logging
import os
from functools import wraps
from typing import Any, Callable, Optional

import redis.asyncio as redis
from fastapi import Response

# Configure logging
logger = logging.getLogger(__name__)

# Redis Configuration
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
DEFAULT_TTL = 300  # 5 minutes default


class CacheService:
    def __init__(self):
        self.redis: Optional[redis.Redis] = None
        self.enabled = os.getenv("REDIS_ENABLED", "true").lower() == "true"

    async def connect(self):
        """Initialize Redis connection pool"""
        if not self.enabled:
            logger.warning("Redis cache is disabled via env")
            return

        try:
            self.redis = redis.from_url(
                REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                socket_connect_timeout=5
            )
            await self.redis.ping()
            logger.info(f"✅ Connected to Redis Cache at {REDIS_URL}")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Redis Cache: {str(e)}")
            self.redis = None

    async def close(self):
        """Close Redis connection"""
        if self.redis:
            await self.redis.close()
            logger.info("Redis Cache connection closed")

    async def get(self, key: str) -> Any:
        """Get value from cache"""
        if not self.redis:
            return None
        try:
            data = await self.redis.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            logger.error(f"Cache GET error for {key}: {str(e)}")
            return None

    async def set(self, key: str, value: Any, ttl: int = DEFAULT_TTL):
        """Set value in cache with TTL"""
        if not self.redis:
            return
        try:
            await self.redis.setex(key, ttl, json.dumps(value))
        except Exception as e:
            logger.error(f"Cache SET error for {key}: {str(e)}")

    async def delete(self, key: str):
        """Delete key from cache"""
        if not self.redis:
            return
        try:
            await self.redis.delete(key)
        except Exception as e:
            logger.error(f"Cache DELETE error for {key}: {str(e)}")

    async def clear_namespace(self, namespace: str):
        """Clear all keys starting with namespace"""
        if not self.redis:
            return
        try:
            keys = await self.redis.keys(f"{namespace}:*")
            if keys:
                await self.redis.delete(*keys)
                logger.info(f"Cleared {len(keys)} keys for namespace {namespace}")
        except Exception as e:
            logger.error(f"Cache CLEAR error for {namespace}: {str(e)}")


# Global instance
cache = CacheService()


def cached(ttl: int = DEFAULT_TTL, namespace: str = "global", key_builder: Optional[Callable] = None):
    """
    Decorator to cache API endpoints.

    Args:
        ttl: Time to live in seconds
        namespace: Key prefix
        key_builder: Custom function to build cache key from request
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 1. Check if cache is available
            if not cache.redis:
                return await func(*args, **kwargs)

            # 2. Build Cache Key
            request = kwargs.get('request')
            if key_builder and request:
                key_part = key_builder(request, *args, **kwargs)
            else:
                # Default: Use path + query params
                key_part = "default"
                if request:
                    key_part = str(request.url)
                # Add args to key to ensure uniqueness
                key_part += f":{str(args)}:{str(kwargs)}"

            cache_key = f"{namespace}:{hash(key_part)}"

            # 3. Try to get from cache
            cached_data = await cache.get(cache_key)
            if cached_data:
                # Add header to indicate cache hit
                if 'response' in kwargs and isinstance(kwargs['response'], Response):
                    kwargs['response'].headers["X-Cache"] = "HIT"
                return cached_data

            # 4. Execute function
            result = await func(*args, **kwargs)

            # 5. Save to cache
            await cache.set(cache_key, result, ttl)

            if 'response' in kwargs and isinstance(kwargs['response'], Response):
                kwargs['response'].headers["X-Cache"] = "MISS"

            return result
        return wrapper
    return decorator
