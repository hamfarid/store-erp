# File:
# /home/ubuntu/gold-price-predictor/backend/app/services/api_key_service.py
"""
API Key Management Service
Handles creation, validation, and management of API keys
"""

import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from database_enhanced import APIKey, User


class APIKeyService:
    """Service for managing API keys"""

    @staticmethod
    def generate_key() -> str:
        """
        Generate a secure random API key

        Returns:
            str: Generated API key (64 characters)
        """
        return secrets.token_urlsafe(48)  # ~64 characters

    @staticmethod
    def hash_key(key: str) -> str:
        """
        Hash an API key for secure storage

        Args:
            key: Plain API key

        Returns:
            str: Hashed key
        """
        return hashlib.sha256(key.encode()).hexdigest()

    @staticmethod
    def create_api_key(
        db: Session,
        user_id: int,
        name: str,
        expires_in_days: Optional[int] = 365
    ) -> Tuple[APIKey, str]:
        """
        Create a new API key for a user

        Args:
            db: Database session
            user_id: User ID
            name: Name/description of the API key
            expires_in_days: Days until expiration (None for no expiration)

        Returns:
            Tuple of (APIKey object, plain key string)
        """
        # Generate key
        plain_key = APIKeyService.generate_key()
        key_hash = APIKeyService.hash_key(plain_key)

        # Calculate expiration
        expires_at = None
        if expires_in_days:
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)

        # Create API key record
        api_key = APIKey(
            user_id=user_id,
            name=name,
            key_hash=key_hash,
            expires_at=expires_at
        )

        db.add(api_key)
        db.commit()
        db.refresh(api_key)

        return api_key, plain_key

    @staticmethod
    def validate_api_key(db: Session, key: str) -> Optional[User]:
        """
        Validate an API key and return the associated user

        Args:
            db: Database session
            key: Plain API key

        Returns:
            User object if valid, None otherwise
        """
        key_hash = APIKeyService.hash_key(key)

        # Find API key
        api_key = db.query(APIKey).filter(
            APIKey.key_hash == key_hash,
            APIKey.is_active
        ).first()

        if not api_key:
            return None

        # Check expiration
        if api_key.expires_at and api_key.expires_at < datetime.utcnow():
            return None

        # Update last used
        api_key.last_used_at = datetime.utcnow()
        api_key.request_count += 1
        db.commit()

        # Get user
        user = db.query(User).filter(User.id == api_key.user_id).first()

        return user

    @staticmethod
    def list_api_keys(db: Session, user_id: int) -> List[APIKey]:
        """
        List all API keys for a user

        Args:
            db: Database session
            user_id: User ID

        Returns:
            List of APIKey objects
        """
        return db.query(APIKey).filter(
            APIKey.user_id == user_id
        ).order_by(APIKey.created_at.desc()).all()

    @staticmethod
    def revoke_api_key(db: Session, key_id: int, user_id: int) -> bool:
        """
        Revoke (deactivate) an API key

        Args:
            db: Database session
            key_id: API key ID
            user_id: User ID (for authorization)

        Returns:
            True if revoked, False otherwise
        """
        api_key = db.query(APIKey).filter(
            APIKey.id == key_id,
            APIKey.user_id == user_id
        ).first()

        if not api_key:
            return False

        api_key.is_active = False
        db.commit()

        return True

    @staticmethod
    def delete_api_key(db: Session, key_id: int, user_id: int) -> bool:
        """
        Permanently delete an API key

        Args:
            db: Database session
            key_id: API key ID
            user_id: User ID (for authorization)

        Returns:
            True if deleted, False otherwise
        """
        api_key = db.query(APIKey).filter(
            APIKey.id == key_id,
            APIKey.user_id == user_id
        ).first()

        if not api_key:
            return False

        db.delete(api_key)
        db.commit()

        return True

    @staticmethod
    def get_api_key_stats(db: Session, user_id: int) -> dict:
        """
        Get statistics about API key usage

        Args:
            db: Database session
            user_id: User ID

        Returns:
            Dictionary with statistics
        """
        keys = db.query(APIKey).filter(APIKey.user_id == user_id).all()

        total_keys = len(keys)
        active_keys = len([k for k in keys if k.is_active])
        expired_keys = len([
            k for k in keys
            if k.expires_at and k.expires_at < datetime.utcnow()
        ])
        total_requests = sum(k.request_count for k in keys)

        return {
            "total_keys": total_keys,
            "active_keys": active_keys,
            "expired_keys": expired_keys,
            "total_requests": total_requests
        }
