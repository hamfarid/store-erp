# دليل إدارة الأسرار (Secrets Management)

## نظرة عامة

يوفر نظام إدارة الأسرار واجهة موحدة للتعامل مع المعلومات الحساسة (كلمات المرور، مفاتيح API، شهادات SSL) عبر مصادر متعددة:

- **Environment Variables** - المتغيرات البيئية (الافتراضي)
- **HashiCorp Vault** - حل متقدم لإدارة الأسرار
- **AWS Secrets Manager** - خدمة AWS لإدارة الأسرار

---

## المتطلبات

### التثبيت الأساسي

```bash
# لا يتطلب مكتبات إضافية للبيئة الافتراضية (Environment Variables)

# لاستخدام HashiCorp Vault
pip install hvac

# لاستخدام AWS Secrets Manager
pip install boto3
```

---

## الاستخدام الأساسي

### 1. استخدام المتغيرات البيئية (الافتراضي)

```python
from services.secrets_manager import get_secret

# الحصول على سر
db_password = get_secret('DB_PASSWORD')

# الحصول على سر مع قيمة افتراضية
api_key = get_secret('API_KEY', default='default-key')
```

### 2. استخدام HashiCorp Vault

```python
from services.secrets_manager import SecretsManager

# تهيئة Secrets Manager مع Vault
secrets = SecretsManager(
    backend='vault',
    vault_addr='http://localhost:8200',
    vault_token='your-vault-token'
)

# الحصول على سر
db_password = secrets.get('database/password')

# تعيين سر جديد
secrets.set('api/key', 'new-api-key-value')

# حذف سر
secrets.delete('old/secret')

# عرض جميع الأسرار
all_secrets = secrets.list()
```

### 3. استخدام AWS Secrets Manager

```python
from services.secrets_manager import SecretsManager

# تهيئة Secrets Manager مع AWS
secrets = SecretsManager(
    backend='aws',
    region_name='us-east-1'
)

# الحصول على سر
db_password = secrets.get('prod/database/password')

# تعيين سر جديد
secrets.set('prod/api/key', 'new-api-key-value')
```

---

## التكوين

### استخدام المتغيرات البيئية

```bash
# تحديد نوع Backend
export SECRETS_BACKEND=env  # أو vault أو aws

# إعدادات Vault
export VAULT_ADDR=http://localhost:8200
export VAULT_TOKEN=your-vault-token
export VAULT_NAMESPACE=your-namespace  # اختياري

# إعدادات AWS
export AWS_REGION=us-east-1
export AWS_ACCESS_KEY_ID=your-access-key
export AWS_SECRET_ACCESS_KEY=your-secret-key
```

### التكوين البرمجي

```python
from services.secrets_manager import SecretsManager

# تكوين مخصص
secrets = SecretsManager(
    backend='vault',
    vault_addr='https://vault.example.com',
    vault_token='s.xxxxxxxxxx',
    mount_point='secret',  # نقطة التثبيت الافتراضية
    cache_enabled=True  # تفعيل التخزين المؤقت
)
```

---

## إعداد HashiCorp Vault

### 1. تثبيت Vault

```bash
# باستخدام Docker
docker run --cap-add=IPC_LOCK \
  -e 'VAULT_DEV_ROOT_TOKEN_ID=myroot' \
  -p 8200:8200 \
  --name=vault \
  vault:latest

# أو التثبيت المباشر
wget https://releases.hashicorp.com/vault/1.15.0/vault_1.15.0_linux_amd64.zip
unzip vault_1.15.0_linux_amd64.zip
sudo mv vault /usr/local/bin/
```

### 2. تهيئة Vault

```bash
# تعيين عنوان Vault
export VAULT_ADDR='http://localhost:8200'

# تسجيل الدخول
vault login myroot

# تفعيل KV secrets engine
vault secrets enable -path=secret kv-v2

# إضافة سر
vault kv put secret/database password=mypassword username=admin

# قراءة سر
vault kv get secret/database
```

### 3. إنشاء سياسة وصول

```bash
# إنشاء ملف سياسة
cat > app-policy.hcl <<EOF
path "secret/data/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}
EOF

# تطبيق السياسة
vault policy write app-policy app-policy.hcl

# إنشاء توكن مع السياسة
vault token create -policy=app-policy
```

---

## إعداد AWS Secrets Manager

### 1. إنشاء سر في AWS

```bash
# باستخدام AWS CLI
aws secretsmanager create-secret \
    --name prod/database/password \
    --secret-string "mypassword" \
    --region us-east-1

# إنشاء سر JSON
aws secretsmanager create-secret \
    --name prod/database/credentials \
    --secret-string '{"username":"admin","password":"mypassword"}' \
    --region us-east-1
```

### 2. إعداد صلاحيات IAM

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret",
        "secretsmanager:ListSecrets"
      ],
      "Resource": "arn:aws:secretsmanager:us-east-1:*:secret:prod/*"
    }
  ]
}
```

---

## أمثلة متقدمة

### 1. التخزين المؤقت (Caching)

```python
from services.secrets_manager import SecretsManager

# تفعيل التخزين المؤقت
secrets = SecretsManager(backend='vault', cache_enabled=True)

# أول استدعاء: يتم جلب السر من Vault
password = secrets.get('database/password')

# الاستدعاءات التالية: يتم جلب السر من الذاكرة
password = secrets.get('database/password')  # أسرع

# مسح الذاكرة المؤقتة
secrets.clear_cache()
```

### 2. Fallback إلى المتغيرات البيئية

```python
from services.secrets_manager import SecretsManager

# إذا لم يتم العثور على السر في Vault، يتم البحث في المتغيرات البيئية
secrets = SecretsManager(backend='vault')

# سيحاول أولاً Vault، ثم المتغيرات البيئية
db_password = secrets.get('DB_PASSWORD')
```

### 3. استخدام Global Instance

```python
from services.secrets_manager import get_secret, get_secrets_manager

# استخدام الدالة المساعدة
password = get_secret('DB_PASSWORD')

# أو الحصول على المدير العام
manager = get_secrets_manager()
password = manager.get('DB_PASSWORD')
```

---

## التكامل مع التطبيق

### تحديث ملف التكوين

```python
# config.py
from services.secrets_manager import get_secret

class Config:
    # استخدام Secrets Manager بدلاً من os.getenv
    DB_HOST = get_secret('DB_HOST', 'localhost')
    DB_PORT = get_secret('DB_PORT', '5432')
    DB_NAME = get_secret('DB_NAME', 'gold_predictor')
    DB_USER = get_secret('DB_USER', 'postgres')
    DB_PASSWORD = get_secret('DB_PASSWORD')  # حساس!
    
    SECRET_KEY = get_secret('SECRET_KEY')  # حساس!
    JWT_SECRET = get_secret('JWT_SECRET')  # حساس!
    
    # API Keys
    GOLD_API_KEY = get_secret('GOLD_API_KEY')  # حساس!
```

### استخدام في FastAPI

```python
from fastapi import FastAPI, Depends
from services.secrets_manager import get_secrets_manager, SecretsManager

app = FastAPI()

def get_secrets() -> SecretsManager:
    """Dependency للحصول على Secrets Manager"""
    return get_secrets_manager()

@app.get("/config")
async def get_config(secrets: SecretsManager = Depends(get_secrets)):
    """عرض التكوين (بدون الأسرار الحساسة)"""
    return {
        "db_host": secrets.get('DB_HOST'),
        "environment": secrets.get('ENVIRONMENT', 'development')
    }
```

---

## أفضل الممارسات

### 1. لا تخزن الأسرار في الكود

```python
# ❌ خطأ
DB_PASSWORD = "mypassword123"

# ✅ صحيح
from services.secrets_manager import get_secret
DB_PASSWORD = get_secret('DB_PASSWORD')
```

### 2. استخدم أسماء واضحة للأسرار

```python
# ❌ غير واضح
password = get_secret('PWD')

# ✅ واضح
db_password = get_secret('DATABASE_PASSWORD')
api_key = get_secret('EXTERNAL_API_KEY')
```

### 3. استخدم Namespaces/Prefixes

```bash
# تنظيم الأسرار حسب البيئة والخدمة
prod/database/password
prod/api/external_key
dev/database/password
dev/api/external_key
```

### 4. قم بتدوير الأسرار بانتظام

```python
# سكريبت لتدوير كلمة مرور قاعدة البيانات
from services.secrets_manager import get_secrets_manager
import secrets
import string

def rotate_db_password():
    manager = get_secrets_manager()
    
    # توليد كلمة مرور جديدة
    new_password = ''.join(secrets.choice(
        string.ascii_letters + string.digits
    ) for _ in range(32))
    
    # تحديث في Secrets Manager
    manager.set('DATABASE_PASSWORD', new_password)
    
    # تحديث في قاعدة البيانات
    # ... (كود تحديث كلمة المرور)
    
    print("Password rotated successfully")
```

### 5. استخدم التخزين المؤقت بحذر

```python
# التخزين المؤقت جيد للأسرار التي لا تتغير كثيراً
secrets = SecretsManager(backend='vault', cache_enabled=True)

# لكن قم بمسح الذاكرة المؤقتة بعد تدوير الأسرار
secrets.clear_cache()
```

---

## الأمان

### 1. تشفير الاتصال

```python
# استخدم HTTPS لـ Vault
secrets = SecretsManager(
    backend='vault',
    vault_addr='https://vault.example.com',  # HTTPS
    vault_token='s.xxxxxxxxxx'
)
```

### 2. صلاحيات محدودة

- استخدم سياسات Vault محدودة (Least Privilege)
- استخدم IAM Roles في AWS بدلاً من Access Keys
- قم بتدوير التوكنات بانتظام

### 3. Audit Logging

```python
# تفعيل Audit Logging في Vault
vault audit enable file file_path=/var/log/vault/audit.log

# مراجعة السجلات بانتظام
tail -f /var/log/vault/audit.log
```

---

## استكشاف الأخطاء

### مشكلة: Vault authentication failed

```bash
# تحقق من التوكن
vault token lookup

# تحقق من الصلاحيات
vault token capabilities secret/data/database
```

### مشكلة: AWS credentials not found

```bash
# تحقق من الإعدادات
aws configure list

# اختبر الاتصال
aws secretsmanager list-secrets
```

### مشكلة: Secret not found

```python
# استخدم قيمة افتراضية
password = get_secret('DB_PASSWORD', default='fallback-password')

# أو تحقق من وجود السر
if get_secret('DB_PASSWORD') is None:
    raise ValueError("DB_PASSWORD not configured")
```

---

## المراجع

- [HashiCorp Vault Documentation](https://www.vaultproject.io/docs)
- [AWS Secrets Manager Documentation](https://docs.aws.amazon.com/secretsmanager/)
- [12-Factor App: Config](https://12factor.net/config)

---

**تاريخ آخر تحديث:** 21 أكتوبر 2025
**المؤلف:** Manus AI

