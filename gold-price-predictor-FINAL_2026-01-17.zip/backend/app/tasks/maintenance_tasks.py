"""
Maintenance Tasks for Celery
"""

import logging
from datetime import datetime, timedelta
from pathlib import Path

from app.core.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task
def cleanup_old_data():
    """
    Cleanup old data files (scheduled weekly on Sunday at 2 AM)
    """
    logger.info("Starting weekly data cleanup")
    
    try:
        import os  # noqa: F401
        import shutil  # noqa: F401
        
        DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
        LOGS_DIR = Path(__file__).parent.parent.parent.parent / "logs"
        
        cleanup_results = {
            "logs_cleaned": 0,
            "temp_files_cleaned": 0,
            "old_backups_cleaned": 0
        }
        
        # Clean old log files (older than 30 days)
        if LOGS_DIR.exists():
            for log_file in LOGS_DIR.glob("*.log"):
                if log_file.stat().st_mtime < (datetime.now() - timedelta(days=30)).timestamp():
                    log_file.unlink()
                    cleanup_results["logs_cleaned"] += 1
                    logger.info(f"Deleted old log: {log_file.name}")
        
        # Clean temp files
        temp_patterns = ["*.tmp", "*.temp", "*.bak"]
        for pattern in temp_patterns:
            for temp_file in DATA_DIR.rglob(pattern):
                temp_file.unlink()
                cleanup_results["temp_files_cleaned"] += 1
        
        logger.info(f"Cleanup completed: {cleanup_results}")
        
        return {
            "status": "success",
            "timestamp": datetime.utcnow().isoformat(),
            "results": cleanup_results
        }
        
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task
def backup_models():
    """Backup trained models"""
    logger.info("Starting model backup")
    
    try:
        import shutil
        
        MODELS_DIR = Path(__file__).parent.parent.parent.parent / "models"
        BACKUP_DIR = MODELS_DIR / "backups" / datetime.now().strftime("%Y%m%d")
        
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        
        backed_up = 0
        for model_file in MODELS_DIR.glob("*_v5.pkl"):
            shutil.copy(model_file, BACKUP_DIR / model_file.name)
            backed_up += 1
        
        logger.info(f"Backed up {backed_up} model files to {BACKUP_DIR}")
        
        return {
            "status": "success",
            "backup_dir": str(BACKUP_DIR),
            "files_backed_up": backed_up
        }
        
    except Exception as e:
        logger.error(f"Model backup failed: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task
def health_check():
    """System health check task"""
    logger.info("Running health check")
    
    checks = {
        "database": False,
        "redis": False,
        "models": False,
        "data": False
    }
    
    try:
        # Check models
        MODELS_DIR = Path(__file__).parent.parent.parent.parent / "models"
        checks["models"] = any(MODELS_DIR.glob("*_v5.pkl"))
        
        # Check data
        DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
        checks["data"] = (DATA_DIR / "extended_dataset_v2.csv").exists()
        
        # Check Redis (if we got here, Celery/Redis is working)
        checks["redis"] = True
        
        # Check database
        try:
            from app.database import engine
            with engine.connect() as conn:
                conn.execute("SELECT 1")
            checks["database"] = True
        except Exception:
            pass
        
        all_healthy = all(checks.values())
        
        return {
            "status": "healthy" if all_healthy else "degraded",
            "checks": checks,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {"status": "error", "message": str(e)}

