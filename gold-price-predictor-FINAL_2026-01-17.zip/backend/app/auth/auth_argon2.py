# /home/ubuntu/gold-price-predictor/auth_argon2.py
"""
نظام المصادقة المحسّن باستخدام Argon2
Authentication System with Argon2 Password Hashing
"""

from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from pydantic import BaseModel
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

# إعدادات JWT
SECRET_KEY = "your-secret-key-change-this-in-production-use-env-variable"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Argon2 Password Hasher
ph = PasswordHasher()


class Token(BaseModel):
    """نموذج Token"""
    access_token: str
    refresh_token: str
    token_type: str


class TokenData(BaseModel):
    """بيانات Token"""
    username: Optional[str] = None


class User(BaseModel):
    """نموذج المستخدم"""
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    disabled: Optional[bool] = None


class UserInDB(User):
    """المستخدم في قاعدة البيانات"""
    hashed_password: str


# قاعدة بيانات مؤقتة للمستخدمين (يجب استبدالها بقاعدة بيانات حقيقية)
# كلمات المرور المشفرة بـ Argon2
fake_users_db = {
    "admin": {
        "username": "admin",
        "full_name": "System Administrator",
        "email": "admin@example.com",
        "hashed_password": ph.hash("admin123"),  # كلمة المرور: admin123
        "disabled": False,
    },
    "user": {
        "username": "user",
        "full_name": "Regular User",
        "email": "user@example.com",
        "hashed_password": ph.hash("user123"),  # كلمة المرور: user123
        "disabled": False,
    }
}


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    التحقق من كلمة المرور باستخدام Argon2

    Args:
        plain_password: كلمة المرور النصية
        hashed_password: كلمة المرور المشفرة

    Returns:
        bool: True إذا كانت كلمة المرور صحيحة
    """
    try:
        ph.verify(hashed_password, plain_password)

        # إعادة تشفير كلمة المرور إذا كانت المعايير قد تغيرت
        if ph.check_needs_rehash(hashed_password):
            # في بيئة production، يجب تحديث كلمة المرور في قاعدة البيانات
            pass

        return True
    except VerifyMismatchError:
        return False


def get_password_hash(password: str) -> str:
    """
    تشفير كلمة المرور باستخدام Argon2

    Args:
        password: كلمة المرور النصية

    Returns:
        str: كلمة المرور المشفرة
    """
    return ph.hash(password)


def get_user(db, username: str):
    """
    الحصول على معلومات المستخدم من قاعدة البيانات

    Args:
        db: قاعدة البيانات
        username: اسم المستخدم

    Returns:
        UserInDB: معلومات المستخدم
    """
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)


def authenticate_user(fake_db, username: str, password: str):
    """
    مصادقة المستخدم

    Args:
        fake_db: قاعدة البيانات المؤقتة
        username: اسم المستخدم
        password: كلمة المرور

    Returns:
        UserInDB: معلومات المستخدم إذا نجحت المصادقة
    """
    user = get_user(fake_db, username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """
    إنشاء Access Token

    Args:
        data: البيانات المراد تشفيرها
        expires_delta: مدة صلاحية Token

    Returns:
        str: Access Token
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict):
    """
    إنشاء Refresh Token

    Args:
        data: البيانات المراد تشفيرها

    Returns:
        str: Refresh Token
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    الحصول على المستخدم الحالي من Token

    Args:
        token: JWT Token

    Returns:
        User: معلومات المستخدم

    Raises:
        HTTPException: إذا فشلت المصادقة
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError as exc:
        raise credentials_exception from exc
    user = get_user(fake_users_db, username=token_data.username)
    if user is None:
        raise credentials_exception
    return user


async def get_current_active_user(current_user: User = Depends(get_current_user)):
    """
    الحصول على المستخدم النشط الحالي

    Args:
        current_user: المستخدم الحالي

    Returns:
        User: معلومات المستخدم

    Raises:
        HTTPException: إذا كان المستخدم معطل
    """
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user
