# File: /home/ubuntu/gold-price-predictor/auth_2fa.py
"""
Two-Factor Authentication (2FA) System
Provides TOTP-based 2FA for enhanced security
"""

import base64
from io import BytesIO
from typing import Tuple
import pyotp
import qrcode
from sqlalchemy.orm import Session
from app.database_enhanced import User


class TwoFactorAuth:
    """Handle Two-Factor Authentication operations"""

    @staticmethod
    def generate_secret() -> str:
        """Generate a new TOTP secret"""
        return pyotp.random_base32()

    @staticmethod
    def generate_qr_code(user_email: str, secret: str, issuer: str = "Gold Predictor") -> str:
        """
        Generate QR code for 2FA setup

        Args:
            user_email: User's email address
            secret: TOTP secret
            issuer: Application name

        Returns:
            Base64-encoded QR code image
        """
        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(name=user_email, issuer_name=issuer)

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(uri)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)

        return base64.b64encode(buffer.getvalue()).decode()

    @staticmethod
    def verify_token(secret: str, token: str, window: int = 1) -> bool:
        """
        Verify TOTP token

        Args:
            secret: TOTP secret
            token: User-provided token
            window: Time window for verification (default: 1 = 30 seconds)

        Returns:
            True if token is valid, False otherwise
        """
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=window)

    @staticmethod
    def enable_2fa(db: Session, user_id: int) -> Tuple[str, str]:
        """
        Enable 2FA for a user

        Args:
            db: Database session
            user_id: User ID

        Returns:
            Tuple of (secret, qr_code_base64)
        """
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise ValueError("User not found")

        secret = TwoFactorAuth.generate_secret()
        qr_code = TwoFactorAuth.generate_qr_code(user.email, secret)

        # Store secret in database (encrypted in production)
        user.totp_secret = secret
        user.is_2fa_enabled = False  # Will be enabled after verification
        db.commit()

        return secret, qr_code

    @staticmethod
    def confirm_2fa(db: Session, user_id: int, token: str) -> bool:
        """
        Confirm 2FA setup by verifying the first token

        Args:
            db: Database session
            user_id: User ID
            token: User-provided token

        Returns:
            True if token is valid and 2FA is enabled, False otherwise
        """
        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.totp_secret:
            return False

        if TwoFactorAuth.verify_token(user.totp_secret, token):
            user.is_2fa_enabled = True
            db.commit()
            return True

        return False

    @staticmethod
    def disable_2fa(db: Session, user_id: int, token: str) -> bool:
        """
        Disable 2FA for a user

        Args:
            db: Database session
            user_id: User ID
            token: User-provided token for verification

        Returns:
            True if 2FA is disabled, False otherwise
        """
        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.is_2fa_enabled:
            return False

        if TwoFactorAuth.verify_token(user.totp_secret, token):
            user.is_2fa_enabled = False
            user.totp_secret = None
            db.commit()
            return True

        return False
