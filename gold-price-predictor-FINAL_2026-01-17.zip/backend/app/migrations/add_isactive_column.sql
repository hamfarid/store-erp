-- FILE: backend/app/migrations/add_isactive_column.sql | PURPOSE: Add isActive column to assets table | OWNER: Database Team | RELATED: drizzle/schema.ts | LAST-AUDITED: 2025-11-26

-- Migration: Add isActive column to assets table
-- Date: 2025-11-26
-- Description: Adds isActive boolean column to track active/inactive assets
-- This column was missing in PostgreSQL but exists in SQLite schema

-- Check if column exists first (PostgreSQL specific)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'assets'
        AND column_name = 'isActive'
    ) THEN
        -- Add isActive column with default value true
        ALTER TABLE assets
        ADD COLUMN "isActive" BOOLEAN DEFAULT true NOT NULL;

        -- Add comment for documentation
        COMMENT ON COLUMN assets."isActive" IS 'Indicates if the asset is active for trading/predictions';

        -- Create index for performance
        CREATE INDEX IF NOT EXISTS idx_assets_isactive ON assets("isActive");

        RAISE NOTICE 'Column "isActive" added successfully to assets table';
    ELSE
        RAISE NOTICE 'Column "isActive" already exists in assets table';
    END IF;
END $$;

-- Update existing records to be active by default
UPDATE assets SET "isActive" = true WHERE "isActive" IS NULL;

-- Verify migration
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'assets' AND column_name = 'isActive';
