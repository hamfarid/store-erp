# Database Migration Guide

## Overview

This project uses **Alembic** for database schema migrations. Alembic allows you to:
- Track database schema changes over time
- Apply incremental updates to the database
- Rollback changes if needed
- Maintain consistency across environments

## Setup

### Prerequisites

```bash
pip install alembic sqlalchemy psycopg2-binary
```

### Configuration

Database connection is configured via environment variables:

```bash
export DB_USER=postgres
export DB_PASSWORD=your_password
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=gold_predictor
```

## Common Commands

### 1. Create a New Migration

After modifying your models in `database_enhanced.py`:

```bash
# Auto-generate migration from model changes
alembic revision --autogenerate -m "Description of changes"

# Example:
alembic revision --autogenerate -m "Add user_preferences table"
```

### 2. Apply Migrations

```bash
# Upgrade to the latest version
alembic upgrade head

# Upgrade to a specific revision
alembic upgrade <revision_id>

# Upgrade one version forward
alembic upgrade +1
```

### 3. Rollback Migrations

```bash
# Downgrade to previous version
alembic downgrade -1

# Downgrade to a specific revision
alembic downgrade <revision_id>

# Downgrade to base (empty database)
alembic downgrade base
```

### 4. View Migration History

```bash
# Show current revision
alembic current

# Show migration history
alembic history

# Show detailed history with SQL
alembic history --verbose
```

### 5. Create Manual Migration

For complex changes that can't be auto-generated:

```bash
# Create empty migration file
alembic revision -m "Custom migration description"

# Edit the generated file in alembic/versions/
# Add your custom upgrade() and downgrade() logic
```

## Migration File Structure

Each migration file contains:

```python
"""Description of migration

Revision ID: abc123
Revises: xyz789
Create Date: 2025-01-15 10:30:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = 'abc123'
down_revision = 'xyz789'
branch_labels = None
depends_on = None

def upgrade():
    # Commands to apply the migration
    op.create_table(
        'new_table',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

def downgrade():
    # Commands to rollback the migration
    op.drop_table('new_table')
```

## Best Practices

### 1. Always Review Auto-Generated Migrations

Auto-generated migrations may not capture all changes correctly. Always review:

```bash
# After creating migration
cat alembic/versions/<revision_id>_description.py
```

### 2. Test Migrations Before Production

```bash
# Test upgrade
alembic upgrade head

# Test downgrade
alembic downgrade -1

# Test upgrade again
alembic upgrade head
```

### 3. Backup Before Migration

```bash
# PostgreSQL backup
pg_dump -U postgres gold_predictor > backup_$(date +%Y%m%d_%H%M%S).sql
```

### 4. Use Descriptive Messages

```bash
# Good
alembic revision --autogenerate -m "Add email_verified column to users table"

# Bad
alembic revision --autogenerate -m "Update"
```

### 5. Keep Migrations Small

- One logical change per migration
- Easier to review and rollback
- Better version control

## Common Scenarios

### Adding a New Column

1. Update model in `database_enhanced.py`:

```python
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    email_verified = Column(Boolean, default=False)  # New column
```

2. Generate migration:

```bash
alembic revision --autogenerate -m "Add email_verified to users"
```

3. Review and apply:

```bash
cat alembic/versions/*_add_email_verified_to_users.py
alembic upgrade head
```

### Adding an Index

1. Update model:

```python
class Prediction(Base):
    __tablename__ = 'predictions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)  # Add index
    created_at = Column(DateTime, default=datetime.utcnow, index=True)  # Add index
```

2. Generate and apply:

```bash
alembic revision --autogenerate -m "Add indexes to predictions table"
alembic upgrade head
```

### Data Migration

For migrations that modify data (not just schema):

```bash
alembic revision -m "Migrate old user data format"
```

Edit the migration file:

```python
def upgrade():
    # Get connection
    conn = op.get_bind()
    
    # Execute data migration
    conn.execute(
        sa.text("UPDATE users SET status = 'active' WHERE status IS NULL")
    )

def downgrade():
    # Reverse data migration if possible
    conn = op.get_bind()
    conn.execute(
        sa.text("UPDATE users SET status = NULL WHERE status = 'active'")
    )
```

## Troubleshooting

### Migration Conflicts

If you get "multiple heads" error:

```bash
# Show all heads
alembic heads

# Merge heads
alembic merge -m "Merge migrations" <head1> <head2>
```

### Reset Migration History

**⚠️ WARNING: This will delete all data!**

```bash
# Drop all tables
alembic downgrade base

# Re-apply all migrations
alembic upgrade head
```

### Stamp Database

If database is already at desired state but Alembic doesn't know:

```bash
# Mark database as being at specific revision
alembic stamp head
```

## Production Deployment

### Pre-Deployment Checklist

- [ ] Backup production database
- [ ] Test migrations on staging environment
- [ ] Review all migration files
- [ ] Ensure rollback plan is ready
- [ ] Schedule maintenance window if needed

### Deployment Steps

```bash
# 1. Backup
pg_dump -U postgres gold_predictor > backup_before_migration.sql

# 2. Apply migrations
alembic upgrade head

# 3. Verify
alembic current
psql -U postgres -d gold_predictor -c "\dt"  # List tables

# 4. If issues, rollback
alembic downgrade -1
```

## Integration with CI/CD

### GitHub Actions Example

```yaml
- name: Run Database Migrations
  run: |
    cd backend/app
    alembic upgrade head
  env:
    DB_USER: ${{ secrets.DB_USER }}
    DB_PASSWORD: ${{ secrets.DB_PASSWORD }}
    DB_HOST: ${{ secrets.DB_HOST }}
    DB_PORT: 5432
    DB_NAME: gold_predictor
```

## References

- [Alembic Documentation](https://alembic.sqlalchemy.org/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

