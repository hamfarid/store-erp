# FILE: backend/app/api_v2.py | PURPOSE: Secure API v2 | OWNER: Backend | LAST-AUDITED: 2026-01-02
"""
Secure API v2 with Repository Pattern and Service Layer
Improved architecture with separation of concerns
"""

from fastapi import FastAPI, HTTPException, Depends, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator
from datetime import datetime
import logging
from logging.handlers import RotatingFileHandler
import os

# Import security modules
from config import settings
from auth_simple import (
    authenticate_user, create_access_token, create_refresh_token,
    get_current_active_user, require_scope, Token, User
)
from rate_limiter import check_rate_limit

# Import business logic
from repositories.model_repository import ModelRepository
from services.prediction_service import PredictionService

# Setup logging
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        RotatingFileHandler(
            settings.LOG_FILE,
            maxBytes=10485760,  # 10MB
            backupCount=5
        ),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title=settings.API_TITLE,
    version="2.0.0",
    description=settings.API_DESCRIPTION + " (v2 with Repository Pattern)",
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.all_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
    max_age=600
)

# Asset symbols mapping
ASSET_SYMBOLS = {
    1: "GC=F", 2: "SI=F", 3: "CL=F", 4: "BZ=F",
    5: "PL=F", 6: "PA=F", 7: "HG=F", 8: "NG=F",
    9: "BTC-USD", 10: "ETH-USD", 11: "TRY=X", 12: "EGP=X",
    13: "EUR=X", 14: "DX-Y.NYB", 15: "SAR=X", 16: "AED=X", 17: "OMR=X"
}

SYMBOL_TO_NAME = {
    "GC=F": "Gold", "SI=F": "Silver", "BTC-USD": "Bitcoin",
    "ETH-USD": "Ethereum", "TRY=X": "TRY_USD", "EGP=X": "EGP_USD"
}

# Initialize services
model_repo = ModelRepository()
prediction_service = PredictionService()

logger.info(f"Loaded {len(model_repo.list_models())} models")


# Pydantic models
class LoginRequest(BaseModel):
    """Login request model"""
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=6)


class PredictionRequest(BaseModel):
    """Prediction request with validation"""
    symbol: str = Field(..., description="Asset symbol (e.g., GC=F, BTC-USD)")
    horizon: str = Field(..., description="Prediction horizon: short, medium, or long")
    confidenceLevel: float = Field(0.95, ge=0.5, le=0.99)

    @field_validator('symbol')
    @classmethod
    def validate_symbol(cls, v):
        valid_symbols = list(ASSET_SYMBOLS.values())
        if v not in valid_symbols:
            raise ValueError(f"Symbol must be one of: {', '.join(valid_symbols)}")
        return v

    @field_validator('horizon')
    @classmethod
    def validate_horizon(cls, v):
        if v not in ['short', 'medium', 'long']:
            raise ValueError("Horizon must be: short, medium, or long")
        return v


# Exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": "An unexpected error occurred" if not settings.DEBUG else str(exc)
        }
    )


# Public endpoints
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": settings.API_TITLE,
        "version": "2.0.0",
        "status": "running",
        "supported_assets": len(ASSET_SYMBOLS),
        "available_models": len(model_repo.list_models()),
        "architecture": "Repository Pattern + Service Layer"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "models_loaded": len(model_repo.list_models()),
        "environment": settings.ENVIRONMENT
    }


# Authentication endpoints
@app.post("/auth/login", response_model=Token)
async def login(login_data: LoginRequest):
    """Login endpoint"""
    user = authenticate_user(login_data.username, login_data.password)
    if not user:
        logger.warning(f"Failed login attempt for user: {login_data.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token = create_access_token(
        data={"sub": user.username, "user_id": user.id, "scopes": user.scopes}
    )
    refresh_token = create_refresh_token(
        data={"sub": user.username, "user_id": user.id}
    )

    logger.info(f"User logged in: {user.username}")
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }


# Protected endpoints
@app.get("/assets")
async def get_assets(
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    """Get list of supported assets"""
    assets = []
    for asset_id, symbol in ASSET_SYMBOLS.items():
        asset_name = SYMBOL_TO_NAME.get(symbol, symbol)
        assets.append({
            "id": asset_id,
            "symbol": symbol,
            "name": asset_name,
            "model_available": model_repo.model_exists(asset_name)
        })
    return {"assets": assets, "total": len(assets)}


@app.get("/models")
async def get_models(
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    """Get list of available models"""
    models = []
    all_info = model_repo.get_all_model_info()
    for name, info in all_info.items():
        models.append({
            "name": name,
            "accuracy": round(info.test_r2 * 100, 2),
            "type": info.model_type,
            "mae": round(info.test_mae, 2),
            "rmse": round(info.test_rmse, 2)
        })
    return {"models": models, "total": len(models)}


@app.post("/predict")
async def predict(
    request: PredictionRequest,
    current_user: User = Depends(require_scope("read")),
    _: None = Depends(check_rate_limit)
):
    """Make prediction (requires authentication and read scope)"""
    try:
        # Get asset name
        asset_name = SYMBOL_TO_NAME.get(
            request.symbol,
            request.symbol.replace("=F", "").replace("-USD", "")
        )

        # Make prediction using service
        result = prediction_service.predict(
            symbol=request.symbol,
            asset_name=asset_name,
            horizon=request.horizon,
            confidence_level=request.confidenceLevel
        )

        if result is None:
            raise HTTPException(
                status_code=404,
                detail=f"Could not make prediction for {request.symbol}"
            )

        logger.info(f"Prediction made by {current_user.username} for {request.symbol}")

        # Convert dataclass to dict
        return {
            "symbol": result.symbol,
            "asset_name": result.asset_name,
            "horizon": result.horizon,
            "horizon_days": result.horizon_days,
            "model_used": result.model_used,
            "current_price": result.current_price,
            "predicted_price": result.predicted_price,
            "change": result.change,
            "change_percent": result.change_percent,
            "confidence_level": result.confidence_level,
            "confidence_interval": result.confidence_interval,
            "model_accuracy": result.model_accuracy,
            "timestamp": result.timestamp
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Prediction error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api_v2:app",
        host="0.0.0.0",
        port=2005,
        reload=settings.DEBUG
    )
