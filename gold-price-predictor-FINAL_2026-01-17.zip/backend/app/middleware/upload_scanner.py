
from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware
import logging

# python-magic is known to hang on Windows if binaries are missing/mismatched.
# Disabling it to prevent server startup lockup.
magic = None
try:
    # import magic
    # MAGIC_AVAILABLE = True
    raise ImportError("Manually disabled")
except ImportError:
    MAGIC_AVAILABLE = False
    magic = None
except Exception:
    MAGIC_AVAILABLE = False
    magic = None

logger = logging.getLogger(__name__)


class UploadScannerMiddleware(BaseHTTPMiddleware):
    """
    Middleware to scan and validate file uploads
    """
    def __init__(self, app, allowed_extensions: set = None, max_size_mb: int = 10):
        super().__init__(app)
        self.allowed_extensions = allowed_extensions or {'jpg', 'jpeg', 'png', 'pdf', 'csv', 'json'}
        self.max_size = max_size_mb * 1024 * 1024

    async def dispatch(self, request: Request, call_next):
        if request.method == "POST" and "multipart/form-data" in request.headers.get("content-type", ""):
            # Note: Deep inspection of multipart body in middleware is complex in Starlette/FastAPI
            # because checking the stream consumes it.
            # For this implementation, we will perform header-based validation
            # and rely on endpoint-level validation for content inspection if needed,
            # or use a library that supports re-playable streams if deep scanning is strictly required here.

            # Content-Length check
            content_length = request.headers.get('content-length')
            if content_length and int(content_length) > self.max_size:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"File too large. Maximum size allowed is {self.max_size // (1024 * 1024)}MB"
                )

        response = await call_next(request)
        return response

    @staticmethod
    def validate_file_content(content: bytes, filename: str) -> bool:
        """
        Validate file content using magic numbers
        Should be called from the endpoint after reading the file
        """
        if not MAGIC_AVAILABLE or magic is None:
            logger.warning("Magic not available, skipping content validation")
            return True

        try:
            mime = magic.Magic(mime=True)
            file_mime = mime.from_buffer(content[:2048])

            # Basic mapping of extension to expected MIME types
            ext = filename.split('.')[-1].lower() if '.' in filename else ''

            valid_mimes = {
                'jpg': ['image/jpeg'],
                'jpeg': ['image/jpeg'],
                'png': ['image/png'],
                'pdf': ['application/pdf'],
                'csv': ['text/csv', 'text/plain'],
                'json': ['application/json', 'text/plain']
            }

            if ext in valid_mimes:
                if file_mime not in valid_mimes[ext]:
                    logger.warning(f"MIME type mismatch for {filename}: expected {valid_mimes[ext]}, got {file_mime}")
                    return False
        except Exception as e:
            logger.error(f"Error during file content validation: {e}")
            # Fail open or closed? Closed is safer, but let's log and pass for now to avoid blocking legitimate users if magic fails
            return True

        return True
