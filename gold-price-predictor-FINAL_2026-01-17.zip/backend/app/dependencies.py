# FILE: backend/app/dependencies.py | PURPOSE: FastAPI dependencies to avoid circular imports | OWNER: Backend Team | RELATED: main.py, auth_postgresql.py | LAST-AUDITED: 2025-01-18

"""
FastAPI Dependencies
Centralized location for dependencies to avoid circular imports between main.py and routers
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database_enhanced import User, get_db
from app.auth_postgresql import get_current_user


# OAuth2
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_user_dep(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """
    Dependency wrapper for get_current_user to make it compatible with FastAPI

    This wrapper:
    - Uses Depends() for proper FastAPI dependency injection
    - Extracts token from OAuth2PasswordBearer
    - Gets database session from get_db
    - Calls the actual get_current_user(token, db) function
    - Raises HTTP 401 if authentication fails

    Used in all protected endpoints via: `current_user = Depends(get_current_user_dep)`
    """
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user
