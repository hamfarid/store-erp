#!/usr/bin/env python3
# FILE: backend/app/main_extended.py | PURPOSE: Extended main entry point | OWNER: Backend | LAST-AUDITED: 2026-01-02
"""
الملف الرئيسي لتشغيل برنامج توقع أسعار الأصول المالية (النسخة الموسعة)
يدعم: الذهب، Bitcoin، Ethereum، TRY/USD، EGP/USD
"""

import sys
from pathlib import Path

# إضافة المسار الجذر للمشروع
ROOT_DIR = Path(__file__).parent
sys.path.append(str(ROOT_DIR))

from gui.main_window_extended import main  # noqa: E402

if __name__ == '__main__':
    print("=" * 60)
    print("برنامج توقع أسعار الأصول المالية - النسخة الموسعة")
    print("Multi-Asset Price Predictor v2.0")
    print("=" * 60)
    print("\nجاري تشغيل الواجهة الرسومية...")
    print("Starting GUI...\n")

    main()
