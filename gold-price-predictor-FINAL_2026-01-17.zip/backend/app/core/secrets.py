"""
AWS Secrets Manager Integration

This module provides a centralized interface for retrieving secrets
from AWS Secrets Manager, with caching and error handling.

Classes:
    SecretsManager: Main secrets management class

Functions:
    get_secret: Retrieve a secret by name

Example:
    >>> from backend.app.core.secrets import secrets
    >>> db_config = secrets.get_secret('gold-predictor/database')
    >>> print(db_config['host'])
    'localhost'
"""

import json
import logging
from functools import lru_cache
from typing import Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class SecretsManager:
    """
    AWS Secrets Manager client wrapper with caching and error handling.
    
    This class provides a simple interface to retrieve secrets from AWS
    Secrets Manager with automatic caching to reduce API calls and costs.
    
    Attributes:
        region_name: AWS region where secrets are stored
        client: boto3 Secrets Manager client
    
    Example:
        >>> manager = SecretsManager(region_name='us-east-1')
        >>> secret = manager.get_secret('my-app/database')
        >>> print(secret['password'])
    """
    
    def __init__(self, region_name: str = 'us-east-1'):
        """
        Initialize Secrets Manager client.
        
        Args:
            region_name: AWS region name. Defaults to 'us-east-1'.
        """
        self.region_name = region_name
        self.client = boto3.client(
            'secretsmanager',
            region_name=region_name
        )
        logger.info(f"Initialized SecretsManager for region: {region_name}")
    
    @lru_cache(maxsize=32)
    def get_secret(self, secret_name: str) -> Dict[str, Any]:
        """
        Retrieve a secret from AWS Secrets Manager.
        
        This method uses LRU caching to avoid repeated API calls for the
        same secret. Cache is cleared when the application restarts.
        
        Args:
            secret_name: The name or ARN of the secret to retrieve
        
        Returns:
            Dictionary containing the secret data
        
        Raises:
            ClientError: If the secret cannot be retrieved
            ValueError: If the secret value is not valid JSON
        
        Example:
            >>> secret = manager.get_secret('gold-predictor/database')
            >>> print(secret['host'])
            'db.example.com'
        """
        try:
            logger.info(f"Retrieving secret: {secret_name}")
            response = self.client.get_secret_value(SecretId=secret_name)
            
            # Parse secret string as JSON
            secret_string = response['SecretString']
            secret_data = json.loads(secret_string)
            
            logger.info(f"Successfully retrieved secret: {secret_name}")
            return secret_data
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            
            if error_code == 'ResourceNotFoundException':
                logger.error(f"Secret not found: {secret_name}")
                raise ValueError(f"Secret '{secret_name}' does not exist")
            
            elif error_code == 'InvalidRequestException':
                logger.error(f"Invalid request for secret: {secret_name}")
                raise ValueError(f"Invalid request for secret '{secret_name}'")
            
            elif error_code == 'InvalidParameterException':
                logger.error(f"Invalid parameter for secret: {secret_name}")
                raise ValueError(f"Invalid parameter for secret '{secret_name}'")
            
            elif error_code == 'DecryptionFailure':
                logger.error(f"Decryption failed for secret: {secret_name}")
                raise RuntimeError(f"Cannot decrypt secret '{secret_name}'")
            
            elif error_code == 'InternalServiceError':
                logger.error(f"AWS service error for secret: {secret_name}")
                raise RuntimeError(f"AWS service error retrieving secret '{secret_name}'")
            
            else:
                logger.error(f"Unknown error retrieving secret: {secret_name}")
                raise
        
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in secret: {secret_name}")
            raise ValueError(f"Secret '{secret_name}' contains invalid JSON: {e}")
    
    def clear_cache(self):
        """
        Clear the secrets cache.
        
        This forces all subsequent get_secret calls to fetch fresh data
        from AWS Secrets Manager.
        
        Example:
            >>> manager.clear_cache()
            >>> secret = manager.get_secret('my-app/database')  # Fresh fetch
        """
        self.get_secret.cache_clear()
        logger.info("Secrets cache cleared")


# Global secrets manager instance
secrets = SecretsManager()


def get_secret(secret_name: str) -> Dict[str, Any]:
    """
    Convenience function to retrieve a secret.
    
    This is a shorthand for secrets.get_secret(secret_name).
    
    Args:
        secret_name: The name or ARN of the secret to retrieve
    
    Returns:
        Dictionary containing the secret data
    
    Example:
        >>> from backend.app.core.secrets import get_secret
        >>> db_config = get_secret('gold-predictor/database')
        >>> print(db_config['password'])
    """
    return secrets.get_secret(secret_name)

