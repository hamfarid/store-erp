"""
Redis Cluster Module with High Availability

This module provides Redis connection management with cluster support,
response caching, and session management.

Features:
- Redis cluster support
- Connection pooling
- Response caching with TTL
- Session management
- Automatic failover

Classes:
    RedisManager: Main Redis management class
    CacheManager: Response caching manager

Functions:
    get_redis: Get Redis client
    cache_response: Decorator for caching responses

Example:
    >>> from backend.app.core.redis import get_redis, cache_response
    >>> 
    >>> # Get Redis client
    >>> redis = await get_redis()
    >>> await redis.set("key", "value", ex=3600)
    >>> 
    >>> # Cache responses
    >>> @cache_response(ttl=300)
    >>> async def get_predictions():
    ...     return {"predictions": [...]}
"""

import json
import hashlib
from typing import Any, Optional, Callable
from functools import wraps
import redis.asyncio as redis
from redis.asyncio.cluster import RedisCluster
from redis.asyncio.connection import ConnectionPool
import logging

from .config import settings

logger = logging.getLogger(__name__)


class RedisManager:
    """
    Redis connection manager with cluster support.
    
    This class manages connections to Redis (standalone or cluster mode),
    providing connection pooling and automatic failover capabilities.
    
    Attributes:
        client: Redis client (standalone or cluster)
        is_cluster: Whether Redis is running in cluster mode
    
    Example:
        >>> manager = RedisManager()
        >>> await manager.initialize()
        >>> await manager.set("key", "value", ex=3600)
    """
    
    def __init__(self):
        """Initialize Redis manager."""
        self.client: Optional[redis.Redis | RedisCluster] = None
        self.is_cluster = False
        self._initialized = False
    
    async def initialize(self):
        """
        Initialize Redis connection.
        
        This method creates a connection pool and establishes connection
        to Redis (standalone or cluster mode based on configuration).
        """
        if self._initialized:
            logger.warning("RedisManager already initialized")
            return
        
        try:
            # Check if cluster mode is enabled
            if settings.REDIS_CLUSTER_ENABLED:
                # Redis Cluster mode
                self.client = RedisCluster(
                    host=settings.REDIS_HOST,
                    port=settings.REDIS_PORT,
                    password=settings.REDIS_PASSWORD,
                    decode_responses=True,
                    skip_full_coverage_check=True,
                    max_connections=50,
                    socket_connect_timeout=5,
                    socket_timeout=5,
                )
                self.is_cluster = True
                logger.info("Initialized Redis cluster connection")
            else:
                # Standalone Redis mode
                pool = ConnectionPool(
                    host=settings.REDIS_HOST,
                    port=settings.REDIS_PORT,
                    password=settings.REDIS_PASSWORD,
                    db=settings.REDIS_DB,
                    decode_responses=True,
                    max_connections=50,
                    socket_connect_timeout=5,
                    socket_timeout=5,
                )
                
                self.client = redis.Redis(connection_pool=pool)
                logger.info("Initialized Redis standalone connection")
            
            # Test connection
            await self.client.ping()
            logger.info("Redis connection test successful")
            
            self._initialized = True
        
        except Exception as e:
            logger.error(f"Failed to initialize Redis: {e}")
            self.client = None
            raise
    
    async def close(self):
        """Close Redis connection."""
        if self.client:
            await self.client.close()
            logger.info("Closed Redis connection")
            self._initialized = False
    
    async def get(self, key: str) -> Optional[str]:
        """
        Get value from Redis.
        
        Args:
            key: Redis key
        
        Returns:
            Value if key exists, None otherwise
        """
        if not self._initialized:
            raise RuntimeError("RedisManager not initialized")
        
        try:
            return await self.client.get(key)
        except Exception as e:
            logger.error(f"Redis GET error for key '{key}': {e}")
            return None
    
    async def set(self, key: str, value: str, ex: Optional[int] = None) -> bool:
        """
        Set value in Redis.
        
        Args:
            key: Redis key
            value: Value to store
            ex: Expiration time in seconds (optional)
        
        Returns:
            True if successful, False otherwise
        """
        if not self._initialized:
            raise RuntimeError("RedisManager not initialized")
        
        try:
            await self.client.set(key, value, ex=ex)
            return True
        except Exception as e:
            logger.error(f"Redis SET error for key '{key}': {e}")
            return False
    
    async def delete(self, *keys: str) -> int:
        """
        Delete keys from Redis.
        
        Args:
            *keys: Keys to delete
        
        Returns:
            Number of keys deleted
        """
        if not self._initialized:
            raise RuntimeError("RedisManager not initialized")
        
        try:
            return await self.client.delete(*keys)
        except Exception as e:
            logger.error(f"Redis DELETE error: {e}")
            return 0
    
    async def exists(self, *keys: str) -> int:
        """
        Check if keys exist in Redis.
        
        Args:
            *keys: Keys to check
        
        Returns:
            Number of existing keys
        """
        if not self._initialized:
            raise RuntimeError("RedisManager not initialized")
        
        try:
            return await self.client.exists(*keys)
        except Exception as e:
            logger.error(f"Redis EXISTS error: {e}")
            return 0
    
    async def expire(self, key: str, seconds: int) -> bool:
        """
        Set expiration time for a key.
        
        Args:
            key: Redis key
            seconds: Expiration time in seconds
        
        Returns:
            True if successful, False otherwise
        """
        if not self._initialized:
            raise RuntimeError("RedisManager not initialized")
        
        try:
            return await self.client.expire(key, seconds)
        except Exception as e:
            logger.error(f"Redis EXPIRE error for key '{key}': {e}")
            return False


class CacheManager:
    """
    Response caching manager.
    
    This class provides high-level caching functionality for API responses,
    including automatic cache key generation and TTL management.
    
    Example:
        >>> cache = CacheManager(redis_manager)
        >>> 
        >>> # Cache a response
        >>> await cache.set_response("predictions", {"data": [...]}, ttl=300)
        >>> 
        >>> # Get cached response
        >>> cached = await cache.get_response("predictions")
    """
    
    def __init__(self, redis_manager: RedisManager):
        """
        Initialize cache manager.
        
        Args:
            redis_manager: RedisManager instance
        """
        self.redis = redis_manager
    
    def _generate_cache_key(self, prefix: str, *args, **kwargs) -> str:
        """
        Generate cache key from prefix and parameters.
        
        Args:
            prefix: Cache key prefix
            *args: Positional arguments
            **kwargs: Keyword arguments
        
        Returns:
            Generated cache key
        """
        # Create a deterministic string from args and kwargs
        key_data = f"{prefix}:{args}:{sorted(kwargs.items())}"
        
        # Hash for shorter keys
        key_hash = hashlib.md5(key_data.encode()).hexdigest()
        
        return f"cache:{prefix}:{key_hash}"
    
    async def get_response(self, cache_key: str) -> Optional[dict]:
        """
        Get cached response.
        
        Args:
            cache_key: Cache key
        
        Returns:
            Cached response if exists, None otherwise
        """
        try:
            cached = await self.redis.get(cache_key)
            if cached:
                return json.loads(cached)
            return None
        except Exception as e:
            logger.error(f"Cache GET error: {e}")
            return None
    
    async def set_response(self, cache_key: str, data: dict, ttl: int = 300) -> bool:
        """
        Cache a response.
        
        Args:
            cache_key: Cache key
            data: Data to cache
            ttl: Time to live in seconds (default: 5 minutes)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            serialized = json.dumps(data)
            return await self.redis.set(cache_key, serialized, ex=ttl)
        except Exception as e:
            logger.error(f"Cache SET error: {e}")
            return False
    
    async def invalidate(self, pattern: str) -> int:
        """
        Invalidate cached responses matching a pattern.
        
        Args:
            pattern: Key pattern (e.g., "cache:predictions:*")
        
        Returns:
            Number of keys deleted
        """
        try:
            # Get all matching keys
            keys = []
            async for key in self.redis.client.scan_iter(match=pattern):
                keys.append(key)
            
            if keys:
                return await self.redis.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Cache invalidation error: {e}")
            return 0


# Global Redis manager instance
redis_manager = RedisManager()
cache_manager = CacheManager(redis_manager)


async def get_redis() -> RedisManager:
    """
    Get Redis manager instance.
    
    Returns:
        RedisManager instance
    
    Example:
        >>> redis = await get_redis()
        >>> await redis.set("key", "value", ex=3600)
    """
    if not redis_manager._initialized:
        await redis_manager.initialize()
    
    return redis_manager


def cache_response(ttl: int = 300, key_prefix: str = "api"):
    """
    Decorator for caching API responses.
    
    This decorator automatically caches function return values in Redis
    with the specified TTL. Cache keys are generated from function name
    and arguments.
    
    Args:
        ttl: Time to live in seconds (default: 5 minutes)
        key_prefix: Cache key prefix (default: "api")
    
    Returns:
        Decorated function
    
    Example:
        >>> @cache_response(ttl=600, key_prefix="predictions")
        >>> async def get_predictions(user_id: int):
        ...     # Expensive operation
        ...     return {"predictions": [...]}
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = cache_manager._generate_cache_key(
                f"{key_prefix}:{func.__name__}",
                *args,
                **kwargs
            )
            
            # Try to get from cache
            cached = await cache_manager.get_response(cache_key)
            if cached is not None:
                logger.debug(f"Cache HIT: {cache_key}")
                return cached
            
            # Cache miss - execute function
            logger.debug(f"Cache MISS: {cache_key}")
            result = await func(*args, **kwargs)
            
            # Cache the result
            await cache_manager.set_response(cache_key, result, ttl=ttl)
            
            return result
        
        return wrapper
    return decorator


async def init_redis():
    """
    Initialize Redis connection on application startup.
    
    Example:
        >>> from fastapi import FastAPI
        >>> 
        >>> app = FastAPI()
        >>> 
        >>> @app.on_event("startup")
        >>> async def startup():
        ...     await init_redis()
    """
    await redis_manager.initialize()
    logger.info("Redis initialized successfully")


async def close_redis():
    """
    Close Redis connection on application shutdown.
    
    Example:
        >>> from fastapi import FastAPI
        >>> 
        >>> app = FastAPI()
        >>> 
        >>> @app.on_event("shutdown")
        >>> async def shutdown():
        ...     await close_redis()
    """
    await redis_manager.close()
    logger.info("Redis connection closed")

