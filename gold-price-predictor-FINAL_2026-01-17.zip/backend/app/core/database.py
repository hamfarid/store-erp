"""
Database configuration with read replica support
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from typing import Generator

# Database URLs
MASTER_DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://user:password@localhost:5432/gold_predictor"
)

# Read replicas (optional)
REPLICA_DATABASE_URLS = os.getenv("REPLICA_DATABASE_URLS", "").split(",")
REPLICA_DATABASE_URLS = [url.strip() for url in REPLICA_DATABASE_URLS if url.strip()]

# Create engines
master_engine = create_engine(
    MASTER_DATABASE_URL,
    pool_size=20,
    max_overflow=40,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

# Create replica engines if configured
replica_engines = []
if REPLICA_DATABASE_URLS:
    replica_engines = [
        create_engine(
            url,
            pool_size=20,
            max_overflow=40,
            pool_pre_ping=True,
            pool_recycle=3600,
            echo=False
        )
        for url in REPLICA_DATABASE_URLS
    ]

# Session factories
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=master_engine)

# Base class for models
Base = declarative_base()

# Round-robin replica selection
_replica_index = 0


def get_read_engine():
    """
    Get read replica engine (round-robin)
    Falls back to master if no replicas configured
    """
    global _replica_index
    
    if not replica_engines:
        return master_engine
    
    engine = replica_engines[_replica_index]
    _replica_index = (_replica_index + 1) % len(replica_engines)
    return engine


def get_write_engine():
    """Get master engine for writes"""
    return master_engine


def get_db_read() -> Generator:
    """
    Database session for read operations
    Uses read replicas if available, otherwise uses master
    """
    engine = get_read_engine()
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_db_write() -> Generator:
    """
    Database session for write operations
    Always uses master database
    """
    engine = get_write_engine()
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_db() -> Generator:
    """
    Default database session (uses master for both read and write)
    Use get_db_read() and get_db_write() for explicit read/write splitting
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database (create tables)"""
    Base.metadata.create_all(bind=master_engine)


def get_db_info():
    """Get database configuration info"""
    return {
        "master": MASTER_DATABASE_URL.split("@")[-1],  # Hide credentials
        "replicas": len(replica_engines),
        "replica_urls": [url.split("@")[-1] for url in REPLICA_DATABASE_URLS] if REPLICA_DATABASE_URLS else []
    }

