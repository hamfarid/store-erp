"""
Redis configuration with cluster support
"""

import os
import pickle
from typing import Any, Optional
import redis
from redis.cluster import RedisCluster

# Redis configuration
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
REDIS_CLUSTER_ENABLED = os.getenv("REDIS_CLUSTER_ENABLED", "false").lower() == "true"

# Redis cluster nodes (comma-separated)
REDIS_CLUSTER_NODES = os.getenv("REDIS_CLUSTER_NODES", "").split(",")
REDIS_CLUSTER_NODES = [node.strip() for node in REDIS_CLUSTER_NODES if node.strip()]


def create_redis_client():
    """Create Redis client (cluster or standalone)"""
    
    if REDIS_CLUSTER_ENABLED and REDIS_CLUSTER_NODES:
        # Redis Cluster mode
        startup_nodes = []
        for node in REDIS_CLUSTER_NODES:
            host, port = node.split(":")
            startup_nodes.append({"host": host, "port": int(port)})
        
        return RedisCluster(
            startup_nodes=startup_nodes,
            decode_responses=True,
            skip_full_coverage_check=True,
            max_connections=50,
            socket_timeout=5,
            socket_connect_timeout=5
        )
    else:
        # Standalone Redis
        return redis.from_url(
            REDIS_URL,
            decode_responses=True,
            max_connections=50,
            socket_timeout=5,
            socket_connect_timeout=5
        )


# Create global Redis client
redis_client = create_redis_client()


class MultiLevelCache:
    """
    Multi-level caching (L1: Memory, L2: Redis)
    """
    
    def __init__(self):
        self.memory_cache = {}  # L1: In-memory cache
        self.redis_client = redis_client  # L2: Redis cache
        self.max_memory_items = 1000  # Limit memory cache size
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Get from cache (L1 → L2 → None)
        """
        # Try L1 (memory)
        if key in self.memory_cache:
            return self.memory_cache[key]
        
        # Try L2 (Redis)
        try:
            value = self.redis_client.get(key)
            if value:
                # Deserialize and promote to L1
                deserialized_value = pickle.loads(value.encode('latin1'))
                self._set_memory(key, deserialized_value)
                return deserialized_value
        except Exception as e:
            print(f"Redis get error: {e}")
        
        return None
    
    async def set(self, key: str, value: Any, ttl: int = 300):
        """
        Set in cache (L1 + L2)
        """
        # Set in L1
        self._set_memory(key, value)
        
        # Set in L2
        try:
            serialized_value = pickle.dumps(value).decode('latin1')
            self.redis_client.setex(key, ttl, serialized_value)
        except Exception as e:
            print(f"Redis set error: {e}")
    
    def invalidate(self, key: str):
        """
        Invalidate cache entry (L1 + L2)
        """
        # Remove from L1
        self.memory_cache.pop(key, None)
        
        # Remove from L2
        try:
            self.redis_client.delete(key)
        except Exception as e:
            print(f"Redis delete error: {e}")
    
    def _set_memory(self, key: str, value: Any):
        """Set in L1 memory cache with size limit"""
        if len(self.memory_cache) >= self.max_memory_items:
            # Remove oldest item (FIFO)
            self.memory_cache.pop(next(iter(self.memory_cache)))
        
        self.memory_cache[key] = value


# Create global cache instance
cache = MultiLevelCache()


async def cache_get(key: str) -> Optional[Any]:
    """Get value from cache"""
    return await cache.get(key)


async def cache_set(key: str, value: Any, ttl: int = 300):
    """Set value in cache"""
    await cache.set(key, value, ttl)


async def cache_delete(key: str):
    """Delete value from cache"""
    cache.invalidate(key)


def get_redis_info():
    """Get Redis configuration info"""
    return {
        "mode": "cluster" if REDIS_CLUSTER_ENABLED else "standalone",
        "nodes": len(REDIS_CLUSTER_NODES) if REDIS_CLUSTER_ENABLED else 1,
        "cluster_nodes": REDIS_CLUSTER_NODES if REDIS_CLUSTER_ENABLED else [REDIS_URL.split("@")[-1]]
    }

