# FILE: backend/app/tests/conftest.py | PURPOSE: Shared pytest fixtures and configuration | OWNER: Backend Team | RELATED: All test files | LAST-AUDITED: 2025-01-18

"""
Shared pytest fixtures for all tests
"""

import pytest
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from pydantic import BaseModel, EmailStr, field_validator
from datetime import timedelta
from typing import Optional

# Import only what we need, avoiding circular dependencies
from app.database_enhanced import Base, User, Asset, get_db
from app.auth_postgresql import hash_password, create_access_token, verify_password

# Import routers
from app.routers import users, assets, predictions, alerts

# Create a minimal FastAPI app for testing
app = FastAPI(title="Test API")

# ===== Auth Endpoints (from main.py) =====


class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str

    @field_validator('password')
    @classmethod
    def password_strength(cls, v):
        """Validate password strength"""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        if not any(c in '@$!%*?&#' for c in v):
            raise ValueError('Password must contain at least one special character')
        return v


class UserLogin(BaseModel):
    username: str
    password: str


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str


class UserInfo(BaseModel):
    username: str
    email: str
    is_admin: bool
    is_active: bool


class TwoFASetup(BaseModel):
    secret: str
    qr_code: str


@app.post("/api/auth/register", response_model=Token)
async def register(user_data: UserRegister, db: Session = Depends(get_db)):
    """Register new user"""
    existing_user = db.query(User).filter(User.username == user_data.username).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already exists")

    new_user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        is_active=True
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    access_token = create_access_token({"sub": new_user.username})
    refresh_token = create_access_token({"sub": new_user.username, "type": "refresh"}, expires_delta=timedelta(days=7))

    return {"access_token": access_token, "refresh_token": refresh_token, "token_type": "bearer"}


@app.post("/api/auth/login", response_model=Token)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Login user"""
    user = db.query(User).filter(User.username == credentials.username).first()
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is inactive")

    access_token = create_access_token({"sub": user.username})
    refresh_token = create_access_token({"sub": user.username, "type": "refresh"}, expires_delta=timedelta(days=7))

    return {"access_token": access_token, "refresh_token": refresh_token, "token_type": "bearer"}


@app.get("/api/auth/me", response_model=UserInfo)
async def get_current_user_info(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    """Get current user information"""
    from jose import jwt, JWTError
    from app.config_secure import settings

    # Extract token from Authorization header
    if not authorization:
        raise HTTPException(status_code=401, detail="Not authenticated")

    token = authorization.replace("Bearer ", "")

    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username = payload.get("sub")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "username": user.username,
        "email": user.email,
        "is_admin": user.is_admin,
        "is_active": user.is_active
    }


@app.post("/api/auth/2fa/setup", response_model=TwoFASetup)
async def setup_2fa(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    """Setup 2FA for user"""
    from jose import jwt, JWTError
    from app.config_secure import settings
    import pyotp
    import qrcode
    from io import BytesIO
    import base64

    if not authorization:
        raise HTTPException(status_code=401, detail="Not authenticated")

    token = authorization.replace("Bearer ", "")

    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username = payload.get("sub")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Generate TOTP secret
    secret = pyotp.random_base32()

    # Generate QR code
    totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=user.username,
        issuer_name="Gold Price Predictor"
    )
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(totp_uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    # Convert to base64
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    qr_code_base64 = base64.b64encode(buffer.getvalue()).decode()

    return {"secret": secret, "qr_code": f"data:image/png;base64,{qr_code_base64}"}  # Include routers
app.include_router(users.router)
app.include_router(assets.router)
app.include_router(predictions.router)
app.include_router(alerts.router)

# Create in-memory SQLite database for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    """Override database dependency for testing"""
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="function")
def client():
    """FastAPI test client"""
    return TestClient(app)


@pytest.fixture(scope="function", autouse=True)
def setup_database():
    """Create tables before each test and drop after"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def db_session():
    """Database session for direct DB operations in tests"""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture
def admin_user(db_session):
    """Create admin user for testing"""
    user = User(
        username="admin",
        email="admin@test.com",
        hashed_password=hash_password("Admin@123"),
        is_admin=True,
        is_active=True
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture
def regular_user(db_session):
    """Create regular user for testing"""
    user = User(
        username="user1",
        email="user1@test.com",
        hashed_password=hash_password("User@123"),
        is_admin=False,
        is_active=True
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture
def admin_token(client, admin_user):
    """Get JWT token for admin user"""
    response = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "Admin@123"}
    )
    assert response.status_code == 200
    return response.json()["access_token"]


@pytest.fixture
def user_token(client, regular_user):
    """Get JWT token for regular user"""
    response = client.post(
        "/api/auth/login",
        json={"username": "user1", "password": "User@123"}
    )
    assert response.status_code == 200
    return response.json()["access_token"]


@pytest.fixture
def sample_asset(db_session):
    """Create sample asset for testing"""
    asset = Asset(
        symbol="GOLD",
        name="Gold",
        category="Precious Metals",
        description="Gold commodity",
        is_active=True
    )
    db_session.add(asset)
    db_session.commit()
    db_session.refresh(asset)
    return asset


@pytest.fixture
def multiple_assets(db_session):
    """Create multiple assets for testing"""
    assets = [
        Asset(symbol="GOLD", name="Gold", category="Precious Metals", is_active=True),
        Asset(symbol="SILVER", name="Silver", category="Precious Metals", is_active=True),
        Asset(symbol="BTC", name="Bitcoin", category="Cryptocurrency", is_active=True),
        Asset(symbol="ETH", name="Ethereum", category="Cryptocurrency", is_active=True),
        Asset(symbol="EUR/USD", name="Euro to USD", category="Forex", is_active=True),
    ]
    for asset in assets:
        db_session.add(asset)
    db_session.commit()
    return assets


@pytest.fixture
def inactive_user(db_session):
    """Create inactive user for testing"""
    user = User(
        username="inactive",
        email="inactive@test.com",
        hashed_password=hash_password("User@123"),
        is_admin=False,
        is_active=False
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user
