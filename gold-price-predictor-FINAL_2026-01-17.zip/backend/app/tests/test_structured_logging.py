# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_structured_logging.py
"""
Unit Tests for Structured Logging
"""

import pytest
import json
import logging
from unittest.mock import Mock, patch, MagicMock
from middleware.structured_logging import (
    StructuredLogger,
    get_correlation_id,
    set_correlation_id,
    get_logger,
    correlation_id_var
)


class TestStructuredLogging:
    """Test Structured Logging functionality"""

    @pytest.fixture
    def logger(self):
        """Create structured logger for testing"""
        return StructuredLogger("test_logger")

    @pytest.fixture
    def mock_logging(self):
        """Mock logging module"""
        with patch('logging.getLogger') as mock:
            mock_logger = MagicMock()
            mock.return_value = mock_logger
            yield mock_logger

    def test_logger_initialization(self, logger):
        """Test logger initialization"""
        assert logger.name == "test_logger"
        assert logger.logger is not None

    def test_get_correlation_id_none(self):
        """Test getting correlation ID when not set"""
        correlation_id_var.set(None)
        assert get_correlation_id() is None

    def test_set_and_get_correlation_id(self):
        """Test setting and getting correlation ID"""
        test_id = "test-correlation-id-123"
        set_correlation_id(test_id)
        assert get_correlation_id() == test_id

    def test_format_log_basic(self, logger):
        """Test basic log formatting"""
        log_entry = logger._format_log("INFO", "Test message")

        assert log_entry["level"] == "INFO"
        assert log_entry["message"] == "Test message"
        assert log_entry["logger"] == "test_logger"
        assert "timestamp" in log_entry

    def test_format_log_with_extra(self, logger):
        """Test log formatting with extra context"""
        extra = {"user_id": 123, "action": "login"}
        log_entry = logger._format_log("INFO", "User action", extra)

        assert log_entry["user_id"] == 123
        assert log_entry["action"] == "login"

    def test_format_log_with_correlation_id(self, logger):
        """Test log formatting with correlation ID"""
        set_correlation_id("test-corr-id")
        log_entry = logger._format_log("INFO", "Test message")

        assert log_entry["correlation_id"] == "test-corr-id"

    def test_info_logging(self, logger, mock_logging):
        """Test info level logging"""
        logger.logger = mock_logging
        logger.info("Test info message", user_id=123)

        # Verify logger.info was called
        assert mock_logging.info.called

        # Parse logged JSON
        call_args = mock_logging.info.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "INFO"
        assert log_data["message"] == "Test info message"
        assert log_data["user_id"] == 123

    def test_error_logging(self, logger, mock_logging):
        """Test error level logging"""
        logger.logger = mock_logging
        logger.error("Test error message", error_code=500)

        assert mock_logging.error.called

        call_args = mock_logging.error.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "ERROR"
        assert log_data["message"] == "Test error message"
        assert log_data["error_code"] == 500

    def test_warning_logging(self, logger, mock_logging):
        """Test warning level logging"""
        logger.logger = mock_logging
        logger.warning("Test warning", severity="medium")

        assert mock_logging.warning.called

        call_args = mock_logging.warning.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "WARNING"
        assert log_data["severity"] == "medium"

    def test_debug_logging(self, logger, mock_logging):
        """Test debug level logging"""
        logger.logger = mock_logging
        logger.debug("Debug info", variable="value")

        assert mock_logging.debug.called

        call_args = mock_logging.debug.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "DEBUG"
        assert log_data["variable"] == "value"

    def test_critical_logging(self, logger, mock_logging):
        """Test critical level logging"""
        logger.logger = mock_logging
        logger.critical("Critical error", system="database")

        assert mock_logging.critical.called

        call_args = mock_logging.critical.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "CRITICAL"
        assert log_data["system"] == "database"

    def test_log_request(self, logger, mock_logging):
        """Test HTTP request logging"""
        logger.logger = mock_logging
        logger.log_request(
            method="GET",
            path="/api/v1/predictions",
            status_code=200,
            duration_ms=45.67,
            user_id=123
        )

        assert mock_logging.info.called

        call_args = mock_logging.info.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["http_method"] == "GET"
        assert log_data["http_path"] == "/api/v1/predictions"
        assert log_data["http_status"] == 200
        assert log_data["duration_ms"] == 45.67
        assert log_data["user_id"] == 123

    def test_log_exception(self, logger, mock_logging):
        """Test exception logging"""
        logger.logger = mock_logging

        try:
            raise ValueError("Test exception")
        except ValueError as e:
            logger.log_exception(e, operation="test_operation")

        assert mock_logging.error.called

        call_args = mock_logging.error.call_args[0][0]
        log_data = json.loads(call_args)

        assert log_data["level"] == "ERROR"
        assert log_data["exception_type"] == "ValueError"
        assert "Test exception" in log_data["exception_message"]
        assert log_data["operation"] == "test_operation"

    def test_get_logger_utility(self):
        """Test get_logger utility function"""
        logger = get_logger("utility_test")
        assert isinstance(logger, StructuredLogger)
        assert logger.name == "utility_test"

    def test_multiple_loggers_different_correlation_ids(self):
        """Test multiple loggers with different correlation IDs"""
        logger1 = get_logger("logger1")
        logger2 = get_logger("logger2")

        set_correlation_id("corr-id-1")
        entry1 = logger1._format_log("INFO", "Message 1")

        set_correlation_id("corr-id-2")
        entry2 = logger2._format_log("INFO", "Message 2")

        # Both should have the current correlation ID
        assert entry2["correlation_id"] == "corr-id-2"

    def test_json_serialization(self, logger, mock_logging):
        """Test that logs are properly JSON serialized"""
        logger.logger = mock_logging

        complex_data = {
            "nested": {"key": "value"},
            "list": [1, 2, 3],
            "number": 42,
            "boolean": True
        }

        logger.info("Complex log", **complex_data)

        call_args = mock_logging.info.call_args[0][0]
        # Should not raise exception
        log_data = json.loads(call_args)

        assert log_data["nested"]["key"] == "value"
        assert log_data["list"] == [1, 2, 3]
        assert log_data["number"] == 42
        assert log_data["boolean"] is True
