# FILE: backend/app/tests/test_jwt_rotation.py | PURPOSE: Test JWT token rotation | OWNER: Security Team | RELATED: auth_postgresql.py, main.py | LAST-AUDITED: 2025-01-18
"""
Tests for JWT Token Rotation
"""

import pytest
from fastapi.testclient import TestClient
from jose import jwt
from app.config_secure import settings
from datetime import datetime
import time


@pytest.fixture
def client():
    """Create test client"""
    from main import app
    return TestClient(app)


@pytest.fixture
def test_user(client):
    """Create a test user"""
    response = client.post(
        "/api/auth/register",
        json={
            "username": "testuser_rotation",
            "email": "rotation@example.com",
            "password": "TestPass123!"
        }
    )
    assert response.status_code == 200
    return response.json()


def test_access_token_ttl_is_15_minutes():
    """Test that access token TTL is 15 minutes"""
    assert settings.ACCESS_TOKEN_EXPIRE_MINUTES == 15


def test_refresh_token_ttl_is_7_days():
    """Test that refresh token TTL is 7 days"""
    assert settings.REFRESH_TOKEN_EXPIRE_DAYS == 7


def test_token_refresh_endpoint_exists(client):
    """Test that token refresh endpoint exists"""
    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": "invalid_token"}
    )
    # Should return 401 for invalid token, not 404
    assert response.status_code in [401, 422]


def test_token_refresh_with_valid_refresh_token(client, test_user):
    """Test token refresh with valid refresh token"""
    # Get initial tokens
    initial_access_token = test_user["access_token"]
    initial_refresh_token = test_user["refresh_token"]

    # Decode initial access token to verify expiration
    initial_payload = jwt.decode(
        initial_access_token,
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM]
    )

    # Verify token type
    assert initial_payload["type"] == "access"

    # Wait a moment to ensure new token has different timestamp
    time.sleep(1)

    # Refresh token
    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": initial_refresh_token}
    )

    assert response.status_code == 200
    data = response.json()

    # Should receive new tokens
    assert "access_token" in data
    assert "refresh_token" in data
    assert "token_type" in data

    # New tokens should be different
    assert data["access_token"] != initial_access_token
    assert data["refresh_token"] != initial_refresh_token

    # Decode new access token
    new_payload = jwt.decode(
        data["access_token"],
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM]
    )

    # Verify new token has correct type
    assert new_payload["type"] == "access"

    # Verify new token has later expiration
    assert new_payload["exp"] > initial_payload["exp"]


def test_token_refresh_with_invalid_token(client):
    """Test token refresh with invalid refresh token"""
    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": "invalid_token"}
    )

    assert response.status_code == 401
    assert "detail" in response.json()


def test_token_refresh_with_access_token_fails(client, test_user):
    """Test that using access token for refresh fails"""
    # Try to use access token as refresh token
    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": test_user["access_token"]}
    )

    # Should fail because token type is "access" not "refresh"
    assert response.status_code == 401


def test_token_refresh_with_expired_token(client):
    """Test token refresh with expired refresh token"""
    # Create an expired refresh token
    from datetime import timedelta

    # Create token that expired 1 day ago
    expired_data = {
        "sub": "testuser",
        "exp": datetime.utcnow() - timedelta(days=1),
        "type": "refresh",
        "iat": datetime.utcnow() - timedelta(days=8)
    }

    expired_token = jwt.encode(
        expired_data,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM
    )

    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": expired_token}
    )

    assert response.status_code == 401


def test_old_refresh_token_blacklisted_after_rotation(client, test_user):
    """Test that old refresh token is blacklisted after rotation"""
    initial_refresh_token = test_user["refresh_token"]

    # Refresh token
    response = client.post(
        "/api/auth/refresh",
        json={"refresh_token": initial_refresh_token}
    )

    assert response.status_code == 200

    # Try to use old refresh token again
    response2 = client.post(
        "/api/auth/refresh",
        json={"refresh_token": initial_refresh_token}
    )

    # Should fail because old token is blacklisted
    assert response2.status_code == 401


def test_access_token_expiration_time():
    """Test that access token expires in 15 minutes"""
    from auth_postgresql import create_access_token

    token = create_access_token(data={"sub": "testuser"})
    payload = jwt.decode(
        token,
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM]
    )

    # Calculate expiration time
    exp_time = datetime.fromtimestamp(payload["exp"])
    iat_time = datetime.fromtimestamp(payload["iat"])

    # Should be approximately 15 minutes
    delta = exp_time - iat_time
    assert 14 * 60 < delta.total_seconds() < 16 * 60  # 14-16 minutes tolerance


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
