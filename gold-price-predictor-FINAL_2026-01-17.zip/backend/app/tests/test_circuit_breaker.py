# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_circuit_breaker.py
"""
Unit Tests for Circuit Breaker Pattern
"""

import pytest
import time
import asyncio
from services.circuit_breaker import (
    CircuitBreaker,
    CircuitState,
    CircuitBreakerError,
    circuit_breaker,
    get_circuit_breaker,
    register_circuit_breaker,
    get_all_circuit_breakers,
    reset_all_circuit_breakers
)


class TestCircuitBreaker:
    """Test Circuit Breaker functionality"""

    @pytest.fixture
    def breaker(self):
        """Create circuit breaker for testing"""
        return CircuitBreaker(
            name="test_breaker",
            failure_threshold=3,
            recovery_timeout=1,  # Short timeout for testing
            success_threshold=2
        )

    def test_initialization(self, breaker):
        """Test circuit breaker initialization"""
        assert breaker.name == "test_breaker"
        assert breaker.state == CircuitState.CLOSED
        assert breaker.failure_count == 0
        assert breaker.success_count == 0

    def test_successful_call(self, breaker):
        """Test successful function call"""
        def success_func():
            return "success"

        result = breaker.call(success_func)
        assert result == "success"
        assert breaker.state == CircuitState.CLOSED
        assert breaker.failure_count == 0

    def test_failed_call(self, breaker):
        """Test failed function call"""
        def failing_func():
            raise Exception("Test error")

        with pytest.raises(Exception):
            breaker.call(failing_func)

        assert breaker.failure_count == 1
        assert breaker.state == CircuitState.CLOSED

    def test_circuit_opens_after_threshold(self, breaker):
        """Test circuit opens after failure threshold"""
        def failing_func():
            raise Exception("Test error")

        # Fail 3 times to reach threshold
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        assert breaker.state == CircuitState.OPEN
        assert breaker.failure_count == 3

    def test_circuit_open_rejects_calls(self, breaker):
        """Test circuit open rejects new calls"""
        def failing_func():
            raise Exception("Test error")

        # Open the circuit
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        # Next call should be rejected
        with pytest.raises(CircuitBreakerError):
            breaker.call(lambda: "test")

    def test_circuit_moves_to_half_open(self, breaker):
        """Test circuit moves to half-open after timeout"""
        def failing_func():
            raise Exception("Test error")

        # Open the circuit
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        assert breaker.state == CircuitState.OPEN

        # Wait for recovery timeout
        time.sleep(1.1)

        # Next call should move to HALF_OPEN
        with pytest.raises(Exception):
            breaker.call(failing_func)

        # State should have been HALF_OPEN before the failure
        assert breaker.state == CircuitState.OPEN  # Back to OPEN after failure

    def test_circuit_closes_after_success_in_half_open(self, breaker):
        """Test circuit closes after successful calls in half-open"""
        def failing_func():
            raise Exception("Test error")

        def success_func():
            return "success"

        # Open the circuit
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        # Wait for recovery timeout
        time.sleep(1.1)

        # Make successful calls to close circuit
        breaker.call(success_func)  # Moves to HALF_OPEN
        breaker.call(success_func)  # Should close circuit

        assert breaker.state == CircuitState.CLOSED

    def test_manual_reset(self, breaker):
        """Test manual circuit reset"""
        def failing_func():
            raise Exception("Test error")

        # Open the circuit
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        assert breaker.state == CircuitState.OPEN

        # Manual reset
        breaker.reset()

        assert breaker.state == CircuitState.CLOSED
        assert breaker.failure_count == 0

    def test_get_state(self, breaker):
        """Test getting circuit state"""
        state = breaker.get_state()

        assert state["name"] == "test_breaker"
        assert state["state"] == "closed"
        assert state["failure_count"] == 0
        assert "last_state_change" in state

    @pytest.mark.asyncio
    async def test_async_call_success(self, breaker):
        """Test successful async function call"""
        async def async_success():
            return "async_success"

        result = await breaker.call_async(async_success)
        assert result == "async_success"

    @pytest.mark.asyncio
    async def test_async_call_failure(self, breaker):
        """Test failed async function call"""
        async def async_failing():
            raise Exception("Async error")

        with pytest.raises(Exception):
            await breaker.call_async(async_failing)

        assert breaker.failure_count == 1

    def test_circuit_breaker_decorator_sync(self):
        """Test circuit breaker decorator for sync functions"""
        @circuit_breaker(name="test_decorator", failure_threshold=2)
        def decorated_func(should_fail=False):
            if should_fail:
                raise Exception("Decorated error")
            return "success"

        # Successful call
        result = decorated_func(should_fail=False)
        assert result == "success"

        # Failed calls
        with pytest.raises(Exception):
            decorated_func(should_fail=True)
        with pytest.raises(Exception):
            decorated_func(should_fail=True)

        # Circuit should be open
        with pytest.raises(CircuitBreakerError):
            decorated_func(should_fail=False)

    @pytest.mark.asyncio
    async def test_circuit_breaker_decorator_async(self):
        """Test circuit breaker decorator for async functions"""
        @circuit_breaker(name="test_async_decorator", failure_threshold=2)
        async def async_decorated(should_fail=False):
            if should_fail:
                raise Exception("Async decorated error")
            return "async_success"

        # Successful call
        result = await async_decorated(should_fail=False)
        assert result == "async_success"

        # Failed calls
        with pytest.raises(Exception):
            await async_decorated(should_fail=True)
        with pytest.raises(Exception):
            await async_decorated(should_fail=True)

        # Circuit should be open
        with pytest.raises(CircuitBreakerError):
            await async_decorated(should_fail=False)

    def test_register_and_get_circuit_breaker(self, breaker):
        """Test registering and retrieving circuit breaker"""
        register_circuit_breaker(breaker)

        retrieved = get_circuit_breaker("test_breaker")
        assert retrieved is breaker

    def test_get_all_circuit_breakers(self, breaker):
        """Test getting all circuit breakers"""
        register_circuit_breaker(breaker)

        all_breakers = get_all_circuit_breakers()
        assert "test_breaker" in all_breakers
        assert all_breakers["test_breaker"]["state"] == "closed"

    def test_reset_all_circuit_breakers(self, breaker):
        """Test resetting all circuit breakers"""
        def failing_func():
            raise Exception("Test error")

        register_circuit_breaker(breaker)

        # Open the circuit
        for _ in range(3):
            with pytest.raises(Exception):
                breaker.call(failing_func)

        assert breaker.state == CircuitState.OPEN

        # Reset all
        reset_all_circuit_breakers()

        assert breaker.state == CircuitState.CLOSED
