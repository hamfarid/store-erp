# FILE: backend/app/tests/test_users_crud.py | PURPOSE: Unit tests for Users CRUD endpoints | OWNER: Backend Team | RELATED: routers/users.py | LAST-AUDITED: 2025-01-18

# import pytest  # Unused

from app.database_enhanced import User
from app.auth_postgresql import hash_password
# from app.database_enhanced import Base  # Unused

# NOTE: Using conftest.py fixtures (setup_database, client, admin_user, admin_token, regular_user, user_token)
# No need to import main.py or create engine here

# ==================== CREATE Tests ====================


def test_create_user_success(client, admin_token):
    """Test creating a new user successfully"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "newuser",
            "email": "newuser@test.com",
            "password": "NewUser@123",
            "is_admin": False
        }
    )
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "newuser"
    assert data["email"] == "newuser@test.com"
    assert data["is_admin"] is False
    assert "id" in data
    assert "hashed_password" not in data  # Password should not be returned


def test_create_user_duplicate_username(client, admin_token, regular_user):
    """Test creating user with duplicate username fails"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "user1",  # Already exists
            "email": "different@test.com",
            "password": "NewUser@123",
            "is_admin": False
        }
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"].lower()


def test_create_user_duplicate_email(client, admin_token, regular_user):
    """Test creating user with duplicate email fails"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "newuser",
            "email": "user1@test.com",  # Already exists
            "password": "NewUser@123",
            "is_admin": False
        }
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"].lower()


def test_create_user_invalid_password(client, admin_token):
    """Test creating user with weak password fails"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "newuser",
            "email": "newuser@test.com",
            "password": "weak",  # Too weak
            "is_admin": False
        }
    )
    assert response.status_code == 422  # Validation error


def test_create_user_unauthorized(client, user_token):
    """Test non-admin cannot create users"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "username": "newuser",
            "email": "newuser@test.com",
            "password": "NewUser@123",
            "is_admin": False
        }
    )
    assert response.status_code == 403


# ==================== READ Tests ====================

def test_get_users_list(client, admin_token, regular_user):
    """Test getting list of users"""
    response = client.get(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "total" in data
    assert len(data["items"]) >= 1


def test_get_users_with_search(client, admin_token, regular_user):
    """Test searching users by username"""
    response = client.get(
        "/api/users?search=user1",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["items"]) >= 1
    assert data["items"][0]["username"] == "user1"


def test_get_users_with_status_filter(client, admin_token, regular_user):
    """Test filtering users by status"""
    response = client.get(
        "/api/users?status=active",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert all(user["is_active"] for user in data["items"])


def test_get_users_pagination(client, admin_token, db_session):
    """Test pagination works correctly"""
    # Create multiple users
    db = db_session
    for i in range(15):
        user = User(
            username=f"user{i}",
            email=f"user{i}@test.com",
            hashed_password=hash_password("User@123"),
            is_active=True
        )
        db.add(user)
    db.commit()
    db.close()

    # Test first page
    response = client.get(
        "/api/users?skip=0&limit=10",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["items"]) == 10
    assert data["total"] >= 15

    # Test second page
    response = client.get(
        "/api/users?skip=10&limit=10",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["items"]) >= 5


def test_get_user_by_id(client, admin_token, regular_user):
    """Test getting a specific user by ID"""
    response = client.get(
        f"/api/users/{regular_user.id}",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == regular_user.id
    assert data["username"] == "user1"
    assert "hashed_password" not in data


def test_get_user_not_found(client, admin_token):
    """Test getting non-existent user returns 404"""
    response = client.get(
        "/api/users/99999",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 404


# ==================== UPDATE Tests ====================

def test_update_user_success(client, admin_token, regular_user):
    """Test updating user successfully"""
    response = client.put(
        f"/api/users/{regular_user.id}",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "user1_updated",
            "email": "user1_updated@test.com",
            "is_admin": False
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert data["username"] == "user1_updated"
    assert data["email"] == "user1_updated@test.com"


def test_update_user_not_found(client, admin_token):
    """Test updating non-existent user returns 404"""
    response = client.put(
        "/api/users/99999",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "updated",
            "email": "updated@test.com"
        }
    )
    assert response.status_code == 404
