# File: /home/ubuntu/gold-price-predictor/backend/app/tests/test_integration.py
"""
Integration Tests
End-to-end tests for complete workflows
"""

from database_enhanced import Base
from main import app, get_db
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_integration.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={
        "check_same_thread": False})
TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine)

# Override get_db dependency


def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

# Test client
client = TestClient(app)


@pytest.fixture(scope="function")
def test_db():
    """Create test database"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


class TestCompleteUserWorkflow:
    """Test complete user workflow from registration to prediction"""

    def test_complete_workflow(self, test_db):
        """Test: Register -> Login -> Get Prediction -> Create API Key"""

        # Step 1: Register
        register_response = client.post(
            "/api/auth/register",
            json={
                "username": "workflow_user",
                "email": "workflow@example.com",
                "password": "Workflow@123"
            }
        )
        assert register_response.status_code == 200
        token = register_response.json()["access_token"]

        # Step 2: Get current user info
        user_response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert user_response.status_code == 200
        assert user_response.json()["username"] == "workflow_user"

        # Step 3: Create API key
        api_key_response = client.post(
            "/api/keys",
            json={"name": "My First Key"},
            headers={"Authorization": f"Bearer {token}"}
        )
        assert api_key_response.status_code == 200
        plain_key = api_key_response.json()["key"]
        assert plain_key is not None

        # Step 4: List API keys
        list_response = client.get(
            "/api/keys",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert list_response.status_code == 200
        assert len(list_response.json()) == 1

        # Step 5: Get API key stats
        stats_response = client.get(
            "/api/keys/stats",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert stats_response.status_code == 200
        stats = stats_response.json()
        assert stats["total_keys"] == 1
        assert stats["active_keys"] == 1


class TestSecurityWorkflow:
    """Test security-related workflows"""

    def test_2fa_workflow(self, test_db):
        """Test: Register -> Login -> Setup 2FA -> Verify 2FA"""

        # Register and login
        client.post(
            "/api/auth/register",
            json={
                "username": "2fa_user",
                "email": "2fa@example.com",
                "password": "TwoFA@123"
            }
        )

        login_response = client.post(
            "/api/auth/login",
            data={
                "username": "2fa_user",
                "password": "TwoFA@123"
            }
        )
        token = login_response.json()["access_token"]

        # Setup 2FA
        setup_response = client.post(
            "/api/auth/2fa/setup",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert setup_response.status_code == 200
        assert "secret" in setup_response.json()
        assert "qr_code" in setup_response.json()


class TestRateLimiting:
    """Test rate limiting functionality"""

    def test_rate_limit_enforcement(self, test_db):
        """Test that rate limiting is enforced"""
        # This test depends on rate limiter configuration
        # For now, just verify the endpoint is protected

        # Try to access without auth (should fail)
        response = client.get("/api/auth/me")
        assert response.status_code == 401


class TestErrorHandling:
    """Test error handling"""

    def test_404_error(self, test_db):
        """Test 404 error handling"""
        response = client.get("/api/nonexistent")
        assert response.status_code == 404

    def test_validation_error(self, test_db):
        """Test validation error handling"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "ab",  # Too short
                "email": "invalid",  # Invalid email
                "password": "weak"  # Weak password
            }
        )
        assert response.status_code == 422

    def test_unauthorized_error(self, test_db):
        """Test unauthorized access"""
        response = client.get("/api/auth/me")
        assert response.status_code == 401


class TestHealthCheck:
    """Test health check endpoint"""

    def test_health_check(self, test_db):
        """Test health check endpoint"""
        response = client.get("/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert "version" in data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
