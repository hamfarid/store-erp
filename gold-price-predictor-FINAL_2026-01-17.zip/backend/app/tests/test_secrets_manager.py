# File:
# /home/ubuntu/gold-price-predictor/backend/app/tests/test_secrets_manager.py
"""
Unit tests for Secrets Manager
"""

import pytest
import os
from unittest.mock import Mock, patch, MagicMock
from services.secrets_manager import (
    SecretsManager,
    EnvironmentBackend,
    VaultBackend,
    AWSSecretsBackend,
    get_secrets_manager,
    get_secret
)


class TestEnvironmentBackend:
    """Test Environment Variables backend"""

    def test_get_secret(self):
        """Test getting secret from environment"""
        os.environ['TEST_SECRET'] = 'test_value'
        backend = EnvironmentBackend()

        assert backend.get_secret('TEST_SECRET') == 'test_value'
        assert backend.get_secret('NON_EXISTENT') is None

        del os.environ['TEST_SECRET']

    def test_set_secret(self):
        """Test setting secret in environment"""
        backend = EnvironmentBackend()

        assert backend.set_secret('NEW_SECRET', 'new_value')
        assert os.getenv('NEW_SECRET') == 'new_value'

        del os.environ['NEW_SECRET']

    def test_delete_secret(self):
        """Test deleting secret from environment"""
        os.environ['DELETE_ME'] = 'value'
        backend = EnvironmentBackend()

        assert backend.delete_secret('DELETE_ME')
        assert 'DELETE_ME' not in os.environ
        assert not backend.delete_secret('NON_EXISTENT')

    def test_list_secrets(self):
        """Test listing environment variables"""
        backend = EnvironmentBackend()
        secrets = backend.list_secrets()

        assert isinstance(secrets, list)
        assert len(secrets) > 0


class TestVaultBackend:
    """Test HashiCorp Vault backend"""

    @patch('services.secrets_manager.hvac')
    def test_vault_initialization(self, mock_hvac):
        """Test Vault backend initialization"""
        mock_client = Mock()
        mock_client.is_authenticated.return_value = True
        mock_hvac.Client.return_value = mock_client

        backend = VaultBackend(
            vault_addr='http://localhost:8200',
            vault_token='test-token'
        )

        assert backend.client is not None
        mock_hvac.Client.assert_called_once()

    @patch('services.secrets_manager.hvac')
    def test_vault_authentication_failure(self, mock_hvac):
        """Test Vault authentication failure"""
        mock_client = Mock()
        mock_client.is_authenticated.return_value = False
        mock_hvac.Client.return_value = mock_client

        backend = VaultBackend()

        assert backend.client is None

    @patch('services.secrets_manager.hvac')
    def test_get_secret_from_vault(self, mock_hvac):
        """Test getting secret from Vault"""
        mock_client = Mock()
        mock_client.is_authenticated.return_value = True
        mock_client.secrets.kv.v2.read_secret_version.return_value = {
            'data': {
                'data': {'password': 'secret_value'}
            }
        }
        mock_hvac.Client.return_value = mock_client

        backend = VaultBackend()
        value = backend.get_secret('database/password')

        assert value == 'secret_value'

    @patch('services.secrets_manager.hvac')
    def test_set_secret_in_vault(self, mock_hvac):
        """Test setting secret in Vault"""
        mock_client = Mock()
        mock_client.is_authenticated.return_value = True
        mock_hvac.Client.return_value = mock_client

        backend = VaultBackend()
        result = backend.set_secret('database/password', 'new_value')

        assert result is True
        mock_client.secrets.kv.v2.create_or_update_secret.assert_called_once()


class TestAWSSecretsBackend:
    """Test AWS Secrets Manager backend"""

    @patch('services.secrets_manager.boto3')
    def test_aws_initialization(self, mock_boto3):
        """Test AWS backend initialization"""
        mock_client = Mock()
        mock_boto3.client.return_value = mock_client

        backend = AWSSecretsBackend(region_name='us-east-1')

        assert backend.client is not None
        mock_boto3.client.assert_called_once_with(
            'secretsmanager',
            region_name='us-east-1'
        )

    @patch('services.secrets_manager.boto3')
    def test_get_secret_from_aws(self, mock_boto3):
        """Test getting secret from AWS"""
        mock_client = Mock()
        mock_client.get_secret_value.return_value = {
            'SecretString': 'secret_value'
        }
        mock_boto3.client.return_value = mock_client

        backend = AWSSecretsBackend()
        value = backend.get_secret('prod/database/password')

        assert value == 'secret_value'

    @patch('services.secrets_manager.boto3')
    def test_get_json_secret_from_aws(self, mock_boto3):
        """Test getting JSON secret from AWS"""
        mock_client = Mock()
        mock_client.get_secret_value.return_value = {
            'SecretString': '{"password": "secret_value"}'
        }
        mock_boto3.client.return_value = mock_client

        backend = AWSSecretsBackend()
        value = backend.get_secret('prod/database/credentials')

        assert value == 'secret_value'

    @patch('services.secrets_manager.boto3')
    def test_set_secret_in_aws(self, mock_boto3):
        """Test setting secret in AWS"""
        mock_client = Mock()
        mock_boto3.client.return_value = mock_client

        backend = AWSSecretsBackend()
        result = backend.set_secret('prod/api/key', 'new_value')

        assert result is True
        mock_client.update_secret.assert_called_once()

    @patch('services.secrets_manager.boto3')
    def test_create_new_secret_in_aws(self, mock_boto3):
        """Test creating new secret in AWS"""
        mock_client = Mock()
        mock_client.update_secret.side_effect = \
            mock_client.exceptions.ResourceNotFoundException()
        mock_boto3.client.return_value = mock_client

        backend = AWSSecretsBackend()
        result = backend.set_secret('prod/new/key', 'new_value')

        assert result is True
        mock_client.create_secret.assert_called_once()


class TestSecretsManager:
    """Test unified Secrets Manager"""

    def test_initialization_with_env_backend(self):
        """Test initialization with environment backend"""
        manager = SecretsManager(backend='env')

        assert isinstance(manager.backend, EnvironmentBackend)

    @patch('services.secrets_manager.hvac')
    def test_initialization_with_vault_backend(self, mock_hvac):
        """Test initialization with Vault backend"""
        mock_client = Mock()
        mock_client.is_authenticated.return_value = True
        mock_hvac.Client.return_value = mock_client

        manager = SecretsManager(backend='vault')

        assert isinstance(manager.backend, VaultBackend)

    @patch('services.secrets_manager.boto3')
    def test_initialization_with_aws_backend(self, mock_boto3):
        """Test initialization with AWS backend"""
        mock_client = Mock()
        mock_boto3.client.return_value = mock_client

        manager = SecretsManager(backend='aws')

        assert isinstance(manager.backend, AWSSecretsBackend)

    def test_get_secret_from_cache(self):
        """Test getting secret from cache"""
        manager = SecretsManager(backend='env', cache_enabled=True)
        manager.cache['CACHED_SECRET'] = 'cached_value'

        value = manager.get('CACHED_SECRET')

        assert value == 'cached_value'

    def test_get_secret_with_fallback(self):
        """Test getting secret with fallback to environment"""
        os.environ['FALLBACK_SECRET'] = 'fallback_value'
        manager = SecretsManager(backend='env')

        # Mock backend to return None
        manager.backend.get_secret = Mock(return_value=None)

        value = manager.get('FALLBACK_SECRET')

        assert value == 'fallback_value'

        del os.environ['FALLBACK_SECRET']

    def test_get_secret_with_default(self):
        """Test getting secret with default value"""
        manager = SecretsManager(backend='env')

        value = manager.get('NON_EXISTENT', default='default_value')

        assert value == 'default_value'

    def test_set_secret_updates_cache(self):
        """Test that setting secret updates cache"""
        manager = SecretsManager(backend='env', cache_enabled=True)

        manager.set('NEW_SECRET', 'new_value')

        assert manager.cache['NEW_SECRET'] == 'new_value'

    def test_delete_secret_clears_cache(self):
        """Test that deleting secret clears cache"""
        manager = SecretsManager(backend='env', cache_enabled=True)
        manager.cache['DELETE_ME'] = 'value'
        os.environ['DELETE_ME'] = 'value'

        manager.delete('DELETE_ME')

        assert 'DELETE_ME' not in manager.cache

    def test_clear_cache(self):
        """Test clearing cache"""
        manager = SecretsManager(backend='env', cache_enabled=True)
        manager.cache['SECRET1'] = 'value1'
        manager.cache['SECRET2'] = 'value2'

        manager.clear_cache()

        assert len(manager.cache) == 0


class TestGlobalInstance:
    """Test global secrets manager instance"""

    def test_get_secrets_manager(self):
        """Test getting global instance"""
        manager = get_secrets_manager()

        assert isinstance(manager, SecretsManager)

    def test_get_secret_convenience_function(self):
        """Test convenience function"""
        os.environ['TEST_GLOBAL'] = 'global_value'

        value = get_secret('TEST_GLOBAL')

        assert value == 'global_value'

        del os.environ['TEST_GLOBAL']


class TestIntegration:
    """Integration tests"""

    def test_end_to_end_workflow(self):
        """Test complete workflow"""
        manager = SecretsManager(backend='env')

        # Set a secret
        manager.set('E2E_SECRET', 'e2e_value')

        # Get the secret
        value = manager.get('E2E_SECRET')
        assert value == 'e2e_value'

        # List secrets
        secrets = manager.list()
        assert 'E2E_SECRET' in secrets

        # Delete the secret
        manager.delete('E2E_SECRET')

        # Verify deletion
        value = manager.get('E2E_SECRET')
        assert value is None

    def test_cache_performance(self):
        """Test cache improves performance"""
        import time

        manager = SecretsManager(backend='env', cache_enabled=True)
        os.environ['PERF_TEST'] = 'value'

        # First call (no cache)
        start = time.time()
        manager.get('PERF_TEST')
        first_call = time.time() - start

        # Second call (from cache)
        start = time.time()
        manager.get('PERF_TEST')
        second_call = time.time() - start

        # Cache should be faster (or at least not slower)
        assert second_call <= first_call * 1.1  # Allow 10% margin

        del os.environ['PERF_TEST']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
