# FILE: backend/app/api_docs.py | PURPOSE: OpenAPI/Swagger documentation configuration | OWNER: Backend Team | RELATED: main.py | LAST-AUDITED: 2025-01-18

"""
OpenAPI/Swagger Documentation Configuration
Provides comprehensive API documentation with examples and schemas
"""

from fastapi.openapi.utils import get_openapi
from fastapi import FastAPI

# API Metadata
API_TITLE = "Gold Price Predictor API"
API_VERSION = "1.0.0"
API_DESCRIPTION = """
## Gold Price Predictor API

A comprehensive API for gold price prediction, asset management, and user alerts.

### Features

* **Authentication** - JWT-based authentication with token rotation
* **Users Management** - CRUD operations for user accounts
* **Assets Management** - Manage tradable assets (Gold, Silver, Crypto, Forex)
* **Predictions** - AI-powered price predictions
* **Alerts** - Price and change alerts with notifications
* **Security** - CSRF protection, account lockout, rate limiting

### Authentication

All endpoints (except `/auth/login` and `/auth/register`)
require authentication.

Include the JWT token in the `Authorization` header:

```
Authorization: Bearer <your_jwt_token>
```

### Rate Limiting

API requests are rate-limited to prevent abuse:
- **100 requests per minute** for authenticated users
- **20 requests per minute** for unauthenticated users

### Error Responses

All error responses follow this format:

```json
{
  "detail": "Error message",
  "code": "ERROR_CODE",
  "timestamp": "2025-01-18T00:00:00Z"
}
```

### Pagination

List endpoints support pagination with `skip` and `limit` parameters:

```
GET /api/users?skip=0&limit=10
```

Response format:

```json
{
  "items": [...],
  "total": 100,
  "skip": 0,
  "limit": 10
}
```
"""

# API Tags
API_TAGS_METADATA = [
    {
        "name": "Authentication",
        "description": "User authentication and authorization endpoints",
    },
    {
        "name": "Users",
        "description": "User management operations (admin only)",
    },
    {
        "name": "Assets",
        "description": "Asset management operations (admin only)",
    },
    {
        "name": "Predictions",
        "description": "Price prediction operations",
    },
    {
        "name": "Alerts",
        "description": "Price alert management",
    },
    {
        "name": "Health",
        "description": "Health check and monitoring endpoints",
    },
]

# Example Responses
EXAMPLE_RESPONSES = {
    "user": {
        "id": 1,
        "username": "john_doe",
        "email": "john@example.com",
        "is_admin": False,
        "is_active": True,
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-01T00:00:00Z"
    },
    "asset": {
        "id": 1,
        "symbol": "GOLD",
        "name": "Gold",
        "category": "Precious Metals",
        "description": "Gold commodity",
        "is_active": True,
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-01T00:00:00Z"
    },
    "prediction": {
        "id": 1,
        "user_id": 1,
        "symbol": "GOLD",
        "horizon": "1d",
        "current_price": 1950.50,
        "predicted_price": 1975.25,
        "change_percent": 1.27,
        "confidence": 0.85,
        "model_used": "LSTM",
        "model_accuracy": 0.92,
        "created_at": "2025-01-18T00:00:00Z"
    },
    "alert": {
        "id": 1,
        "user_id": 1,
        "asset_id": 1,
        "alert_type": "above",
        "target_price": 2000.00,
        "change_percent": None,
        "is_active": True,
        "is_triggered": False,
        "triggered_at": None,
        "notification_method": "email",
        "created_at": "2025-01-18T00:00:00Z"
    },
    "error": {
        "detail": "Resource not found",
        "code": "NOT_FOUND",
        "timestamp": "2025-01-18T00:00:00Z"
    }
}


def custom_openapi(app: FastAPI):
    """
    Generate custom OpenAPI schema with enhanced documentation
    """
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=API_TITLE,
        version=API_VERSION,
        description=API_DESCRIPTION,
        routes=app.routes,
        tags=API_TAGS_METADATA,
    )

    # Add security scheme
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter your JWT token"
        }
    }

    # Add global security requirement
    openapi_schema["security"] = [{"BearerAuth": []}]

    app.openapi_schema = openapi_schema
    return app.openapi_schema
