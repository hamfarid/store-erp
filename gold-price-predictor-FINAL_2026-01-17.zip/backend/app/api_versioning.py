# File: /home/ubuntu/gold-price-predictor/backend/app/api_versioning.py
"""
API Versioning System
Implements URI-based API versioning for backward compatibility
"""

from fastapi import APIRouter, FastAPI, Request
from typing import Callable, Optional
import logging

logger = logging.getLogger(__name__)


class APIVersion:
    """
    API Version Manager

    Provides functionality to:
    - Create versioned API routers
    - Manage multiple API versions
    - Handle version deprecation
    - Provide version information
    """

    # Supported API versions
    SUPPORTED_VERSIONS = ["v1", "v2"]
    DEFAULT_VERSION = "v1"
    DEPRECATED_VERSIONS = []  # e.g., ["v0"]

    def __init__(self, app: FastAPI):
        """
        Initialize API Version Manager

        Args:
            app: FastAPI application instance
        """
        self.app = app
        self.routers = {}

    def create_router(
        self,
        version: str,
        prefix: str = "",
        tags: Optional[list] = None,
        deprecated: bool = False
    ) -> APIRouter:
        """
        Create a versioned API router

        Args:
            version: API version (e.g., "v1", "v2")
            prefix: Additional prefix after version
            tags: OpenAPI tags
            deprecated: Mark this version as deprecated

        Returns:
            APIRouter instance
        """
        if version not in self.SUPPORTED_VERSIONS:
            raise ValueError(f"Unsupported API version: {version}")

        router = APIRouter(
            prefix=f"/api/{version}{prefix}",
            tags=tags or [f"API {version.upper()}"],
            deprecated=deprecated or version in self.DEPRECATED_VERSIONS
        )

        self.routers[version] = router
        logger.info(f"Created API router for version {version}")

        return router

    def get_router(self, version: str) -> Optional[APIRouter]:
        """
        Get router for specific version

        Args:
            version: API version

        Returns:
            APIRouter instance or None
        """
        return self.routers.get(version)

    def register_all_routers(self):
        """Register all created routers with the FastAPI app"""
        for version, router in self.routers.items():
            self.app.include_router(router)
            logger.info(f"Registered API router for version {version}")

    @staticmethod
    def get_version_from_request(request: Request) -> str:
        """
        Extract API version from request path

        Args:
            request: FastAPI request

        Returns:
            API version string (e.g., "v1")
        """
        path = request.url.path
        parts = path.split('/')

        # Look for version in path (e.g., /api/v1/...)
        for part in parts:
            if part.startswith('v') and part[1:].isdigit():
                return part

        return APIVersion.DEFAULT_VERSION

    @classmethod
    def is_deprecated(cls, version: str) -> bool:
        """
        Check if a version is deprecated

        Args:
            version: API version

        Returns:
            True if deprecated, False otherwise
        """
        return version in cls.DEPRECATED_VERSIONS

    @classmethod
    def get_latest_version(cls) -> str:
        """
        Get the latest API version

        Returns:
            Latest version string
        """
        return cls.SUPPORTED_VERSIONS[-1]


def version_header_middleware(request: Request, call_next: Callable):
    """
    Middleware to add API version to response headers

    Args:
        request: FastAPI request
        call_next: Next middleware/handler

    Returns:
        Response with version header
    """
    response = call_next(request)
    version = APIVersion.get_version_from_request(request)

    # Add version information to response headers
    response.headers["X-API-Version"] = version
    response.headers["X-API-Latest-Version"] = APIVersion.get_latest_version()

    if APIVersion.is_deprecated(version):
        response.headers["X-API-Deprecated"] = "true"
        response.headers["Warning"] = f"299 - API version {version} is deprecated"

    return response


# Example usage functions for different versions
def create_v1_endpoints(router: APIRouter):
    """
    Create V1 API endpoints

    Args:
        router: V1 APIRouter instance
    """

    @router.get("/health")
    async def health_check_v1():
        """Health check endpoint for API V1"""
        return {
            "status": "healthy",
            "version": "v1",
            "message": "Gold Price Predictor API V1"
        }

    @router.get("/info")
    async def api_info_v1():
        """API information endpoint for V1"""
        return {
            "version": "v1",
            "supported_versions": APIVersion.SUPPORTED_VERSIONS,
            "deprecated_versions": APIVersion.DEPRECATED_VERSIONS,
            "latest_version": APIVersion.get_latest_version()
        }


def create_v2_endpoints(router: APIRouter):
    """
    Create V2 API endpoints (with improvements)

    Args:
        router: V2 APIRouter instance
    """

    @router.get("/health")
    async def health_check_v2():
        """Health check endpoint for API V2 (enhanced)"""
        return {
            "status": "healthy",
            "version": "v2",
            "message": "Gold Price Predictor API V2",
            "features": [
                "Enhanced security",
                "Better performance",
                "Improved error handling"
            ]
        }

    @router.get("/info")
    async def api_info_v2():
        """API information endpoint for V2 (enhanced)"""
        return {
            "version": "v2",
            "supported_versions": APIVersion.SUPPORTED_VERSIONS,
            "deprecated_versions": APIVersion.DEPRECATED_VERSIONS,
            "latest_version": APIVersion.get_latest_version(),
            "changelog": {
                "v2": [
                    "Added JWT blacklisting",
                    "Enhanced input sanitization",
                    "Improved database indexing",
                    "Added circuit breakers"
                ],
                "v1": [
                    "Initial release",
                    "Basic authentication",
                    "Core prediction features"
                ]
            }
        }


def setup_api_versioning(app: FastAPI) -> APIVersion:
    """
    Setup API versioning for the application

    Args:
        app: FastAPI application instance

    Returns:
        APIVersion manager instance
    """
    api_version = APIVersion(app)

    # Create routers for different versions
    v1_router = api_version.create_router("v1", tags=["API V1"])
    v2_router = api_version.create_router("v2", tags=["API V2"])

    # Setup endpoints for each version
    create_v1_endpoints(v1_router)
    create_v2_endpoints(v2_router)

    # Register all routers
    api_version.register_all_routers()

    logger.info("API versioning setup completed")
    return api_version
