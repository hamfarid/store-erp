# /home/ubuntu/gold-price-predictor/database.py
"""
إعدادات قاعدة البيانات PostgreSQL
PostgreSQL Database Configuration
"""

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

# قراءة إعدادات قاعدة البيانات من المتغيرات البيئية
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://gold_user:gold_password@localhost:5432/gold_predictor_db"
)

# إنشاء Engine
engine = create_engine(DATABASE_URL)

# إنشاء SessionLocal
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class للنماذج
Base = declarative_base()


# نموذج المستخدمين
class UserDB(Base):
    """نموذج المستخدمين في قاعدة البيانات"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True)
    full_name = Column(String)
    hashed_password = Column(String, nullable=False)
    disabled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# نموذج التنبؤات
class PredictionDB(Base):
    """نموذج التنبؤات في قاعدة البيانات"""
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    symbol = Column(String, index=True, nullable=False)
    horizon = Column(String, nullable=False)
    predicted_price = Column(Float, nullable=False)
    confidence_level = Column(Float, default=0.95)
    model_used = Column(String)
    model_accuracy = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


# نموذج الأصول
class AssetDB(Base):
    """نموذج الأصول في قاعدة البيانات"""
    __tablename__ = "assets"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    category = Column(String, index=True)
    description = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


def get_db():
    """
    الحصول على جلسة قاعدة البيانات
    
    Yields:
        Session: جلسة قاعدة البيانات
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """
    تهيئة قاعدة البيانات وإنشاء الجداول
    """
    Base.metadata.create_all(bind=engine)
    print("✅ Database initialized successfully")


def seed_assets(db):
    """
    إضافة البيانات الأولية للأصول
    
    Args:
        db: جلسة قاعدة البيانات
    """
    assets = [
        {"symbol": "GC=F", "name": "Gold", "category": "Precious Metals"},
        {"symbol": "SI=F", "name": "Silver", "category": "Precious Metals"},
        {"symbol": "PL=F", "name": "Platinum", "category": "Precious Metals"},
        {"symbol": "PA=F", "name": "Palladium", "category": "Precious Metals"},
        {"symbol": "CL=F", "name": "Crude Oil", "category": "Energy"},
        {"symbol": "BZ=F", "name": "Brent Oil", "category": "Energy"},
        {"symbol": "NG=F", "name": "Natural Gas", "category": "Energy"},
        {"symbol": "HG=F", "name": "Copper", "category": "Industrial Metals"},
        {"symbol": "BTC-USD", "name": "Bitcoin", "category": "Cryptocurrency"},
        {"symbol": "ETH-USD", "name": "Ethereum", "category": "Cryptocurrency"},
        {"symbol": "TRYUSD=X", "name": "TRY/USD", "category": "Currency"},
        {"symbol": "EGPUSD=X", "name": "EGP/USD", "category": "Currency"},
        {"symbol": "EURUSD=X", "name": "EUR/USD", "category": "Currency"},
        {"symbol": "SARUSD=X", "name": "SAR/USD", "category": "Currency"},
        {"symbol": "AEDUSD=X", "name": "AED/USD", "category": "Currency"},
        {"symbol": "OMRUSD=X", "name": "OMR/USD", "category": "Currency"},
        {"symbol": "DX-Y.NYB", "name": "Dollar Index", "category": "Index"},
    ]
    
    for asset_data in assets:
        # التحقق من عدم وجود الأصل
        existing = db.query(AssetDB).filter(AssetDB.symbol == asset_data["symbol"]).first()
        if not existing:
            asset = AssetDB(**asset_data)
            db.add(asset)
    
    db.commit()
    print("✅ Assets seeded successfully")


def seed_users(db):
    """
    إضافة المستخدمين الأوليين
    
    Args:
        db: جلسة قاعدة البيانات
    """
    from auth_argon2 import get_password_hash
    
    users = [
        {
            "username": "admin",
            "email": "admin@example.com",
            "full_name": "System Administrator",
            "hashed_password": get_password_hash("admin123"),
            "disabled": False
        },
        {
            "username": "user",
            "email": "user@example.com",
            "full_name": "Regular User",
            "hashed_password": get_password_hash("user123"),
            "disabled": False
        }
    ]
    
    for user_data in users:
        # التحقق من عدم وجود المستخدم
        existing = db.query(UserDB).filter(UserDB.username == user_data["username"]).first()
        if not existing:
            user = UserDB(**user_data)
            db.add(user)
    
    db.commit()
    print("✅ Users seeded successfully")


if __name__ == "__main__":
    print("Initializing database...")
    init_db()
    
    # إضافة البيانات الأولية
    db = SessionLocal()
    try:
        seed_assets(db)
        seed_users(db)
    finally:
        db.close()
    
    print("✅ Database setup completed!")

