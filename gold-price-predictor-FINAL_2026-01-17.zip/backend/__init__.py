"""
Backend package for Gold Price Predictor
FILE: backend/__init__.py | PURPOSE: Make backend a Python package | OWNER: Backend Team
"""
