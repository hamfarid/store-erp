import sys
import os
import logging

# Configure logging to stdout
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

sys.path.insert(0, os.getcwd())

print("Step 1: Path setup complete")

try:
    print("Step 2A: Checking app.config_secure...")
    import app.config_secure
    print("OK: app.config_secure")

    print("Step 2B: Checking app.database_enhanced...")
    import app.database_enhanced
    print("OK: app.database_enhanced")
    
    print("Step 2C: Checking app.services.secrets_manager...")
    import app.services.secrets_manager
    print("OK: app.services.secrets_manager")

    print("Step 3: Importing app.main...")
    from app.main import app
    print("Step 3: Imported app.main successfully.")
except Exception as e:
    print(f"Import failed: {e}")
    logger.exception("Full traceback:")
