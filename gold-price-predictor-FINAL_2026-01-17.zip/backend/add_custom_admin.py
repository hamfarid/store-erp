import sys
sys.path.insert(0, '.')
# pylint: disable=wrong-import-position
from app.database_enhanced import get_db, User
from app.auth_postgresql import hash_password

db = next(get_db())
custom_admin = db.query(User).filter(User.email == "hady.m.farid@gmail.com").first()
if not custom_admin:
    custom_admin = User(
        username="Hamfarid",
        email="hady.m.farid@gmail.com",
        hashed_password=hash_password("HaRrMa123!@#"),
        is_admin=True,
        is_active=True
    )
    db.add(custom_admin)
    db.commit()
    print("✅ Custom admin created: Hamfarid / HaRrMa123!@#")
else:
    print("✅ Custom admin already exists")
db.close()
