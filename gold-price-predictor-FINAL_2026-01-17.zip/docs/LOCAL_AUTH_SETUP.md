# نظام تسجيل الدخول المحلي - دليل الإعداد

## 📋 نظرة عامة

تم إضافة نظام تسجيل دخول محلي كامل إلى التطبيق، يعمل بشكل مستقل عن Manus OAuth.

## 🔐 الميزات

- ✅ تسجيل دخول بالبريد الإلكتروني وكلمة المرور
- ✅ تسجيل مستخدمين جدد
- ✅ تشفير كلمات المرور باستخدام bcrypt
- ✅ التحقق من قوة كلمة المرور
- ✅ إدارة الجلسات باستخدام JWT
- ✅ مستخدم Admin افتراضي

## 🚀 بيانات تسجيل الدخول الافتراضية

**مستخدم Admin:**
- **البريد الإلكتروني**: `admin@example.com`
- **كلمة المرور**: `Admin@123`

⚠️ **مهم جداً**: يرجى تغيير كلمة المرور بعد أول تسجيل دخول!

## 📁 الملفات المضافة/المعدلة

### Backend

1. **`server/_core/auth-local.ts`** - دوال المصادقة المحلية
   - `hashPassword()` - تشفير كلمة المرور
   - `verifyPassword()` - التحقق من كلمة المرور
   - `generateUserId()` - توليد معرف مستخدم فريد
   - `isValidEmail()` - التحقق من صحة البريد الإلكتروني
   - `getPasswordValidationError()` - التحقق من قوة كلمة المرور

2. **`server/db-sqlite.ts`** - دوال قاعدة البيانات
   - `getUserByEmail()` - جلب مستخدم بالبريد الإلكتروني
   - `createUser()` - إنشاء مستخدم جديد
   - تحديث `upsertUser()` لدعم passwordHash

3. **`server/routers.ts`** - Auth Router
   - `auth.register` - تسجيل مستخدم جديد
   - `auth.login` - تسجيل الدخول

4. **`drizzle/schema.ts`** - Schema
   - إضافة حقل `passwordHash` إلى جدول users

5. **`server/migrations/001_add_password_to_users.ts`** - Migration
   - إضافة عمود passwordHash
   - إنشاء مستخدم admin افتراضي

### Frontend

1. **`client/src/pages/Login.tsx`** - صفحة تسجيل الدخول
   - نموذج تسجيل دخول محلي
   - التحقق من البيانات
   - معالجة الأخطاء

2. **`client/src/pages/Register.tsx`** - صفحة التسجيل
   - نموذج تسجيل مستخدم جديد
   - التحقق من قوة كلمة المرور
   - تأكيد كلمة المرور

3. **`client/src/pages/Home.tsx`** - الصفحة الرئيسية
   - أزرار تسجيل الدخول والتسجيل
   - إزالة OAuth

4. **`client/src/App.tsx`** - Routes
   - إضافة route `/register`

### Scripts

1. **`server/scripts/create-admin.ts`** - إنشاء مستخدم admin
2. **`server/scripts/check-users.ts`** - التحقق من المستخدمين

## 🔧 كيفية الاستخدام

### 1. تسجيل الدخول

1. افتح `http://localhost:2505/login`
2. أدخل البريد الإلكتروني وكلمة المرور
3. اضغط "تسجيل الدخول"

### 2. تسجيل مستخدم جديد

1. افتح `http://localhost:2505/register`
2. أدخل الاسم والبريد الإلكتروني وكلمة المرور
3. اضغط "إنشاء حساب"

### 3. إنشاء مستخدم admin يدوياً

```bash
npx tsx server/scripts/create-admin.ts
```

### 4. التحقق من المستخدمين

```bash
npx tsx server/scripts/check-users.ts
```

## 📝 متطلبات كلمة المرور

- الحد الأدنى: 8 أحرف
- يجب أن تحتوي على:
  - حرف كبير واحد على الأقل (A-Z)
  - حرف صغير واحد على الأقل (a-z)
  - رقم واحد على الأقل (0-9)
  - رمز خاص واحد على الأقل (!@#$%^&*)

## 🔒 الأمان

- ✅ تشفير كلمات المرور باستخدام bcrypt (cost factor: 10)
- ✅ التحقق من صحة البريد الإلكتروني
- ✅ التحقق من قوة كلمة المرور
- ✅ حماية من SQL Injection (parameterized queries)
- ✅ JWT للجلسات
- ✅ معالجة آمنة للأخطاء

## 🐛 استكشاف الأخطاء

### المشكلة: لا يمكن تسجيل الدخول

1. تحقق من أن السيرفر يعمل: `http://localhost:2505/`
2. تحقق من بيانات الدخول
3. تحقق من Console في المتصفح (F12)
4. تحقق من سجلات السيرفر

### المشكلة: "User not found"

1. تحقق من أن المستخدم موجود:
   ```bash
   npx tsx server/scripts/check-users.ts
   ```
2. إذا لم يكن موجوداً، أنشئ مستخدم admin:
   ```bash
   npx tsx server/scripts/create-admin.ts
   ```

### المشكلة: "Invalid password"

1. تحقق من كلمة المرور
2. استخدم كلمة المرور الافتراضية: `Admin@123`
3. إذا نسيت كلمة المرور، احذف المستخدم وأنشئه من جديد

## 📚 API Endpoints

### POST `/api/trpc/auth.register`

تسجيل مستخدم جديد

**Request:**
```json
{
  "name": "أحمد محمد",
  "email": "ahmed@example.com",
  "password": "SecurePass123!"
}
```

**Response:**
```json
{
  "sessionToken": "jwt_token_here"
}
```

### POST `/api/trpc/auth.login`

تسجيل الدخول

**Request:**
```json
{
  "email": "admin@example.com",
  "password": "Admin@123"
}
```

**Response:**
```json
{
  "sessionToken": "jwt_token_here"
}
```

## 🎯 الخطوات التالية

- [ ] إضافة "نسيت كلمة المرور"
- [ ] إضافة تأكيد البريد الإلكتروني
- [ ] إضافة MFA (Two-Factor Authentication)
- [ ] إضافة تسجيل الدخول بـ Google/Facebook
- [ ] إضافة صفحة تغيير كلمة المرور
- [ ] إضافة صفحة إدارة المستخدمين (Admin)

## 📞 الدعم

إذا واجهت أي مشاكل، يرجى:
1. التحقق من هذا الدليل
2. التحقق من سجلات السيرفر
3. التحقق من Console في المتصفح
4. فتح issue في GitHub

