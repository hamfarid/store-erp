# Environment Variables Documentation

This document describes all environment variables required for the Gold Price Predictor application.

## Required Variables

### Core Configuration

#### `NODE_ENV`
- **Type:** `string`
- **Values:** `development` | `production` | `test`
- **Default:** `development`
- **Description:** Node.js environment mode
- **Required:** No

#### `PORT`
- **Type:** `number`
- **Default:** `3000`
- **Description:** Port number for the server to listen on
- **Required:** No

### Security

#### `JWT_SECRET`
- **Type:** `string`
- **Default:** `development-secret-key-do-not-use-in-production-32chars` (development only)
- **Description:** Secret key for signing JWT tokens. **MUST be set in production**
- **Required:** Yes (in production)
- **Security:** Generate a secure random string: `openssl rand -base64 32`
- **Minimum Length:** 32 characters

### Database

#### `DATABASE_URL`
- **Type:** `string`
- **Default:** `file:./data/asset_predictor.db` (SQLite)
- **Description:** Database connection URL
- **Required:** No
- **Examples:**
  - SQLite: `file:./data/asset_predictor.db`
  - MySQL: `mysql://user:password@localhost:3306/gold_predictor`
  - PostgreSQL: `postgresql://user:password@localhost:5432/gold_predictor`

### OAuth Configuration (Optional)

#### `OAUTH_SERVER_URL`
- **Type:** `string`
- **Default:** `""` (empty)
- **Description:** OAuth server URL for external authentication
- **Required:** No

#### `OWNER_OPEN_ID`
- **Type:** `string`
- **Default:** `""` (empty)
- **Description:** Owner's OpenID for OAuth
- **Required:** No

### Application Configuration

#### `VITE_APP_ID`
- **Type:** `string`
- **Default:** `gold-predictor`
- **Description:** Application identifier
- **Required:** No

### Forge API Configuration (Optional)

#### `BUILT_IN_FORGE_API_URL`
- **Type:** `string`
- **Default:** `""` (empty)
- **Description:** Forge API base URL
- **Required:** No

#### `BUILT_IN_FORGE_API_KEY`
- **Type:** `string`
- **Default:** `""` (empty)
- **Description:** Forge API key
- **Required:** No

## Development vs Production

### Development
- Uses default values for most variables
- SQLite database by default
- Development JWT secret (not secure)

### Production
- **MUST** set `JWT_SECRET` to a secure random value
- **MUST** set `NODE_ENV=production`
- **MUST** use a production database (MySQL/PostgreSQL)
- **MUST** set all API keys and secrets
- **MUST NOT** use default development secrets

## Security Best Practices

1. **Never commit `.env` files** to version control
2. **Use strong secrets** (minimum 32 characters for JWT_SECRET)
3. **Rotate secrets regularly** (document rotation process)
4. **Use different secrets** for development, staging, and production
5. **Store secrets securely** (use secret management services in production)

## Secrets Rotation Process

### JWT Secret Rotation

1. Generate new secret: `openssl rand -base64 32`
2. Update `JWT_SECRET` in production environment
3. Restart application
4. All existing sessions will be invalidated (users need to login again)

### Database Credentials Rotation

1. Create new database user with new password
2. Update `DATABASE_URL` in environment
3. Run migrations if needed
4. Restart application
5. Remove old database user after verification

## Example `.env` File

```env
# Development
NODE_ENV=development
PORT=3000
JWT_SECRET=development-secret-key-do-not-use-in-production-32chars
DATABASE_URL=file:./data/asset_predictor.db
VITE_APP_ID=gold-predictor

# OAuth (optional)
OAUTH_SERVER_URL=
OWNER_OPEN_ID=

# Forge API (optional)
BUILT_IN_FORGE_API_URL=
BUILT_IN_FORGE_API_KEY=
```

## Production Example

```env
# Production
NODE_ENV=production
PORT=3000
JWT_SECRET=<generate-secure-random-32-char-string>
DATABASE_URL=mysql://user:password@localhost:3306/gold_predictor
VITE_APP_ID=gold-predictor
OAUTH_SERVER_URL=https://oauth.example.com
OWNER_OPEN_ID=owner-id-here
BUILT_IN_FORGE_API_URL=https://api.forge.example.com
BUILT_IN_FORGE_API_KEY=<api-key-here>
```

## Verification

To verify all required environment variables are set:

```bash
# Check if JWT_SECRET is set (production)
if [ "$NODE_ENV" = "production" ] && [ -z "$JWT_SECRET" ]; then
  echo "ERROR: JWT_SECRET must be set in production"
  exit 1
fi
```

## Last Updated

2025-01-18

