# Security Testing Guide

This document outlines security testing procedures for the Gold Price Predictor application.

## CSRF Protection Testing

### Test 1: Missing CSRF Token
**Objective:** Verify that requests without CSRF token are rejected.

**Steps:**
1. Login to the application
2. Make a POST/PUT/DELETE request without `X-CSRF-Token` header
3. Expected: 403 Forbidden with error message

**Test Command:**
```bash
curl -X POST http://localhost:3000/api/trpc/auth.update \
  -H "Content-Type: application/json" \
  -H "Cookie: app_session_id=<session-token>" \
  -d '{"name": "Test User"}'
```

**Expected Response:**
```json
{
  "error": {
    "code": "CSRF_TOKEN_MISSING",
    "message": "CSRF token is required"
  }
}
```

### Test 2: Invalid CSRF Token
**Objective:** Verify that requests with invalid CSRF token are rejected.

**Steps:**
1. Login to the application
2. Get a valid CSRF token from `/api/csrf-token`
3. Make a request with a modified/invalid token
4. Expected: 403 Forbidden

**Test Command:**
```bash
# Get CSRF token
CSRF_TOKEN=$(curl -s http://localhost:3000/api/csrf-token \
  -H "Cookie: app_session_id=<session-token>" | jq -r '.csrfToken')

# Make request with invalid token
curl -X POST http://localhost:3000/api/trpc/auth.update \
  -H "Content-Type: application/json" \
  -H "Cookie: app_session_id=<session-token>" \
  -H "X-CSRF-Token: invalid-token-12345" \
  -d '{"name": "Test User"}'
```

### Test 3: Valid CSRF Token
**Objective:** Verify that requests with valid CSRF token are accepted.

**Steps:**
1. Login to the application
2. Get CSRF token from `/api/csrf-token`
3. Make a request with valid token
4. Expected: 200 OK

**Test Command:**
```bash
# Get CSRF token
CSRF_TOKEN=$(curl -s http://localhost:3000/api/csrf-token \
  -H "Cookie: app_session_id=<session-token>" | jq -r '.csrfToken')

# Make request with valid token
curl -X POST http://localhost:3000/api/trpc/auth.update \
  -H "Content-Type: application/json" \
  -H "Cookie: app_session_id=<session-token>" \
  -H "X-CSRF-Token: $CSRF_TOKEN" \
  -d '{"name": "Test User"}'
```

## SQL Injection Testing

### Test 1: Parameterized Queries
**Objective:** Verify that all database queries use parameterized statements.

**Manual Review:**
- ✅ All queries in `server/db-sqlite.ts` use `prepare()` with `?` placeholders
- ✅ All queries in `server/db-learning-control.ts` use Drizzle ORM (parameterized automatically)
- ✅ No string concatenation in SQL queries

**Test Command (Attempt SQL Injection):**
```bash
# Attempt SQL injection in login
curl -X POST http://localhost:3000/api/trpc/auth.login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "password\"; DROP TABLE users; --"
  }'
```

**Expected:** Query should fail safely, no table deletion should occur.

### Test 2: Search Query Injection
**Objective:** Test search functionality for SQL injection.

**Test Command:**
```bash
curl -X GET "http://localhost:3000/api/trpc/users.list?search=%27%20OR%201%3D1%20--" \
  -H "Cookie: app_session_id=<session-token>"
```

**Expected:** Should return empty results or error, not all users.

## XSS (Cross-Site Scripting) Testing

### Test 1: Input Sanitization
**Objective:** Verify that user input is sanitized.

**Test Command:**
```bash
# Attempt XSS in user name
curl -X POST http://localhost:3000/api/trpc/auth.update \
  -H "Content-Type: application/json" \
  -H "Cookie: app_session_id=<session-token>" \
  -H "X-CSRF-Token: <csrf-token>" \
  -d '{"name": "<script>alert(\"XSS\")</script>"}'
```

**Expected:** Script tags should be sanitized/removed from stored data.

### Test 2: Reflected XSS
**Objective:** Test for reflected XSS in search/query parameters.

**Test Command:**
```bash
curl -X GET "http://localhost:3000/api/trpc/users.list?search=<script>alert('XSS')</script>" \
  -H "Cookie: app_session_id=<session-token>"
```

**Expected:** Response should not contain unescaped script tags.

## Password Strength Testing

### Test 1: Weak Password Rejection
**Objective:** Verify that weak passwords are rejected.

**Test Cases:**
- `password` (no uppercase, number, special char) - Should fail
- `Password` (no number, special char) - Should fail
- `Password1` (no special char) - Should fail
- `Password1!` - Should pass

**Test Command:**
```bash
curl -X POST http://localhost:3000/api/trpc/auth.register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "weak"
  }'
```

**Expected:** 400 Bad Request with password validation error.

### Test 2: Password Strength Indicator
**Objective:** Verify password strength indicator in frontend.

**Steps:**
1. Navigate to `/register`
2. Enter password: `password` - Should show "ضعيفة جداً"
3. Enter password: `Password1` - Should show "متوسطة"
4. Enter password: `Password1!` - Should show "قوية"

## Security Headers Testing

### Test 1: Verify Security Headers
**Objective:** Verify all security headers are present in responses.

**Test Command:**
```bash
curl -I http://localhost:3000/
```

**Expected Headers:**
- `X-Frame-Options: DENY`
- `X-XSS-Protection: 1; mode=block`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Content-Security-Policy: default-src 'self'; ...`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains` (if HTTPS)

### Test 2: CSP Violation Testing
**Objective:** Test Content Security Policy enforcement.

**Steps:**
1. Open browser DevTools
2. Navigate to application
3. Check Console for CSP violations
4. Expected: No violations for legitimate resources

## Token Security Testing

### Test 1: Token Expiration
**Objective:** Verify access tokens expire after 15 minutes.

**Steps:**
1. Login and get access token
2. Wait 16 minutes
3. Make authenticated request
4. Expected: 401 Unauthorized, redirect to login

### Test 2: Token Blacklisting
**Objective:** Verify blacklisted tokens are rejected.

**Steps:**
1. Login and get access token
2. Logout (token should be blacklisted)
3. Attempt to use blacklisted token
4. Expected: 401 Unauthorized

### Test 3: Refresh Token Rotation
**Objective:** Verify refresh tokens are rotated on use.

**Steps:**
1. Login and get refresh token
2. Use refresh token to get new access token
3. Old refresh token should be invalid
4. New refresh token should be valid

## Rate Limiting Testing

### Test 1: Login Rate Limiting
**Objective:** Verify login rate limiting (5 attempts per 15 minutes).

**Test Command:**
```bash
# Attempt 6 logins with wrong password
for i in {1..6}; do
  curl -X POST http://localhost:3000/api/trpc/auth.login \
    -H "Content-Type: application/json" \
    -d '{"email": "test@example.com", "password": "wrong"}'
  echo ""
done
```

**Expected:** 6th attempt should return 429 Too Many Requests.

### Test 2: Account Lockout
**Objective:** Verify account is locked after 5 failed attempts.

**Steps:**
1. Attempt 5 failed logins
2. Account should be locked for 30 minutes
3. Attempt login with correct password
4. Expected: Account locked error

## File Upload Testing (If Applicable)

### Test 1: File Size Limit
**Objective:** Verify file size limits are enforced.

**Test Command:**
```bash
# Create a large file (11MB)
dd if=/dev/zero of=large_file.txt bs=1M count=11

# Attempt upload
curl -X POST http://localhost:3000/api/upload \
  -H "Cookie: app_session_id=<session-token>" \
  -F "file=@large_file.txt"
```

**Expected:** 413 Payload Too Large or 400 Bad Request.

### Test 2: File Type Validation
**Objective:** Verify only allowed file types are accepted.

**Test Command:**
```bash
# Attempt to upload executable file
curl -X POST http://localhost:3000/api/upload \
  -H "Cookie: app_session_id=<session-token>" \
  -F "file=@malicious.exe"
```

**Expected:** 400 Bad Request with file type error.

## Session Security Testing

### Test 1: Session Hijacking Protection
**Objective:** Verify session security validation.

**Steps:**
1. Login from one IP address
2. Attempt to use session from different IP
3. Expected: Session invalidated or warning logged

### Test 2: Session Timeout
**Objective:** Verify sessions expire after inactivity.

**Steps:**
1. Login
2. Wait for session timeout period
3. Make authenticated request
4. Expected: 401 Unauthorized

## Automated Testing

### Running Security Tests

```bash
# Run all security tests (when implemented)
pnpm test:security

# Run specific test suite
pnpm test:security -- --grep "CSRF"
pnpm test:security -- --grep "SQL Injection"
pnpm test:security -- --grep "XSS"
```

## Security Checklist

- [ ] CSRF protection enabled on all state-changing endpoints
- [ ] All SQL queries use parameterized statements
- [ ] Input sanitization enabled for all user inputs
- [ ] Password strength validation enforced
- [ ] Security headers present in all responses
- [ ] Token expiration and rotation implemented
- [ ] Rate limiting enabled for authentication endpoints
- [ ] Account lockout after failed attempts
- [ ] File upload validation (size, type, content)
- [ ] Session security validation enabled

## Reporting Security Issues

If you discover a security vulnerability, please:
1. **DO NOT** create a public issue
2. Email security team with details
3. Include steps to reproduce
4. Wait for confirmation before disclosure

## Last Updated

2025-01-18

