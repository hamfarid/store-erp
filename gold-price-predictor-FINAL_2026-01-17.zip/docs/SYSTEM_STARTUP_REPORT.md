# System Startup Report
**Generated:** $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

## Container Status

### Running Containers
- ✅ PostgreSQL (gold-predictor-db)
- ✅ Redis (gold-predictor-redis)
- ✅ Backend (gold-predictor-backend)
- ✅ Frontend (gold-predictor-frontend)
- ✅ ML Service (gold-predictor-ml)
- ✅ Grafana (gold-predictor-grafana)
- ✅ Prometheus (gold-predictor-prometheus)
- ✅ Portainer (gold-predictor-portainer)

## Service URLs

### Application Services
- **Frontend:** http://localhost:2505
- **Backend API:** http://localhost:2005
- **ML Service:** http://localhost:2105

### Monitoring Services
- **Grafana:** http://localhost:3001
- **Prometheus:** http://localhost:9090
- **Portainer:** http://localhost:9000

### Database Services
- **PostgreSQL:** localhost:5432
- **Redis:** localhost:6379

## Health Checks

Run the following commands to verify services:

```bash
# Check PostgreSQL
docker exec gold-predictor-db pg_isready -U postgres

# Check Redis
docker exec gold-predictor-redis redis-cli ping

# Check Frontend
curl http://localhost:2505

# Check Backend
curl http://localhost:2005/health

# Check ML Service
curl http://localhost:2105/health
```

## Useful Commands

```bash
# View logs
npm run logs:prod

# Stop all services
npm run stop:prod

# Restart services
npm run restart:prod

# View container status
docker-compose -f docker-compose.production.yml ps

# View resource usage
docker stats
```

