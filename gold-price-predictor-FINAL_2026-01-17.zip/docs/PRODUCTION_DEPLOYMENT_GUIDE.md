# Production Deployment Guide

**Purpose:** Deploy Gold Price Predictor to production environment  
**Date:** 2025-01-18  
**Owner:** DevOps Team

---

## Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Deployment Steps](#deployment-steps)
3. [Post-Deployment Verification](#post-deployment-verification)
4. [Rollback Procedure](#rollback-procedure)
5. [Monitoring](#monitoring)

---

## Pre-Deployment Checklist

### Code Quality
- [ ] All tests passing (90+ test cases)
- [ ] Code coverage ≥80% (backend), ≥70% (frontend)
- [ ] No critical or high-severity bugs
- [ ] Code review completed
- [ ] Security audit passed

### Testing
- [ ] Staging deployment successful
- [ ] Load testing completed (500+ concurrent users)
- [ ] Security audit completed (OWASP ZAP, Bandit, Safety)
- [ ] UAT completed and signed off
- [ ] Performance targets met (<200ms p95 for GET)

### Infrastructure
- [ ] Production database created and configured
- [ ] Redis cache configured
- [ ] AWS Secrets Manager configured
- [ ] SSL certificates installed
- [ ] DNS configured
- [ ] CDN configured (if applicable)
- [ ] Backup system configured

### Documentation
- [ ] API documentation updated
- [ ] User guide updated
- [ ] Admin guide updated
- [ ] Runbook updated
- [ ] Rollback procedure documented

### Communication
- [ ] Stakeholders notified
- [ ] Maintenance window scheduled
- [ ] Support team briefed
- [ ] Users notified (if downtime expected)

---

## Deployment Steps

### Step 1: Pre-Deployment Backup

```bash
# Backup production database (if exists)
pg_dump -h prod-db.example.com -U prod_user -d gold_predictor_prod > backup_pre_deploy_$(date +%Y%m%d_%H%M%S).sql

# Upload to S3
aws s3 cp backup_pre_deploy_*.sql s3://gold-predictor-backups/pre-deployment/

# Verify backup
aws s3 ls s3://gold-predictor-backups/pre-deployment/
```

### Step 2: Database Migration

```bash
# Connect to production database
export DATABASE_URL=postgresql://prod_user:PROD_PASSWORD@prod-db.example.com:5432/gold_predictor_prod

# Run migrations
cd backend
alembic upgrade head

# Verify migrations
alembic current
alembic history

# Check database health
psql $DATABASE_URL -c "SELECT COUNT(*) FROM users;"
```

### Step 3: Build and Tag Docker Images

```bash
# Build backend image
docker build -t gold-predictor-backend:v1.0.0 -f backend/Dockerfile .

# Build frontend image
docker build -t gold-predictor-frontend:v1.0.0 -f client/Dockerfile .

# Tag for registry
docker tag gold-predictor-backend:v1.0.0 registry.example.com/gold-predictor-backend:v1.0.0
docker tag gold-predictor-frontend:v1.0.0 registry.example.com/gold-predictor-frontend:v1.0.0

# Push to registry
docker push registry.example.com/gold-predictor-backend:v1.0.0
docker push registry.example.com/gold-predictor-frontend:v1.0.0
```

### Step 4: Deploy to Production

**Option A: Docker Compose**

```bash
# Pull latest images
docker-compose -f docker-compose.prod.yml pull

# Stop old containers
docker-compose -f docker-compose.prod.yml down

# Start new containers
docker-compose -f docker-compose.prod.yml up -d

# Check status
docker-compose -f docker-compose.prod.yml ps
```

**Option B: Kubernetes**

```bash
# Apply production namespace
kubectl apply -f k8s/prod/namespace.yaml

# Apply ConfigMaps and Secrets
kubectl apply -f k8s/prod/configmap.yaml
kubectl apply -f k8s/prod/secrets.yaml

# Deploy application
kubectl apply -f k8s/prod/deployment.yaml
kubectl apply -f k8s/prod/service.yaml
kubectl apply -f k8s/prod/ingress.yaml

# Check deployment status
kubectl get pods -n production
kubectl get services -n production
kubectl get ingress -n production

# Wait for rollout to complete
kubectl rollout status deployment/gold-predictor-backend -n production
kubectl rollout status deployment/gold-predictor-frontend -n production
```

### Step 5: Smoke Tests

```bash
# Health check
curl https://api.goldpredictor.com/health

# Expected response:
{
  "status": "healthy",
  "database": "connected",
  "redis": "connected",
  "timestamp": "2025-01-18T00:00:00Z"
}

# Test login
curl -X POST https://api.goldpredictor.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "PROD_ADMIN_PASSWORD"}'

# Expected: 200 OK with access_token

# Test API endpoint
curl -X GET https://api.goldpredictor.com/api/assets \
  -H "Authorization: Bearer $TOKEN"

# Expected: 200 OK with assets list
```

---

## Post-Deployment Verification

### 1. Functional Testing

```bash
# Run smoke tests
npm run test:smoke:production

# Test critical user journeys
# - Login
# - Create prediction
# - Create alert
# - View dashboard
```

### 2. Performance Testing

```bash
# Run quick load test
locust -f performance/locustfile.py \
  --host=https://api.goldpredictor.com \
  --headless \
  --users 100 \
  --spawn-rate 10 \
  --run-time 5m

# Check response times
# Expected: p95 < 200ms for GET requests
```

### 3. Monitoring Verification

```bash
# Check Prometheus targets
curl https://prometheus.goldpredictor.com/api/v1/targets

# Check Grafana dashboards
# Navigate to https://grafana.goldpredictor.com
# Verify all panels showing data

# Check logs
kubectl logs -f deployment/gold-predictor-backend -n production
```

### 4. Security Verification

```bash
# Verify HTTPS
curl -I https://goldpredictor.com
# Expected: 200 OK (not redirect)

# Verify HTTP redirect
curl -I http://goldpredictor.com
# Expected: 301 Redirect to https://

# Verify security headers
curl -I https://goldpredictor.com
# Expected headers:
# - Strict-Transport-Security
# - X-Frame-Options: DENY
# - X-Content-Type-Options: nosniff
# - Content-Security-Policy
```

---

## Rollback Procedure

### When to Rollback

- Critical bugs discovered
- Performance degradation
- Data corruption
- Security vulnerability
- High error rate (>5%)

### Rollback Steps

**Option A: Docker Compose**

```bash
# Stop current containers
docker-compose -f docker-compose.prod.yml down

# Deploy previous version
docker-compose -f docker-compose.prod.yml up -d --force-recreate

# Verify rollback
docker-compose -f docker-compose.prod.yml ps
```

**Option B: Kubernetes**

```bash
# Rollback deployment
kubectl rollout undo deployment/gold-predictor-backend -n production
kubectl rollout undo deployment/gold-predictor-frontend -n production

# Check rollback status
kubectl rollout status deployment/gold-predictor-backend -n production
kubectl rollout status deployment/gold-predictor-frontend -n production

# Verify pods running
kubectl get pods -n production
```

### Database Rollback

```bash
# Rollback migrations
cd backend
alembic downgrade -1

# Or restore from backup
psql $DATABASE_URL < backup_pre_deploy_YYYYMMDD_HHMMSS.sql

# Verify database state
psql $DATABASE_URL -c "SELECT COUNT(*) FROM users;"
```

---

## Monitoring

### Key Metrics to Monitor

**Application Metrics:**
- Request rate (requests/second)
- Response time (p50, p95, p99)
- Error rate (%)
- Active users

**Infrastructure Metrics:**
- CPU usage (%)
- Memory usage (%)
- Disk usage (%)
- Network traffic (MB/s)

**Database Metrics:**
- Connection count
- Query performance
- Replication lag (if applicable)
- Disk usage

**Business Metrics:**
- New user registrations
- Predictions generated
- Alerts created
- Active sessions

### Alerts

**Critical Alerts (PagerDuty):**
- Error rate > 5%
- Response time p95 > 1000ms
- Database connection failures
- Service down

**Warning Alerts (Slack):**
- Error rate > 1%
- Response time p95 > 500ms
- CPU usage > 80%
- Memory usage > 80%

---

## Production Deployment Checklist

### Pre-Deployment
- [ ] All tests passing
- [ ] Security audit passed
- [ ] UAT signed off
- [ ] Backup created
- [ ] Stakeholders notified

### Deployment
- [ ] Database migrated
- [ ] Docker images built and pushed
- [ ] Application deployed
- [ ] Smoke tests passed

### Post-Deployment
- [ ] Functional testing passed
- [ ] Performance testing passed
- [ ] Monitoring verified
- [ ] Security verified
- [ ] No critical errors in logs

### Communication
- [ ] Deployment announcement sent
- [ ] Support team notified
- [ ] Documentation updated
- [ ] Post-deployment report created

---

## Deployment Schedule

**Recommended Time:** Saturday 2:00 AM - 6:00 AM (low traffic)

| Time | Activity | Duration | Owner |
|------|----------|----------|-------|
| 02:00 | Pre-deployment backup | 15 min | DevOps |
| 02:15 | Database migration | 15 min | DevOps |
| 02:30 | Build and push images | 20 min | DevOps |
| 02:50 | Deploy to production | 20 min | DevOps |
| 03:10 | Smoke tests | 15 min | QA |
| 03:25 | Functional testing | 30 min | QA |
| 03:55 | Performance testing | 30 min | QA |
| 04:25 | Monitoring verification | 15 min | DevOps |
| 04:40 | Final checks | 20 min | All |
| 05:00 | Go/No-Go decision | 10 min | All |
| 05:10 | Deployment announcement | 5 min | Product |

---

**Status:** Ready for production deployment  
**Last Updated:** 2025-01-18

