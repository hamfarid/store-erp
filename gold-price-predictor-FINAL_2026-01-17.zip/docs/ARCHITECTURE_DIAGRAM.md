# 🏗️ Architecture Diagrams - Gold Price Predictor V4

**Date**: 2026-01-15  
**Version**: V4.0.0

---

## 📐 System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          CLIENT LAYER                                │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Browser (React 19 + TypeScript)                             │  │
│  │                                                               │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │  │
│  │  │  Dashboard  │  │   Learning  │  │   Alerts    │         │  │
│  │  │    Page     │  │   Control   │  │    Page     │         │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘         │  │
│  │                                                               │  │
│  │  ┌─────────────────────────────────────────────────────┐    │  │
│  │  │         React Query (State Management)              │    │  │
│  │  └─────────────────────────────────────────────────────┘    │  │
│  │                                                               │  │
│  │  ┌─────────────────┐          ┌─────────────────┐           │  │
│  │  │  tRPC Client    │          │  WebSocket      │           │  │
│  │  │  (Type-safe)    │          │  Client         │           │  │
│  │  └─────────────────┘          └─────────────────┘           │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕                      ↕
                         HTTP/tRPC             WebSocket
                              ↕                      ↕
┌─────────────────────────────────────────────────────────────────────┐
│                          SERVER LAYER                                │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Node.js + Express + TypeScript                              │  │
│  │                                                               │  │
│  │  ┌─────────────────────────────────────────────────────┐    │  │
│  │  │            tRPC Router Layer (26 endpoints)         │    │  │
│  │  │                                                      │    │  │
│  │  │  • learningControl  • alerts      • predictions    │    │  │
│  │  │  • auth             • users       • assets         │    │  │
│  │  │  • notifications    • system                       │    │  │
│  │  └─────────────────────────────────────────────────────┘    │  │
│  │                                                               │  │
│  │  ┌───────────────────┐  ┌───────────────────┐              │  │
│  │  │  Business Logic   │  │   Job Queues      │              │  │
│  │  │                   │  │                   │              │  │
│  │  │ • Learning Orch.  │  │ • Learning Queue  │              │  │
│  │  │ • Search Orch.    │  │ • Search Queue    │              │  │
│  │  │ • Auth Service    │  │ • Background Jobs │              │  │
│  │  └───────────────────┘  └───────────────────┘              │  │
│  │                                                               │  │
│  │  ┌─────────────────────────────────────────────────────┐    │  │
│  │  │         WebSocket Manager (7 channels)              │    │  │
│  │  │                                                      │    │  │
│  │  │  • prices         • predictions    • alerts         │    │  │
│  │  │  • ml_progress    • drift_alerts                    │    │  │
│  │  │  • learning_updates • search_updates                │    │  │
│  │  └─────────────────────────────────────────────────────┘    │  │
│  │                                                               │  │
│  │  ┌─────────────────────────────────────────────────────┐    │  │
│  │  │         Database Layer (Drizzle ORM)                │    │  │
│  │  └─────────────────────────────────────────────────────┘    │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕
                             SQL
                              ↕
┌─────────────────────────────────────────────────────────────────────┐
│                          DATA LAYER                                  │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  PostgreSQL 14+ Database                                     │  │
│  │                                                               │  │
│  │  • 15 Tables                                                 │  │
│  │  • Indexed for performance                                   │  │
│  │  • Connection pooling (max 20)                               │  │
│  │  • Row-level security (RLS)                                  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagrams

### 1. Learning Operation Flow

```
┌───────────┐
│   User    │
│  Action   │
└─────┬─────┘
      │
      │ 1. Start Operation
      ↓
┌─────────────────┐
│  React UI       │
│  (Button Click) │
└─────┬───────────┘
      │
      │ 2. tRPC Mutation
      ↓
┌─────────────────────────┐
│  Learning Control Router│
│  (learning-control.ts)  │
└─────┬───────────────────┘
      │
      │ 3. Create DB Record (status: pending)
      ↓
┌─────────────────┐
│   PostgreSQL    │
└─────┬───────────┘
      │
      │ 4. Broadcast Created Event
      ↓
┌─────────────────┐
│  WebSocket      │ ────────┐
│  Manager        │         │
└─────┬───────────┘         │
      │                     │ Real-time Update
      │ 5. Add to Queue     │
      ↓                     ↓
┌─────────────────┐    ┌────────────┐
│  Job Queue      │    │  Frontend  │
│  (SimpleQueue)  │    │  (React)   │
└─────┬───────────┘    └────────────┘
      │
      │ 6. Process Job
      ↓
┌──────────────────────────┐
│  Learning Orchestrator   │
│  (LearningOrchestrator)  │
└─────┬────────────────────┘
      │
      │ 7. Execute Steps (with progress updates)
      ↓
┌──────────────────────────┐
│  Sub-Services            │
│  • PredictionComparator  │
│  • PatternDetector       │
│  • CorrelationAnalyzer   │
└─────┬────────────────────┘
      │
      │ 8. Update Progress (10%, 20%, ..., 100%)
      ↓
┌─────────────────┐
│  PostgreSQL     │
│  + WebSocket    │ ─────────────────┐
└─────────────────┘                  │
      │                              │
      │ 9. Complete                  │ Real-time Progress
      ↓                              ↓
┌─────────────────┐             ┌────────────┐
│  DB: status =   │             │  Frontend  │
│  'completed'    │             │  Progress  │
└─────────────────┘             │  Bar       │
                                 └────────────┘
```

### 2. Real-time Notification Flow

```
Backend Event Occurs
      │
      ↓
┌─────────────────────────┐
│  WebSocket Manager      │
│  broadcastXXXUpdate()   │
└─────────────────────────┘
      │
      ├──────────┬──────────┬──────────┐
      ↓          ↓          ↓          ↓
   Client 1   Client 2   Client 3   Client N
      │          │          │          │
      ↓          ↓          ↓          ↓
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│useWebSocket│ │useWebSocket│ │useWebSocket│ │useWebSocket│
│  Hook    │ │  Hook    │ │  Hook    │ │  Hook    │
└─────┬────┘ └─────┬────┘ └─────┬────┘ └─────┬────┘
      │          │          │          │
      ↓          ↓          ↓          ↓
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ React    │ │ React    │ │ React    │ │ React    │
│ Query    │ │ Query    │ │ Query    │ │ Query    │
│ Update   │ │ Update   │ │ Update   │ │ Update   │
└─────┬────┘ └─────┬────┘ └─────┬────┘ └─────┬────┘
      │          │          │          │
      ↓          ↓          ↓          ↓
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ UI       │ │ UI       │ │ UI       │ │ UI       │
│ Re-render│ │ Re-render│ │ Re-render│ │ Re-render│
└──────────┘ └──────────┘ └──────────┘ └──────────┘
```

### 3. Authentication Flow

```
User Login Attempt
      │
      ↓
┌─────────────────┐
│  Login Form     │
│  (email + pwd)  │
└─────┬───────────┘
      │
      │ 1. tRPC auth.login
      ↓
┌─────────────────────┐
│  Auth Router        │
│  (auth.ts)          │
└─────┬───────────────┘
      │
      │ 2. Verify credentials
      ↓
┌─────────────────────┐
│  bcrypt.compare()   │
└─────┬───────────────┘
      │
      ├─ Invalid ──→ Error Response
      │
      │ 3. Valid ──→ Generate JWT
      ↓
┌─────────────────────┐
│  jwt.sign()         │
│  + CSRF Token       │
│  + Session Info     │
└─────┬───────────────┘
      │
      │ 4. Return tokens + user
      ↓
┌─────────────────────┐
│  Frontend           │
│  • Store JWT        │
│  • Store user info  │
│  • Redirect         │
└─────┬───────────────┘
      │
      │ 5. Subsequent requests
      ↓
┌─────────────────────┐
│  Authorization:     │
│  Bearer <JWT>       │
└─────┬───────────────┘
      │
      │ 6. Verify JWT
      ↓
┌─────────────────────┐
│  jwt.verify()       │
│  + Check blacklist  │
│  + Validate session │
└─────┬───────────────┘
      │
      ├─ Invalid ──→ 401 Unauthorized
      │
      │ 7. Valid ──→ Process request
      ↓
┌─────────────────────┐
│  Protected Endpoint │
└─────────────────────┘
```

---

## 🗄️ Database Schema

```
┌────────────────────────────────────────────────────────────────┐
│                      CORE TABLES                                │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  users                    assets                   predictions  │
│  ├── id (PK)              ├── id (PK)              ├── id (PK) │
│  ├── email (unique)       ├── symbol               ├── asset_id│
│  ├── name                 ├── name_en              ├── model   │
│  ├── password_hash        ├── name_ar              ├── price   │
│  ├── role                 ├── type                 ├── time    │
│  └── preferences          └── category             └── conf.   │
│                                                                 │
│  alerts                   notifications            historical   │
│  ├── id (PK)              ├── id (PK)              ├── id (PK) │
│  ├── user_id (FK)         ├── user_id (FK)         ├── asset_id│
│  ├── asset_id (FK)        ├── type                 ├── price   │
│  ├── condition            ├── title                ├── volume  │
│  └── threshold            └── message              └── time    │
│                                                                 │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│              LEARNING CONTROL TABLES (Phase 7)                  │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  search_keywords          search_sources                        │
│  ├── id (PK)              ├── id (PK)                          │
│  ├── keyword              ├── name                             │
│  ├── category             ├── url                              │
│  ├── priority             ├── type                             │
│  └── active               ├── health                           │
│                           └── stats                             │
│                                                                 │
│  learning_operations      search_operations                     │
│  ├── id (PK)              ├── id (PK)                          │
│  ├── type                 ├── type                             │
│  ├── status               ├── status                           │
│  ├── progress             ├── progress                         │
│  ├── results              ├── keywords (array)                 │
│  └── error                └── sources (array)                  │
│                                                                 │
│  operation_logs                                                 │
│  ├── id (PK)                                                   │
│  ├── operation_id (FK)                                         │
│  ├── level (info/warn/error)                                  │
│  ├── message                                                   │
│  └── timestamp                                                 │
│                                                                 │
└────────────────────────────────────────────────────────────────┘

Relationships:
─────────────
users 1──∞ alerts
users 1──∞ notifications
assets 1──∞ alerts
assets 1──∞ predictions
assets 1──∞ historical_prices
learning_operations 1──∞ operation_logs
search_operations 1──∞ operation_logs
```

---

## 🎯 Component Architecture

### Frontend Component Tree

```
App
├── Providers
│   ├── QueryClientProvider (React Query)
│   ├── NotificationToastProvider (Sonner)
│   └── WebSocketProvider
│
├── Router (React Router)
│   ├── Public Routes
│   │   ├── / (Landing)
│   │   ├── /login
│   │   └── /register
│   │
│   └── Protected Routes
│       ├── /dashboard
│       │   ├── StatsCards
│       │   ├── PriceChart
│       │   └── RecentPredictions
│       │
│       ├── /learning-control
│       │   ├── Tabs
│       │   │   ├── OverviewTab
│       │   │   │   ├── StatisticsCards
│       │   │   │   └── ActiveOperations
│       │   │   │
│       │   │   ├── LearningTab
│       │   │   │   ├── OperationTypeCards
│       │   │   │   └── OperationHistory
│       │   │   │
│       │   │   ├── SearchTab
│       │   │   │   ├── SearchForm
│       │   │   │   └── SearchHistory
│       │   │   │
│       │   │   ├── KeywordsTab
│       │   │   │   ├── KeywordsTable
│       │   │   │   └── AddKeywordDialog
│       │   │   │
│       │   │   └── SourcesTab
│       │   │       ├── SourcesTable
│       │   │       └── AddSourceDialog
│       │   │
│       │   └── OperationCard (reusable)
│       │
│       ├── /alerts
│       │   ├── AlertsToolbar
│       │   ├── AlertsList
│       │   └── CreateAlertDialog
│       │
│       └── /predictions
│           ├── PredictionFilters
│           └── PredictionsGrid
│
└── Shared Components
    ├── Navigation
    ├── NotificationDropdown
    ├── ThemeToggle
    └── UI Components (shadcn/ui)
```

### Backend Module Architecture

```
server/
├── _core/
│   ├── index.ts (Express app setup)
│   ├── websocket.ts (WebSocket manager)
│   ├── security.ts (Auth, CSRF, rate limiting)
│   ├── vault.ts (Environment config)
│   ├── trpc.ts (tRPC setup)
│   └── validation.ts (Zod schemas)
│
├── routers/
│   ├── auth.ts
│   ├── users.ts
│   ├── assets.ts
│   ├── predictions.ts
│   ├── alerts.ts
│   ├── learning-control.ts ← Main router (26 endpoints)
│   └── system.ts
│
├── services/
│   ├── learning/
│   │   ├── LearningOrchestrator.ts
│   │   ├── PredictionComparator.ts
│   │   ├── PatternDetector.ts
│   │   └── CorrelationAnalyzer.ts
│   │
│   └── search/
│       ├── SearchOrchestrator.ts
│       ├── KeywordSearcher.ts
│       └── EventDiscoverer.ts
│
├── jobs/
│   ├── queues.ts (Queue setup)
│   ├── learningQueue.ts
│   └── searchQueue.ts
│
├── db-compat.ts (Database abstraction)
└── db-learning-control.ts (Learning CRUD)
```

---

## 🔌 API Architecture

### tRPC Endpoint Structure

```
/api/trpc/
│
├── auth.*
│   ├── login
│   ├── register
│   ├── logout
│   └── refresh
│
├── learningControl.*
│   ├── stats.get
│   │
│   ├── keywords.*
│   │   ├── list
│   │   ├── create
│   │   ├── update
│   │   └── delete
│   │
│   ├── sources.*
│   │   ├── list
│   │   ├── create
│   │   ├── update
│   │   └── delete
│   │
│   ├── learning.*
│   │   ├── list
│   │   ├── start
│   │   ├── cancel
│   │   └── get
│   │
│   ├── search.*
│   │   ├── list
│   │   ├── start
│   │   ├── cancel
│   │   └── get
│   │
│   └── logs.*
│       ├── list
│       └── get
│
├── alerts.*
│   ├── list
│   ├── create
│   ├── update
│   └── delete
│
└── predictions.*
    ├── list
    ├── create
    └── compare
```

### WebSocket Channels

```
ws://localhost:2507

Channels:
├── prices              → Real-time price updates
├── predictions         → New prediction notifications
├── alerts              → Alert trigger notifications
├── ml_progress         → ML model training progress
├── drift_alerts        → Model drift warnings
├── learning_updates    → Learning operation progress
└── search_updates      → Search operation progress

Message Format:
{
  "channel": "learning_updates",
  "data": {
    "id": "operation-123",
    "status": "running",
    "progress": 45,
    "currentStep": "تحليل البيانات...",
    "timestamp": 1705344000000
  }
}
```

---

## 🚀 Deployment Architecture

### Development
```
localhost:2507
├── Frontend (Vite dev server)
├── Backend (Express)
└── PostgreSQL (local)
```

### Production (Docker)
```
┌──────────────────────────────────────────┐
│             Nginx (Reverse Proxy)        │
│           Port 80/443 (HTTPS)            │
└─────────────────┬────────────────────────┘
                  │
        ┌─────────┼─────────┐
        │         │         │
        ↓         ↓         ↓
┌──────────┐ ┌──────────┐ ┌──────────┐
│ Frontend │ │ Backend  │ │ML Service│
│Container │ │Container │ │Container │
│(Port 80) │ │(Port3000)│ │(Port5000)│
└──────────┘ └────┬─────┘ └──────────┘
                   │
                   ↓
            ┌──────────────┐
            │  PostgreSQL  │
            │   Container  │
            │  (Port 5432) │
            └──────────────┘
```

### Kubernetes (Future)
```
┌────────────────────────────────────────────┐
│            Ingress Controller              │
└─────────────────┬──────────────────────────┘
                  │
        ┌─────────┼─────────┐
        │         │         │
        ↓         ↓         ↓
┌──────────┐ ┌──────────┐ ┌──────────┐
│Frontend  │ │Backend   │ │ML Service│
│ Service  │ │ Service  │ │ Service  │
│          │ │          │ │          │
│ Pod×3    │ │ Pod×3    │ │ Pod×2    │
└──────────┘ └────┬─────┘ └──────────┘
                   │
        ┌──────────┼──────────┐
        ↓          ↓          ↓
┌──────────┐ ┌──────────┐ ┌──────────┐
│PostgreSQL│ │  Redis   │ │Prometheus│
│StatefulS │ │ Service  │ │          │
└──────────┘ └──────────┘ └──────────┘
```

---

**Last Updated**: 2026-01-15  
**Version**: V4.0.0

