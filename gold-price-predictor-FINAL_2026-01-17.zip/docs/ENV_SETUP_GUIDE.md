# دليل إعداد ملف .env - Environment Variables Setup Guide

**FILE**: docs/ENV_SETUP_GUIDE.md  
**PURPOSE**: دليل شامل لإعداد جميع متغيرات البيئة  
**OWNER**: DevOps Team  
**LAST-AUDITED**: 2025-01-27

---

## 📋 الخطوات السريعة

### 1. إنشاء ملف `.env`

```bash
# نسخ ملف المثال
cp env.example .env

# أو في Windows PowerShell
Copy-Item env.example .env
```

### 2. تحديث القيم المطلوبة

افتح ملف `.env` وحدّث القيم التالية:

---

## ✅ الإعدادات المطلوبة (Required)

### 🔐 الأمان (Security)

```env
# مطلوب في الإنتاج - يجب أن يكون 32 حرف على الأقل
JWT_SECRET=your-super-secret-key-at-least-32-characters-long

# يمكن توليد مفتاح آمن باستخدام:
# openssl rand -base64 32
```

### 💾 قاعدة البيانات (Database)

```env
# SQLite (التطوير - افتراضي)
DATABASE_URL=file:./data/asset_predictor.db

# أو PostgreSQL (الإنتاج)
# DATABASE_URL=postgresql://user:password@localhost:5432/gold_predictor
```

### 📧 البريد الإلكتروني (Email - للتأكيد والإشعارات)

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@goldpredictor.com
```

**إعداد Gmail App Password:**
1. تفعيل التحقق بخطوتين في حساب Google
2. الذهاب إلى: https://myaccount.google.com/apppasswords
3. إنشاء كلمة مرور للتطبيق لـ "Mail"
4. استخدام كلمة المرور المُنشأة كـ `SMTP_PASS`

---

## ⚙️ الإعدادات الاختيارية (Optional)

### 🌐 التطبيق (Application)

```env
NODE_ENV=development
PORT=2505
VITE_APP_ID=gold-predictor
FRONTEND_URL=http://localhost:2505
```

### 🔴 Redis (Cache)

```env
REDIS_URL=redis://localhost:6379
REDIS_PASSWORD=
REDIS_ENABLED=false
```

### 🔑 مفاتيح API الخارجية (External API Keys)

```env
# News API (https://newsapi.org)
NEWS_API_KEY=your-news-api-key-here

# FRED API (https://fred.stlouisfed.org)
FRED_API_KEY=your-fred-api-key-here

# Alpha Vantage (https://www.alphavantage.co)
ALPHA_VANTAGE_API_KEY=your-alpha-vantage-api-key-here

# CoinGecko (https://www.coingecko.com)
COINGECKO_API_KEY=your-coingecko-api-key-here
```

### 🤖 خدمات AI (AI Services)

```env
# OpenAI (https://platform.openai.com)
OPENAI_API_KEY=your-openai-api-key-here

# Anthropic (https://www.anthropic.com)
ANTHROPIC_API_KEY=your-anthropic-api-key-here

# Google Gemini (https://ai.google.dev)
GEMINI_API_KEY=your-gemini-api-key-here
```

### 📊 المراقبة (Monitoring)

```env
PROMETHEUS_PORT=9090
GRAFANA_PORT=3001
GRAFANA_USER=admin
GRAFANA_PASSWORD=admin123
```

---

## 🔍 التحقق من الإعدادات

### فحص ملف `.env`

```bash
# في Linux/Mac
cat .env | grep -v "^#" | grep -v "^$"

# في Windows PowerShell
Get-Content .env | Where-Object { $_ -notmatch "^#" -and $_ -notmatch "^$" }
```

### التحقق من القيم المطلوبة

```bash
# فحص JWT_SECRET
node -e "console.log(process.env.JWT_SECRET?.length || 'NOT SET')"

# فحص DATABASE_URL
node -e "console.log(process.env.DATABASE_URL || 'NOT SET')"
```

---

## 🚨 أخطاء شائعة

### 1. JWT_SECRET قصير جداً

**الخطأ**: `JWT_SECRET must be at least 32 characters`

**الحل**: 
```bash
# توليد مفتاح آمن
openssl rand -base64 32
```

### 2. SMTP غير مُعد

**الخطأ**: `SMTP credentials not configured`

**الحل**: إضافة إعدادات SMTP في `.env` (انظر أعلاه)

### 3. DATABASE_URL غير صحيح

**الخطأ**: `Database connection failed`

**الحل**: 
- للتطوير: استخدام SQLite `file:./data/asset_predictor.db`
- للإنتاج: استخدام PostgreSQL أو MySQL مع URL صحيح

---

## 📝 قائمة التحقق (Checklist)

### قبل البدء

- [ ] ملف `.env` موجود في المجلد الرئيسي
- [ ] `JWT_SECRET` مُعد (32 حرف على الأقل)
- [ ] `DATABASE_URL` مُعد
- [ ] `SMTP_*` مُعد (للتأكيد بالإيميل)
- [ ] `FRONTEND_URL` مُعد

### للإنتاج

- [ ] جميع المفاتيح السرية تم تغييرها
- [ ] `NODE_ENV=production`
- [ ] `JWT_SECRET` قوي وآمن
- [ ] `DATABASE_URL` يشير إلى قاعدة بيانات إنتاج
- [ ] `SMTP_*` مُعد بشكل صحيح
- [ ] `ALLOWED_ORIGINS` محدث مع النطاق الصحيح

---

## 🔐 الأمان

### ⚠️ تحذيرات مهمة

1. **لا ترفع ملف `.env` إلى Git**
   - تأكد من وجود `.env` في `.gitignore`

2. **استخدم مفاتيح مختلفة للتطوير والإنتاج**

3. **لا تشارك ملف `.env` مع أي شخص**

4. **استخدم AWS Secrets Manager في الإنتاج** (اختياري)

---

## 📚 مراجع

- [env.example](../env.example) - ملف المثال الكامل
- [docs/ENV_CONFIGURATION.md](./ENV_CONFIGURATION.md) - توثيق تفصيلي
- [docs/ENVIRONMENT_VARIABLES.md](./ENVIRONMENT_VARIABLES.md) - قائمة كاملة

---

**آخر تحديث**: 2025-01-27

