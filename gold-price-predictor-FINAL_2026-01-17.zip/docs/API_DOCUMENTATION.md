# API Documentation

> This is the central entry point for API documentation.

## Core Resources
- [API Guide](API_GUIDE.md)
- [API Contracts](API_Contracts.md)
- [Backend Routes](Routes_BE.md)

## Authenticaton
See `API_GUIDE.md` for authentication flows (JWT/OAuth).

## Endpoints
Full Swagger/OpenAPI documentation is available at `/docs` when the backend is running.
