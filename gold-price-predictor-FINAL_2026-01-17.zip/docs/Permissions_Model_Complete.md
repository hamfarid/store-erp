# Permissions Model - RBAC Matrix

**FILE:** docs/Permissions_Model_Complete.md | **PURPOSE:** Complete RBAC permission matrix | **OWNER:** Security Team | **RELATED:** Security_Comprehensive.md, Routes_BE.md | **LAST-AUDITED:** 2025-01-18

**Project:** Gold Price Predictor  
**Framework:** GLOBAL_GUIDELINES v3.0  
**RBAC Version:** 2.0

---

## 1. Roles

### 1.1 Role Hierarchy

```
ADMIN (Highest)
  ↓
MANAGER
  ↓
USER
  ↓
GUEST (Lowest)
```

### 1.2 Role Definitions

**ADMIN:**
- Full system access
- User management
- System configuration
- All CRUD operations
- Export all data
- View all logs

**MANAGER:**
- Manage own team's data
- Create/edit/delete predictions
- View team reports
- Export team data
- Limited user management

**USER:**
- Create/view own predictions
- Manage own alerts
- View own portfolio
- Export own data

**GUEST:**
- View public data only
- No create/edit/delete operations
- No data export

---

## 2. Permissions Matrix

### 2.1 Users Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| users.list | ✅ | ❌ | ❌ | ❌ |
| users.view | ✅ | ❌ | Self | ❌ |
| users.create | ✅ | ❌ | ❌ | ❌ |
| users.update | ✅ | ❌ | Self | ❌ |
| users.delete | ✅ | ❌ | ❌ | ❌ |
| users.export | ✅ | ❌ | ❌ | ❌ |
| users.updateRole | ✅ | ❌ | ❌ | ❌ |

### 2.2 Assets Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| assets.list | ✅ | ✅ | ✅ | ✅ |
| assets.view | ✅ | ✅ | ✅ | ✅ |
| assets.create | ✅ | ❌ | ❌ | ❌ |
| assets.update | ✅ | ❌ | ❌ | ❌ |
| assets.delete | ✅ | ❌ | ❌ | ❌ |
| assets.export | ✅ | ✅ | ✅ | ❌ |
| assets.getCurrentPrices | ✅ | ✅ | ✅ | ✅ |

### 2.3 Predictions Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| predictions.list | ✅ | Team | Self | ❌ |
| predictions.view | ✅ | Team | Self | ❌ |
| predictions.create | ✅ | ✅ | ✅ | ❌ |
| predictions.update | ✅ | Own | Own | ❌ |
| predictions.delete | ✅ | Own | Own | ❌ |
| predictions.export | ✅ | Team | Self | ❌ |
| predictions.generate | ✅ | ✅ | ✅ | ❌ |
| predictions.getHistory | ✅ | Team | Self | ❌ |

### 2.4 Alerts Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| alerts.list | ✅ | Team | Self | ❌ |
| alerts.view | ✅ | Team | Self | ❌ |
| alerts.create | ✅ | ✅ | ✅ | ❌ |
| alerts.update | ✅ | Own | Own | ❌ |
| alerts.delete | ✅ | Own | Own | ❌ |
| alerts.export | ✅ | Team | Self | ❌ |

### 2.5 Notifications Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| notifications.list | ✅ | Self | Self | ❌ |
| notifications.view | ✅ | Self | Self | ❌ |
| notifications.markAsRead | ✅ | Self | Self | ❌ |
| notifications.delete | ✅ | Self | Self | ❌ |

### 2.6 Portfolio Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| portfolio.list | ✅ | Team | Self | ❌ |
| portfolio.view | ✅ | Team | Self | ❌ |
| portfolio.create | ✅ | ✅ | ✅ | ❌ |
| portfolio.update | ✅ | Own | Own | ❌ |
| portfolio.delete | ✅ | Own | Own | ❌ |
| portfolio.export | ✅ | Team | Self | ❌ |

### 2.7 Reports Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| reports.generate | ✅ | ✅ | ✅ | ❌ |
| reports.view | ✅ | Team | Self | ❌ |
| reports.export | ✅ | Team | Self | ❌ |
| reports.schedule | ✅ | ✅ | ❌ | ❌ |

### 2.8 Logs Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| logs.view | ✅ | ❌ | ❌ | ❌ |
| logs.export | ✅ | ❌ | ❌ | ❌ |
| logs.search | ✅ | ❌ | ❌ | ❌ |

### 2.9 Admin Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| admin.dashboard | ✅ | ❌ | ❌ | ❌ |
| admin.users | ✅ | ❌ | ❌ | ❌ |
| admin.assets | ✅ | ❌ | ❌ | ❌ |
| admin.logs | ✅ | ❌ | ❌ | ❌ |
| admin.backup | ✅ | ❌ | ❌ | ❌ |
| admin.settings | ✅ | ❌ | ❌ | ❌ |

### 2.10 ML Module

| Permission | ADMIN | MANAGER | USER | GUEST |
|------------|-------|---------|------|-------|
| ml.trainModels | ✅ | ❌ | ❌ | ❌ |
| ml.viewPerformance | ✅ | ✅ | ❌ | ❌ |
| ml.compareModels | ✅ | ✅ | ❌ | ❌ |

---

## 3. Permission Enforcement

### 3.1 Backend Enforcement

**FastAPI (Python):**
```python
from fastapi import Depends, HTTPException
from auth_postgresql import get_current_user

def require_permission(permission: str):
    async def permission_checker(current_user = Depends(get_current_user)):
        if not has_permission(current_user, permission):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return current_user
    return permission_checker

# Usage
@app.get("/api/users")
async def list_users(user = Depends(require_permission("users.list"))):
    return await get_all_users()
```

**tRPC (Node.js):**
```typescript
const adminProcedure = publicProcedure.use(async ({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN' });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});
```

### 3.2 Frontend Enforcement

**React Component:**
```typescript
import { usePermission } from '@/hooks/usePermission';

function UserManagement() {
  const canViewUsers = usePermission('users.list');
  const canCreateUsers = usePermission('users.create');
  
  if (!canViewUsers) {
    return <PermissionDenied />;
  }
  
  return (
    <div>
      {canCreateUsers && <CreateUserButton />}
      <UsersList />
    </div>
  );
}
```

---

## 4. Permission Codes

### 4.1 Naming Convention

Format: `{module}.{action}`

**Modules:**
- users, assets, predictions, alerts, notifications
- portfolio, reports, logs, admin, ml

**Actions:**
- list, view, create, update, delete, export
- generate, schedule, search, etc.

### 4.2 Special Permissions

**Self:**
- User can only access their own data
- Example: `predictions.view` with `Self` means user can only view their own predictions

**Team:**
- Manager can access their team's data
- Requires team assignment in database

**Own:**
- User can only modify their own created items
- Example: `alerts.update` with `Own` means user can only update alerts they created

---

## 5. Implementation Checklist

### Backend
- [ ] Add `@require_permission` decorator to all protected routes
- [ ] Implement `has_permission()` function
- [ ] Add permission checks in tRPC procedures
- [ ] Add audit logging for permission checks

### Frontend
- [ ] Create `usePermission()` hook
- [ ] Add `<ProtectedRoute>` component
- [ ] Hide/disable UI elements based on permissions
- [ ] Show permission denied page for unauthorized access

### Database
- [ ] Add `permissions` column to users table (JSON array)
- [ ] Create `role_permissions` mapping table
- [ ] Add migration for permission data

### Testing
- [ ] Unit tests for permission checks
- [ ] Integration tests for each permission
- [ ] E2E tests for permission-based UI

---

**Last Updated:** 2025-01-18  
**Next Review:** 2025-02-18  
**Owner:** Security Team

