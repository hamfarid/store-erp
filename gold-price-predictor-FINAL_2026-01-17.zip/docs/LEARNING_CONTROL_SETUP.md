# Learning Control Dashboard - Setup Guide

## نظرة عامة

تم إنشاء جميع الملفات المطلوبة لـ Phase 10: Learning & Search Control Dashboard. هذا الدليل يشرح كيفية إكمال الإعداد.

## الملفات المُنشأة

### ✅ Database Schema
- `drizzle/schema-learning-control.ts` - Schema definitions للجداول الخمسة
- `drizzle/migrations/0004_learning_control.sql` - Migration file (MySQL syntax)

### ✅ Backend
- `server/db-learning-control.ts` - Database helper functions
- `server/routers/learning-control.ts` - tRPC router
- `server/_core/websocket.ts` - WebSocket server (محدث)

### ✅ Frontend
- `client/src/pages/LearningControlDashboard.tsx` - Dashboard page
- `client/src/hooks/useWebSocket.ts` - WebSocket hook
- Route added to `client/src/App.tsx`

### ✅ Setup Scripts
- `scripts/setup-learning-control.ts` - TypeScript script لإنشاء الجداول
- `scripts/setup-learning-control-tables.js` - JavaScript script (بديل)
- `scripts/setup-database.ts` - محدث بجداول Learning Control

## خطوات الإعداد

### الطريقة 1: استخدام Setup Script (موصى به)

```bash
# تأكد من تثبيت الحزم أولاً
pnpm install

# تشغيل setup script
pnpm exec tsx scripts/setup-learning-control.ts

# أو إذا كان tsx غير متاح
node scripts/setup-learning-control-tables.js
```

### الطريقة 2: استخدام Drizzle Kit

```bash
# Generate migrations
pnpm exec drizzle-kit generate

# Push to database
pnpm exec drizzle-kit push
```

### الطريقة 3: تشغيل Setup Database الكامل

```bash
# هذا سينشئ جميع الجداول بما فيها Learning Control
pnpm setup:db
```

## التحقق من الإعداد

بعد تشغيل migrations، تحقق من:

1. **التحقق من الجداول:**
   ```sql
   -- في SQLite
   SELECT name FROM sqlite_master 
   WHERE type='table' 
   AND name IN ('search_keywords', 'search_sources', 'learning_operations', 'search_operations', 'operation_logs');
   ```

2. **اختبار الاتصال:**
   - شغل السيرفر: `pnpm dev`
   - افتح المتصفح: `http://localhost:3000/learning-control`
   - تحقق من أن الصفحة تعمل بدون أخطاء

3. **اختبار WebSocket:**
   - افتح Developer Tools > Network > WS
   - تحقق من اتصال WebSocket على `/ws`

## الجداول المُنشأة

### 1. search_keywords
- إدارة الكلمات المفتاحية للبحث
- Fields: keyword, category, priority, enabled, search_count, etc.

### 2. search_sources
- إدارة مصادر البحث (محركات البحث، مواقع الأخبار، APIs)
- Fields: name, type, url, enabled, reliability, etc.

### 3. learning_operations
- تتبع عمليات التعلم
- Fields: type, status, progress, input, output, etc.

### 4. search_operations
- تتبع عمليات البحث
- Fields: type, status, keywords, sources, progress, etc.

### 5. operation_logs
- سجل عمليات التعلم والبحث
- Fields: operation_id, operation_type, level, message, etc.

## Indexes

تم إنشاء 12 index لتحسين الأداء:
- `idx_search_keywords_category`
- `idx_search_keywords_priority`
- `idx_search_keywords_enabled`
- `idx_search_sources_type`
- `idx_search_sources_enabled`
- `idx_learning_operations_type`
- `idx_learning_operations_status`
- `idx_learning_operations_created_at`
- `idx_search_operations_type`
- `idx_search_operations_status`
- `idx_search_operations_created_at`
- `idx_operation_logs_operation_id`
- `idx_operation_logs_level`
- `idx_operation_logs_timestamp`

## المشاكل المحتملة وحلولها

### المشكلة: "tsx is not recognized"
**الحل:**
```bash
pnpm add -D tsx
# أو استخدم
npx tsx scripts/setup-learning-control.ts
```

### المشكلة: "better-sqlite3 not found"
**الحل:**
```bash
pnpm install better-sqlite3
```

### المشكلة: "Database connection failed"
**الحل:**
- تأكد من وجود متغير `DATABASE_URL` في `.env`
- للـ SQLite: `DATABASE_URL=file:./data/app.db`
- للـ MySQL: `DATABASE_URL=mysql://user:password@localhost:3306/dbname`

## الخطوات التالية

بعد إنشاء الجداول:

1. ✅ اختبار إضافة كلمة مفتاحية جديدة
2. ✅ اختبار إضافة مصدر بحث جديد
3. ✅ اختبار بدء عملية تعلم
4. ✅ اختبار بدء عملية بحث
5. ✅ التحقق من تحديثات WebSocket في الوقت الفعلي

## ملاحظات

- جميع الجداول تستخدم SQLite syntax في setup scripts
- Schema file (`schema-learning-control.ts`) يستخدم MySQL syntax (للدعم المزدوج)
- WebSocket server يعمل على `/ws` endpoint
- Dashboard متاح على `/learning-control` route

---

**تاريخ الإنشاء:** 2025-01-18  
**الحالة:** ✅ جاهز للتشغيل (يحتاج تشغيل migrations)

