# DATABASE SCHEMA - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/DB_Schema.md | **PURPOSE**: Complete database schema documentation | **OWNER**: Database Team | **RELATED**: ARCHITECTURE.md, MODULE_MAP.md, API_Contracts.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Database Engines**: SQLite 3.43+ (Drizzle ORM), PostgreSQL 15+ (SQLAlchemy ORM)  
**Schema Version**: SQLite v1 (0000_absurd_vargas), PostgreSQL v1 (initial)

---

## Table of Contents
1. [Overview](#1-overview)
2. [Dual Database Strategy](#2-dual-database-strategy)
3. [SQLite Schema (Drizzle ORM)](#3-sqlite-schema-drizzle-orm)
4. [PostgreSQL Schema (SQLAlchemy ORM)](#4-postgresql-schema-sqlalchemy-orm)
5. [Entity Relationship Diagram](#5-entity-relationship-diagram)
6. [Table Specifications](#6-table-specifications)
7. [Indexes and Constraints](#7-indexes-and-constraints)
8. [Migration Strategy](#8-migration-strategy)
9. [Data Integrity Rules](#9-data-integrity-rules)
10. [Backup and Recovery](#10-backup-and-recovery)

---

## 1. Overview

### 1.1 Database Architecture

The Gold & Assets Price Prediction System uses a **dual database architecture**:

1. **SQLite (Drizzle ORM)** - Application data, predictions, alerts, logs
   - Location: `./data/app.db`
   - Size: ~500MB (production)
   - Access: tRPC Server (Node.js)

2. **PostgreSQL (SQLAlchemy ORM)** - Authentication, audit logs, API keys
   - Location: External server (cloud-hosted)
   - Size: ~100MB (production)
   - Access: FastAPI Backend (Python)

### 1.2 Database Statistics

| Metric | SQLite | PostgreSQL |
|--------|--------|------------|
| Tables | 11 | 4 |
| Indexes | 1 (unique) | 12+ (composite) |
| Estimated Rows | ~1M (predictions) | ~10K (users) |
| Growth Rate | ~50K rows/day | ~1K rows/day |
| Backup Frequency | Daily | Hourly |
| Retention | 2 years | 5 years |

### 1.3 Design Principles

**ACID Compliance**:
- ✅ Atomicity: Transactions for multi-table operations
- ✅ Consistency: Foreign key constraints, check constraints
- ✅ Isolation: Read Committed isolation level
- ✅ Durability: WAL mode (SQLite), Synchronous replication (PostgreSQL)

**Normalization**: 3NF (Third Normal Form)
**Soft Deletes**: Preferred over hard deletes (use `isActive` or `deleted_at` columns)
**Audit Trail**: All user actions logged in `audit_logs` (PostgreSQL)

---

## 2. Dual Database Strategy

### 2.1 Rationale

**Why SQLite for Application Data?**
- ✅ **Performance**: Embedded, no network latency, fast read queries
- ✅ **Simplicity**: No separate database server, easy deployment
- ✅ **Reliability**: Single file, easy backups, ACID compliant
- ✅ **Cost**: Zero infrastructure costs
- ⚠️ **Limitations**: Limited concurrency (writers), no horizontal scaling

**Why PostgreSQL for Auth/Audit?**
- ✅ **Security**: Row-level security, encryption at rest/transit
- ✅ **Reliability**: ACID, WAL, point-in-time recovery
- ✅ **Scalability**: Connection pooling, read replicas
- ✅ **Features**: Full-text search, JSON queries, advanced indexing
- ⚠️ **Complexity**: Separate server, higher infrastructure cost

### 2.2 Data Segregation

```mermaid
graph LR
    subgraph "SQLite (Drizzle ORM)"
        Users1[users]
        Assets[assets]
        Predictions[predictions]
        Prices[historicalPrices]
        Alerts[alerts]
        Settings[email_settings]
        AccessCodes[access_codes]
        APILogs[api_request_logs]
        ErrorLogs[error_logs]
        MLLogs[ml_training_logs]
        PredLogs[prediction_logs]
    end
    
    subgraph "PostgreSQL (SQLAlchemy)"
        Users2[users - auth]
        APIKeys[api_keys]
        AuditLogs[audit_logs]
        PredBackup[predictions - backup]
    end
    
    Users1 -.sync.-> Users2
    Predictions -.backup.-> PredBackup
    
    style Users1 fill:#90EE90
    style Users2 fill:#FFB6C1
    style Predictions fill:#87CEEB
    style AuditLogs fill:#FFD700
```

**Sync Strategy**:
- User data synced on creation/update (webhook from tRPC to FastAPI)
- Predictions backed up daily to PostgreSQL
- Audit logs append-only in PostgreSQL (never deleted)

---

## 3. SQLite Schema (Drizzle ORM)

### 3.1 Schema File

**Location**: `drizzle/0000_absurd_vargas.sql`  
**Migration Tool**: Drizzle Kit  
**Generated**: 2025-10-15  
**Version**: v1 (initial schema)

### 3.2 Tables Overview

| Table | Rows (Est.) | Purpose | Key Relationships |
|-------|------------|---------|------------------|
| users | 1,000 | User accounts | → alerts, email_settings |
| assets | 18 | Tradable assets | → predictions, historicalPrices, alerts |
| predictions | 500,000 | ML predictions | → assets, prediction_logs |
| historicalPrices | 1,000,000 | Price history | → assets |
| alerts | 5,000 | Price alerts | → users, assets |
| email_settings | 500 | Email config | → users |
| access_codes | 100 | Invite codes | → users |
| api_request_logs | 2,000,000 | API requests | → users |
| error_logs | 50,000 | Error tracking | → users |
| ml_training_logs | 10,000 | ML training | → assets |
| prediction_logs | 500,000 | Prediction exec | → predictions, assets |

### 3.3 Complete Entity Relationship Diagram

```mermaid
erDiagram
    users ||--o{ alerts : creates
    users ||--o{ email_settings : configures
    users ||--o{ access_codes : uses
    users ||--o{ api_request_logs : generates
    users ||--o{ error_logs : encounters
    users ||--o{ prediction_logs : requests
    
    assets ||--o{ historicalPrices : tracks
    assets ||--o{ predictions : forecasts
    assets ||--o{ alerts : monitors
    assets ||--o{ ml_training_logs : trained
    assets ||--o{ prediction_logs : predicts
    
    predictions ||--o{ prediction_logs : logged
    
    users {
        text id PK "UUID v4"
        text name "Display name"
        text email UK "Email address"
        text loginMethod "oauth/local"
        text role "admin/user"
        integer createdAt "Unix timestamp"
        integer lastSignedIn "Unix timestamp"
    }
    
    assets {
        integer id PK "Auto-increment"
        text name "Asset name"
        text symbol UK "Trading symbol"
        text category "Category type"
        boolean isActive "Active status"
        integer createdAt "Unix timestamp"
    }
    
    predictions {
        integer id PK "Auto-increment"
        integer assetId FK "Asset reference"
        integer predictionDate "Prediction time"
        integer targetDate "Target date"
        integer daysAhead "Horizon days"
        text currentPrice "Current price"
        text predictedPrice "Predicted price"
        text confidenceLower "CI lower bound"
        text confidenceUpper "CI upper bound"
        text modelType "Model name"
        text accuracy "Model accuracy"
        integer createdAt "Unix timestamp"
    }
    
    historicalPrices {
        integer id PK "Auto-increment"
        integer assetId FK "Asset reference"
        integer date "Price date"
        text price "Price value"
        text volume "Trading volume"
        integer createdAt "Unix timestamp"
    }
    
    alerts {
        integer id PK "Auto-increment"
        text userId FK "User reference"
        integer assetId FK "Asset reference"
        text alertType "above/below/change"
        text targetPrice "Target price"
        text changePercent "Change percent"
        boolean isActive "Active status"
        boolean isTriggered "Triggered flag"
        integer triggeredAt "Trigger time"
        text notificationMethod "email/push/telegram"
        integer createdAt "Unix timestamp"
    }
    
    email_settings {
        integer id PK "Auto-increment"
        text userId FK UK "User reference"
        text recipientEmail "Email address"
        text smtpHost "SMTP server"
        integer smtpPort "SMTP port"
        text smtpUser "SMTP username"
        text smtpPassword "SMTP password (encrypted)"
        text fromEmail "From address"
        text fromName "From name"
        boolean enabled "Enabled flag"
        integer createdAt "Unix timestamp"
        integer updatedAt "Unix timestamp"
    }
    
    access_codes {
        integer id PK "Auto-increment"
        text code UK "Invite code"
        text userId FK "User who used"
        integer usedAt "Usage time"
        integer createdAt "Creation time"
    }
    
    api_request_logs {
        integer id PK "Auto-increment"
        integer timestamp "Request time"
        text method "HTTP method"
        text endpoint "API endpoint"
        text userId FK "User reference"
        integer statusCode "HTTP status"
        integer responseTime "Response time (ms)"
        text ipAddress "Client IP"
        text userAgent "User agent"
        text errorMessage "Error message"
    }
    
    error_logs {
        integer id PK "Auto-increment"
        integer timestamp "Error time"
        text level "error/warning/info"
        text source "Error source"
        text component "Component name"
        text message "Error message"
        text stack "Stack trace"
        text userId FK "User reference"
        text metadata "JSON metadata"
    }
    
    ml_training_logs {
        integer id PK "Auto-increment"
        integer timestamp "Training time"
        integer assetId FK "Asset reference"
        text modelType "Model name"
        integer trainingDuration "Duration (seconds)"
        text trainScore "Training score"
        text testScore "Test score"
        text mape "MAPE metric"
        text hyperparameters "JSON params"
        integer datasetSize "Dataset rows"
        text status "started/completed/failed"
        text errorMessage "Error message"
    }
    
    prediction_logs {
        integer id PK "Auto-increment"
        integer timestamp "Prediction time"
        integer predictionId FK "Prediction reference"
        integer assetId FK "Asset reference"
        text modelType "Model name"
        text inputData "JSON input"
        text outputData "JSON output"
        integer executionTime "Execution time (ms)"
        text userId FK "User reference"
        text status "success/failed"
        text errorMessage "Error message"
    }
```

---

## 4. PostgreSQL Schema (SQLAlchemy ORM)

### 4.1 Schema File

**Location**: `backend/app/database.py`  
**Migration Tool**: Alembic  
**Generated**: 2025-10-19  
**Version**: v1 (initial schema)

### 4.2 Tables Overview

| Table | Rows (Est.) | Purpose | Key Relationships |
|-------|------------|---------|------------------|
| users | 1,000 | Auth users | → api_keys, audit_logs, predictions |
| api_keys | 500 | API keys | → users |
| audit_logs | 500,000 | Audit trail | → users |
| predictions | 500,000 | Predictions backup | → users (optional) |

### 4.3 PostgreSQL ERD

```mermaid
erDiagram
    users ||--o{ api_keys : owns
    users ||--o{ audit_logs : generates
    users ||--o{ predictions : creates
    
    users {
        integer id PK "Auto-increment"
        string username UK "Username"
        string email UK "Email address"
        string full_name "Full name"
        string hashed_password "bcrypt/argon2 hash"
        boolean disabled "Account disabled"
        datetime created_at "Creation timestamp"
        datetime updated_at "Update timestamp"
    }
    
    api_keys {
        integer id PK "Auto-increment"
        string key UK "API key (hashed)"
        integer user_id FK "User reference"
        string name "Key name"
        json permissions "Permissions JSON"
        boolean is_active "Active status"
        datetime created_at "Creation timestamp"
        datetime expires_at "Expiry timestamp"
        datetime last_used_at "Last usage timestamp"
    }
    
    audit_logs {
        integer id PK "Auto-increment"
        datetime timestamp "Event time"
        integer user_id FK "User reference"
        string event_type "Event type"
        string resource_type "Resource type"
        string resource_id "Resource ID"
        string action "Action performed"
        json changes "Changes JSON"
        string ip_address "Client IP"
        string user_agent "User agent"
    }
    
    predictions {
        integer id PK "Auto-increment"
        integer user_id FK "User reference"
        string symbol "Asset symbol"
        string horizon "Prediction horizon"
        float predicted_price "Predicted price"
        float confidence_level "Confidence level"
        string model_used "Model name"
        float model_accuracy "Model accuracy"
        datetime created_at "Creation timestamp"
    }
```

---

## 6. Table Specifications

### 6.1 SQLite Tables

#### Table: users

**Purpose**: User accounts with OAuth/local authentication

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | text | PRIMARY KEY NOT NULL | UUID v4 generated by client |
| name | text | - | User's display name (optional) |
| email | text | - | Email address (optional for OAuth) |
| loginMethod | text | - | "oauth", "local", "google", "github" |
| role | text | DEFAULT 'user' NOT NULL | "admin" or "user" |
| createdAt | integer | - | Unix timestamp (milliseconds) |
| lastSignedIn | integer | - | Unix timestamp (milliseconds) |

**Indexes**: None (SQLite auto-indexes PRIMARY KEY)

**Sample Data**:
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "John Doe",
  "email": "john@example.com",
  "loginMethod": "local",
  "role": "user",
  "createdAt": 1700000000000,
  "lastSignedIn": 1700100000000
}
```

---

#### Table: assets

**Purpose**: Tradable assets (gold, silver, crypto, forex)

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| name | text | NOT NULL | Asset name (e.g., "Gold") |
| symbol | text | NOT NULL | Trading symbol (e.g., "GC=F") |
| category | text | NOT NULL | "Precious Metals", "Crypto", "Forex", "Energy" |
| isActive | integer | DEFAULT true NOT NULL | 1 = active, 0 = inactive |
| createdAt | integer | - | Unix timestamp (milliseconds) |

**Indexes**: None

**Sample Data**:
```json
{
  "id": 1,
  "name": "Gold",
  "symbol": "GC=F",
  "category": "Precious Metals",
  "isActive": 1,
  "createdAt": 1700000000000
}
```

---

#### Table: predictions

**Purpose**: ML-generated price predictions with confidence intervals

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| assetId | integer | NOT NULL | Foreign key to assets.id |
| predictionDate | integer | NOT NULL | When prediction was made (Unix ms) |
| targetDate | integer | NOT NULL | Target date for prediction (Unix ms) |
| daysAhead | integer | NOT NULL | Prediction horizon (1-30 days) |
| currentPrice | text | NOT NULL | Current price at prediction time |
| predictedPrice | text | NOT NULL | Predicted price |
| confidenceLower | text | - | Lower bound (95% CI) |
| confidenceUpper | text | - | Upper bound (95% CI) |
| modelType | text | NOT NULL | "ARIMA", "LSTM", "Ensemble", etc. |
| accuracy | text | - | Model accuracy (0.0-1.0) |
| createdAt | integer | - | Unix timestamp (milliseconds) |

**Indexes**: None (consider adding index on `assetId`, `targetDate` for performance)

**Sample Data**:
```json
{
  "id": 12345,
  "assetId": 1,
  "predictionDate": 1700000000000,
  "targetDate": 1700604800000,
  "daysAhead": 7,
  "currentPrice": "1950.50",
  "predictedPrice": "1975.20",
  "confidenceLower": "1960.00",
  "confidenceUpper": "1990.00",
  "modelType": "Ensemble",
  "accuracy": "0.9903",
  "createdAt": 1700000000000
}
```

---

#### Table: historicalPrices

**Purpose**: Historical price data for ML model training

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| assetId | integer | NOT NULL | Foreign key to assets.id |
| date | integer | NOT NULL | Price date (Unix ms, midnight UTC) |
| price | text | NOT NULL | Closing price |
| volume | text | - | Trading volume (optional) |
| createdAt | integer | - | Unix timestamp (milliseconds) |

**Indexes**: Consider composite index on `(assetId, date)` for range queries

**Sample Data**:
```json
{
  "id": 98765,
  "assetId": 1,
  "date": 1700000000000,
  "price": "1950.50",
  "volume": "12500000",
  "createdAt": 1700000100000
}
```

---

#### Table: alerts

**Purpose**: User-defined price alerts with notifications

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| userId | text | NOT NULL | Foreign key to users.id |
| assetId | integer | NOT NULL | Foreign key to assets.id |
| alertType | text | NOT NULL | "above", "below", "change" |
| targetPrice | text | - | Target price (for above/below) |
| changePercent | text | - | Change percentage (for change type) |
| isActive | integer | DEFAULT true NOT NULL | 1 = active, 0 = inactive |
| isTriggered | integer | DEFAULT false NOT NULL | 1 = triggered, 0 = pending |
| triggeredAt | integer | - | Unix timestamp when triggered |
| notificationMethod | text | DEFAULT 'email' NOT NULL | "email", "push", "telegram", "webhook" |
| createdAt | integer | - | Unix timestamp (milliseconds) |

**Indexes**: Consider index on `(assetId, isActive, isTriggered)` for alert checking

**Sample Data**:
```json
{
  "id": 456,
  "userId": "550e8400-e29b-41d4-a716-446655440000",
  "assetId": 1,
  "alertType": "above",
  "targetPrice": "2000.00",
  "changePercent": null,
  "isActive": 1,
  "isTriggered": 0,
  "triggeredAt": null,
  "notificationMethod": "email",
  "createdAt": 1700000000000
}
```

---

#### Table: email_settings

**Purpose**: User email configuration for notifications

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| userId | text | NOT NULL | Foreign key to users.id |
| recipientEmail | text | NOT NULL | Email address for notifications |
| smtpHost | text | - | SMTP server (optional, use default if null) |
| smtpPort | integer | - | SMTP port (optional, default 587) |
| smtpUser | text | - | SMTP username (optional) |
| smtpPassword | text | - | SMTP password (encrypted) |
| fromEmail | text | - | From email address |
| fromName | text | - | From display name |
| enabled | integer | DEFAULT true | 1 = enabled, 0 = disabled |
| createdAt | integer | - | Unix timestamp (milliseconds) |
| updatedAt | integer | - | Unix timestamp (milliseconds) |

**Indexes**: None

**Security**: `smtpPassword` must be encrypted with AES-256 before storage

---

#### Table: access_codes

**Purpose**: Invite codes for user registration

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| code | text | NOT NULL UNIQUE | Invite code (8-16 chars alphanumeric) |
| userId | text | - | User who used code (Foreign key to users.id) |
| usedAt | integer | - | Unix timestamp when used |
| createdAt | integer | - | Unix timestamp when created |

**Indexes**: Unique index on `code`

**Sample Data**:
```json
{
  "id": 10,
  "code": "INVITE2024XYZ",
  "userId": null,
  "usedAt": null,
  "createdAt": 1700000000000
}
```

---

#### Table: api_request_logs

**Purpose**: Log all API requests for monitoring and debugging

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| timestamp | integer | NOT NULL | Unix timestamp (milliseconds) |
| method | text | - | HTTP method (GET, POST, etc.) |
| endpoint | text | - | API endpoint path |
| userId | text | - | User ID (if authenticated) |
| statusCode | integer | - | HTTP status code (200, 404, etc.) |
| responseTime | integer | - | Response time (milliseconds) |
| ipAddress | text | - | Client IP address |
| userAgent | text | - | Client user agent |
| errorMessage | text | - | Error message (if error occurred) |

**Indexes**: Consider index on `(timestamp, statusCode)` for analytics

**Retention**: 90 days (auto-purge older logs)

---

#### Table: error_logs

**Purpose**: Log application errors for debugging

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| timestamp | integer | NOT NULL | Unix timestamp (milliseconds) |
| level | text | DEFAULT 'error' NOT NULL | "error", "warning", "info" |
| source | text | - | Error source (file path) |
| component | text | - | Component name |
| message | text | - | Error message |
| stack | text | - | Stack trace |
| userId | text | - | User ID (if applicable) |
| metadata | text | - | JSON metadata |

**Indexes**: Consider index on `(timestamp, level)` for monitoring

**Retention**: 180 days (auto-purge older logs)

---

#### Table: ml_training_logs

**Purpose**: Log ML model training sessions

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| timestamp | integer | NOT NULL | Unix timestamp (milliseconds) |
| assetId | integer | - | Asset ID (Foreign key to assets.id) |
| modelType | text | - | Model type (ARIMA, LSTM, etc.) |
| trainingDuration | integer | - | Training duration (seconds) |
| trainScore | text | - | Training score (R², accuracy) |
| testScore | text | - | Test score (R², accuracy) |
| mape | text | - | Mean Absolute Percentage Error |
| hyperparameters | text | - | JSON hyperparameters |
| datasetSize | integer | - | Number of training samples |
| status | text | DEFAULT 'started' NOT NULL | "started", "completed", "failed" |
| errorMessage | text | - | Error message (if failed) |

**Indexes**: Consider index on `(assetId, timestamp)` for history queries

**Retention**: Indefinite (for ML auditing)

---

#### Table: prediction_logs

**Purpose**: Log each prediction execution

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT NOT NULL | Auto-generated ID |
| timestamp | integer | NOT NULL | Unix timestamp (milliseconds) |
| predictionId | integer | - | Foreign key to predictions.id |
| assetId | integer | - | Foreign key to assets.id |
| modelType | text | - | Model type used |
| inputData | text | - | JSON input data |
| outputData | text | - | JSON output data |
| executionTime | integer | - | Execution time (milliseconds) |
| userId | text | - | User who requested (if applicable) |
| status | text | DEFAULT 'success' NOT NULL | "success", "failed" |
| errorMessage | text | - | Error message (if failed) |

**Indexes**: Consider index on `(predictionId, assetId, timestamp)` for analytics

**Retention**: 365 days (auto-purge older logs)

---

### 6.2 PostgreSQL Tables

#### Table: users (Auth)

**Purpose**: User authentication and authorization

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT | Auto-generated ID |
| username | varchar | UNIQUE NOT NULL | Username |
| email | varchar | UNIQUE | Email address |
| full_name | varchar | - | Full name |
| hashed_password | varchar | NOT NULL | bcrypt/argon2 hash |
| disabled | boolean | DEFAULT false | Account disabled flag |
| created_at | timestamp | DEFAULT now() | Creation timestamp |
| updated_at | timestamp | DEFAULT now() | Update timestamp (auto-update on change) |

**Indexes**:
- Primary key: `users_pkey` on `id`
- Unique index: `ix_users_username` on `username`
- Unique index: `ix_users_email` on `email`

---

#### Table: api_keys

**Purpose**: API key management for programmatic access

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT | Auto-generated ID |
| key | varchar | UNIQUE NOT NULL | API key (SHA-256 hashed) |
| user_id | integer | FOREIGN KEY(users.id) | Owner user ID |
| name | varchar | - | Key name/description |
| permissions | json | - | Permissions JSON (e.g., `{"predictions": "read"}`) |
| is_active | boolean | DEFAULT true | Active status |
| created_at | timestamp | DEFAULT now() | Creation timestamp |
| expires_at | timestamp | - | Expiry timestamp (nullable for no expiry) |
| last_used_at | timestamp | - | Last usage timestamp |

**Indexes**:
- Primary key: `api_keys_pkey` on `id`
- Unique index: `ix_api_keys_key` on `key`
- Foreign key index: `ix_api_keys_user_id` on `user_id`

---

#### Table: audit_logs

**Purpose**: Comprehensive audit trail of all user actions

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT | Auto-generated ID |
| timestamp | timestamp | NOT NULL DEFAULT now() | Event timestamp |
| user_id | integer | FOREIGN KEY(users.id) | User who performed action |
| event_type | varchar | NOT NULL | "LOGIN", "LOGOUT", "CREATE", "UPDATE", "DELETE", "EXPORT" |
| resource_type | varchar | - | "user", "prediction", "asset", "alert", etc. |
| resource_id | varchar | - | Resource ID |
| action | varchar | NOT NULL | Action performed (e.g., "created_prediction") |
| changes | json | - | JSON of before/after values |
| ip_address | varchar | - | Client IP address |
| user_agent | varchar | - | Client user agent |

**Indexes**:
- Primary key: `audit_logs_pkey` on `id`
- Index: `ix_audit_logs_timestamp` on `timestamp` (for range queries)
- Index: `ix_audit_logs_user_id` on `user_id` (for user history)
- Composite index: `ix_audit_logs_resource` on `(resource_type, resource_id)` (for resource history)

**Retention**: Indefinite (compliance requirement)

---

#### Table: predictions (Backup)

**Purpose**: Backup of predictions from SQLite

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | integer | PRIMARY KEY AUTOINCREMENT | Auto-generated ID |
| user_id | integer | FOREIGN KEY(users.id) | User who requested |
| symbol | varchar | NOT NULL | Asset symbol |
| horizon | varchar | NOT NULL | Prediction horizon (e.g., "7_days") |
| predicted_price | float | NOT NULL | Predicted price |
| confidence_level | float | DEFAULT 0.95 | Confidence level |
| model_used | varchar | - | Model type |
| model_accuracy | float | - | Model accuracy |
| created_at | timestamp | DEFAULT now() | Creation timestamp |

**Indexes**:
- Primary key: `predictions_pkey` on `id`
- Index: `ix_predictions_created_at` on `created_at` (for time-based queries)
- Index: `ix_predictions_symbol` on `symbol` (for asset-based queries)

---

## 7. Indexes and Constraints

### 7.1 SQLite Indexes

**Current Indexes**:
- `access_codes_code_unique` - UNIQUE index on `access_codes.code`

**Recommended Indexes** (Performance Optimization):
```sql
-- Predictions: Frequently queried by asset and date
CREATE INDEX idx_predictions_asset_target 
  ON predictions(assetId, targetDate);

-- Historical Prices: Range queries by asset
CREATE INDEX idx_historical_prices_asset_date 
  ON historicalPrices(assetId, date);

-- Alerts: Check active, untriggered alerts by asset
CREATE INDEX idx_alerts_active 
  ON alerts(assetId, isActive, isTriggered) 
  WHERE isActive = 1 AND isTriggered = 0;

-- API Logs: Analytics by timestamp and status
CREATE INDEX idx_api_logs_timestamp_status 
  ON api_request_logs(timestamp DESC, statusCode);

-- ML Training Logs: History by asset
CREATE INDEX idx_ml_training_asset_time 
  ON ml_training_logs(assetId, timestamp DESC);
```

### 7.2 PostgreSQL Indexes

**Current Indexes**:
```sql
-- Users table
CREATE UNIQUE INDEX ix_users_username ON users(username);
CREATE UNIQUE INDEX ix_users_email ON users(email);

-- API Keys table
CREATE UNIQUE INDEX ix_api_keys_key ON api_keys(key);
CREATE INDEX ix_api_keys_user_id ON api_keys(user_id);

-- Audit Logs table
CREATE INDEX ix_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX ix_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX ix_audit_logs_resource ON audit_logs(resource_type, resource_id);

-- Predictions table
CREATE INDEX ix_predictions_created_at ON predictions(created_at DESC);
CREATE INDEX ix_predictions_symbol ON predictions(symbol);
```

### 7.3 Foreign Key Constraints

**SQLite** (Manual enforcement - Drizzle doesn't create foreign keys):
```typescript
// Define in drizzle/schema.ts
export const alerts = sqliteTable('alerts', {
  // ...
  userId: text('userId').notNull().references(() => users.id),
  assetId: integer('assetId').notNull().references(() => assets.id),
});
```

**PostgreSQL** (Automatic with SQLAlchemy):
```python
# backend/app/database.py
api_keys.user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
audit_logs.user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
predictions.user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
```

---

## 8. Migration Strategy

### 8.1 SQLite Migrations (Drizzle Kit)

**Migration Files**: `drizzle/*.sql`

**Commands**:
```bash
# Generate migration from schema changes
npm run db:generate

# Apply migrations
npm run db:migrate

# Push schema directly (development only)
npm run db:push
```

**Migration Workflow**:
1. Update `drizzle/schema.ts`
2. Run `npm run db:generate` - generates new migration file
3. Review migration SQL
4. Test in development
5. Run `npm run db:migrate` in production

**Rollback Strategy**:
- Drizzle doesn't support rollback
- Manual SQL script required
- Backup database before migration

### 8.2 PostgreSQL Migrations (Alembic)

**Migration Files**: `backend/app/migrations/versions/*.py`

**Commands**:
```bash
# Create migration
cd backend/app
alembic revision --autogenerate -m "Add new column to users"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1

# Rollback to specific version
alembic downgrade <revision_id>
```

**Migration Workflow**:
1. Update `backend/app/database.py` models
2. Run `alembic revision --autogenerate`
3. Review generated migration
4. Test in development
5. Apply to production with `alembic upgrade head`

**Example Migration**:
```python
# migrations/versions/001_add_2fa_columns.py
def upgrade():
    op.add_column('users', sa.Column('twofa_enabled', sa.Boolean(), nullable=True))
    op.add_column('users', sa.Column('twofa_secret', sa.String(), nullable=True))

def downgrade():
    op.drop_column('users', 'twofa_secret')
    op.drop_column('users', 'twofa_enabled')
```

---

## 9. Data Integrity Rules

### 9.1 Referential Integrity

**Cascade Rules**:
- `users` deleted → cascade delete `api_keys` (PostgreSQL)
- `users` deleted → set null `audit_logs.user_id` (PostgreSQL)
- `assets` deleted → restrict if `predictions` exist (business rule)

**Soft Deletes**:
- Users: Set `disabled = true` instead of deleting
- Assets: Set `isActive = false` instead of deleting
- Alerts: Set `isActive = false` instead of deleting

### 9.2 Data Validation

**Application-Level Validation** (Zod/Pydantic):
```typescript
// Zod schema
const createAlertSchema = z.object({
  assetId: z.number().int().positive(),
  alertType: z.enum(['above', 'below', 'change']),
  targetPrice: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
  notificationMethod: z.enum(['email', 'push', 'telegram', 'webhook']),
});
```

```python
# Pydantic model
class PredictionCreate(BaseModel):
    asset_id: int = Field(gt=0)
    days_ahead: int = Field(ge=1, le=30)
    current_price: Decimal = Field(gt=0, decimal_places=2)
```

**Database-Level Validation** (Check Constraints):
```sql
-- PostgreSQL
ALTER TABLE predictions 
ADD CONSTRAINT check_predicted_price_positive 
CHECK (predicted_price > 0);

ALTER TABLE users 
ADD CONSTRAINT check_email_format 
CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$');
```

### 9.3 Data Consistency

**Transaction Usage**:
```python
# Multi-table operation in transaction
with SessionLocal() as db:
    try:
        # Create prediction
        prediction = PredictionDB(...)
        db.add(prediction)
        
        # Log prediction
        log = PredictionLog(prediction_id=prediction.id, ...)
        db.add(log)
        
        # Commit transaction
        db.commit()
    except Exception as e:
        db.rollback()
        raise
```

---

## 10. Backup and Recovery

### 10.1 Backup Strategy

**SQLite Backups**:
- **Frequency**: Daily at 3 AM UTC
- **Method**: File copy with SQLite online backup API
- **Location**: AWS S3 `s3://gold-predictor-backups/sqlite/`
- **Retention**: 30 days online, 365 days archive (Glacier)
- **Command**:
  ```bash
  sqlite3 data/app.db ".backup 'backup-$(date +%Y%m%d-%H%M%S).db'"
  ```

**PostgreSQL Backups**:
- **Frequency**: Hourly incremental, daily full
- **Method**: pg_dump + WAL archiving
- **Location**: AWS S3 `s3://gold-predictor-backups/postgresql/`
- **Retention**: 7 days online, 30 days archive
- **Command**:
  ```bash
  pg_dump -Fc -h localhost -U postgres goldpredictor > backup-$(date +%Y%m%d).dump
  ```

### 10.2 Recovery Procedures

**SQLite Recovery**:
```bash
# Stop application
systemctl stop gold-predictor-backend

# Restore backup
cp backup-20251117-030000.db data/app.db

# Restart application
systemctl start gold-predictor-backend
```

**PostgreSQL Recovery**:
```bash
# Stop application
systemctl stop gold-predictor-backend

# Drop and recreate database
psql -U postgres -c "DROP DATABASE goldpredictor;"
psql -U postgres -c "CREATE DATABASE goldpredictor;"

# Restore backup
pg_restore -d goldpredictor backup-20251117.dump

# Restart application
systemctl start gold-predictor-backend
```

### 10.3 Disaster Recovery

**RTO (Recovery Time Objective)**: <1 hour  
**RPO (Recovery Point Objective)**: <15 minutes (PostgreSQL), <24 hours (SQLite)

**DR Plan**:
1. Automated backup monitoring (alert if backup fails)
2. Multi-region backup storage (S3 cross-region replication)
3. Monthly DR drill (restore backup to test environment)
4. Documented runbook in `docs/DISASTER_RECOVERY_PLAN.md`

---

## Appendix A: Schema Evolution History

| Version | Date | Changes | Migration ID |
|---------|------|---------|-------------|
| v1.0 | 2025-10-15 | Initial SQLite schema (11 tables) | 0000_absurd_vargas |
| v1.0 | 2025-10-19 | Initial PostgreSQL schema (4 tables) | initial_migration |
| v1.1 | TBD | Add 2FA columns to PostgreSQL users | TBD |
| v1.2 | TBD | Add composite indexes for performance | TBD |

---

## Appendix B: Query Performance Guidelines

**Slow Query Threshold**: 100ms

**Optimization Techniques**:
1. Use indexes on WHERE, JOIN, ORDER BY columns
2. Avoid SELECT * - specify columns
3. Use LIMIT for large result sets
4. Use connection pooling (SQLAlchemy, Drizzle)
5. Cache frequently accessed data (Redis, TTL: 5 minutes)
6. Use EXPLAIN ANALYZE to identify bottlenecks

**Example Slow Query**:
```sql
-- SLOW (no index on targetDate)
SELECT * FROM predictions WHERE targetDate > 1700000000000 ORDER BY targetDate DESC;

-- FAST (with index)
CREATE INDEX idx_predictions_target_date ON predictions(targetDate DESC);
SELECT id, assetId, predictedPrice FROM predictions 
WHERE targetDate > 1700000000000 
ORDER BY targetDate DESC 
LIMIT 100;
```

---

## Appendix C: Data Dictionary

| Term | Definition |
|------|------------|
| **Asset** | Tradable financial instrument (gold, silver, crypto, forex) |
| **Prediction** | ML-generated future price forecast with confidence interval |
| **Alert** | User-defined price threshold notification |
| **Confidence Interval** | Range where true value likely falls (95% CI) |
| **MAPE** | Mean Absolute Percentage Error - prediction accuracy metric |
| **Ensemble** | Weighted average of multiple ML models |
| **TOTP** | Time-based One-Time Password (2FA) |
| **Soft Delete** | Mark record as deleted (isActive=false) instead of removing |
| **ACID** | Atomicity, Consistency, Isolation, Durability |

---

**END OF DB_SCHEMA.MD**

**Status**: ✅ Complete  
**Coverage**: 100% database schema documented  
**Tables**: 11 (SQLite) + 4 (PostgreSQL) = 15 total  
**Diagrams**: 3 Mermaid ERDs  
**Next Review**: 2025-12-17  
**Maintainer**: Database Team
