# 🚀 دليل النشر السريع - Gold Price Predictor

**الوقت المقدر:** 30-45 دقيقة  
**الصعوبة:** متوسطة  
**المتطلبات:** Node.js 20+, PM2, Git

---

## ⚡ النشر السريع (5 خطوات)

### 1️⃣ **التحضير** (5 دقائق)

```bash
# Clone repository
git clone <your-repo-url>
cd gold-price-predictor

# Install dependencies
pnpm install

# Verify installation
pnpm --version
node --version
```

---

### 2️⃣ **تكوين البيئة** (10 دقائق)

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your values
nano .env
```

**المتغيرات الأساسية:**
```bash
# Server
NODE_ENV=production
PORT=2505

# Database
DATABASE_URL=file:./data/asset_predictor.db

# Security (Generate new secrets!)
JWT_SECRET=<generate-random-32-chars>
SESSION_SECRET=<generate-random-32-chars>

# APIs (Already configured)
ALPHA_VANTAGE_API_KEY=QNJI6UNG8D5I1CFW
FRED_API_KEY=6d9703816821bdbada241f637fe214ac
NEWS_API_KEY=67b578858ae743928fcdf9562ec82acd

# SMTP (Already configured)
SMTP_HOST=smtp.gaaraholding.com
SMTP_USER=admin@gaaraholding.com
SMTP_PASSWORD=HaRrMa123!@#
SMTP_FROM=info@gaaraholding.com

# Grafana (Already configured)
GRAFANA_ADMIN_PASSWORD=HaRrMa123
```

**توليد Secrets:**
```bash
# Generate JWT_SECRET
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Generate SESSION_SECRET
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

### 3️⃣ **البناء** (5 دقائق)

```bash
# Build production bundle
pnpm build

# Verify build
ls -la dist/

# Run database migrations
npx drizzle-kit push
```

---

### 4️⃣ **النشر** (10 دقائق)

#### Option A: PM2 (Recommended)

```bash
# Install PM2 globally
npm install -g pm2

# Start application
pm2 start ecosystem.config.js --env production

# Verify status
pm2 status
pm2 logs gold-predictor

# Save PM2 configuration
pm2 save
pm2 startup
```

#### Option B: Docker

```bash
# Build Docker image
docker build -t gold-predictor:latest .

# Run container
docker run -d \
  --name gold-predictor \
  -p 2505:2505 \
  --env-file .env \
  -v $(pwd)/data:/app/data \
  gold-predictor:latest

# Verify
docker ps
docker logs gold-predictor
```

#### Option C: Docker Compose

```bash
# Start all services
docker-compose up -d

# Verify
docker-compose ps
docker-compose logs -f gold-predictor
```

---

### 5️⃣ **التحقق** (5 دقائق)

```bash
# Health check
curl http://localhost:2505/api/health

# Expected response:
# {"status":"ok","timestamp":"..."}

# Test authentication
curl -X POST http://localhost:2505/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"admin123"}'

# Open in browser
open http://localhost:2505
```

---

## 🔧 استكشاف الأخطاء

### المشكلة: الخادم لا يبدأ

```bash
# Check logs
pm2 logs gold-predictor --lines 50

# Or for Docker
docker logs gold-predictor --tail 50

# Common issues:
# 1. Port already in use
lsof -i :2505
kill -9 <PID>

# 2. Database locked
rm data/asset_predictor.db-wal
rm data/asset_predictor.db-shm

# 3. Missing dependencies
pnpm install
pnpm rebuild better-sqlite3
```

### المشكلة: Database errors

```bash
# Reset database
rm data/asset_predictor.db
npx drizzle-kit push

# Verify schema
npx drizzle-kit studio
```

### المشكلة: API keys not working

```bash
# Verify .env is loaded
pm2 restart gold-predictor --update-env

# Check environment
pm2 env 0
```

---

## 📊 المراقبة

### PM2 Monitoring

```bash
# Real-time monitoring
pm2 monit

# Logs
pm2 logs gold-predictor

# Metrics
pm2 describe gold-predictor
```

### Health Checks

```bash
# Automated health check (every 5 minutes)
*/5 * * * * curl -f http://localhost:2505/api/health || pm2 restart gold-predictor
```

---

## 🔄 التحديثات

```bash
# Pull latest code
git pull origin main

# Install new dependencies
pnpm install

# Rebuild
pnpm build

# Restart with zero downtime
pm2 reload gold-predictor

# Verify
pm2 status
curl http://localhost:2505/api/health
```

---

## 🔙 Rollback

```bash
# Stop current version
pm2 stop gold-predictor

# Restore database backup
cp data/asset_predictor.db.backup data/asset_predictor.db

# Checkout previous version
git checkout <previous-commit>
pnpm install
pnpm build

# Restart
pm2 restart gold-predictor
```

---

## ✅ Checklist

- [ ] Dependencies installed
- [ ] .env configured
- [ ] Secrets generated
- [ ] Build successful
- [ ] Database migrated
- [ ] Application started
- [ ] Health check passed
- [ ] Authentication working
- [ ] Monitoring configured
- [ ] Backup strategy in place

---

## 📞 الدعم

**المشاكل الشائعة:** راجع `docs/DEPLOYMENT_CHECKLIST.md`  
**الأمان:** راجع `docs/SECURITY_GUIDELINES.md`  
**الأداء:** راجع `docs/PERFORMANCE_REPORT.md`

**Contact:** hady.m.farid@gmail.com

---

**🎉 تهانينا! المشروع الآن في الإنتاج!**

