# Scalability Optimization Guide
# دليل تحسين قابلية التوسع

**Target:** Scalability Score 0.92 → 0.97 (Excellent)  
**Estimated Time:** 3-4 hours  
**Impact:** High

---

## Current State

**Scalability Score:** 0.92/1.00 (Good)

**Current Capacity:**
- Max concurrent users: 200
- Max requests/second: 180
- Database connections: 20
- Redis connections: 50

**Issues:**
- Single server deployment
- No horizontal scaling
- No load balancing
- Limited database connection pool
- No auto-scaling

---

## Target State

**Scalability Score:** 0.97/1.00 (Excellent)

**Target Capacity:**
- Max concurrent users: 10,000+
- Max requests/second: 5,000+
- Auto-scaling enabled
- Multi-region deployment
- Load balancing configured

---

## Optimization 1: Horizontal Scaling

### 1.1 Docker Swarm Setup

```bash
# Initialize Docker Swarm
docker swarm init --advertise-addr <MANAGER-IP>

# Add worker nodes
docker swarm join --token <TOKEN> <MANAGER-IP>:2377

# Deploy stack
docker stack deploy -c docker-compose.yml gold-predictor

# Scale services
docker service scale gold-predictor_backend=5
docker service scale gold-predictor_redis=3
```

### 1.2 Kubernetes Deployment

```yaml
# Create: k8s/deployment.yaml

apiVersion: apps/v1
kind: Deployment
metadata:
  name: gold-predictor-backend
  labels:
    app: gold-predictor
spec:
  replicas: 5  # Start with 5 replicas
  selector:
    matchLabels:
      app: gold-predictor
      tier: backend
  template:
    metadata:
      labels:
        app: gold-predictor
        tier: backend
    spec:
      containers:
      - name: backend
        image: goldpredictor/backend:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: gold-predictor-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: gold-predictor-secrets
              key: redis-url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: gold-predictor-backend
spec:
  selector:
    app: gold-predictor
    tier: backend
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: LoadBalancer
```

### 1.3 Auto-Scaling Configuration

```yaml
# Create: k8s/hpa.yaml

apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: gold-predictor-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: gold-predictor-backend
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300  # Wait 5 min before scaling down
      policies:
      - type: Percent
        value: 50  # Scale down by 50% at a time
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 0  # Scale up immediately
      policies:
      - type: Percent
        value: 100  # Double replicas at a time
        periodSeconds: 30
      - type: Pods
        value: 4  # Or add 4 pods at a time
        periodSeconds: 30
      selectPolicy: Max  # Use the policy that scales up most
```

---

## Optimization 2: Load Balancing

### 2.1 Nginx Load Balancer

```nginx
# /etc/nginx/conf.d/load-balancer.conf

upstream backend_servers {
    least_conn;  # Use least connections algorithm
    
    # Backend servers
    server backend1.goldpredictor.com:8000 max_fails=3 fail_timeout=30s;
    server backend2.goldpredictor.com:8000 max_fails=3 fail_timeout=30s;
    server backend3.goldpredictor.com:8000 max_fails=3 fail_timeout=30s;
    server backend4.goldpredictor.com:8000 max_fails=3 fail_timeout=30s;
    server backend5.goldpredictor.com:8000 max_fails=3 fail_timeout=30s;
    
    # Health check
    keepalive 32;
}

server {
    listen 80;
    listen 443 ssl http2;
    server_name api.goldpredictor.com;
    
    # SSL configuration
    ssl_certificate /etc/letsencrypt/live/api.goldpredictor.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.goldpredictor.com/privkey.pem;
    
    # Load balancing
    location / {
        proxy_pass http://backend_servers;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # Buffering
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 4k;
        proxy_busy_buffers_size 8k;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
```

### 2.2 AWS Application Load Balancer

```bash
# Create Application Load Balancer
aws elbv2 create-load-balancer \
  --name gold-predictor-alb \
  --subnets subnet-12345678 subnet-87654321 \
  --security-groups sg-12345678 \
  --scheme internet-facing \
  --type application \
  --ip-address-type ipv4

# Create target group
aws elbv2 create-target-group \
  --name gold-predictor-targets \
  --protocol HTTP \
  --port 8000 \
  --vpc-id vpc-12345678 \
  --health-check-enabled \
  --health-check-protocol HTTP \
  --health-check-path /health \
  --health-check-interval-seconds 30 \
  --health-check-timeout-seconds 5 \
  --healthy-threshold-count 2 \
  --unhealthy-threshold-count 3

# Register targets
aws elbv2 register-targets \
  --target-group-arn arn:aws:elasticloadbalancing:... \
  --targets Id=i-12345678 Id=i-87654321

# Create listener
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=arn:aws:acm:... \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...
```

---

## Optimization 3: Database Scaling

### 3.1 Read Replicas

```python
# backend/app/core/database.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Master (write) database
master_engine = create_engine(
    MASTER_DATABASE_URL,
    pool_size=20,
    max_overflow=40
)

# Read replicas
replica_engines = [
    create_engine(REPLICA1_DATABASE_URL, pool_size=20, max_overflow=40),
    create_engine(REPLICA2_DATABASE_URL, pool_size=20, max_overflow=40),
    create_engine(REPLICA3_DATABASE_URL, pool_size=20, max_overflow=40),
]

# Round-robin replica selection
replica_index = 0

def get_read_engine():
    """Get read replica engine (round-robin)"""
    global replica_index
    engine = replica_engines[replica_index]
    replica_index = (replica_index + 1) % len(replica_engines)
    return engine

def get_write_engine():
    """Get master engine for writes"""
    return master_engine

# Usage:
def get_db_read():
    """Get database session for reads"""
    engine = get_read_engine()
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_db_write():
    """Get database session for writes"""
    engine = get_write_engine()
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

### 3.2 Connection Pooling (PgBouncer)

```ini
# /etc/pgbouncer/pgbouncer.ini

[databases]
gold_predictor_prod = host=postgres-master.goldpredictor.com port=5432 dbname=gold_predictor_prod

[pgbouncer]
listen_addr = 0.0.0.0
listen_port = 6432
auth_type = md5
auth_file = /etc/pgbouncer/userlist.txt
admin_users = admin
pool_mode = transaction
max_client_conn = 1000
default_pool_size = 25
reserve_pool_size = 5
reserve_pool_timeout = 3
max_db_connections = 100
max_user_connections = 100
server_idle_timeout = 600
server_lifetime = 3600
server_connect_timeout = 15
query_timeout = 0
query_wait_timeout = 120
client_idle_timeout = 0
idle_transaction_timeout = 0
```

### 3.3 Database Sharding

```python
# backend/app/core/sharding.py

import hashlib

class DatabaseSharding:
    """Database sharding by user_id"""
    
    def __init__(self, shard_count: int = 4):
        self.shard_count = shard_count
        self.shards = [
            create_engine(f"postgresql://...shard{i}") 
            for i in range(shard_count)
        ]
    
    def get_shard(self, user_id: int):
        """Get shard for user_id"""
        shard_index = user_id % self.shard_count
        return self.shards[shard_index]
    
    def get_session(self, user_id: int):
        """Get database session for user"""
        engine = self.get_shard(user_id)
        SessionLocal = sessionmaker(bind=engine)
        return SessionLocal()

# Usage:
sharding = DatabaseSharding(shard_count=4)

@app.get("/api/predictions")
async def get_predictions(user_id: int):
    db = sharding.get_session(user_id)
    predictions = db.query(Prediction).filter(
        Prediction.user_id == user_id
    ).all()
    db.close()
    return predictions
```

---

## Optimization 4: Caching Strategy

### 4.1 Multi-Level Caching

```python
# backend/app/core/cache.py

from functools import wraps
import pickle

class MultiLevelCache:
    """Multi-level caching (Memory → Redis → Database)"""
    
    def __init__(self):
        self.memory_cache = {}  # L1: In-memory cache
        self.redis_client = redis_client  # L2: Redis cache
    
    async def get(self, key: str):
        """Get from cache (L1 → L2 → None)"""
        
        # Try L1 (memory)
        if key in self.memory_cache:
            return self.memory_cache[key]
        
        # Try L2 (Redis)
        value = await self.redis_client.get(key)
        if value:
            # Promote to L1
            self.memory_cache[key] = pickle.loads(value)
            return self.memory_cache[key]
        
        return None
    
    async def set(self, key: str, value: any, ttl: int = 300):
        """Set in cache (L1 + L2)"""
        
        # Set in L1
        self.memory_cache[key] = value
        
        # Set in L2
        await self.redis_client.setex(key, ttl, pickle.dumps(value))
    
    def invalidate(self, key: str):
        """Invalidate cache entry"""
        
        # Remove from L1
        self.memory_cache.pop(key, None)
        
        # Remove from L2
        self.redis_client.delete(key)

cache = MultiLevelCache()
```

### 4.2 Redis Cluster

```bash
# Create Redis Cluster (6 nodes: 3 masters + 3 replicas)

# Start Redis nodes
for port in 7000 7001 7002 7003 7004 7005; do
  redis-server --port $port \
    --cluster-enabled yes \
    --cluster-config-file nodes-${port}.conf \
    --cluster-node-timeout 5000 \
    --appendonly yes \
    --appendfilename appendonly-${port}.aof \
    --dbfilename dump-${port}.rdb \
    --logfile ${port}.log \
    --daemonize yes
done

# Create cluster
redis-cli --cluster create \
  127.0.0.1:7000 127.0.0.1:7001 127.0.0.1:7002 \
  127.0.0.1:7003 127.0.0.1:7004 127.0.0.1:7005 \
  --cluster-replicas 1
```

---

## Optimization 5: Async Task Queue

### 5.1 Celery Setup

```python
# backend/app/core/celery.py

from celery import Celery

celery_app = Celery(
    'gold_predictor',
    broker='redis://redis:6379/1',
    backend='redis://redis:6379/2'
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,  # 5 minutes
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
)

# Tasks
@celery_app.task
def train_model(model_name: str):
    """Train ML model (async)"""
    # Long-running task
    pass

@celery_app.task
def send_email(to: str, subject: str, body: str):
    """Send email (async)"""
    # I/O-bound task
    pass

# Usage in API:
@app.post("/api/models/train")
async def train_model_endpoint(model_name: str):
    """Trigger model training"""
    task = train_model.delay(model_name)
    return {"task_id": task.id, "status": "pending"}
```

### 5.2 Worker Scaling

```bash
# Start multiple Celery workers
celery -A app.core.celery worker --loglevel=info --concurrency=8 --hostname=worker1@%h
celery -A app.core.celery worker --loglevel=info --concurrency=8 --hostname=worker2@%h
celery -A app.core.celery worker --loglevel=info --concurrency=8 --hostname=worker3@%h

# Auto-scaling workers
celery -A app.core.celery worker --autoscale=10,3  # Max 10, min 3
```

---

## Optimization 6: CDN & Edge Caching

### 6.1 Cloudflare Workers

```javascript
// Cloudflare Worker for edge caching

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  const cache = caches.default
  const cacheKey = new Request(request.url, request)
  
  // Try cache first
  let response = await cache.match(cacheKey)
  
  if (!response) {
    // Cache miss, fetch from origin
    response = await fetch(request)
    
    // Cache successful responses
    if (response.status === 200) {
      // Clone response before caching
      const responseToCache = response.clone()
      
      // Cache for 5 minutes
      const headers = new Headers(responseToCache.headers)
      headers.set('Cache-Control', 'public, max-age=300')
      
      const cachedResponse = new Response(responseToCache.body, {
        status: responseToCache.status,
        statusText: responseToCache.statusText,
        headers: headers
      })
      
      event.waitUntil(cache.put(cacheKey, cachedResponse))
    }
  }
  
  return response
}
```

---

## Optimization 7: Monitoring & Alerts

### 7.1 Auto-Scaling Alerts

```yaml
# Prometheus alerts for auto-scaling

groups:
- name: scaling_alerts
  rules:
  - alert: HighCPUUsage
    expr: avg(rate(container_cpu_usage_seconds_total[5m])) > 0.8
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "High CPU usage detected"
      description: "CPU usage is above 80% for 5 minutes"
  
  - alert: HighMemoryUsage
    expr: avg(container_memory_usage_bytes / container_spec_memory_limit_bytes) > 0.9
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "High memory usage detected"
      description: "Memory usage is above 90% for 5 minutes"
  
  - alert: HighRequestRate
    expr: rate(http_requests_total[1m]) > 1000
    for: 2m
    labels:
      severity: info
    annotations:
      summary: "High request rate detected"
      description: "Request rate is above 1000 req/s"
```

---

## Expected Results

### Before Optimization

**Scalability Score:** 0.92/1.00 (Good)

| Metric | Value |
|--------|-------|
| Max Concurrent Users | 200 |
| Max Requests/Second | 180 |
| Deployment | Single server |
| Auto-Scaling | No |
| Load Balancing | No |

### After Optimization

**Scalability Score:** 0.97/1.00 (Excellent)

| Metric | Value | Improvement |
|--------|-------|-------------|
| Max Concurrent Users | 10,000+ | +4900% ⭐ |
| Max Requests/Second | 5,000+ | +2678% ⭐ |
| Deployment | Multi-region | ⭐ |
| Auto-Scaling | Yes (3-20 pods) | ⭐ |
| Load Balancing | Yes (ALB) | ⭐ |
| Database | Read replicas + Sharding | ⭐ |
| Caching | Multi-level (L1 + L2) | ⭐ |
| Task Queue | Celery workers | ⭐ |

---

## Implementation Checklist

- [ ] Setup Kubernetes cluster
- [ ] Configure horizontal pod autoscaling
- [ ] Setup load balancer (ALB/Nginx)
- [ ] Configure database read replicas
- [ ] Setup PgBouncer connection pooling
- [ ] Implement database sharding
- [ ] Setup Redis cluster
- [ ] Implement multi-level caching
- [ ] Setup Celery task queue
- [ ] Configure CDN edge caching
- [ ] Setup monitoring & alerts
- [ ] Load test scaled infrastructure

---

**Last Updated:** 2025-10-29  
**Target:** Scalability 0.92 → 0.97  
**Estimated Time:** 3-4 hours  
**Impact:** High

