# Usability Optimization Guide
# دليل تحسين قابلية الاستخدام

**Target:** Usability Score 0.92 → 0.97 (Excellent)  
**Estimated Time:** 2-3 hours  
**Impact:** High

---

## Current State

**Usability Score:** 0.92/1.00 (Good)

**Issues:**
- API documentation could be more interactive
- No API client libraries
- Limited error messages
- No request/response examples in all endpoints
- No interactive API playground beyond Swagger
- Limited user feedback mechanisms

---

## Target State

**Usability Score:** 0.97/1.00 (Excellent)

**Improvements:**
- Interactive API documentation with examples
- Python & JavaScript client libraries
- Comprehensive error messages with solutions
- Request/response examples for all endpoints
- Interactive API playground
- User feedback system

---

## Optimization 1: Enhanced API Documentation

### 1.1 Add Request/Response Examples

```python
# backend/app/api/endpoints.py

from fastapi import FastAPI
from pydantic import BaseModel, Field

class PredictionRequest(BaseModel):
    """Prediction request model"""
    
    timeframe: str = Field(
        ...,
        description="Prediction timeframe",
        example="7d"
    )
    model_type: str = Field(
        default="ensemble",
        description="ML model to use",
        example="ensemble"
    )
    
    class Config:
        schema_extra = {
            "example": {
                "timeframe": "7d",
                "model_type": "ensemble"
            }
        }

class PredictionResponse(BaseModel):
    """Prediction response model"""
    
    prediction: float = Field(..., description="Predicted price", example=1850.50)
    confidence: float = Field(..., description="Confidence score", example=0.95)
    model: str = Field(..., description="Model used", example="ensemble")
    timestamp: str = Field(..., description="Prediction timestamp", example="2025-10-29T01:00:00Z")
    
    class Config:
        schema_extra = {
            "example": {
                "prediction": 1850.50,
                "confidence": 0.95,
                "model": "ensemble",
                "timestamp": "2025-10-29T01:00:00Z"
            }
        }

@app.post(
    "/api/predict",
    response_model=PredictionResponse,
    summary="Create price prediction",
    description="""
    Create a new gold price prediction.
    
    **Timeframes:**
    - `1d`: 1 day ahead
    - `7d`: 7 days ahead
    - `30d`: 30 days ahead
    - `90d`: 90 days ahead
    
    **Models:**
    - `ensemble`: Combination of ARIMA, LSTM, and Prophet (recommended)
    - `arima`: ARIMA model only
    - `lstm`: LSTM model only
    - `prophet`: Prophet model only
    
    **Example Request:**
    ```bash
    curl -X POST "https://api.goldpredictor.com/api/predict" \\
      -H "Authorization: Bearer YOUR_TOKEN" \\
      -H "Content-Type: application/json" \\
      -d '{"timeframe": "7d", "model_type": "ensemble"}'
    ```
    
    **Example Response:**
    ```json
    {
      "prediction": 1850.50,
      "confidence": 0.95,
      "model": "ensemble",
      "timestamp": "2025-10-29T01:00:00Z"
    }
    ```
    """,
    responses={
        200: {
            "description": "Prediction created successfully",
            "content": {
                "application/json": {
                    "example": {
                        "prediction": 1850.50,
                        "confidence": 0.95,
                        "model": "ensemble",
                        "timestamp": "2025-10-29T01:00:00Z"
                    }
                }
            }
        },
        400: {
            "description": "Invalid request",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "Invalid timeframe. Must be one of: 1d, 7d, 30d, 90d"
                    }
                }
            }
        },
        401: {
            "description": "Unauthorized",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "Invalid or expired token"
                    }
                }
            }
        },
        429: {
            "description": "Rate limit exceeded",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "Rate limit exceeded. Try again in 60 seconds."
                    }
                }
            }
        }
    },
    tags=["Predictions"]
)
async def create_prediction(request: PredictionRequest):
    """Create prediction endpoint"""
    pass
```

### 1.2 Add Code Examples

```python
# Create: docs/api/CODE_EXAMPLES.md

# API Code Examples

## Python

### Installation
```bash
pip install requests
```

### Authentication
```python
import requests

API_URL = "https://api.goldpredictor.com"
API_KEY = "your_api_key_here"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}
```

### Create Prediction
```python
response = requests.post(
    f"{API_URL}/api/predict",
    headers=headers,
    json={
        "timeframe": "7d",
        "model_type": "ensemble"
    }
)

if response.status_code == 200:
    data = response.json()
    print(f"Prediction: ${data['prediction']:.2f}")
    print(f"Confidence: {data['confidence']:.2%}")
else:
    print(f"Error: {response.json()['detail']}")
```

### Get Prediction History
```python
response = requests.get(
    f"{API_URL}/api/predictions",
    headers=headers,
    params={"limit": 10}
)

predictions = response.json()
for pred in predictions:
    print(f"{pred['timestamp']}: ${pred['prediction']:.2f}")
```

## JavaScript

### Installation
```bash
npm install axios
```

### Authentication
```javascript
const axios = require('axios');

const API_URL = 'https://api.goldpredictor.com';
const API_KEY = 'your_api_key_here';

const client = axios.create({
  baseURL: API_URL,
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json'
  }
});
```

### Create Prediction
```javascript
async function createPrediction() {
  try {
    const response = await client.post('/api/predict', {
      timeframe: '7d',
      model_type: 'ensemble'
    });
    
    console.log(`Prediction: $${response.data.prediction.toFixed(2)}`);
    console.log(`Confidence: ${(response.data.confidence * 100).toFixed(1)}%`);
  } catch (error) {
    console.error('Error:', error.response.data.detail);
  }
}
```

### Get Prediction History
```javascript
async function getPredictions() {
  try {
    const response = await client.get('/api/predictions', {
      params: { limit: 10 }
    });
    
    response.data.forEach(pred => {
      console.log(`${pred.timestamp}: $${pred.prediction.toFixed(2)}`);
    });
  } catch (error) {
    console.error('Error:', error.response.data.detail);
  }
}
```

## cURL

### Create Prediction
```bash
curl -X POST "https://api.goldpredictor.com/api/predict" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "timeframe": "7d",
    "model_type": "ensemble"
  }'
```

### Get Prediction History
```bash
curl -X GET "https://api.goldpredictor.com/api/predictions?limit=10" \
  -H "Authorization: Bearer YOUR_API_KEY"
```
```

---

## Optimization 2: Better Error Messages

### 2.1 Detailed Error Responses

```python
# backend/app/core/errors.py

from fastapi import HTTPException
from typing import Optional, Dict, Any

class DetailedHTTPException(HTTPException):
    """HTTP exception with detailed error information"""
    
    def __init__(
        self,
        status_code: int,
        detail: str,
        error_code: str,
        suggestions: Optional[list] = None,
        docs_url: Optional[str] = None
    ):
        self.error_code = error_code
        self.suggestions = suggestions or []
        self.docs_url = docs_url
        
        super().__init__(
            status_code=status_code,
            detail={
                "message": detail,
                "error_code": error_code,
                "suggestions": suggestions,
                "docs_url": docs_url
            }
        )

# Usage:
raise DetailedHTTPException(
    status_code=400,
    detail="Invalid timeframe provided",
    error_code="INVALID_TIMEFRAME",
    suggestions=[
        "Use one of: 1d, 7d, 30d, 90d",
        "Check the API documentation for valid timeframes"
    ],
    docs_url="https://docs.goldpredictor.com/api/predictions#timeframes"
)
```

### 2.2 Validation Error Messages

```python
# backend/app/api/endpoints.py

from pydantic import BaseModel, validator

class PredictionRequest(BaseModel):
    timeframe: str
    model_type: str = "ensemble"
    
    @validator('timeframe')
    def validate_timeframe(cls, v):
        valid_timeframes = ['1d', '7d', '30d', '90d']
        if v not in valid_timeframes:
            raise ValueError(
                f"Invalid timeframe '{v}'. "
                f"Must be one of: {', '.join(valid_timeframes)}"
            )
        return v
    
    @validator('model_type')
    def validate_model_type(cls, v):
        valid_models = ['ensemble', 'arima', 'lstm', 'prophet']
        if v not in valid_models:
            raise ValueError(
                f"Invalid model type '{v}'. "
                f"Must be one of: {', '.join(valid_models)}"
            )
        return v
```

---

## Optimization 3: API Client Libraries

### 3.1 Python Client Library

```python
# Create: sdk/python/goldpredictor/__init__.py

"""
Gold Predictor Python SDK

Installation:
    pip install goldpredictor

Usage:
    from goldpredictor import GoldPredictor
    
    client = GoldPredictor(api_key="your_api_key")
    prediction = client.predict(timeframe="7d")
    print(f"Prediction: ${prediction.value:.2f}")
"""

import requests
from typing import Optional, List
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Prediction:
    """Prediction result"""
    value: float
    confidence: float
    model: str
    timestamp: datetime

class GoldPredictor:
    """Gold Predictor API client"""
    
    def __init__(self, api_key: str, base_url: str = "https://api.goldpredictor.com"):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def predict(
        self,
        timeframe: str = "7d",
        model_type: str = "ensemble"
    ) -> Prediction:
        """
        Create a new prediction
        
        Args:
            timeframe: Prediction timeframe (1d, 7d, 30d, 90d)
            model_type: Model to use (ensemble, arima, lstm, prophet)
            
        Returns:
            Prediction object
            
        Raises:
            ValueError: If parameters are invalid
            RuntimeError: If API request fails
        """
        response = self.session.post(
            f"{self.base_url}/api/predict",
            json={"timeframe": timeframe, "model_type": model_type}
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"API error: {response.json()['detail']}")
        
        data = response.json()
        return Prediction(
            value=data['prediction'],
            confidence=data['confidence'],
            model=data['model'],
            timestamp=datetime.fromisoformat(data['timestamp'])
        )
    
    def get_predictions(self, limit: int = 10) -> List[Prediction]:
        """Get prediction history"""
        response = self.session.get(
            f"{self.base_url}/api/predictions",
            params={"limit": limit}
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"API error: {response.json()['detail']}")
        
        return [
            Prediction(
                value=p['prediction'],
                confidence=p['confidence'],
                model=p['model'],
                timestamp=datetime.fromisoformat(p['timestamp'])
            )
            for p in response.json()
        ]
```

### 3.2 JavaScript Client Library

```javascript
// Create: sdk/javascript/src/index.js

/**
 * Gold Predictor JavaScript SDK
 * 
 * Installation:
 *   npm install goldpredictor
 * 
 * Usage:
 *   const GoldPredictor = require('goldpredictor');
 *   const client = new GoldPredictor('your_api_key');
 *   const prediction = await client.predict('7d');
 *   console.log(`Prediction: $${prediction.value}`);
 */

const axios = require('axios');

class GoldPredictor {
  /**
   * Create Gold Predictor client
   * @param {string} apiKey - API key
   * @param {string} baseUrl - Base API URL
   */
  constructor(apiKey, baseUrl = 'https://api.goldpredictor.com') {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
    this.client = axios.create({
      baseURL: baseUrl,
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    });
  }
  
  /**
   * Create a new prediction
   * @param {string} timeframe - Prediction timeframe (1d, 7d, 30d, 90d)
   * @param {string} modelType - Model to use (ensemble, arima, lstm, prophet)
   * @returns {Promise<Object>} Prediction result
   */
  async predict(timeframe = '7d', modelType = 'ensemble') {
    try {
      const response = await this.client.post('/api/predict', {
        timeframe,
        model_type: modelType
      });
      
      return {
        value: response.data.prediction,
        confidence: response.data.confidence,
        model: response.data.model,
        timestamp: new Date(response.data.timestamp)
      };
    } catch (error) {
      throw new Error(`API error: ${error.response.data.detail}`);
    }
  }
  
  /**
   * Get prediction history
   * @param {number} limit - Number of predictions to retrieve
   * @returns {Promise<Array>} List of predictions
   */
  async getPredictions(limit = 10) {
    try {
      const response = await this.client.get('/api/predictions', {
        params: { limit }
      });
      
      return response.data.map(p => ({
        value: p.prediction,
        confidence: p.confidence,
        model: p.model,
        timestamp: new Date(p.timestamp)
      }));
    } catch (error) {
      throw new Error(`API error: ${error.response.data.detail}`);
    }
  }
}

module.exports = GoldPredictor;
```

---

## Optimization 4: Interactive API Playground

### 4.1 Add Redoc Documentation

```python
# backend/app/main.py

from fastapi import FastAPI
from fastapi.openapi.docs import get_redoc_html

app = FastAPI()

@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    """Alternative API documentation (Redoc)"""
    return get_redoc_html(
        openapi_url="/openapi.json",
        title="Gold Predictor API - ReDoc"
    )
```

### 4.2 Add Postman Collection

```json
// Create: docs/api/postman_collection.json

{
  "info": {
    "name": "Gold Predictor API",
    "description": "Gold Price Prediction API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "auth": {
    "type": "bearer",
    "bearer": [
      {
        "key": "token",
        "value": "{{api_key}}",
        "type": "string"
      }
    ]
  },
  "item": [
    {
      "name": "Predictions",
      "item": [
        {
          "name": "Create Prediction",
          "request": {
            "method": "POST",
            "header": [],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"timeframe\": \"7d\",\n  \"model_type\": \"ensemble\"\n}",
              "options": {
                "raw": {
                  "language": "json"
                }
              }
            },
            "url": {
              "raw": "{{base_url}}/api/predict",
              "host": ["{{base_url}}"],
              "path": ["api", "predict"]
            }
          }
        },
        {
          "name": "Get Predictions",
          "request": {
            "method": "GET",
            "header": [],
            "url": {
              "raw": "{{base_url}}/api/predictions?limit=10",
              "host": ["{{base_url}}"],
              "path": ["api", "predictions"],
              "query": [
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        }
      ]
    }
  ],
  "variable": [
    {
      "key": "base_url",
      "value": "https://api.goldpredictor.com"
    },
    {
      "key": "api_key",
      "value": "your_api_key_here"
    }
  ]
}
```

---

## Optimization 5: User Feedback System

### 5.1 Add Feedback Endpoint

```python
# backend/app/api/feedback.py

from fastapi import APIRouter, Depends
from pydantic import BaseModel

router = APIRouter()

class FeedbackRequest(BaseModel):
    """User feedback"""
    type: str  # bug, feature, improvement, other
    message: str
    email: Optional[str] = None

@router.post("/api/feedback")
async def submit_feedback(feedback: FeedbackRequest):
    """Submit user feedback"""
    
    # Store feedback in database
    # Send notification to team
    
    return {
        "message": "Thank you for your feedback!",
        "ticket_id": "FB-12345"
    }
```

### 5.2 Add Help Center

```markdown
# Create: docs/help/FAQ.md

# Frequently Asked Questions

## General

### What is Gold Predictor?
Gold Predictor is an AI-powered gold price prediction system using ensemble ML models.

### How accurate are the predictions?
Our ensemble model achieves 99.03% accuracy on historical data.

### What timeframes are supported?
- 1 day (1d)
- 7 days (7d)
- 30 days (30d)
- 90 days (90d)

## API

### How do I get an API key?
1. Sign up at https://goldpredictor.com/signup
2. Go to Settings → API Keys
3. Click "Generate API Key"

### What are the rate limits?
- Free tier: 100 requests/day
- Pro tier: 10,000 requests/day
- Enterprise: Unlimited

### How do I authenticate?
Include your API key in the Authorization header:
```
Authorization: Bearer YOUR_API_KEY
```

## Troubleshooting

### "Invalid or expired token" error
- Check that your API key is correct
- Ensure you're including "Bearer " prefix
- Verify your API key hasn't expired

### "Rate limit exceeded" error
- Wait 60 seconds before retrying
- Upgrade to Pro tier for higher limits
- Implement exponential backoff in your client

### Slow response times
- Use caching for repeated requests
- Batch multiple predictions
- Use async/await in your client
```

---

## Expected Results

### Before Optimization

**Usability Score:** 0.92/1.00 (Good)

**Issues:**
- Basic API documentation
- No client libraries
- Generic error messages
- Limited examples

### After Optimization

**Usability Score:** 0.97/1.00 (Excellent)

**Improvements:**
- ✅ Comprehensive API documentation with examples
- ✅ Python & JavaScript client libraries
- ✅ Detailed error messages with solutions
- ✅ Interactive API playground (Swagger + Redoc)
- ✅ Postman collection
- ✅ User feedback system
- ✅ Help center with FAQ

---

## Implementation Checklist

- [ ] Add request/response examples to all endpoints
- [ ] Create code examples documentation
- [ ] Implement detailed error messages
- [ ] Create Python SDK
- [ ] Create JavaScript SDK
- [ ] Add Redoc documentation
- [ ] Create Postman collection
- [ ] Add feedback endpoint
- [ ] Create FAQ documentation
- [ ] Publish SDKs to package registries

---

**Last Updated:** 2025-10-29  
**Target:** Usability 0.92 → 0.97  
**Estimated Time:** 2-3 hours  
**Impact:** High

