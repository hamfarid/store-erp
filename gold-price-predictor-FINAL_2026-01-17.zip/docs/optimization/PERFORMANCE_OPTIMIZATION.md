# Performance Optimization Guide
# دليل تحسين الأداء

**Target:** Performance Score 0.93 → 0.97 (Excellent)  
**Estimated Time:** 2-3 hours  
**Impact:** High

---

## Current State

**Performance Score:** 0.93/1.00 (Good)

**Metrics:**
- Response Time (p50): 120ms ✅
- Response Time (p95): 350ms ✅
- Response Time (p99): 680ms ⚠️ (Target: <500ms)
- Throughput: 120 req/s ✅
- Cache Hit Rate: 75% ⚠️ (Target: >85%)
- Database Query Time: 45ms ⚠️ (Target: <30ms)

**Issues:**
- P99 latency too high (680ms vs 500ms target)
- Cache hit rate below target (75% vs 85%)
- Some database queries not optimized
- No query result caching
- No connection pooling optimization

---

## Target State

**Performance Score:** 0.97/1.00 (Excellent)

**Metrics:**
- Response Time (p50): <100ms
- Response Time (p95): <300ms
- Response Time (p99): <500ms ⭐
- Throughput: >150 req/s
- Cache Hit Rate: >85% ⭐
- Database Query Time: <30ms ⭐

---

## Optimization 1: Database Query Optimization

### 1.1 Add Database Indexes

```sql
-- Create indexes for frequently queried columns

-- Users table
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_created_at ON users(created_at DESC);

-- Predictions table
CREATE INDEX idx_predictions_user_id ON predictions(user_id);
CREATE INDEX idx_predictions_created_at ON predictions(created_at DESC);
CREATE INDEX idx_predictions_user_created ON predictions(user_id, created_at DESC);

-- Models table
CREATE INDEX idx_models_name ON models(name);
CREATE INDEX idx_models_version ON models(version);

-- Analyze tables
ANALYZE users;
ANALYZE predictions;
ANALYZE models;
```

### 1.2 Optimize Queries

**Before (Slow):**
```python
# N+1 query problem
predictions = db.query(Prediction).filter(
    Prediction.user_id == user_id
).all()

for prediction in predictions:
    user = db.query(User).filter(User.id == prediction.user_id).first()
    # Process...
```

**After (Fast):**
```python
# Use JOIN to fetch related data
from sqlalchemy.orm import joinedload

predictions = db.query(Prediction).options(
    joinedload(Prediction.user)
).filter(
    Prediction.user_id == user_id
).all()

# All data loaded in single query
```

### 1.3 Add Query Result Caching

```python
# backend/app/core/cache.py

from functools import wraps
import hashlib
import json
from typing import Any, Callable
from .redis import redis_client

def cache_query(ttl: int = 300):
    """
    Cache database query results in Redis
    
    Args:
        ttl: Time to live in seconds (default: 5 minutes)
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            # Generate cache key from function name and arguments
            cache_key = f"query:{func.__name__}:{hashlib.md5(
                json.dumps({'args': args, 'kwargs': kwargs}, sort_keys=True).encode()
            ).hexdigest()}"
            
            # Try to get from cache
            cached = await redis_client.get(cache_key)
            if cached:
                return json.loads(cached)
            
            # Execute query
            result = await func(*args, **kwargs)
            
            # Store in cache
            await redis_client.setex(
                cache_key,
                ttl,
                json.dumps(result)
            )
            
            return result
        return wrapper
    return decorator

# Usage:
@cache_query(ttl=600)  # Cache for 10 minutes
async def get_user_predictions(user_id: int):
    return db.query(Prediction).filter(
        Prediction.user_id == user_id
    ).all()
```

---

## Optimization 2: Connection Pooling

### 2.1 Optimize PostgreSQL Connection Pool

```python
# backend/app/core/database.py

from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool

# Optimized connection pool settings
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,              # Increased from 10
    max_overflow=40,           # Increased from 20
    pool_pre_ping=True,        # Test connections before use
    pool_recycle=3600,         # Recycle connections after 1 hour
    echo=False,
    connect_args={
        "connect_timeout": 10,
        "application_name": "gold_predictor",
        "options": "-c statement_timeout=30000"  # 30s timeout
    }
)
```

### 2.2 Optimize Redis Connection Pool

```python
# backend/app/core/redis.py

import redis
from redis.connection import ConnectionPool

# Optimized Redis connection pool
pool = ConnectionPool(
    host=REDIS_HOST,
    port=REDIS_PORT,
    password=REDIS_PASSWORD,
    db=0,
    max_connections=50,        # Increased from 20
    socket_timeout=5,
    socket_connect_timeout=5,
    socket_keepalive=True,
    health_check_interval=30
)

redis_client = redis.Redis(connection_pool=pool)
```

---

## Optimization 3: Response Caching

### 3.1 Add HTTP Response Caching

```python
# backend/app/middleware/cache.py

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import hashlib

class CacheMiddleware(BaseHTTPMiddleware):
    """Cache HTTP responses"""
    
    async def dispatch(self, request: Request, call_next):
        # Only cache GET requests
        if request.method != "GET":
            return await call_next(request)
        
        # Generate cache key
        cache_key = f"http:{request.url.path}:{hashlib.md5(
            str(request.query_params).encode()
        ).hexdigest()}"
        
        # Try to get from cache
        cached = await redis_client.get(cache_key)
        if cached:
            return Response(
                content=cached,
                media_type="application/json",
                headers={"X-Cache": "HIT"}
            )
        
        # Execute request
        response = await call_next(request)
        
        # Cache successful responses
        if response.status_code == 200:
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            
            await redis_client.setex(cache_key, 300, body)  # 5 minutes
            
            return Response(
                content=body,
                status_code=response.status_code,
                headers=dict(response.headers) | {"X-Cache": "MISS"},
                media_type=response.media_type
            )
        
        return response

# Add to app
app.add_middleware(CacheMiddleware)
```

### 3.2 Add Cache-Control Headers

```python
# backend/app/api/endpoints.py

from fastapi import Response

@app.get("/api/models")
async def get_models(response: Response):
    """Get available models"""
    
    # Add cache headers
    response.headers["Cache-Control"] = "public, max-age=3600"  # 1 hour
    response.headers["ETag"] = generate_etag(models)
    
    return models

@app.get("/api/predictions/{id}")
async def get_prediction(id: int, response: Response):
    """Get prediction by ID"""
    
    # Predictions are immutable, cache forever
    response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
    
    return prediction
```

---

## Optimization 4: Async Processing

### 4.1 Use Async Database Queries

```python
# backend/app/api/endpoints.py

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.ext.asyncio import async_sessionmaker

# Create async engine
async_engine = create_async_engine(
    DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://"),
    pool_size=20,
    max_overflow=40
)

AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False
)

# Async endpoint
@app.get("/api/predictions")
async def get_predictions(
    db: AsyncSession = Depends(get_async_db)
):
    """Get predictions (async)"""
    
    result = await db.execute(
        select(Prediction).order_by(Prediction.created_at.desc()).limit(100)
    )
    predictions = result.scalars().all()
    
    return predictions
```

### 4.2 Parallel API Calls

```python
import asyncio
import aiohttp

async def fetch_external_data():
    """Fetch data from multiple external APIs in parallel"""
    
    async with aiohttp.ClientSession() as session:
        # Fetch from multiple sources in parallel
        tasks = [
            fetch_gold_price(session),
            fetch_market_data(session),
            fetch_news_sentiment(session)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        return {
            "gold_price": results[0],
            "market_data": results[1],
            "news_sentiment": results[2]
        }
```

---

## Optimization 5: Compression

### 5.1 Enable Gzip Compression

```python
# backend/app/main.py

from fastapi.middleware.gzip import GZipMiddleware

# Add Gzip compression
app.add_middleware(GZipMiddleware, minimum_size=1000)  # Compress responses >1KB
```

### 5.2 Enable Brotli Compression

```python
# backend/app/middleware/brotli.py

from starlette.middleware.base import BaseHTTPMiddleware
import brotli

class BrotliMiddleware(BaseHTTPMiddleware):
    """Brotli compression middleware"""
    
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        
        # Check if client accepts Brotli
        if "br" in request.headers.get("accept-encoding", ""):
            # Compress response
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            
            compressed = brotli.compress(body, quality=4)
            
            return Response(
                content=compressed,
                status_code=response.status_code,
                headers=dict(response.headers) | {
                    "Content-Encoding": "br",
                    "Content-Length": str(len(compressed))
                },
                media_type=response.media_type
            )
        
        return response

app.add_middleware(BrotliMiddleware)
```

---

## Optimization 6: ML Model Optimization

### 6.1 Model Caching

```python
# backend/app/ml/models.py

from functools import lru_cache
import joblib

@lru_cache(maxsize=10)
def load_model(model_name: str, version: str):
    """Load ML model with caching"""
    model_path = f"models/{model_name}_{version}.pkl"
    return joblib.load(model_path)

# Models stay in memory, no repeated loading
```

### 6.2 Batch Predictions

```python
# backend/app/ml/predict.py

async def predict_batch(inputs: List[dict]) -> List[dict]:
    """Process multiple predictions in batch"""
    
    # Load model once
    model = load_model("ensemble", "v1.0")
    
    # Prepare batch input
    X = np.array([prepare_features(inp) for inp in inputs])
    
    # Predict in batch (faster than individual predictions)
    predictions = model.predict(X)
    
    return [
        {"input": inp, "prediction": pred}
        for inp, pred in zip(inputs, predictions)
    ]
```

### 6.3 Model Quantization

```python
# Reduce model size and inference time

import tensorflow as tf

# Quantize model to int8
converter = tf.lite.TFLiteConverter.from_saved_model("model/")
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.target_spec.supported_types = [tf.int8]

quantized_model = converter.convert()

# Save quantized model (50-75% smaller, 2-3x faster)
with open("model_quantized.tflite", "wb") as f:
    f.write(quantized_model)
```

---

## Optimization 7: CDN & Static Assets

### 7.1 Optimize Static Assets

```nginx
# nginx.conf

location /static/ {
    alias /var/www/static/;
    
    # Enable caching
    expires 1y;
    add_header Cache-Control "public, immutable";
    
    # Enable compression
    gzip on;
    gzip_types text/css application/javascript image/svg+xml;
    gzip_comp_level 6;
    
    # Enable Brotli
    brotli on;
    brotli_types text/css application/javascript image/svg+xml;
    brotli_comp_level 6;
}
```

### 7.2 Use CDN

```python
# backend/app/core/config.py

# Use CDN for static assets
STATIC_URL = "https://cdn.goldpredictor.com/static/"

# Or use Cloudflare CDN (automatic with Cloudflare)
```

---

## Optimization 8: Database Optimization

### 8.1 PostgreSQL Configuration

```sql
-- postgresql.conf optimizations

# Memory
shared_buffers = 2GB                    # 25% of RAM
effective_cache_size = 6GB              # 75% of RAM
work_mem = 50MB                         # Per query
maintenance_work_mem = 512MB

# Checkpoints
checkpoint_completion_target = 0.9
wal_buffers = 16MB
max_wal_size = 4GB
min_wal_size = 1GB

# Query planner
random_page_cost = 1.1                  # For SSD
effective_io_concurrency = 200          # For SSD

# Parallel queries
max_parallel_workers_per_gather = 4
max_parallel_workers = 8

# Connection
max_connections = 200
```

### 8.2 Vacuum & Analyze

```bash
# Create cron job for regular maintenance

# /etc/cron.daily/postgres-maintenance
#!/bin/bash

# Vacuum and analyze
docker exec gold-predictor-db psql -U goldpredictor -d gold_predictor_prod -c "VACUUM ANALYZE;"

# Reindex
docker exec gold-predictor-db psql -U goldpredictor -d gold_predictor_prod -c "REINDEX DATABASE gold_predictor_prod;"
```

---

## Optimization 9: Load Testing

### 9.1 Run Load Tests

```bash
# Install k6
curl https://github.com/grafana/k6/releases/download/v0.45.0/k6-v0.45.0-linux-amd64.tar.gz -L | tar xvz
sudo mv k6-v0.45.0-linux-amd64/k6 /usr/local/bin/

# Run load test
k6 run tests/e2e/test_load.js

# Expected results:
# - p95 < 300ms
# - p99 < 500ms
# - Error rate < 1%
# - Throughput > 150 req/s
```

### 9.2 Analyze Results

```javascript
// tests/e2e/test_load.js

import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '2m', target: 50 },   // Ramp up to 50 users
    { duration: '5m', target: 50 },   // Stay at 50 users
    { duration: '2m', target: 100 },  // Ramp up to 100 users
    { duration: '5m', target: 100 },  // Stay at 100 users
    { duration: '2m', target: 0 },    // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<300', 'p(99)<500'],  // 95% < 300ms, 99% < 500ms
    http_req_failed: ['rate<0.01'],                 // Error rate < 1%
  },
};

export default function () {
  // Test health endpoint
  let res = http.get('https://goldpredictor.com/health');
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 300ms': (r) => r.timings.duration < 300,
  });
  
  sleep(1);
}
```

---

## Monitoring Performance

### Add Performance Metrics

```python
# backend/app/middleware/metrics.py

from prometheus_client import Histogram, Counter

# Request duration histogram
request_duration = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration',
    ['method', 'endpoint', 'status']
)

# Database query duration
db_query_duration = Histogram(
    'db_query_duration_seconds',
    'Database query duration',
    ['query_type']
)

# Cache hit rate
cache_hits = Counter('cache_hits_total', 'Cache hits')
cache_misses = Counter('cache_misses_total', 'Cache misses')

# Usage:
with request_duration.labels('GET', '/api/predictions', '200').time():
    response = await get_predictions()
```

---

## Expected Results

### Before Optimization

| Metric | Value |
|--------|-------|
| Response Time (p50) | 120ms |
| Response Time (p95) | 350ms |
| Response Time (p99) | 680ms ⚠️ |
| Throughput | 120 req/s |
| Cache Hit Rate | 75% ⚠️ |
| DB Query Time | 45ms ⚠️ |
| **Performance Score** | **0.93** |

### After Optimization

| Metric | Value | Improvement |
|--------|-------|-------------|
| Response Time (p50) | 80ms | -33% ⭐ |
| Response Time (p95) | 250ms | -29% ⭐ |
| Response Time (p99) | 450ms | -34% ⭐ |
| Throughput | 180 req/s | +50% ⭐ |
| Cache Hit Rate | 88% | +17% ⭐ |
| DB Query Time | 25ms | -44% ⭐ |
| **Performance Score** | **0.97** | **+0.04** ⭐ |

---

## Implementation Checklist

- [ ] Add database indexes
- [ ] Optimize database queries
- [ ] Add query result caching
- [ ] Optimize connection pooling
- [ ] Add HTTP response caching
- [ ] Implement async processing
- [ ] Enable compression (Gzip + Brotli)
- [ ] Optimize ML models
- [ ] Configure CDN
- [ ] Optimize PostgreSQL config
- [ ] Run load tests
- [ ] Monitor performance metrics

---

**Last Updated:** 2025-10-29  
**Target:** Performance 0.93 → 0.97  
**Estimated Time:** 2-3 hours  
**Impact:** High

