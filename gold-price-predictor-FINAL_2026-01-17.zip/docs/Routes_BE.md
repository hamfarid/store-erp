# Backend Routes - Gold & Assets Price Prediction System

<!-- cSpell:disable -->

**FILE**: docs/Routes_BE.md | **PURPOSE**: Complete backend API routes documentation | **OWNER**: Backend Team | **RELATED**: API_Contracts.md, ARCHITECTURE.md, Permissions_Model.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Backend Stack**: FastAPI (Python) + tRPC (Node.js)  
**Base URLs**:

- FastAPI: `http://localhost:5073`
- tRPC: `http://localhost:2505`

---

## Table of Contents

1. [Backend Architecture](#1-backend-architecture)
2. [FastAPI Routes](#2-fastapi-routes)
3. [tRPC Procedures](#3-trpc-procedures)
4. [Middleware Stack](#4-middleware-stack)
5. [Request/Response Flow](#5-requestresponse-flow)
6. [Error Handling](#6-error-handling)

---

## 1. Backend Architecture

### 1.1 Dual-Backend Architecture

```
┌──────────────────────────────────────────────────┐
│              Frontend (React)                     │
│            http://localhost:5573                  │
└───────────┬──────────────────────┬───────────────┘
            │                      │
            │ tRPC (type-safe)     │ Axios (direct)
            ▼                      ▼
┌───────────────────────┐  ┌──────────────────────┐
│   tRPC Server         │  │  FastAPI Backend     │
│   Node.js + TypeScript│  │  Python + FastAPI    │
│   http://localhost:2505│  │  http://localhost:5073│
│   ├─ Auth routes      │  │  ├─ Auth endpoints   │
│   ├─ Asset routes     │  │  ├─ 2FA endpoints    │
│   ├─ Prediction routes│  │  ├─ Prediction API   │
│   └─ Alert routes     │  │  └─ ML Engine API    │
└───────────┬───────────┘  └──────────┬───────────┘
            │                         │
            │ HTTP/REST              │ Direct DB
            ▼                         ▼
┌───────────────────────┐  ┌──────────────────────┐
│   SQLite Database     │  │  PostgreSQL          │
│   (Drizzle ORM)       │  │  (SQLAlchemy)        │
│   - app data          │  │  - auth data         │
└───────────────────────┘  └──────────────────────┘
```

### 1.2 Responsibilities

**FastAPI Backend** (`backend/app/main.py`):

- Authentication & authorization (JWT, 2FA)
- ML predictions (8 models)
- Rate limiting (Redis)
- Audit logging
- API key management

**tRPC Server** (`server/routers.ts`):

- Type-safe RPC layer
- Asset management
- Prediction history
- Alert management
- Performance metrics

---

## 2. FastAPI Routes

### 2.1 Health & Status

#### GET /api/health

**Purpose**: Health check endpoint

**Access**: Public

**Response**:

```json
{
  "status": "healthy",
  "timestamp": 1700236800.123,
  "version": "3.0.0"
}
```

**Handler**: `backend/app/main.py:health()`

---

### 2.2 Authentication Routes

#### POST /api/auth/register

**Purpose**: Register new user

**Access**: Public

**Request Body**:

```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

**Response** (200):

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 900
}
```

**Validation**:

- Username: 3-50 chars, alphanumeric + underscore, unique
- Email: Valid format, unique
- Password: Min 8 chars, uppercase, lowercase, number

**Errors**:

- 400: Validation error (weak password, invalid email)
- 409: User already exists

**Handler**: `backend/app/auth_postgresql.py:register_user()`

---

#### POST /api/auth/login

**Purpose**: Authenticate user

**Access**: Public

**Request Body** (form data):

```
username=john_doe&password=SecurePass123
```

**Response** (200):

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 900,
  "requires_2fa": false
}
```

**If 2FA Enabled** (200):

```json
{
  "requires_2fa": true,
  "temp_token": "temp_eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Rate Limiting**: 5 attempts per minute per IP

**Account Lockout**: After 5 failed attempts, 15-minute lockout

**Errors**:

- 401: Invalid credentials
- 429: Too many requests (rate limited)
- 423: Account locked

**Handler**: `backend/app/auth_postgresql.py:login_user()`

---

#### POST /api/auth/refresh

**Purpose**: Refresh access token

**Access**: Requires valid refresh token

**Request Body**:

```json
{
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Response** (200):

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 900
}
```

**Errors**:

- 401: Invalid or expired refresh token

**Handler**: `backend/app/auth_postgresql.py:refresh_token()`

---

#### POST /api/auth/logout

**Purpose**: Logout user (invalidate tokens)

**Access**: Authenticated

**Headers**: `Authorization: Bearer <access_token>`

**Response** (200):

```json
{
  "message": "Logged out successfully"
}
```

**Handler**: `backend/app/auth_postgresql.py:logout_user()`

---

### 2.3 Two-Factor Authentication (2FA)

#### POST /api/auth/2fa/enable

**Purpose**: Enable 2FA for user

**Access**: Authenticated

**Response** (200):

```json
{
  "secret": "JBSWY3DPEHPK3PXP",
  "qr_code": "data:image/png;base64,iVBORw0KGgoAAAANS...",
  "backup_codes": ["12345678", "87654321", ...]
}
```

**Handler**: `backend/app/auth_2fa.py:enable_2fa()`

---

#### POST /api/auth/2fa/verify

**Purpose**: Verify 2FA token during login

**Access**: Requires temp_token from login

**Request Body**:

```json
{
  "temp_token": "temp_eyJ0eXAiOiJKV1QiLCJhbGc...",
  "totp_token": "123456"
}
```

**Response** (200):

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 900
}
```

**Errors**:

- 401: Invalid TOTP token
- 400: Token expired

**Handler**: `backend/app/auth_2fa.py:verify_2fa()`

---

#### POST /api/auth/2fa/disable

**Purpose**: Disable 2FA for user

**Access**: Authenticated + current password

**Request Body**:

```json
{
  "password": "SecurePass123"
}
```

**Response** (200):

```json
{
  "message": "2FA disabled successfully"
}
```

**Handler**: `backend/app/auth_2fa.py:disable_2fa()`

---

### 2.4 API Key Management

#### GET /api/auth/api-keys

**Purpose**: List user's API keys

**Access**: Authenticated (USER+)

**Response** (200):

```json
{
  "api_keys": [
    {
      "id": "key_abc123",
      "name": "Production Key",
      "prefix": "gp_prod_",
      "created_at": "2025-11-01T10:00:00Z",
      "last_used_at": "2025-11-17T14:30:00Z",
      "expires_at": null
    }
  ]
}
```

**Handler**: `backend/app/services/api_key_service.py:list_api_keys()`

---

#### POST /api/auth/api-keys

**Purpose**: Generate new API key

**Access**: Authenticated (USER+)

**Request Body**:

```json
{
  "name": "My API Key",
  "expires_in_days": 90
}
```

**Response** (201):

```json
{
  "id": "key_abc123",
  "name": "My API Key",
  "api_key": "gp_prod_a1b2c3d4e5f6g7h8",
  "created_at": "2025-11-17T15:00:00Z",
  "expires_at": "2026-02-15T15:00:00Z",
  "warning": "Save this key securely. It will not be shown again."
}
```

**Handler**: `backend/app/services/api_key_service.py:create_api_key()`

---

#### DELETE /api/auth/api-keys/{key_id}

**Purpose**: Revoke API key

**Access**: Authenticated (own keys or MANAGER+)

**Response** (200):

```json
{
  "message": "API key revoked successfully"
}
```

**Handler**: `backend/app/services/api_key_service.py:revoke_api_key()`

---

### 2.5 Prediction Routes

#### POST /api/predict

**Purpose**: Create ML price prediction

**Access**: Authenticated (USER+)

**Permission**: `predictions.create`

**Request Body**:

```json
{
  "symbol": "GOLD",
  "horizon": "short",
  "model": "ensemble"
}
```

**Response** (200):

```json
{
  "id": "pred_123",
  "symbol": "GOLD",
  "current_price": 1950.50,
  "predicted_price": 1975.20,
  "confidence": 0.95,
  "horizon": "short",
  "model_used": "ensemble",
  "created_at": "2025-11-17T15:30:00Z",
  "chart_data": [
    {"date": "2025-11-18", "price": 1955.0},
    {"date": "2025-11-19", "price": 1965.0},
    ...
  ]
}
```

**ML Models**:

- `arima`: ARIMA statistical model
- `lstm`: LSTM deep learning
- `ensemble`: Weighted ensemble (99.03% accuracy) - default

**Horizons**:

- `short`: 7 days
- `medium`: 30 days
- `long`: 90 days

**Rate Limiting**: 100 requests/minute per user

**Errors**:

- 400: Invalid symbol or horizon
- 429: Rate limit exceeded
- 503: ML engine unavailable (circuit breaker open)

**Handler**: `backend/app/main.py:create_prediction()` → `modules/ml_api.py:predict()`

---

#### GET /api/predictions/history

**Purpose**: Get prediction history

**Access**: Authenticated (USER+)

**Permission**: `predictions.view`

**Query Parameters**:

- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20, max: 100)
- `symbol`: Filter by asset (optional)
- `horizon`: Filter by horizon (optional)
- `start_date`: Filter by start date (optional)
- `end_date`: Filter by end date (optional)

**Response** (200):

```json
{
  "predictions": [
    {
      "id": "pred_123",
      "symbol": "GOLD",
      "current_price": 1950.5,
      "predicted_price": 1975.2,
      "actual_price": 1980.0,
      "accuracy": 99.75,
      "confidence": 0.95,
      "horizon": "short",
      "created_at": "2025-11-10T10:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 145,
    "pages": 8
  }
}
```

**Handler**: `backend/app/services/prediction_service.py:get_history()`

---

#### DELETE /api/predictions/{prediction_id}

**Purpose**: Delete prediction

**Access**: Authenticated (owner or MANAGER+)

**Permission**: `predictions.delete` (with ownership check)

**Response** (200):

```json
{
  "message": "Prediction deleted successfully"
}
```

**Errors**:

- 403: Not authorized to delete this prediction
- 404: Prediction not found

**Handler**: `backend/app/services/prediction_service.py:delete_prediction()`

---

### 2.6 User Management (Admin)

#### GET /api/users

**Purpose**: List all users (admin)

**Access**: MANAGER+

**Permission**: `users.list`

**Query Parameters**:

- `page`: Page number
- `limit`: Items per page
- `role`: Filter by role
- `search`: Search by username/email

**Response** (200):

```json
{
  "users": [
    {
      "id": "user_123",
      "username": "john_doe",
      "email": "john@example.com",
      "role": "USER",
      "created_at": "2025-01-15T10:00:00Z",
      "last_login": "2025-11-17T14:30:00Z"
    }
  ],
  "pagination": {...}
}
```

**Handler**: `backend/app/auth_postgresql.py:list_users()`

---

#### PUT /api/users/{user_id}

**Purpose**: Update user (admin)

**Access**: ADMIN

**Permission**: `users.update`

**Request Body**:

```json
{
  "role": "MANAGER",
  "is_active": true
}
```

**Response** (200):

```json
{
  "message": "User updated successfully",
  "user": {...}
}
```

**Handler**: `backend/app/auth_postgresql.py:update_user()`

---

#### DELETE /api/users/{user_id}

**Purpose**: Delete user (admin)

**Access**: ADMIN

**Permission**: `users.delete`

**Response** (200):

```json
{
  "message": "User deleted successfully"
}
```

**Handler**: `backend/app/auth_postgresql.py:delete_user()`

---

## 3. tRPC Procedures

### 3.1 tRPC Router Structure

**File**: `server/routers.ts`

```typescript
export const appRouter = router({
  // Auth procedures
  auth: authRouter,

  // Asset procedures
  assets: assetsRouter,

  // Prediction procedures
  predictions: predictionsRouter,

  // Alert procedures
  alerts: alertsRouter,

  // Performance procedures
  performance: performanceRouter,
});
```

### 3.2 Auth Procedures

#### auth.me

**Purpose**: Get current user info

**Input**: None (uses session)

**Output**:

```typescript
{
  id: string;
  username: string;
  email: string;
  role: 'ADMIN' | 'MANAGER' | 'USER' | 'GUEST';
  permissions: string[];
  created_at: string;
}
```

**Handler**: `server/routers/auth.ts:me()`

---

#### auth.updateProfile

**Purpose**: Update user profile

**Input**:

```typescript
{
  username?: string;
  email?: string;
}
```

**Output**:

```typescript
{
  message: string;
  user: User;
}
```

**Handler**: `server/routers/auth.ts:updateProfile()`

---

### 3.3 Asset Procedures

#### assets.list

**Purpose**: List all assets

**Input**: None

**Output**:

```typescript
{
  assets: Array<{
    id: string;
    symbol: string;
    name: string;
    type: "COMMODITY" | "CRYPTO" | "INDEX";
    current_price: number;
    change_24h: number;
    updated_at: string;
  }>;
}
```

**Handler**: `server/routers/assets.ts:list()`

---

#### assets.getPrice

**Purpose**: Get current price for asset

**Input**:

```typescript
{
  symbol: string;
}
```

**Output**:

```typescript
{
  symbol: string;
  current_price: number;
  timestamp: string;
  source: string;
}
```

**Handler**: `server/routers/assets.ts:getPrice()`

---

#### assets.create

**Purpose**: Create new asset (admin)

**Access**: ADMIN

**Input**:

```typescript
{
  symbol: string;
  name: string;
  type: "COMMODITY" | "CRYPTO" | "INDEX";
  data_source: string;
}
```

**Output**:

```typescript
{
  asset: Asset;
}
```

**Handler**: `server/routers/assets.ts:create()`

---

### 3.4 Prediction Procedures

#### predictions.list

**Purpose**: List predictions for current user

**Input**:

```typescript
{
  page?: number;
  limit?: number;
  symbol?: string;
}
```

**Output**:

```typescript
{
  predictions: Prediction[];
  pagination: {
    page: number;
    limit: number;
    total: number;
  };
}
```

**Handler**: `server/routers/predictions.ts:list()`

---

#### predictions.getById

**Purpose**: Get prediction by ID

**Input**:

```typescript
{
  id: string;
}
```

**Output**:

```typescript
{
  prediction: Prediction;
}
```

**Handler**: `server/routers/predictions.ts:getById()`

---

### 3.5 Alert Procedures

#### alerts.list

**Purpose**: List alerts for current user

**Input**:

```typescript
{
  active?: boolean;
}
```

**Output**:

```typescript
{
  alerts: Array<{
    id: string;
    symbol: string;
    condition: "above" | "below";
    target_price: number;
    current_price: number;
    is_triggered: boolean;
    created_at: string;
  }>;
}
```

**Handler**: `server/routers/alerts.ts:list()`

---

#### alerts.create

**Purpose**: Create price alert

**Input**:

```typescript
{
  symbol: string;
  condition: "above" | "below";
  target_price: number;
  notification_method: "email" | "push" | "both";
}
```

**Output**:

```typescript
{
  alert: Alert;
}
```

**Handler**: `server/routers/alerts.ts:create()`

---

#### alerts.delete

**Purpose**: Delete alert

**Input**:

```typescript
{
  id: string;
}
```

**Output**:

```typescript
{
  message: string;
}
```

**Handler**: `server/routers/alerts.ts:delete()`

---

### 3.6 Performance Procedures

#### performance.getMetrics

**Purpose**: Get system performance metrics

**Access**: MANAGER+

**Input**: None

**Output**:

```typescript
{
  metrics: {
    total_predictions: number;
    avg_accuracy: number;
    total_users: number;
    active_alerts: number;
    api_calls_24h: number;
  }
}
```

**Handler**: `server/routers/performance.ts:getMetrics()`

---

## 4. Middleware Stack

### 4.1 FastAPI Middleware (Execution Order)

```
1. CORS Middleware
   ↓
2. Security Headers Middleware
   ↓
3. Rate Limiting Middleware (Redis)
   ↓
4. Authentication Middleware (JWT)
   ↓
5. Audit Logging Middleware
   ↓
6. Route Handler
   ↓
7. Response Compression
   ↓
8. Response (JSON)
```

### 4.2 Middleware Implementation

**File**: `backend/app/main.py`

```python
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5573"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Security Headers
@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response

# Rate Limiting
@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    # See Security.md for full implementation
    ...

# Compression
app.add_middleware(GZipMiddleware, minimum_size=1000)
```

---

## 5. Request/Response Flow

### 5.1 Typical Request Flow

```
Client (Frontend)
  ↓ HTTP POST /api/predict
  ↓ Headers: Authorization: Bearer <JWT>
NGINX/ALB (Load Balancer)
  ↓ SSL Termination
FastAPI Application
  ↓ CORS Middleware
  ↓ Security Headers Middleware
  ↓ Rate Limiting Check (Redis)
  ↓ JWT Validation
  ↓ Permission Check (predictions.create)
  ↓ Audit Log (request received)
Route Handler (/api/predict)
  ↓ Input Validation (Pydantic)
  ↓ Business Logic
  ↓ ML Prediction Service
  ↓ Database Save (PostgreSQL)
  ↓ Cache Result (Redis)
  ↓ Audit Log (prediction created)
Response
  ↓ JSON Serialization
  ↓ Compression (GZip)
Client (Frontend)
```

---

## 6. Error Handling

### 6.1 Standard Error Response

```json
{
  "code": "VALIDATION_ERROR",
  "message": "Invalid request data",
  "details": {
    "field": "symbol",
    "error": "Symbol must be one of: GOLD, SILVER, CRUDE_OIL, BITCOIN, SP500"
  },
  "traceId": "abc-123-def-456",
  "timestamp": "2025-11-17T15:30:00Z"
}
```

### 6.2 HTTP Status Codes

| Code | Meaning               | Usage                    |
| ---- | --------------------- | ------------------------ |
| 200  | OK                    | Successful request       |
| 201  | Created               | Resource created         |
| 400  | Bad Request           | Validation error         |
| 401  | Unauthorized          | Missing or invalid auth  |
| 403  | Forbidden             | Insufficient permissions |
| 404  | Not Found             | Resource not found       |
| 409  | Conflict              | Duplicate resource       |
| 429  | Too Many Requests     | Rate limit exceeded      |
| 500  | Internal Server Error | Server error             |
| 503  | Service Unavailable   | Circuit breaker open     |

---

## 7. Additional FastAPI Routers (Extended Routes)

### 7.1 Users Router (`backend/app/routers/users.py`)

Base Path: `/api/users`

#### POST /api/users/

**Purpose**: Create new user (admin)  
**Access**: ADMIN  
**Permission**: `users.create`  
**Status Code**: 201

#### GET /api/users/

**Purpose**: List all users  
**Access**: MANAGER+  
**Permission**: `users.list`

#### GET /api/users/{user_id}

**Purpose**: Get user details  
**Access**: MANAGER+ or own user  
**Permission**: `users.view`

#### PUT /api/users/{user_id}

**Purpose**: Update user  
**Access**: ADMIN or own user  
**Permission**: `users.update`

#### DELETE /api/users/{user_id}

**Purpose**: Delete user  
**Access**: ADMIN  
**Permission**: `users.delete`  
**Status Code**: 204

---

### 7.2 Predictions Router (`backend/app/routers/predictions.py`)

Base Path: `/api/predictions`

#### GET /api/predictions/

**Purpose**: List predictions  
**Access**: USER+ (own predictions)  
**Permission**: `predictions.view`

#### GET /api/predictions/{prediction_id}

**Purpose**: Get prediction details  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `predictions.view`

#### PUT /api/predictions/{prediction_id}

**Purpose**: Update prediction  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `predictions.update`

#### DELETE /api/predictions/{prediction_id}

**Purpose**: Delete prediction  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `predictions.delete`  
**Status Code**: 204

---

### 7.3 Assets Router (`backend/app/routers/assets.py`)

Base Path: `/api/assets`

#### POST /api/assets/

**Purpose**: Create new asset  
**Access**: ADMIN  
**Permission**: `assets.create`  
**Status Code**: 201

#### GET /api/assets/

**Purpose**: List all assets  
**Access**: Public or USER+  
**Permission**: None

#### GET /api/assets/{asset_id}

**Purpose**: Get asset details  
**Access**: Public or USER+  
**Permission**: None

#### PUT /api/assets/{asset_id}

**Purpose**: Update asset  
**Access**: ADMIN  
**Permission**: `assets.update`

#### DELETE /api/assets/{asset_id}

**Purpose**: Delete asset  
**Access**: ADMIN  
**Permission**: `assets.delete`  
**Status Code**: 204

---

### 7.4 Alerts Router (`backend/app/routers/alerts.py`)

Base Path: `/api/alerts`

#### POST /api/alerts/

**Purpose**: Create new alert  
**Access**: USER+  
**Permission**: `alerts.create`  
**Status Code**: 201

#### GET /api/alerts/

**Purpose**: List user's alerts  
**Access**: USER+ (own alerts)  
**Permission**: `alerts.list`

#### GET /api/alerts/{alert_id}

**Purpose**: Get alert details  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `alerts.view`

#### PUT /api/alerts/{alert_id}

**Purpose**: Update alert  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `alerts.update`

#### DELETE /api/alerts/{alert_id}

**Purpose**: Delete alert  
**Access**: USER+ (own or MANAGER+)  
**Permission**: `alerts.delete`  
**Status Code**: 204

---

## 8. Extended tRPC Procedures Summary

### 8.1 Main Routers in `server/routers.ts`

**Core Routers**:

- `system` - System health and info
- `auth` - Authentication (4 procedures)
- `assets` - Asset management (6 procedures)
- `predictions` - Predictions (6 procedures)
- `alerts` - Price alerts (5 procedures)
- `users` - User management (5 procedures)
- `backup` - Backup operations (3 procedures)

**Extended Routers** (imported):

- `export` - Data export
- `logs` - Activity logs
- `dashboard` - Dashboard data
- `notifications` - Notifications
- `ai` - AI features
- `aiTasks` - AI task management
- `portfolio` - Portfolio management
- `settings` - User settings
- `reports` - Report generation
- `admin` - Admin operations
- `technicalIndicators` - Technical analysis
- `predictionsAdvanced` - Advanced predictions
- `comprehensive` - Comprehensive analysis

### 8.2 Backup Router (`server/routers.ts`)

#### backup.createFullBackup

**Purpose**: Create full system backup  
**Access**: ADMIN  
**Returns**: Backup file path

#### backup.restoreFullBackup

**Purpose**: Restore from backup  
**Access**: ADMIN  
**Input**: `{ backupFile: string }`

#### backup.deleteBackup

**Purpose**: Delete backup file  
**Access**: ADMIN  
**Input**: `{ backupFile: string }`

---

**Route Summary**:

**FastAPI Core**: 18 endpoints

- Health: 1
- Auth: 5
- 2FA: 3
- API Keys: 3
- Predictions: 3
- Users: 3

**FastAPI Extended Routers**: 19 endpoints

- Users Router: 5
- Predictions Router: 4
- Assets Router: 5
- Alerts Router: 5

**Total FastAPI**: 37 endpoints

**tRPC Core Procedures**: 26+

- Auth: 4
- Assets: 6
- Predictions: 6
- Alerts: 5
- Users: 5
- Backup: 3

**tRPC Extended Routers**: 13 additional routers

- system, export, logs, dashboard, notifications
- ai, aiTasks, portfolio, settings, reports
- admin, technicalIndicators, predictionsAdvanced

**Total tRPC**: 39+ procedures

**Grand Total**: 76+ API endpoints across FastAPI and tRPC

---

**Last Updated**: 2025-11-21  
**Next Review**: 2026-02-21  
**Version**: 3.1.0  
**Owner**: Backend Team
