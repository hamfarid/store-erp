# 🎭 Playwright Testing Guide

## 📋 نظرة عامة

تم إعداد Playwright لاختبار التطبيق بشكل شامل. يتضمن اختبارات E2E (End-to-End) لجميع الميزات الرئيسية.

---

## 🚀 تشغيل الاختبارات

### الأوامر المتاحة

```bash
# تشغيل جميع الاختبارات
npm run test:e2e

# تشغيل الاختبارات مع واجهة UI
npm run test:e2e:ui

# تشغيل الاختبارات مع عرض المتصفح
npm run test:e2e:headed

# تشغيل الاختبارات في وضع التصحيح
npm run test:e2e:debug

# عرض تقرير الاختبارات
npm run test:report
```

---

## 📁 هيكل الاختبارات

```
tests/
└── e2e/
    ├── auth.spec.ts        # اختبارات المصادقة
    └── dashboard.spec.ts   # اختبارات لوحة التحكم
```

---

## ✅ الاختبارات المتاحة

### 1️⃣ اختبارات المصادقة (auth.spec.ts)

#### ✅ نجحت (4 اختبارات)
1. **should load home page** - تحميل الصفحة الرئيسية
2. **should navigate to login page** - الانتقال لصفحة تسجيل الدخول
3. **should navigate to register page** - الانتقال لصفحة التسجيل
4. **should show error for password mismatch** - خطأ عند عدم تطابق كلمة المرور

#### ❌ فشلت (9 اختبارات)
1. **should show error for invalid credentials** - خطأ بيانات خاطئة
2. **should login successfully with admin credentials** - تسجيل دخول Admin
3. **should show error for weak password** - خطأ كلمة مرور ضعيفة
4. **should register new user successfully** - تسجيل مستخدم جديد
5. **should logout successfully** - تسجيل الخروج

### 2️⃣ اختبارات لوحة التحكم (dashboard.spec.ts)

#### ❌ فشلت (8 اختبارات)
جميع اختبارات Dashboard فشلت لأن تسجيل الدخول لا يعمل في الاختبارات.

---

## 🔍 المشاكل المكتشفة

### 1. تسجيل الدخول لا يعمل في الاختبارات

**السبب المحتمل**:
- الحقول في صفحة Login لا تحتوي على `name` attribute
- Playwright قد لا يجد الحقول بشكل صحيح باستخدام `getByLabel`
- قد تكون هناك مشكلة في Session/Cookie في بيئة الاختبار

**الحل المقترح**:
1. إضافة `name` attribute للحقول
2. استخدام `data-testid` للعناصر المهمة
3. التحقق من Session/Cookie في بيئة الاختبار

### 2. عنوان الصفحة غير صحيح

**المشكلة**: العنوان يظهر `%VITE_APP_TITLE%` بدلاً من `Gold Price Predictor`

**السبب**: متغيرات البيئة لا يتم استبدالها في بيئة الاختبار

**الحل**: تحديث `index.html` أو إضافة متغيرات البيئة للاختبارات

### 3. Strict Mode Violation

**المشكلة**: بعض العناصر تظهر مرتين (مثل رسالة "8 أحرف على الأقل")

**الحل**: استخدام selectors أكثر تحديداً

---

## 🛠️ التحسينات المقترحة

### 1. إضافة Data Test IDs

```tsx
// في Login.tsx
<Input
  id="email"
  name="email"
  data-testid="login-email"
  type="email"
  // ...
/>

<Input
  id="password"
  name="password"
  data-testid="login-password"
  type="password"
  // ...
/>

<Button
  type="submit"
  data-testid="login-submit"
  // ...
>
  تسجيل الدخول
</Button>
```

### 2. تحديث الاختبارات لاستخدام Test IDs

```typescript
// في auth.spec.ts
await page.getByTestId('login-email').fill('admin@example.com');
await page.getByTestId('login-password').fill('Admin@123');
await page.getByTestId('login-submit').click();
```

### 3. إضافة Fixtures للمصادقة

```typescript
// tests/fixtures/auth.ts
import { test as base } from '@playwright/test';

export const test = base.extend({
  authenticatedPage: async ({ page }, use) => {
    // Login
    await page.goto('/login');
    await page.getByTestId('login-email').fill('admin@example.com');
    await page.getByTestId('login-password').fill('Admin@123');
    await page.getByTestId('login-submit').click();
    await page.waitForURL('/dashboard');
    
    await use(page);
  },
});
```

---

## 📊 النتائج الحالية

```
✅ 4 نجحت
❌ 13 فشلت
⏱️ الوقت: 44.4 ثانية
```

---

## 🎯 الخطوات التالية

1. ✅ **إصلاح تسجيل الدخول في الاختبارات**
   - إضافة `data-testid` للحقول
   - التحقق من Session/Cookie
   - تحديث الاختبارات

2. ✅ **إصلاح عنوان الصفحة**
   - تحديث `index.html`
   - إضافة متغيرات البيئة

3. ✅ **إضافة اختبارات جديدة**
   - اختبارات الأصول (Assets)
   - اختبارات التنبيهات (Alerts)
   - اختبارات التقارير (Reports)

4. ✅ **تحسين الاختبارات الحالية**
   - استخدام Fixtures
   - إضافة Page Objects
   - تحسين Selectors

---

## 📚 الموارد

- [Playwright Documentation](https://playwright.dev/)
- [Best Practices](https://playwright.dev/docs/best-practices)
- [Test Selectors](https://playwright.dev/docs/selectors)
- [Debugging Tests](https://playwright.dev/docs/debug)

---

**آخر تحديث**: 2025-11-20
**الحالة**: 🟡 قيد التطوير

