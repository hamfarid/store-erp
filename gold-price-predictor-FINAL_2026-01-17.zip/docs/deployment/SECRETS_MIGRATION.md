# Secrets Migration Guide
# دليل ترحيل الأسرار

**Status:** Ready for migration  
**Estimated Time:** 30-45 minutes  
**Difficulty:** Intermediate

---

## Overview

هذا الدليل يشرح كيفية ترحيل الأسرار من ملفات `.env` إلى AWS Secrets Manager لتحسين الأمان.

---

## Why Migrate?

### Current State (`.env` files)

**Problems:**
- ❌ Stored in plain text
- ❌ Committed to Git (risk of exposure)
- ❌ No audit logging
- ❌ No rotation mechanism
- ❌ No access control

### Target State (AWS Secrets Manager)

**Benefits:**
- ✅ Encrypted at rest (AES-256)
- ✅ Encrypted in transit (TLS)
- ✅ Automatic rotation
- ✅ Audit logging (CloudTrail)
- ✅ Fine-grained access control (IAM)
- ✅ Version history

---

## Prerequisites

- AWS account with admin access
- AWS CLI installed and configured
- Python 3.11+ with boto3
- Current `.env` file with secrets

---

## Step 1: Setup AWS Secrets Manager

### 1.1 Install AWS CLI

```bash
# Install AWS CLI (if not installed)
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Verify installation
aws --version
```

### 1.2 Configure AWS CLI

```bash
# Configure credentials
aws configure

# Enter:
# - AWS Access Key ID
# - AWS Secret Access Key
# - Default region (e.g., us-east-1)
# - Default output format (json)

# Verify configuration
aws sts get-caller-identity
```

---

## Step 2: Create IAM Policy

### 2.1 Create Policy for Application

```bash
# Create policy file
cat > secrets-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret"
      ],
      "Resource": "arn:aws:secretsmanager:*:*:secret:gold-predictor/*"
    }
  ]
}
EOF

# Create policy
aws iam create-policy \
  --policy-name GoldPredictorSecretsReadPolicy \
  --policy-document file://secrets-policy.json

# Note the Policy ARN from output
```

### 2.2 Create IAM User

```bash
# Create IAM user for application
aws iam create-user --user-name gold-predictor-app

# Attach policy
aws iam attach-user-policy \
  --user-name gold-predictor-app \
  --policy-arn arn:aws:iam::YOUR_ACCOUNT_ID:policy/GoldPredictorSecretsReadPolicy

# Create access key
aws iam create-access-key --user-name gold-predictor-app

# Save the output (AccessKeyId and SecretAccessKey)
```

---

## Step 3: Migrate Secrets

### 3.1 Extract Secrets from .env

```bash
# Create migration script
cat > migrate-secrets.py << 'EOF'
#!/usr/bin/env python3
"""
Migrate secrets from .env to AWS Secrets Manager
"""

import os
import json
import boto3
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Initialize AWS Secrets Manager client
client = boto3.client('secretsmanager', region_name='us-east-1')

# Define secrets to migrate
SECRETS = {
    'gold-predictor/database': {
        'POSTGRES_USER': os.getenv('POSTGRES_USER'),
        'POSTGRES_PASSWORD': os.getenv('POSTGRES_PASSWORD'),
        'POSTGRES_DB': os.getenv('POSTGRES_DB'),
        'POSTGRES_HOST': os.getenv('POSTGRES_HOST', 'localhost'),
        'POSTGRES_PORT': os.getenv('POSTGRES_PORT', '5432'),
    },
    'gold-predictor/redis': {
        'REDIS_HOST': os.getenv('REDIS_HOST', 'localhost'),
        'REDIS_PORT': os.getenv('REDIS_PORT', '6379'),
        'REDIS_PASSWORD': os.getenv('REDIS_PASSWORD'),
    },
    'gold-predictor/jwt': {
        'JWT_SECRET_KEY': os.getenv('JWT_SECRET_KEY'),
        'JWT_ALGORITHM': os.getenv('JWT_ALGORITHM', 'HS256'),
        'JWT_EXPIRATION_MINUTES': os.getenv('JWT_EXPIRATION_MINUTES', '30'),
    },
    'gold-predictor/api-keys': {
        'EXTERNAL_API_KEY': os.getenv('EXTERNAL_API_KEY', ''),
    },
}

def create_or_update_secret(secret_name, secret_value):
    """Create or update a secret in AWS Secrets Manager"""
    try:
        # Try to create secret
        response = client.create_secret(
            Name=secret_name,
            Description=f'Secrets for {secret_name}',
            SecretString=json.dumps(secret_value)
        )
        print(f"✅ Created secret: {secret_name}")
        return response
    except client.exceptions.ResourceExistsException:
        # Secret exists, update it
        response = client.update_secret(
            SecretId=secret_name,
            SecretString=json.dumps(secret_value)
        )
        print(f"✅ Updated secret: {secret_name}")
        return response
    except Exception as e:
        print(f"❌ Error with {secret_name}: {str(e)}")
        return None

def main():
    print("🚀 Starting secrets migration...\n")
    
    # Migrate each secret
    for secret_name, secret_value in SECRETS.items():
        # Remove None values
        secret_value = {k: v for k, v in secret_value.items() if v is not None}
        
        if secret_value:
            create_or_update_secret(secret_name, secret_value)
        else:
            print(f"⚠️  Skipping {secret_name} (no values found)")
    
    print("\n✅ Migration completed!")
    print("\nNext steps:")
    print("1. Update application to use AWS Secrets Manager")
    print("2. Test application with new secrets")
    print("3. Remove .env file")

if __name__ == '__main__':
    main()
EOF

# Make executable
chmod +x migrate-secrets.py

# Install dependencies
pip3 install boto3 python-dotenv

# Run migration
python3 migrate-secrets.py
```

### 3.2 Verify Secrets

```bash
# List all secrets
aws secretsmanager list-secrets

# Get specific secret
aws secretsmanager get-secret-value \
  --secret-id gold-predictor/database \
  --query SecretString \
  --output text | jq .
```

---

## Step 4: Update Application

### 4.1 Install AWS SDK

```bash
# Add to requirements.txt
echo "boto3==1.28.0" >> requirements.txt

# Install
pip install boto3
```

### 4.2 Create Secrets Manager Client

```python
# Create: backend/app/core/secrets.py

import json
import boto3
from functools import lru_cache
from typing import Dict, Any

class SecretsManager:
    """AWS Secrets Manager client"""
    
    def __init__(self, region_name: str = 'us-east-1'):
        self.client = boto3.client('secretsmanager', region_name=region_name)
        self._cache = {}
    
    @lru_cache(maxsize=128)
    def get_secret(self, secret_name: str) -> Dict[str, Any]:
        """
        Get secret from AWS Secrets Manager
        
        Args:
            secret_name: Name of the secret
            
        Returns:
            Dictionary containing secret values
        """
        try:
            response = self.client.get_secret_value(SecretId=secret_name)
            secret_string = response['SecretString']
            return json.loads(secret_string)
        except Exception as e:
            print(f"Error retrieving secret {secret_name}: {str(e)}")
            raise
    
    def get_database_config(self) -> Dict[str, str]:
        """Get database configuration"""
        return self.get_secret('gold-predictor/database')
    
    def get_redis_config(self) -> Dict[str, str]:
        """Get Redis configuration"""
        return self.get_secret('gold-predictor/redis')
    
    def get_jwt_config(self) -> Dict[str, str]:
        """Get JWT configuration"""
        return self.get_secret('gold-predictor/jwt')
    
    def get_api_keys(self) -> Dict[str, str]:
        """Get API keys"""
        return self.get_secret('gold-predictor/api-keys')

# Global instance
secrets_manager = SecretsManager()
```

### 4.3 Update Configuration

```python
# Update: backend/app/core/config.py

from pydantic_settings import BaseSettings
from .secrets import secrets_manager

class Settings(BaseSettings):
    """Application settings"""
    
    # Environment
    ENVIRONMENT: str = "production"
    DEBUG: bool = False
    
    # Database (from Secrets Manager)
    @property
    def DATABASE_URL(self) -> str:
        config = secrets_manager.get_database_config()
        return f"postgresql://{config['POSTGRES_USER']}:{config['POSTGRES_PASSWORD']}@{config['POSTGRES_HOST']}:{config['POSTGRES_PORT']}/{config['POSTGRES_DB']}"
    
    # Redis (from Secrets Manager)
    @property
    def REDIS_URL(self) -> str:
        config = secrets_manager.get_redis_config()
        return f"redis://:{config['REDIS_PASSWORD']}@{config['REDIS_HOST']}:{config['REDIS_PORT']}/0"
    
    # JWT (from Secrets Manager)
    @property
    def JWT_SECRET_KEY(self) -> str:
        config = secrets_manager.get_jwt_config()
        return config['JWT_SECRET_KEY']
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
```

### 4.4 Update Docker Compose

```yaml
# Update: docker-compose.yml

version: '3.8'

services:
  backend:
    build: .
    environment:
      # AWS credentials for Secrets Manager
      - AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}
      - AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}
      - AWS_DEFAULT_REGION=us-east-1
      # Application settings
      - ENVIRONMENT=production
      - DEBUG=false
    # Remove database/redis credentials (now from Secrets Manager)
```

---

## Step 5: Test Migration

### 5.1 Local Testing

```bash
# Set AWS credentials
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1

# Test secrets retrieval
python3 << 'EOF'
from backend.app.core.secrets import secrets_manager

# Test database config
db_config = secrets_manager.get_database_config()
print("Database config:", db_config)

# Test Redis config
redis_config = secrets_manager.get_redis_config()
print("Redis config:", redis_config)

# Test JWT config
jwt_config = secrets_manager.get_jwt_config()
print("JWT config:", jwt_config)

print("✅ All secrets retrieved successfully!")
EOF
```

### 5.2 Integration Testing

```bash
# Start application
docker-compose up -d

# Check logs
docker-compose logs backend

# Test API
curl http://localhost:8000/health

# Expected: {"status":"healthy",...}
```

---

## Step 6: Cleanup

### 6.1 Remove .env Files

```bash
# Backup .env (just in case)
cp .env .env.backup

# Remove from repository
git rm .env
git rm .env.example

# Add to .gitignore (if not already)
echo ".env" >> .gitignore
echo ".env.*" >> .gitignore

# Commit
git add .gitignore
git commit -m "security: Remove .env files, migrate to AWS Secrets Manager"
git push origin main
```

### 6.2 Update Documentation

```bash
# Update README.md
vim README.md

# Add section about AWS Secrets Manager
# Remove references to .env files
```

---

## Step 7: Setup Secret Rotation

### 7.1 Enable Automatic Rotation

```bash
# Create rotation Lambda function (AWS Console)
# 1. Go to AWS Secrets Manager
# 2. Select secret
# 3. Click "Edit rotation"
# 4. Enable automatic rotation
# 5. Set rotation schedule (e.g., 30 days)
# 6. Choose rotation Lambda function

# Or via CLI:
aws secretsmanager rotate-secret \
  --secret-id gold-predictor/database \
  --rotation-lambda-arn arn:aws:lambda:us-east-1:123456789:function:SecretsManagerRotation \
  --rotation-rules AutomaticallyAfterDays=30
```

### 7.2 Test Rotation

```bash
# Manually trigger rotation
aws secretsmanager rotate-secret \
  --secret-id gold-predictor/database

# Check rotation status
aws secretsmanager describe-secret \
  --secret-id gold-predictor/database \
  --query 'RotationEnabled'
```

---

## Step 8: Monitoring & Auditing

### 8.1 Enable CloudTrail Logging

```bash
# CloudTrail automatically logs Secrets Manager API calls
# View logs in CloudWatch

# Example: View recent GetSecretValue calls
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=GetSecretValue \
  --max-results 10
```

### 8.2 Setup Alarms

```bash
# Create CloudWatch alarm for unauthorized access
aws cloudwatch put-metric-alarm \
  --alarm-name secrets-unauthorized-access \
  --alarm-description "Alert on unauthorized Secrets Manager access" \
  --metric-name UnauthorizedAPICallsCount \
  --namespace AWS/SecretsManager \
  --statistic Sum \
  --period 300 \
  --threshold 1 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 1
```

---

## Cost Estimate

| Item | Cost |
|------|------|
| Secrets storage | $0.40/secret/month |
| API calls | $0.05/10,000 calls |
| **Total (4 secrets)** | **~$2-4/month** |

---

## Rollback Procedure

If migration fails:

```bash
# 1. Restore .env file
cp .env.backup .env

# 2. Update docker-compose.yml to use .env

# 3. Restart services
docker-compose restart

# 4. Delete secrets from AWS (optional)
aws secretsmanager delete-secret \
  --secret-id gold-predictor/database \
  --force-delete-without-recovery
```

---

## Best Practices

### Security

- ✅ Use IAM roles instead of access keys (on EC2)
- ✅ Enable MFA for AWS account
- ✅ Use least privilege principle
- ✅ Enable CloudTrail logging
- ✅ Rotate secrets regularly

### Performance

- ✅ Cache secrets in application (with TTL)
- ✅ Use connection pooling
- ✅ Minimize API calls to Secrets Manager

### Monitoring

- ✅ Monitor API call metrics
- ✅ Setup alerts for failures
- ✅ Review CloudTrail logs regularly

---

## Troubleshooting

### Access Denied Error

```
Error: AccessDeniedException: User is not authorized to perform: secretsmanager:GetSecretValue
```

**Solution:**
```bash
# Check IAM policy
aws iam list-attached-user-policies --user-name gold-predictor-app

# Verify policy permissions
aws iam get-policy-version \
  --policy-arn arn:aws:iam::123456789:policy/GoldPredictorSecretsReadPolicy \
  --version-id v1
```

### Secret Not Found

```
Error: ResourceNotFoundException: Secrets Manager can't find the specified secret
```

**Solution:**
```bash
# List all secrets
aws secretsmanager list-secrets

# Check secret name
aws secretsmanager describe-secret --secret-id gold-predictor/database
```

### Connection Timeout

```
Error: ConnectTimeoutError: Connection to secretsmanager timed out
```

**Solution:**
```bash
# Check network connectivity
ping secretsmanager.us-east-1.amazonaws.com

# Check security group allows outbound HTTPS
# Check VPC endpoint (if using private subnet)
```

---

## Verification Checklist

- [ ] AWS CLI configured
- [ ] IAM policy created
- [ ] IAM user created with access key
- [ ] Secrets migrated to Secrets Manager
- [ ] Application updated to use Secrets Manager
- [ ] Local testing passed
- [ ] Integration testing passed
- [ ] .env files removed from repository
- [ ] Documentation updated
- [ ] Secret rotation enabled
- [ ] CloudTrail logging enabled
- [ ] Monitoring alarms configured

---

**Last Updated:** 2025-10-28  
**Status:** Ready for migration  
**Estimated Time:** 30-45 minutes

