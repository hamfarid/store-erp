# Production Deployment Guide
# دليل النشر الإنتاجي

**Status:** Ready for deployment  
**Estimated Time:** 2-3 hours  
**Difficulty:** Intermediate

---

## Overview

هذا الدليل يشرح كيفية نشر Gold Price Predictor إلى بيئة الإنتاج باستخدام Docker Compose على AWS EC2.

---

## Prerequisites

### Required

- AWS account with billing enabled
- Domain name (e.g., goldpredictor.com)
- SSL certificate (Let's Encrypt or AWS Certificate Manager)
- Basic Linux/Docker knowledge

### Recommended

- AWS CLI installed locally
- SSH key pair for EC2 access
- Git installed on production server

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Cloudflare CDN                        │
│                  (WAF + DDoS Protection)                 │
└─────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│                    Load Balancer                         │
│                   (AWS ALB / nginx)                      │
└─────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│                    EC2 Instance                          │
│                  (t3.medium, 2 vCPU, 4GB)               │
│                                                          │
│  ┌────────────────────────────────────────────────┐    │
│  │           Docker Compose Stack                  │    │
│  │                                                 │    │
│  │  • Backend (FastAPI)                           │    │
│  │  • PostgreSQL                                  │    │
│  │  • Redis                                       │    │
│  │  • Prometheus                                  │    │
│  │  • Grafana                                     │    │
│  └────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│                    AWS Services                          │
│                                                          │
│  • RDS (PostgreSQL) - Optional                          │
│  • ElastiCache (Redis) - Optional                       │
│  • S3 (Backups)                                         │
│  • Secrets Manager                                      │
│  • CloudWatch (Logs)                                    │
└─────────────────────────────────────────────────────────┘
```

---

## Step 1: Setup AWS EC2 Instance

### 1.1 Launch EC2 Instance

```bash
# Using AWS CLI
aws ec2 run-instances \
  --image-id ami-0c55b159cbfafe1f0 \
  --instance-type t3.medium \
  --key-name your-key-pair \
  --security-group-ids sg-xxxxxxxxx \
  --subnet-id subnet-xxxxxxxxx \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=gold-predictor-prod}]'
```

**Or via AWS Console:**

1. Go to EC2 Dashboard
2. Click "Launch Instance"
3. **Name:** gold-predictor-prod
4. **AMI:** Ubuntu Server 22.04 LTS
5. **Instance type:** t3.medium (2 vCPU, 4GB RAM)
6. **Key pair:** Create or select existing
7. **Network settings:**
   - VPC: Default or custom
   - Subnet: Public subnet
   - Auto-assign public IP: Enable
8. **Storage:** 30 GB gp3
9. Click "Launch instance"

### 1.2 Configure Security Group

**Inbound Rules:**

| Type | Protocol | Port | Source | Description |
|------|----------|------|--------|-------------|
| SSH | TCP | 22 | Your IP | SSH access |
| HTTP | TCP | 80 | 0.0.0.0/0 | HTTP traffic |
| HTTPS | TCP | 443 | 0.0.0.0/0 | HTTPS traffic |
| Custom TCP | TCP | 8000 | 0.0.0.0/0 | API (temporary) |
| Custom TCP | TCP | 3000 | Your IP | Grafana |
| Custom TCP | TCP | 9090 | Your IP | Prometheus |

**Outbound Rules:**
- All traffic: 0.0.0.0/0

---

## Step 2: Setup Server

### 2.1 Connect to Server

```bash
# SSH to server
ssh -i your-key.pem ubuntu@your-ec2-public-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y \
  git \
  curl \
  wget \
  vim \
  htop \
  net-tools
```

### 2.2 Install Docker

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker ubuntu

# Start Docker
sudo systemctl enable docker
sudo systemctl start docker

# Verify
docker --version
```

### 2.3 Install Docker Compose

```bash
# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

# Make executable
sudo chmod +x /usr/local/bin/docker-compose

# Verify
docker-compose --version
```

---

## Step 3: Deploy Application

### 3.1 Clone Repository

```bash
# Clone repository
cd /home/ubuntu
git clone https://github.com/hamfarid/gold-price-predictor.git
cd gold-price-predictor

# Checkout production branch (if exists)
git checkout production  # or main
```

### 3.2 Configure Environment

```bash
# Create production .env file
cat > .env << 'EOF'
# Database
POSTGRES_USER=goldpredictor
POSTGRES_PASSWORD=CHANGE_THIS_PASSWORD
POSTGRES_DB=gold_predictor_prod

# Redis
REDIS_PASSWORD=CHANGE_THIS_PASSWORD

# JWT
JWT_SECRET_KEY=CHANGE_THIS_SECRET_KEY

# Grafana
GRAFANA_PASSWORD=CHANGE_THIS_PASSWORD

# Application
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=INFO

# API Keys (if needed)
# EXTERNAL_API_KEY=your_api_key
EOF

# Secure .env file
chmod 600 .env

# IMPORTANT: Replace all CHANGE_THIS_* values with strong passwords
```

### 3.3 Start Services

```bash
# Pull latest images
docker-compose pull

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend
```

### 3.4 Verify Deployment

```bash
# Check backend health
curl http://localhost:8000/health

# Expected response:
# {"status":"healthy","checks":{"database":"ok","redis":"ok","ml_models":"ok"}}

# Check all services
docker-compose ps

# All services should be "Up"
```

---

## Step 4: Setup Nginx Reverse Proxy

### 4.1 Install Nginx

```bash
# Install Nginx
sudo apt install -y nginx

# Start Nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

### 4.2 Configure Nginx

```bash
# Create Nginx config
sudo vim /etc/nginx/sites-available/gold-predictor

# Add configuration:
```

```nginx
upstream backend {
    server localhost:8000;
}

server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    # SSL certificates (will be added by Certbot)
    # ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Logging
    access_log /var/log/nginx/gold-predictor-access.log;
    error_log /var/log/nginx/gold-predictor-error.log;

    # API proxy
    location /api {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Health check
    location /health {
        proxy_pass http://backend;
        access_log off;
    }

    # Docs
    location /docs {
        proxy_pass http://backend;
        proxy_set_header Host $host;
    }

    # Static files (if any)
    location /static {
        alias /home/ubuntu/gold-price-predictor/static;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=100r/m;
    limit_req zone=api_limit burst=20 nodelay;
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/gold-predictor /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

---

## Step 5: Setup SSL with Let's Encrypt

### 5.1 Install Certbot

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx
```

### 5.2 Obtain SSL Certificate

```bash
# Get certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Follow prompts:
# - Enter email
# - Agree to terms
# - Choose redirect option (2)

# Verify auto-renewal
sudo certbot renew --dry-run
```

### 5.3 Configure Auto-Renewal

```bash
# Certbot auto-renewal is configured automatically
# Check cron job:
sudo systemctl status certbot.timer

# Manual renewal (if needed):
sudo certbot renew
```

---

## Step 6: Setup Monitoring

### 6.1 Configure Prometheus

```bash
# Prometheus is already running via docker-compose
# Access: http://your-domain.com:9090

# Add alerting rules
vim monitoring/alerts.yml
```

```yaml
groups:
  - name: gold_predictor_alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status="500"}[5m]) > 0.05
        for: 5m
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value }} (threshold: 0.05)"

      - alert: HighLatency
        expr: histogram_quantile(0.95, http_request_duration_seconds) > 1
        for: 5m
        annotations:
          summary: "High latency detected"
          description: "P95 latency is {{ $value }}s (threshold: 1s)"

      - alert: ServiceDown
        expr: up == 0
        for: 2m
        annotations:
          summary: "Service is down"
          description: "{{ $labels.job }} is down"
```

### 6.2 Configure Grafana

```bash
# Access Grafana: http://your-domain.com:3000
# Login: admin / (password from .env)

# Import dashboards:
# 1. Go to Dashboards → Import
# 2. Upload JSON from monitoring/grafana/dashboards/
# 3. Select Prometheus datasource
```

---

## Step 7: Setup Backups

### 7.1 Database Backup Script

```bash
# Create backup script
cat > /home/ubuntu/backup-db.sh << 'EOF'
#!/bin/bash

# Configuration
BACKUP_DIR="/home/ubuntu/backups"
DATE=$(date +%Y%m%d-%H%M%S)
CONTAINER="gold-predictor-db"
DB_NAME="gold_predictor_prod"
DB_USER="goldpredictor"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
docker exec $CONTAINER pg_dump -U $DB_USER $DB_NAME | gzip > $BACKUP_DIR/db-backup-$DATE.sql.gz

# Upload to S3 (optional)
# aws s3 cp $BACKUP_DIR/db-backup-$DATE.sql.gz s3://your-bucket/backups/

# Keep only last 7 days
find $BACKUP_DIR -name "db-backup-*.sql.gz" -mtime +7 -delete

echo "Backup completed: db-backup-$DATE.sql.gz"
EOF

# Make executable
chmod +x /home/ubuntu/backup-db.sh

# Test backup
/home/ubuntu/backup-db.sh
```

### 7.2 Setup Cron Job

```bash
# Edit crontab
crontab -e

# Add daily backup at 2 AM
0 2 * * * /home/ubuntu/backup-db.sh >> /home/ubuntu/backup.log 2>&1
```

---

## Step 8: Setup Logging

### 8.1 Configure Log Rotation

```bash
# Create logrotate config
sudo vim /etc/logrotate.d/gold-predictor
```

```
/var/log/nginx/gold-predictor-*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data adm
    sharedscripts
    postrotate
        [ -f /var/run/nginx.pid ] && kill -USR1 `cat /var/run/nginx.pid`
    endscript
}
```

### 8.2 View Logs

```bash
# Application logs
docker-compose logs -f backend

# Nginx logs
sudo tail -f /var/log/nginx/gold-predictor-access.log
sudo tail -f /var/log/nginx/gold-predictor-error.log

# System logs
sudo journalctl -u docker -f
```

---

## Step 9: Performance Tuning

### 9.1 Optimize Docker

```bash
# Edit docker-compose.yml for production
vim docker-compose.yml
```

Add resource limits:

```yaml
services:
  backend:
    deploy:
      resources:
        limits:
          cpus: '1.5'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 1G
```

### 9.2 Optimize PostgreSQL

```bash
# Connect to PostgreSQL
docker exec -it gold-predictor-db psql -U goldpredictor -d gold_predictor_prod

# Run optimizations
VACUUM ANALYZE;
REINDEX DATABASE gold_predictor_prod;
```

---

## Step 10: Security Hardening

### 10.1 Firewall Configuration

```bash
# Install UFW
sudo apt install -y ufw

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

### 10.2 Fail2Ban

```bash
# Install Fail2Ban
sudo apt install -y fail2ban

# Configure
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo vim /etc/fail2ban/jail.local

# Enable and start
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

---

## Verification Checklist

After deployment, verify:

- [ ] All Docker containers running
- [ ] Backend health check passes
- [ ] API accessible via domain
- [ ] SSL certificate valid
- [ ] Nginx reverse proxy working
- [ ] Prometheus collecting metrics
- [ ] Grafana dashboards visible
- [ ] Database backups working
- [ ] Log rotation configured
- [ ] Firewall enabled
- [ ] Monitoring alerts configured

---

## Troubleshooting

### Service Won't Start

```bash
# Check logs
docker-compose logs backend

# Check container status
docker-compose ps

# Restart service
docker-compose restart backend
```

### Database Connection Failed

```bash
# Check PostgreSQL logs
docker-compose logs postgres

# Verify credentials
cat .env | grep POSTGRES

# Test connection
docker exec -it gold-predictor-db psql -U goldpredictor -d gold_predictor_prod
```

### High Memory Usage

```bash
# Check memory
free -h

# Check Docker stats
docker stats

# Restart services
docker-compose restart
```

---

## Rollback Procedure

If deployment fails:

```bash
# Stop services
docker-compose down

# Restore from backup
cd /home/ubuntu
rm -rf gold-price-predictor
tar -xzf gold-predictor-backup-YYYYMMDD.tar.gz

# Restore database
gunzip < backups/db-backup-YYYYMMDD.sql.gz | docker exec -i gold-predictor-db psql -U goldpredictor gold_predictor_prod

# Restart services
docker-compose up -d
```

---

## Maintenance

### Regular Tasks

**Daily:**
- Check application logs
- Monitor error rates
- Verify backups

**Weekly:**
- Review security alerts
- Update dependencies
- Check disk space

**Monthly:**
- Review performance metrics
- Update system packages
- Test disaster recovery

---

## Cost Estimate

| Service | Cost/Month |
|---------|------------|
| EC2 t3.medium | $30 |
| EBS 30GB | $3 |
| Data transfer | $5 |
| Backups (S3) | $2 |
| **Total** | **~$40/month** |

---

**Last Updated:** 2025-10-28  
**Status:** Ready for deployment  
**Estimated Time:** 2-3 hours

