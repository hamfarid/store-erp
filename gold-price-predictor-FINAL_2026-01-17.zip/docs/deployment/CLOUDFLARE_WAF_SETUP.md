# Cloudflare WAF Setup Guide
# دليل إعداد Cloudflare WAF

**Status:** Ready for setup  
**Estimated Time:** 30-45 minutes  
**Difficulty:** Easy to Intermediate

---

## Overview

هذا الدليل يشرح كيفية إعداد Cloudflare كـ CDN و WAF (Web Application Firewall) لحماية وتسريع Gold Price Predictor.

---

## Why Cloudflare?

### Benefits

**Security:**
- ✅ DDoS protection (automatic)
- ✅ WAF with OWASP rules
- ✅ Bot management
- ✅ SSL/TLS encryption
- ✅ Rate limiting

**Performance:**
- ✅ Global CDN (200+ locations)
- ✅ HTTP/2 & HTTP/3
- ✅ Automatic caching
- ✅ Image optimization
- ✅ Brotli compression

**Reliability:**
- ✅ 100% uptime SLA (Pro+)
- ✅ Load balancing
- ✅ Failover
- ✅ Health checks

---

## Prerequisites

- Domain name (e.g., goldpredictor.com)
- Access to domain DNS settings
- Production server deployed
- Credit card for Pro plan ($20/month)

---

## Step 1: Create Cloudflare Account

### 1.1 Sign Up

1. **Go to Cloudflare:**
   - Visit https://dash.cloudflare.com/sign-up

2. **Create account:**
   - Enter email and password
   - Verify email

3. **Add site:**
   - Click "Add a Site"
   - Enter your domain: `goldpredictor.com`
   - Click "Add site"

### 1.2 Select Plan

**Plans:**
- Free: $0/month (basic protection)
- Pro: $20/month (advanced features) ⭐ **Recommended**
- Business: $200/month (enterprise features)
- Enterprise: Custom pricing

**Select Pro plan for:**
- WAF
- Image optimization
- Mobile optimization
- 100% uptime SLA

---

## Step 2: Configure DNS

### 2.1 Review DNS Records

Cloudflare will scan your existing DNS records.

**Verify these records exist:**

| Type | Name | Content | Proxy |
|------|------|---------|-------|
| A | @ | your-server-ip | ✅ Proxied |
| A | www | your-server-ip | ✅ Proxied |
| CNAME | api | goldpredictor.com | ✅ Proxied |

### 2.2 Add Missing Records

If any records are missing:

1. Click "Add record"
2. **Type:** A
3. **Name:** @ (or www, api)
4. **IPv4 address:** Your server IP
5. **Proxy status:** Proxied (orange cloud)
6. Click "Save"

### 2.3 Update Nameservers

1. **Copy Cloudflare nameservers:**
   - Example: `alice.ns.cloudflare.com`
   - Example: `bob.ns.cloudflare.com`

2. **Update at your domain registrar:**
   - Login to your registrar (GoDaddy, Namecheap, etc.)
   - Find DNS settings
   - Replace nameservers with Cloudflare's
   - Save changes

3. **Wait for propagation:**
   - Usually 5-30 minutes
   - Can take up to 24 hours
   - Check status in Cloudflare dashboard

---

## Step 3: Configure SSL/TLS

### 3.1 SSL/TLS Settings

1. **Go to SSL/TLS tab**

2. **Select encryption mode:**
   - Choose "Full (strict)" ⭐ **Recommended**
   - This ensures end-to-end encryption

3. **Enable settings:**
   - ✅ Always Use HTTPS
   - ✅ Automatic HTTPS Rewrites
   - ✅ Minimum TLS Version: TLS 1.2
   - ✅ TLS 1.3: On
   - ✅ HTTP Strict Transport Security (HSTS)

### 3.2 Configure HSTS

1. Click "Enable HSTS"
2. **Settings:**
   - Max Age: 12 months
   - ✅ Include subdomains
   - ✅ Preload
   - ✅ No-Sniff header
3. Click "Next" → "I understand"

---

## Step 4: Configure WAF

### 4.1 Enable WAF

1. **Go to Security tab → WAF**

2. **Managed Rules:**
   - Click "Deploy managed ruleset"
   - Select "Cloudflare Managed Ruleset"
   - Click "Deploy"

3. **OWASP Rules:**
   - Click "Deploy managed ruleset"
   - Select "Cloudflare OWASP Core Ruleset"
   - Click "Deploy"

### 4.2 Configure WAF Rules

**Create custom rules:**

1. **Block known bad bots:**
   ```
   (cf.client.bot) and not (cf.verified_bot_category in {"Search Engine Crawler" "Monitoring & Analytics"})
   → Block
   ```

2. **Rate limit API:**
   ```
   (http.request.uri.path contains "/api/") and 
   (rate(1m) > 100)
   → Challenge
   ```

3. **Block SQL injection:**
   ```
   (http.request.uri.query contains "union select") or
   (http.request.uri.query contains "' or 1=1")
   → Block
   ```

4. **Block XSS attempts:**
   ```
   (http.request.uri.query contains "<script") or
   (http.request.uri.query contains "javascript:")
   → Block
   ```

---

## Step 5: Configure Rate Limiting

### 5.1 Create Rate Limiting Rules

1. **Go to Security → WAF → Rate limiting rules**

2. **API Rate Limit:**
   - Click "Create rule"
   - **Rule name:** API Rate Limit
   - **If incoming requests match:**
     - Field: URI Path
     - Operator: starts with
     - Value: `/api/`
   - **With the same:**
     - IP Address
   - **Exceeds:**
     - Requests: 100
     - Period: 1 minute
   - **Then:**
     - Action: Block
     - Duration: 10 minutes
   - Click "Save"

3. **Login Rate Limit:**
   - **Rule name:** Login Rate Limit
   - **URI Path:** `/api/auth/login`
   - **Requests:** 5
   - **Period:** 5 minutes
   - **Action:** Block
   - **Duration:** 30 minutes

4. **Prediction Rate Limit:**
   - **Rule name:** Prediction Rate Limit
   - **URI Path:** `/api/predict`
   - **Requests:** 50
   - **Period:** 1 minute
   - **Action:** Challenge

---

## Step 6: Configure Caching

### 6.1 Caching Rules

1. **Go to Caching → Configuration**

2. **Browser Cache TTL:**
   - Select "Respect Existing Headers"

3. **Create Page Rules:**

**Static Assets:**
- URL: `goldpredictor.com/static/*`
- Settings:
  - Cache Level: Cache Everything
  - Edge Cache TTL: 1 month
  - Browser Cache TTL: 1 month

**API Responses (no cache):**
- URL: `goldpredictor.com/api/*`
- Settings:
  - Cache Level: Bypass

**HTML Pages:**
- URL: `goldpredictor.com/*`
- Settings:
  - Cache Level: Standard
  - Edge Cache TTL: 2 hours
  - Browser Cache TTL: 4 hours

---

## Step 7: Configure Performance

### 7.1 Speed Settings

1. **Go to Speed → Optimization**

2. **Enable:**
   - ✅ Auto Minify (HTML, CSS, JS)
   - ✅ Brotli compression
   - ✅ Early Hints
   - ✅ HTTP/2
   - ✅ HTTP/3 (with QUIC)
   - ✅ 0-RTT Connection Resumption

3. **Image Optimization:**
   - ✅ Polish: Lossless
   - ✅ WebP conversion
   - ✅ Mirage (lazy loading)

### 7.2 Network Settings

1. **Go to Network**

2. **Enable:**
   - ✅ HTTP/2
   - ✅ HTTP/3 (with QUIC)
   - ✅ WebSockets
   - ✅ gRPC
   - ✅ Pseudo IPv4

---

## Step 8: Configure Firewall Rules

### 8.1 Country Blocking (Optional)

If you want to block specific countries:

1. **Go to Security → WAF → Custom rules**
2. **Create rule:**
   - **Rule name:** Block Countries
   - **If incoming requests match:**
     - Field: Country
     - Operator: is in
     - Value: [Select countries to block]
   - **Then:** Block
3. Click "Save"

### 8.2 IP Access Rules

**Whitelist your office IP:**

1. **Go to Security → WAF → Tools**
2. **IP Access Rules:**
   - Value: Your office IP
   - Action: Allow
   - Zone: This website
3. Click "Add"

**Blacklist known attackers:**
- Add IPs to block
- Action: Block

---

## Step 9: Configure Analytics

### 9.1 Enable Analytics

1. **Go to Analytics → Traffic**

2. **Available metrics:**
   - Requests
   - Bandwidth
   - Unique visitors
   - Threats blocked
   - Status codes

### 9.2 Setup Alerts

1. **Go to Notifications**

2. **Create alerts:**

**DDoS Attack:**
- Event: DDoS Attack
- Notification: Email + Webhook
- Webhook URL: Your Slack/Discord webhook

**High Error Rate:**
- Event: HTTP 5xx errors
- Threshold: > 5% for 5 minutes
- Notification: Email

**SSL Certificate Expiring:**
- Event: SSL certificate expiring
- Days before: 14
- Notification: Email

---

## Step 10: Test Configuration

### 10.1 Test DNS

```bash
# Check DNS propagation
dig goldpredictor.com
dig www.goldpredictor.com

# Should show Cloudflare IPs
```

### 10.2 Test SSL

```bash
# Test SSL certificate
curl -I https://goldpredictor.com

# Check SSL grade
# Visit: https://www.ssllabs.com/ssltest/analyze.html?d=goldpredictor.com
# Target: A+ rating
```

### 10.3 Test WAF

```bash
# Test SQL injection block
curl "https://goldpredictor.com/api/test?id=1' OR 1=1--"
# Expected: 403 Forbidden

# Test XSS block
curl "https://goldpredictor.com/api/test?q=<script>alert(1)</script>"
# Expected: 403 Forbidden

# Test rate limiting
for i in {1..150}; do
  curl https://goldpredictor.com/api/health
done
# Expected: 429 Too Many Requests after 100 requests
```

### 10.4 Test Performance

```bash
# Test response time
curl -w "@curl-format.txt" -o /dev/null -s https://goldpredictor.com

# Create curl-format.txt:
cat > curl-format.txt << 'EOF'
    time_namelookup:  %{time_namelookup}\n
       time_connect:  %{time_connect}\n
    time_appconnect:  %{time_appconnect}\n
   time_pretransfer:  %{time_pretransfer}\n
      time_redirect:  %{time_redirect}\n
 time_starttransfer:  %{time_starttransfer}\n
                    ----------\n
         time_total:  %{time_total}\n
EOF

# Test from multiple locations
# Visit: https://www.webpagetest.org/
```

---

## Step 11: Monitor & Maintain

### 11.1 Daily Monitoring

**Check dashboard:**
- Requests per minute
- Bandwidth usage
- Threats blocked
- Error rates

### 11.2 Weekly Review

**Security:**
- Review firewall events
- Check blocked threats
- Update WAF rules if needed

**Performance:**
- Check cache hit rate (target: >80%)
- Review slow endpoints
- Optimize caching rules

### 11.3 Monthly Tasks

**Updates:**
- Review and update rate limits
- Optimize caching strategy
- Review analytics trends

**Security:**
- Review firewall logs
- Update IP access rules
- Check for new WAF rules

---

## Cost Breakdown

### Cloudflare Pro Plan

| Feature | Included |
|---------|----------|
| Base price | $20/month |
| Bandwidth | Unlimited |
| Requests | Unlimited |
| DDoS protection | Included |
| WAF | Included |
| SSL certificate | Included |
| CDN | Included |
| **Total** | **$20/month** |

### Additional Costs (Optional)

| Feature | Cost |
|---------|------|
| Load Balancing | $5/month |
| Rate Limiting (extra) | $5/month |
| Argo Smart Routing | $5/month + $0.10/GB |
| Workers | $5/month + $0.50/million requests |

---

## Troubleshooting

### Site Not Loading

**Check:**
1. DNS propagation complete?
   ```bash
   dig goldpredictor.com
   ```
2. SSL mode correct? (Full strict)
3. Origin server accessible?
   ```bash
   curl http://your-server-ip
   ```

### SSL Errors

**Error:** "Your connection is not private"

**Solution:**
1. Check SSL mode: Full (strict)
2. Verify origin certificate valid
3. Check firewall allows port 443

### High Error Rate

**Check:**
1. Origin server health
2. WAF not blocking legitimate traffic
3. Rate limits not too strict

### Cache Not Working

**Check:**
1. Cache rules configured correctly
2. Origin sending correct cache headers
3. Bypass cache for dynamic content

---

## Security Best Practices

### Essential

- ✅ Enable WAF with OWASP rules
- ✅ Use Full (strict) SSL mode
- ✅ Enable HSTS
- ✅ Configure rate limiting
- ✅ Enable DDoS protection

### Recommended

- ✅ Enable Bot Management
- ✅ Configure custom firewall rules
- ✅ Setup security alerts
- ✅ Regular security reviews
- ✅ Monitor firewall events

### Advanced

- ✅ Implement geo-blocking if needed
- ✅ Use IP Access Rules for admin
- ✅ Configure custom error pages
- ✅ Enable Cloudflare Access for admin panel
- ✅ Implement Zero Trust security

---

## Verification Checklist

- [ ] Cloudflare account created
- [ ] Domain added to Cloudflare
- [ ] DNS records configured
- [ ] Nameservers updated
- [ ] SSL/TLS configured (Full strict)
- [ ] HSTS enabled
- [ ] WAF enabled with OWASP rules
- [ ] Rate limiting configured
- [ ] Caching rules configured
- [ ] Performance optimizations enabled
- [ ] Analytics enabled
- [ ] Alerts configured
- [ ] All tests passed

---

## Resources

- **Cloudflare Docs:** https://developers.cloudflare.com/
- **WAF Rules:** https://developers.cloudflare.com/waf/
- **Rate Limiting:** https://developers.cloudflare.com/waf/rate-limiting-rules/
- **SSL/TLS:** https://developers.cloudflare.com/ssl/
- **Community:** https://community.cloudflare.com/

---

**Last Updated:** 2025-10-28  
**Status:** Ready for setup  
**Estimated Time:** 30-45 minutes  
**Monthly Cost:** $20 (Pro plan)

