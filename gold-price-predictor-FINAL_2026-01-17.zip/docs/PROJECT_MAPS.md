# Project Maps - Gold Price Predictor

**Project:** Gold Price Predictor  
**Type:** Full-Stack (Frontend + Backend + ML)  
**Framework:** React 19 + TypeScript + Node.js + FastAPI + Python ML  
**Last Updated:** 2025-01-18

## Architecture Overview

This is a **multi-tier architecture** with three main layers:

1. **Frontend Layer**: React 19 + TypeScript + Redux + tRPC
2. **Backend Layer**: Dual backend (Node.js tRPC + FastAPI)
3. **ML Layer**: Python ML service with 4 models (LSTM, GRU, Transformer, Ensemble)
4. **Database Layer**: PostgreSQL + Drizzle ORM + SQLAlchemy

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React 19)                      │
│  - Pages: 50+ pages                                         │
│  - Components: shadcn/ui + custom                           │
│  - State: Redux Toolkit (auth, prediction, assets)         │
│  - Routing: Wouter                                          │
└────────────────────┬────────────────────────────────────────┘
                     │
                     │ tRPC (type-safe) + Axios (REST)
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              Backend Layer (Dual Backend)                   │
│                                                             │
│  ┌──────────────────────┐    ┌──────────────────────┐     │
│  │  Node.js tRPC Server │    │  FastAPI Backend     │     │
│  │  - routers.ts        │◄───┤  - main.py           │     │
│  │  - 14+ routers       │    │  - auth_postgresql   │     │
│  │  - db.ts (Drizzle)   │    │  - auth_2fa          │     │
│  └──────────────────────┘    │  - 13 services       │     │
│                               └──────────────────────┘     │
└────────────────────┬────────────────────┬───────────────────┘
                     │                    │
                     │                    │ HTTP/REST
                     ▼                    ▼
┌─────────────────────────────┐  ┌──────────────────────────┐
│   PostgreSQL (Drizzle ORM)  │  │  ML Backend (FastAPI)    │
│   - Users, Assets, Alerts   │  │  - 4 ML Models           │
│   - Predictions, Logs       │  │  - Training Service      │
└─────────────────────────────┘  │  - Prediction Service    │
                                  └──────────────────────────┘
```

---

## Directory Structure

```
gold-price-predictor/
├── client/                      # Frontend (React 19 + TypeScript)
│   └── src/
│       ├── pages/               # 50+ pages
│       ├── components/          # shadcn/ui + custom
│       ├── store/               # Redux Toolkit
│       ├── lib/                 # tRPC client
│       └── api/                 # Axios client
├── server/                      # Node.js tRPC Server
│   ├── routers.ts               # Main router
│   ├── db.ts                    # Drizzle ORM
│   └── routers/                 # 14+ sub-routers
├── backend/                     # FastAPI Backend
│   └── app/
│       ├── main.py              # FastAPI app
│       ├── auth_postgresql.py   # JWT auth
│       ├── auth_2fa.py          # 2FA
│       ├── database.py          # SQLAlchemy models
│       └── services/            # 13 services
├── ml_backend/                  # ML Service (FastAPI)
│   └── app/
│       ├── main.py              # ML FastAPI app
│       ├── routers/             # predictions, models, training
│       └── database.py          # ML models metadata
├── drizzle/                     # Database schema (Drizzle ORM)
│   ├── schema.ts                # Main schema
│   └── migrations/              # Migration files
├── ml/                          # ML training scripts
│   ├── enhanced_predictor.py    # 8 models
│   └── model_trainer.py         # Training logic
├── models/                      # Trained ML models
├── docs/                        # 30+ documentation files
├── logs/                        # Structured JSON logs
├── .memory/                     # AI memory system
└── github/global/               # Global guidelines
```

---

## Frontend Modules

### Pages (client/src/pages/)

| Page | Route | Purpose | Components Used | API Calls |
|------|-------|---------|-----------------|----------|
| Home | `/` | Landing page | Hero, Features | `GET /api/stats` |
| Login | `/login` | Authentication | LoginForm | `POST /api/auth/login` |
| DashboardEnhanced | `/dashboard` | Main dashboard | Charts, KPIs | `GET /api/dashboard` |
| Predict | `/predict` | Price prediction | PredictionForm | `POST /api/predictions` |
| PredictionHistory | `/history` | Past predictions | Table, Filters | `GET /api/predictions` |
| Alerts | `/alerts` | Price alerts | AlertsList, AlertForm | `GET /api/alerts` |
| AssetsList | `/assets` | Assets management | Table, Search | `GET /api/assets` |
| AssetsCreate | `/assets/create` | Add new asset | AssetForm | `POST /api/assets` |
| AssetsEdit | `/assets/edit/:id` | Edit asset | AssetForm | `PUT /api/assets/:id` |
| AssetsView | `/assets/view/:id` | View asset details | AssetDetails | `GET /api/assets/:id` |
| Portfolio | `/portfolio` | Portfolio management | PortfolioTable | `GET /api/portfolio` |
| AITasks | `/ai-tasks` | AI task management | TasksList | `GET /api/ai-tasks` |
| AdminDashboard | `/admin` | Admin panel | AdminStats | `GET /api/admin/stats` |
| AdminUsers | `/admin/users` | User management | UsersTable | `GET /api/admin/users` |
| AdminAssets | `/admin/assets` | Asset management | AssetsTable | `GET /api/admin/assets` |
| AdminLogs | `/admin/logs` | System logs | LogsTable | `GET /api/logs` |
| Reports | `/reports` | Generate reports | ReportForm | `POST /api/reports` |
| ModelTraining | `/admin/train-models` | Train ML models | TrainingForm | `POST /api/ml/training` |
| ModelPerformance | `/admin/model-performance` | Model metrics | PerformanceCharts | `GET /api/ml/models` |

### Components (client/src/components/)

| Component | Path | Used By | Props | State |
|-----------|------|---------|-------|-------|
| Navigation | `Navigation.tsx` | All pages | `user` | `isOpen` |
| MobileNav | `MobileNav.tsx` | All pages (mobile) | `user` | `isOpen` |
| ChatWidget | `AIAssistant/ChatWidget.tsx` | All pages | - | `messages` |
| ErrorBoundary | `ErrorBoundary.tsx` | App.tsx | `children` | `hasError` |
| TradingViewChart | `TradingViewChart.tsx` | Dashboard, Predict | `symbol`, `data` | - |
| shadcn/ui/* | `components/ui/` | All pages | Various | - |

### State Management (client/src/store/)

| Slice | Path | Purpose | State | Actions |
|-------|------|---------|-------|---------|
| authSlice | `slices/authSlice.ts` | Authentication | `user`, `token`, `isAuthenticated` | `login`, `logout`, `register` |
| predictionSlice | `slices/predictionSlice.ts` | Predictions | `predictions`, `currentPrediction`, `history` | `createPrediction`, `fetchHistory` |
| assetsSlice | `slices/assetsSlice.ts` | Assets | `assets`, `loading`, `error` | `fetchAssets`, `addAsset` |

### API Integration

| Service | Path | Purpose | Methods |
|---------|------|---------|----------|
| tRPC Client | `lib/trpc.ts` | Type-safe API calls | All tRPC procedures |
| API Client | `api/client.ts` | REST API calls | `login`, `register`, `predict`, `getAssets` |

---

## Backend Modules

### Node.js tRPC Server (server/)

| Router | Path | Procedures | Purpose |
|--------|------|------------|---------|
| appRouter | `routers.ts` | Main router | Combines all sub-routers |
| auth | `routers.ts` | `me`, `logout` | Authentication |
| system | `routers/system-router.ts` | System operations | Health, stats |
| dashboard | `routers/dashboard-router.ts` | Dashboard data | KPIs, charts |
| notifications | `routers/notifications-router.ts` | Notifications | CRUD operations |
| ai | `routers/ai-router.ts` | AI assistant | Chat, tasks |
| aiTasks | `routers/ai-tasks-router.ts` | AI task management | CRUD operations |
| portfolio | `routers/portfolio-router.ts` | Portfolio management | CRUD operations |
| settings | `routers/settings-router.ts` | User settings | Get, update |
| reports | `routers/reports-router.ts` | Report generation | Generate, download |
| admin | `routers/admin-router.ts` | Admin operations | Users, assets, logs |
| technicalIndicators | `routers/technical-indicators-router.ts` | Technical analysis | RSI, MACD, etc. |
| predictionsAdvanced | `routers/predictions-router.ts` | Advanced predictions | Multi-level predictions |

### FastAPI Backend (backend/app/)

| File | Purpose | Key Functions |
|------|---------|---------------|
| main.py | FastAPI application | App initialization, middleware, routes |
| auth_postgresql.py | JWT authentication | `authenticate_user`, `create_access_token`, `get_current_user` |
| auth_2fa.py | Two-factor authentication | `generate_totp_secret`, `verify_totp`, `send_2fa_code` |
| database.py | SQLAlchemy models | `UserDB`, `PredictionDB`, `AssetDB`, `get_db`, `init_db` |

### Backend Services (backend/app/services/)

| Service | Path | Purpose | Key Methods |
|---------|------|---------|-------------|
| API Key Service | `api_key_service.py` | API key management | `create_api_key`, `validate_api_key`, `revoke_api_key` |
| Backup Service | `backup_service.py` | Automated backups | `create_backup`, `restore_backup`, `cleanup_old_backups` |
| Cache Service | `cache_service.py` | Redis caching | `get`, `set`, `delete`, `clear` |
| Circuit Breaker | `circuit_breaker.py` | Resilience pattern | `call`, `open`, `close`, `half_open` |
| Economic Data Service | `economic_data_service.py` | Economic indicators | `get_gdp`, `get_inflation`, `get_interest_rates` |
| JWT Blacklist | `jwt_blacklist.py` | Token revocation | `blacklist_token`, `is_blacklisted` |
| Prediction Service | `prediction_service.py` | ML predictions | `predict`, `get_history`, `get_accuracy` |
| Secrets Manager | `secrets_manager.py` | Secrets management | `get_secret`, `set_secret`, `rotate_secret` |
| Sentiment Service | `sentiment_service.py` | News sentiment analysis | `analyze_sentiment`, `get_news` |

### ML Backend (ml_backend/app/)

| Router | Path | Endpoints | Purpose |
|--------|------|-----------|---------|
| Predictions | `routers/predictions.py` | `/predict`, `/batch-predict` | Generate predictions |
| Models | `routers/models.py` | `/list`, `/info`, `/compare` | Model management |
| Training | `routers/training.py` | `/train`, `/status`, `/history` | Model training |

---

## Database Schema

### PostgreSQL Tables (Drizzle ORM)

| Table | Columns | Indexes | Foreign Keys |
|-------|---------|---------|-------------|
| users | id, username, email, password_hash, role, created_at, updated_at, deleted_at | email (unique), username (unique) | - |
| assets | id, symbol, name, category, description, created_at, updated_at, deleted_at | symbol (unique) | - |
| predictions | id, user_id, asset_id, predicted_price, confidence, horizon, created_at | user_id, asset_id, created_at | user_id → users(id), asset_id → assets(id) |
| alerts | id, user_id, asset_id, condition, target_price, is_active, created_at | user_id, asset_id, is_active | user_id → users(id), asset_id → assets(id) |
| historical_prices | id, asset_id, price, volume, timestamp | asset_id, timestamp | asset_id → assets(id) |
| notifications | id, user_id, type, message, is_read, created_at | user_id, is_read | user_id → users(id) |
| ai_tasks | id, user_id, task_type, status, result, created_at | user_id, status | user_id → users(id) |
| portfolio | id, user_id, asset_id, quantity, purchase_price, created_at | user_id, asset_id | user_id → users(id), asset_id → assets(id) |
| logs | id, user_id, action, details, ip_address, created_at | user_id, created_at | user_id → users(id) |

### PostgreSQL Tables (SQLAlchemy - FastAPI Backend)

| Table | Columns | Purpose |
|-------|---------|---------|
| users | id, username, email, full_name, hashed_password, disabled, created_at, updated_at | User authentication |
| predictions | id, user_id, asset_symbol, predicted_price, confidence, model_used, created_at | Prediction history |
| assets | id, symbol, name, category, description, created_at, updated_at | Asset information |

### ML Backend Tables (SQLAlchemy)

| Table | Columns | Purpose |
|-------|---------|---------|
| ml_models | id, name, model_type, asset_symbol, version, accuracy, mse, rmse, mae, r2_score, training_date, is_active, hyperparameters, file_path, created_at | ML model metadata |
| ml_predictions | id, model_id, asset_symbol, prediction_date, predicted_price, confidence, actual_price, error, created_at | Prediction tracking |
| ml_training_jobs | id, model_type, asset_symbol, status, progress, current_epoch, total_epochs, metrics, error_message, started_at, completed_at, created_at | Training job tracking |

### Database Relationships

```
users (1) ─── (N) predictions
users (1) ─── (N) alerts
users (1) ─── (N) notifications
users (1) ─── (N) ai_tasks
users (1) ─── (N) portfolio
users (1) ─── (N) logs

assets (1) ─── (N) predictions
assets (1) ─── (N) alerts
assets (1) ─── (N) historical_prices
assets (1) ─── (N) portfolio

ml_models (1) ─── (N) ml_predictions
```

---

## Data Flow

### Example 1: User Login

```
[User] → [Frontend: Login Page]
  ↓
  [Submit Button Click]
  ↓
  [Frontend: authSlice.login()]
  ↓
  [API Call: POST /api/auth/login via Axios]
  ↓
  [Backend: FastAPI main.py]
  ↓
  [Backend: auth_postgresql.authenticate_user()]
  ↓
  [Database: SELECT FROM users WHERE username=?]
  ↓
  [Backend: create_access_token()]
  ↓
  [Response: 200 OK with JWT token]
  ↓
  [Frontend: Store token in Redux + localStorage]
  ↓
  [Frontend: Navigate to /dashboard]
  ↓
  [User sees dashboard]
```

### Example 2: Create Prediction

```
[User] → [Frontend: Predict Page]
  ↓
  [Submit Prediction Form]
  ↓
  [Frontend: predictionSlice.createPrediction()]
  ↓
  [API Call: POST /api/predictions via Axios]
  ↓
  [Backend: FastAPI main.py]
  ↓
  [Backend: prediction_service.predict()]
  ↓
  [ML Backend: POST /api/ml/predictions/predict]
  ↓
  [ML Backend: Load model from models/]
  ↓
  [ML Backend: Generate prediction]
  ↓
  [Database: INSERT INTO predictions]
  ↓
  [Response: 201 Created with prediction data]
  ↓
  [Frontend: Update Redux state]
  ↓
  [Frontend: Display prediction result]
  ↓
  [User sees prediction]
```

---

## Missing Files Checklist

### Frontend
- [x] All pages have corresponding routes
- [x] All components are documented
- [x] All services are implemented
- [x] All API calls are defined

### Backend
- [x] All routes have controllers
- [x] All controllers have services
- [x] All services have models
- [x] All models have migrations

### Database
- [x] All tables have migrations
- [x] All foreign keys are defined
- [x] All indexes are created

---

## Technology Stack Summary

### Frontend
- **Framework**: React 19
- **Language**: TypeScript
- **State Management**: Redux Toolkit
- **Routing**: Wouter
- **UI Library**: shadcn/ui + Tailwind CSS 4
- **API Client**: tRPC + Axios
- **Build Tool**: Vite

### Backend
- **Node.js**: Express + tRPC 11
- **Python**: FastAPI 3.0
- **ORM**: Drizzle ORM + SQLAlchemy
- **Authentication**: JWT + bcrypt
- **Caching**: Redis
- **Rate Limiting**: Redis-based

### ML/AI
- **Framework**: TensorFlow/Keras
- **Models**: LSTM, GRU, Transformer, Ensemble
- **Data Processing**: Pandas, NumPy
- **API**: FastAPI

### Database
- **Primary**: PostgreSQL
- **Caching**: Redis
- **ORM**: Drizzle ORM (Node.js) + SQLAlchemy (Python)

### DevOps
- **Containerization**: Docker + Docker Compose
- **Monitoring**: Prometheus + Grafana
- **Logging**: Structured JSON logs
- **CI/CD**: GitHub Actions (planned)

---

**Last Updated:** 2025-01-18
**Status:** Complete
**Next Steps:** Create comprehensive Task_List.md


