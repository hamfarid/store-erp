# Security Guidelines

> **Priority level: CRITICAL**

## Core Resources
- [Security Assessment](Security.md)
- [Comprehensive Security](Security_Comprehensive.md)
- [Permissions Model](Permissions_Model.md)

## Zero-Tolerance Rules
1. No Hardcoded Secrets.
2. No SQL Injection (Use ORM).
3. No XSS (Sanitize inputs).
4. No Unhandled Errors.
