# Resilience - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/Resilience.md | **PURPOSE**: Resilience patterns, circuit breakers, retry logic, fallback strategies | **OWNER**: DevOps Team | **RELATED**: ARCHITECTURE.md, DEPLOYMENT_GUIDE.md, Security.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Target Availability**: 99.9% (43.2 minutes downtime/month)

---

## Table of Contents
1. [Resilience Overview](#1-resilience-overview)
2. [Circuit Breakers](#2-circuit-breakers)
3. [Retry Policies](#3-retry-policies)
4. [Timeout Configurations](#4-timeout-configurations)
5. [Fallback Strategies](#5-fallback-strategies)
6. [Health Checks](#6-health-checks)
7. [Graceful Degradation](#7-graceful-degradation)
8. [Rate Limiting](#8-rate-limiting)
9. [Bulkhead Pattern](#9-bulkhead-pattern)
10. [Monitoring & Alerts](#10-monitoring--alerts)

---

## 1. Resilience Overview

### 1.1 Resilience Principles

**Definition**: System's ability to handle and recover from failures without cascading effects

**Core Patterns**:
1. **Circuit Breaker**: Prevent cascading failures by failing fast
2. **Retry**: Automatic retry with exponential backoff
3. **Timeout**: Prevent indefinite waits
4. **Fallback**: Graceful degradation with cached/default data
5. **Bulkhead**: Isolate resources to prevent total failure
6. **Health Check**: Proactive failure detection

### 1.2 Failure Modes

| Failure Type | Impact | Mitigation |
|--------------|--------|------------|
| **Database Unavailable** | Cannot save/retrieve data | Circuit breaker + cached reads |
| **ML Model Timeout** | Slow predictions | Timeout + fallback to last prediction |
| **External API Failure** | No price data | Retry + cached data + circuit breaker |
| **Redis Cache Down** | Performance degradation | Fallback to database queries |
| **High Load** | Slow response times | Rate limiting + auto-scaling |
| **Network Partition** | Service isolation | Health checks + retry logic |

---

## 2. Circuit Breakers

### 2.1 Circuit Breaker States

```
┌─────────────────────────────────────────────────┐
│              Circuit Breaker States              │
└─────────────────────────────────────────────────┘

    ┌─────────┐
    │ CLOSED  │ ◄───────────┐
    │ Normal  │             │
    └────┬────┘             │
         │                  │
         │ Failure          │ Success (test)
         │ Threshold        │
         │ Exceeded         │
         ▼                  │
    ┌─────────┐        ┌────┴─────┐
    │  OPEN   │───────►│HALF-OPEN │
    │Fail Fast│ Wait   │  Test    │
    └─────────┘ 30s    └──────────┘
                            │
                            │ Failure
                            │
                            ▼
                       ┌─────────┐
                       │  OPEN   │
                       └─────────┘
```

**States**:
- **CLOSED**: Normal operation, requests pass through
- **OPEN**: Circuit tripped, fail fast without calling service
- **HALF-OPEN**: Testing recovery, limited requests allowed

### 2.2 Circuit Breaker Configuration

**Default Settings**:
```python
CIRCUIT_BREAKER_CONFIG = {
    "failure_threshold": 5,        # Trip after 5 failures
    "success_threshold": 2,        # Close after 2 successes in HALF-OPEN
    "timeout": 30,                 # 30 seconds OPEN before HALF-OPEN
    "expected_exception": Exception,
    "fallback_function": None      # Optional fallback
}
```

### 2.3 Implementation (Python)

**File**: `backend/app/resilience/circuit_breaker.py`

```python
import time
from enum import Enum
from functools import wraps
from typing import Callable, Any, Optional
import logging

logger = logging.getLogger(__name__)

class CircuitState(Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"

class CircuitBreaker:
    """Circuit breaker pattern implementation"""
    
    def __init__(
        self,
        failure_threshold: int = 5,
        success_threshold: int = 2,
        timeout: int = 30,
        fallback: Optional[Callable] = None
    ):
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.timeout = timeout
        self.fallback = fallback
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""
        
        # Check if circuit should move to HALF-OPEN
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure_time >= self.timeout:
                logger.info(f"Circuit breaker moving to HALF-OPEN: {func.__name__}")
                self.state = CircuitState.HALF_OPEN
                self.success_count = 0
            else:
                logger.warning(f"Circuit breaker OPEN, using fallback: {func.__name__}")
                if self.fallback:
                    return self.fallback(*args, **kwargs)
                raise CircuitBreakerOpenError(f"Circuit breaker is OPEN for {func.__name__}")
        
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        
        except Exception as e:
            self._on_failure()
            logger.error(f"Circuit breaker caught error in {func.__name__}: {e}")
            
            if self.fallback:
                return self.fallback(*args, **kwargs)
            raise
    
    def _on_success(self):
        """Handle successful call"""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.success_threshold:
                logger.info("Circuit breaker closing (recovery successful)")
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                self.success_count = 0
        
        elif self.state == CircuitState.CLOSED:
            self.failure_count = 0
    
    def _on_failure(self):
        """Handle failed call"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.state == CircuitState.HALF_OPEN:
            logger.warning("Circuit breaker opening (test failed)")
            self.state = CircuitState.OPEN
            self.success_count = 0
        
        elif self.failure_count >= self.failure_threshold:
            logger.warning(f"Circuit breaker opening (threshold {self.failure_threshold} exceeded)")
            self.state = CircuitState.OPEN

class CircuitBreakerOpenError(Exception):
    """Raised when circuit breaker is OPEN"""
    pass

def circuit_breaker(
    failure_threshold: int = 5,
    success_threshold: int = 2,
    timeout: int = 30,
    fallback: Optional[Callable] = None
):
    """Decorator for circuit breaker pattern"""
    breaker = CircuitBreaker(failure_threshold, success_threshold, timeout, fallback)
    
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            return breaker.call(func, *args, **kwargs)
        return wrapper
    
    return decorator
```

### 2.4 Usage Examples

**External API Call**:
```python
from resilience.circuit_breaker import circuit_breaker
import requests

def fallback_price_data(symbol: str):
    """Fallback to cached price data"""
    return get_cached_price(symbol)

@circuit_breaker(
    failure_threshold=3,
    timeout=60,
    fallback=fallback_price_data
)
def fetch_price_from_api(symbol: str):
    """Fetch price from external API with circuit breaker"""
    response = requests.get(
        f"https://api.example.com/price/{symbol}",
        timeout=5
    )
    response.raise_for_status()
    return response.json()

# Usage
try:
    price_data = fetch_price_from_api("GOLD")
except CircuitBreakerOpenError:
    logger.warning("Circuit open, using cached data")
    price_data = fallback_price_data("GOLD")
```

**ML Model Prediction**:
```python
@circuit_breaker(
    failure_threshold=5,
    timeout=30,
    fallback=lambda *args, **kwargs: {"predicted_price": None, "confidence": 0.0}
)
def predict_with_ml_model(symbol: str, horizon: str):
    """ML prediction with circuit breaker"""
    model = load_model(symbol)
    features = prepare_features(symbol)
    
    prediction = model.predict(features)
    return {
        "predicted_price": prediction[0],
        "confidence": calculate_confidence(prediction)
    }
```

---

## 3. Retry Policies

### 3.1 Retry Strategy

**Exponential Backoff Formula**:
```
delay = base_delay × (2 ^ attempt) + random_jitter
```

**Example**:
- Attempt 1: 1s + jitter (0-0.5s)
- Attempt 2: 2s + jitter (0-1s)
- Attempt 3: 4s + jitter (0-2s)
- Max attempts: 3

### 3.2 Implementation (Python)

**File**: `backend/app/resilience/retry.py`

```python
import time
import random
from functools import wraps
from typing import Callable, Type, Tuple
import logging

logger = logging.getLogger(__name__)

def retry_with_backoff(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: bool = True,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,)
):
    """Decorator for retry with exponential backoff
    
    Args:
        max_attempts: Maximum number of retry attempts
        base_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        exponential_base: Base for exponential backoff (default: 2)
        jitter: Add random jitter to delay
        retryable_exceptions: Tuple of exceptions to retry on
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                
                except retryable_exceptions as e:
                    if attempt == max_attempts:
                        logger.error(f"Max retries ({max_attempts}) exceeded for {func.__name__}: {e}")
                        raise
                    
                    # Calculate delay with exponential backoff
                    delay = min(base_delay * (exponential_base ** (attempt - 1)), max_delay)
                    
                    # Add jitter
                    if jitter:
                        delay += random.uniform(0, delay * 0.5)
                    
                    logger.warning(
                        f"Retry attempt {attempt}/{max_attempts} for {func.__name__} "
                        f"after {delay:.2f}s: {e}"
                    )
                    time.sleep(delay)
            
        return wrapper
    return decorator
```

### 3.3 Usage Examples

**Database Query**:
```python
from resilience.retry import retry_with_backoff
from sqlalchemy.exc import OperationalError

@retry_with_backoff(
    max_attempts=3,
    base_delay=1.0,
    retryable_exceptions=(OperationalError,)
)
def query_database(query: str):
    """Execute database query with retry"""
    return db.session.execute(query).fetchall()
```

**External API Call**:
```python
import requests
from requests.exceptions import RequestException

@retry_with_backoff(
    max_attempts=3,
    base_delay=2.0,
    max_delay=10.0,
    retryable_exceptions=(RequestException,)
)
def fetch_external_data(url: str):
    """Fetch data from external API with retry"""
    response = requests.get(url, timeout=5)
    response.raise_for_status()
    return response.json()
```

---

## 4. Timeout Configurations

### 4.1 Timeout Hierarchy

| Level | Timeout | Purpose |
|-------|---------|---------|
| **Connection** | 5s | Establish TCP connection |
| **Read** | 10s | Read response from socket |
| **Request** | 15s | Total request time (connection + read) |
| **Operation** | 30s | Business logic operation |
| **Transaction** | 60s | Database transaction |

### 4.2 Implementation

**HTTP Client Timeouts**:
```python
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

def create_http_client():
    """Create HTTP client with timeouts and retry"""
    session = requests.Session()
    
    # Configure retry strategy
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["GET", "POST"]
    )
    
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    return session

# Usage
client = create_http_client()
response = client.get(
    "https://api.example.com/data",
    timeout=(5, 10)  # (connection_timeout, read_timeout)
)
```

**Database Timeouts**:
```python
from sqlalchemy import create_engine

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600,
    connect_args={
        "connect_timeout": 5,
        "command_timeout": 30,
        "options": "-c statement_timeout=60000"  # 60 seconds
    }
)
```

**FastAPI Timeouts**:
```python
from fastapi import FastAPI, Request
import asyncio

app = FastAPI()

@app.middleware("http")
async def timeout_middleware(request: Request, call_next):
    """Add request timeout middleware"""
    try:
        return await asyncio.wait_for(call_next(request), timeout=30.0)
    except asyncio.TimeoutError:
        return JSONResponse(
            status_code=504,
            content={"error": "Request timeout", "timeout": 30}
        )
```

---

## 5. Fallback Strategies

### 5.1 Fallback Hierarchy

```
Primary Source
    ↓ (fails)
Circuit Breaker
    ↓
Cached Data
    ↓ (cache miss)
Default Value
    ↓ (critical)
Graceful Degradation
```

### 5.2 ML Prediction Fallback

**File**: `modules/prediction_service.py`

```python
from resilience.circuit_breaker import circuit_breaker
from typing import Optional
import logging

logger = logging.getLogger(__name__)

class PredictionService:
    """Prediction service with fallback strategies"""
    
    def __init__(self, cache, model_loader):
        self.cache = cache
        self.model_loader = model_loader
    
    def get_prediction(self, symbol: str, horizon: str) -> dict:
        """Get prediction with fallback cascade"""
        
        # Strategy 1: ML model prediction
        try:
            return self._predict_with_ml(symbol, horizon)
        except Exception as e:
            logger.warning(f"ML prediction failed: {e}, trying cache")
        
        # Strategy 2: Cached prediction (last successful)
        cached = self._get_cached_prediction(symbol, horizon)
        if cached:
            logger.info("Using cached prediction")
            return {**cached, "source": "cache", "confidence": 0.7}
        
        # Strategy 3: Statistical extrapolation
        try:
            return self._statistical_prediction(symbol, horizon)
        except Exception as e:
            logger.warning(f"Statistical prediction failed: {e}")
        
        # Strategy 4: Last known price (degraded mode)
        return self._last_known_price_prediction(symbol)
    
    @circuit_breaker(failure_threshold=5, timeout=30)
    def _predict_with_ml(self, symbol: str, horizon: str) -> dict:
        """Primary: ML model prediction"""
        model = self.model_loader.load_model(symbol)
        features = self._prepare_features(symbol)
        
        prediction = model.predict(features)
        result = {
            "symbol": symbol,
            "predicted_price": float(prediction[0]),
            "confidence": 0.95,
            "source": "ml_model",
            "horizon": horizon
        }
        
        # Cache successful prediction
        self.cache.set(
            f"prediction:{symbol}:{horizon}",
            result,
            ttl=300  # 5 minutes
        )
        
        return result
    
    def _get_cached_prediction(self, symbol: str, horizon: str) -> Optional[dict]:
        """Fallback 1: Cached prediction"""
        return self.cache.get(f"prediction:{symbol}:{horizon}")
    
    def _statistical_prediction(self, symbol: str, horizon: str) -> dict:
        """Fallback 2: Simple statistical extrapolation"""
        historical_prices = get_historical_prices(symbol, days=30)
        
        # Simple moving average + trend
        avg_price = sum(historical_prices) / len(historical_prices)
        trend = (historical_prices[-1] - historical_prices[0]) / len(historical_prices)
        
        predicted_price = avg_price + (trend * 30)  # 30-day projection
        
        return {
            "symbol": symbol,
            "predicted_price": predicted_price,
            "confidence": 0.5,
            "source": "statistical",
            "horizon": horizon
        }
    
    def _last_known_price_prediction(self, symbol: str) -> dict:
        """Fallback 3: Last known price (degraded)"""
        last_price = get_latest_price(symbol)
        
        return {
            "symbol": symbol,
            "predicted_price": last_price,
            "confidence": 0.0,
            "source": "last_known",
            "message": "System degraded - using last known price"
        }
```

---

## 6. Health Checks

### 6.1 Health Check Types

| Type | Purpose | Interval | Timeout |
|------|---------|----------|---------|
| **Liveness** | Is service running? | 10s | 5s |
| **Readiness** | Can service handle requests? | 5s | 3s |
| **Startup** | Has service finished initialization? | 1s | 30s |

### 6.2 Implementation (FastAPI)

**File**: `backend/app/health.py`

```python
from fastapi import APIRouter, status, Response
from sqlalchemy import text
import redis
import time

router = APIRouter()

@router.get("/health/live")
async def liveness():
    """Liveness probe - is the service running?"""
    return {"status": "alive", "timestamp": time.time()}

@router.get("/health/ready")
async def readiness():
    """Readiness probe - can the service handle requests?"""
    checks = {}
    healthy = True
    
    # Check database
    try:
        db.session.execute(text("SELECT 1"))
        checks["database"] = "healthy"
    except Exception as e:
        checks["database"] = f"unhealthy: {str(e)}"
        healthy = False
    
    # Check Redis
    try:
        redis_client.ping()
        checks["redis"] = "healthy"
    except Exception as e:
        checks["redis"] = f"unhealthy: {str(e)}"
        healthy = False
    
    # Check ML models loaded
    try:
        if model_loader.models_loaded():
            checks["ml_models"] = "healthy"
        else:
            checks["ml_models"] = "loading"
            healthy = False
    except Exception as e:
        checks["ml_models"] = f"unhealthy: {str(e)}"
        healthy = False
    
    status_code = status.HTTP_200_OK if healthy else status.HTTP_503_SERVICE_UNAVAILABLE
    
    return Response(
        content=json.dumps({
            "status": "ready" if healthy else "not_ready",
            "checks": checks,
            "timestamp": time.time()
        }),
        status_code=status_code,
        media_type="application/json"
    )

@router.get("/health/startup")
async def startup():
    """Startup probe - has initialization completed?"""
    if app_initialized:
        return {"status": "started", "timestamp": time.time()}
    else:
        return Response(
            content=json.dumps({"status": "starting"}),
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            media_type="application/json"
        )
```

### 6.3 Kubernetes Health Check Configuration

```yaml
livenessProbe:
  httpGet:
    path: /health/live
    port: 8000
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /health/ready
    port: 8000
  initialDelaySeconds: 10
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 2

startupProbe:
  httpGet:
    path: /health/startup
    port: 8000
  initialDelaySeconds: 0
  periodSeconds: 1
  timeoutSeconds: 1
  failureThreshold: 30  # 30 seconds max startup time
```

---

## 7. Graceful Degradation

### 7.1 Degradation Levels

| Level | Features Available | User Impact |
|-------|-------------------|-------------|
| **Full** | All features | None |
| **Degraded** | Core features only | Minor - cached data |
| **Limited** | Read-only | Moderate - no updates |
| **Critical** | Health check only | Severe - maintenance mode |

### 7.2 Feature Flags

```python
from enum import Enum

class SystemMode(Enum):
    FULL = "full"
    DEGRADED = "degraded"
    LIMITED = "limited"
    CRITICAL = "critical"

class FeatureManager:
    """Manage feature availability based on system health"""
    
    def __init__(self):
        self.mode = SystemMode.FULL
    
    def set_mode(self, mode: SystemMode):
        """Set system degradation mode"""
        self.mode = mode
        logger.warning(f"System mode changed to: {mode.value}")
    
    def is_feature_available(self, feature: str) -> bool:
        """Check if feature is available in current mode"""
        
        feature_availability = {
            SystemMode.FULL: [
                "predictions", "alerts", "exports", "admin", "api_keys"
            ],
            SystemMode.DEGRADED: [
                "predictions", "alerts"  # Core features only
            ],
            SystemMode.LIMITED: [
                "predictions"  # Read-only predictions
            ],
            SystemMode.CRITICAL: []  # Nothing available
        }
        
        return feature in feature_availability.get(self.mode, [])

feature_manager = FeatureManager()

# Usage in endpoint
@app.post("/api/predict")
async def create_prediction(data: PredictionRequest):
    if not feature_manager.is_feature_available("predictions"):
        raise HTTPException(
            status_code=503,
            detail="Service degraded - predictions temporarily unavailable"
        )
    
    # Normal prediction logic...
```

---

## 8. Rate Limiting

### 8.1 Rate Limit Configuration

| Endpoint | Limit | Window | Burst |
|----------|-------|--------|-------|
| **/api/auth/login** | 5 req | 1 min | 10 |
| **/api/predict** | 100 req | 1 min | 150 |
| **/api/exports** | 10 req | 1 hour | 15 |
| **Global** | 1000 req | 1 min | 1500 |

See `Security.md` for full rate limiting implementation.

---

## 9. Bulkhead Pattern

### 9.1 Resource Isolation

```python
from concurrent.futures import ThreadPoolExecutor
from functools import wraps

class Bulkhead:
    """Bulkhead pattern - isolate resources"""
    
    def __init__(self, max_concurrent: int = 10):
        self.executor = ThreadPoolExecutor(max_workers=max_concurrent)
    
    def execute(self, func, *args, **kwargs):
        """Execute function in isolated thread pool"""
        future = self.executor.submit(func, *args, **kwargs)
        return future.result(timeout=30)

# Create separate bulkheads for different operations
ml_prediction_bulkhead = Bulkhead(max_concurrent=5)
api_call_bulkhead = Bulkhead(max_concurrent=10)
database_bulkhead = Bulkhead(max_concurrent=20)

# Usage
def predict_with_isolation(symbol: str):
    return ml_prediction_bulkhead.execute(predict_ml_model, symbol)
```

---

## 10. Monitoring & Alerts

### 10.1 Resilience Metrics

**Prometheus Metrics**:
```python
from prometheus_client import Counter, Histogram, Gauge

# Circuit breaker metrics
circuit_breaker_state = Gauge(
    'circuit_breaker_state',
    'Circuit breaker state (0=CLOSED, 1=OPEN, 2=HALF_OPEN)',
    ['service']
)

circuit_breaker_failures = Counter(
    'circuit_breaker_failures_total',
    'Total circuit breaker failures',
    ['service']
)

# Retry metrics
retry_attempts = Counter(
    'retry_attempts_total',
    'Total retry attempts',
    ['function', 'attempt']
)

# Timeout metrics
request_timeouts = Counter(
    'request_timeouts_total',
    'Total request timeouts',
    ['endpoint']
)

# Fallback metrics
fallback_used = Counter(
    'fallback_used_total',
    'Total fallback invocations',
    ['service', 'fallback_type']
)
```

### 10.2 Alert Rules

```yaml
# alerts.yaml
groups:
  - name: resilience
    rules:
      - alert: CircuitBreakerOpen
        expr: circuit_breaker_state{service="ml_prediction"} == 1
        for: 1m
        annotations:
          summary: "Circuit breaker open for {{ $labels.service }}"
      
      - alert: HighRetryRate
        expr: rate(retry_attempts_total[5m]) > 10
        for: 5m
        annotations:
          summary: "High retry rate detected"
      
      - alert: FrequentTimeouts
        expr: rate(request_timeouts_total[5m]) > 5
        for: 5m
        annotations:
          summary: "Frequent timeouts on {{ $labels.endpoint }}"
```

---

**Last Updated**: 2025-11-17  
**Next Review**: 2026-02-17  
**Version**: 3.0.0  
**Owner**: DevOps Team
