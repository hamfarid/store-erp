# 🌐 CDN Setup Guide

**Version**: 1.0  
**Created**: 2026-01-16  
**Project**: Gold Price Predictor - Phase 10

---

## 📋 Overview

This guide covers setting up a Content Delivery Network (CDN) for the Gold Price Predictor to:

- 🚀 Reduce latency for global users
- 📦 Cache static assets at edge locations
- 🔒 Add DDoS protection
- 📊 Improve Core Web Vitals

---

## 🎯 CDN Strategy

### Assets to Cache

| Asset Type | Cache Duration | Location |
|------------|----------------|----------|
| Static JS/CSS | 1 year | Edge |
| Images | 1 year | Edge |
| Fonts | 1 year | Edge |
| HTML | 5 minutes | Edge |
| API responses | No cache | Origin |
| WebSocket | No cache | Origin |

### Cache Headers Strategy

```nginx
# Static assets (immutable - hashed filenames)
location ~* \.(js|css|woff2|png|jpg|svg)$ {
    add_header Cache-Control "public, max-age=31536000, immutable";
}

# HTML (short cache for updates)
location ~* \.html$ {
    add_header Cache-Control "public, max-age=300";
}

# API (no cache)
location /api/ {
    add_header Cache-Control "no-store";
}
```

---

## 🛠️ Option 1: Cloudflare (Recommended)

### Setup Steps

1. **Add Site to Cloudflare**
   ```bash
   # Update DNS nameservers to Cloudflare
   # Wait for propagation (up to 24 hours)
   ```

2. **Configure Page Rules**
   ```
   Rule 1: goldpredictor.app/api/*
   - Cache Level: Bypass
   - SSL: Full (Strict)
   
   Rule 2: goldpredictor.app/static/*
   - Cache Level: Cache Everything
   - Edge Cache TTL: 1 month
   - Browser Cache TTL: 1 year
   
   Rule 3: goldpredictor.app/*
   - Cache Level: Standard
   - Edge Cache TTL: 4 hours
   ```

3. **Enable Features**
   - ✅ Brotli compression
   - ✅ Auto Minify (JS, CSS, HTML)
   - ✅ HTTP/3 (QUIC)
   - ✅ Early Hints
   - ✅ Rocket Loader
   - ✅ Polish (image optimization)

### Cloudflare Workers (Edge Computing)

```javascript
// workers/cache-api.js
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  const url = new URL(request.url)
  
  // Skip caching for API and WebSocket
  if (url.pathname.startsWith('/api/') || 
      url.pathname.startsWith('/ws/')) {
    return fetch(request)
  }
  
  // Check cache
  const cache = caches.default
  let response = await cache.match(request)
  
  if (!response) {
    response = await fetch(request)
    
    // Cache static assets
    if (response.ok && isStaticAsset(url.pathname)) {
      response = new Response(response.body, response)
      response.headers.set('Cache-Control', 'public, max-age=31536000')
      event.waitUntil(cache.put(request, response.clone()))
    }
  }
  
  return response
}

function isStaticAsset(path) {
  return /\.(js|css|png|jpg|svg|woff2)$/.test(path)
}
```

---

## 🛠️ Option 2: AWS CloudFront

### Setup Steps

1. **Create Distribution**
   ```bash
   aws cloudfront create-distribution \
     --origin-domain-name goldpredictor.app \
     --default-root-object index.html
   ```

2. **Configure Behaviors**

   | Path Pattern | Origin | Cache Policy |
   |--------------|--------|--------------|
   | `/api/*` | API origin | CachingDisabled |
   | `/static/*` | S3 bucket | CachingOptimized |
   | `/ws/*` | WebSocket origin | CachingDisabled |
   | `Default (*)` | API origin | CachingOptimizedForUncompressedObjects |

3. **Enable Features**
   - ✅ Compress objects automatically
   - ✅ HTTP/2 & HTTP/3
   - ✅ Origin Shield (for multi-region)
   - ✅ Field-level encryption (for sensitive data)

### CloudFront Function (Edge)

```javascript
// functions/add-security-headers.js
function handler(event) {
  var response = event.response;
  var headers = response.headers;
  
  // Security headers
  headers['strict-transport-security'] = { 
    value: 'max-age=31536000; includeSubDomains; preload' 
  };
  headers['x-content-type-options'] = { value: 'nosniff' };
  headers['x-frame-options'] = { value: 'DENY' };
  headers['x-xss-protection'] = { value: '1; mode=block' };
  
  return response;
}
```

---

## 🛠️ Option 3: Vercel Edge Network

### Setup (if using Vercel deployment)

1. **Configure `vercel.json`**

```json
{
  "headers": [
    {
      "source": "/static/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    },
    {
      "source": "/api/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "no-store"
        }
      ]
    }
  ],
  "rewrites": [
    {
      "source": "/api/:path*",
      "destination": "https://api.goldpredictor.app/:path*"
    }
  ]
}
```

2. **Edge Config for Feature Flags**

```typescript
// lib/edge-config.ts
import { get } from '@vercel/edge-config';

export async function getFeatureFlags() {
  const flags = await get('featureFlags');
  return flags as {
    enableNewDashboard: boolean;
    enableMLPredictions: boolean;
    maintenanceMode: boolean;
  };
}
```

---

## 📊 Performance Metrics

### Before CDN

| Metric | Value | Target |
|--------|-------|--------|
| TTFB | ~800ms | <200ms |
| FCP | ~2.5s | <1.8s |
| LCP | ~4.0s | <2.5s |
| CLS | 0.15 | <0.1 |

### After CDN (Expected)

| Metric | Value | Improvement |
|--------|-------|-------------|
| TTFB | ~150ms | 81% ⬇️ |
| FCP | ~1.2s | 52% ⬇️ |
| LCP | ~2.0s | 50% ⬇️ |
| CLS | 0.05 | 67% ⬇️ |

---

## 🔧 Implementation Checklist

### Phase 1: Basic CDN Setup
- [ ] Choose CDN provider (Cloudflare recommended)
- [ ] Configure DNS
- [ ] Add SSL/TLS certificate
- [ ] Create cache rules for static assets
- [ ] Test basic caching

### Phase 2: Optimization
- [ ] Enable Brotli/Gzip compression
- [ ] Configure image optimization
- [ ] Set up HTTP/3
- [ ] Enable prefetching hints
- [ ] Configure stale-while-revalidate

### Phase 3: Advanced Features
- [ ] Deploy edge functions
- [ ] Set up origin shield
- [ ] Configure failover origins
- [ ] Enable real-time analytics
- [ ] Set up alerting for cache hit ratio

### Phase 4: Monitoring
- [ ] Set up CDN analytics dashboard
- [ ] Monitor cache hit ratio (target: >90%)
- [ ] Track bandwidth savings
- [ ] Monitor error rates
- [ ] Set up origin health checks

---

## 🔒 Security Configuration

### WAF Rules (Cloudflare)

```yaml
# Block known bad actors
- expression: (cf.client.bot) or (cf.threat_score > 30)
  action: challenge

# Rate limiting
- expression: (http.request.uri.path contains "/api/")
  action: rate_limit
  characteristics:
    - ip.src
  period: 60
  requests_per_period: 100

# Block SQL injection attempts
- expression: (http.request.uri.query contains "SELECT" or 
               http.request.uri.query contains "UNION")
  action: block
```

### DDoS Protection

- Enable automatic DDoS mitigation
- Set up traffic anomaly alerts
- Configure under-attack mode threshold

---

## 📈 Cost Estimation

### Cloudflare

| Plan | Price | Features |
|------|-------|----------|
| Free | $0/mo | Basic CDN, SSL |
| Pro | $20/mo | WAF, Image optimization |
| Business | $200/mo | Advanced DDoS, SLA |

### AWS CloudFront

| Usage | Est. Cost |
|-------|-----------|
| 100 GB/mo data transfer | ~$8.50 |
| 10M requests/mo | ~$7.50 |
| Origin Shield | ~$5.00 |
| **Total** | **~$21/mo** |

---

## 🚀 Quick Start Commands

### Cloudflare CLI (Wrangler)

```bash
# Install
npm install -g wrangler

# Login
wrangler login

# Deploy worker
wrangler deploy

# Purge cache
curl -X POST "https://api.cloudflare.com/client/v4/zones/{zone_id}/purge_cache" \
  -H "Authorization: Bearer {api_token}" \
  -H "Content-Type: application/json" \
  --data '{"purge_everything":true}'
```

### AWS CLI

```bash
# Create invalidation
aws cloudfront create-invalidation \
  --distribution-id E1234567890 \
  --paths "/*"

# Check distribution status
aws cloudfront get-distribution --id E1234567890
```

---

## 📝 Next Steps

1. **Week 3**: Choose CDN provider and configure DNS
2. **Week 4**: Implement cache rules and test
3. **Week 5**: Deploy edge functions
4. **Week 6**: Monitor and optimize

---

**Last Updated**: 2026-01-16  
**Maintained by**: DevOps Team
