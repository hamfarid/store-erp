# API Implementation, Testing & Integration Plan

**FILE**: docs/API_IMPLEMENTATION_PLAN.md | **PURPOSE**: Comprehensive plan for API implementation and testing | **OWNER**: Backend Team | **RELATED**: Routes_BE.md, Routes_tRPC_Extended.md | **LAST-AUDITED**: 2025-11-21

**Date**: 2025-11-21  
**Status**: 🚀 **IN PROGRESS**  
**Goal**: Implement, test, and integrate all documented API routes

---

## 📋 Overview

This plan covers the implementation of **157+ API routes** across 3 layers:

- Frontend (14 routes) - Already implemented ✅
- FastAPI Backend (37 endpoints) - 80% implemented
- tRPC (106+ procedures) - 70% implemented

**Estimated Time**: 3-4 days  
**Priority**: High (P0)

---

## Phase 1: API Testing Infrastructure Setup ⏳

### 1.1 FastAPI Testing Setup

**Status**: Partially done (29 test files exist)  
**Goal**: Expand to cover all 37 endpoints

#### Existing Tests

- ✅ auth tests (JWT, 2FA, CSRF)
- ✅ security tests (input sanitizer, rate limiter)
- ✅ backup tests
- ⏳ CRUD operations (users, assets, predictions, alerts) - Need expansion

#### New Tests Needed

- [ ] Extended routers testing
- [ ] Integration tests for ML predictions
- [ ] Performance tests for heavy operations
- [ ] Security tests for all admin endpoints

**Tools**: pytest, pytest-asyncio, httpx, faker

---

### 1.2 tRPC Testing Setup

**Status**: Minimal (2 test files)  
**Goal**: Create comprehensive test suite

#### Existing Tests

- ✅ email-service.test.ts
- ✅ ai-training-data.test.ts

#### New Tests Needed

- [ ] Auth procedures tests
- [ ] All 13 extended routers tests
- [ ] Type safety tests
- [ ] Error handling tests

**Tools**: Vitest, MSW (Mock Service Worker), supertest

---

## Phase 2: Missing Router Implementation 🔧

### 2.1 Backend Implementation Gaps

#### Database Functions (Priority: High)

- [ ] **Reports Module** (`db-reports.ts` or `server/db-sqlite.ts`)
  - [ ] `generatePortfolioReport(userId, options)`
  - [ ] `generateAccuracyReport(userId, options)`
  - [ ] `generateAlertsReport(userId, options)`
  - [ ] `generatePriceHistoryReport(options)`
  - [ ] `convertToCSV(data)`
  - [ ] `getReportHistory(userId, limit, offset)`
  - [ ] `saveReport(userId, reportData)`
  - [ ] `deleteReport(reportId, userId)`

#### Admin Functions (Priority: Medium)

- [ ] **Admin Module** (`server/db-sqlite.ts`)
  - [ ] `getAllUsersAdmin(options)`
  - [ ] `getUserByIdAdmin(userId)`
  - [ ] `updateUserAdmin(userId, updates)`
  - [ ] `deleteUser(userId)`
  - [ ] `getUserStats()`
  - [ ] `getAllAssetsAdmin()`
  - [ ] `createAssetAdmin(data)`
  - [ ] `updateAssetAdmin(id, updates)`
  - [ ] `deleteAssetAdmin(id)`
  - [ ] `getSystemLogs(options)`
  - [ ] `clearSystemLogs(olderThan)`
  - [ ] `getDatabaseStats()`
  - [ ] `createDatabaseBackup()`
  - [ ] `optimizeDatabase()`
  - [ ] `getSystemConfig()`
  - [ ] `updateSystemConfig(key, value)`

#### Comprehensive System (Priority: Medium)

- [ ] **Comprehensive Module** (`server/comprehensive-system.ts`)
  - [ ] `sendNotification(options)`
  - [ ] `getUserNotifications(userId, limit)`
  - [ ] `markNotificationAsRead(notificationId, userId)`
  - [ ] `generateReport(options)`
  - [ ] `calculateKPIs(userId, period)`
  - [ ] `getKPIHistory(userId, periods)`
  - [ ] `logActivity(options)`
  - [ ] `trackChange(options)`
  - [ ] `getUserActivity(userId, limit)`
  - [ ] `generateAIRecommendation(userId, assetId)`
  - [ ] `analyzeSentiment(text, assetId)`
  - [ ] `calculateRiskProfile(userId, assetId)`

#### AI Tasks Scheduler (Priority: High)

- [ ] **AI Scheduler** (`server/ai-scheduler.ts`)
  - [ ] `initialize()` - Load tasks from DB
  - [ ] `scheduleTask(task)` - Add cron job
  - [ ] `unscheduleTask(taskId)` - Remove cron job
  - [ ] `executeTask(task)` - Run task logic
  - [ ] `getStatus()` - Get scheduler status

#### Database Operations (Priority: High)

- [ ] **AI Tasks DB** (`server/db-ai-tasks.ts`)
  - [ ] `createScheduledTask(data)`
  - [ ] `getUserScheduledTasks(userId)`
  - [ ] `getScheduledTask(taskId, userId)`
  - [ ] `updateScheduledTask(taskId, userId, data)`
  - [ ] `deleteScheduledTask(taskId, userId)`
  - [ ] `getTaskResults(taskId, limit)`

---

### 2.2 Frontend-Backend Connection Validation

#### Verify Existing Implementations

- [ ] Check `server/routers/ai-tasks-router.ts` - Uses undefined `dbAITasks`
- [ ] Check `server/routers/reports-router.ts` - Uses undefined DB functions
- [ ] Check `server/routers/admin-router.ts` - Uses undefined admin functions
- [ ] Check `server/routers/comprehensive-router.ts` - Uses undefined `ComprehensiveSystem`

---

## Phase 3: Database Schema Updates 📊

### 3.1 New Tables Needed

#### ai_scheduled_tasks

```sql
CREATE TABLE ai_scheduled_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  assistant_id INTEGER DEFAULT 1,
  task_name TEXT NOT NULL,
  description TEXT,
  task_type TEXT NOT NULL,
  schedule_type TEXT NOT NULL,
  cron_expression TEXT NOT NULL,
  task_config TEXT,
  is_active BOOLEAN DEFAULT 1,
  last_run DATETIME,
  next_run DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### ai_task_results

```sql
CREATE TABLE ai_task_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL,
  executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  status TEXT DEFAULT 'success',
  result TEXT,
  error TEXT,
  FOREIGN KEY (task_id) REFERENCES ai_scheduled_tasks(id)
);
```

#### saved_reports

```sql
CREATE TABLE saved_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  report_type TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  data TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### system_config

```sql
CREATE TABLE system_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  description TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## Phase 4: Integration Testing 🧪

### 4.1 FastAPI Test Suite

**File**: `backend/app/tests/test_api_complete.py`

```python
# Test all 37 FastAPI endpoints
# - Authentication flow (login, register, 2FA, refresh, logout)
# - Users CRUD (create, read, update, delete, list)
# - Assets CRUD (create, read, update, delete, list, historical prices)
# - Predictions CRUD (create, read, list, delete, advanced)
# - Alerts CRUD (create, read, list, delete, update)
# - System endpoints (health, export)
```

### 4.2 tRPC Test Suite

**File**: `tests/server/routers/complete-test-suite.test.ts`

```typescript
// Test all 106+ tRPC procedures
// - Auth procedures (register, login, logout, me)
// - All 13 extended routers
// - Type safety validation
// - Error handling
// - Permission checks
```

### 4.3 E2E Tests

**File**: `tests/e2e/critical-flows.spec.ts`

```typescript
// Critical user flows
// 1. User registration + login
// 2. Create prediction + view history
// 3. Create alert + trigger notification
// 4. Admin: user management
// 5. Portfolio creation + transactions
// 6. Report generation + export
```

---

## Phase 5: Frontend Integration 🎨

### 5.1 Replace Axios with tRPC

#### Pages to Update

- [ ] `client/src/pages/Home.tsx` - Use `trpc.dashboard.getLivePrices.useQuery()`
- [ ] `client/src/pages/Predict.tsx` - Use `trpc.predictionsAdvanced.generate.useMutation()`
- [ ] `client/src/pages/History.tsx` - Use `trpc.predictions.list.useQuery()`
- [ ] `client/src/pages/Alerts.tsx` - Use `trpc.alerts.list.useQuery()`
- [ ] `client/src/pages/Settings.tsx` - Use `trpc.settings.get.useQuery()`
- [ ] `client/src/pages/Logs.tsx` - Use `trpc.logs.getErrors.useQuery()`
- [ ] `client/src/pages/admin/*.tsx` - Use admin router procedures

### 5.2 Error Handling

#### Create Error Boundary

**File**: `client/src/components/ErrorBoundary.tsx`

```tsx
// Catch tRPC errors
// Display user-friendly messages
// Log errors to monitoring service
```

#### Create Loading States

**File**: `client/src/components/ui/LoadingSkeleton.tsx`

```tsx
// Skeleton loaders for:
// - Dashboard cards
// - Tables
// - Charts
// - Forms
```

---

## Phase 6: Performance & Optimization ⚡

### 6.1 Backend Optimizations

- [ ] Add Redis caching for expensive queries
- [ ] Implement database query optimization (indexes)
- [ ] Add connection pooling
- [ ] Implement background jobs for ML predictions

### 6.2 Frontend Optimizations

- [ ] Implement React Query caching strategies
- [ ] Add pagination for large lists
- [ ] Lazy load heavy components
- [ ] Optimize bundle size

---

## Phase 7: Documentation Updates 📚

### 7.1 API Documentation

- [ ] Update OpenAPI/Swagger docs for FastAPI
- [ ] Generate tRPC client docs
- [ ] Add usage examples for all endpoints
- [ ] Document error codes

### 7.2 Developer Guides

- [ ] Create API integration guide
- [ ] Add testing guide
- [ ] Create troubleshooting guide
- [ ] Add deployment guide

---

## Phase 8: Security & Compliance 🔒

### 8.1 Security Testing

- [ ] Run OWASP ZAP scan
- [ ] Test SQL injection protection
- [ ] Test XSS protection
- [ ] Test CSRF protection
- [ ] Test rate limiting
- [ ] Test JWT expiration

### 8.2 Compliance Checks

- [ ] GDPR compliance (data export, deletion)
- [ ] Audit logging complete
- [ ] Data encryption at rest
- [ ] Secure secrets management

---

## Progress Tracking

### Overall Progress

| Phase                         | Status         | Progress | Priority |
| ----------------------------- | -------------- | -------- | -------- |
| Phase 1: Testing Setup        | 🔄 In Progress | 20%      | P0       |
| Phase 2: Missing Routers      | ⏳ Not Started | 0%       | P0       |
| Phase 3: Database Schema      | ⏳ Not Started | 0%       | P0       |
| Phase 4: Integration Tests    | ⏳ Not Started | 0%       | P1       |
| Phase 5: Frontend Integration | ⏳ Not Started | 0%       | P1       |
| Phase 6: Optimization         | ⏳ Not Started | 0%       | P2       |
| Phase 7: Documentation        | ⏳ Not Started | 0%       | P2       |
| Phase 8: Security             | ⏳ Not Started | 0%       | P1       |

**Overall**: 5% Complete

---

## Quick Start Guide

### Step 1: Run Existing Tests

```bash
# Backend tests
cd backend
pytest -v

# Frontend tests
npm run test

# E2E tests
npm run test:e2e
```

### Step 2: Implement Missing Modules

```bash
# Create comprehensive-system module
touch server/comprehensive-system.ts

# Create db-ai-tasks module
touch server/db-ai-tasks.ts

# Create ai-scheduler module
touch server/ai-scheduler.ts
```

### Step 3: Update Database Schema

```bash
# Add new tables to Drizzle schema
# Run migration
npm run db:push
```

### Step 4: Write Tests

```bash
# Add new test files
touch backend/app/tests/test_routers_complete.py
touch tests/server/routers/*.test.ts
```

---

## Success Criteria

✅ All 157+ routes have working implementations  
✅ Test coverage >85% for backend  
✅ Test coverage >80% for frontend  
✅ All critical E2E flows pass  
✅ Performance benchmarks met (API <200ms, Frontend <3s)  
✅ Security tests pass (no critical/high vulnerabilities)  
✅ Documentation complete and accurate

---

## Next Steps (Priority Order)

1. **[P0] Create missing database functions** (Reports, Admin, AI Tasks)
2. **[P0] Implement comprehensive-system module**
3. **[P0] Add database migrations for new tables**
4. **[P0] Write integration tests for all routers**
5. **[P1] Update frontend to use tRPC exclusively**
6. **[P1] Add E2E tests for critical flows**
7. **[P2] Optimize performance**
8. **[P2] Update documentation**

---

**Status**: 🚀 Ready to start implementation  
**Estimated Completion**: 2025-11-25  
**Owner**: Backend Team  
**Last Updated**: 2025-11-21

**End of Plan**
