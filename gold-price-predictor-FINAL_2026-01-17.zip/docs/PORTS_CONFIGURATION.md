# 🔌 تكوين المنافذ (Ports Configuration)

**FILE**: docs/PORTS_CONFIGURATION.md | **PURPOSE**: Ports configuration documentation | **OWNER**: DevOps Team | **LAST-AUDITED**: 2025-11-25

---

## 📋 **ملخص المنافذ المستخدمة**

| الخدمة | المنفذ | الوصف | الحالة |
|--------|--------|-------|--------|
| **Frontend (React)** | **2505** | واجهة المستخدم الرئيسية | ✅ نشط |
| **Backend (Node.js)** | **2005** | API الخلفية (tRPC) | ✅ نشط |
| **PostgreSQL** | **5432** | قاعدة البيانات الرئيسية | ✅ نشط |
| **Redis** | **6379** | التخزين المؤقت والجلسات | ✅ نشط |
| **ML Service (FastAPI)** | **8000** | خدمة التعلم الآلي | ✅ نشط |
| **Grafana** | **3001** | لوحات المراقبة | ✅ نشط |
| **Prometheus** | **9090** | جمع المقاييس | ✅ نشط |
| **Elasticsearch** | **9200** | محرك البحث | 🟡 اختياري |
| **Elasticsearch (Transport)** | **9300** | اتصال داخلي | 🟡 اختياري |
| **Kibana** | **5601** | واجهة Elasticsearch | 🟡 اختياري |
| **pgAdmin** | **5050** | إدارة PostgreSQL | 🟡 اختياري |

---

## 🎯 **المنافذ الأساسية (يجب أن تكون متاحة)**

### **1. Frontend - Port 2505**
```
http://localhost:2505
```
- **الوصف**: واجهة المستخدم الرئيسية (React + Vite)
- **الاستخدام**: الوصول إلى التطبيق من المتصفح
- **التكوين**: `.env` → `PORT=2505`

### **2. Backend - Port 2005**
```
http://localhost:2005
```
- **الوصف**: API الخلفية (Node.js + tRPC)
- **الاستخدام**: معالجة طلبات API من Frontend
- **التكوين**: `.env` → `BACKEND_PORT=2005`

### **3. PostgreSQL - Port 5432**
```
postgresql://localhost:5432
```
- **الوصف**: قاعدة البيانات الرئيسية
- **الاستخدام**: تخزين البيانات (users, assets, price_history)
- **التكوين**: `docker-compose.yml` → `ports: "5432:5432"`

### **4. Redis - Port 6379**
```
redis://localhost:6379
```
- **الوصف**: التخزين المؤقت والجلسات
- **الاستخدام**: Cache, Sessions, Rate Limiting
- **التكوين**: `docker-compose.yml` → `ports: "6379:6379"`

### **5. ML Service - Port 8000**
```
http://localhost:8000
```
- **الوصف**: خدمة التعلم الآلي (FastAPI + TensorFlow)
- **الاستخدام**: التنبؤات بالأسعار
- **التكوين**: `docker-compose.yml` → `ports: "8000:8000"`
- **API Docs**: `http://localhost:8000/docs`

---

## 📊 **المنافذ الإضافية (للمراقبة)**

### **6. Grafana - Port 3001**
```
http://localhost:3001
```
- **الوصف**: لوحات المراقبة والتصور
- **الاستخدام**: عرض المقاييس والرسوم البيانية
- **التكوين**: `docker-compose.yml` → `ports: "3001:3000"`
- **الدخول**: `admin / admin` (افتراضي)

### **7. Prometheus - Port 9090**
```
http://localhost:9090
```
- **الوصف**: جمع وتخزين المقاييس
- **الاستخدام**: مراقبة الأداء والصحة
- **التكوين**: `docker-compose.yml` → `ports: "9090:9090"`

---

## 🔍 **المنافذ الاختيارية (للبحث)**

### **8. Elasticsearch - Port 9200**
```
http://localhost:9200
```
- **الوصف**: محرك البحث والتحليل
- **الاستخدام**: البحث السريع في البيانات
- **التكوين**: `docker-compose.yml` → `ports: "9200:9200"`

### **9. Kibana - Port 5601**
```
http://localhost:5601
```
- **الوصف**: واجهة Elasticsearch
- **الاستخدام**: تصور بيانات البحث
- **التكوين**: `docker-compose.yml` → `ports: "5601:5601"`

---

## 🛠️ **كيفية تغيير المنافذ**

### **تغيير منفذ Frontend (2505)**
```bash
# في ملف .env
PORT=2505  # غيّر إلى المنفذ المطلوب

# في package.json (إذا لزم الأمر)
"dev": "vite --port 2505"
```

### **تغيير منفذ Backend (2005)**
```bash
# في ملف .env
BACKEND_PORT=2005  # غيّر إلى المنفذ المطلوب

# في server/_core/index.ts
const PORT = process.env.BACKEND_PORT || 2005;
```

### **تغيير منفذ ML Service (8000)**
```bash
# في docker-compose.yml
ml-service:
  ports:
    - "8000:8000"  # غيّر الرقم الأول فقط
```

### **تغيير منفذ Grafana (3001)**
```bash
# في docker-compose.yml
grafana:
  ports:
    - "3001:3000"  # غيّر الرقم الأول فقط
```

---

## ⚠️ **تعارضات المنافذ الشائعة**

### **المشكلة: Port 2505 already in use**
```bash
# الحل 1: إيقاف العملية المستخدمة للمنفذ
# Windows PowerShell:
Get-Process -Id (Get-NetTCPConnection -LocalPort 2505).OwningProcess | Stop-Process

# الحل 2: تغيير المنفذ في .env
PORT=2506
```

### **المشكلة: Port 5432 already in use (PostgreSQL)**
```bash
# الحل 1: إيقاف PostgreSQL المحلي
# Windows:
Stop-Service postgresql-x64-14

# الحل 2: تغيير المنفذ في docker-compose.yml
postgres:
  ports:
    - "5433:5432"  # استخدم 5433 بدلاً من 5432
```

### **المشكلة: Port 8000 already in use (ML Service)**
```bash
# الحل: تغيير المنفذ في docker-compose.yml
ml-service:
  ports:
    - "8001:8000"  # استخدم 8001 بدلاً من 8000
```

---

## ✅ **التحقق من المنافذ**

### **Windows PowerShell**
```powershell
# التحقق من منفذ واحد
Test-NetConnection -ComputerName localhost -Port 2505

# عرض جميع المنافذ المستخدمة
Get-NetTCPConnection | Where-Object {$_.State -eq "Listen"} | Select-Object LocalPort, OwningProcess | Sort-Object LocalPort
```

### **Linux/Mac**
```bash
# التحقق من منفذ واحد
nc -zv localhost 2505

# عرض جميع المنافذ المستخدمة
netstat -tuln | grep LISTEN
```

---

## 🔥 **Firewall Configuration**

### **Windows Firewall**
```powershell
# السماح بالمنافذ الأساسية
New-NetFirewallRule -DisplayName "Gold Predictor Frontend" -Direction Inbound -LocalPort 2505 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "Gold Predictor Backend" -Direction Inbound -LocalPort 2005 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "Gold Predictor ML" -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow
```

---

## 📝 **ملاحظات مهمة**

1. **المنافذ الأساسية (2505, 2005, 5432, 6379, 8000)** يجب أن تكون متاحة دائماً
2. **Grafana** تم تغييره من 2505 إلى **3001** لتجنب التعارض مع Frontend
3. **Elasticsearch و Kibana** اختياريان ويمكن تعطيلهما إذا لم تكن بحاجة للبحث
4. **جميع المنافذ** يمكن تغييرها في `docker-compose.yml` و `.env`

---

## 🚀 **اختبار المنافذ**

```bash
# Frontend
curl http://localhost:2505

# Backend
curl http://localhost:2005/health

# ML Service
curl http://localhost:8000/health

# Grafana
curl http://localhost:3001

# Prometheus
curl http://localhost:9090/-/healthy

# PostgreSQL
psql -h localhost -p 5432 -U postgres -d gold_predictor

# Redis
redis-cli -h localhost -p 6379 ping
```

---

**آخر تحديث**: 2025-11-25  
**الحالة**: ✅ تم تصحيح تعارض المنافذ  
**التغييرات**: Grafana من 2505 إلى 3001

