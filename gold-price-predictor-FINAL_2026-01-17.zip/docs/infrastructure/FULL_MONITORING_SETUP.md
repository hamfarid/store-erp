# Full Monitoring Setup Guide
# دليل إعداد المراقبة الشاملة

**Component:** Monitoring & Observability  
**Estimated Time:** 60 minutes  
**Cost:** Free (Prometheus + Grafana)  
**Difficulty:** Intermediate

---

## Overview

Setup comprehensive monitoring with Prometheus + Grafana + CloudWatch.

**Metrics:**
- ✅ Application metrics
- ✅ Infrastructure metrics
- ✅ Database metrics
- ✅ Cache metrics
- ✅ Business metrics

---

## Step 1: Prometheus Setup

### 1.1 Install Prometheus

```yaml
# docker-compose.yml

services:
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=30d'
```

### 1.2 Configure Prometheus

```yaml
# monitoring/prometheus.yml

global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'backend'
    static_configs:
      - targets: ['backend:8000']
  
  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']
  
  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']
```

---

## Step 2: Grafana Setup

### 2.1 Install Grafana

```yaml
# docker-compose.yml

services:
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources
```

### 2.2 Configure Datasource

```yaml
# monitoring/grafana/datasources/prometheus.yml

apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
```

---

## Step 3: Application Metrics

### 3.1 Add Prometheus Client

```python
# backend/app/core/metrics.py

from prometheus_client import Counter, Histogram, Gauge, generate_latest

# Request metrics
request_count = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

request_duration = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration',
    ['method', 'endpoint']
)

# Business metrics
predictions_total = Counter(
    'predictions_total',
    'Total predictions made',
    ['model']
)

prediction_accuracy = Gauge(
    'prediction_accuracy',
    'Model prediction accuracy',
    ['model']
)

# Database metrics
db_query_duration = Histogram(
    'db_query_duration_seconds',
    'Database query duration',
    ['query_type']
)

# Cache metrics
cache_hits = Counter('cache_hits_total', 'Cache hits')
cache_misses = Counter('cache_misses_total', 'Cache misses')
```

### 3.2 Add Metrics Endpoint

```python
# backend/app/api/metrics.py

from fastapi import APIRouter, Response
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

router = APIRouter()

@router.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )
```

---

## Step 4: Dashboards

### 4.1 Import Dashboards

1. Go to Grafana (http://localhost:3000)
2. Login (admin/admin)
3. Import dashboards:
   - Node Exporter (ID: 1860)
   - PostgreSQL (ID: 9628)
   - Redis (ID: 11835)

### 4.2 Create Custom Dashboard

Create dashboard with panels for:
- Request rate
- Response time (p50, p95, p99)
- Error rate
- Prediction accuracy
- Cache hit rate
- Database connections
- Queue size

---

## Step 5: Alerts

### 5.1 Configure Alerting

```yaml
# monitoring/prometheus/alerts.yml

groups:
  - name: application
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
      
      - alert: HighResponseTime
        expr: histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m])) > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High response time detected"
```

---

**Last Updated:** 2025-10-29  
**Component:** Monitoring  
**Status:** Ready for implementation
