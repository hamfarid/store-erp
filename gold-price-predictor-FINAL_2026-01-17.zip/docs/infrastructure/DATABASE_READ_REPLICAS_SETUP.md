# Database Read Replicas Setup Guide
# دليل إعداد نسخ قاعدة البيانات للقراءة

**Component:** Database Scaling  
**Estimated Time:** 60 minutes  
**Cost:** ~$60/month (2 replicas)  
**Difficulty:** Intermediate

---

## Overview

Setup PostgreSQL read replicas to scale read operations and improve performance.

**Benefits:**
- ✅ Improved read performance
- ✅ Reduced load on master
- ✅ High availability
- ✅ Disaster recovery

---

## Architecture

```
Master (Write)
    ↓ (Replication)
┌──────────┬──────────┐
│ Replica1 │ Replica2 │
│ (Read)   │ (Read)   │
└──────────┴──────────┘
```

---

## Step 1: Create Read Replicas (AWS RDS)

### 1.1 Via AWS Console

1. Go to RDS Console
2. Select master database
3. Actions → Create read replica
4. Configure:
   - DB instance identifier: `gold-predictor-replica-1`
   - Instance class: `db.t3.medium`
   - Multi-AZ: No
   - Public access: No
5. Create replica

### 1.2 Via AWS CLI

```bash
# Create first replica
aws rds create-db-instance-read-replica \
  --db-instance-identifier gold-predictor-replica-1 \
  --source-db-instance-identifier gold-predictor-master \
  --db-instance-class db.t3.medium \
  --availability-zone us-east-1b \
  --publicly-accessible false

# Create second replica
aws rds create-db-instance-read-replica \
  --db-instance-identifier gold-predictor-replica-2 \
  --source-db-instance-identifier gold-predictor-master \
  --db-instance-class db.t3.medium \
  --availability-zone us-east-1c \
  --publicly-accessible false

# Wait for replicas to be available
aws rds wait db-instance-available \
  --db-instance-identifier gold-predictor-replica-1
```

---

## Step 2: Configure Application

### 2.1 Update Database Configuration

```python
# backend/app/core/database.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import random

# Master database (writes)
MASTER_DB_URL = "postgresql://user:pass@master.xxx.rds.amazonaws.com:5432/gold_predictor"

# Read replicas (reads)
REPLICA_DB_URLS = [
    "postgresql://user:pass@replica1.xxx.rds.amazonaws.com:5432/gold_predictor",
    "postgresql://user:pass@replica2.xxx.rds.amazonaws.com:5432/gold_predictor",
]

# Create engines
master_engine = create_engine(
    MASTER_DB_URL,
    pool_size=20,
    max_overflow=40,
    pool_pre_ping=True
)

replica_engines = [
    create_engine(url, pool_size=20, max_overflow=40, pool_pre_ping=True)
    for url in REPLICA_DB_URLS
]

# Round-robin replica selection
replica_index = 0

def get_read_engine():
    """Get read replica engine (round-robin)"""
    global replica_index
    engine = replica_engines[replica_index]
    replica_index = (replica_index + 1) % len(replica_engines)
    return engine

def get_write_engine():
    """Get master engine for writes"""
    return master_engine

# Session factories
def get_db_read():
    """Database session for reads"""
    engine = get_read_engine()
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_db_write():
    """Database session for writes"""
    engine = get_write_engine()
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

### 2.2 Update API Endpoints

```python
# backend/app/api/endpoints.py

from fastapi import Depends
from sqlalchemy.orm import Session
from app.core.database import get_db_read, get_db_write

# Read operations use replicas
@app.get("/api/predictions")
async def get_predictions(db: Session = Depends(get_db_read)):
    """Get predictions (uses read replica)"""
    predictions = db.query(Prediction).all()
    return predictions

# Write operations use master
@app.post("/api/predictions")
async def create_prediction(
    data: PredictionCreate,
    db: Session = Depends(get_db_write)
):
    """Create prediction (uses master)"""
    prediction = Prediction(**data.dict())
    db.add(prediction)
    db.commit()
    return prediction
```

---

## Step 3: Monitor Replication

### 3.1 Check Replication Lag

```sql
-- On master
SELECT * FROM pg_stat_replication;

-- On replica
SELECT now() - pg_last_xact_replay_timestamp() AS replication_lag;
```

### 3.2 CloudWatch Metrics

```bash
# Monitor replication lag
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name ReplicaLag \
  --dimensions Name=DBInstanceIdentifier,Value=gold-predictor-replica-1 \
  --start-time 2025-10-29T00:00:00Z \
  --end-time 2025-10-29T23:59:59Z \
  --period 300 \
  --statistics Average
```

---

## Cost Estimate

| Component | Cost/Month |
|-----------|------------|
| Replica 1 (db.t3.medium) | $30 |
| Replica 2 (db.t3.medium) | $30 |
| Storage (30GB × 2) | $6 |
| **Total** | **~$66/month** |

---

**Last Updated:** 2025-10-29  
**Component:** Database Scaling  
**Status:** Ready for implementation
