# Redis Cluster Setup Guide
# دليل إعداد Redis Cluster

**Component:** Caching Layer  
**Estimated Time:** 45 minutes  
**Cost:** ~$30/month  
**Difficulty:** Intermediate

---

## Overview

Setup Redis Cluster for high-availability caching.

**Benefits:**
- ✅ High availability
- ✅ Automatic sharding
- ✅ Horizontal scaling
- ✅ Fault tolerance

---

## Architecture

```
Redis Cluster (6 nodes)
┌────────────────────────────────┐
│ Master1  Master2  Master3      │
│   ↓        ↓        ↓          │
│ Replica1 Replica2 Replica3     │
└────────────────────────────────┘
```

---

## Step 1: Create Redis Cluster (AWS ElastiCache)

### 1.1 Via AWS CLI

```bash
# Create Redis cluster
aws elasticache create-replication-group \
  --replication-group-id gold-predictor-redis \
  --replication-group-description "Gold Predictor Redis Cluster" \
  --engine redis \
  --cache-node-type cache.t3.medium \
  --num-cache-clusters 3 \
  --automatic-failover-enabled \
  --multi-az-enabled \
  --cache-subnet-group-name my-subnet-group \
  --security-group-ids sg-12345678

# Wait for cluster to be available
aws elasticache wait replication-group-available \
  --replication-group-id gold-predictor-redis
```

---

## Step 2: Configure Application

### 2.1 Install Redis Cluster Client

```bash
pip install redis-py-cluster
```

### 2.2 Update Redis Configuration

```python
# backend/app/core/redis.py

from rediscluster import RedisCluster

# Redis cluster nodes
startup_nodes = [
    {"host": "node1.xxx.cache.amazonaws.com", "port": "6379"},
    {"host": "node2.xxx.cache.amazonaws.com", "port": "6379"},
    {"host": "node3.xxx.cache.amazonaws.com", "port": "6379"},
]

# Create cluster client
redis_client = RedisCluster(
    startup_nodes=startup_nodes,
    decode_responses=True,
    skip_full_coverage_check=True,
    max_connections=50,
    socket_timeout=5,
    socket_connect_timeout=5
)

# Usage
async def cache_set(key: str, value: str, ttl: int = 300):
    """Set cache value"""
    redis_client.setex(key, ttl, value)

async def cache_get(key: str):
    """Get cache value"""
    return redis_client.get(key)
```

---

## Cost Estimate

| Component | Cost/Month |
|-----------|------------|
| 3 × cache.t3.medium | $30 |
| Data transfer | Variable |
| **Total** | **~$30/month** |

---

**Last Updated:** 2025-10-29  
**Component:** Caching Layer  
**Status:** Ready for implementation
