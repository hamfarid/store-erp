# AWS Application Load Balancer Setup Guide
# دليل إعداد AWS Application Load Balancer

**Component:** Load Balancing  
**Estimated Time:** 45-60 minutes  
**Cost:** ~$20/month  
**Difficulty:** Intermediate

---

## Overview

This guide walks through setting up AWS Application Load Balancer (ALB) for the Gold Price Predictor application to distribute traffic across multiple backend instances.

**Benefits:**
- ✅ High availability
- ✅ Auto-scaling support
- ✅ SSL/TLS termination
- ✅ Health checks
- ✅ Path-based routing
- ✅ WebSocket support

---

## Prerequisites

- AWS account with admin access
- AWS CLI installed and configured
- At least 2 EC2 instances running the application
- VPC with multiple subnets in different AZs

---

## Architecture

```
Internet
    ↓
AWS ALB (Port 443)
    ↓
Target Group
    ↓
┌─────────┬─────────┬─────────┐
│ EC2-1   │ EC2-2   │ EC2-3   │
│ :8000   │ :8000   │ :8000   │
└─────────┴─────────┴─────────┘
```

---

## Step 1: Create Security Groups

### 1.1 ALB Security Group

```bash
# Create security group for ALB
aws ec2 create-security-group \
  --group-name gold-predictor-alb-sg \
  --description "Security group for Gold Predictor ALB" \
  --vpc-id vpc-12345678

# Note the security group ID
export ALB_SG_ID=sg-alb123456

# Allow HTTP (80)
aws ec2 authorize-security-group-ingress \
  --group-id $ALB_SG_ID \
  --protocol tcp \
  --port 80 \
  --cidr 0.0.0.0/0

# Allow HTTPS (443)
aws ec2 authorize-security-group-ingress \
  --group-id $ALB_SG_ID \
  --protocol tcp \
  --port 443 \
  --cidr 0.0.0.0/0
```

### 1.2 Backend Security Group

```bash
# Create security group for backend instances
aws ec2 create-security-group \
  --group-name gold-predictor-backend-sg \
  --description "Security group for Gold Predictor backend" \
  --vpc-id vpc-12345678

export BACKEND_SG_ID=sg-backend123456

# Allow traffic from ALB only
aws ec2 authorize-security-group-ingress \
  --group-id $BACKEND_SG_ID \
  --protocol tcp \
  --port 8000 \
  --source-group $ALB_SG_ID

# Allow SSH (for management)
aws ec2 authorize-security-group-ingress \
  --group-id $BACKEND_SG_ID \
  --protocol tcp \
  --port 22 \
  --cidr YOUR_IP/32
```

---

## Step 2: Create Target Group

### 2.1 Create Target Group

```bash
# Create target group
aws elbv2 create-target-group \
  --name gold-predictor-targets \
  --protocol HTTP \
  --port 8000 \
  --vpc-id vpc-12345678 \
  --health-check-enabled \
  --health-check-protocol HTTP \
  --health-check-path /health \
  --health-check-interval-seconds 30 \
  --health-check-timeout-seconds 5 \
  --healthy-threshold-count 2 \
  --unhealthy-threshold-count 3 \
  --matcher HttpCode=200

# Note the target group ARN
export TG_ARN=arn:aws:elasticloadbalancing:us-east-1:123456789:targetgroup/gold-predictor-targets/abc123
```

### 2.2 Register Targets

```bash
# Register EC2 instances
aws elbv2 register-targets \
  --target-group-arn $TG_ARN \
  --targets \
    Id=i-instance1 \
    Id=i-instance2 \
    Id=i-instance3

# Verify targets
aws elbv2 describe-target-health \
  --target-group-arn $TG_ARN
```

### 2.3 Configure Target Group Attributes

```bash
# Configure stickiness (optional)
aws elbv2 modify-target-group-attributes \
  --target-group-arn $TG_ARN \
  --attributes \
    Key=stickiness.enabled,Value=true \
    Key=stickiness.type,Value=lb_cookie \
    Key=stickiness.lb_cookie.duration_seconds,Value=86400 \
    Key=deregistration_delay.timeout_seconds,Value=30
```

---

## Step 3: Create Application Load Balancer

### 3.1 Create ALB

```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name gold-predictor-alb \
  --subnets subnet-12345678 subnet-87654321 \
  --security-groups $ALB_SG_ID \
  --scheme internet-facing \
  --type application \
  --ip-address-type ipv4 \
  --tags Key=Name,Value=gold-predictor-alb

# Note the ALB ARN and DNS name
export ALB_ARN=arn:aws:elasticloadbalancing:us-east-1:123456789:loadbalancer/app/gold-predictor-alb/xyz123
export ALB_DNS=gold-predictor-alb-123456789.us-east-1.elb.amazonaws.com
```

### 3.2 Configure ALB Attributes

```bash
# Enable access logs (optional)
aws elbv2 modify-load-balancer-attributes \
  --load-balancer-arn $ALB_ARN \
  --attributes \
    Key=access_logs.s3.enabled,Value=true \
    Key=access_logs.s3.bucket,Value=my-alb-logs \
    Key=access_logs.s3.prefix,Value=gold-predictor \
    Key=idle_timeout.timeout_seconds,Value=60 \
    Key=deletion_protection.enabled,Value=true
```

---

## Step 4: Request SSL Certificate

### 4.1 Request Certificate from ACM

```bash
# Request certificate
aws acm request-certificate \
  --domain-name api.goldpredictor.com \
  --subject-alternative-names \
    "*.goldpredictor.com" \
    "goldpredictor.com" \
  --validation-method DNS \
  --region us-east-1

# Note the certificate ARN
export CERT_ARN=arn:aws:acm:us-east-1:123456789:certificate/abc-123-def-456
```

### 4.2 Validate Certificate

```bash
# Get validation records
aws acm describe-certificate \
  --certificate-arn $CERT_ARN

# Add CNAME records to your DNS (Route 53 or external)
# Wait for validation (usually 5-30 minutes)

# Check status
aws acm describe-certificate \
  --certificate-arn $CERT_ARN \
  --query 'Certificate.Status'
```

---

## Step 5: Create Listeners

### 5.1 Create HTTPS Listener

```bash
# Create HTTPS listener (port 443)
aws elbv2 create-listener \
  --load-balancer-arn $ALB_ARN \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=$CERT_ARN \
  --default-actions \
    Type=forward,TargetGroupArn=$TG_ARN \
  --ssl-policy ELBSecurityPolicy-TLS-1-2-2017-01

# Note the listener ARN
export HTTPS_LISTENER_ARN=arn:aws:elasticloadbalancing:us-east-1:123456789:listener/app/gold-predictor-alb/xyz123/abc123
```

### 5.2 Create HTTP Listener (Redirect to HTTPS)

```bash
# Create HTTP listener (port 80) that redirects to HTTPS
aws elbv2 create-listener \
  --load-balancer-arn $ALB_ARN \
  --protocol HTTP \
  --port 80 \
  --default-actions \
    Type=redirect,RedirectConfig='{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}'
```

---

## Step 6: Configure Listener Rules

### 6.1 Add Path-Based Routing

```bash
# Create rule for /api/* (higher priority)
aws elbv2 create-rule \
  --listener-arn $HTTPS_LISTENER_ARN \
  --priority 10 \
  --conditions \
    Field=path-pattern,Values='/api/*' \
  --actions \
    Type=forward,TargetGroupArn=$TG_ARN

# Create rule for /health (health check)
aws elbv2 create-rule \
  --listener-arn $HTTPS_LISTENER_ARN \
  --priority 20 \
  --conditions \
    Field=path-pattern,Values='/health' \
  --actions \
    Type=forward,TargetGroupArn=$TG_ARN
```

### 6.2 Add Host-Based Routing (Optional)

```bash
# Create rule for specific subdomain
aws elbv2 create-rule \
  --listener-arn $HTTPS_LISTENER_ARN \
  --priority 5 \
  --conditions \
    Field=host-header,Values='api.goldpredictor.com' \
  --actions \
    Type=forward,TargetGroupArn=$TG_ARN
```

---

## Step 7: Update DNS

### 7.1 Create Route 53 Record

```bash
# Get hosted zone ID
aws route53 list-hosted-zones-by-name \
  --dns-name goldpredictor.com

export HOSTED_ZONE_ID=Z1234567890ABC

# Create A record (alias to ALB)
cat > change-batch.json << EOF
{
  "Changes": [{
    "Action": "CREATE",
    "ResourceRecordSet": {
      "Name": "api.goldpredictor.com",
      "Type": "A",
      "AliasTarget": {
        "HostedZoneId": "Z35SXDOTRQ7X7K",
        "DNSName": "$ALB_DNS",
        "EvaluateTargetHealth": true
      }
    }
  }]
}
EOF

aws route53 change-resource-record-sets \
  --hosted-zone-id $HOSTED_ZONE_ID \
  --change-batch file://change-batch.json
```

---

## Step 8: Configure Backend Application

### 8.1 Update Application to Trust ALB

```python
# backend/app/main.py

from fastapi import FastAPI, Request

app = FastAPI()

@app.middleware("http")
async def trust_alb_headers(request: Request, call_next):
    """Trust X-Forwarded-* headers from ALB"""
    
    # Get real client IP from ALB headers
    if "X-Forwarded-For" in request.headers:
        request.state.client_ip = request.headers["X-Forwarded-For"].split(",")[0]
    else:
        request.state.client_ip = request.client.host
    
    # Get real protocol from ALB headers
    if "X-Forwarded-Proto" in request.headers:
        request.state.protocol = request.headers["X-Forwarded-Proto"]
    else:
        request.state.protocol = request.url.scheme
    
    response = await call_next(request)
    return response
```

### 8.2 Update Health Check Endpoint

```python
# backend/app/api/health.py

from fastapi import APIRouter
from sqlalchemy import text

router = APIRouter()

@router.get("/health")
async def health_check():
    """
    Health check endpoint for ALB
    
    Returns 200 if healthy, 503 if unhealthy
    """
    try:
        # Check database connection
        db.execute(text("SELECT 1"))
        
        # Check Redis connection
        redis_client.ping()
        
        return {
            "status": "healthy",
            "database": "connected",
            "redis": "connected"
        }
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "error": str(e)
            }
        )
```

---

## Step 9: Test Load Balancer

### 9.1 Test HTTP → HTTPS Redirect

```bash
# Test HTTP redirect
curl -I http://api.goldpredictor.com

# Expected: 301 redirect to https://
```

### 9.2 Test HTTPS Connection

```bash
# Test HTTPS
curl -I https://api.goldpredictor.com/health

# Expected: 200 OK
```

### 9.3 Test Load Distribution

```bash
# Make multiple requests
for i in {1..10}; do
  curl https://api.goldpredictor.com/health
  sleep 1
done

# Check ALB access logs to verify distribution
```

### 9.4 Test Health Checks

```bash
# Check target health
aws elbv2 describe-target-health \
  --target-group-arn $TG_ARN

# Expected: All targets "healthy"
```

---

## Step 10: Monitoring & Alerts

### 10.1 Enable CloudWatch Metrics

```bash
# ALB metrics are automatically published to CloudWatch
# View metrics in CloudWatch console

# Key metrics:
# - TargetResponseTime
# - RequestCount
# - HealthyHostCount
# - UnHealthyHostCount
# - HTTPCode_Target_2XX_Count
# - HTTPCode_Target_5XX_Count
```

### 10.2 Create CloudWatch Alarms

```bash
# Alarm for unhealthy targets
aws cloudwatch put-metric-alarm \
  --alarm-name gold-predictor-unhealthy-targets \
  --alarm-description "Alert when targets are unhealthy" \
  --metric-name UnHealthyHostCount \
  --namespace AWS/ApplicationELB \
  --statistic Average \
  --period 300 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --evaluation-periods 2 \
  --dimensions \
    Name=LoadBalancer,Value=app/gold-predictor-alb/xyz123 \
    Name=TargetGroup,Value=targetgroup/gold-predictor-targets/abc123

# Alarm for high response time
aws cloudwatch put-metric-alarm \
  --alarm-name gold-predictor-high-response-time \
  --alarm-description "Alert when response time is high" \
  --metric-name TargetResponseTime \
  --namespace AWS/ApplicationELB \
  --statistic Average \
  --period 300 \
  --threshold 1.0 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --dimensions \
    Name=LoadBalancer,Value=app/gold-predictor-alb/xyz123
```

---

## Step 11: Auto-Scaling Integration

### 11.1 Create Launch Template

```bash
# Create launch template for auto-scaling
aws ec2 create-launch-template \
  --launch-template-name gold-predictor-template \
  --version-description "v1.0" \
  --launch-template-data '{
    "ImageId": "ami-12345678",
    "InstanceType": "t3.medium",
    "SecurityGroupIds": ["'$BACKEND_SG_ID'"],
    "UserData": "'$(base64 -w 0 user-data.sh)'",
    "TagSpecifications": [{
      "ResourceType": "instance",
      "Tags": [{"Key": "Name", "Value": "gold-predictor-backend"}]
    }]
  }'
```

### 11.2 Create Auto Scaling Group

```bash
# Create auto-scaling group
aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name gold-predictor-asg \
  --launch-template LaunchTemplateName=gold-predictor-template,Version='$Latest' \
  --min-size 2 \
  --max-size 10 \
  --desired-capacity 3 \
  --target-group-arns $TG_ARN \
  --health-check-type ELB \
  --health-check-grace-period 300 \
  --vpc-zone-identifier "subnet-12345678,subnet-87654321"
```

### 11.3 Create Scaling Policies

```bash
# Scale up policy
aws autoscaling put-scaling-policy \
  --auto-scaling-group-name gold-predictor-asg \
  --policy-name scale-up \
  --policy-type TargetTrackingScaling \
  --target-tracking-configuration '{
    "PredefinedMetricSpecification": {
      "PredefinedMetricType": "ASGAverageCPUUtilization"
    },
    "TargetValue": 70.0
  }'
```

---

## Terraform Configuration (Alternative)

```hcl
# main.tf

# Security group for ALB
resource "aws_security_group" "alb" {
  name        = "gold-predictor-alb-sg"
  description = "Security group for ALB"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# Application Load Balancer
resource "aws_lb" "main" {
  name               = "gold-predictor-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = var.public_subnets

  enable_deletion_protection = true
  enable_http2              = true
  enable_cross_zone_load_balancing = true

  access_logs {
    bucket  = aws_s3_bucket.alb_logs.id
    prefix  = "gold-predictor"
    enabled = true
  }

  tags = {
    Name = "gold-predictor-alb"
  }
}

# Target group
resource "aws_lb_target_group" "main" {
  name     = "gold-predictor-targets"
  port     = 8000
  protocol = "HTTP"
  vpc_id   = var.vpc_id

  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    path                = "/health"
    matcher             = "200"
  }

  stickiness {
    type            = "lb_cookie"
    cookie_duration = 86400
    enabled         = true
  }

  deregistration_delay = 30
}

# HTTPS listener
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.main.arn
  port              = "443"
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS-1-2-2017-01"
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.main.arn
  }
}

# HTTP listener (redirect to HTTPS)
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type = "redirect"

    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

# Route 53 record
resource "aws_route53_record" "api" {
  zone_id = var.hosted_zone_id
  name    = "api.goldpredictor.com"
  type    = "A"

  alias {
    name                   = aws_lb.main.dns_name
    zone_id                = aws_lb.main.zone_id
    evaluate_target_health = true
  }
}
```

---

## Cost Estimate

| Component | Cost/Month |
|-----------|------------|
| ALB (hourly) | $16.20 |
| ALB (LCU) | $3-8 |
| Data transfer | Variable |
| **Total** | **~$20-25/month** |

---

## Troubleshooting

### Targets Unhealthy

**Check:**
1. Security group allows traffic from ALB
2. Application is running on correct port (8000)
3. Health check endpoint returns 200
4. Health check path is correct (/health)

### SSL Certificate Issues

**Check:**
1. Certificate is validated
2. Certificate ARN is correct
3. Domain matches certificate

### High Response Time

**Check:**
1. Backend instances have sufficient resources
2. Database connections not exhausted
3. No slow queries

---

## Best Practices

- ✅ Use multiple AZs for high availability
- ✅ Enable access logs for debugging
- ✅ Configure appropriate health checks
- ✅ Use SSL/TLS for all traffic
- ✅ Enable deletion protection
- ✅ Configure CloudWatch alarms
- ✅ Use auto-scaling for elasticity
- ✅ Regular review of metrics

---

**Last Updated:** 2025-10-29  
**Component:** Load Balancing  
**Cost:** ~$20/month  
**Status:** Ready for implementation

