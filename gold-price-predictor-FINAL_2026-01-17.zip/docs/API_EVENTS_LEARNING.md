# API Documentation - Events & Learning System

**ملف:** `docs/API_EVENTS_LEARNING.md`  
**الغرض:** توثيق API endpoints لنظام Events & Learning  
**آخر تحديث:** 2025-01-18

---

## نظرة عامة

يستخدم النظام tRPC للاتصال بين العميل والخادم. جميع الـ endpoints مكتوبة بالكامل مع TypeScript وتوفر type safety كامل.

---

## Events Router (`events.*`)

### `events.list`

**الوصف:** الحصول على قائمة الأحداث مع فلاتر اختيارية

**Input:**
```typescript
{
  eventType?: "political" | "economic" | "geopolitical" | "monetary_policy" | "market" | "commodity" | "natural_disaster" | "war" | "sanctions" | "other";
  severity?: "low" | "medium" | "high" | "critical";
  verified?: boolean;
  startDate?: string; // ISO string
  endDate?: string; // ISO string
  limit?: number; // 1-1000
  offset?: number;
}
```

**Output:**
```typescript
Event[]
```

**مثال:**
```typescript
const events = await trpc.events.list.query({
  eventType: "economic",
  severity: "high",
  limit: 50
});
```

---

### `events.getById`

**الوصف:** الحصول على حدث محدد بالمعرف

**Input:**
```typescript
{
  id: string;
}
```

**Output:**
```typescript
Event
```

**Errors:**
- `NOT_FOUND` - إذا لم يتم العثور على الحدث

---

### `events.getWithAnalysis`

**الوصف:** الحصول على حدث مع تحليله

**Input:**
```typescript
{
  id: string;
}
```

**Output:**
```typescript
{
  event: Event;
  analysis: EventAnalysis | null;
}
```

---

### `events.getWithImpacts`

**الوصف:** الحصول على حدث مع تأثيراته على الأسعار

**Input:**
```typescript
{
  id: string;
}
```

**Output:**
```typescript
{
  event: Event;
  impacts: EventPriceImpact[];
}
```

---

### `events.create` (Admin Only)

**الوصف:** إنشاء حدث جديد

**Input:**
```typescript
{
  title: string; // 1-255 chars
  description?: string;
  eventType: "political" | "economic" | ...;
  eventDate: string; // ISO string
  source?: string;
  sourceUrl?: string; // URL or empty string
  severity?: "low" | "medium" | "high" | "critical";
  verified?: boolean;
  tags?: string[];
}
```

**Output:**
```typescript
Event
```

**Errors:**
- `FORBIDDEN` - إذا لم يكن المستخدم admin
- `INTERNAL_SERVER_ERROR` - في حالة فشل الإنشاء

---

### `events.createWithAnalysis` (Admin Only)

**الوصف:** إنشاء حدث مع تحليله في استدعاء واحد (مع دعم المعاملات)

**Input:**
```typescript
{
  // Event data
  title: string;
  description?: string;
  eventType: "political" | "economic" | ...;
  eventDate: string; // ISO string
  source?: string;
  sourceUrl?: string;
  severity?: "low" | "medium" | "high" | "critical";
  verified?: boolean;
  tags?: string[];
  // Analysis data
  sentiment?: "positive" | "neutral" | "negative";
  sentimentScore?: string; // -1 to 1
  impactScore?: string; // 0 to 10
  confidence?: string; // 0 to 1
  entities?: any[];
  keywords?: string[];
  summary?: string;
  analyzerVersion?: string;
}
```

**Output:**
```typescript
{
  event: Event;
  analysis: EventAnalysis;
}
```

**ملاحظة:** هذه العملية ذرية (atomic) - إذا فشل إنشاء التحليل، يتم التراجع عن إنشاء الحدث.

---

### `events.update` (Admin Only)

**الوصف:** تحديث حدث موجود

**Input:**
```typescript
{
  id: string;
  title?: string;
  description?: string;
  eventType?: "political" | "economic" | ...;
  eventDate?: string; // ISO string
  source?: string;
  sourceUrl?: string;
  severity?: "low" | "medium" | "high" | "critical";
  verified?: boolean;
  tags?: string[];
}
```

**Output:**
```typescript
Event
```

---

### `events.delete` (Admin Only)

**الوصف:** حذف حدث

**Input:**
```typescript
{
  id: string;
}
```

**Output:**
```typescript
{
  success: boolean;
}
```

---

## Learning Router (`learning.*`)

### `learning.predictions.create`

**الوصف:** إنشاء توقع جديد

**Input:**
```typescript
{
  assetId: number;
  predictionDate: string; // ISO string
  targetDate: string; // ISO string
  daysAhead: number;
  currentPrice: string;
  predictedPrice: string;
  confidenceLower?: string;
  confidenceUpper?: string;
  modelType: string;
}
```

**Output:**
```typescript
Prediction
```

---

### `learning.predictions.list`

**الوصف:** الحصول على قائمة التوقعات

**Input:**
```typescript
{
  assetId?: number;
  limit?: number; // 1-1000
  offset?: number;
}
```

**Output:**
```typescript
Prediction[]
```

---

### `learning.predictions.updateActual`

**الوصف:** تحديث السعر الفعلي للتوقع (لنظام التعلم)

**Input:**
```typescript
{
  predictionId: number;
  actualPrice: string;
}
```

**Output:**
```typescript
{
  success: boolean;
}
```

**ملاحظة:** هذا endpoint مهم لنظام التعلم - عند تحديث السعر الفعلي، يمكن للنظام حساب دقة التوقع وإنشاء مقارنات.

---

### `learning.comparisons.create`

**الوصف:** إنشاء مقارنة بين التوقع والنتيجة الفعلية

**Input:**
```typescript
{
  predictionId: number;
  actualPrice: string;
  predictedPrice: string;
  error?: string;
  errorPercent?: string;
  accuracy?: string; // 0 to 1
  withinConfidence?: boolean;
  modelVersion?: string;
}
```

**Output:**
```typescript
PredictionComparison
```

---

### `learning.comparisons.get`

**الوصف:** الحصول على مقارنة محددة

**Input:**
```typescript
{
  id: number;
}
```

**Output:**
```typescript
PredictionComparison
```

---

### `learning.comparisons.list`

**الوصف:** الحصول على قائمة المقارنات

**Input:**
```typescript
{
  predictionId?: number;
  minAccuracy?: number;
  maxAccuracy?: number;
  withinConfidence?: boolean;
  limit?: number; // 1-1000
  offset?: number;
}
```

**Output:**
```typescript
PredictionComparison[]
```

---

### `learning.comparisons.listByAccuracy`

**الوصف:** الحصول على المقارنات مرتبة حسب الدقة

**Input:**
```typescript
{
  minAccuracy: number; // 0-1, default: 0.8
  limit: number; // default: 100
}
```

**Output:**
```typescript
PredictionComparison[]
```

---

### `learning.insights.create`

**الوصف:** إنشاء رؤية (insight) جديدة

**Input:**
```typescript
{
  type: "pattern" | "correlation" | "anomaly" | "trend" | "prediction_accuracy" | "model_performance";
  title: string; // 1-255 chars
  description?: string;
  confidence?: string; // 0 to 1
  impact?: "low" | "medium" | "high" | "critical";
  data?: Record<string, unknown>;
  relatedPredictions?: number[];
  relatedEvents?: string[];
}
```

**Output:**
```typescript
LearningInsight
```

---

### `learning.insights.list`

**الوصف:** الحصول على قائمة الرؤى

**Input:**
```typescript
{
  type?: "pattern" | "correlation" | ...;
  status?: "pending" | "reviewed" | "applied" | "rejected";
  impact?: "low" | "medium" | "high" | "critical";
  limit?: number; // 1-1000
  offset?: number;
}
```

**Output:**
```typescript
LearningInsight[]
```

---

### `learning.insights.updateStatus` (Admin Only)

**الوصف:** تحديث حالة الرؤية

**Input:**
```typescript
{
  id: number;
  status: "pending" | "reviewed" | "applied" | "rejected";
}
```

**Output:**
```typescript
LearningInsight
```

---

### `learning.adjustments.create`

**الوصف:** إنشاء تعديل على النموذج

**Input:**
```typescript
{
  insightId: number;
  adjustmentType: "parameter_tuning" | "feature_addition" | "feature_removal" | "weight_adjustment" | "threshold_change" | "algorithm_change";
  description?: string;
  parameters?: Record<string, unknown>;
  modelVersion?: string;
  previousVersion?: string;
  performanceBefore?: Record<string, unknown>;
}
```

**Output:**
```typescript
ModelAdjustment
```

---

### `learning.adjustments.list`

**الوصف:** الحصول على قائمة التعديلات

**Input:**
```typescript
{
  insightId?: number;
  status?: "proposed" | "approved" | "applied" | "reverted" | "rejected";
  adjustmentType?: "parameter_tuning" | ...;
  limit?: number; // 1-1000
  offset?: number;
}
```

**Output:**
```typescript
ModelAdjustment[]
```

---

### `learning.adjustments.apply` (Admin Only)

**الوصف:** تطبيق تعديل على النموذج

**Input:**
```typescript
{
  id: number;
  performanceAfter?: Record<string, unknown>;
}
```

**Output:**
```typescript
ModelAdjustment
```

---

### `learning.adjustments.revert` (Admin Only)

**الوصف:** إرجاع تعديل

**Input:**
```typescript
{
  id: number;
}
```

**Output:**
```typescript
ModelAdjustment
```

---

## Learning Control Router (`learningControl.*`)

### Keywords

#### `learningControl.keywords.list`

**Input:**
```typescript
{
  category?: string;
  priority?: string;
  enabled?: boolean;
}
```

**Output:**
```typescript
SearchKeyword[]
```

---

#### `learningControl.keywords.create`

**Input:**
```typescript
{
  keyword: string; // min 1 char
  category: "political" | "economic" | "geopolitical" | "monetary_policy" | "market" | "commodity" | "general";
  priority?: "low" | "medium" | "high" | "critical";
  enabled?: boolean;
}
```

**Output:**
```typescript
SearchKeyword
```

---

#### `learningControl.keywords.update`

**Input:**
```typescript
{
  id: number;
  keyword?: string;
  category?: "political" | ...;
  priority?: "low" | "medium" | "high" | "critical";
  enabled?: boolean;
}
```

**Output:**
```typescript
SearchKeyword
```

---

#### `learningControl.keywords.delete` (Admin Only)

**Input:**
```typescript
{
  id: number;
}
```

**Output:**
```typescript
{
  success: boolean;
}
```

---

### Sources

#### `learningControl.sources.list`

**Input:**
```typescript
{
  type?: string;
  enabled?: boolean;
}
```

**Output:**
```typescript
SearchSource[]
```

---

#### `learningControl.sources.create`

**Input:**
```typescript
{
  name: string;
  type: "search_engine" | "news_site" | "financial_site" | "government_site" | "social_media" | "api";
  url: string;
  enabled?: boolean;
  config?: Record<string, unknown>;
  headers?: Record<string, string>;
  rateLimit?: number; // requests per minute
}
```

**Output:**
```typescript
SearchSource
```

---

#### `learningControl.sources.update`

**Input:**
```typescript
{
  id: number;
  name?: string;
  type?: "search_engine" | ...;
  url?: string;
  enabled?: boolean;
  config?: Record<string, unknown>;
  headers?: Record<string, string>;
  rateLimit?: number;
}
```

**Output:**
```typescript
SearchSource
```

---

#### `learningControl.sources.delete` (Admin Only)

**Input:**
```typescript
{
  id: number;
}
```

**Output:**
```typescript
{
  success: boolean;
}
```

---

### Learning Operations

#### `learningControl.learning.list`

**Input:**
```typescript
{
  type?: string;
  status?: string;
  triggeredBy?: string;
}
```

**Output:**
```typescript
LearningOperation[]
```

---

#### `learningControl.learning.active`

**الوصف:** الحصول على العمليات النشطة فقط

**Output:**
```typescript
LearningOperation[]
```

---

#### `learningControl.learning.start`

**Input:**
```typescript
{
  type: "prediction_comparison" | "pattern_detection" | "correlation_analysis" | "model_training" | "insight_generation" | "adjustment_application";
  input?: Record<string, unknown>;
}
```

**Output:**
```typescript
LearningOperation
```

---

#### `learningControl.learning.update`

**Input:**
```typescript
{
  id: string;
  status?: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress?: number; // 0-100
  currentStep?: string;
  totalSteps?: number;
  output?: Record<string, unknown>;
  error?: string;
  duration?: number; // seconds
  resultsCount?: number;
  insightsGenerated?: number;
  adjustmentsProposed?: number;
}
```

**Output:**
```typescript
LearningOperation
```

---

### Search Operations

#### `learningControl.search.list`

**Input:**
```typescript
{
  type?: string;
  status?: string;
  triggeredBy?: string;
}
```

**Output:**
```typescript
SearchOperation[]
```

---

#### `learningControl.search.active`

**الوصف:** الحصول على عمليات البحث النشطة فقط

**Output:**
```typescript
SearchOperation[]
```

---

#### `learningControl.search.start`

**Input:**
```typescript
{
  type: "keyword_search" | "event_discovery" | "news_scraping" | "sentiment_analysis" | "entity_extraction";
  keywords: string[];
  sources: string[]; // Source IDs or names
  dateRange?: {
    start: string; // ISO string
    end: string; // ISO string
  };
}
```

**Output:**
```typescript
SearchOperation
```

---

#### `learningControl.search.update`

**Input:**
```typescript
{
  id: string;
  status?: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress?: number; // 0-100
  currentSource?: string;
  sourcesProcessed?: number;
  totalSources?: number;
  resultsFound?: number;
  eventsCreated?: number;
  error?: string;
  duration?: number; // seconds
}
```

**Output:**
```typescript
SearchOperation
```

---

### Operation Logs

#### `learningControl.logs.list`

**Input:**
```typescript
{
  operationId: string;
  operationType?: "learning" | "search";
  level?: "debug" | "info" | "warning" | "error";
  limit?: number; // 1-1000
}
```

**Output:**
```typescript
OperationLog[]
```

---

#### `learningControl.logs.create`

**Input:**
```typescript
{
  operationId: string;
  operationType: "learning" | "search";
  level: "debug" | "info" | "warning" | "error";
  message: string;
  data?: Record<string, unknown>;
}
```

**Output:**
```typescript
OperationLog
```

---

## معالجة الأخطاء

جميع endpoints تستخدم `TRPCError` مع الرموز التالية:

- `NOT_FOUND` - المورد غير موجود
- `UNAUTHORIZED` - غير مصرح (يحتاج تسجيل دخول)
- `FORBIDDEN` - محظور (يحتاج صلاحيات admin)
- `BAD_REQUEST` - بيانات غير صحيحة
- `INTERNAL_SERVER_ERROR` - خطأ في الخادم

**مثال:**
```typescript
try {
  const event = await trpc.events.getById.query({ id: "invalid-id" });
} catch (error) {
  if (error.data?.code === "NOT_FOUND") {
    console.log("Event not found");
  }
}
```

---

## أمثلة الاستخدام

### إنشاء حدث مع تحليل

```typescript
const result = await trpc.events.createWithAnalysis.mutate({
  title: "Federal Reserve Interest Rate Decision",
  description: "The Fed announced a 0.25% rate increase",
  eventType: "monetary_policy",
  eventDate: "2025-01-18T10:00:00Z",
  source: "Federal Reserve",
  sourceUrl: "https://federalreserve.gov/...",
  severity: "high",
  verified: true,
  tags: ["interest rates", "monetary policy"],
  sentiment: "negative",
  sentimentScore: "-0.6",
  impactScore: "8.5",
  confidence: "0.9",
  summary: "Rate increase expected to impact gold prices negatively"
});
```

### بدء عملية تعلم

```typescript
const operation = await trpc.learningControl.learning.start.mutate({
  type: "pattern_detection",
  input: {
    assetId: 1,
    dateRange: {
      start: "2025-01-01",
      end: "2025-01-18"
    }
  }
});
```

### الاشتراك في التحديثات (WebSocket)

```typescript
const { subscribe } = useWebSocket();

useEffect(() => {
  const unsubscribe = subscribe('learning:operation:update', (message) => {
    if (message.data.id === operation.id) {
      // Update operation in UI
      setOperation(message.data);
    }
  });
  
  return unsubscribe;
}, [operation.id]);
```

---

## ملاحظات مهمة

1. **التواريخ:** جميع التواريخ تُرسل كـ ISO strings وتُحول تلقائياً إلى Date objects
2. **الأرقام:** الأرقام الكبيرة (مثل الأسعار) تُرسل كـ strings لتجنب مشاكل precision
3. **JSON Fields:** الحقول من نوع JSON تُرسل كـ objects/arrays عادية
4. **Admin Only:** بعض endpoints تحتاج صلاحيات admin - سيتم رفض الطلب بـ `FORBIDDEN` إذا لم يكن المستخدم admin

---

**آخر تحديث:** 2025-01-18

