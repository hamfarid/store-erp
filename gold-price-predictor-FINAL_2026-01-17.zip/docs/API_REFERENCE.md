# 📡 API Reference - Gold Price Predictor

**Version**: 4.0  
**Last Updated**: 2026-01-15  
**Base URL**: `http://localhost:3000/api`

---

## 📋 Table of Contents

1. [Authentication](#authentication)
2. [Learning Control API](#learning-control-api)
   - [Stats](#stats)
   - [Keywords](#keywords)
   - [Sources](#sources)
   - [Learning Operations](#learning-operations)
   - [Search Operations](#search-operations)
   - [Logs](#logs)
3. [WebSocket API](#websocket-api)
4. [Error Handling](#error-handling)
5. [Rate Limiting](#rate-limiting)

---

## Authentication

All API endpoints require authentication via JWT token.

### Request Header

```http
Authorization: Bearer <your-jwt-token>
```

### Getting a Token

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "your-password"
}
```

**Response**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "user_123",
    "email": "admin@example.com",
    "role": "admin"
  },
  "expiresIn": "24h"
}
```

---

## Learning Control API

Base path: `/api/trpc/learningControl`

### Stats

#### Get Dashboard Stats

```http
GET /api/trpc/learningControl.stats.get
```

**Response**:
```json
{
  "result": {
    "data": {
      "totalKeywords": 42,
      "activeKeywords": 38,
      "totalSources": 15,
      "activeSources": 12,
      "healthySources": 10,
      "totalLearningOps": 156,
      "runningLearningOps": 2,
      "completedLearningOps": 150,
      "failedLearningOps": 4,
      "totalSearchOps": 89,
      "runningSearchOps": 1,
      "totalInsights": 234,
      "recentInsights": 12
    }
  }
}
```

---

### Keywords

#### List Keywords

```http
GET /api/trpc/learningControl.keywords.list?input={"limit":10,"offset":0}
```

**Query Parameters** (as JSON in `input`):
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| limit | number | No | 50 | Max results |
| offset | number | No | 0 | Pagination offset |
| category | string | No | - | Filter by category |
| enabled | boolean | No | - | Filter by status |
| search | string | No | - | Search in keyword text |

**Response**:
```json
{
  "result": {
    "data": [
      {
        "id": 1,
        "keyword": "gold",
        "category": "commodity",
        "priority": "high",
        "enabled": true,
        "searchCount": 156,
        "lastSearched": "2026-01-15T10:30:00Z",
        "totalResults": 4567,
        "createdAt": "2026-01-01T00:00:00Z"
      }
    ],
    "total": 42,
    "hasMore": true
  }
}
```

#### Get Keyword by ID

```http
GET /api/trpc/learningControl.keywords.getById?input={"id":1}
```

#### Create Keyword

```http
POST /api/trpc/learningControl.keywords.create
Content-Type: application/json

{
  "keyword": "inflation",
  "category": "economic",
  "priority": "high",
  "enabled": true
}
```

**Response**:
```json
{
  "result": {
    "data": {
      "id": 43,
      "keyword": "inflation",
      "category": "economic",
      "priority": "high",
      "enabled": true,
      "createdAt": "2026-01-15T14:30:00Z"
    }
  }
}
```

#### Update Keyword

```http
POST /api/trpc/learningControl.keywords.update
Content-Type: application/json

{
  "id": 43,
  "priority": "medium",
  "enabled": false
}
```

#### Delete Keyword

```http
POST /api/trpc/learningControl.keywords.delete
Content-Type: application/json

{
  "id": 43
}
```

---

### Sources

#### List Sources

```http
GET /api/trpc/learningControl.sources.list?input={"limit":10}
```

**Query Parameters**:
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| limit | number | No | 50 | Max results |
| offset | number | No | 0 | Pagination offset |
| type | string | No | - | Filter by type |
| enabled | boolean | No | - | Filter by status |
| healthy | boolean | No | - | Filter by health |

**Response**:
```json
{
  "result": {
    "data": [
      {
        "id": 1,
        "name": "Reuters",
        "url": "https://www.reuters.com",
        "type": "news_site",
        "priority": "high",
        "enabled": true,
        "healthy": true,
        "lastChecked": "2026-01-15T14:25:00Z",
        "avgResponseTime": 234,
        "successRate": 99.2,
        "totalRequests": 1456,
        "failedRequests": 12
      }
    ],
    "total": 15
  }
}
```

#### Create Source

```http
POST /api/trpc/learningControl.sources.create
Content-Type: application/json

{
  "name": "Bloomberg",
  "url": "https://www.bloomberg.com",
  "type": "financial_site",
  "priority": "high",
  "enabled": true
}
```

**Source Types**:
- `news_site` - News websites
- `financial_site` - Financial data sites
- `api` - API endpoints
- `social` - Social media platforms

#### Update Source

```http
POST /api/trpc/learningControl.sources.update
Content-Type: application/json

{
  "id": 2,
  "enabled": false
}
```

#### Delete Source

```http
POST /api/trpc/learningControl.sources.delete
Content-Type: application/json

{
  "id": 2
}
```

#### Check Source Health

```http
POST /api/trpc/learningControl.sources.checkHealth
Content-Type: application/json

{
  "id": 1
}
```

---

### Learning Operations

#### List Learning Operations

```http
GET /api/trpc/learningControl.learning.list?input={"limit":10,"status":"running"}
```

**Query Parameters**:
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| limit | number | No | 20 | Max results |
| offset | number | No | 0 | Pagination offset |
| type | string | No | - | Filter by operation type |
| status | string | No | - | Filter by status |

**Operation Types**:
- `prediction_comparison` - Compare predictions with actual prices
- `pattern_detection` - Detect recurring patterns
- `correlation_analysis` - Analyze event-price correlations
- `model_training` - Train ML models
- `insight_generation` - Generate insights
- `adjustment_application` - Apply model adjustments

**Status Values**:
- `pending` - Queued, waiting to start
- `running` - Currently executing
- `completed` - Finished successfully
- `failed` - Finished with error
- `cancelled` - Cancelled by user

**Response**:
```json
{
  "result": {
    "data": [
      {
        "id": "op_abc123",
        "type": "prediction_comparison",
        "status": "running",
        "progress": 75,
        "currentStep": "مقارنة التوقعات بالواقع",
        "totalSteps": 5,
        "input": {},
        "output": null,
        "resultsCount": 45,
        "insightsGenerated": 3,
        "adjustmentsProposed": 0,
        "duration": null,
        "error": null,
        "startedAt": "2026-01-15T14:00:00Z",
        "completedAt": null,
        "triggeredBy": "user_123",
        "createdAt": "2026-01-15T13:59:55Z"
      }
    ],
    "total": 156
  }
}
```

#### Start Learning Operation

```http
POST /api/trpc/learningControl.learning.start
Content-Type: application/json

{
  "type": "prediction_comparison",
  "input": {
    "daysBack": 30,
    "confidenceThreshold": 0.7
  }
}
```

**Response**:
```json
{
  "result": {
    "data": {
      "id": "op_def456",
      "type": "prediction_comparison",
      "status": "pending",
      "createdAt": "2026-01-15T14:30:00Z"
    }
  }
}
```

#### Get Operation by ID

```http
GET /api/trpc/learningControl.learning.getById?input={"id":"op_abc123"}
```

#### Cancel Operation

```http
POST /api/trpc/learningControl.learning.cancel
Content-Type: application/json

{
  "id": "op_abc123"
}
```

---

### Search Operations

#### List Search Operations

```http
GET /api/trpc/learningControl.search.list?input={"limit":10}
```

**Response**:
```json
{
  "result": {
    "data": [
      {
        "id": "search_xyz789",
        "type": "keyword_search",
        "status": "running",
        "progress": 40,
        "currentSource": "Bloomberg",
        "sourcesProcessed": 2,
        "totalSources": 5,
        "keywords": ["gold", "fed"],
        "sources": [1, 2, 3, 4, 5],
        "dateRange": {
          "from": "2026-01-01",
          "to": "2026-01-15"
        },
        "resultsFound": 156,
        "eventsCreated": 12,
        "startedAt": "2026-01-15T14:00:00Z"
      }
    ],
    "total": 89
  }
}
```

#### Start Search Operation

```http
POST /api/trpc/learningControl.search.start
Content-Type: application/json

{
  "type": "keyword_search",
  "keywords": ["gold", "fed", "inflation"],
  "sources": [1, 2, 3],
  "dateRange": {
    "from": "2026-01-01",
    "to": "2026-01-15"
  }
}
```

**Search Types**:
- `keyword_search` - Search by keywords
- `event_discovery` - Discover new events
- `news_scraping` - Scrape news articles
- `sentiment_analysis` - Analyze sentiment
- `entity_extraction` - Extract entities

#### Cancel Search

```http
POST /api/trpc/learningControl.search.cancel
Content-Type: application/json

{
  "id": "search_xyz789"
}
```

---

### Logs

#### List Operation Logs

```http
GET /api/trpc/learningControl.logs.list?input={"operationId":"op_abc123","limit":50}
```

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| operationId | string | No | Filter by operation |
| operationType | string | No | "learning" or "search" |
| level | string | No | "debug", "info", "warning", "error" |
| limit | number | No | Max results (default: 100) |

**Response**:
```json
{
  "result": {
    "data": [
      {
        "id": 1,
        "operationId": "op_abc123",
        "operationType": "learning",
        "level": "info",
        "message": "بدء عملية مقارنة التوقعات",
        "data": null,
        "createdAt": "2026-01-15T14:00:00Z"
      },
      {
        "id": 2,
        "operationId": "op_abc123",
        "operationType": "learning",
        "level": "info",
        "message": "جلب التوقعات السابقة - تم",
        "data": { "count": 156 },
        "createdAt": "2026-01-15T14:00:30Z"
      }
    ],
    "total": 25
  }
}
```

---

## WebSocket API

### Connection

```javascript
const ws = new WebSocket('ws://localhost:3001');
```

### Authentication

```javascript
ws.send(JSON.stringify({
  type: 'auth',
  token: 'your-jwt-token'
}));
```

### Subscribe to Channels

```javascript
// Learning operation updates
ws.send(JSON.stringify({
  type: 'subscribe',
  channel: 'learning:operation:update'
}));

// Search operation updates
ws.send(JSON.stringify({
  type: 'subscribe',
  channel: 'search:operation:update'
}));

// Stats updates
ws.send(JSON.stringify({
  type: 'subscribe',
  channel: 'learning:stats'
}));
```

### Message Format

**Learning Operation Update**:
```json
{
  "channel": "learning:operation:update",
  "type": "progress",
  "data": {
    "id": "op_abc123",
    "status": "running",
    "progress": 80,
    "currentStep": "توليد الرؤى"
  }
}
```

**Search Operation Update**:
```json
{
  "channel": "search:operation:update",
  "type": "progress",
  "data": {
    "id": "search_xyz789",
    "status": "running",
    "progress": 60,
    "currentSource": "Reuters",
    "sourcesProcessed": 3,
    "totalSources": 5
  }
}
```

### Available Channels

| Channel | Description |
|---------|-------------|
| `learning:operation:update` | Learning operation status changes |
| `learning:operation:progress` | Learning operation progress |
| `search:operation:update` | Search operation status changes |
| `search:operation:progress` | Search operation progress |
| `learning:stats` | Dashboard stats updates |
| `keywords:update` | Keywords CRUD events |
| `sources:update` | Sources CRUD events |

---

## Error Handling

### Error Response Format

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Invalid or expired token",
    "details": null
  }
}
```

### Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `UNAUTHORIZED` | 401 | Invalid/missing auth token |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `BAD_REQUEST` | 400 | Invalid request body |
| `VALIDATION_ERROR` | 400 | Input validation failed |
| `CONFLICT` | 409 | Resource conflict |
| `RATE_LIMITED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Server error |

### Validation Error Example

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input",
    "details": [
      {
        "path": ["keyword"],
        "message": "Keyword is required"
      },
      {
        "path": ["priority"],
        "message": "Invalid priority value"
      }
    ]
  }
}
```

---

## Rate Limiting

### Limits

| Endpoint Type | Limit | Window |
|---------------|-------|--------|
| Read (GET) | 100 | 1 minute |
| Write (POST) | 30 | 1 minute |
| Operations Start | 10 | 1 minute |
| WebSocket | 1 connection | per user |

### Rate Limit Headers

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1705329600
```

### Rate Limited Response

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "Too many requests",
    "details": {
      "retryAfter": 45
    }
  }
}
```

---

## TypeScript Types

```typescript
// Keywords
interface Keyword {
  id: number;
  keyword: string;
  category: 'commodity' | 'monetary_policy' | 'economic' | 'geopolitical' | 'market';
  priority: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  searchCount: number;
  lastSearched: string | null;
  totalResults: number;
  createdAt: string;
  updatedAt: string;
}

// Sources
interface Source {
  id: number;
  name: string;
  url: string;
  type: 'news_site' | 'financial_site' | 'api' | 'social';
  priority: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  healthy: boolean;
  lastChecked: string | null;
  avgResponseTime: number | null;
  successRate: number;
  createdAt: string;
}

// Learning Operation
interface LearningOperation {
  id: string;
  type: LearningOperationType;
  status: OperationStatus;
  progress: number;
  currentStep: string | null;
  totalSteps: number | null;
  input: Record<string, unknown>;
  output: Record<string, unknown> | null;
  resultsCount: number;
  insightsGenerated: number;
  adjustmentsProposed: number;
  duration: number | null;
  error: string | null;
  startedAt: string | null;
  completedAt: string | null;
  triggeredBy: string | null;
  createdAt: string;
}

type LearningOperationType = 
  | 'prediction_comparison'
  | 'pattern_detection'
  | 'correlation_analysis'
  | 'model_training'
  | 'insight_generation'
  | 'adjustment_application';

type OperationStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

// Search Operation
interface SearchOperation {
  id: string;
  type: SearchOperationType;
  status: OperationStatus;
  progress: number;
  currentSource: string | null;
  sourcesProcessed: number;
  totalSources: number;
  keywords: string[];
  sources: number[];
  dateRange: { from: string; to: string } | null;
  resultsFound: number;
  eventsCreated: number;
  startedAt: string | null;
  completedAt: string | null;
  createdAt: string;
}

type SearchOperationType = 
  | 'keyword_search'
  | 'event_discovery'
  | 'news_scraping'
  | 'sentiment_analysis'
  | 'entity_extraction';
```

---

## SDK Usage (TypeScript)

```typescript
import { createTRPCClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from './server/routers';

const trpc = createTRPCClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000/api/trpc',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }),
  ],
});

// List keywords
const keywords = await trpc.learningControl.keywords.list.query({
  limit: 10,
  category: 'commodity',
});

// Start learning operation
const operation = await trpc.learningControl.learning.start.mutate({
  type: 'prediction_comparison',
  input: { daysBack: 30 },
});

// Subscribe to WebSocket updates
const ws = new WebSocket('ws://localhost:3001');
ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  if (message.channel === 'learning:operation:update') {
    console.log('Operation update:', message.data);
  }
};
```

---

**End of API Reference**

---

📌 **Note**: This documentation is auto-generated and updated with each release.

**Version**: 4.0 | **Date**: 2026-01-15
