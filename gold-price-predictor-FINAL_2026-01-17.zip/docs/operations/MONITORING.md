# Monitoring Guide
# دليل المراقبة

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Prometheus Metrics

### Application Metrics

```python
# Request metrics
http_requests_total{method="POST", endpoint="/predictions", status="200"}
http_request_duration_seconds{endpoint="/predictions"}

# Prediction metrics
predictions_total{model="ensemble"}
prediction_accuracy{model="lstm"}
prediction_latency_seconds{model="arima"}

# Cache metrics
cache_hits_total
cache_misses_total
cache_hit_rate

# Database metrics
db_query_duration_seconds
db_connections_active
db_connections_idle
```

### System Metrics

```python
# CPU & Memory
process_cpu_percent
process_memory_bytes

# Disk
disk_usage_percent
disk_io_bytes

# Network
network_bytes_sent
network_bytes_received
```

---

## Grafana Dashboards

### 1. System Overview

- Request rate (req/s)
- Response time (p50, p95, p99)
- Error rate (%)
- CPU & Memory usage

### 2. ML Performance

- Prediction accuracy by model
- Prediction latency
- Model usage distribution
- Ensemble performance

### 3. Security Metrics

- Failed login attempts
- Rate limit hits
- 2FA usage rate
- Suspicious activity

---

## Alerts

### Critical Alerts

| Alert | Condition | Action |
|-------|-----------|--------|
| High Error Rate | >5% errors | Page on-call |
| API Down | No requests for 5min | Page on-call |
| Database Down | Connection failed | Page on-call |

### Warning Alerts

| Alert | Condition | Action |
|-------|-----------|--------|
| High Latency | p95 >1s | Slack notification |
| High CPU | >80% for 5min | Slack notification |
| Low Cache Hit | <50% | Slack notification |

---

## Health Checks

```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "checks": {
    "database": "ok",
    "redis": "ok",
    "ml_models": "ok"
  },
  "version": "2.0.0",
  "uptime": 86400
}
```

---

**Document Version:** 1.0
