# Backup & Restore
# النسخ الاحتياطي والاستعادة

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Backup Strategy

### Automated Backups

**Schedule:** Daily at 2:00 AM UTC

```bash
#!/bin/bash
# scripts/backup.sh

DATE=$(date +%Y%m%d-%H%M%S)
BACKUP_FILE="backup-${DATE}.sql.gz"

# Dump database
pg_dump -h localhost -U postgres gold_predictor | gzip > ${BACKUP_FILE}

# Encrypt
openssl enc -aes-256-cbc -in ${BACKUP_FILE} -out ${BACKUP_FILE}.enc

# Upload to S3
aws s3 cp ${BACKUP_FILE}.enc s3://backups/gold-predictor/

# Cleanup local
rm ${BACKUP_FILE} ${BACKUP_FILE}.enc
```

### Backup Types

| Type | Frequency | Retention |
|------|-----------|-----------|
| Full | Daily | 30 days |
| Incremental | Every 6 hours | 7 days |
| ML Models | Weekly | 90 days |

---

## Restore Procedure

### 1. Download Backup

```bash
aws s3 cp s3://backups/gold-predictor/backup-20251028.sql.gz.enc .
```

### 2. Decrypt

```bash
openssl enc -d -aes-256-cbc -in backup-20251028.sql.gz.enc -out backup-20251028.sql.gz
```

### 3. Decompress

```bash
gunzip backup-20251028.sql.gz
```

### 4. Restore

```bash
psql -h localhost -U postgres gold_predictor < backup-20251028.sql
```

### 5. Verify

```bash
psql -h localhost -U postgres gold_predictor -c "SELECT COUNT(*) FROM users;"
```

---

## Disaster Recovery

**RTO (Recovery Time Objective):** 4 hours  
**RPO (Recovery Point Objective):** 6 hours

### Recovery Steps

1. Provision new infrastructure
2. Restore latest backup
3. Update DNS records
4. Verify functionality
5. Monitor closely

---

**Document Version:** 1.0
