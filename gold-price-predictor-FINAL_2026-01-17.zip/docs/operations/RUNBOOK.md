# Operations Runbook

## System Startup

```bash
# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

## System Shutdown

```bash
# Stop all services
docker-compose down

# Stop and remove volumes
docker-compose down -v
```

## Common Operations

### Database Backup
```bash
./scripts/backup.sh
```

### Database Restore
```bash
./scripts/restore.sh <backup_file>
```

### View Logs
```bash
docker-compose logs -f backend
```

**Version:** 1.0
