# Troubleshooting Guide
# دليل حل المشاكل

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Common Issues

### Issue: API Returns 500 Error

**Symptoms:**
- HTTP 500 responses
- Error in logs: "Database connection failed"

**Solution:**
```bash
# Check database status
docker-compose ps postgres

# Restart database
docker-compose restart postgres

# Check logs
docker-compose logs -f postgres
```

### Issue: Slow Predictions

**Symptoms:**
- Prediction latency >10s
- High CPU usage

**Solution:**
```bash
# Check model cache
redis-cli INFO

# Clear cache if needed
redis-cli FLUSHDB

# Restart ML service
docker-compose restart backend
```

### Issue: Authentication Fails

**Symptoms:**
- Login returns 401
- "Invalid token" error

**Solution:**
```bash
# Check JWT secret
echo $JWT_SECRET_KEY

# Clear JWT blacklist
redis-cli DEL jwt:blacklist:*

# Restart backend
docker-compose restart backend
```

---

## Debugging Commands

```bash
# View logs
docker-compose logs -f backend

# Check database connections
psql -h localhost -U postgres -c "SELECT * FROM pg_stat_activity;"

# Check Redis
redis-cli PING

# Test API
curl -X GET http://localhost:8000/health
```

---

**Document Version:** 1.0
