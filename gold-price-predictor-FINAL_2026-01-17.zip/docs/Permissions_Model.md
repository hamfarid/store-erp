# Permissions Model - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/Permissions_Model.md | **PURPOSE**: Role-based access control (RBAC) permission matrix | **OWNER**: Security Team | **RELATED**: Security.md, API_Contracts.md, auth_postgresql.py | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Authorization Model**: Role-Based Access Control (RBAC)

---

## Table of Contents
1. [Overview](#1-overview)
2. [Role Hierarchy](#2-role-hierarchy)
3. [Permission Matrix](#3-permission-matrix)
4. [Resource Permissions](#4-resource-permissions)
5. [Implementation](#5-implementation)
6. [Frontend Route Guards](#6-frontend-route-guards)
7. [Backend Decorators](#7-backend-decorators)
8. [Examples](#8-examples)

---

## 1. Overview

### 1.1 RBAC Principles

**Authorization Model**: Role-Based Access Control (RBAC) with hierarchical inheritance

**Key Concepts**:
- **Role**: Collection of permissions assigned to users
- **Permission**: Authorization to perform action on resource
- **Resource**: Protected entity (predictions, alerts, users, settings)
- **Action**: Operation (create, read, update, delete, export)

**Design Goals**:
- ✅ Least privilege principle
- ✅ Role inheritance (ADMIN inherits MANAGER, MANAGER inherits USER)
- ✅ Fine-grained permissions
- ✅ Consistent enforcement (frontend + backend)

### 1.2 System Roles

| Role | Count | Description | Permissions |
|------|-------|-------------|-------------|
| **ADMIN** | ~2 | System administrator | All permissions (100%) |
| **MANAGER** | ~10 | Team lead, supervisor | 80% of permissions |
| **USER** | ~1000 | Regular user | 50% of permissions |
| **GUEST** | Unlimited | Read-only access | 10% of permissions |

---

## 2. Role Hierarchy

### 2.1 Hierarchy Diagram

```
┌─────────────┐
│    ADMIN    │  (100% permissions)
│  SuperUser  │
└──────┬──────┘
       │ inherits
┌──────▼──────┐
│   MANAGER   │  (80% permissions)
│  Team Lead  │
└──────┬──────┘
       │ inherits
┌──────▼──────┐
│     USER    │  (50% permissions)
│   Regular   │
└──────┬──────┘
       │ inherits
┌──────▼──────┐
│    GUEST    │  (10% permissions)
│  Read-Only  │
└─────────────┘
```

### 2.2 Role Inheritance

**Inheritance Rules**:
- **ADMIN** has all MANAGER permissions + admin-specific permissions
- **MANAGER** has all USER permissions + manager-specific permissions
- **USER** has all GUEST permissions + user-specific permissions
- **GUEST** has minimal read-only permissions

**Example**:
```python
# If ADMIN is granted "predictions.create", it also has:
# - predictions.read (from MANAGER)
# - predictions.view (from USER)
# - predictions.list (from GUEST)
```

---

## 3. Permission Matrix

### 3.1 Complete Permission Matrix

| Resource | GUEST | USER | MANAGER | ADMIN |
|----------|:-----:|:----:|:-------:|:-----:|
| **Predictions** | | | | |
| predictions.list | ✅ | ✅ | ✅ | ✅ |
| predictions.view | ❌ | ✅ | ✅ | ✅ |
| predictions.create | ❌ | ✅ | ✅ | ✅ |
| predictions.delete | ❌ | Own only | ✅ | ✅ |
| predictions.export | ❌ | ❌ | ✅ | ✅ |
| **Alerts** | | | | |
| alerts.list | ❌ | ✅ | ✅ | ✅ |
| alerts.view | ❌ | ✅ | ✅ | ✅ |
| alerts.create | ❌ | ✅ | ✅ | ✅ |
| alerts.update | ❌ | Own only | ✅ | ✅ |
| alerts.delete | ❌ | Own only | ✅ | ✅ |
| **Assets** | | | | |
| assets.list | ✅ | ✅ | ✅ | ✅ |
| assets.view | ✅ | ✅ | ✅ | ✅ |
| assets.create | ❌ | ❌ | ❌ | ✅ |
| assets.update | ❌ | ❌ | ❌ | ✅ |
| assets.delete | ❌ | ❌ | ❌ | ✅ |
| **Users** | | | | |
| users.list | ❌ | ❌ | ✅ | ✅ |
| users.view | ❌ | Own only | ✅ | ✅ |
| users.create | ❌ | ❌ | ❌ | ✅ |
| users.update | ❌ | Own only | ✅ | ✅ |
| users.delete | ❌ | ❌ | ❌ | ✅ |
| users.assign_role | ❌ | ❌ | ❌ | ✅ |
| **API Keys** | | | | |
| api_keys.list | ❌ | Own only | ✅ | ✅ |
| api_keys.create | ❌ | ✅ | ✅ | ✅ |
| api_keys.revoke | ❌ | Own only | ✅ | ✅ |
| api_keys.rotate | ❌ | Own only | ✅ | ✅ |
| **Settings** | | | | |
| settings.view | ❌ | Own only | ✅ | ✅ |
| settings.update | ❌ | Own only | ✅ | ✅ |
| settings.system | ❌ | ❌ | ❌ | ✅ |
| **Logs** | | | | |
| logs.view | ❌ | Own only | ✅ | ✅ |
| logs.export | ❌ | ❌ | ✅ | ✅ |
| logs.audit | ❌ | ❌ | ❌ | ✅ |
| **Exports** | | | | |
| exports.predictions | ❌ | ❌ | ✅ | ✅ |
| exports.alerts | ❌ | ❌ | ✅ | ✅ |
| exports.users | ❌ | ❌ | ❌ | ✅ |
| **System** | | | | |
| system.health | ✅ | ✅ | ✅ | ✅ |
| system.metrics | ❌ | ❌ | ✅ | ✅ |
| system.backup | ❌ | ❌ | ❌ | ✅ |
| system.restore | ❌ | ❌ | ❌ | ✅ |

### 3.2 Permission Counts by Role

| Role | Total Permissions | Read | Write | Delete | Export |
|------|-------------------|------|-------|--------|--------|
| **ADMIN** | 42 (100%) | 21 | 15 | 6 | 4 |
| **MANAGER** | 33 (79%) | 20 | 10 | 3 | 4 |
| **USER** | 21 (50%) | 15 | 6 | 2 (own only) | 0 |
| **GUEST** | 4 (10%) | 4 | 0 | 0 | 0 |

---

## 4. Resource Permissions

### 4.1 Predictions

**Resource**: `predictions`

**Actions**:
- `list`: View list of predictions (all users)
- `view`: View prediction details (requires authentication)
- `create`: Create new prediction (authenticated users)
- `delete`: Delete prediction (owner or MANAGER+)
- `export`: Export predictions to CSV/JSON (MANAGER+)

**Ownership Rules**:
- Users can only delete their own predictions (unless MANAGER+)
- MANAGER can delete any user's predictions
- ADMIN can delete any predictions

**Example**:
```python
# USER can delete own prediction
if prediction.user_id == current_user.id or current_user.role in ['MANAGER', 'ADMIN']:
    prediction.delete()
```

### 4.2 Alerts

**Resource**: `alerts`

**Actions**:
- `list`: View list of alerts (USER+)
- `view`: View alert details (USER+)
- `create`: Create new alert (USER+)
- `update`: Modify alert (owner or MANAGER+)
- `delete`: Delete alert (owner or MANAGER+)

**Ownership Rules**:
- Users can only manage their own alerts (unless MANAGER+)
- MANAGER can manage any user's alerts

### 4.3 Assets

**Resource**: `assets`

**Actions**:
- `list`: View list of assets (PUBLIC)
- `view`: View asset details (PUBLIC)
- `create`: Add new asset (ADMIN only)
- `update`: Modify asset (ADMIN only)
- `delete`: Remove asset (ADMIN only)

**Rationale**: Assets are system-level configuration, only admins can modify

### 4.4 Users

**Resource**: `users`

**Actions**:
- `list`: View list of users (MANAGER+)
- `view`: View user details (own profile or MANAGER+)
- `create`: Register new user (ADMIN only)
- `update`: Modify user profile (own profile or MANAGER+)
- `delete`: Delete user (ADMIN only)
- `assign_role`: Change user role (ADMIN only)

**Security Notes**:
- Password changes require current password (even for ADMIN)
- Email changes require verification
- Role changes are audit logged

### 4.5 API Keys

**Resource**: `api_keys`

**Actions**:
- `list`: View API keys (own keys or MANAGER+)
- `create`: Generate new API key (USER+)
- `revoke`: Disable API key (owner or MANAGER+)
- `rotate`: Regenerate API key secret (owner or MANAGER+)

**Security Notes**:
- API key secrets shown only once at creation
- Rotation invalidates old key immediately
- Revoked keys cannot be re-enabled

---

## 5. Implementation

### 5.1 Database Schema

**Users Table** (PostgreSQL):
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN', 'MANAGER', 'USER', 'GUEST')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_email ON users(email);
```

**Permissions Check Function**:
```python
# backend/app/auth_postgresql.py
from enum import Enum
from typing import Optional

class Role(str, Enum):
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    USER = "USER"
    GUEST = "GUEST"

class Permission:
    """Permission checker with role hierarchy"""
    
    # Role hierarchy (higher roles inherit lower role permissions)
    ROLE_HIERARCHY = {
        Role.ADMIN: [Role.MANAGER, Role.USER, Role.GUEST],
        Role.MANAGER: [Role.USER, Role.GUEST],
        Role.USER: [Role.GUEST],
        Role.GUEST: []
    }
    
    # Permission matrix
    PERMISSIONS = {
        "predictions.list": [Role.GUEST, Role.USER, Role.MANAGER, Role.ADMIN],
        "predictions.view": [Role.USER, Role.MANAGER, Role.ADMIN],
        "predictions.create": [Role.USER, Role.MANAGER, Role.ADMIN],
        "predictions.delete": [Role.MANAGER, Role.ADMIN],  # + ownership
        "predictions.export": [Role.MANAGER, Role.ADMIN],
        
        "assets.create": [Role.ADMIN],
        "assets.update": [Role.ADMIN],
        "assets.delete": [Role.ADMIN],
        
        "users.list": [Role.MANAGER, Role.ADMIN],
        "users.create": [Role.ADMIN],
        "users.assign_role": [Role.ADMIN],
        
        # ... (full matrix)
    }
    
    @classmethod
    def has_permission(cls, user_role: Role, permission: str, 
                      resource_owner_id: Optional[str] = None, 
                      user_id: Optional[str] = None) -> bool:
        """Check if user role has permission
        
        Args:
            user_role: User's role
            permission: Permission to check (e.g., "predictions.delete")
            resource_owner_id: ID of resource owner (for ownership checks)
            user_id: Current user ID
        
        Returns:
            True if user has permission, False otherwise
        """
        # Check ownership for "own only" permissions
        if resource_owner_id and user_id:
            if resource_owner_id == user_id:
                # User owns resource, check if USER+ can access
                if permission in ["predictions.delete", "alerts.update"]:
                    return user_role in [Role.USER, Role.MANAGER, Role.ADMIN]
        
        # Check role-based permission
        allowed_roles = cls.PERMISSIONS.get(permission, [])
        
        # Check if user role or any inherited role has permission
        if user_role in allowed_roles:
            return True
        
        # Check inherited permissions
        inherited_roles = cls.ROLE_HIERARCHY.get(user_role, [])
        return any(role in allowed_roles for role in inherited_roles)
    
    @classmethod
    def get_user_permissions(cls, user_role: Role) -> list[str]:
        """Get all permissions for a role"""
        permissions = []
        for permission, allowed_roles in cls.PERMISSIONS.items():
            if cls.has_permission(user_role, permission):
                permissions.append(permission)
        return permissions
```

---

## 6. Frontend Route Guards

### 6.1 React Router Protection

**File**: `client/src/components/ProtectedRoute.tsx`

```typescript
import { Navigate } from 'wouter';
import { useSelector } from 'react-redux';
import { RootState } from '@/store';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: 'ADMIN' | 'MANAGER' | 'USER' | 'GUEST';
  requiredPermission?: string;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRole,
  requiredPermission
}) => {
  const { isAuthenticated, user } = useSelector((state: RootState) => state.auth);
  
  // Not authenticated -> redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  // Check role requirement
  if (requiredRole) {
    const roleHierarchy = {
      ADMIN: ['ADMIN'],
      MANAGER: ['ADMIN', 'MANAGER'],
      USER: ['ADMIN', 'MANAGER', 'USER'],
      GUEST: ['ADMIN', 'MANAGER', 'USER', 'GUEST']
    };
    
    if (!roleHierarchy[requiredRole].includes(user.role)) {
      return <Navigate to="/unauthorized" />;
    }
  }
  
  // Check permission requirement
  if (requiredPermission && !user.permissions.includes(requiredPermission)) {
    return <Navigate to="/unauthorized" />;
  }
  
  return <>{children}</>;
};
```

**Usage**:
```typescript
// client/src/App.tsx
import { Route } from 'wouter';
import { ProtectedRoute } from '@/components/ProtectedRoute';

<Route path="/admin/*">
  <ProtectedRoute requiredRole="ADMIN">
    <AdminDashboard />
  </ProtectedRoute>
</Route>

<Route path="/exports">
  <ProtectedRoute requiredPermission="exports.predictions">
    <ExportsPage />
  </ProtectedRoute>
</Route>
```

### 6.2 Component-Level Permission Checks

**File**: `client/src/hooks/usePermission.ts`

```typescript
import { useSelector } from 'react-redux';
import { RootState } from '@/store';

export const usePermission = () => {
  const { user } = useSelector((state: RootState) => state.auth);
  
  const hasPermission = (permission: string): boolean => {
    return user?.permissions?.includes(permission) || false;
  };
  
  const hasRole = (role: string): boolean => {
    const roleHierarchy = {
      ADMIN: ['ADMIN'],
      MANAGER: ['ADMIN', 'MANAGER'],
      USER: ['ADMIN', 'MANAGER', 'USER'],
      GUEST: ['ADMIN', 'MANAGER', 'USER', 'GUEST']
    };
    
    return roleHierarchy[role as keyof typeof roleHierarchy]?.includes(user?.role) || false;
  };
  
  return { hasPermission, hasRole };
};
```

**Usage**:
```typescript
// client/src/components/Dashboard.tsx
import { usePermission } from '@/hooks/usePermission';

export const Dashboard: React.FC = () => {
  const { hasPermission } = usePermission();
  
  return (
    <div>
      {hasPermission('predictions.create') && (
        <button onClick={handleCreatePrediction}>Create Prediction</button>
      )}
      
      {hasPermission('exports.predictions') && (
        <button onClick={handleExport}>Export Data</button>
      )}
    </div>
  );
};
```

---

## 7. Backend Decorators

### 7.1 FastAPI Permission Decorator

**File**: `backend/app/dependencies.py`

```python
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.auth_postgresql import decode_jwt, Permission, Role
from typing import Optional

security = HTTPBearer()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current authenticated user from JWT token"""
    token = credentials.credentials
    payload = decode_jwt(token)
    
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )
    
    # Fetch user from database
    user = await get_user_by_id(payload["user_id"])
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    return user

def require_permission(permission: str, check_ownership: bool = False):
    """Decorator to require specific permission"""
    async def permission_checker(
        current_user = Depends(get_current_user),
        resource_owner_id: Optional[str] = None
    ):
        has_perm = Permission.has_permission(
            user_role=current_user.role,
            permission=permission,
            resource_owner_id=resource_owner_id if check_ownership else None,
            user_id=current_user.id if check_ownership else None
        )
        
        if not has_perm:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions: {permission} required"
            )
        
        return current_user
    
    return permission_checker

def require_role(min_role: Role):
    """Decorator to require minimum role"""
    async def role_checker(current_user = Depends(get_current_user)):
        role_hierarchy = [Role.GUEST, Role.USER, Role.MANAGER, Role.ADMIN]
        
        if role_hierarchy.index(current_user.role) < role_hierarchy.index(min_role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient role: {min_role} required"
            )
        
        return current_user
    
    return role_checker
```

### 7.2 Endpoint Protection Examples

**File**: `backend/app/main.py`

```python
from fastapi import APIRouter, Depends
from app.dependencies import require_permission, require_role, get_current_user

router = APIRouter()

@router.get("/api/predictions")
async def list_predictions(
    current_user = Depends(require_permission("predictions.list"))
):
    """List predictions - GUEST+ can access"""
    return {"predictions": get_all_predictions()}

@router.post("/api/predict")
async def create_prediction(
    data: PredictionRequest,
    current_user = Depends(require_permission("predictions.create"))
):
    """Create prediction - USER+ can access"""
    return {"prediction": create_new_prediction(data, current_user.id)}

@router.delete("/api/predictions/{prediction_id}")
async def delete_prediction(
    prediction_id: str,
    current_user = Depends(get_current_user)
):
    """Delete prediction - owner or MANAGER+"""
    prediction = get_prediction_by_id(prediction_id)
    
    # Check ownership or MANAGER+ role
    has_perm = Permission.has_permission(
        user_role=current_user.role,
        permission="predictions.delete",
        resource_owner_id=prediction.user_id,
        user_id=current_user.id
    )
    
    if not has_perm:
        raise HTTPException(status_code=403, detail="Cannot delete this prediction")
    
    prediction.delete()
    return {"message": "Prediction deleted"}

@router.post("/api/assets")
async def create_asset(
    data: AssetRequest,
    current_user = Depends(require_role(Role.ADMIN))
):
    """Create asset - ADMIN only"""
    return {"asset": create_new_asset(data)}
```

---

## 8. Examples

### 8.1 Example: User Views Own Prediction

**Scenario**: USER with id `user-123` views prediction created by `user-123`

**Check**:
```python
Permission.has_permission(
    user_role=Role.USER,
    permission="predictions.view",
    resource_owner_id="user-123",
    user_id="user-123"
)
# Returns: True (USER can view predictions)
```

### 8.2 Example: User Tries to Delete Another User's Prediction

**Scenario**: USER with id `user-123` tries to delete prediction owned by `user-456`

**Check**:
```python
Permission.has_permission(
    user_role=Role.USER,
    permission="predictions.delete",
    resource_owner_id="user-456",
    user_id="user-123"
)
# Returns: False (USER can only delete own predictions)
```

### 8.3 Example: Manager Deletes Any User's Prediction

**Scenario**: MANAGER tries to delete prediction owned by any user

**Check**:
```python
Permission.has_permission(
    user_role=Role.MANAGER,
    permission="predictions.delete",
    resource_owner_id="user-456",
    user_id="manager-789"
)
# Returns: True (MANAGER can delete any predictions)
```

### 8.4 Example: Guest Tries to Create Prediction

**Scenario**: GUEST tries to create prediction

**Check**:
```python
Permission.has_permission(
    user_role=Role.GUEST,
    permission="predictions.create"
)
# Returns: False (GUEST is read-only)
```

---

**Last Updated**: 2025-11-17  
**Next Review**: 2026-02-17  
**Version**: 3.0.0  
**Owner**: Security Team
