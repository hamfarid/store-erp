# Environment Configuration Guide

## Required Environment Variables

Create a `.env` file in the project root with these values:

```env
# ===== REQUIRED =====

# Application
NODE_ENV=development
PORT=2505

# Database (SQLite for development)
DATABASE_URL=file:./data/asset_predictor.db

# Authentication (minimum 32 characters)
JWT_SECRET=your-super-secret-key-at-least-32-characters-long
```

## Optional Environment Variables

```env
# ===== OPTIONAL - External APIs =====

# News API (https://newsapi.org)
NEWS_API_KEY=

# Alpha Vantage (https://www.alphavantage.co)
ALPHA_VANTAGE_API_KEY=

# ===== OPTIONAL - AI Services =====

# OpenAI
OPENAI_API_KEY=

# Anthropic
ANTHROPIC_API_KEY=

# Google Gemini
GEMINI_API_KEY=

# ===== OPTIONAL - Email (for notifications) =====

SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=

# ===== OPTIONAL - Telegram Bot =====

TELEGRAM_BOT_TOKEN=

# ===== OPTIONAL - AWS (for backups) =====

AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=us-east-1
AWS_S3_BUCKET=

# ===== OPTIONAL - Google Services =====

GOOGLE_SEARCH_API_KEY=
GOOGLE_SEARCH_ENGINE_ID=
GOOGLE_DRIVE_CREDENTIALS=

# ===== OPTIONAL - ML Service =====

ML_SERVICE_URL=http://localhost:5000
ML_API_URL=http://localhost:8001

# ===== OPTIONAL - Redis =====

REDIS_URL=redis://localhost:6379

# ===== OPTIONAL - Monitoring =====

SENTRY_DSN=
LOG_LEVEL=info

# ===== FEATURE FLAGS =====

ENABLE_WEB_SCRAPING=false
ENABLE_DRIFT_DETECTION=true
ENABLE_LEARNING_PATH=true
ENABLE_SOCIAL_SENTIMENT=false
ENABLE_SWAGGER=true

# ===== CORS =====

ALLOWED_ORIGINS=http://localhost:2505,http://localhost:3000

# ===== RATE LIMITING =====

RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

## Environment Validation

The system validates environment variables on startup:

### Production Mode
- `DATABASE_URL` - Required
- `JWT_SECRET` - Required (minimum 32 characters)

### Development Mode
- Uses defaults if not set:
  - `JWT_SECRET`: Auto-generated development key
  - `DATABASE_URL`: SQLite file database

## Vault Configuration (Production)

For production, use dotenv-vault:

1. Install: `npx dotenv-vault@latest new`
2. Push: `npx dotenv-vault@latest push`
3. Build: `npx dotenv-vault@latest build`
4. Set `DOTENV_KEY` in production environment

## Quick Start

```bash
# 1. Copy example config
cp .env.example .env

# 2. Edit .env with your values
nano .env

# 3. Start development server
npm run dev
```

---

*Last Updated: December 2, 2025*

