# API Endpoints Reference

## Authentication
- POST `/api/v1/auth/register` - Register new user
- POST `/api/v1/auth/login` - Login with credentials  
- POST `/api/v1/auth/logout` - Logout current session
- POST `/api/v1/auth/refresh` - Refresh JWT token
- POST `/api/v1/auth/2fa/setup` - Setup 2FA
- POST `/api/v1/auth/2fa/verify` - Verify 2FA code

## Predictions
- POST `/api/v1/predictions` - Create new prediction
- GET `/api/v1/predictions/{id}` - Get prediction by ID
- GET `/api/v1/predictions` - List user predictions
- DELETE `/api/v1/predictions/{id}` - Delete prediction

## Admin
- GET `/api/v1/admin/users` - List all users
- GET `/api/v1/admin/stats` - System statistics
- POST `/api/v1/admin/backup` - Trigger backup

**Version:** 1.0
