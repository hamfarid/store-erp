# API Request & Response Format
# تنسيق الطلبات والاستجابات

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Request Format

### Headers

```http
Content-Type: application/json
Authorization: Bearer <access_token>
X-Request-ID: <uuid>
```

### Body

```json
{
  "timeframe": "7d",
  "model_type": "ensemble"
}
```

---

## Response Format

### Success Response

```json
{
  "status": "success",
  "data": {
    "prediction": {
      "price": 1875.30,
      "confidence": 0.99,
      "trend": "up"
    }
  },
  "meta": {
    "request_id": "uuid",
    "timestamp": "2025-10-28T10:00:00Z"
  }
}
```

### Error Response

```json
{
  "status": "error",
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid timeframe",
    "details": {
      "field": "timeframe",
      "allowed_values": ["1d", "7d", "30d", "90d"]
    }
  },
  "meta": {
    "request_id": "uuid",
    "timestamp": "2025-10-28T10:00:00Z"
  }
}
```

---

## HTTP Status Codes

| Code | Meaning | Usage |
|------|---------|-------|
| 200 | OK | Successful request |
| 201 | Created | Resource created |
| 400 | Bad Request | Invalid input |
| 401 | Unauthorized | Missing/invalid token |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource not found |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server error |

---

**Document Version:** 1.0
