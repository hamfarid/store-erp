# Testing Guide
# دليل الاختبار

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Test Structure

```
tests/
├── unit/           # Unit tests
├── integration/    # Integration tests
├── e2e/           # End-to-end tests
└── load/          # Load tests
```

---

## Running Tests

### All Tests

```bash
pytest tests/ -v
```

### Unit Tests Only

```bash
pytest tests/unit/ -v
```

### With Coverage

```bash
pytest tests/ -v --cov=backend --cov-report=html
```

### Specific Test

```bash
pytest tests/unit/test_auth.py::test_login -v
```

---

## Test Examples

### Unit Test

```python
def test_jwt_token_generation():
    """Test JWT token generation"""
    user_id = "test-user-123"
    token = generate_jwt_token(user_id)
    
    assert token is not None
    assert isinstance(token, str)
    
    # Verify token
    payload = decode_jwt_token(token)
    assert payload["user_id"] == user_id
```

### Integration Test

```python
def test_prediction_endpoint(client):
    """Test prediction API endpoint"""
    # Login first
    response = client.post("/api/v1/auth/login", json={
        "email": "test@example.com",
        "password": "TestPass123!"
    })
    token = response.json()["access_token"]
    
    # Make prediction
    response = client.post(
        "/api/v1/predictions",
        headers={"Authorization": f"Bearer {token}"},
        json={"timeframe": "7d", "model_type": "ensemble"}
    )
    
    assert response.status_code == 200
    assert "prediction" in response.json()["data"]
```

---

## Coverage Goals

| Component | Current | Target |
|-----------|---------|--------|
| Overall | 85% | 90% |
| Backend API | 90% | 95% |
| ML Models | 80% | 85% |
| Services | 85% | 90% |

---

**Document Version:** 1.0
