# Code Style Guide
# دليل أسلوب الكود

**Version:** 1.0  
**Last Updated:** 2025-10-28

---

## Python Style

### PEP 8 Compliance

```python
# Good
def calculate_prediction(data: List[float]) -> float:
    """Calculate prediction from data."""
    return sum(data) / len(data)

# Bad
def calc(d):
    return sum(d)/len(d)
```

### Type Hints

```python
from typing import List, Dict, Optional

def process_data(
    data: List[Dict[str, float]],
    threshold: float = 0.5
) -> Optional[Dict[str, float]]:
    """Process data with threshold."""
    pass
```

### Docstrings

```python
def predict_price(timeframe: str) -> float:
    """
    Predict gold price for given timeframe.
    
    Args:
        timeframe: Time period (1d, 7d, 30d, 90d)
        
    Returns:
        Predicted price in USD
        
    Raises:
        ValueError: If timeframe is invalid
    """
    pass
```

---

## Naming Conventions

- **Variables:** snake_case
- **Functions:** snake_case
- **Classes:** PascalCase
- **Constants:** UPPER_SNAKE_CASE

---

**Document Version:** 1.0
