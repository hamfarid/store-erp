# Staging Deployment Guide

**Purpose:** Deploy Gold Price Predictor to staging environment for testing before production  
**Date:** 2025-01-18  
**Owner:** DevOps Team

---

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Environment Configuration](#environment-configuration)
4. [Database Setup](#database-setup)
5. [Application Deployment](#application-deployment)
6. [Verification](#verification)
7. [Troubleshooting](#troubleshooting)

---

## Overview

The staging environment mirrors production and is used for:
- Final testing before production deployment
- User acceptance testing (UAT)
- Performance testing with realistic data
- Security audits
- Integration testing with external services

**Staging URL:** https://staging.goldpredictor.com  
**Database:** PostgreSQL (separate from production)  
**Cache:** Redis (separate from production)

---

## Prerequisites

### Required Tools
- Docker & Docker Compose
- AWS CLI (for secrets management)
- kubectl (for Kubernetes deployment)
- PostgreSQL client
- Git

### Required Access
- AWS account with appropriate permissions
- Staging server SSH access
- Database credentials
- Docker registry access

---

## Environment Configuration

### 1. Create Staging Environment File

Create `.env.staging` in the project root:

```bash
# Application
NODE_ENV=staging
VITE_API_URL=https://staging-api.goldpredictor.com

# Database
DATABASE_URL=postgresql://staging_user:STAGING_PASSWORD@staging-db.example.com:5432/gold_predictor_staging
DB_HOST=staging-db.example.com
DB_PORT=5432
DB_NAME=gold_predictor_staging
DB_USER=staging_user
DB_PASSWORD=STAGING_PASSWORD

# Redis
REDIS_URL=redis://staging-redis.example.com:6379
REDIS_HOST=staging-redis.example.com
REDIS_PORT=6379

# JWT
JWT_SECRET_KEY=STAGING_JWT_SECRET_KEY_CHANGE_ME
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=15
JWT_REFRESH_TOKEN_EXPIRE_DAYS=7

# CSRF
CSRF_SECRET_KEY=STAGING_CSRF_SECRET_KEY_CHANGE_ME

# AWS Secrets Manager
AWS_REGION=us-east-1
AWS_SECRETS_MANAGER_SECRET_NAME=gold-predictor-staging

# Email (for alerts)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=staging@goldpredictor.com
SMTP_PASSWORD=STAGING_EMAIL_PASSWORD
SMTP_FROM=staging@goldpredictor.com

# External APIs
ALPHA_VANTAGE_API_KEY=STAGING_ALPHA_VANTAGE_KEY
OPENAI_API_KEY=STAGING_OPENAI_KEY

# Monitoring
SENTRY_DSN=https://STAGING_SENTRY_DSN@sentry.io/PROJECT_ID
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true

# Feature Flags
ENABLE_2FA=true
ENABLE_EMAIL_NOTIFICATIONS=true
ENABLE_SMS_NOTIFICATIONS=false
```

### 2. Store Secrets in AWS Secrets Manager

```bash
# Create staging secrets
aws secretsmanager create-secret \
  --name gold-predictor-staging \
  --description "Staging environment secrets" \
  --secret-string file://staging-secrets.json \
  --region us-east-1

# staging-secrets.json content:
{
  "DATABASE_PASSWORD": "STAGING_DB_PASSWORD",
  "JWT_SECRET_KEY": "STAGING_JWT_SECRET",
  "CSRF_SECRET_KEY": "STAGING_CSRF_SECRET",
  "SMTP_PASSWORD": "STAGING_EMAIL_PASSWORD",
  "ALPHA_VANTAGE_API_KEY": "STAGING_API_KEY",
  "OPENAI_API_KEY": "STAGING_OPENAI_KEY"
}
```

---

## Database Setup

### 1. Create Staging Database

```bash
# Connect to PostgreSQL server
psql -h staging-db.example.com -U postgres

# Create database and user
CREATE DATABASE gold_predictor_staging;
CREATE USER staging_user WITH ENCRYPTED PASSWORD 'STAGING_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE gold_predictor_staging TO staging_user;
```

### 2. Run Migrations

```bash
# Navigate to backend directory
cd backend

# Run Alembic migrations
alembic upgrade head

# Verify migrations
alembic current
```

### 3. Seed Staging Data

```bash
# Run seed script with staging data
python scripts/seed_staging_data.py

# This will create:
# - Admin user (admin@staging.com / Admin@123)
# - 10 test users
# - 20 assets (Gold, Silver, Bitcoin, etc.)
# - 50 sample predictions
# - 30 sample alerts
```

---

## Application Deployment

### Option 1: Docker Compose (Recommended for Staging)

```bash
# Build images
docker-compose -f docker-compose.staging.yml build

# Start services
docker-compose -f docker-compose.staging.yml up -d

# View logs
docker-compose -f docker-compose.staging.yml logs -f

# Check status
docker-compose -f docker-compose.staging.yml ps
```

### Option 2: Kubernetes

```bash
# Apply staging namespace
kubectl apply -f k8s/staging/namespace.yaml

# Apply ConfigMaps and Secrets
kubectl apply -f k8s/staging/configmap.yaml
kubectl apply -f k8s/staging/secrets.yaml

# Deploy application
kubectl apply -f k8s/staging/deployment.yaml
kubectl apply -f k8s/staging/service.yaml
kubectl apply -f k8s/staging/ingress.yaml

# Check deployment status
kubectl get pods -n staging
kubectl get services -n staging
kubectl get ingress -n staging
```

---

## Verification

### 1. Health Checks

```bash
# Backend health check
curl https://staging-api.goldpredictor.com/health

# Expected response:
{
  "status": "healthy",
  "database": "connected",
  "redis": "connected",
  "timestamp": "2025-01-18T00:00:00Z"
}

# Frontend health check
curl https://staging.goldpredictor.com

# Should return 200 OK
```

### 2. Smoke Tests

```bash
# Run smoke tests
npm run test:smoke:staging

# This will test:
# - Login functionality
# - CRUD operations
# - API endpoints
# - Database connectivity
# - Cache functionality
```

### 3. Manual Verification

1. **Login:** https://staging.goldpredictor.com/login
   - Username: `admin@staging.com`
   - Password: `Admin@123`

2. **Test CRUD Operations:**
   - Create a new user
   - Create a new asset
   - Create a prediction
   - Create an alert

3. **Test Security:**
   - Verify CSRF protection
   - Verify JWT token rotation
   - Test account lockout (5 failed attempts)

---

## Troubleshooting

### Database Connection Issues

```bash
# Check database connectivity
psql -h staging-db.example.com -U staging_user -d gold_predictor_staging

# Check database logs
docker logs gold-predictor-staging-db

# Verify migrations
alembic current
alembic history
```

### Application Not Starting

```bash
# Check logs
docker-compose -f docker-compose.staging.yml logs backend
docker-compose -f docker-compose.staging.yml logs frontend

# Check environment variables
docker-compose -f docker-compose.staging.yml exec backend env

# Restart services
docker-compose -f docker-compose.staging.yml restart
```

### Performance Issues

```bash
# Check resource usage
docker stats

# Check database performance
psql -h staging-db.example.com -U staging_user -d gold_predictor_staging
SELECT * FROM pg_stat_activity;

# Check slow queries
SELECT query, mean_exec_time FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;
```

---

## Rollback Procedure

If issues are found in staging:

```bash
# Stop services
docker-compose -f docker-compose.staging.yml down

# Rollback database migrations
alembic downgrade -1

# Restore from backup
pg_restore -h staging-db.example.com -U staging_user -d gold_predictor_staging backup.sql

# Deploy previous version
git checkout <previous-tag>
docker-compose -f docker-compose.staging.yml up -d
```

---

## Next Steps

After successful staging deployment:

1. ✅ Run load testing (see LOAD_TESTING_GUIDE.md)
2. ✅ Run security audit (see SECURITY_AUDIT_GUIDE.md)
3. ✅ Conduct UAT (see UAT_GUIDE.md)
4. ✅ Deploy to production (see PRODUCTION_DEPLOYMENT_GUIDE.md)

---

**Deployment Checklist:**

- [ ] Environment variables configured
- [ ] Secrets stored in AWS Secrets Manager
- [ ] Database created and migrated
- [ ] Staging data seeded
- [ ] Application deployed
- [ ] Health checks passing
- [ ] Smoke tests passing
- [ ] Manual verification complete
- [ ] Monitoring configured
- [ ] Logs accessible

---

**Status:** Ready for staging deployment  
**Last Updated:** 2025-01-18

