# Security Audit Guide

**Purpose:** Comprehensive security audit for Gold Price Predictor  
**Date:** 2025-01-18  
**Owner:** Security Team

---

## Table of Contents

1. [Overview](#overview)
2. [Automated Security Scanning](#automated-security-scanning)
3. [Manual Security Testing](#manual-security-testing)
4. [Penetration Testing](#penetration-testing)
5. [Security Checklist](#security-checklist)
6. [Remediation](#remediation)

---

## Overview

Security audit ensures the application is protected against common vulnerabilities and follows security best practices.

**Audit Scope:**
- OWASP Top 10 vulnerabilities
- Authentication and authorization
- Data encryption
- Input validation
- Dependency vulnerabilities
- Infrastructure security

**Tools Used:**
- OWASP ZAP (Web application scanner)
- Bandit (Python security linter)
- Safety (Dependency checker)
- Trivy (Container scanner)
- Snyk (Dependency and code scanner)

---

## Automated Security Scanning

### 1. OWASP ZAP (Web Application Scanner)

**Install OWASP ZAP**
```bash
# macOS
brew install --cask owasp-zap

# Windows
choco install zap

# Linux
wget https://github.com/zaproxy/zaproxy/releases/download/v2.14.0/ZAP_2.14.0_Linux.tar.gz
tar -xvf ZAP_2.14.0_Linux.tar.gz
```

**Run Automated Scan**
```bash
# Start ZAP in daemon mode
zap.sh -daemon -port 8090 -config api.disablekey=true

# Run baseline scan
zap-baseline.py -t https://staging.goldpredictor.com -r zap-report.html

# Run full scan
zap-full-scan.py -t https://staging.goldpredictor.com -r zap-full-report.html

# Run API scan
zap-api-scan.py -t https://staging-api.goldpredictor.com/openapi.json -f openapi -r zap-api-report.html
```

**Expected Results:**
- No high-risk vulnerabilities
- No medium-risk vulnerabilities (or documented exceptions)
- Low-risk vulnerabilities acceptable with mitigation plan

### 2. Bandit (Python Security Linter)

**Install Bandit**
```bash
pip install bandit
```

**Run Bandit Scan**
```bash
# Scan backend code
cd backend
bandit -r app/ -f json -o bandit-report.json
bandit -r app/ -ll  # Show only high and medium severity

# Expected output: No issues found
```

**Common Issues to Check:**
- Hardcoded passwords
- SQL injection vulnerabilities
- Use of insecure functions (eval, exec)
- Weak cryptography
- Insecure random number generation

### 3. Safety (Dependency Vulnerability Scanner)

**Install Safety**
```bash
pip install safety
```

**Run Safety Check**
```bash
# Check Python dependencies
cd backend/app
safety check --json --output safety-report.json
safety check  # Show vulnerabilities

# Expected output: No known security vulnerabilities found
```

### 4. Trivy (Container Scanner)

**Install Trivy**
```bash
# macOS
brew install trivy

# Linux
wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | sudo apt-key add -
echo "deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" | sudo tee -a /etc/apt/sources.list.d/trivy.list
sudo apt-get update
sudo apt-get install trivy
```

**Scan Docker Images**
```bash
# Build image
docker build -t gold-predictor:latest .

# Scan image
trivy image gold-predictor:latest --severity HIGH,CRITICAL

# Generate report
trivy image gold-predictor:latest --format json --output trivy-report.json
```

### 5. Snyk (Code and Dependency Scanner)

**Install Snyk**
```bash
npm install -g snyk
snyk auth
```

**Run Snyk Scan**
```bash
# Scan backend dependencies
cd backend
snyk test --json > snyk-backend-report.json

# Scan frontend dependencies
cd client
snyk test --json > snyk-frontend-report.json

# Scan code
snyk code test
```

---

## Manual Security Testing

### 1. Authentication Testing

**Test Cases:**
```bash
# Test 1: SQL Injection in login
curl -X POST https://staging-api.goldpredictor.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin'\'' OR 1=1--", "password": "anything"}'
# Expected: 401 Unauthorized (not successful login)

# Test 2: Brute force protection
for i in {1..10}; do
  curl -X POST https://staging-api.goldpredictor.com/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"username": "admin", "password": "wrong"}'
done
# Expected: Account locked after 5 attempts

# Test 3: JWT token expiration
# Login and get token
TOKEN=$(curl -X POST https://staging-api.goldpredictor.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "Admin@123"}' | jq -r '.access_token')

# Wait 16 minutes (token expires after 15 minutes)
sleep 960

# Try to use expired token
curl -X GET https://staging-api.goldpredictor.com/api/users \
  -H "Authorization: Bearer $TOKEN"
# Expected: 401 Unauthorized
```

### 2. Authorization Testing

**Test Cases:**
```bash
# Test 1: Regular user accessing admin endpoint
# Login as regular user
USER_TOKEN=$(curl -X POST https://staging-api.goldpredictor.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "user1", "password": "User@123"}' | jq -r '.access_token')

# Try to access admin endpoint
curl -X GET https://staging-api.goldpredictor.com/api/users \
  -H "Authorization: Bearer $USER_TOKEN"
# Expected: 403 Forbidden

# Test 2: Accessing other user's data
curl -X GET https://staging-api.goldpredictor.com/api/users/2 \
  -H "Authorization: Bearer $USER_TOKEN"
# Expected: 403 Forbidden (if user ID 2 is not the current user)
```

### 3. CSRF Protection Testing

**Test Cases:**
```bash
# Test 1: POST without CSRF token
curl -X POST https://staging-api.goldpredictor.com/api/users \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"username": "newuser", "email": "new@test.com", "password": "Test@123"}'
# Expected: 403 Forbidden (missing CSRF token)

# Test 2: POST with invalid CSRF token
curl -X POST https://staging-api.goldpredictor.com/api/users \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-CSRF-Token: invalid-token" \
  -H "Content-Type: application/json" \
  -d '{"username": "newuser", "email": "new@test.com", "password": "Test@123"}'
# Expected: 403 Forbidden (invalid CSRF token)
```

### 4. Input Validation Testing

**Test Cases:**
```bash
# Test 1: XSS in username
curl -X POST https://staging-api.goldpredictor.com/api/users \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "X-CSRF-Token: $CSRF_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"username": "<script>alert(\"XSS\")</script>", "email": "xss@test.com", "password": "Test@123"}'
# Expected: 400 Bad Request (invalid username format)

# Test 2: SQL Injection in search
curl -X GET "https://staging-api.goldpredictor.com/api/users?search=admin' OR 1=1--" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
# Expected: Empty results or error (not all users)

# Test 3: Path traversal
curl -X GET "https://staging-api.goldpredictor.com/api/files/../../etc/passwd" \
  -H "Authorization: Bearer $TOKEN"
# Expected: 400 Bad Request or 404 Not Found
```

### 5. Encryption Testing

**Test Cases:**
```bash
# Test 1: HTTPS enforcement
curl -I http://staging.goldpredictor.com
# Expected: 301 Redirect to https://

# Test 2: TLS version
nmap --script ssl-enum-ciphers -p 443 staging.goldpredictor.com
# Expected: TLS 1.2 or higher, strong ciphers only

# Test 3: Password storage
# Check database (passwords should be hashed with Argon2)
psql -h staging-db.example.com -U staging_user -d gold_predictor_staging \
  -c "SELECT username, hashed_password FROM users LIMIT 1;"
# Expected: hashed_password starts with $argon2id$
```

---

## Penetration Testing

### OWASP Top 10 Checklist

**1. Injection**
- [ ] SQL Injection tested (parameterized queries used)
- [ ] NoSQL Injection tested (if applicable)
- [ ] Command Injection tested
- [ ] LDAP Injection tested (if applicable)

**2. Broken Authentication**
- [ ] Brute force protection tested (account lockout works)
- [ ] Session management tested (tokens expire)
- [ ] Password policy tested (complexity enforced)
- [ ] MFA tested (if enabled)

**3. Sensitive Data Exposure**
- [ ] HTTPS enforced
- [ ] Passwords hashed (Argon2)
- [ ] Secrets not in code (AWS Secrets Manager)
- [ ] Database encrypted at rest

**4. XML External Entities (XXE)**
- [ ] XML parsing disabled or secured
- [ ] File upload validation tested

**5. Broken Access Control**
- [ ] RBAC tested (admin vs user)
- [ ] Horizontal privilege escalation tested
- [ ] Vertical privilege escalation tested

**6. Security Misconfiguration**
- [ ] Default credentials changed
- [ ] Error messages don't leak info
- [ ] Security headers configured
- [ ] Unnecessary services disabled

**7. Cross-Site Scripting (XSS)**
- [ ] Input sanitization tested
- [ ] Output encoding tested
- [ ] CSP headers configured

**8. Insecure Deserialization**
- [ ] Deserialization secured
- [ ] Input validation on serialized data

**9. Using Components with Known Vulnerabilities**
- [ ] Dependencies scanned (Safety, Snyk)
- [ ] No critical vulnerabilities
- [ ] Update plan for medium vulnerabilities

**10. Insufficient Logging & Monitoring**
- [ ] All authentication attempts logged
- [ ] All CRUD operations logged
- [ ] Security events logged
- [ ] Logs monitored (Prometheus, Grafana)

---

## Remediation

### High Priority (Fix Immediately)
- SQL Injection vulnerabilities
- Authentication bypass
- Sensitive data exposure
- Remote code execution

### Medium Priority (Fix Within 1 Week)
- XSS vulnerabilities
- CSRF vulnerabilities
- Insecure dependencies
- Missing security headers

### Low Priority (Fix Within 1 Month)
- Information disclosure
- Weak password policy
- Missing rate limiting
- Outdated dependencies (no known exploits)

---

## Security Audit Checklist

- [ ] OWASP ZAP scan completed (no high/medium issues)
- [ ] Bandit scan completed (no issues)
- [ ] Safety check completed (no vulnerabilities)
- [ ] Trivy scan completed (no critical vulnerabilities)
- [ ] Snyk scan completed (no high vulnerabilities)
- [ ] Authentication testing passed
- [ ] Authorization testing passed
- [ ] CSRF protection verified
- [ ] Input validation verified
- [ ] Encryption verified (HTTPS, password hashing)
- [ ] OWASP Top 10 checklist completed
- [ ] Penetration testing completed
- [ ] All high-priority issues fixed
- [ ] Security audit report generated

---

**Status:** Ready for security audit  
**Last Updated:** 2025-01-18

