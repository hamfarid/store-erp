# واجهة إدارة الحاويات - Container Management Interface

**FILE**: docs/CONTAINER_MANAGEMENT_INTERFACE.md  
**PURPOSE**: توثيق واجهات إدارة الحاويات والربط بين الواجهات  
**OWNER**: DevOps Team  
**LAST-AUDITED**: 2025-01-27

---

## 📋 ملخص الحالة

### ✅ الربط بين الواجهات

#### 1. **الواجهة الأمامية (Frontend) ↔ الواجهة الخلفية (Backend)**

**الربط**: ✅ **مكتمل**

- **التقنية**: tRPC (Type-safe RPC)
- **المنفذ**: `2505` (Frontend) → `2505/api/trpc` (Backend)
- **التكوين**:
  - Frontend يستخدم `@trpc/react-query` للاتصال
  - Backend يعرض tRPC router على `/api/trpc`
  - WebSocket للاتصال المباشر على `/ws`

**الملفات**:
- `client/src/lib/trpc.ts` - تكوين tRPC client
- `server/routers.ts` - tRPC router الرئيسي
- `server/_core/index.ts` - Express server مع tRPC middleware

**مثال الاستخدام**:
```typescript
// في Frontend
const { data } = trpc.assets.getById.useQuery({ id: 1 });
const mutation = trpc.predictions.generate.useMutation();
```

#### 2. **الحاويات (Docker Containers)**

**الربط**: ✅ **مكتمل**

**ملفات Docker Compose**:
- `docker-compose.yml` - التكوين الأساسي
- `docker-compose.production.yml` - الإنتاج
- `docker-compose.ml.yml` - خدمات ML
- `docker-compose.monitoring.yml` - المراقبة

**الشبكة**: `gold-predictor-network` (bridge)

**الخدمات المتصلة**:
```
Frontend (2505:80) 
  ↓
Nginx (82:80, 442:443)
  ↓
Backend (2005:5000) ← → Redis (6382:6379)
  ↓
PostgreSQL (5432:5432)
  ↓
ML Service (8001:8000)
```

---

## 🖥️ واجهات إدارة الحاويات

### ❌ **لا توجد واجهة إدارة مخصصة للحاويات حالياً**

**الخيارات المتاحة**:

#### 1. **Grafana Dashboard** (✅ موجود)
- **المنفذ**: `3001:3000` (في docker-compose.production.yml)
- **الوصول**: `http://localhost:3001`
- **الاستخدام**: مراقبة المقاييس والرسوم البيانية
- **التكوين**: موجود في `monitoring/grafana/`

#### 2. **Prometheus** (✅ موجود)
- **المنفذ**: `9090:9090`
- **الوصول**: `http://localhost:9090`
- **الاستخدام**: جمع المقاييس والاستعلامات

#### 3. **Portainer** (❌ غير مثبت - موصى به)
- **الوصف**: واجهة ويب لإدارة Docker containers
- **التثبيت المقترح**:
```yaml
# إضافة إلى docker-compose.production.yml
portainer:
  image: portainer/portainer-ce:latest
  container_name: gold-predictor-portainer
  ports:
    - "9000:9000"
  volumes:
    - /var/run/docker.sock:/var/run/docker.sock
    - portainer_data:/data
  networks:
    - gold-predictor-network
  restart: always
```

#### 4. **Docker Desktop** (محلي فقط)
- **الوصف**: واجهة GUI لإدارة Docker (Windows/Mac)
- **الاستخدام**: إدارة محلية فقط

---

## 🔗 تفاصيل الربط

### Frontend → Backend

**في التطوير**:
- Frontend: `http://localhost:2505` (Vite dev server)
- Backend: `http://localhost:2505/api/trpc` (نفس المنفذ)
- WebSocket: `ws://localhost:2505/ws`

**في الإنتاج**:
- Frontend: `http://localhost:2505` (Nginx)
- Backend: `http://backend:5000` (داخلي) أو `http://localhost:2005` (خارجي)
- API Proxy: Nginx يوجه `/api/*` إلى Backend

### Backend → Database

**PostgreSQL**:
- URL: `postgresql://user:pass@postgres:5432/gold_predictor`
- داخل Docker: `postgres:5432`
- خارج Docker: `localhost:5432`

**Redis**:
- URL: `redis://:password@redis:6379`
- داخل Docker: `redis:6379`
- خارج Docker: `localhost:6382` (في production)

### Backend → ML Service

- URL: `http://ml-service:8000` (داخلي)
- خارجي: `http://localhost:8001`

---

## 📊 حالة الخدمات

| الخدمة | الحاوية | المنفذ | الحالة | الواجهة |
|--------|---------|--------|--------|---------|
| Frontend | `gold-predictor-frontend` | 2505:80 | ✅ | React UI |
| Backend | `gold-predictor-backend` | 2005:5000 | ✅ | FastAPI |
| PostgreSQL | `gold-predictor-db` | 5432:5432 | ✅ | - |
| Redis | `gold-predictor-redis` | 6382:6379 | ✅ | - |
| ML Service | `gold-predictor-ml` | 8001:8000 | ✅ | FastAPI |
| Nginx | `gold-predictor-nginx` | 82:80, 442:443 | ✅ | - |
| Prometheus | `gold-predictor-prometheus` | 9090:9090 | ✅ | Web UI |
| Grafana | `gold-predictor-grafana` | 3001:3000 | ✅ | Web UI |
| Portainer | - | - | ❌ | - |

---

## 🚀 التوصيات

### 1. إضافة Portainer (موصى به بشدة)

**المزايا**:
- واجهة ويب سهلة لإدارة الحاويات
- عرض حالة الحاويات والخدمات
- إدارة Logs والبيئة
- إدارة Volumes والشبكات

**التثبيت**:
```bash
# إضافة إلى docker-compose.production.yml ثم:
docker compose -f docker-compose.production.yml up -d portainer
```

### 2. إضافة Health Check Dashboard

إنشاء صفحة في Frontend لعرض حالة جميع الخدمات:
- `/admin/containers` - حالة الحاويات
- `/admin/health` - صحة الخدمات
- `/admin/metrics` - المقاييس

### 3. إضافة Container Logs Viewer

واجهة لعرض logs الحاويات في الوقت الفعلي.

---

## 📝 ملاحظات

1. **في التطوير**: Frontend و Backend يعملان على نفس المنفذ (2505) مع Vite proxy
2. **في الإنتاج**: Nginx يعمل كـ reverse proxy بين Frontend و Backend
3. **WebSocket**: متصل تلقائياً من Frontend إلى Backend على `/ws`
4. **tRPC**: يوفر type-safety كامل بين Frontend و Backend

---

## 🔍 التحقق من الربط

### اختبار Frontend → Backend
```bash
# من Frontend
curl http://localhost:2505/api/trpc/assets.list
```

### اختبار Backend → Database
```bash
# من داخل Backend container
docker exec gold-predictor-backend python -c "from app.database import engine; print(engine.connect())"
```

### اختبار WebSocket
```javascript
// من المتصفح console
const ws = new WebSocket('ws://localhost:2505/ws');
ws.onopen = () => console.log('Connected');
```

---

**آخر تحديث**: 2025-01-27

