# Testing Strategy - Gold & Assets Price Prediction System
<!-- cSpell:disable -->
**FILE**: docs/TESTING_STRATEGY.md | **PURPOSE**: Comprehensive testing strategy and quality assurance | **OWNER**: QA Team | **RELATED**: ARCHITECTURE.md, Security.md, CI_CD_GUIDE.md | **LAST-AUDITED**: 2025-11-17

**Version**: 3.0.0  
**Last Updated**: 2025-11-17  
**Test Coverage Target**: 90%  
**Current Coverage**: 85%

---

## Table of Contents
1. [Testing Overview](#1-testing-overview)
2. [Testing Pyramid](#2-testing-pyramid)
3. [Unit Testing](#3-unit-testing)
4. [Integration Testing](#4-integration-testing)
5. [End-to-End Testing](#5-end-to-end-testing)
6. [API Testing](#6-api-testing)
7. [Performance Testing](#7-performance-testing)
8. [Security Testing](#8-security-testing)
9. [ML Model Testing](#9-ml-model-testing)
10. [Accessibility Testing](#10-accessibility-testing)
11. [Test Environments](#11-test-environments)
12. [CI/CD Integration](#12-cicd-integration)
13. [Quality Gates](#13-quality-gates)
14. [Test Data Management](#14-test-data-management)

---

## 1. Testing Overview

### 1.1 Testing Objectives

**Primary Goals**:
1. **Correctness**: Verify all features work as specified
2. **Reliability**: Ensure system stability under load
3. **Security**: Prevent vulnerabilities (OWASP Top 10)
4. **Performance**: Meet latency and throughput targets
5. **Accessibility**: WCAG AA compliance
6. **Regression Prevention**: Catch bugs before production

### 1.2 Testing Metrics

| Metric | Current | Target | Status |
|--------|---------|--------|--------|
| **Code Coverage** | 85% | 90% | 🟡 In Progress |
| **Unit Test Pass Rate** | 98% | 100% | 🟡 In Progress |
| **Integration Test Pass Rate** | 95% | 100% | 🟡 In Progress |
| **E2E Test Pass Rate** | 92% | 95% | 🟡 In Progress |
| **Performance Tests** | Manual | Automated | ⚠️ Planned |
| **Security Scan** | Weekly | Daily | ⚠️ Planned |
| **Mutation Score** | 75% | 85% | 🟡 In Progress |
| **Flaky Test Rate** | 3% | <1% | 🟡 In Progress |

### 1.3 Test Execution Time

```
Total Test Suite: ~15 minutes
├── Unit Tests: 2 min (234 tests)
├── Integration Tests: 5 min (87 tests)
├── E2E Tests: 8 min (24 tests)
└── Parallel Execution: Yes (4 workers)
```

---

## 2. Testing Pyramid

### 2.1 Test Distribution

```
         ╱╲
        ╱  ╲
       ╱ E2E╲         24 tests (10%)  - Critical user flows
      ╱──────╲        8 minutes
     ╱────────╲
    ╱Integration╲     87 tests (20%)  - API, database, services
   ╱────────────╲    5 minutes
  ╱──────────────╲
 ╱  Unit Tests   ╲   234 tests (70%) - Functions, components
╱────────────────╲  2 minutes
```

**Distribution Rationale**:
- **70% Unit Tests**: Fast, isolated, high coverage
- **20% Integration**: Critical paths, database, external APIs
- **10% E2E**: User journeys, UI flows, cross-system

### 2.2 Test Types by Layer

**Frontend**:
- Unit: React components (Jest + React Testing Library)
- Integration: Page interactions, API mocking
- E2E: Full user flows (Playwright)

**Backend**:
- Unit: Business logic, utilities (pytest)
- Integration: API endpoints, database (pytest + testcontainers)
- E2E: API contracts (Postman/Newman)

**ML Models**:
- Unit: Feature engineering, data preprocessing
- Integration: Model loading, prediction pipeline
- Performance: Inference latency, accuracy benchmarks

---

## 3. Unit Testing

### 3.1 Backend Unit Tests (Python/pytest)

**Framework**: pytest + pytest-cov + pytest-mock

**Coverage Target**: **90%**

**Test Structure**:
```
backend/app/tests/
├── unit/
│   ├── test_auth_service.py       # Authentication logic
│   ├── test_prediction_service.py # Prediction business logic
│   ├── test_validators.py         # Input validation
│   ├── test_models.py             # SQLAlchemy models
│   └── test_utils.py              # Utility functions
├── conftest.py                    # Shared fixtures
└── pytest.ini                     # Configuration
```

**Example Test** (backend/app/tests/unit/test_auth_service.py):
```python
import pytest
from app.auth_postgresql import hash_password, verify_password
from app.auth_2fa import TwoFactorAuth

class TestPasswordHashing:
    """Test password hashing and verification"""
    
    def test_hash_password_returns_bcrypt_hash(self):
        """Should return valid bcrypt hash"""
        password = "SecurePass123"
        hashed = hash_password(password)
        
        assert hashed != password
        assert hashed.startswith("$2b$")
        assert len(hashed) == 60
    
    def test_verify_password_with_correct_password(self):
        """Should verify correct password"""
        password = "SecurePass123"
        hashed = hash_password(password)
        
        assert verify_password(password, hashed) is True
    
    def test_verify_password_with_incorrect_password(self):
        """Should reject incorrect password"""
        password = "SecurePass123"
        hashed = hash_password(password)
        
        assert verify_password("WrongPass456", hashed) is False
    
    @pytest.mark.parametrize("password", [
        "short",  # Too short
        "nouppercase123",  # No uppercase
        "NOLOWERCASE123",  # No lowercase
        "NoDigitsHere",  # No digits
    ])
    def test_weak_passwords_rejected(self, password):
        """Should reject weak passwords"""
        from pydantic import ValidationError
        from app.main import UserCreate
        
        with pytest.raises(ValidationError):
            UserCreate(
                username="testuser",
                email="test@example.com",
                password=password
            )

class TestTwoFactorAuth:
    """Test 2FA functionality"""
    
    def test_generate_secret_returns_32_char_base32(self):
        """Should generate valid TOTP secret"""
        secret = TwoFactorAuth.generate_secret()
        
        assert len(secret) == 32
        assert secret.isupper()
        assert all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" for c in secret)
    
    def test_verify_token_with_valid_token(self):
        """Should verify valid TOTP token"""
        secret = TwoFactorAuth.generate_secret()
        token = TwoFactorAuth.get_token(secret)
        
        assert TwoFactorAuth.verify_token(token, secret) is True
    
    def test_verify_token_with_invalid_token(self):
        """Should reject invalid TOTP token"""
        secret = TwoFactorAuth.generate_secret()
        
        assert TwoFactorAuth.verify_token("000000", secret) is False
```

**Running Unit Tests**:
```bash
# Run all unit tests
pytest backend/app/tests/unit -v

# Run with coverage
pytest backend/app/tests/unit --cov=backend/app --cov-report=html

# Run specific test file
pytest backend/app/tests/unit/test_auth_service.py -v

# Run tests matching pattern
pytest -k "test_password" -v
```

### 3.2 Frontend Unit Tests (TypeScript/Jest)

**Framework**: Jest + React Testing Library + Vitest

**Coverage Target**: **85%**

**Test Structure**:
```
client/src/
├── __tests__/
│   ├── components/
│   │   ├── Dashboard.test.tsx
│   │   ├── PredictionForm.test.tsx
│   │   └── AlertsList.test.tsx
│   ├── store/
│   │   ├── authSlice.test.ts
│   │   └── predictionSlice.test.ts
│   └── utils/
│       ├── formatters.test.ts
│       └── validators.test.ts
└── setupTests.ts
```

**Example Test** (client/src/__tests__/components/PredictionForm.test.tsx):
```typescript
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { PredictionForm } from '@/components/PredictionForm';
import { store } from '@/store';

describe('PredictionForm', () => {
  it('renders form with all fields', () => {
    render(
      <Provider store={store}>
        <PredictionForm />
      </Provider>
    );
    
    expect(screen.getByLabelText(/asset/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/horizon/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /predict/i })).toBeInTheDocument();
  });
  
  it('submits form with valid data', async () => {
    const mockOnSubmit = jest.fn();
    
    render(
      <Provider store={store}>
        <PredictionForm onSubmit={mockOnSubmit} />
      </Provider>
    );
    
    // Select asset
    fireEvent.change(screen.getByLabelText(/asset/i), {
      target: { value: 'GOLD' }
    });
    
    // Select horizon
    fireEvent.change(screen.getByLabelText(/horizon/i), {
      target: { value: 'short' }
    });
    
    // Submit form
    fireEvent.click(screen.getByRole('button', { name: /predict/i }));
    
    await waitFor(() => {
      expect(mockOnSubmit).toHaveBeenCalledWith({
        asset: 'GOLD',
        horizon: 'short'
      });
    });
  });
  
  it('shows validation error for empty asset', async () => {
    render(
      <Provider store={store}>
        <PredictionForm />
      </Provider>
    );
    
    fireEvent.click(screen.getByRole('button', { name: /predict/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/asset is required/i)).toBeInTheDocument();
    });
  });
});
```

**Running Frontend Tests**:
```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run in watch mode
npm run test:watch

# Run specific test file
npm test -- PredictionForm.test.tsx
```

---

## 4. Integration Testing

### 4.1 Backend Integration Tests

**Framework**: pytest + testcontainers + httpx

**Test Scope**:
- API endpoint responses
- Database transactions
- External API integrations
- Service-to-service communication

**Test Structure**:
```
backend/app/tests/
├── integration/
│   ├── test_api_auth.py           # Authentication endpoints
│   ├── test_api_predictions.py    # Prediction endpoints
│   ├── test_api_alerts.py         # Alert endpoints
│   ├── test_database.py           # Database operations
│   └── test_ml_service.py         # ML service integration
└── docker-compose.test.yml        # Test containers
```

**Example Test** (backend/app/tests/integration/test_api_auth.py):
```python
import pytest
from httpx import AsyncClient
from app.main import app
from app.database import get_db, Base
from testcontainers.postgres import PostgresContainer

@pytest.fixture(scope="module")
def postgres_container():
    """Start PostgreSQL test container"""
    with PostgresContainer("postgres:15") as postgres:
        yield postgres

@pytest.fixture
async def test_client(postgres_container):
    """Create test client with test database"""
    # Override database connection
    DATABASE_URL = postgres_container.get_connection_url()
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client

class TestAuthAPI:
    """Test authentication API endpoints"""
    
    @pytest.mark.asyncio
    async def test_register_new_user(self, test_client):
        """Should register new user and return tokens"""
        response = await test_client.post("/api/auth/register", json={
            "username": "testuser",
            "email": "test@example.com",
            "password": "SecurePass123"
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
    
    @pytest.mark.asyncio
    async def test_register_duplicate_user(self, test_client):
        """Should reject duplicate username"""
        # Register first user
        await test_client.post("/api/auth/register", json={
            "username": "testuser",
            "email": "test@example.com",
            "password": "SecurePass123"
        })
        
        # Try to register again
        response = await test_client.post("/api/auth/register", json={
            "username": "testuser",
            "email": "test2@example.com",
            "password": "SecurePass123"
        })
        
        assert response.status_code == 400
        assert "already exists" in response.json()["message"].lower()
    
    @pytest.mark.asyncio
    async def test_login_with_valid_credentials(self, test_client):
        """Should login and return tokens"""
        # Register user
        await test_client.post("/api/auth/register", json={
            "username": "testuser",
            "email": "test@example.com",
            "password": "SecurePass123"
        })
        
        # Login
        response = await test_client.post("/api/auth/login", data={
            "username": "testuser",
            "password": "SecurePass123"
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
    
    @pytest.mark.asyncio
    async def test_login_with_invalid_credentials(self, test_client):
        """Should reject invalid credentials"""
        response = await test_client.post("/api/auth/login", data={
            "username": "nonexistent",
            "password": "WrongPass123"
        })
        
        assert response.status_code == 401
        assert "incorrect" in response.json()["message"].lower()
```

**Running Integration Tests**:
```bash
# Run all integration tests
pytest backend/app/tests/integration -v

# Run with test containers
docker-compose -f backend/app/tests/docker-compose.test.yml up -d
pytest backend/app/tests/integration -v
docker-compose -f backend/app/tests/docker-compose.test.yml down
```

### 4.2 Frontend Integration Tests

**Test Scope**:
- Component interactions
- API mocking (MSW - Mock Service Worker)
- State management
- Routing

**Example Test**:
```typescript
import { render, screen, waitFor } from '@testing-library/react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { Dashboard } from '@/pages/Dashboard';

const server = setupServer(
  rest.get('/api/predictions/history', (req, res, ctx) => {
    return res(ctx.json({
      predictions: [
        { id: 1, asset: 'GOLD', predicted_price: 1975.20 }
      ]
    }));
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

test('loads and displays predictions', async () => {
  render(<Dashboard />);
  
  await waitFor(() => {
    expect(screen.getByText(/1975.20/)).toBeInTheDocument();
  });
});
```

---

## 5. End-to-End Testing

### 5.1 E2E Framework: Playwright

**Test Coverage**:
- Critical user journeys
- Cross-browser testing (Chrome, Firefox, Safari)
- Mobile responsive testing
- Visual regression testing

**Test Structure**:
```
tests/e2e/
├── specs/
│   ├── auth.spec.ts              # Login, registration, 2FA
│   ├── predictions.spec.ts       # Create predictions
│   ├── alerts.spec.ts            # Alert management
│   └── dashboard.spec.ts         # Dashboard navigation
├── pages/                        # Page Object Model
│   ├── LoginPage.ts
│   ├── DashboardPage.ts
│   └── PredictionPage.ts
├── fixtures/
│   └── test-data.json
└── playwright.config.ts
```

**Example E2E Test** (tests/e2e/specs/predictions.spec.ts):
```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { PredictionPage } from '../pages/PredictionPage';

test.describe('Prediction Flow', () => {
  test.beforeEach(async ({ page }) => {
    // Login before each test
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('testuser', 'SecurePass123');
  });
  
  test('create gold price prediction', async ({ page }) => {
    const predictionPage = new PredictionPage(page);
    
    // Navigate to prediction page
    await predictionPage.goto();
    
    // Fill form
    await predictionPage.selectAsset('GOLD');
    await predictionPage.selectHorizon('short');
    
    // Submit
    await predictionPage.submit();
    
    // Verify result
    await expect(page.locator('[data-testid="prediction-result"]')).toBeVisible();
    await expect(page.locator('[data-testid="predicted-price"]')).toContainText(/\d+\.\d{2}/);
    await expect(page.locator('[data-testid="confidence"]')).toContainText(/\d+\.\d{2}%/);
  });
  
  test('validate prediction history', async ({ page }) => {
    const predictionPage = new PredictionPage(page);
    
    // Create prediction
    await predictionPage.goto();
    await predictionPage.createPrediction('GOLD', 'short');
    
    // Navigate to history
    await page.click('text=History');
    
    // Verify prediction appears
    await expect(page.locator('table tbody tr')).toHaveCount(1);
    await expect(page.locator('table')).toContainText('GOLD');
  });
  
  test('mobile responsive layout', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    const predictionPage = new PredictionPage(page);
    await predictionPage.goto();
    
    // Verify mobile menu
    await expect(page.locator('[data-testid="mobile-menu"]')).toBeVisible();
    
    // Verify form is responsive
    await expect(page.locator('form')).toHaveCSS('flex-direction', 'column');
  });
});
```

**Running E2E Tests**:
```bash
# Run all E2E tests
npx playwright test

# Run in headed mode (see browser)
npx playwright test --headed

# Run specific browser
npx playwright test --project=chromium

# Run specific test file
npx playwright test tests/e2e/specs/predictions.spec.ts

# Generate test report
npx playwright show-report
```

---

## 6. API Testing

### 6.1 Contract Testing

**Framework**: Postman + Newman (CLI)

**Test Collection**: `tests/api/gold-predictor-api.postman_collection.json`

**Test Scenarios**:
- Request/response schema validation
- Error handling (400, 401, 403, 404, 500)
- Rate limiting (429)
- Authentication flows
- CRUD operations

**Example Postman Test**:
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has valid structure", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('symbol');
    pm.expect(jsonData).to.have.property('predicted_price');
    pm.expect(jsonData.predicted_price).to.be.a('number');
    pm.expect(jsonData.confidence).to.be.within(0, 1);
});

pm.test("Response time is less than 500ms", function () {
    pm.expect(pm.response.responseTime).to.be.below(500);
});
```

**Running API Tests**:
```bash
# Run Postman collection
newman run tests/api/gold-predictor-api.postman_collection.json \
  --environment tests/api/environments/dev.postman_environment.json \
  --reporters cli,json,html
```

---

## 7. Performance Testing

### 7.1 Load Testing (k6)

**Target Metrics**:
- P50 latency: <100ms
- P95 latency: <500ms
- P99 latency: <1000ms
- Throughput: 1000 req/s
- Error rate: <0.1%

**Test Script** (tests/performance/load-test.js):
```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '1m', target: 100 },   // Ramp up to 100 users
    { duration: '5m', target: 100 },   // Stay at 100 users
    { duration: '1m', target: 500 },   // Spike to 500 users
    { duration: '5m', target: 500 },   // Stay at 500 users
    { duration: '1m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
    http_req_failed: ['rate<0.01'],
  },
};

export default function () {
  // Login
  const loginRes = http.post('http://localhost:2005/api/auth/login', {
    username: 'testuser',
    password: 'SecurePass123',
  });
  
  check(loginRes, {
    'login successful': (r) => r.status === 200,
  });
  
  const token = loginRes.json('access_token');
  
  // Create prediction
  const predictionRes = http.post(
    'http://localhost:2005/api/predict',
    JSON.stringify({
      symbol: 'GOLD',
      horizon: 'short',
    }),
    {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    }
  );
  
  check(predictionRes, {
    'prediction successful': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });
  
  sleep(1);
}
```

**Running Performance Tests**:
```bash
# Run k6 load test
k6 run tests/performance/load-test.js

# Run with Cloud output
k6 run --out cloud tests/performance/load-test.js
```

---

## 8. Security Testing

### 8.1 SAST (Static Application Security Testing)

**Tools**:
- **Bandit** (Python): Security linter
- **Semgrep**: Multi-language static analysis
- **SonarQube**: Code quality + security

**Running SAST**:
```bash
# Bandit (Python)
bandit -r backend/app -f json -o security-report.json

# Semgrep
semgrep --config=auto backend/app

# SonarQube
sonar-scanner \
  -Dsonar.projectKey=gold-predictor \
  -Dsonar.sources=. \
  -Dsonar.host.url=http://localhost:9000
```

### 8.2 DAST (Dynamic Application Security Testing)

**Tool**: OWASP ZAP

**Test Scenarios**:
- SQL injection
- XSS attacks
- CSRF vulnerabilities
- Authentication bypass
- Sensitive data exposure

**Running DAST**:
```bash
# OWASP ZAP baseline scan
docker run -t owasp/zap2docker-stable zap-baseline.py \
  -t http://localhost:2505 \
  -r zap-report.html
```

### 8.3 Dependency Scanning

**Tools**:
- **Snyk**: Vulnerability scanning
- **npm audit**: Node.js dependencies
- **pip-audit**: Python dependencies

```bash
# Snyk
snyk test --all-projects

# npm audit
npm audit --audit-level=high

# pip-audit
pip-audit --require requirements.txt
```

---

## 9. ML Model Testing

### 9.1 Model Accuracy Testing

**Metrics**:
- R² Score: >0.95
- MAE (Mean Absolute Error): <50
- RMSE (Root Mean Squared Error): <100
- Prediction time: <100ms

**Test Script** (tests/ml/test_model_accuracy.py):
```python
import pytest
from modules.model_loader import ModelLoader
from sklearn.metrics import r2_score, mean_absolute_error

def test_gold_model_accuracy():
    """Test GOLD model meets accuracy requirements"""
    loader = ModelLoader()
    model = loader.load_model('GOLD', 'ensemble')
    
    # Load test data
    X_test, y_test = load_test_data('GOLD')
    
    # Predict
    predictions = model.predict(X_test)
    
    # Calculate metrics
    r2 = r2_score(y_test, predictions)
    mae = mean_absolute_error(y_test, predictions)
    
    # Assert accuracy requirements
    assert r2 > 0.95, f"R² score {r2} below threshold"
    assert mae < 50, f"MAE {mae} above threshold"

def test_model_inference_time():
    """Test model inference meets latency requirements"""
    import time
    
    loader = ModelLoader()
    model = loader.load_model('GOLD', 'ensemble')
    
    X_test, _ = load_test_data('GOLD', n_samples=1)
    
    # Measure inference time
    start = time.time()
    model.predict(X_test)
    duration_ms = (time.time() - start) * 1000
    
    assert duration_ms < 100, f"Inference took {duration_ms}ms (threshold: 100ms)"
```

---

## 10. Accessibility Testing

### 10.1 Automated Accessibility Testing

**Tools**:
- **axe-core** (via Playwright)
- **Lighthouse** (Chrome DevTools)
- **Pa11y**

**Target**: WCAG 2.1 AA Compliance

**Example Test**:
```typescript
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('homepage should not have accessibility violations', async ({ page }) => {
  await page.goto('http://localhost:2505');
  
  const accessibilityScanResults = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa'])
    .analyze();
  
  expect(accessibilityScanResults.violations).toEqual([]);
});
```

---

## 11. Test Environments

| Environment | Purpose | Database | API URL |
|-------------|---------|----------|---------|
| **Local** | Development | SQLite | http://localhost:2005 |
| **Docker** | Integration tests | PostgreSQL (container) | http://localhost:2005 |
| **CI** | Automated testing | PostgreSQL (container) | http://test-api:8000 |
| **Staging** | Pre-production | PostgreSQL (RDS) | https://staging.goldpredictor.com |
| **Production** | Live system | PostgreSQL (RDS) | https://api.goldpredictor.com |

---

## 12. CI/CD Integration

### 12.1 GitHub Actions Workflow

```yaml
name: Test Pipeline

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Unit Tests
        run: pytest backend/app/tests/unit --cov
      
      - name: Run Integration Tests
        run: |
          docker-compose -f docker-compose.test.yml up -d
          pytest backend/app/tests/integration
          docker-compose -f docker-compose.test.yml down
      
      - name: Run E2E Tests
        run: npx playwright test
      
      - name: Security Scan
        run: bandit -r backend/app
      
      - name: Upload Coverage
        uses: codecov/codecov-action@v3
```

---

## 13. Quality Gates

**Pre-Commit**:
- ✅ Linting (flake8, prettier)
- ✅ Type checking (mypy, tsc)
- ✅ Unit tests pass

**Pre-Merge (PR)**:
- ✅ All tests pass (unit + integration + E2E)
- ✅ Code coverage >85%
- ✅ No HIGH/CRITICAL security vulns
- ✅ Code review approved

**Pre-Deploy (Staging)**:
- ✅ Performance tests pass
- ✅ DAST scan clean
- ✅ Load testing passed

**Pre-Deploy (Production)**:
- ✅ Smoke tests pass in staging
- ✅ Manual QA approval
- ✅ Security review completed

---

## 14. Test Data Management

**Test Data Sources**:
- Fixtures: JSON files in `tests/fixtures/`
- Factories: Generate test data programmatically
- Mocks: Mock external APIs (MSW, responses)
- Containers: Real databases (testcontainers)

**Test Data Cleanup**:
- Database: Rollback after each test (transactions)
- Files: Delete temp files in teardown
- Cache: Clear Redis after tests

---

**Last Updated**: 2025-11-17  
**Next Review**: 2026-02-17  
**Version**: 3.0.0  
**Owner**: QA Team
