# Testing Guide

Comprehensive testing strategy for the Gold Price Predictor application.

## Table of Contents

1. [Overview](#overview)
2. [Backend Testing](#backend-testing)
3. [Frontend Testing](#frontend-testing)
4. [E2E Testing](#e2e-testing)
5. [Performance Testing](#performance-testing)
6. [Coverage Requirements](#coverage-requirements)
7. [CI/CD Integration](#cicd-integration)

---

## Overview

Our testing strategy follows the testing pyramid:
- **70% Unit Tests** - Fast, isolated tests for individual functions/components
- **20% Integration Tests** - Tests for API endpoints and database interactions
- **10% E2E Tests** - Critical user journeys through the UI

**Coverage Target:** 90% for backend, 80% for frontend

---

## Backend Testing

### Setup

```bash
cd backend
pip install -r requirements-dev.txt
```

### Running Tests

```bash
# Run all tests with coverage
python run_tests.py

# Run specific test types
python run_tests.py --type unit
python run_tests.py --type integration
python run_tests.py --type security
python run_tests.py --type crud

# Run specific test file
python run_tests.py --file app/tests/test_users_crud.py

# Run specific test function
python run_tests.py --file app/tests/test_users_crud.py --test test_create_user_success

# Run without coverage
python run_tests.py --no-coverage

# Quiet mode
python run_tests.py --quiet
```

### Test Structure

```
backend/app/tests/
├── conftest.py                    # Shared fixtures
├── test_users_crud.py             # Users CRUD tests
├── test_assets_crud.py            # Assets CRUD tests
├── test_predictions_crud.py       # Predictions CRUD tests
├── test_alerts_crud.py            # Alerts CRUD tests
├── test_auth.py                   # Authentication tests
├── test_csrf_protection.py        # CSRF tests
├── test_jwt_rotation.py           # JWT rotation tests
├── test_account_lockout.py        # Account lockout tests
└── test_integration.py            # Integration tests
```

### Writing Tests

```python
import pytest
from fastapi.testclient import TestClient

def test_create_user_success(admin_token, client):
    """Test creating a new user successfully"""
    response = client.post(
        "/api/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "username": "newuser",
            "email": "newuser@test.com",
            "password": "NewUser@123",
            "is_admin": False
        }
    )
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "newuser"
    assert "id" in data
```

### Coverage Report

After running tests, view the HTML coverage report:

```bash
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
start htmlcov/index.html  # Windows
```

---

## Frontend Testing

### Setup

```bash
# Install dependencies (if not already installed)
pnpm install
```

### Running Tests

```bash
# Run all tests
pnpm test

# Run in watch mode
pnpm test --watch

# Run with coverage
pnpm test --coverage

# Run specific test file
pnpm test UsersList.test.tsx

# Run tests matching pattern
pnpm test --grep "authentication"
```

### Test Structure

```
client/src/
├── pages/
│   └── admin/
│       └── __tests__/
│           ├── UsersList.test.tsx
│           ├── UserForm.test.tsx
│           ├── AssetsList.test.tsx
│           └── AssetsForm.test.tsx
└── components/
    └── __tests__/
        ├── Navigation.test.tsx
        └── ProtectedRoute.test.tsx
```

### Writing Tests

```typescript
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import UsersList from '../UsersList';

describe('UsersList Component', () => {
  it('renders users list successfully', async () => {
    render(<UsersList />);
    
    await waitFor(() => {
      expect(screen.getByText('admin')).toBeInTheDocument();
    });
  });
});
```

---

## E2E Testing

### Setup

```bash
# Install Playwright
pnpm install -D @playwright/test

# Install browsers
npx playwright install
```

### Running Tests

```bash
# Run all E2E tests
npx playwright test

# Run in headed mode (see browser)
npx playwright test --headed

# Run specific test file
npx playwright test auth.spec.ts

# Run specific test
npx playwright test -g "should login with valid credentials"

# Debug mode
npx playwright test --debug

# View report
npx playwright show-report
```

### Test Structure

```
e2e/tests/
├── auth.spec.ts           # Authentication flow
├── users-crud.spec.ts     # Users CRUD operations
├── assets-crud.spec.ts    # Assets CRUD operations
└── dashboard.spec.ts      # Dashboard functionality
```

---

## Performance Testing

### Setup

```bash
pip install locust
```

### Running Tests

```bash
# Start Locust web UI
cd performance
locust -f locustfile.py --host=http://localhost:2005

# Open browser to http://localhost:8089
# Configure number of users and spawn rate
# Start test

# Headless mode
locust -f locustfile.py --host=http://localhost:2005 --headless -u 100 -r 10 -t 5m
```

### Performance Targets

- **Response Time (p95):** < 200ms for GET requests
- **Response Time (p95):** < 500ms for POST/PUT/DELETE requests
- **Throughput:** > 100 requests/second
- **Error Rate:** < 1%

---

## Coverage Requirements

### Backend
- **Minimum:** 80%
- **Target:** 90%
- **Critical Paths:** 100% (auth, CRUD, security)

### Frontend
- **Minimum:** 70%
- **Target:** 80%
- **Critical Components:** 90% (auth, forms, protected routes)

---

## CI/CD Integration

### GitHub Actions Workflow

```yaml
name: Tests

on: [push, pull_request]

jobs:
  backend-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run backend tests
        run: |
          cd backend
          pip install -r requirements-dev.txt
          python run_tests.py
      - name: Upload coverage
        uses: codecov/codecov-action@v3

  frontend-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run frontend tests
        run: pnpm test --coverage
      - name: Upload coverage
        uses: codecov/codecov-action@v3

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run E2E tests
        run: npx playwright test
```

---

## Best Practices

1. **Write tests first** (TDD) for critical features
2. **Keep tests isolated** - No dependencies between tests
3. **Use descriptive names** - Test names should explain what they test
4. **Mock external dependencies** - Don't call real APIs in tests
5. **Test edge cases** - Not just happy paths
6. **Maintain test data** - Use fixtures for consistent test data
7. **Run tests locally** before pushing
8. **Review coverage reports** regularly

---

## Troubleshooting

### Tests Failing Locally

1. Check database is running
2. Verify environment variables are set
3. Clear test database: `pytest --create-db`
4. Check for port conflicts

### Slow Tests

1. Use `pytest -v --durations=10` to find slow tests
2. Mock external API calls
3. Use in-memory database for unit tests
4. Run tests in parallel: `pytest -n auto`

### Coverage Not Updating

1. Delete `.coverage` file
2. Delete `htmlcov/` directory
3. Run tests again with `--cov`

---

## Resources

- [Pytest Documentation](https://docs.pytest.org/)
- [Vitest Documentation](https://vitest.dev/)
- [Playwright Documentation](https://playwright.dev/)
- [Locust Documentation](https://docs.locust.io/)

