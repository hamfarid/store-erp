# WebSocket Documentation

**ملف:** `docs/WEBSOCKET.md`  
**الغرض:** توثيق استخدام WebSocket في النظام  
**آخر تحديث:** 2025-01-18

---

## نظرة عامة

يستخدم النظام WebSocket لتوفير تحديثات في الوقت الفعلي للوحة تحكم التعلم والبحث، وعمليات ML، والأسعار، والتنبيهات.

---

## الاتصال

### URL الاتصال

```
ws://localhost:3000/ws        # Development
wss://yourdomain.com/ws       # Production (HTTPS)
```

### مثال الاتصال (JavaScript)

```javascript
const ws = new WebSocket('ws://localhost:3000/ws');

ws.onopen = () => {
  console.log('Connected to WebSocket');
  
  // Authenticate with JWT token
  ws.send(JSON.stringify({
    type: 'auth',
    data: { token: 'your-jwt-token' }
  }));
  
  // Subscribe to channels
  ws.send(JSON.stringify({
    type: 'subscribe',
    channel: 'learning:operation:update'
  }));
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  console.log('Received:', message);
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};

ws.onclose = () => {
  console.log('WebSocket disconnected');
};
```

---

## المصادقة

### إرسال Token

```json
{
  "type": "auth",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### الاستجابة

**نجاح:**
```json
{
  "type": "authenticated",
  "data": {
    "userId": "user-123"
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

**فشل:**
```json
{
  "type": "error",
  "data": {
    "message": "Authentication failed: invalid token"
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

---

## القنوات المتاحة

### Learning & Search Operations

| Channel | الوصف | نوع الرسالة |
|---------|-------|-------------|
| `learning:operation:update` | تحديثات عمليات التعلم | `learning_operation_update` |
| `learning:operation:progress` | تقدم عمليات التعلم | `learning_operation_progress` |
| `search:operation:update` | تحديثات عمليات البحث | `search_operation_update` |
| `search:operation:progress` | تقدم عمليات البحث | `search_operation_progress` |
| `operation:log` | سجلات العمليات | `operation_log` |

### Keywords & Sources

| Channel | الوصف | نوع الرسالة |
|---------|-------|-------------|
| `keyword:update` | تحديثات الكلمات المفتاحية | `keyword_created`, `keyword_updated`, `keyword_deleted` |
| `source:update` | تحديثات المصادر | `source_created`, `source_updated`, `source_deleted` |

### Prices & Predictions

| Channel | الوصف | نوع الرسالة |
|---------|-------|-------------|
| `prices` | تحديثات الأسعار العامة | `price_update` |
| `prices:gold` | تحديثات سعر الذهب | `price_update` |
| `prices:silver` | تحديثات سعر الفضة | `price_update` |
| `predictions` | توقعات جديدة | `new_prediction` |

### ML & Training

| Channel | الوصف | نوع الرسالة |
|---------|-------|-------------|
| `ml:training` | تقدم تدريب النماذج | `training_progress` |
| `ml:drift` | كشف انحراف البيانات | `drift_detected` |

---

## أنواع الرسائل

### 1. Learning Operation Update

```json
{
  "type": "learning_operation_update",
  "channel": "learning:operation:update",
  "data": {
    "id": "op-123",
    "type": "pattern_detection",
    "status": "running",
    "progress": 45,
    "currentStep": "Analyzing patterns",
    "totalSteps": 10
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

### 2. Search Operation Update

```json
{
  "type": "search_operation_update",
  "channel": "search:operation:update",
  "data": {
    "id": "search-456",
    "type": "keyword_search",
    "status": "running",
    "progress": 60,
    "currentSource": "Google News",
    "sourcesProcessed": 3,
    "totalSources": 5,
    "resultsFound": 15
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

### 3. Operation Log

```json
{
  "type": "operation_log",
  "channel": "operation:log",
  "data": {
    "operationId": "op-123",
    "operationType": "learning",
    "level": "info",
    "message": "Pattern detection completed",
    "data": {
      "patternsFound": 5
    }
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

### 4. Keyword Update

```json
{
  "type": "keyword_created",
  "channel": "keyword:update",
  "data": {
    "id": 1,
    "keyword": "inflation",
    "category": "economic",
    "priority": "high",
    "enabled": true
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

---

## الاشتراك والاشتراك

### الاشتراك في قناة

```json
{
  "type": "subscribe",
  "channel": "learning:operation:update"
}
```

**الاستجابة:**
```json
{
  "type": "subscribed",
  "channel": "learning:operation:update",
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

### إلغاء الاشتراك

```json
{
  "type": "unsubscribe",
  "channel": "learning:operation:update"
}
```

**الاستجابة:**
```json
{
  "type": "unsubscribed",
  "channel": "learning:operation:update",
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

---

## استخدام React Hook

### مثال استخدام `useWebSocket`

```typescript
import { useWebSocket } from '@/hooks/useWebSocket';

function LearningDashboard() {
  const { isConnected, subscribe, lastMessage } = useWebSocket({
    autoConnect: true,
    onMessage: (message) => {
      console.log('Received:', message);
    }
  });

  useEffect(() => {
    if (isConnected) {
      // Subscribe to learning operation updates
      const unsubscribe = subscribe('learning:operation:update', (message) => {
        if (message.type === 'learning_operation_update') {
          // Update UI with operation data
          updateOperation(message.data);
        }
      });

      return () => {
        unsubscribe();
      };
    }
  }, [isConnected, subscribe]);

  return (
    <div>
      {isConnected ? (
        <div>Connected to WebSocket</div>
      ) : (
        <div>Connecting...</div>
      )}
    </div>
  );
}
```

---

## Heartbeat & Reconnection

### Heartbeat

الخادم يرسل ping كل 30 ثانية. يجب على العميل الرد بـ pong.

### إعادة الاتصال التلقائي

Hook `useWebSocket` يوفر إعادة اتصال تلقائية مع:
- Exponential backoff (زيادة تدريجية في وقت الانتظار)
- حد أقصى 10 محاولات
- إعادة إرسال الرسائل المعلقة عند الاتصال

---

## الأمان

### JWT Authentication

- يجب إرسال JWT token بعد الاتصال
- Token يتم التحقق منه باستخدام `JWT_SECRET`
- المستخدمون غير المصادقين يمكنهم الاتصال لكن مع قيود

### Rate Limiting

- حد أقصى 100 رسالة في الدقيقة لكل اتصال
- الاتصالات المفرطة يتم إغلاقها تلقائياً

---

## معالجة الأخطاء

### أنواع الأخطاء

```json
{
  "type": "error",
  "data": {
    "message": "Invalid channel name",
    "code": "INVALID_CHANNEL"
  },
  "timestamp": "2025-01-18T10:00:00.000Z"
}
```

### رموز الأخطاء

- `INVALID_CHANNEL` - اسم القناة غير صحيح
- `AUTH_FAILED` - فشل المصادقة
- `RATE_LIMIT` - تجاوز حد المعدل
- `SERVER_ERROR` - خطأ في الخادم

---

## أمثلة متقدمة

### متعدد القنوات

```javascript
const channels = [
  'learning:operation:update',
  'search:operation:update',
  'operation:log'
];

channels.forEach(channel => {
  ws.send(JSON.stringify({
    type: 'subscribe',
    channel
  }));
});
```

### تصفية الرسائل

```javascript
ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  // Filter by operation ID
  if (message.data?.operationId === 'op-123') {
    handleOperationUpdate(message);
  }
  
  // Filter by level
  if (message.data?.level === 'error') {
    showError(message.data.message);
  }
};
```

---

## استكشاف الأخطاء

### مشاكل شائعة

1. **الاتصال يفشل**
   - تحقق من URL (ws:// vs wss://)
   - تحقق من أن الخادم يعمل
   - تحقق من CORS settings

2. **لا تصل الرسائل**
   - تأكد من الاشتراك في القناة
   - تحقق من المصادقة
   - تحقق من console للأخطاء

3. **الاتصال ينقطع**
   - تحقق من Heartbeat
   - تحقق من Network stability
   - Hook `useWebSocket` يعيد الاتصال تلقائياً

---

## مراجع

- **ملف الخادم:** `server/_core/websocket.ts`
- **Hook العميل:** `client/src/hooks/useWebSocket.ts`
- **لوحة التحكم:** `client/src/pages/LearningControlDashboard.tsx`

---

**آخر تحديث:** 2025-01-18

