# Migration Guide - Events & Learning System

**ملف:** `docs/MIGRATION_GUIDE.md`  
**الغرض:** دليل Migration لنظام Events & Learning  
**آخر تحديث:** 2025-01-18

---

## نظرة عامة

هذا الدليل يشرح كيفية تطبيق تغييرات قاعدة البيانات الجديدة لنظام Events & Learning.

---

## المتطلبات

- Node.js 22+
- pnpm 10+
- MySQL/TiDB أو SQLite
- Drizzle ORM

---

## خطوات Migration

### 1. النسخ الاحتياطي

**قبل أي migration، قم بعمل backup:**

```bash
# MySQL
mysqldump -u user -p database_name > backup_$(date +%Y%m%d).sql

# SQLite
cp database.db database_backup_$(date +%Y%m%d).db
```

---

### 2. تحديث Dependencies

```bash
pnpm install
```

---

### 3. تطبيق Schema Changes

#### الطريقة 1: Push مباشر (موصى به للتطوير)

```bash
# تطبيق جميع التغييرات مباشرة
pnpm db:push
```

**ملاحظة:** هذه الطريقة تطبق التغييرات مباشرة بدون إنشاء ملفات migration.

---

#### الطريقة 2: Generate Migrations (موصى به للإنتاج)

```bash
# إنشاء ملفات migration
pnpm db:generate

# مراجعة الملفات المُنشأة في drizzle/
# ثم تطبيقها
pnpm db:migrate
```

---

### 4. التحقق من التطبيق

```bash
# التحقق من الاتصال
pnpm db:studio  # إذا كان متاحاً

# أو التحقق يدوياً
mysql -u user -p database_name -e "SHOW TABLES;"
```

**الجداول المتوقعة:**
- `events`
- `event_analyses`
- `event_price_impacts`
- `prediction_comparisons`
- `learning_insights`
- `model_adjustments`
- `chart_snapshots`
- `search_keywords`
- `search_sources`
- `learning_operations`
- `search_operations`
- `operation_logs`

---

## Schema Changes Details

### الجداول الجديدة

#### Events Tables

1. **`events`**
   - Primary Key: `id` (varchar 64)
   - Indexes: `eventType`, `eventDate`, `severity`, `createdAt`

2. **`event_analyses`**
   - Foreign Key: `eventId` → `events.id`
   - Indexes: `eventId`, `sentiment`, `analysisDate`

3. **`event_price_impacts`**
   - Foreign Keys: `eventId` → `events.id`, `historicalPriceId` → `historicalPrices.id`
   - Indexes: `eventId`, `historicalPriceId`, `assetId`

4. **`prediction_comparisons`**
   - Foreign Key: `predictionId` → `predictions.id`
   - Indexes: `predictionId`, `comparedAt`

5. **`learning_insights`**
   - Indexes: `type`, `status`, `createdAt`

6. **`model_adjustments`**
   - Foreign Key: `insightId` → `learning_insights.id`
   - Indexes: `insightId`, `status`, `createdAt`

7. **`chart_snapshots`**
   - Indexes: `chartType`, `relatedAssetId`, `createdAt`

#### Learning Control Tables

8. **`search_keywords`**
   - Unique: `keyword`
   - Indexes: `category`, `priority`, `enabled`

9. **`search_sources`**
   - Indexes: `type`, `enabled`

10. **`learning_operations`**
    - Primary Key: `id` (varchar 64)
    - Indexes: `type`, `status`, `createdAt`

11. **`search_operations`**
    - Primary Key: `id` (varchar 64)
    - Indexes: `type`, `status`, `createdAt`

12. **`operation_logs`**
    - Foreign Key: `operationId` (references learning_operations or search_operations)
    - Indexes: `operationId`, `level`, `timestamp`

---

## Rollback Procedures

### إذا فشل Migration

#### MySQL

```sql
-- حذف الجداول الجديدة (بحذر!)
DROP TABLE IF EXISTS operation_logs;
DROP TABLE IF EXISTS search_operations;
DROP TABLE IF EXISTS learning_operations;
DROP TABLE IF EXISTS search_sources;
DROP TABLE IF EXISTS search_keywords;
DROP TABLE IF EXISTS chart_snapshots;
DROP TABLE IF EXISTS model_adjustments;
DROP TABLE IF EXISTS learning_insights;
DROP TABLE IF EXISTS prediction_comparisons;
DROP TABLE IF EXISTS event_price_impacts;
DROP TABLE IF EXISTS event_analyses;
DROP TABLE IF EXISTS events;
```

#### SQLite

```bash
# استعادة من backup
cp database_backup_YYYYMMDD.db database.db
```

---

## Data Migration (إذا لزم الأمر)

### Migrate Existing Data

إذا كان لديك بيانات موجودة تحتاج للترحيل:

```typescript
// مثال: ترحيل التوقعات القديمة إلى prediction_comparisons
import { getDb } from './server/db';
import { predictions } from './drizzle/schema';
import { createComparison } from './server/services/learning/predictionsDb';

async function migrateOldPredictions() {
  const db = await getDb();
  const oldPredictions = await db.select().from(predictions);
  
  for (const pred of oldPredictions) {
    // إذا كان هناك actualPrice
    if (pred.actualPrice) {
      await createComparison({
        predictionId: pred.id,
        actualPrice: pred.actualPrice,
        predictedPrice: pred.predictedPrice,
        // حساب accuracy, error, etc.
      });
    }
  }
}
```

---

## Verification Steps

### 1. التحقق من الجداول

```sql
-- MySQL
SHOW TABLES LIKE '%event%';
SHOW TABLES LIKE '%learning%';
SHOW TABLES LIKE '%search%';
```

### 2. التحقق من Indexes

```sql
SHOW INDEXES FROM events;
SHOW INDEXES FROM learning_operations;
```

### 3. التحقق من Foreign Keys

```sql
SELECT 
  TABLE_NAME,
  CONSTRAINT_NAME,
  REFERENCED_TABLE_NAME,
  REFERENCED_COLUMN_NAME
FROM
  INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE
  REFERENCED_TABLE_SCHEMA = 'your_database_name'
  AND TABLE_NAME IN ('event_analyses', 'event_price_impacts', 'prediction_comparisons');
```

### 4. اختبار CRUD Operations

```typescript
// اختبار إنشاء حدث
const event = await trpc.events.create.mutate({
  title: "Test Event",
  eventType: "economic",
  eventDate: new Date().toISOString()
});

// اختبار إنشاء keyword
const keyword = await trpc.learningControl.keywords.create.mutate({
  keyword: "test-keyword",
  category: "economic"
});
```

---

## Troubleshooting

### مشكلة: Foreign Key Constraint Fails

**السبب:** الجدول المرجعي غير موجود

**الحل:**
```sql
-- التحقق من وجود الجدول المرجعي
SHOW TABLES LIKE 'historicalPrices';

-- إذا لم يكن موجوداً، تأكد من تطبيق schema.ts أولاً
```

---

### مشكلة: Column Already Exists

**السبب:** Migration تم تطبيقه مسبقاً

**الحل:**
```bash
# التحقق من حالة Migration
pnpm db:status

# إذا كان Migration مطبقاً بالفعل، لا حاجة لإعادة التطبيق
```

---

### مشكلة: JSON Column Type Error

**السبب:** MySQL قد لا يدعم JSON type في إصدارات قديمة

**الحل:**
- استخدم `TEXT` بدلاً من `JSON`
- Drizzle سيتعامل مع التحويل تلقائياً

---

## Production Deployment

### خطوات الإنتاج

1. **Backup Production Database**
   ```bash
   mysqldump -u user -p production_db > backup_prod_$(date +%Y%m%d).sql
   ```

2. **Test Migration on Staging**
   ```bash
   # تطبيق على staging أولاً
   DATABASE_URL=staging_url pnpm db:push
   ```

3. **Verify Staging**
   - اختبار جميع endpoints
   - التحقق من البيانات
   - اختبار الأداء

4. **Apply to Production**
   ```bash
   DATABASE_URL=production_url pnpm db:push
   ```

5. **Monitor**
   - مراقبة الأخطاء
   - مراقبة الأداء
   - التحقق من البيانات

---

## Environment Variables

تأكد من وجود المتغيرات التالية:

```env
DATABASE_URL=mysql://user:password@host:port/database
# أو
DATABASE_URL=file:./database.db  # للـ SQLite
```

---

## Post-Migration Checklist

- [ ] جميع الجداول موجودة
- [ ] جميع Indexes موجودة
- [ ] جميع Foreign Keys موجودة
- [ ] اختبار CRUD operations
- [ ] اختبار WebSocket connections
- [ ] اختبار Dashboard
- [ ] مراجعة Logs للأخطاء
- [ ] Backup جديد بعد Migration

---

## Support

إذا واجهت مشاكل:

1. راجع Logs في `server/logs/`
2. تحقق من `COMPREHENSIVE_TODO.md`
3. راجع `docs/ARCHITECTURE.md`
4. افتح Issue في GitHub

---

**آخر تحديث:** 2025-01-18

