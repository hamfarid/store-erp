# دليل نظام التصميم المتسق
# Design System Guide

## نظرة عامة

تم إنشاء نظام تصميم شامل لضمان اتساق التصميم عبر جميع الصفحات، مع إضافة رسوم متحركة سلسة وتصميم متجاوب بالكامل لجميع الأجهزة.

## المكونات الجديدة

### 1. Animation Components

#### FadeIn
مكون للرسوم المتحركة fade-in:

```tsx
import { FadeIn } from "@/components/animations";

<FadeIn delay={0.2} duration={0.5}>
  <Card>Content</Card>
</FadeIn>
```

#### SlideUp
مكون للرسوم المتحركة slide-up:

```tsx
import { SlideUp } from "@/components/animations";

<SlideUp delay={0.1} distance={30}>
  <Card>Content</Card>
</SlideUp>
```

#### Stagger
مكون للرسوم المتحركة المتتالية (staggered):

```tsx
import { Stagger } from "@/components/animations";

<Stagger>
  {items.map(item => (
    <Card key={item.id}>{item.content}</Card>
  ))}
</Stagger>
```

### 2. Animated UI Components

#### AnimatedCard
بطاقة مع رسوم متحركة مدمجة:

```tsx
import { AnimatedCard } from "@/components/ui/card-animated";

<AnimatedCard
  title="Title"
  description="Description"
  delay={0.2}
  hover={true}
>
  Content
</AnimatedCard>
```

#### AnimatedButton
زر مع رسوم متحركة وحالة تحميل:

```tsx
import { AnimatedButton } from "@/components/ui/button-animated";

<AnimatedButton
  loading={isLoading}
  delay={0.1}
  onClick={handleClick}
>
  Click Me
</AnimatedButton>
```

### 3. PageLayout Enhanced

تم تحسين `PageLayout` ليشمل:
- رسوم متحركة تلقائية للرأس والمحتوى
- تصميم متجاوب محسن
- دعم كامل للشاشات الصغيرة

```tsx
import { PageLayout } from "@/components/PageLayout";

<PageLayout
  title="Page Title"
  description="Page description"
  breadcrumbs={[
    { label: "Home", href: "/" },
    { label: "Current Page" }
  ]}
  actions={<Button>Action</Button>}
>
  Page content
</PageLayout>
```

## CSS Utilities

### Animation Classes

```css
.transition-smooth    /* Smooth transition */
.transition-fast      /* Fast transition */
.transition-slow      /* Slow transition */
.hover-lift           /* Lift on hover */
.hover-scale          /* Scale on hover */
.hover-glow           /* Glow on hover */
.animate-fade-in      /* Fade in animation */
.animate-slide-up     /* Slide up animation */
.animate-card-enter   /* Card entrance animation */
```

### Responsive Classes

```css
.container-responsive      /* Responsive container */
.grid-responsive          /* Responsive grid */
.flex-responsive          /* Responsive flex */
.text-responsive          /* Responsive text */
.heading-responsive       /* Responsive heading */
.spacing-responsive       /* Responsive spacing */
.card-responsive          /* Responsive card */
.button-responsive        /* Responsive button */
.stats-grid-responsive    /* Responsive stats grid */
```

### Hide/Show Utilities

```css
.hide-mobile      /* Hide on mobile */
.show-mobile      /* Show on mobile */
.hide-tablet      /* Hide on tablet */
.show-tablet      /* Show on tablet */
```

## Best Practices

### 1. استخدام PageLayout

**✅ DO:**
```tsx
<PageLayout
  title="Dashboard"
  description="Your dashboard"
  breadcrumbs={breadcrumbs}
>
  Content
</PageLayout>
```

**❌ DON'T:**
```tsx
<div className="min-h-screen">
  <header>...</header>
  <main>...</main>
</div>
```

### 2. استخدام Animations

**✅ DO:**
```tsx
<Stagger>
  {items.map(item => (
    <FadeIn key={item.id} delay={0.1}>
      <Card>{item.content}</Card>
    </FadeIn>
  ))}
</Stagger>
```

**❌ DON'T:**
```tsx
{items.map(item => (
  <Card key={item.id}>{item.content}</Card>
))}
```

### 3. Responsive Design

**✅ DO:**
```tsx
<div className="grid-responsive grid-auto-responsive">
  {items.map(item => (
    <AnimatedCard key={item.id}>{item.content}</AnimatedCard>
  ))}
</div>
```

**❌ DON'T:**
```tsx
<div className="grid grid-cols-4">
  {items.map(item => (
    <Card key={item.id}>{item.content}</Card>
  ))}
</div>
```

## Breakpoints

- **Mobile**: `< 640px`
- **Tablet**: `641px - 1024px`
- **Desktop**: `> 1025px`

## Accessibility

- جميع الرسوم المتحركة تحترم `prefers-reduced-motion`
- أهداف اللمس بحد أدنى 44x44px
- Focus indicators واضحة
- دعم كامل للوحة المفاتيح

## Performance

- استخدام `will-change` بحذر
- تقليل عدد الرسوم المتحركة المتزامنة
- استخدام `transform` و `opacity` للرسوم المتحركة
- تجنب الرسوم المتحركة على `width` و `height`

## Examples

### صفحة بسيطة مع PageLayout

```tsx
import { PageLayout } from "@/components/PageLayout";
import { FadeIn } from "@/components/animations";

export default function MyPage() {
  return (
    <PageLayout
      title="My Page"
      description="Page description"
      breadcrumbs={[
        { label: "Home", href: "/" },
        { label: "My Page" }
      ]}
    >
      <FadeIn>
        <Card>Content</Card>
      </FadeIn>
    </PageLayout>
  );
}
```

### صفحة مع Grid متجاوب

```tsx
import { PageLayout } from "@/components/PageLayout";
import { Stagger } from "@/components/animations";
import { AnimatedCard } from "@/components/ui/card-animated";

export default function GridPage() {
  const items = [...];

  return (
    <PageLayout title="Grid Page">
      <div className="grid-responsive grid-auto-responsive">
        <Stagger>
          {items.map((item, index) => (
            <AnimatedCard
              key={item.id}
              title={item.title}
              delay={index * 0.1}
            >
              {item.content}
            </AnimatedCard>
          ))}
        </Stagger>
      </div>
    </PageLayout>
  );
}
```

## Migration Guide

### تحديث صفحة موجودة

1. استبدل الهيكل اليدوي بـ `PageLayout`
2. أضف `FadeIn` أو `SlideUp` للمحتوى
3. استبدل `Card` بـ `AnimatedCard` عند الحاجة
4. استخدم CSS utilities للتصميم المتجاوب
5. اختبر على أجهزة مختلفة

## Support

للمساعدة أو الأسئلة، راجع:
- `client/src/components/animations/` - Animation components
- `client/src/styles/animations.css` - Animation styles
- `client/src/styles/responsive-enhancements.css` - Responsive utilities

