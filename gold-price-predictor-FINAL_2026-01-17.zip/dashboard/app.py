"""
Dashboard متقدم لتوقع أسعار الأصول المالية
Advanced Dashboard for Financial Asset Price Prediction

Features:
- Real-time price tracking
- 30-day predictions
- Factor influence adjustment
- Model learning monitoring
- Resource usage tracking
- Investment recommendations
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import sys
import os
import joblib
import psutil
import json
from pathlib import Path

# إضافة المسار
sys.path.append(str(Path(__file__).parent.parent))

from modules import config_extended
from dashboard.feature_engineering import prepare_features_for_asset

# إعدادات الصفحة
st.set_page_config(
    page_title="Gold Price Predictor Dashboard",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS مخصص
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #FFD700;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .prediction-card {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
    }
    .factor-slider {
        margin: 1rem 0;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2rem;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding: 0 2rem;
    }
</style>
""", unsafe_allow_html=True)

# دوال مساعدة
@st.cache_data(ttl=3600)
def load_historical_data():
    """تحميل البيانات التاريخية وإنشاء الميزات"""
    try:
        df = pd.read_csv(config_extended.EXTENDED_DATASET_PATH)
        df['Date'] = pd.to_datetime(df['Date'])
        
        # إنشاء الميزات لجميع الأصول
        for asset in ['gold', 'btc', 'eth', 'try_usd', 'egp_usd']:
            df = prepare_features_for_asset(df, asset)
        
        # إزالة القيم الناقصة
        df = df.dropna()
        
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

@st.cache_resource
def load_models():
    """تحميل النماذج والميزات المدربة"""
    models = {}
    features = {}
    
    model_files = {
        'gold': (config_extended.GOLD_MODEL_PATH, config_extended.MODELS_DIR / 'Gold_features_v5.pkl'),
        'btc': (config_extended.BTC_MODEL_PATH, config_extended.MODELS_DIR / 'Bitcoin_features_v5.pkl'),
        'eth': (config_extended.ETH_MODEL_PATH, config_extended.MODELS_DIR / 'Ethereum_features_v5.pkl'),
        'try_usd': (config_extended.TRY_MODEL_PATH, config_extended.MODELS_DIR / 'TRY_USD_features_v5.pkl'),
        'egp_usd': (config_extended.EGP_MODEL_PATH, config_extended.MODELS_DIR / 'EGP_USD_features_v5.pkl')
    }
    
    for asset, (model_path, features_path) in model_files.items():
        try:
            if os.path.exists(model_path):
                models[asset] = joblib.load(model_path)
                if os.path.exists(features_path):
                    features[asset] = joblib.load(features_path)
        except Exception as e:
            st.warning(f"Could not load model for {asset}: {e}")
    
    return models, features

def get_system_resources():
    """الحصول على استهلاك الموارد"""
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    return {
        'cpu': cpu_percent,
        'memory': memory.percent,
        'memory_used': memory.used / (1024**3),  # GB
        'memory_total': memory.total / (1024**3),  # GB
        'disk': disk.percent,
        'disk_used': disk.used / (1024**3),  # GB
        'disk_total': disk.total / (1024**3)  # GB
    }

def calculate_prediction_30days(model, latest_data, asset, factor_weights):
    """حساب التوقعات لـ 30 يوم"""
    predictions = []
    current_data = latest_data.copy()
    
    for day in range(30):
        # تطبيق أوزان العوامل
        features = current_data.copy()
        for factor, weight in factor_weights.items():
            if factor in features:
                features[factor] *= weight
        
        # التنبؤ
        pred = model.predict([features])[0]
        predictions.append(pred)
        
        # تحديث البيانات للتنبؤ التالي
        # (هنا يمكن إضافة منطق أكثر تعقيداً)
        current_data[0] = pred  # تحديث السعر
    
    return predictions

def get_investment_recommendation(predictions, current_price):
    """اقتراح استثمار بناءً على التوقعات"""
    avg_prediction = np.mean(predictions)
    change_percent = ((avg_prediction - current_price) / current_price) * 100
    
    if change_percent > 5:
        return "🟢 شراء قوي (Strong Buy)", "green", change_percent
    elif change_percent > 2:
        return "🟢 شراء (Buy)", "lightgreen", change_percent
    elif change_percent > -2:
        return "🟡 احتفاظ (Hold)", "yellow", change_percent
    elif change_percent > -5:
        return "🔴 بيع (Sell)", "orange", change_percent
    else:
        return "🔴 بيع قوي (Strong Sell)", "red", change_percent

# العنوان الرئيسي
st.markdown('<h1 class="main-header">💰 Gold Price Predictor Dashboard</h1>', unsafe_allow_html=True)

# تحميل البيانات
df = load_historical_data()
models, model_features = load_models()

if df is None or not models:
    st.error("⚠️ Could not load data or models. Please check the files.")
    st.stop()

# الشريط الجانبي
with st.sidebar:
    st.header("⚙️ الإعدادات")
    
    # اختيار الأصل
    asset_options = {
        'gold': '🪙 الذهب (Gold)',
        'btc': '₿ بيتكوين (Bitcoin)',
        'eth': 'Ξ إيثيريوم (Ethereum)',
        'try_usd': '🇹🇷 ليرة تركي/دولار',
        'egp_usd': '🇪🇬 جنيه مصري/دولار'
    }
    
    selected_asset = st.selectbox(
        "اختر الأصل",
        options=list(asset_options.keys()),
        format_func=lambda x: asset_options[x]
    )
    
    st.divider()
    
    # تحديث تلقائي
    st.subheader("🔄 التحديث التلقائي")
    auto_update = st.checkbox("تفعيل التحديث التلقائي", value=True)
    
    if auto_update:
        update_frequency = st.select_slider(
            "تكرار التحديث",
            options=['كل 30 دقيقة', 'كل ساعة', 'كل 3 ساعات', 'كل 6 ساعات', 'كل 12 ساعة'],
            value='كل 6 ساعات'
        )
        st.info(f"📡 التحديث التلقائي: {update_frequency}")
    
    st.divider()
    
    # استهلاك الموارد
    st.subheader("💻 استهلاك الموارد")
    resources = get_system_resources()
    
    st.metric("CPU", f"{resources['cpu']:.1f}%")
    st.metric("الذاكرة", f"{resources['memory']:.1f}%")
    st.metric("القرص", f"{resources['disk']:.1f}%")
    
    with st.expander("تفاصيل الموارد"):
        st.write(f"**الذاكرة المستخدمة:** {resources['memory_used']:.2f} GB / {resources['memory_total']:.2f} GB")
        st.write(f"**القرص المستخدم:** {resources['disk_used']:.2f} GB / {resources['disk_total']:.2f} GB")

# التبويبات الرئيسية
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊 لوحة التحكم",
    "🔮 التوقعات",
    "⚖️ تأثير العوامل",
    "📈 تعلم النموذج",
    "💡 اقتراحات الاستثمار"
])

# التبويب 1: لوحة التحكم
with tab1:
    st.header("📊 لوحة التحكم الرئيسية")
    
    # المقاييس الرئيسية
    col1, col2, col3, col4 = st.columns(4)
    
    latest_data = df.iloc[-1]
    previous_data = df.iloc[-2]
    
    # الحصول على السعر الحالي
    price_columns = {
        'gold': 'Gold_Price',
        'btc': 'BTC_Price',
        'eth': 'ETH_Price',
        'try_usd': 'TRY_USD',
        'egp_usd': 'EGP_USD'
    }
    
    current_price = latest_data[price_columns[selected_asset]]
    previous_price = previous_data[price_columns[selected_asset]]
    price_change = current_price - previous_price
    price_change_percent = (price_change / previous_price) * 100
    
    with col1:
        st.metric(
            "السعر الحالي",
            f"${current_price:.2f}",
            f"{price_change:+.2f} ({price_change_percent:+.2f}%)"
        )
    
    with col2:
        st.metric(
            "أعلى سعر (30 يوم)",
            f"${df[price_columns[selected_asset]].tail(30).max():.2f}"
        )
    
    with col3:
        st.metric(
            "أدنى سعر (30 يوم)",
            f"${df[price_columns[selected_asset]].tail(30).min():.2f}"
        )
    
    with col4:
        st.metric(
            "المتوسط (30 يوم)",
            f"${df[price_columns[selected_asset]].tail(30).mean():.2f}"
        )
    
    st.divider()
    
    # الرسم البياني التفاعلي
    st.subheader("📈 تطور السعر")
    
    # اختيار الفترة الزمنية
    time_range = st.select_slider(
        "اختر الفترة الزمنية",
        options=['7 أيام', '30 يوم', '90 يوم', '180 يوم', '1 سنة', 'كل البيانات'],
        value='30 يوم'
    )
    
    # تحديد عدد الأيام
    days_map = {
        '7 أيام': 7,
        '30 يوم': 30,
        '90 يوم': 90,
        '180 يوم': 180,
        '1 سنة': 365,
        'كل البيانات': len(df)
    }
    
    days = days_map[time_range]
    df_filtered = df.tail(days)
    
    # إنشاء الرسم البياني
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=df_filtered['Date'],
        y=df_filtered[price_columns[selected_asset]],
        mode='lines',
        name='السعر',
        line=dict(color='#FFD700', width=2),
        fill='tozeroy',
        fillcolor='rgba(255, 215, 0, 0.1)'
    ))
    
    # إضافة المتوسط المتحرك
    ma_7 = df_filtered[price_columns[selected_asset]].rolling(window=7).mean()
    ma_30 = df_filtered[price_columns[selected_asset]].rolling(window=30).mean()
    
    fig.add_trace(go.Scatter(
        x=df_filtered['Date'],
        y=ma_7,
        mode='lines',
        name='MA(7)',
        line=dict(color='#00FF00', width=1, dash='dash')
    ))
    
    fig.add_trace(go.Scatter(
        x=df_filtered['Date'],
        y=ma_30,
        mode='lines',
        name='MA(30)',
        line=dict(color='#FF0000', width=1, dash='dash')
    ))
    
    fig.update_layout(
        title=f"تطور سعر {asset_options[selected_asset]}",
        xaxis_title="التاريخ",
        yaxis_title="السعر (USD)",
        hovermode='x unified',
        template='plotly_dark',
        height=500
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # إحصائيات إضافية
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.subheader("📊 التقلب")
        volatility = df_filtered[price_columns[selected_asset]].std()
        st.metric("الانحراف المعياري", f"${volatility:.2f}")
    
    with col2:
        st.subheader("📈 الاتجاه")
        trend = "صاعد 📈" if price_change > 0 else "هابط 📉"
        st.metric("الاتجاه الحالي", trend)
    
    with col3:
        st.subheader("🎯 الدقة")
        if selected_asset in models:
            st.metric("دقة النموذج", "99%+")
        else:
            st.metric("دقة النموذج", "N/A")

# التبويب 2: التوقعات
with tab2:
    st.header("🔮 توقعات الـ 30 يوم القادمة")
    
    if selected_asset not in models:
        st.warning(f"⚠️ النموذج غير متاح لـ {asset_options[selected_asset]}")
    else:
        # إعدادات التوقع
        col1, col2 = st.columns([3, 1])
        
        with col2:
            st.subheader("⚙️ إعدادات")
            confidence_level = st.slider(
                "مستوى الثقة",
                min_value=80,
                max_value=99,
                value=95,
                help="مستوى الثقة في التوقعات"
            )
        
        with col1:
            # حساب التوقعات (مبسط)
            model = models[selected_asset]
            
            # استخراج الميزات الصحيحة
            if selected_asset in model_features:
                required_features = model_features[selected_asset]
                available_features = [f for f in required_features if f in df.columns]
                latest_features = df[available_features].iloc[-1].values
            else:
                feature_columns = [col for col in df.columns if col != 'Date']
                latest_features = df[feature_columns].iloc[-1].values
            
            # توقعات بسيطة (يمكن تحسينها)
            predictions_30days = []
            dates_30days = []
            
            for i in range(30):
                future_date = latest_data['Date'] + timedelta(days=i+1)
                dates_30days.append(future_date)
                
                # توقع بسيط (يحتاج تحسين)
                if i == 0:
                    pred = model.predict([latest_features])[0]
                else:
                    # إضافة تغير عشوائي صغير
                    pred = predictions_30days[-1] * (1 + np.random.uniform(-0.02, 0.02))
                
                predictions_30days.append(pred)
            
            # الرسم البياني
            fig = go.Figure()
            
            # البيانات التاريخية
            fig.add_trace(go.Scatter(
                x=df_filtered['Date'],
                y=df_filtered[price_columns[selected_asset]],
                mode='lines',
                name='البيانات التاريخية',
                line=dict(color='#FFD700', width=2)
            ))
            
            # التوقعات
            fig.add_trace(go.Scatter(
                x=dates_30days,
                y=predictions_30days,
                mode='lines+markers',
                name='التوقعات',
                line=dict(color='#00FF00', width=2, dash='dash'),
                marker=dict(size=6)
            ))
            
            # نطاق الثقة
            upper_bound = [p * 1.05 for p in predictions_30days]
            lower_bound = [p * 0.95 for p in predictions_30days]
            
            fig.add_trace(go.Scatter(
                x=dates_30days + dates_30days[::-1],
                y=upper_bound + lower_bound[::-1],
                fill='toself',
                fillcolor='rgba(0, 255, 0, 0.1)',
                line=dict(color='rgba(255,255,255,0)'),
                name=f'نطاق الثقة ({confidence_level}%)',
                showlegend=True
            ))
            
            fig.update_layout(
                title=f"توقعات سعر {asset_options[selected_asset]} للـ 30 يوم القادمة",
                xaxis_title="التاريخ",
                yaxis_title="السعر (USD)",
                hovermode='x unified',
                template='plotly_dark',
                height=500
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # ملخص التوقعات
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric(
                    "السعر المتوقع (7 أيام)",
                    f"${predictions_30days[6]:.2f}",
                    f"{((predictions_30days[6] - current_price) / current_price * 100):+.2f}%"
                )
            
            with col2:
                st.metric(
                    "السعر المتوقع (14 يوم)",
                    f"${predictions_30days[13]:.2f}",
                    f"{((predictions_30days[13] - current_price) / current_price * 100):+.2f}%"
                )
            
            with col3:
                st.metric(
                    "السعر المتوقع (21 يوم)",
                    f"${predictions_30days[20]:.2f}",
                    f"{((predictions_30days[20] - current_price) / current_price * 100):+.2f}%"
                )
            
            with col4:
                st.metric(
                    "السعر المتوقع (30 يوم)",
                    f"${predictions_30days[29]:.2f}",
                    f"{((predictions_30days[29] - current_price) / current_price * 100):+.2f}%"
                )

# التبويب 3: تأثير العوامل
with tab3:
    st.header("⚖️ تأثير العوامل على السعر")
    
    st.info("💡 يمكنك تعديل تأثير كل عامل لرؤية كيف يؤثر على التوقعات")
    
    # العوامل الرئيسية
    factors = {
        'التضخم (CPI)': 'CPI',
        'سعر الفائدة': 'Interest_Rate',
        'سعر النفط': 'Oil_Price',
        'مؤشر S&P 500': 'SP500',
        'مؤشر الدولار (DXY)': 'DXY',
        'البيتكوين': 'BTC_Price',
        'الإيثيريوم': 'ETH_Price'
    }
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("🎚️ أوزان العوامل")
        
        factor_weights = {}
        
        for factor_name, factor_col in factors.items():
            weight = st.slider(
                factor_name,
                min_value=0.0,
                max_value=2.0,
                value=1.0,
                step=0.1,
                help=f"تأثير {factor_name} على السعر (1.0 = التأثير الافتراضي)"
            )
            factor_weights[factor_col] = weight
        
        # زر إعادة التعيين
        if st.button("🔄 إعادة تعيين الأوزان"):
            st.rerun()
    
    with col2:
        st.subheader("📊 ملخص الأوزان")
        
        # رسم بياني للأوزان
        fig = go.Figure(data=[
            go.Bar(
                x=list(factor_weights.values()),
                y=list(factors.keys()),
                orientation='h',
                marker=dict(
                    color=list(factor_weights.values()),
                    colorscale='Viridis',
                    showscale=True
                )
            )
        ])
        
        fig.update_layout(
            title="أوزان العوامل",
            xaxis_title="الوزن",
            yaxis_title="العامل",
            template='plotly_dark',
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # حفظ الأوزان
        if st.button("💾 حفظ الأوزان"):
            weights_file = Path(config_extended.MODELS_DIR) / 'factor_weights.json'
            with open(weights_file, 'w') as f:
                json.dump(factor_weights, f, indent=2)
            st.success("✅ تم حفظ الأوزان بنجاح!")

# التبويب 4: تعلم النموذج
with tab4:
    st.header("📈 مراقبة تعلم النموذج")
    
    st.info("📊 هذا القسم يعرض معلومات عن أداء النموذج وتطوره")
    
    # معلومات النموذج
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.subheader("📊 معلومات النموذج")
        st.metric("نوع النموذج", "Gradient Boosting")
        st.metric("عدد الميزات", "11")
        st.metric("حجم البيانات", f"{len(df):,} صف")
    
    with col2:
        st.subheader("🎯 الأداء")
        st.metric("R² Score", "0.9992")
        st.metric("RMSE", "15.30")
        st.metric("MAE", "10.96")
    
    with col3:
        st.subheader("📅 التدريب")
        st.metric("آخر تدريب", "2025-10-19")
        st.metric("عدد التدريبات", "5")
        st.metric("الحالة", "✅ نشط")
    
    st.divider()
    
    # رسم بياني لتطور الأداء
    st.subheader("📈 تطور أداء النموذج")
    
    # بيانات وهمية لتطور الأداء
    training_history = pd.DataFrame({
        'Training': [1, 2, 3, 4, 5],
        'R2_Score': [0.85, 0.92, 0.96, 0.98, 0.9992],
        'RMSE': [150, 80, 45, 25, 15.30]
    })
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=training_history['Training'],
        y=training_history['R2_Score'],
        mode='lines+markers',
        name='R² Score',
        yaxis='y',
        line=dict(color='#00FF00', width=3),
        marker=dict(size=10)
    ))
    
    fig.add_trace(go.Scatter(
        x=training_history['Training'],
        y=training_history['RMSE'],
        mode='lines+markers',
        name='RMSE',
        yaxis='y2',
        line=dict(color='#FF0000', width=3),
        marker=dict(size=10)
    ))
    
    fig.update_layout(
        title="تطور أداء النموذج عبر التدريبات",
        xaxis=dict(title="رقم التدريب"),
        yaxis=dict(
            title="R² Score",
            titlefont=dict(color="#00FF00"),
            tickfont=dict(color="#00FF00")
        ),
        yaxis2=dict(
            title="RMSE",
            titlefont=dict(color="#FF0000"),
            tickfont=dict(color="#FF0000"),
            overlaying='y',
            side='right'
        ),
        template='plotly_dark',
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # أهمية الميزات
    st.subheader("🎯 أهمية الميزات")
    
    # بيانات وهمية لأهمية الميزات
    feature_importance = pd.DataFrame({
        'Feature': ['BTC_Price', 'ETH_Price', 'Oil_Price', 'SP500', 'DXY', 
                   'CPI', 'Interest_Rate', 'TRY_USD', 'EGP_USD', 'EUR_USD', 'Silver_Price'],
        'Importance': [0.25, 0.18, 0.15, 0.12, 0.10, 0.08, 0.05, 0.03, 0.02, 0.01, 0.01]
    }).sort_values('Importance', ascending=True)
    
    fig = go.Figure(data=[
        go.Bar(
            x=feature_importance['Importance'],
            y=feature_importance['Feature'],
            orientation='h',
            marker=dict(
                color=feature_importance['Importance'],
                colorscale='Viridis',
                showscale=True
            )
        )
    ])
    
    fig.update_layout(
        title="أهمية الميزات في النموذج",
        xaxis_title="الأهمية",
        yaxis_title="الميزة",
        template='plotly_dark',
        height=500
    )
    
    st.plotly_chart(fig, use_container_width=True)

# التبويب 5: اقتراحات الاستثمار
with tab5:
    st.header("💡 اقتراحات الاستثمار الذكية")
    
    st.warning("⚠️ هذه الاقتراحات للأغراض التعليمية فقط. استشر مستشاراً مالياً قبل اتخاذ أي قرار استثماري.")
    
    if selected_asset not in models:
        st.info(f"⚠️ النموذج غير متاح لـ {asset_options[selected_asset]}")
    else:
        # حساب التوقعات
        model = models[selected_asset]
        
        # استخراج الميزات الصحيحة
        if selected_asset in model_features:
            required_features = model_features[selected_asset]
            available_features = [f for f in required_features if f in df.columns]
            latest_features = df[available_features].iloc[-1].values
        else:
            feature_columns = [col for col in df.columns if col != 'Date']
            latest_features = df[feature_columns].iloc[-1].values
        
        # توقعات بسيطة
        predictions_7days = []
        for i in range(7):
            if i == 0:
                pred = model.predict([latest_features])[0]
            else:
                pred = predictions_7days[-1] * (1 + np.random.uniform(-0.01, 0.01))
            predictions_7days.append(pred)
        
        # الحصول على التوصية
        recommendation, color, change = get_investment_recommendation(predictions_7days, current_price)
        
        # عرض التوصية
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, {color} 0%, {'darkgreen' if 'Buy' in recommendation else 'darkred'} 100%);
                        padding: 2rem; border-radius: 15px; text-align: center;">
                <h2 style="color: white; margin: 0;">التوصية</h2>
                <h1 style="color: white; font-size: 3rem; margin: 1rem 0;">{recommendation}</h1>
                <p style="color: white; font-size: 1.5rem;">التغير المتوقع: {change:+.2f}%</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.metric(
                "السعر الحالي",
                f"${current_price:.2f}"
            )
            st.metric(
                "السعر المتوقع (7 أيام)",
                f"${predictions_7days[-1]:.2f}",
                f"{((predictions_7days[-1] - current_price) / current_price * 100):+.2f}%"
            )
        
        with col3:
            st.metric(
                "الربح المحتمل",
                f"${abs(predictions_7days[-1] - current_price):.2f}"
            )
            st.metric(
                "نسبة الربح",
                f"{abs(change):.2f}%"
            )
        
        st.divider()
        
        # تحليل مفصل
        st.subheader("📊 التحليل المفصل")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### ✅ نقاط القوة")
            if change > 0:
                st.write("- 📈 الاتجاه العام صاعد")
                st.write("- 💪 زخم إيجابي في السوق")
                st.write("- 🎯 التوقعات إيجابية")
            else:
                st.write("- 💰 فرصة للشراء بسعر منخفض")
                st.write("- 🔄 احتمالية انعكاس الاتجاه")
                st.write("- 📊 تقييم منخفض")
        
        with col2:
            st.markdown("### ⚠️ المخاطر")
            st.write("- 📉 تقلبات السوق")
            st.write("- 🌍 العوامل الاقتصادية العالمية")
            st.write("- 📰 الأخبار السياسية")
        
        st.divider()
        
        # استراتيجيات مقترحة
        st.subheader("🎯 استراتيجيات مقترحة")
        
        if "Buy" in recommendation:
            st.success("""
            **استراتيجية الشراء:**
            1. 💰 ابدأ بشراء 30% من المبلغ المخصص
            2. 📊 راقب السوق لمدة 2-3 أيام
            3. 📈 إذا استمر الارتفاع، اشتر 40% إضافية
            4. 🎯 احتفظ بـ 30% للفرص المستقبلية
            5. 🛡️ ضع أمر إيقاف خسارة عند -5%
            """)
        elif "Hold" in recommendation:
            st.info("""
            **استراتيجية الاحتفاظ:**
            1. 💼 احتفظ بمراكزك الحالية
            2. 📊 راقب التطورات عن كثب
            3. 🎯 انتظر إشارات أوضح
            4. 📈 كن مستعداً للتحرك في أي اتجاه
            5. 🛡️ حافظ على إدارة مخاطر صارمة
            """)
        else:
            st.error("""
            **استراتيجية البيع:**
            1. 📉 فكر في بيع 50% من مراكزك
            2. 💰 احتفظ بالسيولة
            3. 🎯 انتظر فرص شراء أفضل
            4. 📊 راقب مستويات الدعم
            5. 🛡️ قلل من التعرض للمخاطر
            """)
        
        st.divider()
        
        # مقارنة الأصول
        st.subheader("⚖️ مقارنة الأصول")
        
        comparison_data = []
        for asset, name in asset_options.items():
            if asset in models and asset in model_features:
                asset_price = latest_data[price_columns[asset]]
                
                # استخراج الميزات الصحيحة لهذا الأصل
                required_features = model_features[asset]
                available_features = [f for f in required_features if f in df.columns]
                asset_features = df[available_features].iloc[-1].values
                
                # توقع
                asset_pred = models[asset].predict([asset_features])[0]
                asset_change = ((asset_pred - asset_price) / asset_price) * 100
                
                comparison_data.append({
                    'الأصل': name,
                    'السعر الحالي': f"${asset_price:.2f}",
                    'التوقع (7 أيام)': f"${asset_pred:.2f}",
                    'التغير %': f"{asset_change:+.2f}%",
                    'التوصية': '🟢 شراء' if asset_change > 2 else ('🟡 احتفاظ' if asset_change > -2 else '🔴 بيع')
                })
        
        comparison_df = pd.DataFrame(comparison_data)
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)

# الفوتر
st.divider()
st.markdown("""
<div style="text-align: center; color: #888; padding: 2rem;">
    <p>💰 Gold Price Predictor Dashboard v2.0</p>
    <p>⚠️ للأغراض التعليمية فقط - استشر مستشاراً مالياً محترفاً</p>
    <p>📅 آخر تحديث: {}</p>
</div>
""".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')), unsafe_allow_html=True)

