#!/usr/bin/env python3
"""
Yahoo Finance API Integration
دمج Yahoo Finance API للحصول على بيانات حية
"""

import os
import sys
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import time

# إضافة مسار المشروع
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class YahooFinanceAPI:
    """
    واجهة Yahoo Finance API
    
    الميزات:
    - بيانات حية للأسهم والعملات
    - بيانات تاريخية
    - معلومات الشركات
    - تحليلات السوق
    """
    
    # رموز الأصول
    SYMBOLS = {
        'Gold': 'GC=F',  # Gold Futures
        'Silver': 'SI=F',  # Silver Futures
        'Oil': 'CL=F',  # Crude Oil Futures
        'SP500': '^GSPC',  # S&P 500
        'Bitcoin': 'BTC-USD',
        'Ethereum': 'ETH-USD',
        'BNB': 'BNB-USD',
        'Cardano': 'ADA-USD',
        'Solana': 'SOL-USD',
        'EUR_USD': 'EURUSD=X',
        'TRY_USD': 'TRYUSD=X',
        'EGP_USD': 'EGPUSD=X',
        'DXY': 'DX-Y.NYB'  # US Dollar Index
    }
    
    def __init__(self, use_yfinance: bool = True):
        """
        تهيئة Yahoo Finance API
        
        Args:
            use_yfinance: استخدام مكتبة yfinance (أسهل وأكثر موثوقية)
        """
        self.use_yfinance = use_yfinance
        
        if use_yfinance:
            try:
                import yfinance as yf
                self.yf = yf
                print("✅ Using yfinance library")
            except ImportError:
                print("⚠️ yfinance not installed. Install with: pip install yfinance")
                print("   Falling back to direct API calls")
                self.use_yfinance = False
        
        print("✅ Yahoo Finance API initialized")
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        الحصول على السعر الحالي
        
        Args:
            symbol: رمز الأصل
        
        Returns:
            السعر الحالي أو None
        """
        if self.use_yfinance:
            try:
                ticker = self.yf.Ticker(symbol)
                data = ticker.history(period='1d')
                if not data.empty:
                    return float(data['Close'].iloc[-1])
            except Exception as e:
                print(f"Error getting price for {symbol}: {e}")
        
        return None
    
    def get_historical_data(self, symbol: str, start_date: str, 
                           end_date: Optional[str] = None, 
                           interval: str = '1d') -> pd.DataFrame:
        """
        الحصول على البيانات التاريخية
        
        Args:
            symbol: رمز الأصل
            start_date: تاريخ البداية (YYYY-MM-DD)
            end_date: تاريخ النهاية (YYYY-MM-DD)
            interval: الفاصل الزمني (1d, 1h, 1m, etc.)
        
        Returns:
            DataFrame مع البيانات التاريخية
        """
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        if self.use_yfinance:
            try:
                ticker = self.yf.Ticker(symbol)
                data = ticker.history(start=start_date, end=end_date, interval=interval)
                
                if not data.empty:
                    # إعادة تسمية الأعمدة
                    data = data.reset_index()
                    data.columns = [col.replace(' ', '_') for col in data.columns]
                    
                    print(f"✅ Downloaded {len(data)} rows for {symbol}")
                    return data
            except Exception as e:
                print(f"Error downloading data for {symbol}: {e}")
        
        return pd.DataFrame()
    
    def get_all_assets_data(self, start_date: str, 
                           end_date: Optional[str] = None) -> Dict[str, pd.DataFrame]:
        """
        الحصول على بيانات جميع الأصول
        
        Args:
            start_date: تاريخ البداية
            end_date: تاريخ النهاية
        
        Returns:
            قاموس بالبيانات لكل أصل
        """
        all_data = {}
        
        for asset_name, symbol in self.SYMBOLS.items():
            print(f"📥 Downloading {asset_name} ({symbol})...")
            data = self.get_historical_data(symbol, start_date, end_date)
            
            if not data.empty:
                all_data[asset_name] = data
            
            # تأخير قصير لتجنب تجاوز الحد
            time.sleep(0.5)
        
        print(f"\n✅ Downloaded data for {len(all_data)} assets")
        return all_data
    
    def get_current_prices_all(self) -> Dict[str, float]:
        """
        الحصول على الأسعار الحالية لجميع الأصول
        
        Returns:
            قاموس بالأسعار الحالية
        """
        prices = {}
        
        for asset_name, symbol in self.SYMBOLS.items():
            price = self.get_current_price(symbol)
            if price is not None:
                prices[asset_name] = price
                print(f"✅ {asset_name}: ${price:.2f}")
            else:
                print(f"⚠️ Failed to get price for {asset_name}")
            
            time.sleep(0.3)
        
        return prices
    
    def get_asset_info(self, symbol: str) -> Dict[str, Any]:
        """
        الحصول على معلومات الأصل
        
        Args:
            symbol: رمز الأصل
        
        Returns:
            قاموس بمعلومات الأصل
        """
        if self.use_yfinance:
            try:
                ticker = self.yf.Ticker(symbol)
                info = ticker.info
                
                # استخراج المعلومات المهمة
                relevant_info = {
                    'symbol': symbol,
                    'name': info.get('longName', info.get('shortName', 'N/A')),
                    'currency': info.get('currency', 'USD'),
                    'market_cap': info.get('marketCap', 0),
                    'volume': info.get('volume', 0),
                    'avg_volume': info.get('averageVolume', 0),
                    '52w_high': info.get('fiftyTwoWeekHigh', 0),
                    '52w_low': info.get('fiftyTwoWeekLow', 0),
                    'description': info.get('longBusinessSummary', 'N/A')
                }
                
                return relevant_info
            except Exception as e:
                print(f"Error getting info for {symbol}: {e}")
        
        return {}
    
    def update_local_data(self, data_dir: str = "data/live"):
        """
        تحديث البيانات المحلية
        
        Args:
            data_dir: مجلد البيانات
        """
        os.makedirs(data_dir, exist_ok=True)
        
        # الحصول على آخر 30 يوم
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        
        # تحميل البيانات
        all_data = self.get_all_assets_data(start_str, end_str)
        
        # حفظ البيانات
        for asset_name, data in all_data.items():
            filepath = os.path.join(data_dir, f"{asset_name.lower()}_live.csv")
            data.to_csv(filepath, index=False)
            print(f"✅ Saved {asset_name} data to {filepath}")
        
        # حفظ الأسعار الحالية
        current_prices = self.get_current_prices_all()
        prices_filepath = os.path.join(data_dir, "current_prices.json")
        
        with open(prices_filepath, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'prices': current_prices
            }, f, indent=2)
        
        print(f"✅ Saved current prices to {prices_filepath}")
    
    def get_market_summary(self) -> Dict[str, Any]:
        """
        الحصول على ملخص السوق
        
        Returns:
            ملخص شامل للسوق
        """
        summary = {
            'timestamp': datetime.now().isoformat(),
            'assets': {}
        }
        
        for asset_name, symbol in self.SYMBOLS.items():
            price = self.get_current_price(symbol)
            
            if price is not None:
                # الحصول على بيانات آخر 7 أيام
                data = self.get_historical_data(
                    symbol, 
                    (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
                )
                
                if not data.empty:
                    # حساب التغير
                    first_price = data['Close'].iloc[0]
                    change = ((price - first_price) / first_price) * 100
                    
                    summary['assets'][asset_name] = {
                        'current_price': price,
                        'change_7d': change,
                        'high_7d': float(data['High'].max()),
                        'low_7d': float(data['Low'].min()),
                        'volume_avg_7d': float(data['Volume'].mean())
                    }
        
        return summary


def example_usage():
    """مثال على الاستخدام"""
    # تهيئة API
    api = YahooFinanceAPI(use_yfinance=True)
    
    # الحصول على الأسعار الحالية
    print("\n📊 Current Prices:")
    prices = api.get_current_prices_all()
    
    # الحصول على ملخص السوق
    print("\n📈 Market Summary:")
    summary = api.get_market_summary()
    print(json.dumps(summary, indent=2, default=str))
    
    # تحديث البيانات المحلية
    print("\n🔄 Updating local data...")
    api.update_local_data("/home/ubuntu/gold_price_predictor_clean/data/live")


if __name__ == "__main__":
    example_usage()

