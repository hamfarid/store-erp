# Gold Price Predictor API

REST API for predicting financial asset prices using machine learning.

## Quick Start

### 1. Install Dependencies

```bash
pip install fastapi uvicorn pydantic
```

### 2. Run API

```bash
# From project root
python run_api.py

# Or using uvicorn directly
uvicorn api.main:app --reload
```

### 3. Access Documentation

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### 4. Test API

```bash
python test_api.py
```

## Supported Assets

- `gold` - Gold
- `btc` - Bitcoin
- `eth` - Ethereum
- `try_usd` - Turkish Lira / USD
- `egp_usd` - Egyptian Pound / USD

## Example Usage

### Python

```python
import requests

response = requests.post(
    "http://localhost:8000/predict",
    json={
        "asset": "gold",
        "features": {
            "Silver_Price": 50.10,
            "Oil_Price": 57.15,
            # ... more features
        }
    }
)

result = response.json()
print(f"Predicted price: ${result['predicted_price']:.2f}")
```

### cURL

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"asset": "gold", "features": {...}}'
```

## Documentation

See [API_GUIDE.md](../docs/API_GUIDE.md) for complete documentation.

## License

MIT License - See [LICENSE](../LICENSE) for details.
