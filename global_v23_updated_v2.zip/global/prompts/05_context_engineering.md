================================================================================
MODULE 19: CONTEXT ENGINEERING & LEARNING SYSTEM
================================================================================

⚠️ NOTE: This module is part of Global Guidelines (instruction manual).
Apply this guidance to THE USER'S PROJECT, not to Global Guidelines itself.
Global Guidelines is in: ~/global/ or similar
User's project is in: A separate directory (ask user for project path)



OVERVIEW
--------
هذا المودول يوفر نظام هندسة السياق والتعلم المستمر، يمكّن الذكاء الاصطناعي
من فهم السياق بعمق، اتخاذ قرارات ذكية، التكيف مع المواقف، والتعلم من التجارب.

CORE PHILOSOPHY
---------------
"Understand deeply, decide wisely, adapt continuously, learn constantly"

النظام يجب أن:
- يفهم السياق الكامل قبل اتخاذ القرارات
- يتخذ قرارات مبنية على البيانات والتجارب
- يتكيف مع التغييرات والمواقف الجديدة
- يتعلم من النجاحات والإخفاقات
- يحسن أداءه بشكل مستمر

================================================================================
SECTION 1: CONTEXT AWARENESS
================================================================================

OVERVIEW
--------
فهم شامل للسياق المحيط بالمشروع والمهمة الحالية.

MULTI-DIMENSIONAL CONTEXT
-------------------------

```typescript
{
  "context_dimensions": {
    "project_context": {
      "name": "string",
      "type": "web_app | mobile_app | api | library | tool",
      "phase": "planning | development | testing | deployment | maintenance",
      "size": "small | medium | large | enterprise",
      "complexity": "low | medium | high | very_high",
      "tech_stack": {
        "frontend": ["React", "TypeScript", "Tailwind"],
        "backend": ["FastAPI", "Python", "PostgreSQL"],
        "infrastructure": ["Docker", "Cloudflare", "GitHub Actions"]
      },
      "team": {
        "size": 5,
        "experience": "junior | mid | senior | mixed",
        "timezone": "UTC+2",
        "availability": "full_time | part_time"
      }
    },
    
    "code_context": {
      "languages": ["Python", "TypeScript", "SQL"],
      "frameworks": ["FastAPI", "React", "Prisma"],
      "architecture": "microservices | monolith | serverless",
      "design_patterns": ["Repository", "Factory", "Observer"],
      "code_quality": {
        "test_coverage": 85,
        "maintainability_index": 78,
        "technical_debt_ratio": 5.2,
        "code_smells": 12
      },
      "dependencies": {
        "total": 45,
        "outdated": 3,
        "vulnerable": 0
      }
    },
    
    "task_context": {
      "current_task": {
        "id": "TASK-123",
        "type": "bug | feature | refactor | test | docs",
        "priority": "low | medium | high | critical",
        "complexity": "low | medium | high",
        "estimated_effort": "hours",
        "actual_effort": "hours",
        "progress": 45,
        "blockers": []
      },
      "related_tasks": ["TASK-120", "TASK-121"],
      "dependencies": ["TASK-100"],
      "blocked_by": [],
      "blocking": ["TASK-125"]
    },
    
    "environment_context": {
      "current_environment": "local | staging | production",
      "available_tools": [
        "playwright", "ruff", "eslint", "sentry",
        "github", "cloudflare", "context7 (Exa MCP)"
      ],
      "resource_limits": {
        "memory": "8GB",
        "cpu": "4 cores",
        "storage": "256GB"
      },
      "network": {
        "internet": true,
        "vpn": false,
        "proxy": false
      }
    },
    
    "business_context": {
      "objectives": [
        "Increase user engagement",
        "Reduce technical debt",
        "Improve performance"
      ],
      "constraints": {
        "budget": "limited",
        "timeline": "tight",
        "resources": "constrained"
      },
      "stakeholders": [
        {"role": "Product Manager", "priority": "features"},
        {"role": "CTO", "priority": "quality"},
        {"role": "Users", "priority": "performance"}
      ]
    },
    
    "historical_context": {
      "similar_tasks_completed": 15,
      "success_rate": 87,
      "common_issues": ["Performance", "Edge cases"],
      "lessons_learned": [
        "Always write tests first",
        "Profile before optimizing",
        "Document complex logic"
      ]
    }
  }
}
```

---

## CONTEXT GATHERING

```python
class ContextEngine:
    def __init__(self):
        self.context = {}
        self.tools = self.init_tools()
    
    async def gather_full_context(self):
        """Gather complete context from all sources"""
        
        # Gather in parallel
        results = await asyncio.gather(
            self.gather_project_context(),
            self.gather_code_context(),
            self.gather_task_context(),
            self.gather_environment_context(),
            self.gather_business_context(),
            self.gather_historical_context(),
            self.gather_external_context()  # Added Firecrawl/Exa search
        )
        
        self.context = {
            'project': results[0],
            'code': results[1],
            'task': results[2],
            'environment': results[3],
            'business': results[4],
            'historical': results[5],
            'external': results[6],  # Added external context
            'timestamp': datetime.now(),
            'confidence': self.calculate_confidence()
        }
        
        return self.context

    async def gather_external_context(self):
        """Gather external context using Firecrawl/Exa"""
        # Use MCP to search for relevant external info
        search_results = await self.tools.mcp.call(
            "search", 
            {"query": f"best practices for {self.context.get('task', {}).get('type', 'general')}"}
        )
        return {
            'search_results': search_results,
            'source': 'firecrawl/exa'
        }
    
    async def gather_code_context(self):
        """Gather code-related context"""
        return {
            'quality': await self.tools.ruff.check_project(),
            'coverage': await self.tools.pytest.get_coverage(),
            'complexity': await self.tools.code_analysis.measure_complexity(),
            'dependencies': await self.tools.pip.list_packages(),
            'security': await self.tools.security_scan.check()
        }
    
    async def gather_historical_context(self):
        """Gather historical data"""
        return {
            'similar_tasks': await self.tools.github.search_similar_issues(),
            'past_solutions': await self.learning_system.get_solutions(),
            'lessons': await self.learning_system.get_lessons(),
            'patterns': await self.learning_system.get_patterns()
        }
```

================================================================================
SECTION 2: INTELLIGENT DECISION MAKING
================================================================================

OVERVIEW
--------
اتخاذ قرارات ذكية مبنية على السياق والبيانات.

DECISION FRAMEWORK
-----------------

```python
class DecisionEngine:
    def __init__(self, context_engine, learning_system):
        self.context = context_engine
        self.learning = learning_system
        self.rules = self.load_decision_rules()
    
    def make_decision(self, decision_type, options):
        """Make intelligent decision"""
        
        # Get current context
        context = self.context.get_current()
        
        # Get historical data
        history = self.learning.get_similar_decisions(decision_type)
        
        # Evaluate each option
        scores = {}
        for option in options:
            scores[option] = self.evaluate_option(
                option,
                context,
                history
            )
        
        # Select best option
        best_option = max(scores, key=scores.get)
        
        # Explain decision
        explanation = self.explain_decision(
            best_option,
            scores,
            context
        )
        
        # Record decision for learning
        self.learning.record_decision({
            'type': decision_type,
            'context': context,
            'options': options,
            'scores': scores,
            'selected': best_option,
            'explanation': explanation,
            'timestamp': datetime.now()
        })
        
        return {
            'decision': best_option,
            'confidence': scores[best_option],
            'explanation': explanation,
            'alternatives': sorted(
                scores.items(),
                key=lambda x: x[1],
                reverse=True
            )[1:3]
        }
    
    def evaluate_option(self, option, context, history):
        """Evaluate a single option"""
        score = 0
        
        # Rule-based evaluation
        for rule in self.rules:
            if rule.applies(option, context):
                score += rule.score(option, context)
        
        # Historical performance
        if history:
            similar = [h for h in history if h['option'] == option]
            if similar:
                success_rate = sum(h['success'] for h in similar) / len(similar)
                score += success_rate * 30
        
        # Context fit
        context_score = self.calculate_context_fit(option, context)
        score += context_score * 20
        
        return score
```

---

## DECISION RULES

```python
# Example Decision Rules

class ChooseArchitectureRule:
    def applies(self, option, context):
        return context['decision_type'] == 'architecture'
    
    def score(self, option, context):
        score = 0
        
        # Small project + simple requirements → Monolith
        if (context['project']['size'] == 'small' and 
            context['project']['complexity'] == 'low'):
            if option == 'monolith':
                score += 40
        
        # Large project + multiple teams → Microservices
        elif (context['project']['size'] == 'large' and 
              context['team']['size'] > 10):
            if option == 'microservices':
                score += 40
        
        # High scalability requirement → Microservices
        if 'high_scalability' in context['business']['objectives']:
            if option in ['microservices', 'serverless']:
                score += 30
        
        return score


class ChooseDatabaseRule:
    def applies(self, option, context):
        return context['decision_type'] == 'database'
    
    def score(self, option, context):
        score = 0
        
        # Structured data + ACID → PostgreSQL
        if (context['data_type'] == 'structured' and 
            context['needs_acid']):
            if option == 'postgresql':
                score += 40
        
        # Flexible schema + high write → MongoDB
        elif (context['schema'] == 'flexible' and 
              context['write_heavy']):
            if option == 'mongodb':
                score += 40
        
        # Time-series data → TimescaleDB
        if context['data_type'] == 'time_series':
            if option == 'timescaledb':
                score += 50
        
        return score
```

================================================================================
SECTION 3: ADAPTIVE BEHAVIOR
================================================================================

OVERVIEW
--------
التكيف مع التغييرات والمواقف الجديدة.

ADAPTATION STRATEGIES
--------------------

```python
class AdaptiveSystem:
    def __init__(self):
        self.strategies = {}
        self.current_strategy = None
        self.performance_history = []
    
    def adapt_to_context(self, context):
        """Adapt behavior based on context"""
        
        # Detect context changes
        changes = self.detect_changes(context)
        
        if changes:
            # Select appropriate strategy
            new_strategy = self.select_strategy(context, changes)
            
            if new_strategy != self.current_strategy:
                self.switch_strategy(new_strategy, context)
        
        return self.current_strategy
    
    def detect_changes(self, context):
        """Detect significant context changes"""
        changes = []
        
        if not hasattr(self, 'previous_context'):
            self.previous_context = context
            return changes
        
        prev = self.previous_context
        
        # Project phase changed
        if context['project']['phase'] != prev['project']['phase']:
            changes.append({
                'type': 'phase_change',
                'from': prev['project']['phase'],
                'to': context['project']['phase']
            })
        
        # Priority shift
        if context['task']['priority'] != prev['task']['priority']:
            changes.append({
                'type': 'priority_change',
                'from': prev['task']['priority'],
                'to': context['task']['priority']
            })
        
        # Resource constraints
        if context['business']['constraints'] != prev['business']['constraints']:
            changes.append({
                'type': 'constraints_change',
                'details': context['business']['constraints']
            })
        
        # Performance issues
        if context['code']['quality'] < prev['code']['quality'] - 10:
            changes.append({
                'type': 'quality_degradation',
                'from': prev['code']['quality'],
                'to': context['code']['quality']
            })
        
        self.previous_context = context
        return changes
    
    def select_strategy(self, context, changes):
        """Select appropriate strategy"""
        
        # Critical production issue
        if context['task']['priority'] == 'critical':
            return 'emergency_mode'
        
        # Development phase
        elif context['project']['phase'] == 'development':
            if context['business']['constraints']['timeline'] == 'tight':
                return 'fast_delivery'
            else:
                return 'quality_focused'
        
        # Maintenance phase
        elif context['project']['phase'] == 'maintenance':
            return 'stability_focused'
        
        # Testing phase
        elif context['project']['phase'] == 'testing':
            return 'quality_assurance'
        
        return 'balanced'
```

---

## STRATEGY DEFINITIONS

```typescript
{
  "strategies": {
    "emergency_mode": {
      "description": "Handle critical production issues",
      "priorities": ["Fix immediately", "Minimal testing", "Quick deployment"],
      "tools": ["sentry", "cloudflare", "github"],
      "workflow": "hotfix",
      "quality_threshold": 70,
      "speed_multiplier": 2.0
    },
    
    "fast_delivery": {
      "description": "Deliver quickly with acceptable quality",
      "priorities": ["Speed", "Core features", "Basic testing"],
      "tools": ["ruff", "pytest", "playwright"],
      "workflow": "agile",
      "quality_threshold": 75,
      "speed_multiplier": 1.5
    },
    
    "quality_focused": {
      "description": "Prioritize code quality and maintainability",
      "priorities": ["Quality", "Testing", "Documentation"],
      "tools": ["ruff", "eslint", "pytest", "code-analysis"],
      "workflow": "thorough",
      "quality_threshold": 90,
      "speed_multiplier": 0.8
    },
    
    "stability_focused": {
      "description": "Maintain stability and reliability",
      "priorities": ["Stability", "Monitoring", "Gradual changes"],
      "tools": ["sentry", "cloudflare", "playwright"],
      "workflow": "cautious",
      "quality_threshold": 95,
      "speed_multiplier": 0.7
    },
    
    "quality_assurance": {
      "description": "Comprehensive testing and validation",
      "priorities": ["Testing", "Bug fixing", "Performance"],
      "tools": ["playwright", "pytest", "code-analysis"],
      "workflow": "testing",
      "quality_threshold": 95,
      "speed_multiplier": 0.6
    },
    
    "balanced": {
      "description": "Balance between speed and quality",
      "priorities": ["Features", "Quality", "Testing"],
      "tools": ["all"],
      "workflow": "standard",
      "quality_threshold": 80,
      "speed_multiplier": 1.0
    }
  }
}
```

================================================================================
SECTION 4: LEARNING SYSTEM
================================================================================

OVERVIEW
--------
نظام تعلم مستمر يحسن الأداء بناءً على التجارب.

LEARNING ARCHITECTURE
--------------------

```python
class LearningSystem:
    def __init__(self):
        self.knowledge_base = KnowledgeBase()
        self.pattern_detector = PatternDetector()
        self.performance_tracker = PerformanceTracker()
    
    def learn_from_experience(self, experience):
        """Learn from a completed task or decision"""
        
        # Extract lessons
        lessons = self.extract_lessons(experience)
        
        # Detect patterns
        patterns = self.pattern_detector.find_patterns(experience)
        
        # Update knowledge base
        for lesson in lessons:
            self.knowledge_base.add_lesson(lesson)
        
        for pattern in patterns:
            self.knowledge_base.add_pattern(pattern)
        
        # Update performance metrics
        self.performance_tracker.record(experience)
        
        # Identify improvements
        improvements = self.identify_improvements(experience)
        
        return {
            'lessons': lessons,
            'patterns': patterns,
            'improvements': improvements
        }
    
    def extract_lessons(self, experience):
        """Extract lessons from experience"""
        lessons = []
        
        # Success lessons
        if experience['success']:
            lessons.append({
                'type': 'success',
                'context': experience['context'],
                'action': experience['action'],
                'result': experience['result'],
                'lesson': f"In {experience['context']}, doing {experience['action']} leads to {experience['result']}"
            })
        
        # Failure lessons
        else:
            lessons.append({
                'type': 'failure',
                'context': experience['context'],
                'action': experience['action'],
                'result': experience['result'],
                'lesson': f"In {experience['context']}, avoid {experience['action']} because {experience['result']}"
            })
        
        # Performance lessons
        if 'performance' in experience:
            if experience['performance']['actual'] < experience['performance']['expected']:
                lessons.append({
                    'type': 'performance',
                    'lesson': f"Task took longer than expected. Reason: {experience['performance']['reason']}"
                })
        
        return lessons
```

---

## PATTERN DETECTION

```python
class PatternDetector:
    def __init__(self):
        self.patterns = []
    
    def find_patterns(self, experience):
        """Detect patterns in experiences"""
        patterns = []
        
        # Recurring issues
        similar = self.find_similar_experiences(experience)
        if len(similar) >= 3:
            pattern = {
                'type': 'recurring_issue',
                'frequency': len(similar),
                'context': self.extract_common_context(similar),
                'solution': self.extract_best_solution(similar),
                'confidence': len(similar) / 10.0
            }
            patterns.append(pattern)
        
        # Success patterns
        if experience['success']:
            successful_similar = [e for e in similar if e['success']]
            if len(successful_similar) >= 2:
                pattern = {
                    'type': 'success_pattern',
                    'context': self.extract_common_context(successful_similar),
                    'actions': self.extract_common_actions(successful_similar),
                    'confidence': len(successful_similar) / 5.0
                }
                patterns.append(pattern)
        
        return patterns
    
    def extract_best_solution(self, experiences):
        """Extract the best solution from similar experiences"""
        solutions = {}
        
        for exp in experiences:
            solution = exp['solution']
            if solution not in solutions:
                solutions[solution] = {
                    'count': 0,
                    'success_rate': 0,
                    'avg_time': 0
                }
            
            solutions[solution]['count'] += 1
            if exp['success']:
                solutions[solution]['success_rate'] += 1
            solutions[solution]['avg_time'] += exp['time']
        
        # Calculate averages
        for solution in solutions.values():
            solution['success_rate'] /= solution['count']
            solution['avg_time'] /= solution['count']
        
        # Select best
        best = max(
            solutions.items(),
            key=lambda x: x[1]['success_rate'] * 0.7 + (1 / x[1]['avg_time']) * 0.3
        )
        
        return best[0]
```

---

## KNOWLEDGE BASE

```python
class KnowledgeBase:
    def __init__(self):
        self.lessons = []
        self.patterns = []
        self.best_practices = []
        self.anti_patterns = []
    
    def add_lesson(self, lesson):
        """Add a lesson to the knowledge base"""
        # Check if similar lesson exists
        similar = self.find_similar_lesson(lesson)
        
        if similar:
            # Reinforce existing lesson
            similar['confidence'] += 0.1
            similar['occurrences'] += 1
        else:
            # Add new lesson
            lesson['confidence'] = 0.5
            lesson['occurrences'] = 1
            lesson['timestamp'] = datetime.now()
            self.lessons.append(lesson)
    
    def get_relevant_lessons(self, context):
        """Get lessons relevant to current context"""
        relevant = []
        
        for lesson in self.lessons:
            similarity = self.calculate_context_similarity(
                lesson['context'],
                context
            )
            
            if similarity > 0.7:
                relevant.append({
                    'lesson': lesson,
                    'relevance': similarity,
                    'confidence': lesson['confidence']
                })
        
        # Sort by relevance and confidence
        relevant.sort(
            key=lambda x: x['relevance'] * x['confidence'],
            reverse=True
        )
        
        return relevant[:5]
    
    def evolve_to_best_practice(self, lesson):
        """Evolve a lesson into a best practice"""
        if (lesson['confidence'] > 0.9 and 
            lesson['occurrences'] > 10):
            
            best_practice = {
                'title': self.generate_title(lesson),
                'description': lesson['lesson'],
                'context': lesson['context'],
                'examples': self.find_examples(lesson),
                'confidence': lesson['confidence']
            }
            
            self.best_practices.append(best_practice)
            return True
        
        return False
```

---

## PERFORMANCE TRACKING

```python
class PerformanceTracker:
    def __init__(self):
        self.metrics = {}
        self.trends = {}
    
    def record(self, experience):
        """Record performance metrics"""
        metric_type = experience['type']
        
        if metric_type not in self.metrics:
            self.metrics[metric_type] = []
        
        self.metrics[metric_type].append({
            'timestamp': datetime.now(),
            'duration': experience['duration'],
            'success': experience['success'],
            'quality': experience.get('quality', 0),
            'context': experience['context']
        })
        
        # Update trends
        self.update_trends(metric_type)
    
    def update_trends(self, metric_type):
        """Update performance trends"""
        data = self.metrics[metric_type]
        
        if len(data) < 5:
            return
        
        recent = data[-10:]
        
        self.trends[metric_type] = {
            'avg_duration': sum(d['duration'] for d in recent) / len(recent),
            'success_rate': sum(d['success'] for d in recent) / len(recent),
            'avg_quality': sum(d.get('quality', 0) for d in recent) / len(recent),
            'trend': self.calculate_trend(data)
        }
    
    def calculate_trend(self, data):
        """Calculate if performance is improving or declining"""
        if len(data) < 10:
            return 'insufficient_data'
        
        recent = data[-5:]
        previous = data[-10:-5]
        
        recent_avg = sum(d['duration'] for d in recent) / len(recent)
        previous_avg = sum(d['duration'] for d in previous) / len(previous)
        
        if recent_avg < previous_avg * 0.9:
            return 'improving'
        elif recent_avg > previous_avg * 1.1:
            return 'declining'
        else:
            return 'stable'
    
    def get_insights(self):
        """Get performance insights"""
        insights = []
        
        for metric_type, trend in self.trends.items():
            if trend['trend'] == 'declining':
                insights.append({
                    'type': 'warning',
                    'metric': metric_type,
                    'message': f"Performance declining for {metric_type}",
                    'recommendation': "Review recent changes and identify bottlenecks"
                })
            
            if trend['success_rate'] < 0.8:
                insights.append({
                    'type': 'alert',
                    'metric': metric_type,
                    'message': f"Low success rate ({trend['success_rate']*100}%) for {metric_type}",
                    'recommendation': "Investigate common failure causes"
                })
        
        return insights
```

---

## CONTINUOUS IMPROVEMENT

```python
class ContinuousImprovement:
    def __init__(self, learning_system):
        self.learning = learning_system
        self.improvement_cycles = []
    
    def run_improvement_cycle(self):
        """Run a continuous improvement cycle"""
        
        # 1. Analyze current performance
        performance = self.learning.performance_tracker.get_insights()
        
        # 2. Identify improvement opportunities
        opportunities = self.identify_opportunities(performance)
        
        # 3. Generate improvement actions
        actions = self.generate_actions(opportunities)
        
        # 4. Prioritize actions
        prioritized = self.prioritize_actions(actions)
        
        # 5. Execute top actions
        results = self.execute_actions(prioritized[:3])
        
        # 6. Measure impact
        impact = self.measure_impact(results)
        
        # 7. Learn from cycle
        self.learning.learn_from_experience({
            'type': 'improvement_cycle',
            'opportunities': opportunities,
            'actions': actions,
            'results': results,
            'impact': impact,
            'timestamp': datetime.now()
        })
        
        return {
            'opportunities': opportunities,
            'actions': prioritized,
            'impact': impact
        }
    
    def identify_opportunities(self, performance):
        """Identify improvement opportunities"""
        opportunities = []
        
        for insight in performance:
            if insight['type'] in ['warning', 'alert']:
                opportunities.append({
                    'area': insight['metric'],
                    'issue': insight['message'],
                    'potential_impact': 'high' if insight['type'] == 'alert' else 'medium'
                })
        
        return opportunities
```

================================================================================
SECTION 5: META-LEARNING
================================================================================

OVERVIEW
--------
التعلم عن التعلم - تحسين عملية التعلم نفسها.

META-LEARNING SYSTEM
-------------------

```python
class MetaLearner:
    def __init__(self, learning_system):
        self.learning = learning_system
        self.learning_strategies = []
        self.strategy_performance = {}
    
    def optimize_learning(self):
        """Optimize the learning process itself"""
        
        # Analyze learning effectiveness
        effectiveness = self.analyze_learning_effectiveness()
        
        # Identify best learning strategies
        best_strategies = self.identify_best_strategies()
        
        # Adjust learning parameters
        adjustments = self.adjust_learning_parameters(effectiveness)
        
        # Apply improvements
        self.apply_improvements(best_strategies, adjustments)
        
        return {
            'effectiveness': effectiveness,
            'best_strategies': best_strategies,
            'adjustments': adjustments
        }
    
    def analyze_learning_effectiveness(self):
        """Analyze how effective the learning has been"""
        
        # Get all lessons
        lessons = self.learning.knowledge_base.lessons
        
        # Calculate metrics
        total_lessons = len(lessons)
        high_confidence = len([l for l in lessons if l['confidence'] > 0.8])
        applied_successfully = len([l for l in lessons if l.get('applied', False)])
        
        return {
            'total_lessons': total_lessons,
            'high_confidence_rate': high_confidence / total_lessons if total_lessons > 0 else 0,
            'application_rate': applied_successfully / total_lessons if total_lessons > 0 else 0,
            'learning_velocity': total_lessons / self.get_days_active()
        }
```

================================================================================
RESOURCES
================================================================================

### Context Engineering
- **Context-Aware Computing:** https://en.wikipedia.org/wiki/Context-aware_computing
- **Adaptive Systems:** https://en.wikipedia.org/wiki/Adaptive_system

### Machine Learning
- **Reinforcement Learning:** https://en.wikipedia.org/wiki/Reinforcement_learning
- **Transfer Learning:** https://en.wikipedia.org/wiki/Transfer_learning

### Knowledge Management
- **Knowledge Base Systems:** https://en.wikipedia.org/wiki/Knowledge_base
- **Expert Systems:** https://en.wikipedia.org/wiki/Expert_system

================================================================================
END OF MODULE 19: CONTEXT ENGINEERING & LEARNING SYSTEM
================================================================================

