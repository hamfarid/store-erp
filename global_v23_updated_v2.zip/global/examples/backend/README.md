# Backend Examples

## Example 1: REST API with Django
See: `api_example.py`

## Example 2: Authentication System
See: `auth_example.py`

## Example 3: Database Models
See: `models_example.py`

Study these examples before creating backend code.
