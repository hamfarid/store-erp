# Sequential Thinking Rules

## Mandatory Application
You **must** apply Sequential Thinking for:
1.  **Complex Tasks:** Any task involving >3 steps or multiple dependencies.
2.  **Debugging:** When diagnosing errors or unexpected behavior.
3.  **Architecture:** When designing new components or systems.

## The Process
1.  **Deconstruct:** Break it down.
2.  **Sequence:** Order it.
3.  **Analyze:** Verify it.
4.  **Synthesize:** Build it.
5.  **Review:** Check it.

## Documentation
-   **Log It:** You must explicitly state your thinking process in the logs.
-   **Format:** Use the `Sequential Thinking` header in your output.
