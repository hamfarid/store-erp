# E2E Tests - Playwright

اختبارات End-to-End شاملة لجميع الصفحات والأزرار باستخدام Playwright.

## 📋 الملفات

### الاختبارات الرئيسية

1. **`comprehensive-pages-test.spec.ts`**
   - اختبار شامل لجميع الصفحات
   - اختبار الأزرار والتفاعلات
   - أخذ لقطات شاشة

2. **`error-analysis.spec.ts`**
   - تحليل الأخطاء في جميع الصفحات
   - جمع console errors
   - فحص broken links

3. **`all-buttons-screenshots.spec.ts`**
   - اختبار شامل لجميع الأزرار
   - لقطات شاشة للأزرار في حالات مختلفة
   - اختبار hover, click, disabled states

## 🚀 التشغيل

### الطريقة 1: استخدام السكريبت (موصى بها)

```powershell
.\scripts\run-e2e-tests.ps1
```

### الطريقة 2: يدوياً

```bash
# 1. تأكد من تشغيل السيرفر
npm run dev

# 2. في terminal آخر
npx playwright test e2e/tests/comprehensive-pages-test.spec.ts --project=chromium
```

### تشغيل اختبارات محددة

```bash
# اختبار الصفحات العامة فقط
npx playwright test e2e/tests/comprehensive-pages-test.spec.ts --grep "public"

# اختبار تحليل الأخطاء
npx playwright test e2e/tests/error-analysis.spec.ts

# اختبار الأزرار
npx playwright test e2e/tests/all-buttons-screenshots.spec.ts
```

## 📸 لقطات الشاشة

جميع لقطات الشاشة تُحفظ في:
- `screenshots/` - لقطات من الاختبارات الجديدة
- `playwright-screenshots/` - لقطات من `all-buttons-screenshots.spec.ts`

## 📊 التقارير

عرض تقرير HTML:
```bash
npx playwright show-report
```

## 🔧 الإعدادات

### Environment Variables

في ملف `.env`:
```env
PLAYWRIGHT_BASE_URL=http://localhost:2505
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=adminpassword
```

### Configuration

الإعدادات في `playwright.config.ts`:
- Timeout: 180 seconds
- Viewport: 1280x720
- Locale: ar-EG
- Timezone: Africa/Cairo

## 📝 الصفحات المختبرة

### الصفحات العامة (5)
- `/` - الرئيسية
- `/login` - تسجيل الدخول
- `/register` - إنشاء حساب
- `/about` - حول
- `/help` - المساعدة

### الصفحات المحمية (30+)
- `/dashboard` - لوحة التحكم
- `/predictions` - التوقعات
- `/alerts` - التنبيهات
- `/assets` - الأصول
- `/reports` - التقارير
- `/portfolio` - المحفظة
- `/settings` - الإعدادات
- وغيرها...

### صفحات المدير (10+)
- `/admin` - لوحة المدير
- `/admin/users` - إدارة المستخدمين
- `/admin/assets` - إدارة الأصول
- `/admin/backup` - النسخ الاحتياطي
- وغيرها...

## 🐛 الأخطاء المعروفة

1. **Server Timeout**: قد يحتاج السيرفر وقت أطول للبدء
   - **الحل**: زيادة timeout في `playwright.config.ts`

2. **Authentication**: بعض الصفحات تحتاج تسجيل دخول
   - **الحل**: استخدام login helper في الاختبارات

3. **Button Visibility**: بعض الأزرار تحتاج وقت للظهور
   - **الحل**: استخدام `waitFor` conditions

## 📚 المزيد من المعلومات

- [Playwright Documentation](https://playwright.dev)
- [E2E Test Task List](../docs/E2E_TEST_TASK_LIST.md)
- [Error Analysis](../docs/E2E_TEST_ERRORS.md)

