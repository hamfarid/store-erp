/**
 * Authentication Helper for E2E Tests
 * Provides login functionality for testing protected routes
 */

import { Page } from "@playwright/test";

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || "http://localhost:2505";
const TEST_EMAIL = process.env.TEST_EMAIL || "test@example.com";
const TEST_PASSWORD = process.env.TEST_PASSWORD || "testpassword123";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@example.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "adminpassword123";

/**
 * Login as regular user
 */
export async function loginAsUser(page: Page) {
  await page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2000);

  // Try to find and fill login form
  const emailInput = page.locator('input[type="email"], input[name="email"], [data-testid="login-email"]').first();
  const passwordInput = page.locator('input[type="password"], input[name="password"], [data-testid="login-password"]').first();
  const submitButton = page.locator('button[type="submit"], button:has-text("تسجيل الدخول"), [data-testid="login-submit"]').first();

  if (await emailInput.count() > 0) {
    await emailInput.fill(TEST_EMAIL);
    await passwordInput.fill(TEST_PASSWORD);
    await submitButton.click();
    
    // Wait for navigation away from login page
    await page.waitForFunction(
      () => !window.location.pathname.includes("/login"),
      { timeout: 10000 }
    ).catch(() => {});
    
    await page.waitForTimeout(2000);
  }
}

/**
 * Login as admin user
 */
export async function loginAsAdmin(page: Page) {
  await page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2000);

  const emailInput = page.locator('input[type="email"], input[name="email"], [data-testid="login-email"]').first();
  const passwordInput = page.locator('input[type="password"], input[name="password"], [data-testid="login-password"]').first();
  const submitButton = page.locator('button[type="submit"], button:has-text("تسجيل الدخول"), [data-testid="login-submit"]').first();

  if (await emailInput.count() > 0) {
    await emailInput.fill(ADMIN_EMAIL);
    await passwordInput.fill(ADMIN_PASSWORD);
    await submitButton.click();
    
    await page.waitForFunction(
      () => !window.location.pathname.includes("/login"),
      { timeout: 10000 }
    ).catch(() => {});
    
    await page.waitForTimeout(2000);
  }
}

/**
 * Check if user is logged in
 */
export async function isLoggedIn(page: Page): Promise<boolean> {
  const currentUrl = page.url();
  return !currentUrl.includes("/login");
}

