/**
 * Comprehensive Button Testing and Screenshots
 * Tests all buttons and interactive elements across all pages
 * Takes screenshots of each page and button interaction
 */

import { test, expect, Page } from '@playwright/test';
import * as path from 'path';
import * as fs from 'fs';
import { fileURLToPath } from 'url';

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:2501';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@goldpredictor.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@123456';

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure screenshots directory exists
const screenshotsDir = path.join(__dirname, '../../playwright-screenshots');
if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

// Helper function to login
async function loginAsAdmin(page: Page) {
  await page.goto(`${BASE_URL}/login`);
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(2000);
  
  const emailInput = page.locator('[data-testid="login-email"], input[name="email"]').first();
  const passwordInput = page.locator('[data-testid="login-password"], input[name="password"]').first();
  const submitButton = page.locator('[data-testid="login-submit"], button[type="submit"]').first();
  
  await emailInput.fill(ADMIN_EMAIL);
  await passwordInput.fill(ADMIN_PASSWORD);
  await submitButton.click();
  
  await page.waitForFunction(() => !window.location.pathname.includes('/login'), { timeout: 15000 }).catch(() => {});
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(2000);
}

// Helper to test all buttons on a page
async function testAllButtons(page: Page, pageName: string, screenshotPrefix: string) {
  const buttons = page.locator('button:visible');
  const buttonCount = await buttons.count();
  
  console.log(`\n📍 ${pageName}: Found ${buttonCount} visible buttons`);
  
  const buttonInfo: Array<{ text: string; enabled: boolean; index: number }> = [];
  
  for (let i = 0; i < Math.min(buttonCount, 30); i++) {
    const button = buttons.nth(i);
    if (await button.isVisible().catch(() => false)) {
      const text = (await button.textContent() || 'No text').trim();
      const enabled = await button.isEnabled().catch(() => false);
      buttonInfo.push({ text: text.substring(0, 50), enabled, index: i });
      
      // Test hover
      try {
        await button.hover({ timeout: 2000 });
        await page.waitForTimeout(300);
        await button.screenshot({ 
          path: path.join(screenshotsDir, `${screenshotPrefix}-button-${i}-hover.png`) 
        }).catch(() => {});
      } catch (e) {
        // Ignore hover errors
      }
    }
  }
  
  return buttonInfo;
}

test.describe('All Pages - Full Screenshots and Button Tests', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.setViewportSize({ width: 1920, height: 1080 });
  });

  test('Home Page - Screenshot and Buttons', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    // Full page screenshot
    await page.screenshot({ 
      path: path.join(screenshotsDir, '01-home-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Home Page', '01-home');
    expect(buttons.length).toBeGreaterThanOrEqual(0);
  });

  test('Login Page - Screenshot and Buttons', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '02-login-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Login Page', '02-login');
    
    // Test form inputs
    const emailInput = page.locator('[data-testid="login-email"], input[name="email"]').first();
    if (await emailInput.isVisible().catch(() => false)) {
      await emailInput.fill('test@example.com');
      await page.waitForTimeout(500);
      await page.screenshot({ 
        path: path.join(screenshotsDir, '02-login-filled.png'),
        fullPage: true 
      });
    }
  });

  test('Dashboard - Screenshot and All Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '03-dashboard-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Dashboard', '03-dashboard');
    
    // Test navigation buttons
    const navLinks = page.locator('nav a, nav button, [role="navigation"] a');
    const navCount = await navLinks.count();
    console.log(`Dashboard: Found ${navCount} navigation links`);
    
    for (let i = 0; i < Math.min(navCount, 10); i++) {
      const link = navLinks.nth(i);
      if (await link.isVisible().catch(() => false)) {
        await link.hover();
        await page.waitForTimeout(300);
      }
    }
  });

  test('Predictions Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/predictions`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '04-predictions-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Predictions', '04-predictions');
    
    // Test generate button
    const generateBtn = page.locator('button:has-text("Generate"), button:has-text("Predict"), button:has-text("توقع"), [data-testid*="generate"]');
    if (await generateBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await generateBtn.first().hover();
      await page.waitForTimeout(300);
    }
  });

  test('Assets Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/assets`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '05-assets-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Assets', '05-assets');
    
    // Test action buttons (view, edit, delete)
    const actionButtons = page.locator('button:has-text("View"), button:has-text("Edit"), button:has-text("Delete"), button:has-text("عرض"), button:has-text("تعديل"), button:has-text("حذف")');
    const actionCount = await actionButtons.count();
    console.log(`Assets: Found ${actionCount} action buttons`);
    
    for (let i = 0; i < Math.min(actionCount, 5); i++) {
      const btn = actionButtons.nth(i);
      if (await btn.isVisible().catch(() => false)) {
        await btn.hover();
        await page.waitForTimeout(300);
      }
    }
  });

  test('Alerts Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '06-alerts-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Alerts', '06-alerts');
    
    // Test create button
    const createBtn = page.locator('button:has-text("Create"), button:has-text("Add"), button:has-text("New"), button:has-text("إضافة"), [data-testid*="create"]');
    if (await createBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await createBtn.first().hover();
      await page.waitForTimeout(300);
    }
    
    // Test toggle switches
    const toggles = page.locator('[role="switch"], input[type="checkbox"]:visible');
    const toggleCount = await toggles.count();
    console.log(`Alerts: Found ${toggleCount} toggles`);
  });

  test('Reports Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/reports`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '07-reports-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Reports', '07-reports');
  });

  test('Portfolio Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/portfolio`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '08-portfolio-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Portfolio', '08-portfolio');
  });

  test('Settings Page - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/settings`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '09-settings-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Settings', '09-settings');
    
    // Test save button
    const saveBtn = page.locator('button:has-text("Save"), button:has-text("حفظ"), button[type="submit"]');
    if (await saveBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await saveBtn.first().hover();
      await page.waitForTimeout(300);
    }
    
    // Test toggle switches
    const switches = page.locator('[role="switch"], input[type="checkbox"]:visible');
    const switchCount = await switches.count();
    console.log(`Settings: Found ${switchCount} switches`);
  });

  test('Admin Dashboard - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/admin`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '10-admin-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Admin Dashboard', '10-admin');
  });

  test('Admin Users - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/admin/users`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '11-admin-users-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Admin Users', '11-admin-users');
  });

  test('Admin Assets - Screenshot and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/admin/assets`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, '12-admin-assets-full.png'),
      fullPage: true 
    });

    const buttons = await testAllButtons(page, 'Admin Assets', '12-admin-assets');
  });

  test('All Navigation Links - Test and Screenshot', async ({ page }) => {
    await loginAsAdmin(page);
    
    const pages = [
      { path: '/dashboard', name: 'dashboard' },
      { path: '/predictions', name: 'predictions' },
      { path: '/assets', name: 'assets' },
      { path: '/alerts', name: 'alerts' },
      { path: '/reports', name: 'reports' },
      { path: '/portfolio', name: 'portfolio' },
      { path: '/settings', name: 'settings' },
      { path: '/admin', name: 'admin' },
    ];

    for (const pageInfo of pages) {
      await page.goto(`${BASE_URL}${pageInfo.path}`);
      await page.waitForLoadState('networkidle');
      await page.waitForTimeout(2000);

      await page.screenshot({ 
        path: path.join(screenshotsDir, `nav-${pageInfo.name}.png`),
        fullPage: true 
      });

      const buttons = await testAllButtons(page, pageInfo.name, `nav-${pageInfo.name}`);
      console.log(`${pageInfo.name}: Tested ${buttons.length} buttons`);
    }
  });

  test('Button States - Hover, Active, Disabled', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    const buttons = page.locator('button:visible');
    const buttonCount = await buttons.count();
    console.log(`Testing ${buttonCount} buttons for states`);

    let testedCount = 0;
    for (let i = 0; i < buttonCount && testedCount < 25; i++) {
      const button = buttons.nth(i);
      
      if (await button.isVisible().catch(() => false)) {
        const isEnabled = await button.isEnabled().catch(() => false);
        const text = (await button.textContent() || `button-${i}`).trim();
        
        // Test hover state
        try {
          await button.hover({ timeout: 2000 });
          await page.waitForTimeout(300);
          await button.screenshot({ 
            path: path.join(screenshotsDir, `button-state-${testedCount}-hover.png`) 
          }).catch(() => {});
        } catch (e) {
          // Ignore hover errors
        }

        // Test click if enabled
        if (isEnabled) {
          try {
            await button.click({ force: true, timeout: 2000 });
            await page.waitForTimeout(500);
            await button.screenshot({ 
              path: path.join(screenshotsDir, `button-state-${testedCount}-clicked.png`) 
            }).catch(() => {});
            // Undo click if possible
            await page.keyboard.press('Escape');
            await page.waitForTimeout(300);
          } catch (e) {
            // Ignore click errors
          }
        } else {
          await button.screenshot({ 
            path: path.join(screenshotsDir, `button-state-${testedCount}-disabled.png`) 
          }).catch(() => {});
        }

        testedCount++;
      }
    }

    console.log(`Tested ${testedCount} buttons`);
  });

  test('Form Inputs and Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/settings`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    // Test all inputs
    const inputs = page.locator('input:visible, textarea:visible, select:visible');
    const inputCount = await inputs.count();
    console.log(`Found ${inputCount} form inputs`);

    for (let i = 0; i < Math.min(inputCount, 10); i++) {
      const input = inputs.nth(i);
      if (await input.isVisible().catch(() => false)) {
        const inputType = await input.getAttribute('type') || 'text';
        
        // Test empty state
        await input.screenshot({ 
          path: path.join(screenshotsDir, `input-${i}-empty.png`) 
        }).catch(() => {});

        // Test filled state
        try {
          if (inputType === 'email') {
            await input.fill('test@example.com');
          } else if (inputType === 'number') {
            await input.fill('100');
          } else {
            await input.fill('Test Value');
          }
          await page.waitForTimeout(500);
          await input.screenshot({ 
            path: path.join(screenshotsDir, `input-${i}-filled.png`) 
          }).catch(() => {});
        } catch (e) {
          // Ignore fill errors
        }

        // Test focused state
        try {
          await input.focus();
          await page.waitForTimeout(300);
          await input.screenshot({ 
            path: path.join(screenshotsDir, `input-${i}-focused.png`) 
          }).catch(() => {});
        } catch (e) {
          // Ignore focus errors
        }
      }
    }
  });

  test('Modal and Dialog Buttons', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    // Try to open a dialog by clicking create button
    const createButtons = page.locator('button:has-text("Create"), button:has-text("Add"), button:has-text("New"), button:has-text("إضافة"), [data-testid*="create"]');
    if (await createButtons.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await createButtons.first().click();
      await page.waitForTimeout(1000);

      // Take screenshot of dialog
      await page.screenshot({ 
        path: path.join(screenshotsDir, 'dialog-opened.png'),
        fullPage: true 
      });

      // Test dialog buttons
      const dialogButtons = page.locator('[role="dialog"] button, [data-testid*="dialog"] button');
      const dialogButtonCount = await dialogButtons.count();
      console.log(`Found ${dialogButtonCount} dialog buttons`);

      for (let i = 0; i < dialogButtonCount; i++) {
        const button = dialogButtons.nth(i);
        if (await button.isVisible().catch(() => false)) {
          await button.hover();
          await page.waitForTimeout(300);
        }
      }

      // Close dialog
      const closeButton = page.locator('button:has-text("Close"), button:has-text("Cancel"), button:has-text("إغلاق"), button:has-text("إلغاء"), [aria-label*="close"]');
      if (await closeButton.first().isVisible({ timeout: 3000 }).catch(() => false)) {
        await closeButton.first().click();
        await page.waitForTimeout(500);
      } else {
        await page.keyboard.press('Escape');
        await page.waitForTimeout(500);
      }
    }
  });

  test('Dropdown and Select Elements', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/admin/users`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    // Test select dropdowns
    const selects = page.locator('select:visible, [role="combobox"]:visible');
    const selectCount = await selects.count();
    console.log(`Found ${selectCount} select elements`);

    for (let i = 0; i < Math.min(selectCount, 5); i++) {
      const select = selects.nth(i);
      if (await select.isVisible().catch(() => false)) {
        await select.click();
        await page.waitForTimeout(500);
        await page.screenshot({ 
          path: path.join(screenshotsDir, `select-${i}-open.png`),
          fullPage: true 
        }).catch(() => {});
        // Close dropdown
        await page.keyboard.press('Escape');
        await page.waitForTimeout(300);
      }
    }
  });

  test('User Menu and Navigation', async ({ page }) => {
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    // Test user menu
    const userMenu = page.locator('[data-testid="user-menu"], button[aria-haspopup="menu"], .user-avatar, [aria-label*="user"]').first();
    if (await userMenu.isVisible({ timeout: 3000 }).catch(() => false)) {
      await userMenu.click();
      await page.waitForTimeout(500);
      await page.screenshot({ 
        path: path.join(screenshotsDir, 'user-menu-open.png'),
        fullPage: true 
      });
      
      // Test menu items
      const menuItems = page.locator('[role="menuitem"]');
      const count = await menuItems.count();
      console.log(`User menu has ${count} items`);
      
      for (let i = 0; i < Math.min(count, 5); i++) {
        const item = menuItems.nth(i);
        if (await item.isVisible().catch(() => false)) {
          await item.hover();
          await page.waitForTimeout(300);
        }
      }
      
      // Close menu
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    }
  });

  test('Theme Toggle and Settings', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(2000);

    // Test theme toggle
    const themeBtn = page.locator('[data-testid="theme-toggle"], button[aria-label*="theme"], button:has-text("🌙"), button:has-text("☀️")');
    if (await themeBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await themeBtn.first().click();
      await page.waitForTimeout(1000);
      await page.screenshot({ 
        path: path.join(screenshotsDir, 'theme-dark.png'),
        fullPage: true 
      });
      
      await themeBtn.first().click();
      await page.waitForTimeout(1000);
      await page.screenshot({ 
        path: path.join(screenshotsDir, 'theme-light.png'),
        fullPage: true 
      });
    }
  });

  test('Mobile View - All Buttons', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });
    await loginAsAdmin(page);
    
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);

    await page.screenshot({ 
      path: path.join(screenshotsDir, 'mobile-dashboard.png'),
      fullPage: true 
    });

    // Test mobile menu
    const mobileMenuBtn = page.locator('button:has-text("المزيد"), button[aria-label*="menu"], [data-testid*="mobile-menu"]').first();
    if (await mobileMenuBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
      await mobileMenuBtn.click();
      await page.waitForTimeout(500);
      await page.screenshot({ 
        path: path.join(screenshotsDir, 'mobile-menu-open.png'),
        fullPage: true 
      });
    }

    const buttons = await testAllButtons(page, 'Mobile Dashboard', 'mobile');
  });

});

