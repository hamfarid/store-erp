/**
 * E2E Tests: History Page
 * User Story 5 - عرض البيانات التاريخية (Historical Data Display)
 *
 * Constitution Principle V: Test-Driven Quality
 */

import { test, expect } from '@playwright/test';
import { login } from '../helpers/auth';

test.describe('History Page - User Story 5', () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
    // Try different possible URLs for history page
    const historyUrls = ['/history', '/historical', '/price-history', '/historical-prices'];

    for (const url of historyUrls) {
      try {
        await page.goto(url, { waitUntil: 'networkidle', timeout: 5000 });
        if (!page.url().includes('404') && !page.url().includes('error')) {
          break;
        }
      } catch {
        continue;
      }
    }
  });

  test('history page shows asset selector', async ({ page }) => {
    const assetSelector = page.locator(
      '[data-testid="asset-selector"], ' +
      'select[name="asset"], ' +
      '[role="combobox"], ' +
      '[class*="asset-select"]'
    ).first();

    await expect(assetSelector).toBeVisible({ timeout: 10000 });
  });

  test('history page shows period selector', async ({ page }) => {
    const periodSelector = page.locator(
      '[data-testid="period-selector"], ' +
      'select[name="period"], ' +
      'button:has-text("7 أيام"), ' +
      'button:has-text("30 يوم"), ' +
      'button:has-text("7 Days"), ' +
      'button:has-text("30 Days"), ' +
      '[class*="period"], ' +
      '[class*="range"]'
    ).first();

    await expect(periodSelector).toBeVisible({ timeout: 10000 });
  });

  test('history page shows OHLC chart', async ({ page }) => {
    // Look for chart elements
    const chartElements = page.locator(
      'canvas, ' +
      'svg, ' +
      '.recharts-wrapper, ' +
      '[class*="chart"], ' +
      '[data-testid="ohlc-chart"], ' +
      '[data-testid="price-chart"]'
    );

    const hasChart = await chartElements.count() > 0;
    expect(hasChart).toBe(true);
  });

  test('T152.1: can enable Moving Average indicators', async ({ page }) => {
    // Look for indicator toggles
    const maToggle = page.locator(
      '[data-testid="ma-toggle"], ' +
      'button:has-text("MA"), ' +
      'button:has-text("Moving Average"), ' +
      'button:has-text("المتوسط"), ' +
      '[class*="indicator"]'
    ).first();

    if (await maToggle.isVisible()) {
      await maToggle.click();
      await page.waitForTimeout(500);

      // Verify MA lines appear (check for legend or data series)
      const maLegend = page.locator(
        ':text("MA7"), ' +
        ':text("MA30"), ' +
        ':text("MA90"), ' +
        '[class*="moving-average"]'
      );

      console.log(`MA indicator count: ${await maLegend.count()}`);
    }
  });

  test('T152.2: can enable RSI indicator', async ({ page }) => {
    const rsiToggle = page.locator(
      '[data-testid="rsi-toggle"], ' +
      'button:has-text("RSI"), ' +
      'button:has-text("القوة النسبية"), ' +
      '[class*="rsi"]'
    ).first();

    if (await rsiToggle.isVisible()) {
      await rsiToggle.click();
      await page.waitForTimeout(500);
    }
  });

  test('export button is available', async ({ page }) => {
    const exportButton = page.locator(
      '[data-testid="export-button"], ' +
      'button:has-text("تصدير"), ' +
      'button:has-text("Export"), ' +
      'button:has-text("CSV"), ' +
      'button:has-text("JSON"), ' +
      '[class*="export"]'
    ).first();

    await expect(exportButton).toBeVisible({ timeout: 10000 });
  });

  test('can export data as CSV', async ({ page }) => {
    const csvButton = page.locator(
      'button:has-text("CSV"), ' +
      '[data-testid="export-csv"], ' +
      'a[download*=".csv"]'
    ).first();

    if (await csvButton.isVisible()) {
      // Set up download listener
      const downloadPromise = page.waitForEvent('download', { timeout: 5000 }).catch(() => null);
      await csvButton.click();

      const download = await downloadPromise;
      if (download) {
        const filename = download.suggestedFilename();
        expect(filename).toMatch(/\.csv$/i);
      }
    }
  });

  test('Arabic RTL rendering on history page', async ({ page }) => {
    const htmlElement = page.locator('html');
    const dir = await htmlElement.getAttribute('dir');
    const lang = await htmlElement.getAttribute('lang');

    const pageText = await page.textContent('body');
    const hasArabicText = /[\u0600-\u06FF]/.test(pageText || '');

    expect(dir === 'rtl' || lang === 'ar' || hasArabicText).toBe(true);
  });

  test('history data shows OHLC values', async ({ page }) => {
    // Look for OHLC labels
    const ohlcLabels = page.locator(
      ':text("Open"), ' +
      ':text("High"), ' +
      ':text("Low"), ' +
      ':text("Close"), ' +
      ':text("الافتتاح"), ' +
      ':text("الأعلى"), ' +
      ':text("الأدنى"), ' +
      ':text("الإغلاق"), ' +
      '[class*="ohlc"]'
    );

    const hasOhlcLabels = await ohlcLabels.count() > 0;

    // Or check table headers
    const tableHeaders = page.locator('th, [role="columnheader"]');
    const headerTexts = await tableHeaders.allTextContents();
    const hasOhlcHeaders = headerTexts.some(text =>
      /open|high|low|close|افتتاح|أعلى|أدنى|إغلاق/i.test(text)
    );

    expect(hasOhlcLabels || hasOhlcHeaders).toBe(true);
  });
});

test.describe('History API Integration', () => {
  test('historical prices endpoint returns data', async ({ request }) => {
    const response = await request.get('/api/assets/1/prices');
    expect([200, 401, 403, 404]).toContain(response.status());
  });

  test('technical indicators endpoint returns data', async ({ request }) => {
    const response = await request.get('/api/technical-indicators');
    expect([200, 401, 403]).toContain(response.status());
  });
});
