/**
 * Button Tests
 * Comprehensive tests for all buttons and interactive elements
 * Updated for Arabic UI support
 */

import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:2501';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@goldpredictor.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@123456';

// Helper function to login with robust handling
async function loginAsAdmin(page: Page) {
  await page.goto(`${BASE_URL}/login`);
  await page.waitForLoadState('networkidle');
  
  // Wait for login form to be visible
  await page.waitForSelector('[data-testid="login-email"]', { state: 'visible', timeout: 10000 });
  await page.waitForSelector('[data-testid="login-password"]', { state: 'visible', timeout: 10000 });
  await page.waitForSelector('[data-testid="login-submit"]', { state: 'visible', timeout: 10000 });
  
  await page.locator('[data-testid="login-email"]').fill(ADMIN_EMAIL);
  await page.locator('[data-testid="login-password"]').fill(ADMIN_PASSWORD);
  await page.locator('[data-testid="login-submit"]').click();
  
  // Wait for navigation away from login
  await page.waitForFunction(() => !window.location.pathname.includes('/login'), { timeout: 15000 }).catch(() => {});
  await page.waitForLoadState('networkidle');
}

// Helper to test all buttons on a page
async function testPageButtons(page: Page, pageName: string) {
  const buttons = page.locator('button:visible');
  const buttonCount = await buttons.count();
  
  console.log(`\n📍 ${pageName}: Found ${buttonCount} visible buttons`);
  
  const buttonInfo: { text: string; enabled: boolean }[] = [];
  
  for (let i = 0; i < Math.min(buttonCount, 20); i++) { // Limit to 20 for performance
    const button = buttons.nth(i);
    const text = await button.textContent() || 'No text';
    const enabled = await button.isEnabled();
    buttonInfo.push({ text: text.trim(), enabled });
  }
  
  // Log button info
  buttonInfo.forEach((btn, idx) => {
    const status = btn.enabled ? '✅' : '❌';
    console.log(`  ${status} [${idx}] "${btn.text.substring(0, 30)}..."`);
  });
  
  return buttonInfo;
}

test.describe('Home Page Buttons', () => {
  test('All home page buttons are functional', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Home Page');
    
    // Test login button (Arabic: تسجيل الدخول, English: Login)
    const loginBtn = page.locator('a[href*="login"], button:has-text("Login"), button:has-text("تسجيل الدخول")');
    if (await loginBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await loginBtn.first().click();
      await expect(page).toHaveURL(/.*login/);
    }
  });
});

test.describe('Login Page Buttons', () => {
  test('Login form buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Login Page');
    
    // Submit button should be enabled
    const submitBtn = page.locator('[data-testid="login-submit"]');
    expect(await submitBtn.isEnabled()).toBeTruthy();
  });
  
  test('Register link works', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.waitForLoadState('networkidle');
    
    const registerLink = page.locator('a[href*="register"]');
    if (await registerLink.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await registerLink.first().click();
      await expect(page).toHaveURL(/.*register/);
    }
  });
});

test.describe('Dashboard Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Dashboard action buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Dashboard');
    
    // All visible buttons should be enabled
    buttons.forEach(btn => {
      expect(btn.enabled).toBeTruthy();
    });
  });

  test('Dashboard navigation buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    // Test refresh button if exists (Arabic: تحديث, English: Refresh)
    const refreshBtn = page.locator('button:has-text("Refresh"), button:has-text("تحديث"), [data-testid="refresh"]');
    if (await refreshBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await refreshBtn.first().click();
      await page.waitForLoadState('networkidle');
    }
    
    await expect(page.locator('body')).toBeVisible();
  });
});

test.describe('Predictions Page Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Prediction buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/predictions`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Predictions');
    await expect(page.locator('body')).toBeVisible();
  });

  test('Generate prediction button works', async ({ page }) => {
    await page.goto(`${BASE_URL}/predictions`);
    await page.waitForLoadState('networkidle');
    
    // Arabic: توقع, English: Generate/Predict
    const generateBtn = page.locator('button:has-text("Generate"), button:has-text("Predict"), button:has-text("توقع"), button:has-text("إنشاء"), [data-testid="generate-prediction"]');
    
    if (await generateBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      expect(await generateBtn.first().isEnabled()).toBeTruthy();
    }
  });
});

test.describe('Assets Page Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Assets list buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/assets`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Assets');
    await expect(page.locator('body')).toBeVisible();
  });

  test('Asset action buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/assets`);
    await page.waitForLoadState('networkidle');
    
    // View buttons (Arabic: عرض, English: View)
    const viewBtns = page.locator('button:has-text("View"), button:has-text("عرض"), [data-testid*="view"]');
    if (await viewBtns.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      expect(await viewBtns.first().isEnabled()).toBeTruthy();
    }
    
    // Edit buttons (Arabic: تعديل, English: Edit)
    const editBtns = page.locator('button:has-text("Edit"), button:has-text("تعديل"), [data-testid*="edit"]');
    if (await editBtns.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      expect(await editBtns.first().isEnabled()).toBeTruthy();
    }
  });
});

test.describe('Alerts Page Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Alerts buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Alerts');
    await expect(page.locator('body')).toBeVisible();
  });

  test('Create alert button works', async ({ page }) => {
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    
    // Arabic: إضافة/جديد, English: Create/Add/New
    const createBtn = page.locator('button:has-text("Create"), button:has-text("Add"), button:has-text("New"), button:has-text("إضافة"), button:has-text("جديد"), [data-testid="create-alert"]');
    
    if (await createBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      await createBtn.first().click();
      await page.waitForTimeout(500);
    }
    
    await expect(page.locator('body')).toBeVisible();
  });

  test('Alert toggle buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    
    // Toggle switches for enabling/disabling alerts
    const toggles = page.locator('[role="switch"], input[type="checkbox"]:visible');
    const toggleCount = await toggles.count();
    
    console.log(`Found ${toggleCount} toggles`);
    
    if (toggleCount > 0) {
      expect(await toggles.first().isEnabled()).toBeTruthy();
    }
  });
});

test.describe('Admin Page Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Admin dashboard buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/admin`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Admin Dashboard');
    await expect(page.locator('body')).toBeVisible();
  });

  test('Admin user management buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/admin/users`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Admin Users');
    
    // Role change buttons
    const roleSelects = page.locator('select[name="role"]');
    if (await roleSelects.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      expect(await roleSelects.first().isEnabled()).toBeTruthy();
    }
  });

  test('Admin asset management buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/admin/assets`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Admin Assets');
    await expect(page.locator('body')).toBeVisible();
  });
});

test.describe('Settings Page Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Settings buttons are functional', async ({ page }) => {
    await page.goto(`${BASE_URL}/settings`);
    await page.waitForLoadState('networkidle');
    
    const buttons = await testPageButtons(page, 'Settings');
    await expect(page.locator('body')).toBeVisible();
  });

  test('Save settings button works', async ({ page }) => {
    await page.goto(`${BASE_URL}/settings`);
    await page.waitForLoadState('networkidle');
    
    // Arabic: حفظ, English: Save
    const saveBtn = page.locator('button:has-text("Save"), button:has-text("حفظ"), button[type="submit"]');
    
    if (await saveBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
      expect(await saveBtn.first().isEnabled()).toBeTruthy();
    }
  });
});

test.describe('Modal and Dialog Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Dialog close buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    // Try to open a modal
    const modalTrigger = page.locator('button:has-text("New"), button:has-text("Create"), button:has-text("Add"), button:has-text("جديد"), button:has-text("إضافة")').first();
    
    if (await modalTrigger.isVisible({ timeout: 3000 }).catch(() => false)) {
      await modalTrigger.click();
      await page.waitForTimeout(500);
      
      // Check for close button in modal
      const closeBtn = page.locator('[role="dialog"] button:has-text("Close"), [role="dialog"] button:has-text("Cancel"), [role="dialog"] button:has-text("إغلاق"), [role="dialog"] button:has-text("إلغاء"), [role="dialog"] button[aria-label="Close"]');
      
      if (await closeBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
        await closeBtn.first().click();
        await page.waitForTimeout(300);
      }
    }
    
    await expect(page.locator('body')).toBeVisible();
  });

  test('Confirmation dialog buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/alerts`);
    await page.waitForLoadState('networkidle');
    
    // Find delete button (Arabic: حذف, English: Delete)
    const deleteBtn = page.locator('button:has-text("Delete"), button:has-text("حذف"), [data-testid*="delete"]').first();
    
    if (await deleteBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
      await deleteBtn.click();
      await page.waitForTimeout(500);
      
      // Check for confirmation dialog (Arabic: تأكيد/نعم/إلغاء/لا)
      const cancelBtn = page.locator('button:has-text("Cancel"), button:has-text("No"), button:has-text("إلغاء"), button:has-text("لا")');
      
      if (await cancelBtn.first().isVisible({ timeout: 3000 }).catch(() => false)) {
        await cancelBtn.first().click();
      }
    }
    
    await expect(page.locator('body')).toBeVisible();
  });
});

test.describe('Dropdown and Menu Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('User menu dropdown works', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    // Find user avatar/menu button
    const userMenu = page.locator('[data-testid="user-menu"], button[aria-haspopup="menu"], .user-avatar').first();
    
    if (await userMenu.isVisible({ timeout: 3000 }).catch(() => false)) {
      await userMenu.click();
      await page.waitForTimeout(300);
      
      // Check dropdown items
      const menuItems = page.locator('[role="menuitem"]');
      const count = await menuItems.count();
      console.log(`User menu has ${count} items`);
    }
    
    await expect(page.locator('body')).toBeVisible();
  });

  test('Navigation menu buttons work', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    // Mobile menu button (Arabic: المزيد, English: Menu)
    const menuBtn = page.locator('button[aria-label*="Menu"], button:has-text("Menu"), button:has-text("المزيد")').first();
    
    if (await menuBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
      await menuBtn.click();
      await page.waitForTimeout(300);
    }
    
    await expect(page.locator('body')).toBeVisible();
  });
});

test.describe('Form Submit Buttons', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('All form submit buttons are properly typed', async ({ page }) => {
    await page.goto(`${BASE_URL}/settings`);
    await page.waitForLoadState('networkidle');
    
    const submitButtons = page.locator('button[type="submit"], input[type="submit"]');
    const count = await submitButtons.count();
    
    console.log(`Found ${count} submit buttons`);
    
    for (let i = 0; i < Math.min(count, 5); i++) {
      const btn = submitButtons.nth(i);
      if (await btn.isVisible()) {
        expect(await btn.isEnabled()).toBeTruthy();
      }
    }
  });
});

test.describe('Button Accessibility', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('Buttons have accessible names', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    const buttons = page.locator('button');
    const count = await buttons.count();
    
    let accessibleCount = 0;
    
    for (let i = 0; i < Math.min(count, 20); i++) {
      const btn = buttons.nth(i);
      if (await btn.isVisible()) {
        const ariaLabel = await btn.getAttribute('aria-label');
        const text = await btn.textContent();
        const title = await btn.getAttribute('title');
        
        if (ariaLabel || (text && text.trim()) || title) {
          accessibleCount++;
        }
      }
    }
    
    console.log(`${accessibleCount} buttons have accessible names`);
    expect(accessibleCount).toBeGreaterThan(0);
  });

  test('Icon-only buttons have aria-labels', async ({ page }) => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState('networkidle');
    
    // Find buttons that only contain icons
    const iconButtons = page.locator('button:has(svg)');
    const count = await iconButtons.count();
    
    console.log(`Found ${count} icon buttons`);
    
    for (let i = 0; i < Math.min(count, 5); i++) {
      const btn = iconButtons.nth(i);
      if (await btn.isVisible()) {
        const ariaLabel = await btn.getAttribute('aria-label');
        const title = await btn.getAttribute('title');
        const text = await btn.textContent();
        
        // At least one accessibility attribute should exist
        if (!ariaLabel && !title && (!text || !text.trim())) {
          console.warn(`Button ${i} may be missing accessible name`);
        }
      }
    }
    
    await expect(page.locator('body')).toBeVisible();
  });
});
