/**
 * E2E Tests: Learning Control Dashboard
 * User Story 4 - لوحة التحكم في التعلم (Learning Control Dashboard)
 *
 * Constitution Principle V: Test-Driven Quality
 */

import { test, expect } from '@playwright/test';
import { login } from '../helpers/auth';

test.describe('Learning Control Dashboard - User Story 4', () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
    // Try different possible URLs for learning dashboard
    const learningUrls = [
      '/learning',
      '/learning-control',
      '/admin/learning',
      '/learning-control-dashboard'
    ];

    for (const url of learningUrls) {
      try {
        await page.goto(url, { waitUntil: 'networkidle', timeout: 5000 });
        if (!page.url().includes('404') && !page.url().includes('error')) {
          break;
        }
      } catch {
        continue;
      }
    }
  });

  test('learning dashboard renders main sections', async ({ page }) => {
    // Check for main sections: Jobs, Keywords, Sources, Insights
    const sections = page.locator(
      '[data-testid="learning-tabs"], ' +
      '[role="tablist"], ' +
      'button:has-text("المهام"), ' +
      'button:has-text("Jobs"), ' +
      'button:has-text("الكلمات"), ' +
      'button:has-text("Keywords")'
    );

    const hasSections = await sections.count() > 0;

    // Or check for section headers
    const sectionHeaders = page.locator(
      'h2, h3, [class*="section-title"]'
    );
    const headerTexts = await sectionHeaders.allTextContents();
    const hasLearningContent = headerTexts.some(text =>
      /jobs|keywords|sources|insights|مهام|كلمات|مصادر|رؤى/i.test(text)
    );

    expect(hasSections || hasLearningContent).toBe(true);
  });

  test('can view active jobs', async ({ page }) => {
    // Look for jobs list
    const jobsList = page.locator(
      '[data-testid="jobs-list"], ' +
      '.jobs-list, ' +
      '[class*="job"], ' +
      'table'
    ).first();

    if (await jobsList.isVisible()) {
      await expect(jobsList).toBeVisible();
    }
  });

  test('can start comparison job', async ({ page }) => {
    const startButton = page.locator(
      'button:has-text("بدء المقارنة"), ' +
      'button:has-text("Start Comparison"), ' +
      '[data-testid="start-comparison"]'
    ).first();

    if (await startButton.isVisible()) {
      await expect(startButton).toBeEnabled();
    }
  });

  test('can manage keywords', async ({ page }) => {
    // Navigate to keywords tab if needed
    const keywordsTab = page.locator(
      'button:has-text("الكلمات"), ' +
      'button:has-text("Keywords"), ' +
      '[data-testid="keywords-tab"]'
    ).first();

    if (await keywordsTab.isVisible()) {
      await keywordsTab.click();
      await page.waitForTimeout(500);
    }

    // Look for add keyword button
    const addButton = page.locator(
      'button:has-text("إضافة"), ' +
      'button:has-text("Add"), ' +
      '[data-testid="add-keyword"]'
    ).first();

    if (await addButton.isVisible()) {
      await expect(addButton).toBeVisible();
    }
  });

  test('can manage sources', async ({ page }) => {
    // Navigate to sources tab if needed
    const sourcesTab = page.locator(
      'button:has-text("المصادر"), ' +
      'button:has-text("Sources"), ' +
      '[data-testid="sources-tab"]'
    ).first();

    if (await sourcesTab.isVisible()) {
      await sourcesTab.click();
      await page.waitForTimeout(500);
    }

    // Look for sources list or add button
    const sourceElements = page.locator(
      '[data-testid="sources-list"], ' +
      '.source-item, ' +
      '[class*="source"]'
    );

    const hasSourceElements = await sourceElements.count() > 0;
    console.log(`Source elements found: ${await sourceElements.count()}`);
  });

  test('shows learning insights', async ({ page }) => {
    // Navigate to insights tab if needed
    const insightsTab = page.locator(
      'button:has-text("الرؤى"), ' +
      'button:has-text("Insights"), ' +
      '[data-testid="insights-tab"]'
    ).first();

    if (await insightsTab.isVisible()) {
      await insightsTab.click();
      await page.waitForTimeout(500);
    }

    // Look for insights content
    const insightsContent = page.locator(
      '[data-testid="insights-list"], ' +
      '.insights, ' +
      '[class*="insight"]'
    );

    const hasInsights = await insightsContent.count() > 0;
    console.log(`Insights elements found: ${await insightsContent.count()}`);
  });

  test('job progress updates in real-time', async ({ page }) => {
    // Look for progress indicators
    const progressIndicators = page.locator(
      '[role="progressbar"], ' +
      '[data-testid="job-progress"], ' +
      '.progress-bar, ' +
      '[class*="progress"]'
    );

    const hasProgress = await progressIndicators.count() > 0;

    // Or check for status indicators
    const statusIndicators = page.locator(
      ':text("جاري"), ' +
      ':text("Running"), ' +
      ':text("Completed"), ' +
      ':text("مكتمل"), ' +
      '[class*="status"]'
    );

    const hasStatus = await statusIndicators.count() > 0;

    expect(hasProgress || hasStatus).toBe(true);
  });

  test('Arabic RTL rendering on learning page', async ({ page }) => {
    const htmlElement = page.locator('html');
    const dir = await htmlElement.getAttribute('dir');
    const lang = await htmlElement.getAttribute('lang');

    const pageText = await page.textContent('body');
    const hasArabicText = /[\u0600-\u06FF]/.test(pageText || '');

    expect(dir === 'rtl' || lang === 'ar' || hasArabicText).toBe(true);
  });
});

test.describe('Learning API Integration', () => {
  test('learning insights endpoint returns data', async ({ request }) => {
    const response = await request.get('/api/learning/insights');
    expect([200, 401, 403]).toContain(response.status());
  });

  test('learning jobs endpoint returns data', async ({ request }) => {
    const response = await request.get('/api/learning/jobs');
    expect([200, 401, 403]).toContain(response.status());
  });
});
