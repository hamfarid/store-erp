/**
 * Error Analysis Test
 * Tests all pages and collects errors for analysis
 */

import { test, expect } from "@playwright/test";

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || "http://localhost:2501";

interface PageError {
  route: string;
  name: string;
  errors: string[];
  warnings: string[];
  buttons: number;
  brokenLinks: number;
}

const allRoutes = [
  { path: "/", name: "Home", public: true },
  { path: "/login", name: "Login", public: true },
  { path: "/register", name: "Register", public: true },
  { path: "/dashboard", name: "Dashboard", public: false },
  { path: "/predictions", name: "Predictions", public: false },
  { path: "/alerts", name: "Alerts", public: false },
  { path: "/assets", name: "Assets", public: false },
  { path: "/reports", name: "Reports", public: false },
  { path: "/portfolio", name: "Portfolio", public: false },
  { path: "/settings", name: "Settings", public: false },
  { path: "/admin", name: "Admin Dashboard", public: false, admin: true },
  { path: "/admin/users", name: "Admin Users", public: false, admin: true },
  { path: "/admin/assets", name: "Admin Assets", public: false, admin: true },
  { path: "/fear-greed", name: "Fear Greed Index", public: false },
  { path: "/news-sentiment", name: "News Sentiment", public: false },
  { path: "/expert-opinions", name: "Expert Opinions", public: false },
  { path: "/learning-control", name: "Learning Control", public: false },
  { path: "/system-health", name: "System Health", public: false },
  { path: "/drift-detection", name: "Drift Detection", public: false },
];

test.describe("Error Analysis", () => {
  const pageErrors: PageError[] = [];

  test("Analyze all pages for errors", async ({ page }) => {
    // Listen to console errors
    const consoleErrors: string[] = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") {
        consoleErrors.push(msg.text());
      }
    });

    // Listen to page errors
    const pageErrorsList: string[] = [];
    page.on("pageerror", (error) => {
      pageErrorsList.push(error.message);
    });

    // Listen to failed requests
    const failedRequests: string[] = [];
    page.on("requestfailed", (request) => {
      failedRequests.push(`${request.method()} ${request.url()} - ${request.failure()?.errorText}`);
    });

    for (const route of allRoutes) {
      const errors: string[] = [];
      const warnings: string[] = [];

      try {
        console.log(`Testing ${route.name} (${route.path})`);
        
        await page.goto(`${BASE_URL}${route.path}`, {
          waitUntil: "domcontentloaded",
          timeout: 30000,
        });

        await page.waitForTimeout(2000);

        // Check for redirects (authentication)
        const currentUrl = page.url();
        if (currentUrl.includes("/login") && !route.public) {
          warnings.push("Redirected to login (authentication required)");
        }

        // Count buttons
        const buttons = await page.locator("button, a[role='button']").count();

        // Count broken links
        const links = await page.locator("a[href]").all();
        let brokenLinks = 0;
        for (const link of links.slice(0, 10)) {
          const href = await link.getAttribute("href");
          if (href && !href.startsWith("#") && !href.startsWith("http")) {
            // Check if internal link exists
            try {
              const response = await page.goto(`${BASE_URL}${href}`, {
                waitUntil: "domcontentloaded",
                timeout: 5000,
              });
              if (response && response.status() >= 400) {
                brokenLinks++;
              }
            } catch {
              brokenLinks++;
            }
          }
        }

        // Check for error messages in DOM
        const errorElements = await page
          .locator("text=/error|Error|ERROR|خطأ|فشل/i")
          .count();
        if (errorElements > 0) {
          warnings.push(`Found ${errorElements} error text elements on page`);
        }

        // Check for loading states stuck
        const loadingElements = await page
          .locator("[data-loading], .loading, .spinner")
          .count();
        if (loadingElements > 0) {
          warnings.push(`Found ${loadingElements} loading elements (may be stuck)`);
        }

        // Collect console errors for this page
        if (consoleErrors.length > 0) {
          errors.push(...consoleErrors.slice());
          consoleErrors.length = 0; // Clear for next page
        }

        // Collect page errors
        if (pageErrorsList.length > 0) {
          errors.push(...pageErrorsList.slice());
          pageErrorsList.length = 0;
        }

        // Collect failed requests
        if (failedRequests.length > 0) {
          errors.push(...failedRequests.slice());
          failedRequests.length = 0;
        }

        pageErrors.push({
          route: route.path,
          name: route.name,
          errors,
          warnings,
          buttons,
          brokenLinks,
        });
      } catch (error) {
        pageErrors.push({
          route: route.path,
          name: route.name,
          errors: [`Failed to load page: ${error}`],
          warnings: [],
          buttons: 0,
          brokenLinks: 0,
        });
      }
    }

    // Log summary
    console.log("\n=== ERROR ANALYSIS SUMMARY ===");
    const totalErrors = pageErrors.reduce((sum, p) => sum + p.errors.length, 0);
    const totalWarnings = pageErrors.reduce((sum, p) => sum + p.warnings.length, 0);
    const pagesWithErrors = pageErrors.filter((p) => p.errors.length > 0).length;

    console.log(`Total pages tested: ${pageErrors.length}`);
    console.log(`Pages with errors: ${pagesWithErrors}`);
    console.log(`Total errors: ${totalErrors}`);
    console.log(`Total warnings: ${totalWarnings}`);

    // Log errors by page
    pageErrors.forEach((pageError) => {
      if (pageError.errors.length > 0 || pageError.warnings.length > 0) {
        console.log(`\n${pageError.name} (${pageError.route}):`);
        if (pageError.errors.length > 0) {
          console.log(`  Errors (${pageError.errors.length}):`);
          pageError.errors.forEach((err) => console.log(`    - ${err}`));
        }
        if (pageError.warnings.length > 0) {
          console.log(`  Warnings (${pageError.warnings.length}):`);
          pageError.warnings.forEach((warn) => console.log(`    - ${warn}`));
        }
      }
    });

    // Don't fail the test, just report
    expect(pageErrors.length).toBeGreaterThan(0);
  });
});

