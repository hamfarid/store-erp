/**
 * E2E Tests: Events Page
 * User Story 2 - تحليل الأحداث المؤثرة (Event Impact Analysis)
 *
 * Constitution Principle V: Test-Driven Quality
 */

import { test, expect } from '@playwright/test';
import { login } from '../helpers/auth';

test.describe('Events Page - User Story 2', () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
    await page.goto('/events');
    await page.waitForLoadState('networkidle');
  });

  test('events page renders event list', async ({ page }) => {
    // Check for events list container
    const eventsList = page.locator(
      '[data-testid="events-list"], ' +
      '.events-list, ' +
      '[class*="event"], ' +
      'table, ' +
      '[role="list"]'
    ).first();

    await expect(eventsList).toBeVisible({ timeout: 10000 });
  });

  test('can filter events by category', async ({ page }) => {
    // Look for category filter
    const categoryFilter = page.locator(
      '[data-testid="category-filter"], ' +
      'select[name="category"], ' +
      '[role="tablist"], ' +
      'button:has-text("سياسي"), ' +
      'button:has-text("اقتصادي"), ' +
      'button:has-text("Political"), ' +
      'button:has-text("Economic")'
    ).first();

    if (await categoryFilter.isVisible()) {
      await categoryFilter.click();
      // Verify filter interaction works
      await page.waitForTimeout(500);
    }
  });

  test('can filter events by severity', async ({ page }) => {
    // Look for severity filter
    const severityFilter = page.locator(
      '[data-testid="severity-filter"], ' +
      'select[name="severity"], ' +
      'button:has-text("عالية"), ' +
      'button:has-text("High"), ' +
      '[class*="severity"]'
    ).first();

    if (await severityFilter.isVisible()) {
      await expect(severityFilter).toBeVisible();
    }
  });

  test('event shows sentiment analysis', async ({ page }) => {
    // Look for sentiment indicators
    const sentimentIndicators = page.locator(
      '[data-testid="sentiment"], ' +
      '[class*="sentiment"], ' +
      ':text("إيجابي"), ' +
      ':text("سلبي"), ' +
      ':text("محايد"), ' +
      ':text("positive"), ' +
      ':text("negative"), ' +
      ':text("neutral")'
    );

    const hasSentiment = await sentimentIndicators.count() > 0;

    // Check for sentiment scores
    const sentimentScores = page.locator('[class*="score"], :text("%")');
    const hasScores = await sentimentScores.count() > 0;

    expect(hasSentiment || hasScores).toBe(true);
  });

  test('event detail shows impact analysis', async ({ page }) => {
    // Click on first event to see details
    const eventItem = page.locator(
      '[data-testid="event-item"], ' +
      '.event-card, ' +
      'tr, ' +
      '[role="listitem"]'
    ).first();

    if (await eventItem.isVisible()) {
      await eventItem.click();
      await page.waitForTimeout(500);

      // Check for impact analysis elements
      const impactSection = page.locator(
        '[data-testid="impact-analysis"], ' +
        '[class*="impact"], ' +
        ':text("التأثير"), ' +
        ':text("impact"), ' +
        ':text("الأصول المتأثرة"), ' +
        ':text("Affected")'
      );

      // Modal or detail view should show
      const hasImpactInfo = await impactSection.count() > 0;
      console.log(`Impact section visible: ${hasImpactInfo}`);
    }
  });

  test('events page shows recent events', async ({ page }) => {
    // Check for date/time stamps on events
    const timestamps = page.locator(
      'time, ' +
      '[data-testid="event-date"], ' +
      '[class*="date"], ' +
      '[class*="time"]'
    );

    const hasTimestamps = await timestamps.count() > 0;

    // Or check for "recent" section
    const recentSection = page.locator(
      ':text("أحدث"), ' +
      ':text("Recent"), ' +
      ':text("Latest")'
    );

    expect(hasTimestamps || await recentSection.count() > 0).toBe(true);
  });

  test('Arabic RTL rendering on events page', async ({ page }) => {
    const htmlElement = page.locator('html');
    const dir = await htmlElement.getAttribute('dir');
    const lang = await htmlElement.getAttribute('lang');

    const pageText = await page.textContent('body');
    const hasArabicText = /[\u0600-\u06FF]/.test(pageText || '');

    expect(dir === 'rtl' || lang === 'ar' || hasArabicText).toBe(true);
  });
});

test.describe('Events API Integration', () => {
  test('events endpoint returns data', async ({ request }) => {
    const response = await request.get('/api/events');
    expect([200, 401, 403]).toContain(response.status());
  });
});
