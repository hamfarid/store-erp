/**
 * FILE: load-tests/k6-learning-control.js
 * PURPOSE: K6 load testing script for Learning Control Dashboard
 * CREATED: 2026-01-15
 * 
 * Run with: k6 run load-tests/k6-learning-control.js
 */

import http from 'k6/http';
import ws from 'k6/ws';
import { check, sleep, group } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';

// ==================== Configuration ====================

const BASE_URL = __ENV.BASE_URL || 'http://localhost:3000';
const WS_URL = __ENV.WS_URL || 'ws://localhost:3001';
const API_URL = `${BASE_URL}/api/trpc`;

// Custom Metrics
const apiErrors = new Counter('api_errors');
const wsConnections = new Counter('ws_connections');
const wsMessages = new Counter('ws_messages');
const operationDuration = new Trend('operation_duration');
const pageLoadTime = new Trend('page_load_time');

// ==================== Test Options ====================

export const options = {
  scenarios: {
    // Scenario 1: Ramp up to 1000 concurrent users
    load_test: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '2m', target: 100 },   // Ramp up to 100 users
        { duration: '3m', target: 500 },   // Ramp up to 500 users
        { duration: '5m', target: 1000 },  // Ramp up to 1000 users
        { duration: '5m', target: 1000 },  // Stay at 1000 users
        { duration: '3m', target: 500 },   // Ramp down to 500
        { duration: '2m', target: 0 },     // Ramp down to 0
      ],
      gracefulRampDown: '30s',
    },
    
    // Scenario 2: Spike test
    spike_test: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '10s', target: 100 },  // Warm up
        { duration: '1m', target: 100 },   // Stay at 100
        { duration: '10s', target: 1000 }, // Spike to 1000
        { duration: '3m', target: 1000 },  // Stay at 1000
        { duration: '10s', target: 100 },  // Drop back
        { duration: '1m', target: 100 },   // Stay at 100
        { duration: '10s', target: 0 },    // Ramp down
      ],
      startTime: '22m', // Start after load test
    },
    
    // Scenario 3: Stress test
    stress_test: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '2m', target: 500 },
        { duration: '5m', target: 500 },
        { duration: '2m', target: 1500 },  // Push beyond normal
        { duration: '5m', target: 1500 },
        { duration: '2m', target: 2000 },  // Extreme load
        { duration: '5m', target: 2000 },
        { duration: '2m', target: 0 },
      ],
      startTime: '30m', // Start after spike test
    },
  },
  
  thresholds: {
    http_req_duration: ['p(95)<2000', 'p(99)<5000'], // 95% under 2s, 99% under 5s
    http_req_failed: ['rate<0.05'],                   // Error rate under 5%
    'api_errors': ['count<100'],                      // Less than 100 API errors
    'page_load_time': ['p(95)<3000'],                 // Page load under 3s
    'operation_duration': ['p(95)<30000'],            // Operations complete in 30s
  },
};

// ==================== Helper Functions ====================

function getAuthHeaders() {
  // In production, implement proper JWT token fetching
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${__ENV.AUTH_TOKEN || 'test-token'}`,
  };
}

function trpcQuery(procedure, input = {}) {
  const url = `${API_URL}/${procedure}?input=${encodeURIComponent(JSON.stringify(input))}`;
  return http.get(url, { headers: getAuthHeaders() });
}

function trpcMutation(procedure, input = {}) {
  const url = `${API_URL}/${procedure}`;
  return http.post(url, JSON.stringify(input), { headers: getAuthHeaders() });
}

// ==================== Test Scenarios ====================

export default function () {
  // Randomly select a test scenario
  const scenarios = [
    testDashboardLoad,
    testLearningOperations,
    testSearchOperations,
    testKeywordsCRUD,
    testSourcesCRUD,
    testWebSocketConnections,
  ];
  
  const scenario = scenarios[Math.floor(Math.random() * scenarios.length)];
  scenario();
  
  sleep(Math.random() * 2 + 1); // Random sleep 1-3 seconds
}

// ==================== Dashboard Load Test ====================

function testDashboardLoad() {
  group('Dashboard Load', () => {
    const startTime = Date.now();
    
    // Load main page
    const pageRes = http.get(`${BASE_URL}/learning-control`);
    pageLoadTime.add(Date.now() - startTime);
    
    check(pageRes, {
      'page status is 200': (r) => r.status === 200,
      'page contains RTL': (r) => r.body.includes('dir="rtl"') || r.body.includes("dir='rtl'"),
    });
    
    // Fetch stats
    const statsRes = trpcQuery('learningControl.stats.get');
    check(statsRes, {
      'stats status is 200': (r) => r.status === 200,
    });
    
    if (statsRes.status !== 200) {
      apiErrors.add(1);
    }
    
    sleep(0.5);
  });
}

// ==================== Learning Operations Test ====================

function testLearningOperations() {
  group('Learning Operations', () => {
    // List operations
    const listRes = trpcQuery('learningControl.learning.list', {
      limit: 10,
      offset: 0,
    });
    
    check(listRes, {
      'list operations status is 200': (r) => r.status === 200,
    });
    
    // Start a new operation (if not in read-only mode)
    if (__ENV.ENABLE_MUTATIONS === 'true') {
      const startTime = Date.now();
      
      const startRes = trpcMutation('learningControl.learning.start', {
        type: 'prediction_comparison',
        input: {},
      });
      
      check(startRes, {
        'start operation status is 200': (r) => r.status === 200,
      });
      
      if (startRes.status === 200) {
        // Poll for completion
        let completed = false;
        let attempts = 0;
        const maxAttempts = 30;
        
        while (!completed && attempts < maxAttempts) {
          sleep(1);
          attempts++;
          
          try {
            const body = JSON.parse(startRes.body);
            if (body.result?.data?.id) {
              const statusRes = trpcQuery('learningControl.learning.getById', {
                id: body.result.data.id,
              });
              
              if (statusRes.status === 200) {
                const status = JSON.parse(statusRes.body);
                if (status.result?.data?.status === 'completed' || 
                    status.result?.data?.status === 'failed') {
                  completed = true;
                }
              }
            }
          } catch (e) {
            // Continue polling
          }
        }
        
        operationDuration.add(Date.now() - startTime);
      } else {
        apiErrors.add(1);
      }
    }
    
    sleep(0.5);
  });
}

// ==================== Search Operations Test ====================

function testSearchOperations() {
  group('Search Operations', () => {
    // List search operations
    const listRes = trpcQuery('learningControl.search.list', {
      limit: 10,
      offset: 0,
    });
    
    check(listRes, {
      'list search ops status is 200': (r) => r.status === 200,
    });
    
    // Get keywords for search
    const keywordsRes = trpcQuery('learningControl.keywords.list');
    const sourcesRes = trpcQuery('learningControl.sources.list');
    
    check(keywordsRes, {
      'keywords status is 200': (r) => r.status === 200,
    });
    
    check(sourcesRes, {
      'sources status is 200': (r) => r.status === 200,
    });
    
    sleep(0.5);
  });
}

// ==================== Keywords CRUD Test ====================

function testKeywordsCRUD() {
  group('Keywords CRUD', () => {
    // List keywords
    const listRes = trpcQuery('learningControl.keywords.list');
    
    check(listRes, {
      'list keywords status is 200': (r) => r.status === 200,
    });
    
    // Create keyword (if mutations enabled)
    if (__ENV.ENABLE_MUTATIONS === 'true') {
      const createRes = trpcMutation('learningControl.keywords.create', {
        keyword: `test_keyword_${Date.now()}`,
        category: 'commodity',
        priority: 'medium',
        enabled: true,
      });
      
      check(createRes, {
        'create keyword status is 200': (r) => r.status === 200,
      });
      
      if (createRes.status !== 200) {
        apiErrors.add(1);
      }
    }
    
    sleep(0.5);
  });
}

// ==================== Sources CRUD Test ====================

function testSourcesCRUD() {
  group('Sources CRUD', () => {
    // List sources
    const listRes = trpcQuery('learningControl.sources.list');
    
    check(listRes, {
      'list sources status is 200': (r) => r.status === 200,
    });
    
    // Create source (if mutations enabled)
    if (__ENV.ENABLE_MUTATIONS === 'true') {
      const createRes = trpcMutation('learningControl.sources.create', {
        name: `Test Source ${Date.now()}`,
        url: `https://test-source-${Date.now()}.com`,
        type: 'news_site',
        priority: 'medium',
        enabled: true,
      });
      
      check(createRes, {
        'create source status is 200': (r) => r.status === 200,
      });
      
      if (createRes.status !== 200) {
        apiErrors.add(1);
      }
    }
    
    sleep(0.5);
  });
}

// ==================== WebSocket Test ====================

function testWebSocketConnections() {
  group('WebSocket Connections', () => {
    const url = `${WS_URL}`;
    
    const res = ws.connect(url, {}, function (socket) {
      wsConnections.add(1);
      
      socket.on('open', () => {
        // Subscribe to learning updates
        socket.send(JSON.stringify({
          type: 'subscribe',
          channel: 'learning:operation:update',
        }));
        
        // Subscribe to search updates
        socket.send(JSON.stringify({
          type: 'subscribe',
          channel: 'search:operation:update',
        }));
      });
      
      socket.on('message', (data) => {
        wsMessages.add(1);
      });
      
      socket.on('error', (e) => {
        apiErrors.add(1);
      });
      
      // Keep connection open for 5 seconds
      socket.setTimeout(() => {
        socket.close();
      }, 5000);
    });
    
    check(res, {
      'WebSocket connection successful': (r) => r && r.status === 101,
    });
    
    sleep(0.5);
  });
}

// ==================== Teardown ====================

export function teardown(data) {
  console.log('Load test completed');
  console.log(`Total API errors: ${apiErrors.name}`);
  console.log(`Total WebSocket connections: ${wsConnections.name}`);
}
