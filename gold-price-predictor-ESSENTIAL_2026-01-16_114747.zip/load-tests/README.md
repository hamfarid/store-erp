# 🔥 Load Testing - Gold Price Predictor

دليل اختبارات الحمل لنظام التنبؤ بأسعار الذهب

---

## 📋 المتطلبات

### K6 (Grafana Labs)

```bash
# macOS
brew install k6

# Windows (Chocolatey)
choco install k6

# Linux (Debian/Ubuntu)
sudo gpg -k
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
sudo apt-get update
sudo apt-get install k6
```

### Artillery

```bash
npm install -g artillery
```

---

## 🏃 تشغيل الاختبارات

### K6 Load Test

```bash
# اختبار أساسي
k6 run load-tests/k6-learning-control.js

# مع متغيرات البيئة
k6 run \
  -e BASE_URL=http://localhost:3000 \
  -e WS_URL=ws://localhost:3001 \
  -e AUTH_TOKEN=your-jwt-token \
  -e ENABLE_MUTATIONS=false \
  load-tests/k6-learning-control.js

# مع تقرير HTML
k6 run --out json=results.json load-tests/k6-learning-control.js
```

### Artillery Load Test

```bash
# تشغيل الاختبار
artillery run load-tests/artillery-config.yml

# مع تقرير
artillery run --output report.json load-tests/artillery-config.yml
artillery report report.json
```

---

## 📊 سيناريوهات الاختبار

### سيناريو 1: اختبار الحمل التدريجي (Load Test)

```
المستخدمين │ 1000 ─────────────────────
           │      ╱                    ╲
     500 ──│─────╱                      ╲─────
           │    ╱                        ╲
     100 ──│───╱                          ╲───
           │  ╱                            ╲
       0 ──│─╱──────────────────────────────╲─
           └─────────────────────────────────→
              2m   5m   10m   15m   18m   20m
```

- **الهدف**: اختبار القدرة على التعامل مع 1000 مستخدم متزامن
- **المدة**: 20 دقيقة
- **التدرج**: 0 → 100 → 500 → 1000 → 500 → 0

### سيناريو 2: اختبار الارتفاع المفاجئ (Spike Test)

```
المستخدمين │ 1000 ──────────────
           │      │            │
           │      │            │
     100 ──│──────┴────────────┴──────
           │
       0 ──│──────────────────────────
           └──────────────────────────→
              1m   1m10s  4m10s  4m20s
```

- **الهدف**: اختبار الاستجابة للارتفاع المفاجئ في الطلب
- **المدة**: 5 دقائق
- **التدرج**: 100 → 1000 (فجائي) → 100

### سيناريو 3: اختبار الإجهاد (Stress Test)

```
المستخدمين │ 2000 ────────────────────
           │ 1500 ──────────────
           │  500 ──────
           │
       0 ──│────────────────────────→
              2m   7m   14m   21m   23m
```

- **الهدف**: اختبار حدود النظام
- **المدة**: 23 دقيقة
- **التدرج**: 500 → 1500 → 2000 → 0

---

## 📈 معايير النجاح (Thresholds)

| المقياس | الحد الأدنى | الحد الأقصى |
|---------|-------------|-------------|
| وقت الاستجابة (P95) | - | 2 ثانية |
| وقت الاستجابة (P99) | - | 5 ثواني |
| معدل الخطأ | - | 5% |
| تحميل الصفحة (P95) | - | 3 ثواني |
| مدة العملية (P95) | - | 30 ثانية |

---

## 🎯 النقاط المختبرة

### 1. تحميل لوحة التحكم

```javascript
// اختبار تحميل الصفحة الرئيسية
GET /learning-control
// التحقق من: RTL، حالة 200، وقت التحميل
```

### 2. عمليات التعلم

```javascript
// قائمة العمليات
GET /api/trpc/learningControl.learning.list

// بدء عملية جديدة
POST /api/trpc/learningControl.learning.start
// الحمولة: { type: 'prediction_comparison', input: {} }
```

### 3. عمليات البحث

```javascript
// قائمة العمليات
GET /api/trpc/learningControl.search.list

// قائمة الكلمات المفتاحية
GET /api/trpc/learningControl.keywords.list

// قائمة المصادر
GET /api/trpc/learningControl.sources.list
```

### 4. WebSocket

```javascript
// الاتصال
ws://localhost:3001

// الاشتراك
{ type: 'subscribe', channel: 'learning:operation:update' }
{ type: 'subscribe', channel: 'search:operation:update' }
```

---

## 📊 تفسير النتائج

### مخرجات K6

```
          /\      |‾‾| /‾‾/   /‾‾/   
     /\  /  \     |  |/  /   /  /    
    /  \/    \    |     (   /   ‾‾\  
   /          \   |  |\  \ |  (‾)  | 
  / __________ \  |__| \__\ \_____/ .io

  execution: local
     script: k6-learning-control.js

  scenarios: (100.00%) 3 scenarios, 2000 max VUs, 53m30s max duration
           ✓ load_test: OK (20m0s graceful stop)
           ✓ spike_test: OK (started @ 22m0s)
           ✓ stress_test: OK (started @ 30m0s)

     ✓ page status is 200
     ✓ stats status is 200
     ✗ list operations status is 200
      ↳  98% — ✓ 9800 / ✗ 200

     checks.........................: 99.33% ✓ 29800 / ✗ 200
     http_req_duration..............: avg=234ms p(95)=1.2s p(99)=2.1s
     http_req_failed................: 0.67% ✓ 200 / ✗ 29800
     api_errors.....................: 45
     page_load_time.................: avg=1.5s p(95)=2.8s
     operation_duration.............: avg=8.2s p(95)=22s
     ws_connections.................: 1500
     ws_messages....................: 45000
```

### القراءة:

- ✅ **99.33% نجاح** - ممتاز
- ⚠️ **P95 = 1.2s** - ضمن الحد المقبول (< 2s)
- ⚠️ **P99 = 2.1s** - ضمن الحد المقبول (< 5s)
- ✅ **معدل الخطأ 0.67%** - ممتاز (< 5%)

---

## 🔧 استكشاف الأخطاء

### مشكلة: وقت استجابة بطيء

```bash
# تحقق من حالة الخادم
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:3000/learning-control

# curl-format.txt:
#     time_namelookup:  %{time_namelookup}\n
#        time_connect:  %{time_connect}\n
#     time_appconnect:  %{time_appconnect}\n
#    time_pretransfer:  %{time_pretransfer}\n
#       time_redirect:  %{time_redirect}\n
#  time_starttransfer:  %{time_starttransfer}\n
#                     ----------\n
#          time_total:  %{time_total}\n
```

### مشكلة: فشل WebSocket

```bash
# اختبار اتصال WebSocket
wscat -c ws://localhost:3001
```

### مشكلة: أخطاء المصادقة

```bash
# تأكد من توفر TOKEN صالح
export AUTH_TOKEN=$(curl -s http://localhost:3000/api/auth/token)
```

---

## 📁 ملفات المشروع

```
load-tests/
├── k6-learning-control.js    # سكريبت K6 الرئيسي
├── artillery-config.yml      # إعداد Artillery
└── README.md                 # هذا الملف
```

---

## 🎯 التوصيات

1. **قبل النشر للإنتاج**: شغّل اختبار الحمل الكامل
2. **المراقبة**: راقب استهلاك الذاكرة و CPU أثناء الاختبار
3. **قاعدة البيانات**: تأكد من أن connection pool كافٍ
4. **التخزين المؤقت**: فعّل التخزين المؤقت للبيانات الثابتة
5. **CDN**: استخدم CDN للملفات الثابتة في الإنتاج

---

**آخر تحديث**: 2026-01-15
