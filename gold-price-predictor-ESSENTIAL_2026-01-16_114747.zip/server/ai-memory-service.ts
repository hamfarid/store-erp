/**
 * AI Memory Service
 * Provides persistent memory and RAG capabilities for AI assistants
 * Stores user preferences, context, and conversation summaries
 */

import { query } from "./db-compat";

export interface AIMemory {
  id: number;
  userId: string;
  assistantId: number;
  memoryType: "fact" | "preference" | "context" | "summary";
  key: string;
  value: string;
  importance: number; // 0-10 scale for relevance
  createdAt: number;
  lastAccessedAt: number;
  accessCount: number;
}

export interface AIMemoryInput {
  userId: string;
  assistantId: number;
  memoryType: AIMemory["memoryType"];
  key: string;
  value: string;
  importance?: number;
}

class AIMemoryService {
  /**
   * Initialize the memory table if it doesn't exist
   */
  async initializeTable(): Promise<void> {
    try {
      await query(`
        CREATE TABLE IF NOT EXISTS ai_memory (
          id SERIAL PRIMARY KEY,
          "userId" VARCHAR(64) NOT NULL,
          "assistantId" INTEGER NOT NULL,
          "memoryType" VARCHAR(20) NOT NULL,
          key VARCHAR(255) NOT NULL,
          value TEXT NOT NULL,
          importance INTEGER DEFAULT 5,
          "createdAt" BIGINT NOT NULL,
          "lastAccessedAt" BIGINT NOT NULL,
          "accessCount" INTEGER DEFAULT 1,
          UNIQUE("userId", "assistantId", key)
        )
      `);

      // Create index for faster lookups
      await query(
        'CREATE INDEX IF NOT EXISTS idx_ai_memory_user ON ai_memory ("userId", "assistantId")'
      );

      console.log("[AI Memory] Table initialized");
    } catch (error) {
      console.error("[AI Memory] Failed to initialize table:", error);
    }
  }

  /**
   * Store a memory for a user
   */
  async storeMemory(input: AIMemoryInput): Promise<AIMemory | null> {
    const now = Date.now();

    try {
      // Use upsert to update if exists
      const result = await query(`
        INSERT INTO ai_memory ("userId", "assistantId", "memoryType", key, value, importance, "createdAt", "lastAccessedAt", "accessCount")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 1)
        ON CONFLICT("userId", "assistantId", key) DO UPDATE SET
          value = EXCLUDED.value,
          importance = EXCLUDED.importance,
          "lastAccessedAt" = EXCLUDED."lastAccessedAt",
          "accessCount" = ai_memory."accessCount" + 1
        RETURNING *
      `, [
        input.userId,
        input.assistantId,
        input.memoryType,
        input.key,
        input.value,
        input.importance || 5,
        now,
        now
      ]);

      return result.rows[0] as AIMemory || null;
    } catch (error) {
      console.error("[AI Memory] Failed to store memory:", error);
      return null;
    }
  }

  /**
   * Get a specific memory
   */
  async getMemory(userId: string, assistantId: number, key: string): Promise<AIMemory | null> {
    try {
      const result = await query(
        'SELECT * FROM ai_memory WHERE "userId" = $1 AND "assistantId" = $2 AND key = $3',
        [userId, assistantId, key]
      );

      if (result.rows.length > 0) {
        const memory = result.rows[0] as AIMemory;
        // Update access count and last accessed
        await query(
          'UPDATE ai_memory SET "lastAccessedAt" = $1, "accessCount" = "accessCount" + 1 WHERE id = $2',
          [Date.now(), memory.id]
        );
        return memory;
      }

      return null;
    } catch (error) {
      console.error("[AI Memory] Failed to get memory:", error);
      return null;
    }
  }

  /**
   * Get all memories for a user and assistant
   */
  async getMemories(
    userId: string,
    assistantId: number,
    options?: {
      memoryType?: AIMemory["memoryType"];
      limit?: number;
      minImportance?: number;
    }
  ): Promise<AIMemory[]> {
    try {
      let sql = 'SELECT * FROM ai_memory WHERE "userId" = $1 AND "assistantId" = $2';
      const params: any[] = [userId, assistantId];
      let paramIndex = 3;

      if (options?.memoryType) {
        sql += ` AND "memoryType" = $${paramIndex++}`;
        params.push(options.memoryType);
      }

      if (options?.minImportance) {
        sql += ` AND importance >= $${paramIndex++}`;
        params.push(options.minImportance);
      }

      sql += ' ORDER BY importance DESC, "lastAccessedAt" DESC';

      if (options?.limit) {
        sql += ` LIMIT $${paramIndex++}`;
        params.push(options.limit);
      }

      const result = await query(sql, params);
      return result.rows as AIMemory[];
    } catch (error) {
      console.error("[AI Memory] Failed to get memories:", error);
      return [];
    }
  }

  /**
   * Search memories by keyword
   */
  async searchMemories(
    userId: string,
    assistantId: number,
    keyword: string,
    limit: number = 10
  ): Promise<AIMemory[]> {
    try {
      const searchPattern = `%${keyword}%`;
      const result = await query(`
        SELECT * FROM ai_memory 
        WHERE "userId" = $1 AND "assistantId" = $2 
        AND (key LIKE $3 OR value LIKE $4)
        ORDER BY importance DESC, "lastAccessedAt" DESC
        LIMIT $5
      `, [userId, assistantId, searchPattern, searchPattern, limit]);
      
      return result.rows as AIMemory[];
    } catch (error) {
      console.error("[AI Memory] Failed to search memories:", error);
      return [];
    }
  }

  /**
   * Delete a specific memory
   */
  async deleteMemory(userId: string, assistantId: number, key: string): Promise<boolean> {
    try {
      await query(
        'DELETE FROM ai_memory WHERE "userId" = $1 AND "assistantId" = $2 AND key = $3',
        [userId, assistantId, key]
      );
      return true;
    } catch (error) {
      console.error("[AI Memory] Failed to delete memory:", error);
      return false;
    }
  }

  /**
   * Clear all memories for a user and assistant
   */
  async clearMemories(userId: string, assistantId: number): Promise<boolean> {
    try {
      await query(
        'DELETE FROM ai_memory WHERE "userId" = $1 AND "assistantId" = $2',
        [userId, assistantId]
      );
      return true;
    } catch (error) {
      console.error("[AI Memory] Failed to clear memories:", error);
      return false;
    }
  }

  /**
   * Build context string from relevant memories for a message
   */
  async buildMemoryContext(
    userId: string,
    assistantId: number,
    message: string
  ): Promise<string> {
    // Get high-importance memories
    const importantMemories = await this.getMemories(userId, assistantId, {
      minImportance: 7,
      limit: 5,
    });

    // Search for relevant memories based on message keywords
    const keywords = this.extractKeywords(message);
    const relevantMemories: AIMemory[] = [];

    for (const keyword of keywords) {
      const found = await this.searchMemories(userId, assistantId, keyword, 3);
      relevantMemories.push(...found);
    }

    // Combine and deduplicate
    const allMemories = [...importantMemories, ...relevantMemories];
    const uniqueMemories = Array.from(
      new Map(allMemories.map(m => [m.key, m])).values()
    ).slice(0, 10);

    if (uniqueMemories.length === 0) {
      return "";
    }

    // Build context string
    let contextStr = "\n\n**معلومات مخزنة عن المستخدم:**\n";

    const facts = uniqueMemories.filter(m => m.memoryType === "fact");
    const preferences = uniqueMemories.filter(m => m.memoryType === "preference");
    const summaries = uniqueMemories.filter(m => m.memoryType === "summary");

    if (facts.length > 0) {
      contextStr += "\n*حقائق:*\n";
      facts.forEach(m => {
        contextStr += `- ${m.key}: ${m.value}\n`;
      });
    }

    if (preferences.length > 0) {
      contextStr += "\n*تفضيلات:*\n";
      preferences.forEach(m => {
        contextStr += `- ${m.key}: ${m.value}\n`;
      });
    }

    if (summaries.length > 0) {
      contextStr += "\n*ملخصات سابقة:*\n";
      summaries.forEach(m => {
        contextStr += `- ${m.value}\n`;
      });
    }

    return contextStr;
  }

  /**
   * Extract keywords from a message for memory search
   */
  private extractKeywords(message: string): string[] {
    // Common Arabic and English keywords related to finance
    const financeKeywords = [
      "ذهب",
      "فضة",
      "بيتكوين",
      "عملة",
      "سعر",
      "توقع",
      "تحليل",
      "استثمار",
      "محفظة",
      "gold",
      "silver",
      "bitcoin",
      "crypto",
      "price",
      "predict",
      "invest",
      "portfolio",
    ];

    const foundKeywords: string[] = [];

    // Check for finance keywords
    for (const keyword of financeKeywords) {
      if (message.toLowerCase().includes(keyword)) {
        foundKeywords.push(keyword);
      }
    }

    // Extract capitalized words (likely proper nouns/assets)
    const words = message.split(/\s+/);
    for (const word of words) {
      if (word.length > 3 && /^[A-Z]/.test(word)) {
        foundKeywords.push(word.toLowerCase());
      }
    }

    return [...new Set(foundKeywords)].slice(0, 5);
  }

  /**
   * Learn from a conversation (extract and store relevant information)
   */
  async learnFromConversation(
    userId: string,
    assistantId: number,
    userMessage: string,
    aiResponse: string
  ): Promise<void> {
    // Extract potential facts and preferences from conversation
    const patterns = [
      {
        // User mentions they prefer something
        regex: /(?:أفضل|أحب|أريد|prefer|like|want)\s+(.+)/i,
        type: "preference" as const,
        importance: 6,
      },
      {
        // User mentions they have something (portfolio, investment)
        regex: /(?:لدي|عندي|أملك|I have|I own)\s+(.+)/i,
        type: "fact" as const,
        importance: 7,
      },
      {
        // User asks about specific asset
        regex: /(?:سعر|توقع|ماذا عن|what about|price of)\s+(\w+)/i,
        type: "context" as const,
        importance: 5,
      },
    ];

    for (const pattern of patterns) {
      const match = userMessage.match(pattern.regex);
      if (match && match[1]) {
        const key = `${pattern.type}_${Date.now()}`;
        this.storeMemory({
          userId,
          assistantId,
          memoryType: pattern.type,
          key,
          value: match[1].trim(),
          importance: pattern.importance,
        });
      }
    }
  }
}

// Export singleton instance
export const aiMemoryService = new AIMemoryService();

// Initialize table on module load
aiMemoryService.initializeTable().catch((error) => {
  console.error("[AI Memory] Failed to initialize:", error);
});

