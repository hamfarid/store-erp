// /home/ubuntu/asset_predictor_ui/server/db-python.ts
/**
 * Database functions that integrate with Python API
 * This file provides the bridge between tRPC and the Python backend
 */

import { getPythonApiClient, PredictionRequest } from "./python-api-client";
import * as localDb from "./db";

const pythonApi = getPythonApiClient();

// Asset symbols mapping (matches Python backend)
const ASSET_SYMBOLS: Record<number, string> = {
  1: "GC=F",
  2: "SI=F",
  3: "CL=F",
  4: "BZ=F",
  5: "PL=F",
  6: "PA=F",
  7: "HG=F",
  8: "NG=F",
  9: "BTC-USD",
  10: "ETH-USD",
  11: "TRY=X",
  12: "EGP=X",
  13: "EUR=X",
  14: "DX-Y.NYB",
  15: "SAR=X",
  16: "AED=X",
  17: "OMR=X",
};

/**
 * Get all assets from Python API
 */
export async function getAllAssets() {
  try {
    const response = await pythonApi.getAssets();
    return response.assets;
  } catch (error) {
    console.error("[Python API] Failed to get assets:", error);
    // Fallback to local database
    return await localDb.getAllAssets();
  }
}

/**
 * Get asset by ID
 */
export async function getAssetById(id: number) {
  return await localDb.getAssetById(id);
}

/**
 * Get current prices (from local database)
 */
export async function getCurrentPrices() {
  // Note: getCurrentPrices needs to be implemented in db.ts
  // For now, return empty array
  return [];
}

/**
 * Generate prediction using Python API
 */
export async function generatePrediction(params: {
  assetId: number;
  horizon: "short" | "medium" | "long";
  modelType: "simple" | "advanced" | "ensemble";
  confidenceLevel: number;
  userId: string;
}) {
  try {
    // Get asset symbol
    const symbol = ASSET_SYMBOLS[params.assetId];
    if (!symbol) {
      throw new Error(`Unknown asset ID: ${params.assetId}`);
    }

    // Make prediction request to Python API
    const request: PredictionRequest = {
      symbol,
      horizon: params.horizon,
      confidenceLevel: params.confidenceLevel,
    };

    const prediction = await pythonApi.predict(request);

    // Save prediction to local database
    const db = await localDb.getDb();
    if (db) {
      try {
        const { predictions } = await import("../drizzle/schema");
        await (db as any).insert(predictions).values({
          assetId: params.assetId,
          userId: params.userId,
          predictionDate: new Date(),
          targetDate: new Date(
            Date.now() + prediction.horizon_days * 24 * 60 * 60 * 1000
          ),
          predictedPrice: prediction.predicted_price.toString(),
          currentPrice: prediction.current_price.toString(),
          change: prediction.change.toString(),
          changePercent: prediction.change_percent.toString(),
          confidenceLevel: prediction.confidence_level.toString(),
          confidenceIntervalLower:
            prediction.confidence_interval.lower.toString(),
          confidenceIntervalUpper:
            prediction.confidence_interval.upper.toString(),
          modelUsed: prediction.model_used,
          accuracy: prediction.model_accuracy.toString(),
        });
      } catch (dbError) {
        console.error("[Database] Failed to save prediction:", dbError);
        // Continue even if saving fails
      }
    }

    return {
      id: Date.now(), // Temporary ID
      assetId: params.assetId,
      userId: params.userId,
      predictionDate: new Date(),
      targetDate: new Date(
        Date.now() + prediction.horizon_days * 24 * 60 * 60 * 1000
      ),
      predictedPrice: prediction.predicted_price.toString(),
      currentPrice: prediction.current_price.toString(),
      change: prediction.change.toString(),
      changePercent: prediction.change_percent.toString(),
      confidenceLevel: prediction.confidence_level.toString(),
      confidenceIntervalLower: prediction.confidence_interval.lower.toString(),
      confidenceIntervalUpper: prediction.confidence_interval.upper.toString(),
      modelUsed: prediction.model_used,
      accuracy: prediction.model_accuracy.toString(),
    };
  } catch (error) {
    console.error("[Python API] Prediction failed:", error);
    throw new Error(
      error instanceof Error ? error.message : "Prediction failed"
    );
  }
}

/**
 * Get prediction history
 */
export async function getPredictionHistory(params: {
  userId: string;
  assetId?: number;
  limit: number;
}) {
  // Note: getPredictionHistory needs to be implemented in db.ts
  return [];
}

/**
 * Get prediction by ID
 */
export async function getPredictionById(id: number) {
  // Note: getPredictionById needs to be implemented in db.ts
  return null;
}

/**
 * Create alert
 */
export async function createAlert(params: {
  assetId: number;
  userId: string;
  condition: "above" | "below" | "change";
  threshold: number;
  channels: ("email" | "push" | "telegram")[];
}) {
  // Note: createAlert needs to be implemented in db.ts
  return { id: 0, ...params };
}

/**
 * Get user alerts
 */
export async function getUserAlerts(userId: string) {
  // Note: getUserAlerts needs to be implemented in db.ts
  return [];
}

/**
 * Update alert
 */
export async function updateAlert(
  id: number,
  isActive: boolean,
  userId: string
) {
  // Note: updateAlert needs to be implemented in db.ts
  return { id, isActive, userId };
}

/**
 * Delete alert
 */
export async function deleteAlert(id: number, userId: string) {
  // Note: deleteAlert needs to be implemented in db.ts
  return true;
}

/**
 * Get model performance
 */
export async function getModelPerformance(assetId: number) {
  try {
    const models = await pythonApi.getModels();
    // Filter models for this asset if needed
    return models.models;
  } catch (error) {
    console.error("[Python API] Failed to get models:", error);
    return [];
  }
}

/**
 * Get accuracy history
 */
export async function getAccuracyHistory(assetId: number, days: number) {
  // Note: getAccuracyHistory needs to be implemented in db.ts
  return [];
}
