/**
 * Simple SQLite Database Wrapper
 * Direct SQL queries for SQLite database
 */

import Database from "better-sqlite3";
import { join } from "path";

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) {
    try {
      const dbPath = join(process.cwd(), "data", "asset_predictor.db");
      _db = new Database(dbPath);
      _db.pragma("foreign_keys = ON");
      console.log("[Database] Connected to SQLite:", dbPath);
    } catch (error) {
      console.error("[Database] Failed to connect:", error);
      throw new Error("Database connection failed");
    }
  }
  return _db;
}

// Users
export function getUser(id: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id);
}

export function getUserByEmail(email: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM users WHERE email = ?").get(email);
}

export function createUser(user: {
  id: string;
  name: string;
  email: string;
  passwordHash?: string;
  loginMethod: string;
  role?: string;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO users (id, name, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(
    user.id,
    user.name,
    user.email,
    user.passwordHash || null,
    user.loginMethod,
    user.role || "user",
    Date.now(),
    Date.now()
  );

  return getUser(user.id);
}

export function upsertUser(user: any) {
  const db = getDb();
  
  // Check if user exists first
  const existingUser = getUser(user.id);
  
  if (existingUser) {
    // User exists - only update the fields that are provided
    const updates: string[] = [];
    const params: any[] = [];
    
    if (user.name !== undefined) {
      updates.push('name = ?');
      params.push(user.name);
    }
    if (user.email !== undefined) {
      updates.push('email = ?');
      params.push(user.email);
    }
    if (user.passwordHash !== undefined) {
      updates.push('passwordHash = ?');
      params.push(user.passwordHash);
    }
    if (user.loginMethod !== undefined) {
      updates.push('loginMethod = ?');
      params.push(user.loginMethod);
    }
    if (user.role !== undefined) {
      updates.push('role = ?');
      params.push(user.role);
    }
    if (user.lastSignedIn !== undefined) {
      updates.push('lastSignedIn = ?');
      params.push(user.lastSignedIn);
    }
    
    if (updates.length > 0) {
      params.push(user.id);
      const stmt = db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`);
      stmt.run(...params);
    }
  } else {
    // User doesn't exist - create new user
    const stmt = db.prepare(`
      INSERT INTO users (id, name, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      user.id,
      user.name || 'User',  // Default name to avoid NOT NULL constraint
      user.email || null,
      user.passwordHash || null,
      user.loginMethod || null,
      user.role || 'user',
      user.createdAt || Date.now(),
      user.lastSignedIn || Date.now()
    );
  }
}

// Assets
export function getAllAssets() {
  try {
    const db = getDb();
    return db.prepare("SELECT * FROM assets ORDER BY id").all();
  } catch (error) {
    console.error("[Database] Error getting assets:", error);
    return [];
  }
}

export function getAssetById(id: number) {
  const db = getDb();
  return db.prepare("SELECT * FROM assets WHERE id = ?").get(id);
}

export function getAssetBySymbol(symbol: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM assets WHERE symbol = ?").get(symbol);
}

// Historical Prices
export function getHistoricalPricesByAssetId(
  assetId: number,
  limit: number = 100
) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT * FROM historical_prices
    WHERE assetId = ?
    ORDER BY date DESC
    LIMIT ?
  `
    )
    .all(assetId, limit);
}

export function insertHistoricalPrice(price: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO historical_prices (assetId, date, price, high, low, open, volume, change, changePercent, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  return stmt.run(
    price.assetId,
    price.date,
    price.price,
    price.high || null,
    price.low || null,
    price.open || null,
    price.volume || null,
    price.change || "0.00",
    price.changePercent || "0.00",
    price.timestamp
  );
}

// Predictions
export function getAllPredictions(limit: number = 50, offset: number = 0) {
  try {
    const db = getDb();
    return db
      .prepare("SELECT * FROM predictions ORDER BY createdAt DESC LIMIT ? OFFSET ?")
      .all(limit, offset);
  } catch (error) {
    console.error("[Database] Error getting predictions:", error);
    return [];
  }
}

export function getPredictionsByAssetId(assetId: number) {
  const db = getDb();
  return db
    .prepare(
      "SELECT * FROM predictions WHERE assetId = ? ORDER BY createdAt DESC"
    )
    .all(assetId);
}

export function getPredictionsByUserId(userId: string) {
  const db = getDb();
  return db
    .prepare(
      "SELECT * FROM predictions WHERE userId = ? ORDER BY createdAt DESC"
    )
    .all(userId);
}

export function insertPrediction(prediction: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO predictions (assetId, userId, modelType, horizon, predictedPrice, confidenceLevel, predictionDate, accuracy, metadata, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  return stmt.run(
    prediction.assetId,
    prediction.userId,
    prediction.modelType,
    prediction.horizon,
    prediction.predictedPrice,
    prediction.confidenceLevel,
    prediction.predictionDate,
    prediction.accuracy || null,
    prediction.metadata || null,
    prediction.createdAt || Date.now()
  );
}

// Alerts
export function getAllAlerts() {
  try {
    const db = getDb();
    return db.prepare("SELECT * FROM alerts ORDER BY createdAt DESC").all();
  } catch (error) {
    console.error("[Database] Error getting alerts:", error);
    return [];
  }
}

export function getAlertsByUserId(userId: string) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM alerts WHERE userId = ? ORDER BY createdAt DESC")
    .all(userId);
}

export function getAlertsByAssetId(assetId: number) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM alerts WHERE assetId = ? ORDER BY createdAt DESC")
    .all(assetId);
}

export function insertAlert(alert: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO alerts (userId, assetId, alertType, condition, threshold, isActive, isTriggered, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  return stmt.run(
    alert.userId,
    alert.assetId,
    alert.alertType,
    alert.condition,
    alert.threshold,
    alert.isActive !== undefined ? (alert.isActive ? 1 : 0) : 1,
    alert.isTriggered !== undefined ? (alert.isTriggered ? 1 : 0) : 0,
    alert.createdAt || Date.now()
  );
}

export function updateAlert(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.isActive !== undefined) {
    fields.push("isActive = ?");
    values.push(updates.isActive ? 1 : 0);
  }
  if (updates.isTriggered !== undefined) {
    fields.push("isTriggered = ?");
    values.push(updates.isTriggered ? 1 : 0);
  }
  if (updates.threshold !== undefined) {
    fields.push("threshold = ?");
    values.push(updates.threshold);
  }

  if (fields.length === 0) {return;}

  values.push(id);
  const stmt = db.prepare(
    `UPDATE alerts SET ${fields.join(", ")} WHERE id = ?`
  );
  return stmt.run(...values);
}

export function deleteAlert(id: number) {
  const db = getDb();
  return db.prepare("DELETE FROM alerts WHERE id = ?").run(id);
}

// Prediction Accuracy Comparison
export function getPredictionAccuracyComparison(input?: any) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT
      modelType,
      COUNT(*) as totalPredictions,
      AVG(CAST(accuracy AS REAL)) as avgAccuracy,
      AVG(CAST(confidenceLevel AS REAL)) as avgConfidence
    FROM predictions
    WHERE accuracy IS NOT NULL
    GROUP BY modelType
  `
    )
    .all();
}

// Statistics
export function getAssetCount() {
  const db = getDb();
  return db.prepare("SELECT COUNT(*) as count FROM assets").get();
}

export function getPredictionCount() {
  const db = getDb();
  return db.prepare("SELECT COUNT(*) as count FROM predictions").get();
}

export function getAlertCount() {
  const db = getDb();
  return db.prepare("SELECT COUNT(*) as count FROM alerts").get();
}

export function getActiveAlertCount() {
  const db = getDb();
  return db
    .prepare("SELECT COUNT(*) as count FROM alerts WHERE isActive = 1")
    .get();
}

// Additional Asset Functions
export function createAsset(asset: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO assets (symbol, name, assetType, exchange, currency, currentPrice, sector, description, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    asset.symbol,
    asset.name,
    asset.type || asset.assetType,
    asset.exchange || null,
    asset.currency || "USD",
    asset.currentPrice || null,
    asset.sector || null,
    asset.description || null,
    Date.now()
  );

  return { id: result.lastInsertRowid, ...asset };
}

export function updateAsset(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.name) {
    fields.push("name = ?");
    values.push(updates.name);
  }
  if (updates.symbol) {
    fields.push("symbol = ?");
    values.push(updates.symbol);
  }
  if (updates.type || updates.assetType) {
    fields.push("assetType = ?");
    values.push(updates.type || updates.assetType);
  }
  if (updates.currentPrice) {
    fields.push("currentPrice = ?");
    values.push(updates.currentPrice);
  }
  if (updates.description) {
    fields.push("description = ?");
    values.push(updates.description);
  }

  fields.push("updatedAt = ?");
  values.push(Date.now());

  if (fields.length === 1) {return;} // Only updatedAt

  values.push(id);
  const stmt = db.prepare(
    `UPDATE assets SET ${fields.join(", ")} WHERE id = ?`
  );
  return stmt.run(...values);
}

export function deleteAsset(id: number) {
  const db = getDb();
  return db.prepare("DELETE FROM assets WHERE id = ?").run(id);
}

export function getCurrentPrices() {
  const db = getDb();
  return db
    .prepare(
      "SELECT id, symbol, name, currentPrice, updatedAt FROM assets WHERE currentPrice IS NOT NULL"
    )
    .all();
}

// Additional Prediction Functions
export function getPredictionById(id: number) {
  const db = getDb();
  return db.prepare("SELECT * FROM predictions WHERE id = ?").get(id);
}

export function updatePrediction(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.modelType) {
    fields.push("modelType = ?");
    values.push(updates.modelType);
  }
  if (updates.accuracy) {
    fields.push("accuracy = ?");
    values.push(updates.accuracy);
  }
  if (updates.metadata) {
    fields.push("metadata = ?");
    values.push(updates.metadata);
  }

  if (fields.length === 0) {return;}

  values.push(id);
  const stmt = db.prepare(
    `UPDATE predictions SET ${fields.join(", ")} WHERE id = ?`
  );
  return stmt.run(...values);
}

export function deletePrediction(id: number) {
  const db = getDb();
  return db.prepare("DELETE FROM predictions WHERE id = ?").run(id);
}

export function generatePrediction(params: any) {
  // For now, generate a simple prediction
  // In production, this would call Python backend
  const db = getDb();
  const asset = getAssetById(params.assetId);

  if (!asset) {
    throw new Error("Asset not found");
  }

  const currentPrice = parseFloat((asset as any).currentPrice || "0");
  const randomChange = (Math.random() - 0.5) * 0.1; // ±5%
  const predictedPrice = (currentPrice * (1 + randomChange)).toFixed(2);

  const prediction = {
    assetId: params.assetId,
    userId: params.userId,
    modelType: params.modelType,
    horizon: params.horizon,
    predictedPrice: predictedPrice,
    confidenceLevel: params.confidenceLevel.toString(),
    predictionDate: Date.now(),
    accuracy: null,
    metadata: JSON.stringify({ generated: true }),
    createdAt: Date.now(),
  };

  const result = insertPrediction(prediction);
  return { id: result.lastInsertRowid, ...prediction };
}

export function getPredictionHistory(params: any) {
  const db = getDb();

  if (params.assetId) {
    return db
      .prepare(
        `
      SELECT * FROM predictions
      WHERE userId = ? AND assetId = ?
      ORDER BY createdAt DESC
      LIMIT ?
    `
      )
      .all(params.userId, params.assetId, params.limit);
  } else {
    return db
      .prepare(
        `
      SELECT * FROM predictions
      WHERE userId = ?
      ORDER BY createdAt DESC
      LIMIT ?
    `
      )
      .all(params.userId, params.limit);
  }
}

// Additional Alert Functions
export function getAlertById(id: number) {
  const db = getDb();
  return db.prepare("SELECT * FROM alerts WHERE id = ?").get(id);
}

export function createAlert(alert: any) {
  return insertAlert(alert);
}

// Historical Prices
export function getLatestPrices(limit: number = 10) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT hp.*, a.symbol, a.name
    FROM historical_prices hp
    JOIN assets a ON hp.assetId = a.id
    ORDER BY hp.timestamp DESC
    LIMIT ?
  `
    )
    .all(limit);
}

// User Alerts Functions
export function getUserAlerts(userId: string) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT a.*, ast.symbol, ast.name as assetName
    FROM alerts a
    LEFT JOIN assets ast ON a.assetId = ast.id
    WHERE a.userId = ?
    ORDER BY a.createdAt DESC
  `
    )
    .all(userId);
}

// Admin User Management Functions
export function getAllUsers() {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT id, name, email, role, loginMethod, createdAt, lastSignedIn
    FROM users
    ORDER BY createdAt DESC
  `
    )
    .all();
}

export function getUserByIdAdmin(userId: string) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT id, name, email, role, loginMethod, createdAt, lastSignedIn
    FROM users
    WHERE id = ?
  `
    )
    .get(userId);
}

export function updateUserRole(userId: string, role: string) {
  const db = getDb();
  const stmt = db.prepare(`
    UPDATE users
    SET role = ?, updatedAt = ?
    WHERE id = ?
  `);
  return stmt.run(role, Date.now(), userId);
}

export function deleteUser(userId: string) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM users WHERE id = ?");
  return stmt.run(userId);
}

// User Permissions Functions
export function getUserPermissions(userId: string) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT * FROM user_permissions
    WHERE userId = ?
  `
    )
    .all(userId);
}

export function createPermission(permission: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO user_permissions (userId, permission, createdAt)
    VALUES (?, ?, ?)
  `);
  return stmt.run(permission.userId, permission.permission, Date.now());
}

export function updatePermission(id: number, permission: any) {
  const db = getDb();
  const stmt = db.prepare(`
    UPDATE user_permissions
    SET permission = ?, updatedAt = ?
    WHERE id = ?
  `);
  return stmt.run(permission.permission, Date.now(), id);
}

export function deletePermission(id: number) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM user_permissions WHERE id = ?");
  return stmt.run(id);
}

export function revokePermission(userId: string, permission: string) {
  const db = getDb();
  const stmt = db.prepare(
    "DELETE FROM user_permissions WHERE userId = ? AND permission = ?"
  );
  return stmt.run(userId, permission);
}

export function hasPermission(userId: string, permission: string) {
  const db = getDb();
  const result = db
    .prepare(
      "SELECT * FROM user_permissions WHERE userId = ? AND permission = ?"
    )
    .get(userId, permission);
  return !!result;
}

// Additional helper functions already exist above

// User Settings Functions
export function getUserSettings(userId: string) {
  const db = getDb();
  const result = db
    .prepare(
      `
    SELECT * FROM user_settings
    WHERE userId = ?
  `
    )
    .get(userId);

  // Return default settings if none exist
  if (!result) {
    return {
      userId,
      emailEnabled: false,
      notifyPriceChanges: true,
      notifyAlerts: true,
      notifyPredictions: true,
      notifyReports: false,
      language: "ar",
      theme: "light",
      currency: "USD",
    };
  }

  return result;
}

export function updateUserSettings(userId: string, settings: any) {
  const db = getDb();

  // Check if settings exist
  const existing = db
    .prepare("SELECT userId FROM user_settings WHERE userId = ?")
    .get(userId);

  if (existing) {
    // Update existing settings
    const fields = Object.keys(settings)
      .map(key => `${key} = ?`)
      .join(", ");
    const values = [...Object.values(settings), userId];

    const stmt = db.prepare(`
      UPDATE user_settings
      SET ${fields}, updatedAt = ?
      WHERE userId = ?
    `);
    return stmt.run(...values, Date.now(), userId);
  } else {
    // Insert new settings
    const stmt = db.prepare(`
      INSERT INTO user_settings (userId, ${Object.keys(settings).join(", ")}, createdAt, updatedAt)
      VALUES (?, ${Object.keys(settings)
        .map(() => "?")
        .join(", ")}, ?, ?)
    `);
    return stmt.run(userId, ...Object.values(settings), Date.now(), Date.now());
  }
}

export function resetUserSettings(userId: string) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM user_settings WHERE userId = ?");
  return stmt.run(userId);
}

// Reports Generation Functions
export function generatePortfolioReport(userId: string, params: any) {
  const db = getDb();
  const { portfolioId, startDate, endDate } = params;

  // Check if portfolios table exists
  try {
    const tableInfo = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolios'").get();
    if (!tableInfo) {
      console.warn("[Reports] Portfolios table does not exist");
      return {
        summary: {
          totalPortfolios: 0,
          totalAssets: 0,
          totalInvested: 0,
          totalReturns: 0,
        },
        portfolios: [],
        message: "لا توجد محافظ متاحة",
      };
    }
  } catch (error) {
    console.error("[Reports] Error checking portfolios table:", error);
    return {
      summary: {
        totalPortfolios: 0,
        totalAssets: 0,
        totalInvested: 0,
        totalReturns: 0,
      },
      portfolios: [],
      message: "خطأ في قاعدة البيانات",
    };
  }

  let query = `
    SELECT
      p.id as portfolioId,
      p.name as portfolioName,
      COUNT(DISTINCT t.assetId) as totalAssets,
      COALESCE(SUM(CASE WHEN t.transactionType = 'buy' THEN t.totalAmount ELSE 0 END), 0) as totalInvested,
      COALESCE(SUM(CASE WHEN t.transactionType = 'sell' THEN t.totalAmount ELSE 0 END), 0) as totalReturns
    FROM portfolios p
    LEFT JOIN transactions t ON p.id = t.portfolioId
    WHERE p.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (portfolioId) {
    query += " AND p.id = ?";
    queryParams.push(portfolioId);
  }

  if (startDate) {
    query += " AND t.transactionDate >= ?";
    queryParams.push(startDate);
  }

  if (endDate) {
    query += " AND t.transactionDate <= ?";
    queryParams.push(endDate);
  }

  query += " GROUP BY p.id";

  const portfolios = db.prepare(query).all(...queryParams) as any[];
  
  const summary = {
    totalPortfolios: portfolios.length,
    totalAssets: portfolios.reduce((sum, p) => sum + (p.totalAssets || 0), 0),
    totalInvested: portfolios.reduce((sum, p) => sum + (p.totalInvested || 0), 0),
    totalReturns: portfolios.reduce((sum, p) => sum + (p.totalReturns || 0), 0),
  };

  return {
    summary,
    portfolios,
    generatedAt: new Date().toISOString(),
  };
}

export function generateAccuracyReport(userId: string, params: any) {
  const db = getDb();
  const { assetId, modelType, startDate, endDate } = params;

  let query = `
    SELECT
      p.modelType,
      p.assetId,
      a.symbol,
      a.name as assetName,
      COUNT(*) as totalPredictions,
      COALESCE(AVG(CAST(p.accuracy AS REAL)), 0) as avgAccuracy,
      COALESCE(AVG(CAST(p.confidenceLevel AS REAL)), 0) as avgConfidence,
      COALESCE(MIN(CAST(p.accuracy AS REAL)), 0) as minAccuracy,
      COALESCE(MAX(CAST(p.accuracy AS REAL)), 0) as maxAccuracy
    FROM predictions p
    LEFT JOIN assets a ON p.assetId = a.id
    WHERE p.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (assetId) {
    query += " AND p.assetId = ?";
    queryParams.push(assetId);
  }

  if (modelType) {
    query += " AND p.modelType = ?";
    queryParams.push(modelType);
  }

  if (startDate) {
    query += " AND p.createdAt >= ?";
    queryParams.push(new Date(startDate).getTime());
  }

  if (endDate) {
    query += " AND p.createdAt <= ?";
    queryParams.push(new Date(endDate).getTime());
  }

  query += " GROUP BY p.modelType, p.assetId";

  const results = db.prepare(query).all(...queryParams) as any[];
  
  return {
    summary: {
      totalPredictions: results.reduce((sum, r) => sum + (r.totalPredictions || 0), 0),
      avgAccuracy: results.length > 0 ? results.reduce((sum, r) => sum + (r.avgAccuracy || 0), 0) / results.length : 0,
      avgConfidence: results.length > 0 ? results.reduce((sum, r) => sum + (r.avgConfidence || 0), 0) / results.length : 0,
    },
    details: results,
    generatedAt: new Date().toISOString(),
  };
}

export function generateAlertsReport(userId: string, params: any) {
  const db = getDb();
  const { startDate, endDate, status } = params;

  let query = `
    SELECT
      a.*,
      ast.symbol,
      ast.name as assetName
    FROM alerts a
    LEFT JOIN assets ast ON a.assetId = ast.id
    WHERE a.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (status && status !== "all") {
    if (status === "triggered") {
      query += " AND a.isTriggered = 1";
    } else if (status === "active") {
      query += " AND a.isActive = 1 AND a.isTriggered = 0";
    } else if (status === "inactive") {
      query += " AND a.isActive = 0";
    }
  }

  if (startDate) {
    query += " AND a.createdAt >= ?";
    queryParams.push(new Date(startDate).getTime());
  }

  if (endDate) {
    query += " AND a.createdAt <= ?";
    queryParams.push(new Date(endDate).getTime());
  }

  query += " ORDER BY a.createdAt DESC";

  const alerts = db.prepare(query).all(...queryParams) as any[];
  
  const summary = {
    total: alerts.length,
    triggered: alerts.filter(a => a.isTriggered).length,
    active: alerts.filter(a => a.isActive && !a.isTriggered).length,
    inactive: alerts.filter(a => !a.isActive).length,
  };

  return {
    summary,
    alerts,
    generatedAt: new Date().toISOString(),
  };
}

export function generatePriceHistoryReport(params: any) {
  const db = getDb();
  const { assetId, startDate, endDate, interval = "daily" } = params;

  let query = `
    SELECT
      hp.*,
      a.symbol,
      a.name as assetName
    FROM historical_prices hp
    JOIN assets a ON hp.assetId = a.id
    WHERE hp.assetId = ?
  `;

  const queryParams: any[] = [assetId];

  if (startDate) {
    query += " AND hp.timestamp >= ?";
    queryParams.push(new Date(startDate).getTime());
  }

  if (endDate) {
    query += " AND hp.timestamp <= ?";
    queryParams.push(new Date(endDate).getTime());
  }

  query += " ORDER BY hp.timestamp ASC";

  return db.prepare(query).all(...queryParams);
}

export function convertToCSV(data: any[]) {
  if (!data || data.length === 0) {return "";}

  const headers = Object.keys(data[0]);
  const rows = data.map(row =>
    headers
      .map(header => {
        const value = row[header];
        // Escape quotes and wrap in quotes if contains comma
        if (
          typeof value === "string" &&
          (value.includes(",") || value.includes('"'))
        ) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      })
      .join(",")
  );

  return [headers.join(","), ...rows].join("\n");
}

export function getReportHistory(
  userId: string,
  limit: number,
  offset: number
) {
  const db = getDb();
  return db
    .prepare(
      `
    SELECT * FROM saved_reports
    WHERE userId = ?
    ORDER BY createdAt DESC
    LIMIT ? OFFSET ?
  `
    )
    .all(userId, limit, offset);
}

export function saveReport(userId: string, report: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO saved_reports (userId, reportType, title, description, data, createdAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  return stmt.run(
    userId,
    report.reportType,
    report.title,
    report.description || null,
    JSON.stringify(report.data),
    Date.now()
  );
}

export function deleteReport(reportId: number, userId: string) {
  const db = getDb();
  const stmt = db.prepare(
    "DELETE FROM saved_reports WHERE id = ? AND userId = ?"
  );
  return stmt.run(reportId, userId);
}

// Admin Functions
export function getSystemStats() {
  const db = getDb();

  const userCount = db
    .prepare("SELECT COUNT(*) as count FROM users")
    .get() as any;
  const assetCount = db
    .prepare("SELECT COUNT(*) as count FROM assets")
    .get() as any;
  const predictionCount = db
    .prepare("SELECT COUNT(*) as count FROM predictions")
    .get() as any;
  const alertCount = db
    .prepare("SELECT COUNT(*) as count FROM alerts")
    .get() as any;
  const portfolioCount = db
    .prepare("SELECT COUNT(*) as count FROM portfolios")
    .get() as any;

  return {
    users: userCount.count,
    assets: assetCount.count,
    predictions: predictionCount.count,
    alerts: alertCount.count,
    portfolios: portfolioCount.count,
    timestamp: Date.now(),
  };
}

export function getAllUsersAdmin(params: any) {
  const db = getDb();
  const { limit, offset, search, role } = params;

  let query = "SELECT * FROM users WHERE 1=1";
  const queryParams: any[] = [];

  if (search) {
    query += " AND (name LIKE ? OR email LIKE ?)";
    queryParams.push(`%${search}%`, `%${search}%`);
  }

  if (role && role !== "all") {
    query += " AND role = ?";
    queryParams.push(role);
  }

  query += " ORDER BY createdAt DESC LIMIT ? OFFSET ?";
  queryParams.push(limit, offset);

  return db.prepare(query).all(...queryParams);
}

export function updateUserAdmin(userId: string, updates: any) {
  const db = getDb();
  const fields = Object.keys(updates)
    .map(key => `${key} = ?`)
    .join(", ");
  const values = [...Object.values(updates), userId];

  const stmt = db.prepare(`
    UPDATE users
    SET ${fields}
    WHERE id = ?
  `);

  return stmt.run(...values);
}

export function getUserStats() {
  const db = getDb();

  return {
    total: (db.prepare("SELECT COUNT(*) as count FROM users").get() as any)
      .count,
    admins: (
      db
        .prepare('SELECT COUNT(*) as count FROM users WHERE role = "admin"')
        .get() as any
    ).count,
    active: (
      db
        .prepare("SELECT COUNT(*) as count FROM users WHERE lastSignedIn > ?")
        .get(Date.now() - 30 * 24 * 60 * 60 * 1000) as any
    ).count,
  };
}

export function getAllAssetsAdmin() {
  const db = getDb();
  return db.prepare("SELECT * FROM assets ORDER BY createdAt DESC").all();
}

export function createAssetAdmin(asset: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO assets (symbol, name, type, description, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  return stmt.run(
    asset.symbol,
    asset.name,
    asset.type,
    asset.description || null,
    Date.now(),
    Date.now()
  );
}

export function updateAssetAdmin(id: number, updates: any) {
  const db = getDb();
  const fields = Object.keys(updates)
    .map(key => `${key} = ?`)
    .join(", ");
  const values = [...Object.values(updates), Date.now(), id];

  const stmt = db.prepare(`
    UPDATE assets
    SET ${fields}, updatedAt = ?
    WHERE id = ?
  `);

  return stmt.run(...values);
}

export function deleteAssetAdmin(id: number) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM assets WHERE id = ?");
  return stmt.run(id);
}

export function getSystemLogs(params: any) {
  const db = getDb();
  const { limit, offset, level, startDate, endDate } = params;

  let query = "SELECT * FROM system_logs WHERE 1=1";
  const queryParams: any[] = [];

  if (level && level !== "all") {
    query += " AND level = ?";
    queryParams.push(level);
  }

  if (startDate) {
    query += " AND timestamp >= ?";
    queryParams.push(new Date(startDate).getTime());
  }

  if (endDate) {
    query += " AND timestamp <= ?";
    queryParams.push(new Date(endDate).getTime());
  }

  query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?";
  queryParams.push(limit, offset);

  return db.prepare(query).all(...queryParams);
}

export function clearSystemLogs(olderThan?: string) {
  const db = getDb();

  if (olderThan) {
    const stmt = db.prepare("DELETE FROM system_logs WHERE timestamp < ?");
    return stmt.run(new Date(olderThan).getTime());
  } else {
    const stmt = db.prepare("DELETE FROM system_logs");
    return stmt.run();
  }
}

export function getDatabaseStats() {
  const db = getDb();

  // Get table sizes
  const tables = [
    "users",
    "assets",
    "predictions",
    "alerts",
    "portfolios",
    "transactions",
    "historical_prices",
  ];
  const stats: any = {};

  tables.forEach(table => {
    const result = db
      .prepare(`SELECT COUNT(*) as count FROM ${table}`)
      .get() as any;
    stats[table] = result.count;
  });

  return stats;
}

export function createDatabaseBackup() {
  // This would typically use SQLite backup API or file copy
  // For now, return a placeholder
  return {
    success: true,
    backupPath: `/backups/db_${Date.now()}.sqlite`,
    timestamp: Date.now(),
  };
}

export function optimizeDatabase() {
  const db = getDb();
  db.prepare("VACUUM").run();
  db.prepare("ANALYZE").run();

  return {
    success: true,
    timestamp: Date.now(),
  };
}

export function getSystemConfig() {
  const db = getDb();
  return db.prepare("SELECT * FROM system_config").all();
}

export function updateSystemConfig(key: string, value: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO system_config (key, value, updatedAt)
    VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET value = ?, updatedAt = ?
  `);

  const valueStr = JSON.stringify(value);
  return stmt.run(key, valueStr, Date.now(), valueStr, Date.now());
}

/**
 * Get asset price history for technical indicators
 */
export function getAssetPriceHistory(
  assetId: number,
  startDate?: Date,
  endDate?: Date,
  limit: number = 1000
) {
  const db = getDb();

  const query = `
    SELECT * FROM historical_prices
    WHERE assetId = ?
    ORDER BY date ASC
    LIMIT ?
  `;

  return db.prepare(query).all(assetId, limit);
}

// Additional functions for routers.ts
export function getHistoricalPrices(assetId: number, limit: number = 100) {
  return getHistoricalPricesByAssetId(assetId, limit);
}

export function getHistoricalPricesByAsset(
  assetId: number,
  limit: number = 100
) {
  return getHistoricalPricesByAssetId(assetId, limit);
}

export function getLatestPrice(assetId: number) {
  const db = getDb();
  return db
    .prepare(
      "SELECT * FROM historical_prices WHERE assetId = ? ORDER BY timestamp DESC LIMIT 1"
    )
    .get(assetId);
}

export function calculateTradingSignals(assetId: number) {
  // Placeholder - implement technical analysis
  return [];
}

export function createTradingSignal(signal: any) {
  // Placeholder - implement signal creation
  return { id: Date.now(), ...signal };
}

export function getTradingSignals(assetId: number) {
  // Placeholder - implement signal retrieval
  return [];
}

export function calculateBreakoutPoints(assetId: number) {
  // Placeholder - implement breakout calculation
  return [];
}

export function createBreakoutPoint(point: any) {
  // Placeholder - implement breakout point creation
  return { id: Date.now(), ...point };
}

export function getBreakoutPoints(assetId: number) {
  // Placeholder - implement breakout point retrieval
  return [];
}

export function createBreakEvenPoint(point: any) {
  // Placeholder - implement break-even point creation
  return { id: Date.now(), ...point };
}

export function getBreakEvenPoints(assetId: number) {
  // Placeholder - implement break-even point retrieval
  return [];
}

export function deleteBreakEvenPoint(id: number) {
  // Placeholder - implement break-even point deletion
  return true;
}

export function calculateInflectionPoints(assetId: number) {
  // Placeholder - implement inflection point calculation
  return [];
}

export function createInflectionPoint(point: any) {
  // Placeholder - implement inflection point creation
  return { id: Date.now(), ...point };
}

export function getInflectionPoints(assetId: number) {
  // Placeholder - implement inflection point retrieval
  return [];
}

export function getModelPerformance(assetId: number) {
  // Placeholder - implement model performance retrieval
  return { accuracy: 0, precision: 0, recall: 0 };
}

export function getAccuracyHistory(assetId: number, days: number) {
  // Placeholder - implement accuracy history retrieval
  return [];
}

// ==================== NOTIFICATION FUNCTIONS ====================

export function getUserNotifications(userId: string, limit: number = 50, offset: number = 0) {
  const db = getDb();
  return db
    .prepare(`
      SELECT * FROM notifications
      WHERE userId = ?
      ORDER BY createdAt DESC
      LIMIT ? OFFSET ?
    `)
    .all(userId, limit, offset);
}

export function getUnreadNotificationsCount(userId: string) {
  const db = getDb();
  const result = db
    .prepare("SELECT COUNT(*) as count FROM notifications WHERE userId = ? AND isRead = 0")
    .get(userId) as { count: number };
  return result?.count || 0;
}

export function markNotificationAsRead(id: number, userId: string) {
  const db = getDb();
  return db
    .prepare("UPDATE notifications SET isRead = 1 WHERE id = ? AND userId = ?")
    .run(id, userId);
}

export function markAllNotificationsAsRead(userId: string) {
  const db = getDb();
  return db
    .prepare("UPDATE notifications SET isRead = 1 WHERE userId = ?")
    .run(userId);
}

export function deleteNotification(id: number, userId: string) {
  const db = getDb();
  return db
    .prepare("DELETE FROM notifications WHERE id = ? AND userId = ?")
    .run(id, userId);
}

export function deleteAllReadNotifications(userId: string) {
  const db = getDb();
  return db
    .prepare("DELETE FROM notifications WHERE userId = ? AND isRead = 1")
    .run(userId);
}

export function createNotification(data: {
  userId: string;
  title: string;
  message: string;
  type?: string;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO notifications (userId, title, message, type, isRead, createdAt)
    VALUES (?, ?, ?, ?, 0, ?)
  `);
  
  const result = stmt.run(
    data.userId,
    data.title,
    data.message,
    data.type || 'info',
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...data };
}

// ==================== EXPERT OPINIONS FUNCTIONS ====================

export function getExpertOpinions(assetId?: number, limit: number = 50) {
  const db = getDb();
  if (assetId) {
    return db
      .prepare(`
        SELECT * FROM expert_opinions
        WHERE assetId = ?
        ORDER BY createdAt DESC
        LIMIT ?
      `)
      .all(assetId, limit);
  }
  return db
    .prepare("SELECT * FROM expert_opinions ORDER BY createdAt DESC LIMIT ?")
    .all(limit);
}

export function createExpertOpinion(opinion: {
  assetId?: number;
  expertName: string;
  opinion: string;
  sentiment?: string;
  confidenceLevel?: number;
  sourceUrl?: string;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO expert_opinions (assetId, expertName, opinion, sentiment, confidenceLevel, sourceUrl, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    opinion.assetId || null,
    opinion.expertName,
    opinion.opinion,
    opinion.sentiment || 'neutral',
    opinion.confidenceLevel || 0.5,
    opinion.sourceUrl || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...opinion };
}

export function deleteExpertOpinion(id: number) {
  const db = getDb();
  return db.prepare("DELETE FROM expert_opinions WHERE id = ?").run(id);
}

// ==================== DRIFT DETECTION FUNCTIONS ====================

export function getDriftDetections(limit: number = 50) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM drift_detections ORDER BY detectedAt DESC LIMIT ?")
    .all(limit);
}

export function createDriftDetection(drift: {
  modelType: string;
  driftType: string;
  severity?: string;
  details?: string;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO drift_detections (modelType, driftType, severity, details, detectedAt)
    VALUES (?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    drift.modelType,
    drift.driftType,
    drift.severity || 'low',
    drift.details || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...drift };
}

export function resolveDriftDetection(id: number) {
  const db = getDb();
  return db
    .prepare("UPDATE drift_detections SET isResolved = 1, resolvedAt = ? WHERE id = ?")
    .run(Date.now(), id);
}

// ==================== LEARNING PATH FUNCTIONS ====================

export function getUserLearningPaths(userId: string) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM learning_paths WHERE userId = ? ORDER BY createdAt DESC")
    .all(userId);
}

export function createLearningPath(path: {
  userId: string;
  pathName: string;
  description?: string;
  modules?: string;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO learning_paths (userId, pathName, description, modules, progress, status, createdAt)
    VALUES (?, ?, ?, ?, 0, 'active', ?)
  `);
  
  const result = stmt.run(
    path.userId,
    path.pathName,
    path.description || null,
    path.modules || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...path };
}

export function updateLearningPathProgress(id: number, progress: number) {
  const db = getDb();
  const status = progress >= 100 ? 'completed' : 'active';
  return db
    .prepare("UPDATE learning_paths SET progress = ?, status = ?, updatedAt = ? WHERE id = ?")
    .run(progress, status, Date.now(), id);
}

export function deleteLearningPath(id: number, userId: string) {
  const db = getDb();
  return db
    .prepare("DELETE FROM learning_paths WHERE id = ? AND userId = ?")
    .run(id, userId);
}

// ==================== TRADING SIGNALS FUNCTIONS ====================

export function getAssetTradingSignals(assetId: number, limit: number = 50) {
  const db = getDb();
  return db
    .prepare(`
      SELECT * FROM trading_signals
      WHERE assetId = ? AND (validUntil IS NULL OR validUntil > ?)
      ORDER BY createdAt DESC
      LIMIT ?
    `)
    .all(assetId, Date.now(), limit);
}

export function createTradingSignalDb(signal: {
  assetId: number;
  signalType: string;
  strength?: string;
  price: number;
  targetPrice?: number;
  stopLoss?: number;
  confidence?: number;
  validUntil?: number;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO trading_signals (assetId, signalType, strength, price, targetPrice, stopLoss, confidence, validUntil, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    signal.assetId,
    signal.signalType,
    signal.strength || 'moderate',
    signal.price,
    signal.targetPrice || null,
    signal.stopLoss || null,
    signal.confidence || 0.5,
    signal.validUntil || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...signal };
}

// ==================== TECHNICAL INDICATORS FUNCTIONS ====================

export function getAssetTechnicalIndicators(assetId: number, indicatorType?: string) {
  const db = getDb();
  if (indicatorType) {
    return db
      .prepare(`
        SELECT * FROM technical_indicators
        WHERE assetId = ? AND indicatorType = ?
        ORDER BY calculatedAt DESC
        LIMIT 1
      `)
      .get(assetId, indicatorType);
  }
  return db
    .prepare("SELECT * FROM technical_indicators WHERE assetId = ? ORDER BY calculatedAt DESC")
    .all(assetId);
}

export function saveTechnicalIndicator(indicator: {
  assetId: number;
  indicatorType: string;
  value: number;
  period?: number;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO technical_indicators (assetId, indicatorType, value, period, calculatedAt)
    VALUES (?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    indicator.assetId,
    indicator.indicatorType,
    indicator.value,
    indicator.period || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...indicator };
}

// ==================== MODEL PERFORMANCE FUNCTIONS ====================

export function getModelPerformanceHistory(modelType?: string, limit: number = 50) {
  const db = getDb();
  if (modelType) {
    return db
      .prepare("SELECT * FROM model_performance WHERE modelType = ? ORDER BY evaluatedAt DESC LIMIT ?")
      .all(modelType, limit);
  }
  return db
    .prepare("SELECT * FROM model_performance ORDER BY evaluatedAt DESC LIMIT ?")
    .all(limit);
}

export function saveModelPerformance(performance: {
  modelType: string;
  accuracy?: number;
  mae?: number;
  rmse?: number;
  mape?: number;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO model_performance (modelType, accuracy, mae, rmse, mape, evaluatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    performance.modelType,
    performance.accuracy || null,
    performance.mae || null,
    performance.rmse || null,
    performance.mape || null,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...performance };
}

// ==================== AI CONVERSATIONS FUNCTIONS ====================

export function getAIConversations(userId: string, limit: number = 20) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM ai_conversations WHERE userId = ? ORDER BY createdAt DESC LIMIT ?")
    .all(userId, limit);
}

export function createAIConversation(conversation: {
  userId: string;
  assistantType?: string;
  messages: string;
  tokensUsed?: number;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO ai_conversations (userId, assistantType, messages, tokensUsed, createdAt)
    VALUES (?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    conversation.userId,
    conversation.assistantType || 'general',
    conversation.messages,
    conversation.tokensUsed || 0,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...conversation };
}

export function updateAIConversation(id: number, updates: { messages?: string; tokensUsed?: number }) {
  const db = getDb();
  const fields: string[] = [];
  const values: any[] = [];
  
  if (updates.messages) {
    fields.push("messages = ?");
    values.push(updates.messages);
  }
  if (updates.tokensUsed !== undefined) {
    fields.push("tokensUsed = ?");
    values.push(updates.tokensUsed);
  }
  fields.push("updatedAt = ?");
  values.push(Date.now());
  values.push(id);
  
  return db.prepare(`UPDATE ai_conversations SET ${fields.join(", ")} WHERE id = ?`).run(...values);
}

// ==================== AI MEMORIES (RAG) FUNCTIONS ====================

export function getAIMemories(userId: string, type?: string, limit: number = 50) {
  const db = getDb();
  if (type) {
    return db
      .prepare("SELECT * FROM ai_memories WHERE userId = ? AND type = ? ORDER BY relevanceScore DESC LIMIT ?")
      .all(userId, type, limit);
  }
  return db
    .prepare("SELECT * FROM ai_memories WHERE userId = ? ORDER BY relevanceScore DESC LIMIT ?")
    .all(userId, limit);
}

export function createAIMemory(memory: {
  userId: string;
  type?: string;
  content: string;
  keywords?: string;
  relevanceScore?: number;
}) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO ai_memories (userId, type, content, keywords, relevanceScore, createdAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    memory.userId,
    memory.type || 'fact',
    memory.content,
    memory.keywords || null,
    memory.relevanceScore || 1.0,
    Date.now()
  );
  
  return { id: result.lastInsertRowid, ...memory };
}

export function deleteAIMemory(id: number, userId: string) {
  const db = getDb();
  return db
    .prepare("DELETE FROM ai_memories WHERE id = ? AND userId = ?")
    .run(id, userId);
}

export function searchAIMemories(userId: string, searchTerm: string, limit: number = 10) {
  const db = getDb();
  return db
    .prepare(`
      SELECT * FROM ai_memories
      WHERE userId = ? AND (content LIKE ? OR keywords LIKE ?)
      ORDER BY relevanceScore DESC
      LIMIT ?
    `)
    .all(userId, `%${searchTerm}%`, `%${searchTerm}%`, limit);
}

export function clearUserAIMemories(userId: string) {
  const db = getDb();
  return db
    .prepare("DELETE FROM ai_memories WHERE userId = ?")
    .run(userId);
}
