/**
 * Enhanced AI System with LLM Integration
 * Advanced sentiment analysis and smart recommendations using OpenAI/Anthropic
 */

import { invokeLLM } from "./_core/llm";
import * as db from "./db-compat";

// ==================== ADVANCED SENTIMENT ANALYSIS ====================

export interface SentimentAnalysisResult {
  sentiment:
    | "very_negative"
    | "negative"
    | "neutral"
    | "positive"
    | "very_positive";
  score: number; // -1 to 1
  confidence: number; // 0 to 1
  keywords: string[];
  entities: string[];
  summary: string;
  impact: "high" | "medium" | "low";
}

export async function analyzeSentimentAdvanced(
  text: string,
  language: string = "ar"
): Promise<SentimentAnalysisResult> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "أنت محلل مشاعر خبير للأخبار المالية. قم بتحليل النص وإرجاع تحليل شامل بصيغة JSON." as any,
        },
        {
          role: "user",
          content: `حلل مشاعر هذا النص المالي وأعط تحليل شامل:

النص: "${text}"

قم بتحديد:
1. المشاعر العامة (very_negative, negative, neutral, positive, very_positive)
2. درجة المشاعر من -1 (سلبي جداً) إلى 1 (إيجابي جداً)
3. مستوى الثقة في التحليل (0 إلى 1)
4. الكلمات المفتاحية الأكثر أهمية (5-10 كلمات)
5. الكيانات المذكورة (شركات، أصول، أشخاص)
6. ملخص قصير للنص (جملة واحدة)
7. مستوى التأثير المتوقع على السوق (high, medium, low)`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "sentiment_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              sentiment: {
                type: "string",
                enum: [
                  "very_negative",
                  "negative",
                  "neutral",
                  "positive",
                  "very_positive",
                ],
              },
              score: { type: "number", description: "Score from -1 to 1" },
              confidence: {
                type: "number",
                description: "Confidence from 0 to 1",
              },
              keywords: {
                type: "array",
                items: { type: "string" },
                description: "5-10 most important keywords",
              },
              entities: {
                type: "array",
                items: { type: "string" },
                description: "Companies, assets, people mentioned",
              },
              summary: { type: "string", description: "One sentence summary" },
              impact: {
                type: "string",
                enum: ["high", "medium", "low"],
                description: "Expected market impact",
              },
            },
            required: [
              "sentiment",
              "score",
              "confidence",
              "keywords",
              "entities",
              "summary",
              "impact",
            ],
            additionalProperties: false,
          },
        },
      },
    });

    const result = JSON.parse(response.choices[0].message.content as string);

    // Save to database
    await db.insertSentimentAnalysis({
      text,
      language,
      sentiment: result.sentiment,
      score: result.score,
      confidence: result.confidence,
      keywords: result.keywords,
      entities: result.entities,
      summary: result.summary,
      impact: result.impact
    });

    return result;
  } catch (error) {
    console.error("[AI] Sentiment analysis error:", error);
    // Fallback to simple analysis
    return {
      sentiment: "neutral",
      score: 0,
      confidence: 0.5,
      keywords: [],
      entities: [],
      summary: "تعذر تحليل النص",
      impact: "low",
    };
  }
}

/**
 * Batch sentiment analysis for multiple texts
 */
export async function analyzeSentimentBatch(
  texts: string[]
): Promise<SentimentAnalysisResult[]> {
  const results: SentimentAnalysisResult[] = [];

  for (const text of texts) {
    const result = await analyzeSentimentAdvanced(text);
    results.push(result);
  }

  return results;
}

// ==================== SMART AI RECOMMENDATIONS ====================

export interface SmartRecommendation {
  type: "buy" | "sell" | "hold" | "diversify" | "reduce_risk" | "take_profit";
  assetId?: number;
  assetSymbol?: string;
  title: string;
  description: string;
  reasoning: string[];
  confidence: number; // 0 to 100
  expectedReturn?: number;
  riskLevel: "low" | "medium" | "high";
  timeframe: "short" | "medium" | "long";
  priority: "low" | "medium" | "high" | "urgent";
}

export async function generateSmartRecommendation(
  userId: string,
  assetId?: number
): Promise<SmartRecommendation[]> {
  try {
    // Gather comprehensive data using db-compat helpers
    const portfolioData = await db.getPortfolioJoined(userId);
    // Filter by assetId if provided (though db.getPortfolioJoined returns all, we might want to filter in memory or update helper. 
    // For now filtering in memory is fine for typical portfolio size)
    const filteredPortfolio = assetId 
        ? portfolioData.filter((p: any) => p.assetId === assetId) 
        : portfolioData;

    const priceHistory = await db.getPriceHistoryForAI(userId);
    
    // Note: getRecentNewsForAI and getMarketTrendsForAI are generic (not per user/asset necessarily, or they return global context)
    const recentNews = await db.getRecentNewsForAI();
    const marketTrends = await db.getMarketTrendsForAI();

    // Prepare data for LLM
    const contextData = {
      portfolio: filteredPortfolio,
      priceHistory: priceHistory.slice(0, 50), // Last 50 data points
      recentNews: recentNews.map((n: any) => ({
        title: n.title,
        sentiment: n.sentiment,
      })),
      marketTrends: marketTrends,
    };

    // Get AI recommendations
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            `أنت مستشار مالي خبير متخصص في تحليل المحافظ الاستثمارية وتقديم التوصيات الذكية.

قم بتحليل البيانات المقدمة وتقديم توصيات استثمارية ذكية بناءً على:
1. أداء المحفظة الحالي
2. اتجاهات الأسعار التاريخية
3. معنويات الأخبار الأخيرة
4. اتجاهات السوق
5. مستوى المخاطر

قدم 3-5 توصيات مرتبة حسب الأولوية.` as any,
        },
        {
          role: "user",
          content: `بيانات المحفظة والسوق:

${JSON.stringify(contextData, null, 2)}

قدم توصيات استثمارية ذكية مع:
- نوع التوصية (buy, sell, hold, diversify, reduce_risk, take_profit)
- الأصل المستهدف (إن وجد)
- العنوان والوصف
- الأسباب المنطقية (3-5 نقاط)
- مستوى الثقة (0-100)
- العائد المتوقع (إن أمكن)
- مستوى المخاطر (low, medium, high)
- الإطار الزمني (short, medium, long)
- الأولوية (low, medium, high, urgent)`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "recommendations",
          strict: true,
          schema: {
            type: "object",
            properties: {
              recommendations: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    type: {
                      type: "string",
                      enum: [
                        "buy",
                        "sell",
                        "hold",
                        "diversify",
                        "reduce_risk",
                        "take_profit",
                      ],
                    },
                    assetId: { type: "number" },
                    assetSymbol: { type: "string" },
                    title: { type: "string" },
                    description: { type: "string" },
                    reasoning: {
                      type: "array",
                      items: { type: "string" },
                    },
                    confidence: { type: "number" },
                    expectedReturn: { type: "number" },
                    riskLevel: {
                      type: "string",
                      enum: ["low", "medium", "high"],
                    },
                    timeframe: {
                      type: "string",
                      enum: ["short", "medium", "long"],
                    },
                    priority: {
                      type: "string",
                      enum: ["low", "medium", "high", "urgent"],
                    },
                  },
                  required: [
                    "type",
                    "title",
                    "description",
                    "reasoning",
                    "confidence",
                    "riskLevel",
                    "timeframe",
                    "priority",
                  ],
                  additionalProperties: false,
                },
              },
            },
            required: ["recommendations"],
            additionalProperties: false,
          },
        },
      },
    });

    const result = JSON.parse(response.choices[0].message.content as string);

    // Save recommendations to database
    for (const rec of result.recommendations) {
      await db.insertAIRecommendation({
        userId,
        type: rec.type,
        assetId: rec.assetId,
        title: rec.title,
        description: rec.description,
        reasoning: rec.reasoning,
        confidence: rec.confidence,
        expectedReturn: rec.expectedReturn,
        riskLevel: rec.riskLevel,
        timeframe: rec.timeframe,
        priority: rec.priority
      });
    }

    return result.recommendations;
  } catch (error) {
    console.error("[AI] Smart recommendation error:", error);
    return [];
  }
}

/**
 * Evaluate recommendation performance (backtesting)
 */
export async function evaluateRecommendationPerformance(
  recommendationId: number
): Promise<{
  success: boolean;
  actualReturn: number;
  expectedReturn: number;
  accuracy: number;
}> {
  try {
    const rec = await db.getAIRecommendationById(recommendationId);

    if (!rec) {
      return {
        success: false,
        actualReturn: 0,
        expectedReturn: 0,
        accuracy: 0,
      };
    }

    // Get actual price movement
    // Need price history starting from creation time of recommendation
    const priceData = await db.getAssetPriceHistoryAfter(rec.assetId, rec.createdAt, 2);

    if (!priceData || priceData.length < 2) {
      return {
        success: false,
        actualReturn: 0,
        expectedReturn: 0,
        accuracy: 0,
      };
    }

    const startPrice = priceData[0].price;
    // Assuming the second point is the "latest" we could get or 'end' price for evaluation
    // If limit is 2, and we sort ASC, 0 is start, 1 is next available point.
    // Ideally we want current price. 
    // getAssetPriceHistoryAfter sorts ASC. 
    // If we only got 2 points, indices are 0 and 1.
    const endPrice = priceData[priceData.length - 1].price;
    
    const actualReturn = ((endPrice - startPrice) / startPrice) * 100;
    const expectedReturn = rec.expectedReturn || 0;

    const accuracy =
      expectedReturn !== 0
        ? Math.max(
            0,
            100 -
              (Math.abs(actualReturn - expectedReturn) /
                Math.abs(expectedReturn)) *
                100
          )
        : 50;

    // Update recommendation with results
    await db.updateAIRecommendation(recommendationId, {
      actualReturn,
      accuracy,
      status: 'evaluated'
    });

    return {
      success: true,
      actualReturn,
      expectedReturn,
      accuracy,
    };
  } catch (error) {
    console.error("[AI] Evaluation error:", error);
    return { success: false, actualReturn: 0, expectedReturn: 0, accuracy: 0 };
  }
}

// ==================== AI CHAT ASSISTANT ====================

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export async function chatWithAI(
  userId: string,
  message: string,
  conversationHistory: ChatMessage[] = []
): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `أنت مساعد مالي ذكي متخصص في تحليل الأصول والاستثمارات.

يمكنك:
- تحليل الأصول والأسعار
- تقديم توصيات استثمارية
- شرح المفاهيم المالية
- الإجابة على الأسئلة المتعلقة بالمحفظة

كن دقيقاً ومفيداً وودوداً في إجاباتك.` as any,
        },
        ...conversationHistory.map(msg => ({
          role: msg.role,
          content: msg.content as any,
        })),
        {
          role: "user",
          content: message as any,
        },
      ],
    });

    const reply = response.choices[0].message.content as string;

    // Save conversation to database
    await db.insertAIConversation({
      userId,
      userMessage: message,
      assistantResponse: reply
    });

    return reply;
  } catch (error) {
    console.error("[AI] Chat error:", error);
    return "عذراً، حدث خطأ في معالجة رسالتك. يرجى المحاولة مرة أخرى.";
  }
}

/**
 * Get conversation history
 */
export async function getConversationHistory(
  userId: string,
  limit: number = 50
): Promise<ChatMessage[]> {
  try {
    const rows = await db.getChatHistory(userId, limit);

    const history: ChatMessage[] = [];
    for (const row of rows) {
      history.push({ role: "user", content: row.userMessage });
      history.push({ role: "assistant", content: row.assistantResponse });
    }

    return history.reverse();
  } catch (error) {
    console.error("[AI] Error fetching history:", error);
    return [];
  }
}
