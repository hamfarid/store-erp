/**
 * FILE: server/ml/learning-path/aco-optimizer.ts
 * PURPOSE: Ant Colony Optimization for feature selection and hyperparameter tuning
 * OWNER: ML Team
 * RELATED: server/ml/learning-path/path-evaluator.ts
 * LAST-AUDITED: 2025-01-18
 */

/**
 * ACO Configuration
 */
export interface ACOConfig {
  numAnts: number; // Number of ants per iteration
  numIterations: number; // Number of iterations
  alpha: number; // Pheromone importance (default: 1.0)
  beta: number; // Heuristic importance (default: 2.0)
  evaporationRate: number; // Pheromone evaporation (default: 0.1)
  pheromoneDeposit: number; // Amount of pheromone to deposit (default: 1.0)
  elitistWeight: number; // Weight for best solution (default: 2.0)
}

/**
 * Feature/Parameter Node
 */
export interface Node {
  id: string;
  type: "feature" | "hyperparameter";
  name: string;
  value: number | string;
  pheromone: number;
  heuristic: number; // Based on historical performance
}

/**
 * Ant Solution
 */
export interface AntSolution {
  path: Node[];
  score: number;
  features: string[];
  hyperparameters: Record<string, number | string>;
}

/**
 * ACO Result
 */
export interface ACOResult {
  bestSolution: AntSolution;
  allSolutions: AntSolution[];
  convergenceHistory: number[];
  pheromoneMap: Map<string, number>;
  iterations: number;
}

/**
 * Ant Colony Optimization for ML Path Optimization
 */
export class ACOOptimizer {
  private config: ACOConfig;
  private nodes: Node[];
  private pheromoneMap: Map<string, number>;
  private bestSolution: AntSolution | null;

  constructor(config: Partial<ACOConfig> = {}) {
    this.config = {
      numAnts: config.numAnts || 20,
      numIterations: config.numIterations || 50,
      alpha: config.alpha || 1.0,
      beta: config.beta || 2.0,
      evaporationRate: config.evaporationRate || 0.1,
      pheromoneDeposit: config.pheromoneDeposit || 1.0,
      elitistWeight: config.elitistWeight || 2.0,
    };
    this.nodes = [];
    this.pheromoneMap = new Map();
    this.bestSolution = null;
  }

  /**
   * Initialize nodes (features and hyperparameters)
   */
  initializeNodes(
    features: string[],
    hyperparameters: Record<string, number[]>
  ): void {
    this.nodes = [];

    // Add feature nodes
    features.forEach(feature => {
      this.nodes.push({
        id: `feature_${feature}`,
        type: "feature",
        name: feature,
        value: feature,
        pheromone: 1.0,
        heuristic: 1.0,
      });
    });

    // Add hyperparameter nodes
    Object.entries(hyperparameters).forEach(([param, values]) => {
      values.forEach(value => {
        this.nodes.push({
          id: `param_${param}_${value}`,
          type: "hyperparameter",
          name: param,
          value,
          pheromone: 1.0,
          heuristic: 1.0,
        });
      });
    });
  }

  /**
   * Run ACO optimization
   */
  async optimize(
    evaluateFunction: (solution: AntSolution) => Promise<number>
  ): Promise<ACOResult> {
    const convergenceHistory: number[] = [];
    const allSolutions: AntSolution[] = [];

    for (
      let iteration = 0;
      iteration < this.config.numIterations;
      iteration++
    ) {
      const iterationSolutions: AntSolution[] = [];

      // Generate solutions for all ants
      for (let ant = 0; ant < this.config.numAnts; ant++) {
        const solution = this.constructSolution();
        solution.score = await evaluateFunction(solution);
        iterationSolutions.push(solution);
        allSolutions.push(solution);

        // Update best solution
        if (!this.bestSolution || solution.score > this.bestSolution.score) {
          this.bestSolution = solution;
        }
      }

      // Update pheromones
      this.updatePheromones(iterationSolutions);

      // Track convergence
      convergenceHistory.push(this.bestSolution?.score || 0);
    }

    return {
      bestSolution: this.bestSolution!,
      allSolutions,
      convergenceHistory,
      pheromoneMap: this.pheromoneMap,
      iterations: this.config.numIterations,
    };
  }

  /**
   * Construct solution using probabilistic selection
   */
  private constructSolution(): AntSolution {
    const selectedFeatures: string[] = [];
    const selectedHyperparameters: Record<string, number | string> = {};
    const path: Node[] = [];

    // Select features
    const featureNodes = this.nodes.filter(n => n.type === "feature");
    featureNodes.forEach(node => {
      if (this.shouldSelectNode(node)) {
        selectedFeatures.push(node.value as string);
        path.push(node);
      }
    });

    // Select hyperparameters (one value per parameter)
    const hyperparamGroups = this.groupHyperparameters();
    Object.entries(hyperparamGroups).forEach(([param, nodes]) => {
      const selected = this.selectFromGroup(nodes);
      if (selected) {
        selectedHyperparameters[param] = selected.value;
        path.push(selected);
      }
    });

    return {
      path,
      score: 0,
      features: selectedFeatures,
      hyperparameters: selectedHyperparameters,
    };
  }

  /**
   * Probabilistic node selection based on pheromone and heuristic
   */
  private shouldSelectNode(node: Node): boolean {
    const probability = this.calculateProbability(node);
    return Math.random() < probability;
  }

  /**
   * Calculate selection probability
   */
  private calculateProbability(node: Node): number {
    const pheromone = Math.pow(node.pheromone, this.config.alpha);
    const heuristic = Math.pow(node.heuristic, this.config.beta);
    return Math.min(0.9, (pheromone * heuristic) / 10);
  }

  /**
   * Group hyperparameter nodes by parameter name
   */
  private groupHyperparameters(): Record<string, Node[]> {
    const groups: Record<string, Node[]> = {};
    this.nodes
      .filter(n => n.type === "hyperparameter")
      .forEach(node => {
        if (!groups[node.name]) {
          groups[node.name] = [];
        }
        groups[node.name].push(node);
      });
    return groups;
  }

  /**
   * Select one node from a group using roulette wheel selection
   */
  private selectFromGroup(nodes: Node[]): Node | null {
    if (nodes.length === 0) {return null;}

    const probabilities = nodes.map(n => this.calculateProbability(n));
    const total = probabilities.reduce((sum, p) => sum + p, 0);

    let random = Math.random() * total;
    for (let i = 0; i < nodes.length; i++) {
      random -= probabilities[i];
      if (random <= 0) {
        return nodes[i];
      }
    }

    return nodes[nodes.length - 1];
  }

  /**
   * Update pheromones based on solutions
   */
  private updatePheromones(solutions: AntSolution[]): void {
    // Evaporate pheromones
    this.nodes.forEach(node => {
      node.pheromone *= 1 - this.config.evaporationRate;
    });

    // Deposit pheromones
    solutions.forEach(solution => {
      const deposit =
        this.config.pheromoneDeposit *
        (solution.score / (solutions.length || 1));
      solution.path.forEach(node => {
        const foundNode = this.nodes.find(n => n.id === node.id);
        if (foundNode) {
          foundNode.pheromone += deposit;
        }
      });
    });

    // Elitist strategy: extra pheromone for best solution
    if (this.bestSolution) {
      const elitistDeposit =
        this.config.pheromoneDeposit * this.config.elitistWeight;
      this.bestSolution.path.forEach(node => {
        const foundNode = this.nodes.find(n => n.id === node.id);
        if (foundNode) {
          foundNode.pheromone += elitistDeposit;
        }
      });
    }

    // Update pheromone map
    this.pheromoneMap.clear();
    this.nodes.forEach(node => {
      this.pheromoneMap.set(node.id, node.pheromone);
    });
  }
}
