/**
 * FILE: server/ml/learning-path/path-evaluator.ts
 * PURPOSE: Evaluate learning paths and model configurations
 * OWNER: ML Team
 * RELATED: server/ml/learning-path/aco-optimizer.ts, server/ml/learning-path/rl-optimizer.ts
 * LAST-AUDITED: 2025-01-18
 */

import { ENV } from "../../_core/env";

/**
 * Evaluation Metrics
 */
export interface EvaluationMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  mae: number; // Mean Absolute Error
  rmse: number; // Root Mean Squared Error
  trainingTime: number; // seconds
  score: number; // Overall fitness score
}

/**
 * Path Configuration
 */
export interface PathConfig {
  symbol: string;
  modelType: "lstm" | "gru" | "transformer" | "ensemble";
  features: string[];
  hyperparameters: Record<string, number | string>;
}

/**
 * Evaluate a learning path configuration
 */
export async function evaluatePath(
  config: PathConfig
): Promise<EvaluationMetrics> {
  try {
    // Call Python ML backend to train and evaluate model
    const mlServiceUrl = process.env.ML_SERVICE_URL || 'http://localhost:5000';
    const response = await fetch(`${mlServiceUrl}/learning-path/evaluate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config),
    });

    if (!response.ok) {
      throw new Error(`ML service error: ${response.statusText}`);
    }

    const result = await response.json();

    // Calculate overall fitness score
    const score = calculateFitnessScore(result);

    return {
      accuracy: result.accuracy || 0,
      precision: result.precision || 0,
      recall: result.recall || 0,
      f1Score: result.f1_score || 0,
      mae: result.mae || 0,
      rmse: result.rmse || 0,
      trainingTime: result.training_time || 0,
      score,
    };
  } catch (error) {
    console.error("[PathEvaluator] Error evaluating path:", error);
    // Return poor metrics on error
    return {
      accuracy: 0,
      precision: 0,
      recall: 0,
      f1Score: 0,
      mae: 999,
      rmse: 999,
      trainingTime: 0,
      score: 0,
    };
  }
}

/**
 * Calculate fitness score from metrics
 * Higher is better
 */
export function calculateFitnessScore(metrics: Partial<EvaluationMetrics>): number {
  const weights = {
    accuracy: 0.3,
    f1Score: 0.25,
    precision: 0.15,
    recall: 0.15,
    mae: -0.075, // Negative because lower is better
    rmse: -0.075, // Negative because lower is better
  };

  let score = 0;

  // Positive metrics (higher is better)
  score += (metrics.accuracy || 0) * weights.accuracy;
  score += (metrics.f1Score || 0) * weights.f1Score;
  score += (metrics.precision || 0) * weights.precision;
  score += (metrics.recall || 0) * weights.recall;

  // Negative metrics (lower is better) - normalize to 0-1 range
  const normalizedMAE = Math.max(0, 1 - (metrics.mae || 0) / 100);
  const normalizedRMSE = Math.max(0, 1 - (metrics.rmse || 0) / 100);
  score += normalizedMAE * Math.abs(weights.mae);
  score += normalizedRMSE * Math.abs(weights.rmse);

  return Math.max(0, Math.min(1, score)); // Clamp to [0, 1]
}

/**
 * Compare two paths and return the better one
 */
export function comparePaths(
  path1: { config: PathConfig; metrics: EvaluationMetrics },
  path2: { config: PathConfig; metrics: EvaluationMetrics }
): { config: PathConfig; metrics: EvaluationMetrics } {
  return path1.metrics.score > path2.metrics.score ? path1 : path2;
}

/**
 * Validate path configuration
 */
export function validatePathConfig(config: PathConfig): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  // Check symbol
  if (!config.symbol || config.symbol.trim() === "") {
    errors.push("Symbol is required");
  }

  // Check model type
  const validModelTypes = ["lstm", "gru", "transformer", "ensemble"];
  if (!validModelTypes.includes(config.modelType)) {
    errors.push(`Invalid model type: ${config.modelType}`);
  }

  // Check features
  if (!config.features || config.features.length === 0) {
    errors.push("At least one feature is required");
  }

  // Check hyperparameters
  if (!config.hyperparameters || Object.keys(config.hyperparameters).length === 0) {
    errors.push("Hyperparameters are required");
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

