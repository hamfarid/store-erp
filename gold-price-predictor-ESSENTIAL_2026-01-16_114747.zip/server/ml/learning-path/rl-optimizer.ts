/**
 * FILE: server/ml/learning-path/rl-optimizer.ts
 * PURPOSE: Reinforcement Learning (Q-Learning) for hyperparameter optimization
 * OWNER: ML Team
 * RELATED: server/ml/learning-path/path-evaluator.ts
 * LAST-AUDITED: 2025-01-18
 */

/**
 * RL Configuration
 */
export interface RLConfig {
  learningRate: number; // Alpha (default: 0.1)
  discountFactor: number; // Gamma (default: 0.9)
  explorationRate: number; // Epsilon (default: 0.3)
  explorationDecay: number; // Epsilon decay (default: 0.995)
  minExploration: number; // Min epsilon (default: 0.01)
  numEpisodes: number; // Number of training episodes (default: 100)
  maxStepsPerEpisode: number; // Max steps per episode (default: 50)
}

/**
 * State representation
 */
export interface State {
  features: string[];
  hyperparameters: Record<string, number | string>;
  performance: number; // Current model performance
}

/**
 * Action representation
 */
export interface Action {
  type: "add_feature" | "remove_feature" | "adjust_hyperparameter";
  target: string; // Feature name or hyperparameter name
  value?: number | string; // New value for hyperparameter
}

/**
 * Q-Table entry
 */
export interface QEntry {
  state: string; // Serialized state
  action: string; // Serialized action
  qValue: number;
}

/**
 * RL Result
 */
export interface RLResult {
  bestState: State;
  qTable: Map<string, Map<string, number>>;
  episodeRewards: number[];
  convergenceHistory: number[];
  episodes: number;
}

/**
 * Reinforcement Learning Optimizer using Q-Learning
 */
export class RLOptimizer {
  private config: RLConfig;
  private qTable: Map<string, Map<string, number>>; // state -> action -> Q-value
  private explorationRate: number;
  private bestState: State | null;
  private bestReward: number;

  constructor(config: Partial<RLConfig> = {}) {
    this.config = {
      learningRate: config.learningRate || 0.1,
      discountFactor: config.discountFactor || 0.9,
      explorationRate: config.explorationRate || 0.3,
      explorationDecay: config.explorationDecay || 0.995,
      minExploration: config.minExploration || 0.01,
      numEpisodes: config.numEpisodes || 100,
      maxStepsPerEpisode: config.maxStepsPerEpisode || 50,
    };
    this.qTable = new Map();
    this.explorationRate = this.config.explorationRate;
    this.bestState = null;
    this.bestReward = -Infinity;
  }

  /**
   * Train the RL agent
   */
  async train(
    initialState: State,
    possibleActions: Action[],
    evaluateFunction: (state: State) => Promise<number>
  ): Promise<RLResult> {
    const episodeRewards: number[] = [];
    const convergenceHistory: number[] = [];

    for (let episode = 0; episode < this.config.numEpisodes; episode++) {
      let currentState = { ...initialState };
      let episodeReward = 0;

      for (let step = 0; step < this.config.maxStepsPerEpisode; step++) {
        // Choose action (epsilon-greedy)
        const action = this.chooseAction(currentState, possibleActions);

        // Take action and get next state
        const nextState = this.applyAction(currentState, action);

        // Evaluate next state
        const reward = await evaluateFunction(nextState);
        episodeReward += reward;

        // Update Q-table
        this.updateQValue(
          currentState,
          action,
          reward,
          nextState,
          possibleActions
        );

        // Update best state
        if (reward > this.bestReward) {
          this.bestReward = reward;
          this.bestState = { ...nextState };
        }

        // Move to next state
        currentState = nextState;
      }

      // Decay exploration rate
      this.explorationRate = Math.max(
        this.config.minExploration,
        this.explorationRate * this.config.explorationDecay
      );

      episodeRewards.push(episodeReward);
      convergenceHistory.push(this.bestReward);
    }

    return {
      bestState: this.bestState!,
      qTable: this.qTable,
      episodeRewards,
      convergenceHistory,
      episodes: this.config.numEpisodes,
    };
  }

  /**
   * Choose action using epsilon-greedy strategy
   */
  private chooseAction(state: State, possibleActions: Action[]): Action {
    // Exploration: random action
    if (Math.random() < this.explorationRate) {
      return possibleActions[
        Math.floor(Math.random() * possibleActions.length)
      ];
    }

    // Exploitation: best action from Q-table
    const stateKey = this.serializeState(state);
    const actionQValues = this.qTable.get(stateKey);

    if (!actionQValues || actionQValues.size === 0) {
      // No Q-values yet, choose random
      return possibleActions[
        Math.floor(Math.random() * possibleActions.length)
      ];
    }

    // Find action with highest Q-value
    let bestAction: Action | null = null;
    let bestQValue = -Infinity;

    possibleActions.forEach(action => {
      const actionKey = this.serializeAction(action);
      const qValue = actionQValues.get(actionKey) || 0;
      if (qValue > bestQValue) {
        bestQValue = qValue;
        bestAction = action;
      }
    });

    return bestAction || possibleActions[0];
  }

  /**
   * Update Q-value using Q-learning formula
   */
  private updateQValue(
    state: State,
    action: Action,
    reward: number,
    nextState: State,
    possibleActions: Action[]
  ): void {
    const stateKey = this.serializeState(state);
    const actionKey = this.serializeAction(action);

    // Get current Q-value
    if (!this.qTable.has(stateKey)) {
      this.qTable.set(stateKey, new Map());
    }
    const currentQ = this.qTable.get(stateKey)!.get(actionKey) || 0;

    // Get max Q-value for next state
    const nextStateKey = this.serializeState(nextState);
    const nextActionQValues = this.qTable.get(nextStateKey);
    let maxNextQ = 0;

    if (nextActionQValues) {
      possibleActions.forEach(a => {
        const aKey = this.serializeAction(a);
        const qValue = nextActionQValues.get(aKey) || 0;
        maxNextQ = Math.max(maxNextQ, qValue);
      });
    }

    // Q-learning update: Q(s,a) = Q(s,a) + α[r + γ*max(Q(s',a')) - Q(s,a)]
    const newQ =
      currentQ +
      this.config.learningRate *
        (reward + this.config.discountFactor * maxNextQ - currentQ);

    this.qTable.get(stateKey)!.set(actionKey, newQ);
  }

  /**
   * Apply action to state and return new state
   */
  private applyAction(state: State, action: Action): State {
    const newState: State = {
      features: [...state.features],
      hyperparameters: { ...state.hyperparameters },
      performance: state.performance,
    };

    switch (action.type) {
      case "add_feature":
        if (!newState.features.includes(action.target)) {
          newState.features.push(action.target);
        }
        break;

      case "remove_feature":
        newState.features = newState.features.filter(f => f !== action.target);
        break;

      case "adjust_hyperparameter":
        if (action.value !== undefined) {
          newState.hyperparameters[action.target] = action.value;
        }
        break;
    }

    return newState;
  }

  /**
   * Serialize state to string key
   */
  private serializeState(state: State): string {
    return JSON.stringify({
      features: state.features.sort(),
      hyperparameters: state.hyperparameters,
    });
  }

  /**
   * Serialize action to string key
   */
  private serializeAction(action: Action): string {
    return JSON.stringify(action);
  }

  /**
   * Get Q-value for state-action pair
   */
  getQValue(state: State, action: Action): number {
    const stateKey = this.serializeState(state);
    const actionKey = this.serializeAction(action);
    return this.qTable.get(stateKey)?.get(actionKey) || 0;
  }

  /**
   * Get best action for a given state
   */
  getBestAction(state: State, possibleActions: Action[]): Action {
    const stateKey = this.serializeState(state);
    const actionQValues = this.qTable.get(stateKey);

    if (!actionQValues || actionQValues.size === 0) {
      return possibleActions[0];
    }

    let bestAction = possibleActions[0];
    let bestQValue = -Infinity;

    possibleActions.forEach(action => {
      const actionKey = this.serializeAction(action);
      const qValue = actionQValues.get(actionKey) || 0;
      if (qValue > bestQValue) {
        bestQValue = qValue;
        bestAction = action;
      }
    });

    return bestAction;
  }
}
