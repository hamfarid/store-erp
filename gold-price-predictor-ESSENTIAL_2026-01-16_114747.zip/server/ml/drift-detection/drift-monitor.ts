/**
 * FILE: server/ml/drift-detection/drift-monitor.ts
 * PURPOSE: Main drift monitoring service that orchestrates all detectors
 * OWNER: ML Team
 * RELATED: psi-detector.ts, ks-test-detector.ts, autoencoder-detector.ts
 * LAST-AUDITED: 2025-01-18
 */

import {
  insertDriftDetection,
  insertDriftAlert,
} from "../../db-compat";
import {
  type NewDriftDetection,
  type NewDriftAlert,
} from "../../../drizzle/schema-drift";
import { calculatePSI, type PSIResult } from "./psi-detector";
import { performKSTest, type KSTestResult } from "./ks-test-detector";
import {
  detectDriftWithAutoencoder,
  type AutoencoderResult,
} from "./autoencoder-detector";
import { nanoid } from "nanoid";

export interface DriftMonitorResult {
  symbol: string;
  timestamp: Date;
  psi?: PSIResult;
  ksTest?: KSTestResult;
  autoencoder?: AutoencoderResult;
  overallSeverity: "none" | "low" | "medium" | "high";
  recommendRetraining: boolean;
  alerts: string[];
}

/**
 * Monitor drift for a symbol using all available detectors
 */
export async function monitorDrift(
  symbol: string,
  baselineData: Record<string, number[]>,
  currentData: Record<string, number[]>,
  options: {
    usePSI?: boolean;
    useKSTest?: boolean;
    useAutoencoder?: boolean;
    autoencoderData?: number[][];
  } = {}
): Promise<DriftMonitorResult> {
  const {
    usePSI = true,
    useKSTest = true,
    useAutoencoder = false,
    autoencoderData,
  } = options;

  const results: DriftMonitorResult = {
    symbol,
    timestamp: new Date(),
    overallSeverity: "none",
    recommendRetraining: false,
    alerts: [],
  };

  const severities: Array<"none" | "low" | "medium" | "high"> = [];

  // 1. PSI Detection
  if (usePSI) {
    try {
      const psiResults: Record<string, PSIResult> = {};
      for (const feature in baselineData) {
        if (currentData[feature]) {
          psiResults[feature] = calculatePSI(
            baselineData[feature],
            currentData[feature]
          );
        }
      }

      // Get worst PSI result
      const worstPSI = Object.values(psiResults).reduce((worst, current) =>
        current.psi > worst.psi ? current : worst
      );

      results.psi = worstPSI;
      severities.push(worstPSI.severity);

      // Save to database
      await saveDriftDetection(symbol, "psi", worstPSI.psi, worstPSI.severity, {
        features: psiResults,
      });
    } catch (error) {
      console.error("[Drift Monitor] PSI error:", error);
      results.alerts.push(`PSI detection failed: ${error}`);
    }
  }

  // 2. KS Test Detection
  if (useKSTest) {
    try {
      const ksResults: Record<string, KSTestResult> = {};
      for (const feature in baselineData) {
        if (currentData[feature]) {
          ksResults[feature] = performKSTest(
            baselineData[feature],
            currentData[feature]
          );
        }
      }

      // Get worst KS result
      const worstKS = Object.values(ksResults).reduce((worst, current) =>
        current.ksStatistic > worst.ksStatistic ? current : worst
      );

      results.ksTest = worstKS;
      severities.push(worstKS.severity);

      // Save to database
      await saveDriftDetection(
        symbol,
        "ks_test",
        worstKS.ksStatistic,
        worstKS.severity,
        { features: ksResults }
      );
    } catch (error) {
      console.error("[Drift Monitor] KS Test error:", error);
      results.alerts.push(`KS Test detection failed: ${error}`);
    }
  }

  // 3. Autoencoder Detection
  if (useAutoencoder && autoencoderData) {
    try {
      const autoencoderResult = await detectDriftWithAutoencoder(
        symbol,
        autoencoderData
      );

      results.autoencoder = autoencoderResult;
      severities.push(autoencoderResult.severity);

      // Save to database
      await saveDriftDetection(
        symbol,
        "autoencoder",
        autoencoderResult.reconstructionError,
        autoencoderResult.severity,
        autoencoderResult.details
      );
    } catch (error) {
      console.error("[Drift Monitor] Autoencoder error:", error);
      results.alerts.push(`Autoencoder detection failed: ${error}`);
    }
  }

  // Determine overall severity (worst of all detectors)
  results.overallSeverity = getOverallSeverity(severities);

  // Recommend retraining if severity is high
  results.recommendRetraining =
    results.overallSeverity === "high" || results.overallSeverity === "medium";

  // Create alerts if needed
  if (results.recommendRetraining && results.overallSeverity !== "none") {
    await createDriftAlert(symbol, results.overallSeverity as "low" | "medium" | "high", results);
  }

  return results;
}

/**
 * Save drift detection to database
 */
async function saveDriftDetection(
  symbol: string,
  detectorType: "psi" | "ks_test" | "autoencoder",
  driftScore: number,
  severity: "none" | "low" | "medium" | "high",
  details: any
): Promise<void> {
  const detection: NewDriftDetection = {
    id: nanoid(),
    symbol,
    detectorType,
    driftScore,
    severity,
    details: JSON.stringify(details),
    actionTaken: null,
  };

  await insertDriftDetection(detection);
}

/**
 * Create drift alert
 */
async function createDriftAlert(
  symbol: string,
  severity: "low" | "medium" | "high",
  result: DriftMonitorResult
): Promise<void> {
  const message = `Drift detected for ${symbol} with ${severity} severity. Retraining recommended.`;

  const alert: NewDriftAlert = {
    id: nanoid(),
    driftDetectionId: nanoid(), // Link to latest detection
    severity: severity === "medium" || severity === "high" ? severity : "low",
    message,
    acknowledged: false,
    acknowledgedBy: null,
    acknowledgedAt: null,
  };

  await insertDriftAlert(alert);
}

/**
 * Get overall severity (worst of all)
 */
function getOverallSeverity(
  severities: Array<"none" | "low" | "medium" | "high">
): "none" | "low" | "medium" | "high" {
  if (severities.includes("high")) {return "high";}
  if (severities.includes("medium")) {return "medium";}
  if (severities.includes("low")) {return "low";}
  return "none";
}
