/**
 * FILE: server/ml/drift-detection/autoencoder-detector.ts
 * PURPOSE: Autoencoder-based drift detector (calls Python ML backend)
 * OWNER: ML Team
 * RELATED: drizzle/schema-drift.ts, ml_backend/app/routers/drift.py
 * LAST-AUDITED: 2025-01-18
 */

import { ENV } from "../../config/vault";

/**
 * Autoencoder Drift Detector
 * 
 * Uses a trained autoencoder to detect drift by measuring reconstruction error.
 * High reconstruction error indicates data has drifted from training distribution.
 * 
 * Interpretation:
 * - Reconstruction error < threshold: No drift
 * - Reconstruction error ≥ threshold: Drift detected
 */

export interface AutoencoderResult {
  reconstructionError: number;
  threshold: number;
  severity: "none" | "low" | "medium" | "high";
  details: {
    sampleSize: number;
    meanError: number;
    stdError: number;
    maxError: number;
    driftDetected: boolean;
  };
}

/**
 * Detect drift using autoencoder (calls Python ML backend)
 */
export async function detectDriftWithAutoencoder(
  symbol: string,
  currentData: number[][],
  threshold?: number
): Promise<AutoencoderResult> {
  const mlServiceUrl = ENV.ml.serviceUrl;

  try {
    const response = await fetch(`${mlServiceUrl}/drift/autoencoder`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        symbol,
        data: currentData,
        threshold,
      }),
    });

    if (!response.ok) {
      throw new Error(`ML service error: ${response.statusText}`);
    }

    const result = await response.json();

    // Determine severity
    const severity = getSeverity(
      result.reconstruction_error,
      result.threshold
    );

    return {
      reconstructionError: result.reconstruction_error,
      threshold: result.threshold,
      severity,
      details: {
        sampleSize: result.sample_size,
        meanError: result.mean_error,
        stdError: result.std_error,
        maxError: result.max_error,
        driftDetected: result.drift_detected,
      },
    };
  } catch (error) {
    console.error("[Autoencoder Detector] Error:", error);
    throw new Error(`Failed to detect drift with autoencoder: ${error}`);
  }
}

/**
 * Train autoencoder on baseline data (calls Python ML backend)
 */
export async function trainAutoencoder(
  symbol: string,
  baselineData: number[][],
  epochs: number = 50,
  latentDim: number = 10
): Promise<{
  success: boolean;
  threshold: number;
  modelPath: string;
}> {
  const mlServiceUrl = ENV.ml.serviceUrl;

  try {
    const response = await fetch(`${mlServiceUrl}/drift/train-autoencoder`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        symbol,
        data: baselineData,
        epochs,
        latent_dim: latentDim,
      }),
    });

    if (!response.ok) {
      throw new Error(`ML service error: ${response.statusText}`);
    }

    const result = await response.json();

    return {
      success: result.success,
      threshold: result.threshold,
      modelPath: result.model_path,
    };
  } catch (error) {
    console.error("[Autoencoder Detector] Training error:", error);
    throw new Error(`Failed to train autoencoder: ${error}`);
  }
}

/**
 * Determine severity based on reconstruction error
 */
function getSeverity(
  reconstructionError: number,
  threshold: number
): "none" | "low" | "medium" | "high" {
  const ratio = reconstructionError / threshold;

  if (ratio < 1.0) {return "none";}
  if (ratio < 1.5) {return "low";}
  if (ratio < 2.0) {return "medium";}
  return "high";
}

/**
 * Get autoencoder model info
 */
export async function getAutoencoderInfo(
  symbol: string
): Promise<{
  exists: boolean;
  threshold?: number;
  trainedAt?: string;
  sampleSize?: number;
}> {
  const mlServiceUrl = ENV.ml.serviceUrl;

  try {
    const response = await fetch(
      `${mlServiceUrl}/drift/autoencoder-info/${symbol}`
    );

    if (!response.ok) {
      return { exists: false };
    }

    const result = await response.json();
    return {
      exists: true,
      threshold: result.threshold,
      trainedAt: result.trained_at,
      sampleSize: result.sample_size,
    };
  } catch (error) {
    console.error("[Autoencoder Detector] Info error:", error);
    return { exists: false };
  }
}

