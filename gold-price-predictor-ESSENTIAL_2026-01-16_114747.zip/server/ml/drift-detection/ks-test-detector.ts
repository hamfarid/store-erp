/**
 * FILE: server/ml/drift-detection/ks-test-detector.ts
 * PURPOSE: Kolmogorov-Smirnov (KS) Test drift detector
 * OWNER: ML Team
 * RELATED: drizzle/schema-drift.ts, psi-detector.ts
 * LAST-AUDITED: 2025-01-18
 */

/**
 * Kolmogorov-Smirnov (KS) Test Detector
 * 
 * KS test measures the maximum distance between two cumulative distribution functions.
 * 
 * Interpretation:
 * - KS statistic: 0 to 1 (0 = identical distributions, 1 = completely different)
 * - p-value: probability that distributions are the same
 * - If p-value < 0.05: distributions are significantly different
 */

export interface KSTestResult {
  ksStatistic: number;
  pValue: number;
  severity: "none" | "low" | "medium" | "high";
  details: {
    sampleSize1: number;
    sampleSize2: number;
    maxDistance: number;
    criticalValue: number;
  };
}

/**
 * Perform Kolmogorov-Smirnov test
 */
export function performKSTest(
  sample1: number[],
  sample2: number[],
  alpha: number = 0.05
): KSTestResult {
  if (sample1.length === 0 || sample2.length === 0) {
    throw new Error("Samples cannot be empty");
  }

  // Sort samples
  const sorted1 = [...sample1].sort((a, b) => a - b);
  const sorted2 = [...sample2].sort((a, b) => a - b);

  // Calculate empirical CDFs
  const { ksStatistic, maxDistance } = calculateKSStatistic(sorted1, sorted2);

  // Calculate critical value
  const n1 = sample1.length;
  const n2 = sample2.length;
  const criticalValue = calculateCriticalValue(n1, n2, alpha);

  // Calculate p-value (approximation)
  const pValue = calculatePValue(ksStatistic, n1, n2);

  // Determine severity
  const severity = getSeverity(ksStatistic, pValue, alpha);

  return {
    ksStatistic,
    pValue,
    severity,
    details: {
      sampleSize1: n1,
      sampleSize2: n2,
      maxDistance,
      criticalValue,
    },
  };
}

/**
 * Calculate KS statistic (maximum distance between CDFs)
 */
function calculateKSStatistic(
  sorted1: number[],
  sorted2: number[]
): { ksStatistic: number; maxDistance: number } {
  const n1 = sorted1.length;
  const n2 = sorted2.length;

  let maxDistance = 0;
  let i = 0;
  let j = 0;

  while (i < n1 && j < n2) {
    const cdf1 = (i + 1) / n1;
    const cdf2 = (j + 1) / n2;
    const distance = Math.abs(cdf1 - cdf2);

    if (distance > maxDistance) {
      maxDistance = distance;
    }

    if (sorted1[i] < sorted2[j]) {
      i++;
    } else {
      j++;
    }
  }

  return { ksStatistic: maxDistance, maxDistance };
}

/**
 * Calculate critical value for KS test
 * Using approximation: c(α) * sqrt((n1 + n2) / (n1 * n2))
 */
function calculateCriticalValue(
  n1: number,
  n2: number,
  alpha: number
): number {
  // Critical values for common alpha levels
  const criticalValues: Record<number, number> = {
    0.1: 1.22,
    0.05: 1.36,
    0.01: 1.63,
  };

  const c = criticalValues[alpha] || 1.36; // Default to 0.05
  return c * Math.sqrt((n1 + n2) / (n1 * n2));
}

/**
 * Calculate p-value (approximation using Kolmogorov distribution)
 */
function calculatePValue(ksStatistic: number, n1: number, n2: number): number {
  const n = (n1 * n2) / (n1 + n2);
  const lambda = (Math.sqrt(n) + 0.12 + 0.11 / Math.sqrt(n)) * ksStatistic;

  // Approximation of Kolmogorov distribution
  // P(K ≤ x) ≈ 1 - 2 * Σ((-1)^(k-1) * exp(-2k²x²))
  let pValue = 0;
  for (let k = 1; k <= 10; k++) {
    pValue += Math.pow(-1, k - 1) * Math.exp(-2 * k * k * lambda * lambda);
  }
  pValue = 1 - 2 * pValue;

  // Clamp to [0, 1]
  return Math.max(0, Math.min(1, pValue));
}

/**
 * Determine severity based on KS statistic and p-value
 */
function getSeverity(
  ksStatistic: number,
  pValue: number,
  alpha: number
): "none" | "low" | "medium" | "high" {
  if (pValue >= alpha) {
    return "none"; // No significant difference
  }

  // Significant difference detected
  if (ksStatistic < 0.1) {return "low";}
  if (ksStatistic < 0.2) {return "medium";}
  return "high";
}

/**
 * Perform KS test for multiple features
 */
export function performMultiFeatureKSTest(
  expectedData: Record<string, number[]>,
  actualData: Record<string, number[]>,
  alpha: number = 0.05
): Record<string, KSTestResult> {
  const results: Record<string, KSTestResult> = {};

  for (const feature in expectedData) {
    if (actualData[feature]) {
      results[feature] = performKSTest(
        expectedData[feature],
        actualData[feature],
        alpha
      );
    }
  }

  return results;
}

