/**
 * FILE: server/ml/drift-detection/psi-detector.ts
 * PURPOSE: Population Stability Index (PSI) drift detector
 * OWNER: ML Team
 * RELATED: drizzle/schema-drift.ts, ml_backend/
 * LAST-AUDITED: 2025-01-18
 */

/**
 * Population Stability Index (PSI) Detector
 * 
 * PSI measures the shift in distribution between two datasets.
 * Formula: PSI = Σ (actual% - expected%) * ln(actual% / expected%)
 * 
 * Interpretation:
 * - PSI < 0.1: No significant change
 * - 0.1 ≤ PSI < 0.2: Moderate change
 * - PSI ≥ 0.2: Significant change (retraining recommended)
 */

export interface PSIResult {
  psi: number;
  severity: "none" | "low" | "medium" | "high";
  details: {
    bins: number;
    expectedDist: number[];
    actualDist: number[];
    psiPerBin: number[];
  };
}

/**
 * Calculate PSI between expected (baseline) and actual (current) distributions
 */
export function calculatePSI(
  expected: number[],
  actual: number[],
  nBins: number = 10
): PSIResult {
  if (expected.length === 0 || actual.length === 0) {
    throw new Error("Expected and actual arrays cannot be empty");
  }

  // Create bins based on expected distribution
  const { bins, expectedDist, actualDist } = createBins(expected, actual, nBins);

  // Calculate PSI for each bin
  const psiPerBin: number[] = [];
  let totalPSI = 0;

  for (let i = 0; i < nBins; i++) {
    const expPct = expectedDist[i];
    const actPct = actualDist[i];

    // Avoid division by zero and log(0)
    const expPctSafe = Math.max(expPct, 0.0001);
    const actPctSafe = Math.max(actPct, 0.0001);

    const psi = (actPctSafe - expPctSafe) * Math.log(actPctSafe / expPctSafe);
    psiPerBin.push(psi);
    totalPSI += psi;
  }

  // Determine severity
  const severity = getSeverity(totalPSI);

  return {
    psi: totalPSI,
    severity,
    details: {
      bins: nBins,
      expectedDist,
      actualDist,
      psiPerBin,
    },
  };
}

/**
 * Create bins and calculate distributions
 */
function createBins(
  expected: number[],
  actual: number[],
  nBins: number
): {
  bins: number[];
  expectedDist: number[];
  actualDist: number[];
} {
  // Find min and max across both datasets
  const allValues = [...expected, ...actual];
  const min = Math.min(...allValues);
  const max = Math.max(...allValues);

  // Create bin edges
  const binWidth = (max - min) / nBins;
  const bins: number[] = [];
  for (let i = 0; i <= nBins; i++) {
    bins.push(min + i * binWidth);
  }

  // Count values in each bin
  const expectedCounts = countInBins(expected, bins);
  const actualCounts = countInBins(actual, bins);

  // Convert to percentages
  const expectedDist = expectedCounts.map((count) => count / expected.length);
  const actualDist = actualCounts.map((count) => count / actual.length);

  return { bins, expectedDist, actualDist };
}

/**
 * Count values in each bin
 */
function countInBins(values: number[], bins: number[]): number[] {
  const counts = new Array(bins.length - 1).fill(0);

  for (const value of values) {
    for (let i = 0; i < bins.length - 1; i++) {
      if (value >= bins[i] && value < bins[i + 1]) {
        counts[i]++;
        break;
      }
      // Handle edge case for max value
      if (i === bins.length - 2 && value === bins[i + 1]) {
        counts[i]++;
        break;
      }
    }
  }

  return counts;
}

/**
 * Determine severity based on PSI value
 */
function getSeverity(psi: number): "none" | "low" | "medium" | "high" {
  if (psi < 0.1) {return "none";}
  if (psi < 0.2) {return "low";}
  if (psi < 0.3) {return "medium";}
  return "high";
}

/**
 * Calculate PSI for multiple features
 */
export function calculateMultiFeaturePSI(
  expectedData: Record<string, number[]>,
  actualData: Record<string, number[]>,
  nBins: number = 10
): Record<string, PSIResult> {
  const results: Record<string, PSIResult> = {};

  for (const feature in expectedData) {
    if (actualData[feature]) {
      results[feature] = calculatePSI(
        expectedData[feature],
        actualData[feature],
        nBins
      );
    }
  }

  return results;
}

