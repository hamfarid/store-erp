/**
 * Portfolio Management Backend Logic
 * Handles portfolio calculations and analytics
 */

import * as db from "./db";

export interface PortfolioSummary {
  portfolioId: number;
  totalValue: number;
  totalInvested: number;
  totalReturn: number;
  returnPercent: number;
  profitLoss: number;
  assetCount: number;
}

export interface AssetHolding {
  assetId: number;
  assetName: string;
  assetSymbol: string;
  quantity: number; // Parsed from decimal string for calculations
  averageBuyPrice: number;
  currentPrice: number;
  totalValue: number;
  totalInvested: number;
  profitLoss: number;
  returnPercent: number;
  percentageOfPortfolio: number;
}

export interface AssetBreakdown {
  holdings: AssetHolding[];
  totalValue: number;
}

/**
 * Get current price for an asset
 */
async function getCurrentPrice(assetId: number): Promise<number> {
  const latestPrice = await db.getLatestPrice(assetId);

  if (!latestPrice) {
    throw new Error(`No price data found for asset ${assetId}`);
  }

  return parseFloat(latestPrice.price);
}

/**
 * Calculate total invested amount (sum of buy transactions minus sell transactions)
 */
export async function calculateTotalInvested(
  portfolioId: number
): Promise<number> {
  const txs = await db.getTransactions(portfolioId);

  let totalInvested = 0;
  for (const tx of txs) {
    if (tx.transactionType === "buy") {
      totalInvested += parseFloat(tx.totalAmount);
    } else if (tx.transactionType === "sell") {
      totalInvested -= parseFloat(tx.totalAmount);
    }
  }

  return totalInvested;
}

/**
 * Get current holdings for a portfolio
 */
async function getCurrentHoldings(
  portfolioId: number
): Promise<Map<number, number>> {
  const txs = await db.getTransactions(portfolioId);

  const holdings = new Map<number, number>();

  for (const tx of txs) {
    const assetId = tx.assetId;
    const quantity = parseFloat(tx.quantity);
    const current = holdings.get(assetId) || 0;

    if (tx.transactionType === "buy") {
      holdings.set(assetId, current + quantity);
    } else if (tx.transactionType === "sell") {
      holdings.set(assetId, current - quantity);
    }
  }

  // Remove assets with zero or negative holdings
  for (const [assetId, quantity] of Array.from(holdings.entries())) {
    if (quantity <= 0) {
      holdings.delete(assetId);
    }
  }

  return holdings;
}

/**
 * Calculate current portfolio value
 */
export async function calculatePortfolioValue(
  portfolioId: number
): Promise<number> {
  const holdings = await getCurrentHoldings(portfolioId);
  let totalValue = 0;

  for (const [assetId, quantity] of Array.from(holdings.entries())) {
    try {
      const currentPrice = await getCurrentPrice(assetId);
      totalValue += quantity * currentPrice;
    } catch (error) {
      console.error(`Error getting price for asset ${assetId}:`, error);
      // Skip this asset if price is not available
    }
  }

  return totalValue;
}

/**
 * Calculate ROI percentage
 */
export async function calculateROI(portfolioId: number): Promise<number> {
  const totalInvested = await calculateTotalInvested(portfolioId);
  if (totalInvested === 0) {return 0;}

  const totalValue = await calculatePortfolioValue(portfolioId);
  const roi = ((totalValue - totalInvested) / totalInvested) * 100;

  return roi;
}

/**
 * Calculate profit/loss amount
 */
export async function calculateProfitLoss(
  portfolioId: number
): Promise<number> {
  const totalInvested = await calculateTotalInvested(portfolioId);
  const totalValue = await calculatePortfolioValue(portfolioId);

  return totalValue - totalInvested;
}

/**
 * Get portfolio summary with all metrics
 */
export async function getPortfolioSummary(
  portfolioId: number
): Promise<PortfolioSummary> {
  const totalValue = await calculatePortfolioValue(portfolioId);
  const totalInvested = await calculateTotalInvested(portfolioId);
  const profitLoss = totalValue - totalInvested;
  const returnPercent =
    totalInvested === 0 ? 0 : (profitLoss / totalInvested) * 100;
  const holdings = await getCurrentHoldings(portfolioId);

  return {
    portfolioId,
    totalValue,
    totalInvested,
    totalReturn: profitLoss,
    returnPercent,
    profitLoss,
    assetCount: holdings.size,
  };
}

/**
 * Get detailed asset breakdown for portfolio
 */
export async function getPortfolioBreakdown(
  portfolioId: number
): Promise<AssetBreakdown> {
  const holdings = await getCurrentHoldings(portfolioId);
  const assetHoldings: AssetHolding[] = [];
  let totalPortfolioValue = 0;

  for (const [assetId, quantity] of Array.from(holdings.entries())) {
    try {
      // Get asset info
      const assetInfo = await db.getAssetById(assetId);

      if (!assetInfo) {continue;}

      // Get current price
      const currentPrice = await getCurrentPrice(assetId);

      // Calculate average buy price for this asset
      const buyTxs = await db.getTransactionsByAsset(portfolioId, assetId);
      
      const buyTxsFiltered = buyTxs.filter((tx: any) => tx.transactionType === "buy");

      let totalQuantityBought = 0;
      let totalAmountPaid = 0;

      for (const tx of buyTxsFiltered) {
        const qty = parseFloat(tx.quantity);
        const price = parseFloat(tx.pricePerUnit);
        totalQuantityBought += qty;
        totalAmountPaid += qty * price;
      }

      const averageBuyPrice =
        totalQuantityBought > 0 ? totalAmountPaid / totalQuantityBought : 0;
      const totalValue = quantity * currentPrice;
      const totalInvested = quantity * averageBuyPrice;
      const profitLoss = totalValue - totalInvested;
      const returnPercent =
        totalInvested > 0 ? (profitLoss / totalInvested) * 100 : 0;

      totalPortfolioValue += totalValue;

      assetHoldings.push({
        assetId,
        assetName: assetInfo.name,
        assetSymbol: assetInfo.symbol,
        quantity,
        averageBuyPrice,
        currentPrice,
        totalValue,
        totalInvested,
        profitLoss,
        returnPercent,
        percentageOfPortfolio: 0, // Will calculate after we know total
      });
    } catch (error) {
      console.error(`Error processing asset ${assetId}:`, error);
    }
  }

  // Calculate percentage of portfolio for each asset
  for (const holding of assetHoldings) {
    holding.percentageOfPortfolio =
      totalPortfolioValue > 0
        ? (holding.totalValue / totalPortfolioValue) * 100
        : 0;
  }

  // Sort by value (descending)
  assetHoldings.sort((a, b) => b.totalValue - a.totalValue);

  return {
    holdings: assetHoldings,
    totalValue: totalPortfolioValue,
  };
}

/**
 * Get performance for a specific asset in the portfolio
 */
export async function getAssetPerformance(
  portfolioId: number,
  assetId: number
): Promise<AssetHolding | null> {
  const breakdown = await getPortfolioBreakdown(portfolioId);
  const holding = breakdown.holdings.find(h => h.assetId === assetId);
  return holding || null;
}

/**
 * Create a portfolio snapshot (for historical tracking)
 */
export async function createPortfolioSnapshot(
  portfolioId: number
): Promise<void> {
  const summary = await getPortfolioSummary(portfolioId);
  const breakdown = await getPortfolioBreakdown(portfolioId);

  // Build asset breakdown JSON
  const assetBreakdownJson: Record<string, any> = {};
  for (const holding of breakdown.holdings) {
    assetBreakdownJson[holding.assetId] = {
      quantity: holding.quantity,
      value: holding.totalValue,
      percentage: holding.percentageOfPortfolio,
    };
  }

  await db.createPortfolioSnapshot({
    portfolioId,
    snapshotDate: Date.now(),
    totalValue: summary.totalValue.toFixed(2),
    totalInvested: summary.totalInvested.toFixed(2),
    totalReturn: summary.totalReturn.toFixed(2),
    returnPercent: summary.returnPercent.toFixed(4),
    assetBreakdown: JSON.stringify(assetBreakdownJson),
  });
}


