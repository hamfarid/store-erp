/**
 * Swagger API Documentation
 * OpenAPI 3.0 specification for Asset Predictor API
 */

import swaggerJsdoc from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";
import { Express } from "express";

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Asset Predictor API",
      version: "1.0.0",
      description: `
# Asset Predictor API Documentation

نظام شامل لتوقع أسعار الأصول وإدارة المحافظ الاستثمارية.

## الميزات الرئيسية

- **إدارة المحافظ**: إضافة وتعديل وحذف الأصول في المحفظة
- **التنبيهات الذكية**: تنبيهات تلقائية عند الوصول للأسعار المستهدفة
- **التوقعات**: توقعات أسعار باستخدام ML
- **التقارير**: تقارير PDF/Excel شاملة
- **الذكاء الاصطناعي**: توصيات ذكية وتحليل المشاعر
- **إدارة المخاطر**: تقييم المخاطر وتوصيات الحماية

## المصادقة

يستخدم النظام OAuth 2.0 مع Manus Auth. جميع endpoints المحمية تتطلب JWT token في header:

\`\`\`
Authorization: Bearer <your-jwt-token>
\`\`\`

## معدلات الاستخدام

- **المستخدم المجاني**: 10 طلبات/دقيقة
- **المستخدم المدفوع**: غير محدود

## الأخطاء

يستخدم API رموز HTTP القياسية:

- \`200\`: نجاح
- \`400\`: خطأ في الطلب
- \`401\`: غير مصرح
- \`403\`: ممنوع
- \`404\`: غير موجود
- \`500\`: خطأ في الخادم
      `,
      contact: {
        name: "API Support",
        email: "support@assetpredictor.com",
      },
      license: {
        name: "MIT",
        url: "https://opensource.org/licenses/MIT",
      },
    },
    servers: [
      {
        url: "http://localhost:3000",
        description: "Development server",
      },
      {
        url: "https://api.assetpredictor.com",
        description: "Production server",
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
          description: "JWT token from Manus OAuth",
        },
      },
      schemas: {
        User: {
          type: "object",
          properties: {
            id: { type: "string", description: "User ID" },
            name: { type: "string", description: "User name" },
            email: {
              type: "string",
              format: "email",
              description: "User email",
            },
            role: {
              type: "string",
              enum: ["user", "admin"],
              description: "User role",
            },
            createdAt: { type: "string", format: "date-time" },
          },
        },
        Asset: {
          type: "object",
          properties: {
            id: { type: "integer" },
            symbol: {
              type: "string",
              description: "Asset symbol (e.g., BTC, ETH)",
            },
            name: { type: "string", description: "Asset name" },
            currentPrice: { type: "number", format: "double" },
            marketCap: { type: "number", format: "double" },
            volatility: { type: "number", format: "double" },
            updatedAt: { type: "string", format: "date-time" },
          },
        },
        Portfolio: {
          type: "object",
          properties: {
            id: { type: "integer" },
            userId: { type: "string" },
            assetId: { type: "integer" },
            quantity: { type: "number" },
            purchasePrice: { type: "number" },
            currentValue: { type: "number" },
            profit: { type: "number" },
            profitPercent: { type: "number" },
          },
        },
        Alert: {
          type: "object",
          properties: {
            id: { type: "integer" },
            userId: { type: "string" },
            assetId: { type: "integer" },
            targetPrice: { type: "number" },
            condition: { type: "string", enum: ["above", "below"] },
            status: {
              type: "string",
              enum: ["active", "triggered", "expired"],
            },
            createdAt: { type: "string", format: "date-time" },
          },
        },
        Prediction: {
          type: "object",
          properties: {
            id: { type: "integer" },
            assetId: { type: "integer" },
            predictedPrice: { type: "number" },
            confidence: { type: "number" },
            horizon: { type: "integer", description: "Days ahead" },
            model: { type: "string" },
            createdAt: { type: "string", format: "date-time" },
          },
        },
        Notification: {
          type: "object",
          properties: {
            id: { type: "integer" },
            userId: { type: "string" },
            type: {
              type: "string",
              enum: ["push", "email", "telegram", "in_app"],
            },
            title: { type: "string" },
            message: { type: "string" },
            status: {
              type: "string",
              enum: ["pending", "sent", "read", "failed"],
            },
            createdAt: { type: "string", format: "date-time" },
          },
        },
        Report: {
          type: "object",
          properties: {
            type: {
              type: "string",
              enum: ["portfolio", "price_analysis", "predictions", "alerts"],
            },
            format: { type: "string", enum: ["pdf", "excel", "csv"] },
            downloadUrl: { type: "string" },
            generatedAt: { type: "string", format: "date-time" },
          },
        },
        AIRecommendation: {
          type: "object",
          properties: {
            id: { type: "integer" },
            type: {
              type: "string",
              enum: ["buy", "sell", "hold", "diversify", "reduce_risk"],
            },
            assetId: { type: "integer" },
            title: { type: "string" },
            description: { type: "string" },
            reasoning: { type: "array", items: { type: "string" } },
            confidence: { type: "number" },
            riskLevel: { type: "string", enum: ["low", "medium", "high"] },
            priority: {
              type: "string",
              enum: ["low", "medium", "high", "urgent"],
            },
          },
        },
        SentimentAnalysis: {
          type: "object",
          properties: {
            sentiment: {
              type: "string",
              enum: [
                "very_negative",
                "negative",
                "neutral",
                "positive",
                "very_positive",
              ],
            },
            score: { type: "number", minimum: -1, maximum: 1 },
            confidence: { type: "number", minimum: 0, maximum: 1 },
            keywords: { type: "array", items: { type: "string" } },
            entities: { type: "array", items: { type: "string" } },
            summary: { type: "string" },
            impact: { type: "string", enum: ["high", "medium", "low"] },
          },
        },
        RiskProfile: {
          type: "object",
          properties: {
            riskScore: { type: "number" },
            riskLevel: {
              type: "string",
              enum: ["low", "medium", "high", "critical"],
            },
            volatility: { type: "number" },
            recommendations: { type: "array", items: { type: "string" } },
          },
        },
        KPIMetrics: {
          type: "object",
          properties: {
            totalValue: { type: "number" },
            totalInvested: { type: "number" },
            totalProfit: { type: "number" },
            totalLoss: { type: "number" },
            roi: { type: "number", description: "Return on Investment %" },
            winRate: { type: "number", description: "Win rate %" },
            avgProfit: { type: "number" },
            avgLoss: { type: "number" },
            profitFactor: { type: "number" },
          },
        },
        Error: {
          type: "object",
          properties: {
            error: { type: "string" },
            message: { type: "string" },
            code: { type: "string" },
          },
        },
      },
    },
    security: [
      {
        bearerAuth: [],
      },
    ],
    tags: [
      { name: "Auth", description: "Authentication endpoints" },
      { name: "Assets", description: "Asset management" },
      { name: "Portfolio", description: "Portfolio management" },
      { name: "Alerts", description: "Price alerts" },
      { name: "Predictions", description: "Price predictions" },
      { name: "Notifications", description: "Notifications system" },
      { name: "Reports", description: "Report generation" },
      { name: "AI", description: "AI recommendations and analysis" },
      { name: "Risk", description: "Risk management" },
      { name: "KPIs", description: "Key Performance Indicators" },
      { name: "Activity", description: "Activity tracking" },
    ],
  },
  apis: ["./server/routers/**/*.ts", "./server/swagger-docs.ts"],
};

const swaggerSpec = swaggerJsdoc(options);

export function setupSwagger(app: Express) {
  // Swagger UI
  app.use(
    "/api-docs",
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec, {
      customCss: ".swagger-ui .topbar { display: none }",
      customSiteTitle: "Asset Predictor API Docs",
    })
  );

  // OpenAPI JSON
  app.get("/api-docs.json", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.send(swaggerSpec);
  });

  console.log("[Swagger] API documentation available at /api-docs");
}

export { swaggerSpec };
