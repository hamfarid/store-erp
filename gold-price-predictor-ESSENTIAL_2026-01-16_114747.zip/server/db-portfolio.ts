/**
 * Portfolio Database CRUD Operations
 * specific implementation delegates to db-compat
 */

import * as db from "./db-compat";
// Import interfaces for type safety, though we might pass them as any to db-compat if needed
// or strict typing if db-compat supports it.
import {
  InsertPortfolio,
  InsertTransaction,
} from "../drizzle/schema";

/**
 * Create a new portfolio
 */
export async function createPortfolio(data: InsertPortfolio) {
  return await db.createPortfolio(data);
}

/**
 * Get user's portfolios
 */
export async function getUserPortfolios(userId: string) {
  return await db.getUserPortfolios(userId);
}

/**
 * Get single portfolio by ID
 */
export async function getPortfolio(portfolioId: number, userId: string) {
  return await db.getPortfolio(portfolioId, userId);
}

/**
 * Update portfolio
 */
export async function updatePortfolio(
  portfolioId: number,
  userId: string,
  data: Partial<InsertPortfolio>
) {
  return await db.updatePortfolio(portfolioId, userId, data);
}

/**
 * Delete portfolio
 */
export async function deletePortfolio(portfolioId: number, userId: string) {
  return await db.deletePortfolio(portfolioId, userId);
}

/**
 * Add transaction to portfolio
 */
export async function addTransaction(data: InsertTransaction) {
  return await db.addTransaction(data);
}

/**
 * Get transactions for a portfolio
 */
export async function getTransactions(
  portfolioId: number,
  userId: string,
  filters?: {
    assetId?: number;
    transactionType?: "buy" | "sell";
    startDate?: Date;
    endDate?: Date;
  }
) {
  return await db.getTransactions(portfolioId, userId, filters);
}

/**
 * Get single transaction
 */
export async function getTransaction(transactionId: number, userId: string) {
  return await db.getTransaction(transactionId, userId);
}

/**
 * Update transaction
 */
export async function updateTransaction(
  transactionId: number,
  userId: string,
  data: Partial<InsertTransaction>
) {
  return await db.updateTransaction(transactionId, userId, data);
}

/**
 * Delete transaction
 */
export async function deleteTransaction(transactionId: number, userId: string) {
  return await db.deleteTransaction(transactionId, userId);
}

/**
 * Get portfolio snapshots (historical performance)
 */
export async function getPortfolioSnapshots(
  portfolioId: number,
  startDate?: Date,
  endDate?: Date
) {
  return await db.getPortfolioSnapshots(portfolioId, startDate, endDate);
}
