/**
 * PDF and Excel Report Generation Utilities
 * Generates professional reports in PDF and Excel formats
 */

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ExcelJS from 'exceljs';

// Arabic font support for jsPDF (using built-in fonts for now)
// For full Arabic support, you would need to add custom fonts

/**
 * Generate Portfolio PDF Report
 */
export async function generatePortfolioPDFReport(data: {
  userName: string;
  period: string;
  totalValue: number;
  totalInvested: number;
  totalProfit: number;
  roi: number;
  assets: Array<{
    name: string;
    symbol: string;
    quantity: number;
    price: number;
    value: number;
    profit: number;
    profitPercent: number;
  }>;
}): Promise<Buffer> {
  const doc = new jsPDF();
  
  // Title
  doc.setFontSize(20);
  doc.text('Portfolio Report', 105, 20, { align: 'center' });
  
  // User info
  doc.setFontSize(12);
  doc.text(`User: ${data.userName}`, 20, 35);
  doc.text(`Period: ${data.period}`, 20, 42);
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 49);
  
  // Summary section
  doc.setFontSize(14);
  doc.text('Summary', 20, 65);
  
  doc.setFontSize(11);
  doc.text(`Total Value: $${data.totalValue.toFixed(2)}`, 20, 75);
  doc.text(`Total Invested: $${data.totalInvested.toFixed(2)}`, 20, 82);
  doc.text(`Total Profit: $${data.totalProfit.toFixed(2)}`, 20, 89);
  doc.text(`ROI: ${data.roi.toFixed(2)}%`, 20, 96);
  
  // Assets table
  doc.setFontSize(14);
  doc.text('Assets', 20, 115);
  
  autoTable(doc, {
    startY: 120,
    head: [['Asset', 'Symbol', 'Qty', 'Price', 'Value', 'Profit', 'Profit %']],
    body: data.assets.map(asset => [
      asset.name,
      asset.symbol,
      asset.quantity.toString(),
      `$${asset.price.toFixed(2)}`,
      `$${asset.value.toFixed(2)}`,
      `$${asset.profit.toFixed(2)}`,
      `${asset.profitPercent.toFixed(2)}%`
    ]),
    theme: 'striped',
    headStyles: { fillColor: [41, 128, 185] },
    styles: { fontSize: 10 },
  });
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.text(
      `Page ${i} of ${pageCount}`,
      doc.internal.pageSize.getWidth() / 2,
      doc.internal.pageSize.getHeight() - 10,
      { align: 'center' }
    );
  }
  
  return Buffer.from(doc.output('arraybuffer'));
}

/**
 * Generate Price Analysis PDF Report
 */
export async function generatePriceAnalysisPDFReport(data: {
  assetName: string;
  symbol: string;
  period: string;
  currentPrice: number;
  minPrice: number;
  maxPrice: number;
  avgPrice: number;
  volatility: number;
  priceHistory: Array<{
    date: string;
    price: number;
    change: number;
  }>;
}): Promise<Buffer> {
  const doc = new jsPDF();
  
  // Title
  doc.setFontSize(20);
  doc.text('Price Analysis Report', 105, 20, { align: 'center' });
  
  // Asset info
  doc.setFontSize(12);
  doc.text(`Asset: ${data.assetName} (${data.symbol})`, 20, 35);
  doc.text(`Period: ${data.period}`, 20, 42);
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 49);
  
  // Statistics
  doc.setFontSize(14);
  doc.text('Statistics', 20, 65);
  
  doc.setFontSize(11);
  doc.text(`Current Price: $${data.currentPrice.toFixed(2)}`, 20, 75);
  doc.text(`Min Price: $${data.minPrice.toFixed(2)}`, 20, 82);
  doc.text(`Max Price: $${data.maxPrice.toFixed(2)}`, 20, 89);
  doc.text(`Avg Price: $${data.avgPrice.toFixed(2)}`, 20, 96);
  doc.text(`Volatility: ${data.volatility.toFixed(2)}%`, 20, 103);
  
  // Price history table
  doc.setFontSize(14);
  doc.text('Price History', 20, 120);
  
  autoTable(doc, {
    startY: 125,
    head: [['Date', 'Price', 'Change']],
    body: data.priceHistory.map(item => [
      item.date,
      `$${item.price.toFixed(2)}`,
      `${item.change >= 0 ? '+' : ''}${item.change.toFixed(2)}%`
    ]),
    theme: 'striped',
    headStyles: { fillColor: [41, 128, 185] },
    styles: { fontSize: 10 },
  });
  
  return Buffer.from(doc.output('arraybuffer'));
}

/**
 * Generate Portfolio Excel Report
 */
export async function generatePortfolioExcelReport(data: {
  userName: string;
  period: string;
  totalValue: number;
  totalInvested: number;
  totalProfit: number;
  roi: number;
  assets: Array<{
    name: string;
    symbol: string;
    quantity: number;
    price: number;
    value: number;
    profit: number;
    profitPercent: number;
  }>;
}): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Portfolio Report');
  
  // Set column widths
  worksheet.columns = [
    { width: 20 },
    { width: 12 },
    { width: 12 },
    { width: 12 },
    { width: 12 },
    { width: 12 },
    { width: 12 },
  ];
  
  // Title
  worksheet.mergeCells('A1:G1');
  const titleCell = worksheet.getCell('A1');
  titleCell.value = 'Portfolio Report';
  titleCell.font = { size: 18, bold: true };
  titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
  
  // User info
  worksheet.getCell('A3').value = 'User:';
  worksheet.getCell('B3').value = data.userName;
  worksheet.getCell('A4').value = 'Period:';
  worksheet.getCell('B4').value = data.period;
  worksheet.getCell('A5').value = 'Generated:';
  worksheet.getCell('B5').value = new Date().toLocaleDateString();
  
  // Summary section
  worksheet.getCell('A7').value = 'Summary';
  worksheet.getCell('A7').font = { size: 14, bold: true };
  
  worksheet.getCell('A8').value = 'Total Value:';
  worksheet.getCell('B8').value = data.totalValue;
  worksheet.getCell('B8').numFmt = '$#,##0.00';
  
  worksheet.getCell('A9').value = 'Total Invested:';
  worksheet.getCell('B9').value = data.totalInvested;
  worksheet.getCell('B9').numFmt = '$#,##0.00';
  
  worksheet.getCell('A10').value = 'Total Profit:';
  worksheet.getCell('B10').value = data.totalProfit;
  worksheet.getCell('B10').numFmt = '$#,##0.00';
  
  worksheet.getCell('A11').value = 'ROI:';
  worksheet.getCell('B11').value = data.roi / 100;
  worksheet.getCell('B11').numFmt = '0.00%';
  
  // Assets table
  worksheet.getCell('A13').value = 'Assets';
  worksheet.getCell('A13').font = { size: 14, bold: true };
  
  // Headers
  const headerRow = worksheet.getRow(14);
  headerRow.values = ['Asset', 'Symbol', 'Quantity', 'Price', 'Value', 'Profit', 'Profit %'];
  headerRow.font = { bold: true };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF2980B9' }
  };
  headerRow.font = { color: { argb: 'FFFFFFFF' }, bold: true };
  
  // Data rows
  data.assets.forEach((asset, index) => {
    const row = worksheet.getRow(15 + index);
    row.values = [
      asset.name,
      asset.symbol,
      asset.quantity,
      asset.price,
      asset.value,
      asset.profit,
      asset.profitPercent / 100
    ];
    
    // Format numbers
    row.getCell(4).numFmt = '$#,##0.00'; // Price
    row.getCell(5).numFmt = '$#,##0.00'; // Value
    row.getCell(6).numFmt = '$#,##0.00'; // Profit
    row.getCell(7).numFmt = '0.00%'; // Profit %
  });
  
  // Add borders to table
  const tableRange = `A14:G${14 + data.assets.length}`;
  worksheet.getCell(tableRange).border = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
  };
  
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

/**
 * Generate Price Analysis Excel Report
 */
export async function generatePriceAnalysisExcelReport(data: {
  assetName: string;
  symbol: string;
  period: string;
  currentPrice: number;
  minPrice: number;
  maxPrice: number;
  avgPrice: number;
  volatility: number;
  priceHistory: Array<{
    date: string;
    price: number;
    change: number;
  }>;
}): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Price Analysis');
  
  // Set column widths
  worksheet.columns = [
    { width: 20 },
    { width: 15 },
    { width: 15 },
  ];
  
  // Title
  worksheet.mergeCells('A1:C1');
  const titleCell = worksheet.getCell('A1');
  titleCell.value = 'Price Analysis Report';
  titleCell.font = { size: 18, bold: true };
  titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
  
  // Asset info
  worksheet.getCell('A3').value = 'Asset:';
  worksheet.getCell('B3').value = `${data.assetName} (${data.symbol})`;
  worksheet.getCell('A4').value = 'Period:';
  worksheet.getCell('B4').value = data.period;
  worksheet.getCell('A5').value = 'Generated:';
  worksheet.getCell('B5').value = new Date().toLocaleDateString();
  
  // Statistics
  worksheet.getCell('A7').value = 'Statistics';
  worksheet.getCell('A7').font = { size: 14, bold: true };
  
  worksheet.getCell('A8').value = 'Current Price:';
  worksheet.getCell('B8').value = data.currentPrice;
  worksheet.getCell('B8').numFmt = '$#,##0.00';
  
  worksheet.getCell('A9').value = 'Min Price:';
  worksheet.getCell('B9').value = data.minPrice;
  worksheet.getCell('B9').numFmt = '$#,##0.00';
  
  worksheet.getCell('A10').value = 'Max Price:';
  worksheet.getCell('B10').value = data.maxPrice;
  worksheet.getCell('B10').numFmt = '$#,##0.00';
  
  worksheet.getCell('A11').value = 'Avg Price:';
  worksheet.getCell('B11').value = data.avgPrice;
  worksheet.getCell('B11').numFmt = '$#,##0.00';
  
  worksheet.getCell('A12').value = 'Volatility:';
  worksheet.getCell('B12').value = data.volatility / 100;
  worksheet.getCell('B12').numFmt = '0.00%';
  
  // Price history table
  worksheet.getCell('A14').value = 'Price History';
  worksheet.getCell('A14').font = { size: 14, bold: true };
  
  // Headers
  const headerRow = worksheet.getRow(15);
  headerRow.values = ['Date', 'Price', 'Change'];
  headerRow.font = { bold: true };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF2980B9' }
  };
  headerRow.font = { color: { argb: 'FFFFFFFF' }, bold: true };
  
  // Data rows
  data.priceHistory.forEach((item, index) => {
    const row = worksheet.getRow(16 + index);
    row.values = [
      item.date,
      item.price,
      item.change / 100
    ];
    
    row.getCell(2).numFmt = '$#,##0.00'; // Price
    row.getCell(3).numFmt = '0.00%'; // Change
  });
  
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

/**
 * Generate CSV Report (simple format)
 */
export function generateCSVReport(data: {
  headers: string[];
  rows: string[][];
}): string {
  const csvLines = [
    data.headers.join(','),
    ...data.rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ];
  
  return csvLines.join('\n');
}

