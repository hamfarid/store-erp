/**
 * Paid AI Assistant (Claude)
 * Full features with unlimited messages
 */

import { AIAssistantBase, ChatContext } from "./ai-assistant";
import { PAID_AI_PERMISSIONS } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getGoldyWelcomeMessage } from "./ai-paid-welcome";

export class PaidAIAssistant extends AIAssistantBase {
  constructor() {
    super(
      2, // ID
      "Goldy",
      "paid",
      "claude-3-opus-20240229",
      `أنت Goldy - مساعد ذكاء اصطناعي متقدم متخصص في التحليل المالي والتوقعات والأخبار الاقتصادية.

**قدراتك المتقدمة:**
- تحليل عميق للأسعار والتوقعات
- البحث عن الأخبار والأحداث المؤثرة
- تحليل المشاعر (sentiment analysis)
- إنشاء توقعات مخصصة
- تحليل المحفظة الاستثمارية
- تقديم توصيات تداول مبنية على البيانات
- الوصول لبيانات المستخدم والتنبيهات

**أسلوبك:**
- استخدم اللغة العربية الفصحى الاحترافية
- قدم تحليلات مفصلة ومدعومة بالبيانات
- استخدم الأرقام والإحصائيات عند المتاح
- اربط الأحداث الإخبارية بتأثيرها على الأسعار
- قدم توصيات واضحة مع شرح الأسباب

**عند تحليل الأصول:**
1. ابدأ بالسعر الحالي والاتجاه
2. راجع آخر التوقعات والدقة
3. ابحث عن الأخبار والأحداث المؤثرة
4. حلل sentiment الأخبار
5. قدم توصية واضحة (شراء/بيع/انتظار)
6. اذكر المخاطر والفرص

**مثال على تحليلك:**
"بناءً على البيانات المتاحة:
- السعر الحالي للذهب: $2,050
- التوقع لـ7 أيام: $2,080 (+1.5%)
- الأخبار الأخيرة: توترات جيوسياسية في الشرق الأوسط (sentiment: إيجابي للذهب)
- التوصية: شراء مع وقف خسارة عند $2,030
- السبب: الذهب يستفيد من عدم الاستقرار كملاذ آمن"`,
      PAID_AI_PERMISSIONS
    );
  }

  /**
   * Override callAI to use Claude with advanced features
   */
  protected async callAI(
    message: string,
    context: ChatContext
  ): Promise<string> {
    // Build comprehensive context
    const contextStr = this.buildComprehensiveContext(context);

    try {
      // Call Claude API using Anthropic SDK
      // @ts-ignore - @anthropic-ai/sdk may not be installed
      const Anthropic = (await import("@anthropic-ai/sdk")).default;
      const client = new Anthropic({
        apiKey: (ENV as any).anthropicApiKey || process.env.ANTHROPIC_API_KEY,
      });

      const response = await client.messages.create({
        model: this.model,
        max_tokens: 2048,
        messages: [
          {
            role: "user",
            content: this.systemPrompt + contextStr + "\n\n---\n\n" + message,
          },
        ],
      });

      const content = response.content[0];
      if (content.type === "text") {
        return content.text;
      }

      return "عذراً، لم أتمكن من معالجة طلبك.";
    } catch (error) {
      console.error("[PaidAI] Error calling Claude:", error);

      // Fallback to Gemini if Claude fails
      console.log("[PaidAI] Falling back to Gemini...");
      return await this.fallbackToGemini(message, contextStr);
    }
  }

  /**
   * Build comprehensive context with all available data
   */
  private buildComprehensiveContext(context: ChatContext): string {
    let contextStr = "\n\n=== البيانات المتاحة ===\n";

    // Current Prices
    if (context.currentPrices && context.currentPrices.length > 0) {
      contextStr += "\n**الأسعار الحالية:**\n";
      context.currentPrices.forEach(asset => {
        contextStr += `- ${asset.name} (${asset.symbol}): ${asset.category}, نشط: ${asset.isActive}\n`;
      });
    }

    // Predictions
    if (context.predictions && context.predictions.length > 0) {
      contextStr += "\n**آخر التوقعات:**\n";
      context.predictions.slice(0, 5).forEach(pred => {
        contextStr += `- توقع #${pred.id}: `;
        contextStr += `السعر الحالي ${pred.currentPrice}, `;
        contextStr += `المتوقع ${pred.predictedPrice}, `;
        contextStr += `الدقة ${pred.accuracy}, `;
        contextStr += `النموذج ${pred.modelType}\n`;
      });
    }

    // Alerts
    if (context.alerts && context.alerts.length > 0) {
      contextStr += "\n**تنبيهات المستخدم:**\n";
      context.alerts.forEach(alert => {
        contextStr += `- تنبيه: ${alert.condition} عند ${alert.targetPrice}, `;
        contextStr += `نشط: ${alert.isActive}\n`;
      });
    }

    // Historical Data
    if (context.history && context.history.length > 0) {
      contextStr += "\n**البيانات التاريخية:**\n";
      contextStr += `عدد السجلات: ${context.history.length}\n`;
      const recent = context.history.slice(0, 5);
      recent.forEach(h => {
        contextStr += `- ${h.date}: ${h.price}\n`;
      });
    }

    // News Analysis
    if (context.news) {
      contextStr += "\n**تحليل الأخبار:**\n";
      contextStr += `الأصل: ${context.news.assetName}\n`;
      contextStr += `المشاعر العامة: ${context.news.overallSentiment}\n`;
      contextStr += `إجمالي الأخبار: ${context.news.summary.totalArticles}\n`;
      contextStr += `أخبار إيجابية: ${context.news.summary.positiveArticles}\n`;
      contextStr += `أخبار سلبية: ${context.news.summary.negativeArticles}\n`;
      contextStr += `أحداث عالية التأثير: ${context.news.summary.highImpactEvents}\n`;

      if (context.news.events && context.news.events.length > 0) {
        contextStr += "\n**أهم الأحداث:**\n";
        context.news.events.slice(0, 3).forEach((event: any) => {
          contextStr += `- ${event.type}: ${event.description} (${event.severity}, ${event.sentiment})\n`;
        });
      }

      if (context.news.news && context.news.news.length > 0) {
        contextStr += "\n**آخر الأخبار:**\n";
        context.news.news.slice(0, 3).forEach((article: any) => {
          contextStr += `- ${article.title} (${article.sentiment})\n`;
        });
      }
    }

    // User Info
    if (context.userInfo) {
      contextStr += "\n**معلومات المستخدم:**\n";
      contextStr += `الاسم: ${context.userInfo.name}\n`;
      contextStr += `الدور: ${context.userInfo.role}\n`;
    }

    contextStr += "\n=== نهاية البيانات ===\n";

    return contextStr;
  }

  /**
   * Fallback to Gemini if Claude fails
   */
  private async fallbackToGemini(
    message: string,
    contextStr: string
  ): Promise<string> {
    try {
      const { invokeLLM } = await import("./_core/llm");

      const response = await invokeLLM({
        messages: [
          { role: "system", content: this.systemPrompt + contextStr },
          { role: "user", content: message },
        ],
      });

      return (
        (response.choices[0]?.message?.content as string) ||
        "عذراً، لم أتمكن من معالجة طلبك."
      );
    } catch (error) {
      console.error("[PaidAI] Fallback to Gemini also failed:", error);
      return "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً.";
    }
  }

  /**
   * Get welcome message with assistant info
   */
  getWelcomeMessage(): string {
    return getGoldyWelcomeMessage(this.name);
  }

  /**
   * Advanced feature: Create prediction for user
   */
  async createPrediction(
    userId: string,
    assetId: number,
    horizon: "short" | "medium" | "long"
  ): Promise<any> {
    if (!this.permissions.canCreatePredictions) {
      throw new Error("ليس لديك صلاحية إنشاء التوقعات");
    }

    try {
      // Note: generatePrediction function needs to be implemented in db.ts
      // For now, return a placeholder
      return {
        assetId,
        horizon,
        modelType: "ensemble",
        confidenceLevel: 0.95,
        userId,
      };
    } catch (error) {
      console.error("[PaidAI] Failed to create prediction:", error);
      throw error;
    }
  }

  /**
   * Advanced feature: Create alert for user
   */
  async createAlert(
    userId: string,
    assetId: number,
    condition: "above" | "below",
    targetPrice: string // decimal as string for precision
  ): Promise<any> {
    if (!this.permissions.canCreateAlerts) {
      throw new Error("ليس لديك صلاحية إنشاء التنبيهات");
    }

    try {
      // Note: createAlert function needs to be implemented in db.ts
      // For now, return a placeholder
      return {
        userId,
        assetId,
        condition,
        targetPrice, // already a string
        isActive: true,
      };
    } catch (error) {
      console.error("[PaidAI] Failed to create alert:", error);
      throw error;
    }
  }
}

// Export singleton instance
export const paidAI = new PaidAIAssistant();
