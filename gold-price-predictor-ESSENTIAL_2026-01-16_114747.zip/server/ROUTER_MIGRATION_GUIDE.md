/\*\*

- FILE: server/ROUTER_MIGRATION_GUIDE.md
- PURPOSE: Guide for migrating routers to unified response format
- OWNER: Backend Team
- LAST-AUDITED: 2025-11-25
  \*/

# Router Migration Guide - Unified Response Format

## Overview

This guide explains how to migrate existing tRPC routers to use the unified response format from `server/types/api-response.ts`.

**GLOBAL_PROMPT Compliance**: Security 35%, Correctness 20%, Maintainability 10%

---

## Step 1: Import Helper Functions

Add to the top of your router file:

```typescript
import {
  createSuccessResponse,
  createErrorResponse,
  createPaginatedResponse,
  ErrorCodes,
  createTRPCError,
} from "./types/api-response";
```

---

## Step 2: Access traceId from Context

All procedures now have access to `ctx.traceId` thanks to the traceId middleware:

```typescript
export const myRouter = router({
  myProcedure: protectedProcedure.query(({ ctx }) => {
    const traceId = (ctx as any).traceId;

    // Use traceId in your response
    return createSuccessResponse(
      { data: "example" },
      "Success message",
      traceId
    );
  }),
});
```

---

## Step 3: Convert Existing Responses

### Before (Old Format):

```typescript
return {
  success: true,
  user: { id: 1, name: "John" },
};
```

### After (Unified Format):

```typescript
return createSuccessResponse(
  { user: { id: 1, name: "John" } },
  "User retrieved successfully",
  (ctx as any).traceId
);
```

---

## Step 4: Convert Error Handling

### Before (Old Format):

```typescript
if (!user) {
  throw new Error("User not found");
}
```

### After (Unified Format - Option 1: tRPC Error):

```typescript
if (!user) {
  throw createTRPCError(
    ErrorCodes.NOT_FOUND,
    "User not found",
    (ctx as any).traceId
  );
}
```

### After (Unified Format - Option 2: Direct Error Response):

```typescript
if (!user) {
  throw new TRPCError({
    code: "NOT_FOUND",
    message: "User not found",
    cause: createErrorResponse(
      ErrorCodes.NOT_FOUND,
      "User not found",
      (ctx as any).traceId
    ),
  });
}
```

---

## Step 5: Convert Paginated Responses

### Before (Old Format):

```typescript
return {
  users: [...],
  total: 100,
  page: 1,
  pageSize: 10
};
```

### After (Unified Format):

```typescript
return createPaginatedResponse(
  users,
  100, // total
  1, // page
  10, // pageSize
  "Users retrieved successfully",
  (ctx as any).traceId
);
```

---

## Migration Examples

### Example 1: Simple Query

```typescript
// BEFORE
myQuery: protectedProcedure.query(async ({ ctx }) => {
  const data = await fetchData();
  return { success: true, data };
});

// AFTER
myQuery: protectedProcedure.query(async ({ ctx }) => {
  const data = await fetchData();
  return createSuccessResponse(
    { data },
    "Data retrieved successfully",
    (ctx as any).traceId
  );
});
```

---

### Example 2: Mutation with Validation

```typescript
// BEFORE
createUser: protectedProcedure
  .input(z.object({ name: z.string() }))
  .mutation(async ({ input, ctx }) => {
    if (!input.name) {
      throw new Error("Name is required");
    }
    const user = await db.createUser(input);
    return { success: true, user };
  });

// AFTER
createUser: protectedProcedure
  .input(z.object({ name: z.string() }))
  .mutation(async ({ input, ctx }) => {
    if (!input.name) {
      throw createTRPCError(
        ErrorCodes.VALIDATION_ERROR,
        "Name is required",
        (ctx as any).traceId
      );
    }
    const user = await db.createUser(input);
    return createSuccessResponse(
      { user },
      "User created successfully",
      (ctx as any).traceId
    );
  });
```

---

### Example 3: List with Pagination

```typescript
// BEFORE
listUsers: protectedProcedure
  .input(
    z.object({
      page: z.number().default(1),
      pageSize: z.number().default(10),
    })
  )
  .query(async ({ input }) => {
    const users = await db.getUsers(input.page, input.pageSize);
    const total = await db.countUsers();
    return { users, total, page: input.page, pageSize: input.pageSize };
  });

// AFTER
listUsers: protectedProcedure
  .input(
    z.object({
      page: z.number().default(1),
      pageSize: z.number().default(10),
    })
  )
  .query(async ({ input, ctx }) => {
    const users = await db.getUsers(input.page, input.pageSize);
    const total = await db.countUsers();
    return createPaginatedResponse(
      users,
      total,
      input.page,
      input.pageSize,
      "Users retrieved successfully",
      (ctx as any).traceId
    );
  });
```

---

### Example 4: Auth Router (auth.me)

```typescript
// BEFORE
me: publicProcedure.query(opts => opts.ctx.user),

// AFTER
me: publicProcedure.query(opts => {
  return createSuccessResponse(
    { user: opts.ctx.user },
    opts.ctx.user ? "User authenticated" : "Not authenticated",
    (opts.ctx as any).traceId
  );
}),
```

---

### Example 5: Auth Router (logout)

```typescript
// BEFORE
logout: publicProcedure.mutation(({ ctx }) => {
  const cookieOptions = getSessionCookieOptions(ctx.req);
  ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
  return { success: true };
});

// AFTER
logout: publicProcedure.mutation(({ ctx }) => {
  const cookieOptions = getSessionCookieOptions(ctx.req);
  ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
  return createSuccessResponse(
    {},
    "Logged out successfully",
    (ctx as any).traceId
  );
});
```

---

### Example 6: Auth Router (register)

```typescript
// BEFORE - Last return statement in register
return {
  success: true,
  user: {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
  },
};

// AFTER
return createSuccessResponse(
  {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    },
  },
  "Registration successful",
  (ctx as any).traceId
);
```

---

## Migration Checklist

For each router file:

- [ ] Import helper functions (`createSuccessResponse`, etc.)
- [ ] Update all `.query()` return statements
- [ ] Update all `.mutation()` return statements
- [ ] Convert error throws to use `createTRPCError()`
- [ ] Add traceId to all responses: `(ctx as any).traceId`
- [ ] Update paginated responses to use `createPaginatedResponse()`
- [ ] Test all endpoints after migration
- [ ] Update frontend client to handle new format (if needed)

---

## Testing After Migration

```typescript
// Test with tRPC client
const result = await trpc.myRouter.myQuery.query();

// New response format:
console.log(result.success); // true
console.log(result.data); // { ... }
console.log(result.message); // "Success message"
console.log(result.traceId); // "uuid"
console.log(result.timestamp); // "2025-11-25T..."
```

---

## Priority Order for Migration

1. **High Priority** (P0):
   - `auth` router (login, register, logout, me)
   - `system` router (health checks)
2. **Medium Priority** (P1):
   - `dashboard` router
   - `predictions` router
   - `portfolio` router
3. **Low Priority** (P2):
   - `ai` router
   - `reports` router
   - `admin` router
   - Other routers

---

## Notes

- **traceId Access**: Use `(ctx as any).traceId` until TypeScript types are updated
- **Backward Compatibility**: Old clients may break if they expect old format
- **Frontend Update**: Update frontend tRPC client to handle new response structure
- **Testing**: Test each router after migration
- **Logging**: traceId is automatically logged by request logging middleware

---

## Status

- ✅ `traceIdMiddleware` implemented in `server/_core/trpc.ts`
- ✅ `createSuccessResponse()` available in `server/types/api-response.ts`
- ✅ All procedures have access to `ctx.traceId`
- ⏸️ Routers migration in progress (use this guide)

---

## Questions?

See:

- `server/types/api-response.ts` - Type definitions and helpers
- `server/__tests__/api-response.test.ts` - Usage examples
- `docs/API_Contracts.md` - Response format documentation
