/**
 * AI Assistant Core Logic
 * Base class for all AI assistants (free and paid)
 * With memory/RAG support for persistent context
 */

import * as dbPostgres from "./db-compat";
import {
  AIPermissions,
  AIAssistant,
} from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";
import { newsService } from "./news-service";
import { aiMemoryService, type AIMemory } from "./ai-memory-service";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatContext {
  currentPrices?: any[];
  predictions?: any[];
  alerts?: any[];
  history?: any[];
  news?: any;
  userInfo?: any;
}

export interface ChatResponse {
  message: string;
  tokensUsed: number;
  responseTime: number;
  wasSuccessful: boolean;
  errorMessage?: string;
}

export class AIAssistantBase {
  constructor(
    public id: number,
    public name: string,
    public type: "free" | "paid",
    public model: string,
    public systemPrompt: string,
    public permissions: AIPermissions
  ) {}

  /**
   * Main chat method
   */
  async chat(userId: string, message: string): Promise<ChatResponse> {
    const startTime = Date.now();

    try {
      // 1. Check permissions and usage limits
      await this.checkUsageLimit(userId);

      // 2. Build context based on permissions
      const context = await this.buildContext(userId, message);

      // 3. Call AI API
      const response = await this.callAI(message, context);

      // 4. Calculate response time and tokens
      const responseTime = Date.now() - startTime;
      const tokensUsed = this.estimateTokens(message + response);

      // 5. Save conversation
      await this.saveConversation(
        userId,
        message,
        response,
        tokensUsed,
        responseTime,
        true
      );

      // 6. Update usage limits
      await this.updateUsageLimit(userId, tokensUsed);

      return {
        message: response,
        tokensUsed,
        responseTime,
        wasSuccessful: true,
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error";

      // Save failed conversation
      await this.saveConversation(
        userId,
        message,
        "",
        0,
        responseTime,
        false,
        errorMessage
      );

      return {
        message: "",
        tokensUsed: 0,
        responseTime,
        wasSuccessful: false,
        errorMessage,
      };
    }
  }

  /**
   * Check if user has reached usage limit
   */
  async checkUsageLimit(userId: string): Promise<void> {
    if (this.permissions.dailyMessageLimit === null) {
      return; // Unlimited
    }

    const db = dbPostgres.getDb();
    
    // Get or create usage limit record
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Ensure table exists
    await db.prepare(`
      CREATE TABLE IF NOT EXISTS ai_usage_limits (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL,
        "assistantId" INTEGER NOT NULL,
        "messagesToday" INTEGER DEFAULT 0,
        "tokensToday" INTEGER DEFAULT 0,
        "lastResetDate" BIGINT NOT NULL,
        UNIQUE("userId", "assistantId")
      )
    `).run();

    const limit = await db.prepare(
      'SELECT * FROM ai_usage_limits WHERE "userId" = $1 AND "assistantId" = $2'
    ).get(userId, this.id) as any;

    if (!limit) {
      // Create new limit record
      await db.prepare(`
        INSERT INTO ai_usage_limits ("userId", "assistantId", "messagesToday", "tokensToday", "lastResetDate")
        VALUES ($1, $2, 0, 0, $3)
      `).run(userId, this.id, Date.now());
      return;
    }

    const lastReset = new Date(limit.lastResetDate);
    lastReset.setHours(0, 0, 0, 0);

    // Reset if it's a new day
    if (today > lastReset) {
      await db.prepare(`
        UPDATE ai_usage_limits 
        SET "messagesToday" = 0, "tokensToday" = 0, "lastResetDate" = $1
        WHERE id = $2
      `).run(Date.now(), limit.id);
      return;
    }

    // Check if limit reached
    if (limit.messagesToday >= this.permissions.dailyMessageLimit!) {
      throw new Error(
        `لقد وصلت إلى الحد الأقصى اليومي (${this.permissions.dailyMessageLimit} رسالة). يرجى الترقية للنسخة المدفوعة للحصول على رسائل غير محدودة.`
      );
    }
  }

  /**
   * Update usage limit after successful chat
   */
  async updateUsageLimit(userId: string, tokensUsed: number): Promise<void> {
    const db = dbPostgres.getDb();

    const limit = await db.prepare(
      'SELECT * FROM ai_usage_limits WHERE "userId" = $1 AND "assistantId" = $2'
    ).get(userId, this.id) as any;

    if (limit) {
      await db.prepare(`
        UPDATE ai_usage_limits 
        SET "messagesToday" = "messagesToday" + 1, "tokensToday" = "tokensToday" + $1
        WHERE id = $2
      `).run(tokensUsed, limit.id);
    }
  }

  /**
   * Build context based on permissions
   */
  async buildContext(userId: string, message: string): Promise<ChatContext> {
    const context: ChatContext = {};

    try {
      // Get current prices
      if (this.permissions.canReadPrices) {
        context.currentPrices = await dbPostgres.getAllAssets();
      }

      // Get predictions
      if (this.permissions.canReadPredictions) {
        context.predictions = (await dbPostgres.getAllPredictions()).slice(0, 10);
      }

      // Get user's alerts
      if (this.permissions.canReadAlerts) {
        context.alerts = (await dbPostgres.getAlertsByUserId(userId)).slice(0, 10);
      }

      // Get historical data
      if (this.permissions.canReadHistory) {
        context.history = await dbPostgres.getLatestPrices(50);
      }

      // Search for relevant news
      if (this.permissions.canSearchNews) {
        // Extract asset names from message
        const assetKeywords = [
          "gold",
          "silver",
          "bitcoin",
          "ethereum",
          "oil",
          "ذهب",
          "فضة",
          "بيتكوين",
        ];
        const foundAsset = assetKeywords.find(keyword =>
          message.toLowerCase().includes(keyword)
        );

        if (foundAsset) {
          try {
            context.news = await newsService.getAssetNewsAnalysis(
              foundAsset,
              foundAsset
            );
          } catch (e) {
            // News service may not be available
            console.warn("[AIAssistant] News service unavailable");
          }
        }
      }

      // Get user info
      if (this.permissions.canReadUserData) {
        context.userInfo = await dbPostgres.getUser(userId);
      }

      // Get memory context from AI memory service
      const memoryContext = aiMemoryService.buildMemoryContext(
        userId,
        this.id,
        message
      );
      if (memoryContext) {
        (context as any).memoryContext = memoryContext;
      }
    } catch (error) {
      console.error("[AIAssistant] Failed to build context:", error);
    }

    return context;
  }

  /**
   * Call AI API (to be overridden by subclasses)
   */
  protected async callAI(
    message: string,
    context: ChatContext
  ): Promise<string> {
    // Build context string
    let contextStr = "";

    // Add memory context first (user-specific information)
    if ((context as any).memoryContext) {
      contextStr += (context as any).memoryContext;
    }

    if (context.currentPrices && context.currentPrices.length > 0) {
      contextStr += "\n\n**الأسعار الحالية:**\n";
      context.currentPrices.forEach((asset: any) => {
        contextStr += `- ${asset.name} (${asset.symbol}): ${asset.assetType || asset.category}\n`;
      });
    }

    if (context.predictions && context.predictions.length > 0) {
      contextStr += "\n\n**آخر التوقعات:**\n";
      context.predictions.slice(0, 5).forEach((pred: any) => {
        contextStr += `- التوقع #${pred.id}: السعر المتوقع ${pred.predictedPrice}, الدقة ${pred.accuracy || 'N/A'}\n`;
      });
    }

    if (context.news) {
      contextStr += "\n\n**الأخبار الأخيرة:**\n";
      contextStr += `المشاعر العامة: ${context.news.overallSentiment}\n`;
      contextStr += `عدد الأخبار: ${context.news.summary?.totalArticles || 0}\n`;
      contextStr += `أحداث عالية التأثير: ${context.news.summary?.highImpactEvents || 0}\n`;
    }

    // Call LLM
    const response = await invokeLLM({
      messages: [
        { role: "system", content: this.systemPrompt + contextStr },
        { role: "user", content: message },
      ],
    });

    return (
      (response.choices[0]?.message?.content as string) ||
      "عذراً، لم أتمكن من معالجة طلبك."
    );
  }

  /**
   * Save conversation to database
   */
  async saveConversation(
    userId: string,
    message: string,
    response: string,
    tokensUsed: number,
    responseTime: number,
    wasSuccessful: boolean,
    errorMessage?: string
  ): Promise<void> {
    const db = dbPostgres.getDb();

    try {
      // Ensure table exists
      await db.prepare(`
        CREATE TABLE IF NOT EXISTS ai_conversations (
          id SERIAL PRIMARY KEY,
          "userId" VARCHAR(64) NOT NULL,
          "assistantId" INTEGER NOT NULL,
          message TEXT NOT NULL,
          response TEXT,
          "tokensUsed" INTEGER DEFAULT 0,
          "responseTime" INTEGER DEFAULT 0,
          "wasSuccessful" INTEGER DEFAULT 1,
          "errorMessage" TEXT,
          "createdAt" BIGINT NOT NULL
        )
      `).run();

      await db.prepare(`
        INSERT INTO ai_conversations ("userId", "assistantId", "message", "response", "tokensUsed", "responseTime", "wasSuccessful", "errorMessage", "createdAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      `).run(
        userId,
        this.id,
        message,
        response,
        tokensUsed,
        responseTime,
        wasSuccessful ? 1 : 0,
        errorMessage || null,
        Date.now()
      );

      // Learn from conversation for memory
      if (wasSuccessful) {
        await aiMemoryService.learnFromConversation(
          userId,
          this.id,
          message,
          response
        );
      }
    } catch (error) {
      console.error("[AIAssistant] Failed to save conversation:", error);
    }
  }

  /**
   * Get conversation history
   */
  async getHistory(userId: string, limit: number = 50): Promise<any[]> {
    const db = dbPostgres.getDb();

    try {
      return await db.prepare(`
        SELECT * FROM ai_conversations 
        WHERE "userId" = $1 AND "assistantId" = $2
        ORDER BY "createdAt" DESC
        LIMIT $3
      `).all(userId, this.id, limit) as any[];
    } catch (error) {
      console.error("[AIAssistant] Failed to get history:", error);
      return [];
    }
  }

  /**
   * Clear conversation history
   */
  async clearHistory(userId: string): Promise<void> {
    const db = dbPostgres.getDb();

    try {
      // Clear both conversations and memory
      await db.prepare(
        'DELETE FROM ai_conversations WHERE "userId" = $1 AND "assistantId" = $2'
      ).run(userId, this.id);
      
      aiMemoryService.clearMemories(userId, this.id);
      
      console.log(
        `[AIAssistant] User ${userId} cleared history for assistant ${this.id}`
      );
    } catch (error) {
      console.error("[AIAssistant] Failed to clear history:", error);
    }
  }

  /**
   * Estimate tokens (rough approximation)
   */
  private estimateTokens(text: string): number {
    // Rough estimate: 1 token ≈ 4 characters
    return Math.ceil(text.length / 4);
  }
}
