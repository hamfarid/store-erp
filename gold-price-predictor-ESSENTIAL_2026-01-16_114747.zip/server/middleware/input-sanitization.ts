/**
 * FILE: server/middleware/input-sanitization.ts
 * PURPOSE: Input sanitization middleware for XSS protection
 * OWNER: Security Team
 * RELATED: server/_core/security.ts
 * LAST-AUDITED: 2025-01-18
 */

import type { Request, Response, NextFunction } from "express";

/**
 * Sanitize string input to prevent XSS
 */
export function sanitizeString(input: string): string {
  if (typeof input !== "string") {
    return String(input);
  }

  // Remove potentially dangerous characters
  return input
    .replace(/[<>]/g, "") // Remove < and >
    .replace(/javascript:/gi, "") // Remove javascript: protocol
    .replace(/on\w+=/gi, "") // Remove event handlers (onclick=, onerror=, etc.)
    .trim();
}

/**
 * Sanitize object recursively
 */
export function sanitizeObject(obj: any): any {
  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj === "string") {
    return sanitizeString(obj);
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => sanitizeObject(item));
  }

  if (typeof obj === "object") {
    const sanitized: any = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        sanitized[key] = sanitizeObject(obj[key]);
      }
    }
    return sanitized;
  }

  return obj;
}

/**
 * Input sanitization middleware
 * Sanitizes request body, query, and params
 */
export function inputSanitizationMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  // Sanitize request body
  if (req.body && typeof req.body === "object") {
    req.body = sanitizeObject(req.body);
  }

  // Sanitize query parameters
  if (req.query && typeof req.query === "object") {
    req.query = sanitizeObject(req.query) as any;
  }

  // Sanitize route parameters
  if (req.params && typeof req.params === "object") {
    req.params = sanitizeObject(req.params) as any;
  }

  next();
}

