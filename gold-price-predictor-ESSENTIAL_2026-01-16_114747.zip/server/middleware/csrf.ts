/**
 * FILE: server/middleware/csrf.ts
 * PURPOSE: CSRF protection middleware
 * OWNER: Security Team
 * RELATED: server/_core/security.ts
 * LAST-AUDITED: 2025-01-18
 */

import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { generateCSRFToken, validateCSRFToken } from "../_core/security";

// CSRF token expiration (1 hour)
const CSRF_TOKEN_EXPIRY_MS = 60 * 60 * 1000;

/**
 * CSRF protection middleware
 * Validates CSRF token on state-changing requests (POST, PUT, DELETE, PATCH)
 */
export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  // Skip CSRF check for safe methods
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    return next();
  }

  // Skip CSRF check for tRPC endpoints (handled by tRPC)
  if (req.path.startsWith("/api/trpc")) {
    return next();
  }

  // Get CSRF token from header
  const token = req.headers["x-csrf-token"] as string | undefined;
  const sessionId = req.sessionInfo?.sessionId;

  if (!token) {
    return res.status(403).json({
      error: {
        code: "CSRF_TOKEN_MISSING",
        message: "CSRF token is required",
      },
    });
  }

  if (!sessionId) {
    return res.status(401).json({
      error: {
        code: "UNAUTHORIZED",
        message: "Session required for CSRF validation",
      },
    });
  }

  // Validate CSRF token
  const isValid = validateCSRFToken(sessionId, token);

  if (!isValid) {
    return res.status(403).json({
      error: {
        code: "CSRF_TOKEN_INVALID",
        message: "Invalid CSRF token",
      },
    });
  }

  next();
}

/**
 * Generate and return CSRF token endpoint handler
 */
export function getCSRFToken(req: Request, res: Response) {
  const sessionId = req.sessionInfo?.sessionId;

  if (!sessionId) {
    return res.status(401).json({
      error: {
        code: "UNAUTHORIZED",
        message: "Session required",
      },
    });
  }

  const token = generateCSRFToken(sessionId);

  res.json({
    csrfToken: token,
  });
}

