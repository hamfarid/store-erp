/**
 * FILE: server/middleware/caching.ts
 * PURPOSE: Express middleware for HTTP response caching
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import type { Request, Response, NextFunction } from 'express';
import { cacheService, CACHE_TTL } from '../cache/cacheService';

/**
 * Cache middleware options
 */
export interface CacheOptions {
  ttl?: number;
  keyGenerator?: (req: Request) => string;
  condition?: (req: Request) => boolean;
  invalidateOn?: string[];
}

/**
 * Generate cache key from request
 */
function defaultKeyGenerator(req: Request): string {
  const { method, originalUrl, user } = req as any;
  const userId = user?.id || 'anonymous';
  return `api:${method}:${originalUrl}:${userId}`;
}

/**
 * HTTP response caching middleware
 */
export function cacheMiddleware(options: CacheOptions = {}) {
  const {
    ttl = CACHE_TTL.MEDIUM,
    keyGenerator = defaultKeyGenerator,
    condition = () => true,
    invalidateOn = [],
  } = options;

  return async (req: Request, res: Response, next: NextFunction) => {
    // Only cache GET requests
    if (req.method !== 'GET') {
      return next();
    }

    // Check condition
    if (!condition(req)) {
      return next();
    }

    // Generate cache key
    const cacheKey = keyGenerator(req);

    try {
      // Try to get from cache
      const cached = await cacheService.get(cacheKey);
      
      if (cached) {
        console.log(`[Cache] HIT: ${cacheKey}`);
        res.setHeader('X-Cache', 'HIT');
        res.setHeader('X-Cache-Key', cacheKey);
        return res.json(cached);
      }

      console.log(`[Cache] MISS: ${cacheKey}`);
      res.setHeader('X-Cache', 'MISS');
      res.setHeader('X-Cache-Key', cacheKey);

      // Intercept response
      const originalJson = res.json.bind(res);
      res.json = function (body: any) {
        // Store in cache
        cacheService.set(cacheKey, body, ttl).catch(err => {
          console.error(`[Cache] Failed to cache response:`, err);
        });

        return originalJson(body);
      };

      next();
    } catch (error) {
      console.error('[Cache] Middleware error:', error);
      next();
    }
  };
}

/**
 * Cache invalidation middleware
 * Invalidates specified cache patterns on mutation requests
 */
export function invalidateCacheMiddleware(patterns: string[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Store original json method
    const originalJson = res.json.bind(res);

    // Override json method
    res.json = function (body: any) {
      // Invalidate caches after response
      Promise.all(
        patterns.map(pattern => cacheService.deletePattern(pattern))
      ).then(() => {
        console.log(`[Cache] Invalidated patterns:`, patterns);
      }).catch(err => {
        console.error(`[Cache] Invalidation error:`, err);
      });

      return originalJson(body);
    };

    next();
  };
}

/**
 * Cache warming middleware
 * Pre-loads frequently accessed data into cache on app start
 */
export async function warmUpCache(): Promise<void> {
  console.log('[Cache] Starting cache warm-up...');
  
  try {
    // Import database functions
    const { getAllAssets } = await import('../db');
    
    // Warm up assets cache
    const assets = await getAllAssets();
    await cacheService.set('assets:all', assets, CACHE_TTL.HOUR);
    
    console.log(`[Cache] Warmed up ${assets.length} assets`);
  } catch (error) {
    console.error('[Cache] Warm-up error:', error);
  }
}

/**
 * Cache statistics middleware
 * Adds cache stats to response headers
 */
export function cacheStatsMiddleware() {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (req.path === '/api/health' || req.path === '/api/cache/stats') {
      const stats = await cacheService.getStats();
      res.setHeader('X-Cache-Keys', stats.keys.toString());
      res.setHeader('X-Cache-Hit-Rate', stats.hitRate);
    }
    next();
  };
}

/**
 * Helper: Create cache key for specific patterns
 */
export const cacheKeys = {
  user: (id: string) => `user:${id}`,
  asset: (id: number) => `asset:${id}`,
  prediction: (assetId: number) => `predictions:asset:${assetId}`,
  alerts: (userId: string) => `alerts:user:${userId}`,
  notifications: (userId: string) => `notifications:user:${userId}`,
};

/**
 * Helper: Invalidate user cache
 */
export async function invalidateUserCache(userId: string): Promise<void> {
  await cacheService.invalidateUser(userId);
}

/**
 * Helper: Invalidate asset cache
 */
export async function invalidateAssetCache(assetId: number): Promise<void> {
  await cacheService.invalidateAsset(assetId);
}
