/**
 * Backup Utilities
 * Functions for exporting and importing database and AI training data
 */

import { getDb } from "./db";
import { promises as fs } from "fs";
import path from "path";
import { TRAINING_EXAMPLES, DOMAIN_KNOWLEDGE } from "./ai-training-data";

/**
 * Export all database tables to JSON
 */
export async function exportDatabase(): Promise<{
  success: boolean;
  data?: any;
  error?: string;
  timestamp: string;
}> {
  try {
    const db = await getDb();
    if (!db) {
      return {
        success: false,
        error: "Database not available",
        timestamp: new Date().toISOString(),
      };
    }

    // Export all tables
    const tables = [
      "users",
      "assets",
      "predictions",
      "alerts",
      "portfolio_items",
      "price_history",
      "ai_assistants",
      "ai_conversations",
      "ai_usage_limits",
      "permissions",
      "user_permissions",
      "news_cache",
      "email_settings",
      "system_logs",
    ];

    const exportData: any = {
      version: "1.0",
      exportDate: new Date().toISOString(),
      tables: {},
    };

    for (const table of tables) {
      try {
        const result = await (db as any).execute(`SELECT * FROM ${table}`);
        exportData.tables[table] = result.rows || [];
      } catch (error) {
        console.warn(`Failed to export table ${table}:`, error);
        exportData.tables[table] = [];
      }
    }

    return {
      success: true,
      data: exportData,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Database export error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Import database from JSON
 */
export async function importDatabase(data: any): Promise<{
  success: boolean;
  imported: number;
  skipped: number;
  errors: string[];
}> {
  const result = {
    success: true,
    imported: 0,
    skipped: 0,
    errors: [] as string[],
  };

  try {
    const db = await getDb();
    if (!db) {
      result.success = false;
      result.errors.push("Database not available");
      return result;
    }

    if (!data.tables) {
      result.success = false;
      result.errors.push("Invalid import data format");
      return result;
    }

    // Import each table
    for (const [tableName, rows] of Object.entries(data.tables)) {
      if (!Array.isArray(rows) || rows.length === 0) {
        result.skipped++;
        continue;
      }

      try {
        // Get columns from first row
        const columns = Object.keys(rows[0]);
        const placeholders = columns.map(() => "?").join(", ");
        const columnNames = columns.join(", ");

        // Insert rows
        for (const row of rows as any[]) {
          try {
            const values = columns.map(col => row[col]);
            await (db as any).execute(
              `INSERT INTO ${tableName} (${columnNames}) VALUES (${placeholders})
               ON DUPLICATE KEY UPDATE ${columns.map(col => `${col}=VALUES(${col})`).join(", ")}`,
              values
            );
            result.imported++;
          } catch (error) {
            result.errors.push(
              `Failed to import row in ${tableName}: ${error}`
            );
          }
        }
      } catch (error) {
        result.errors.push(`Failed to import table ${tableName}: ${error}`);
        result.skipped++;
      }
    }

    result.success = result.errors.length === 0;
    return result;
  } catch (error) {
    result.success = false;
    result.errors.push(
      error instanceof Error ? error.message : "Unknown error"
    );
    return result;
  }
}

/**
 * Export AI training data to JSON
 */
export async function exportAITrainingData(): Promise<{
  success: boolean;
  data?: any;
  error?: string;
  timestamp: string;
}> {
  try {
    const exportData = {
      version: "1.0",
      exportDate: new Date().toISOString(),
      trainingExamples: TRAINING_EXAMPLES,
      domainKnowledge: DOMAIN_KNOWLEDGE,
      statistics: {
        totalExamples: TRAINING_EXAMPLES.length,
        totalKnowledge: DOMAIN_KNOWLEDGE.length,
        categories: Array.from(
          new Set(TRAINING_EXAMPLES.map(ex => ex.category))
        ),
        languages: Array.from(
          new Set(TRAINING_EXAMPLES.map(ex => ex.language))
        ),
      },
    };

    return {
      success: true,
      data: exportData,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("AI training data export error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Import AI training data from JSON
 */
export async function importAITrainingData(data: any): Promise<{
  success: boolean;
  message: string;
}> {
  try {
    if (!data.trainingExamples || !data.domainKnowledge) {
      return {
        success: false,
        message: "Invalid AI training data format",
      };
    }

    // Validate data structure
    const isValid =
      Array.isArray(data.trainingExamples) &&
      Array.isArray(data.domainKnowledge);
    if (!isValid) {
      return {
        success: false,
        message: "Invalid data structure",
      };
    }

    // Write to file (will be loaded on next server restart)
    const filePath = path.join(
      process.cwd(),
      "server",
      "ai-training-data-imported.ts"
    );
    const fileContent = `/**
 * Imported AI Training Data
 * Imported on: ${new Date().toISOString()}
 */

export const IMPORTED_TRAINING_EXAMPLES = ${JSON.stringify(data.trainingExamples, null, 2)};

export const IMPORTED_DOMAIN_KNOWLEDGE = ${JSON.stringify(data.domainKnowledge, null, 2)};
`;

    await fs.writeFile(filePath, fileContent, "utf-8");

    return {
      success: true,
      message: `Successfully imported ${data.trainingExamples.length} training examples and ${data.domainKnowledge.length} knowledge entries`,
    };
  } catch (error) {
    console.error("AI training data import error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Create full backup (database + AI data)
 */
export async function createFullBackup(): Promise<{
  success: boolean;
  filePath?: string;
  size?: number;
  error?: string;
  timestamp: string;
}> {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupDir = path.join(process.cwd(), "backups");

    // Create backups directory if it doesn't exist
    try {
      await fs.mkdir(backupDir, { recursive: true });
    } catch (error) {
      // Directory might already exist
    }

    // Export database
    const dbExport = await exportDatabase();
    if (!dbExport.success) {
      return {
        success: false,
        error: `Database export failed: ${dbExport.error}`,
        timestamp: new Date().toISOString(),
      };
    }

    // Export AI data
    const aiExport = await exportAITrainingData();
    if (!aiExport.success) {
      return {
        success: false,
        error: `AI data export failed: ${aiExport.error}`,
        timestamp: new Date().toISOString(),
      };
    }

    // Combine into single backup file
    const fullBackup = {
      version: "1.0",
      backupDate: new Date().toISOString(),
      database: dbExport.data,
      aiTrainingData: aiExport.data,
    };

    const fileName = `full-backup-${timestamp}.json`;
    const filePath = path.join(backupDir, fileName);

    await fs.writeFile(filePath, JSON.stringify(fullBackup, null, 2), "utf-8");

    const stats = await fs.stat(filePath);

    return {
      success: true,
      filePath,
      size: stats.size,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Full backup error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Restore from full backup
 */
export async function restoreFullBackup(data: any): Promise<{
  success: boolean;
  message: string;
  details: {
    database: { imported: number; skipped: number; errors: string[] };
    aiData: { success: boolean; message: string };
  };
}> {
  try {
    if (!data.database || !data.aiTrainingData) {
      return {
        success: false,
        message: "Invalid backup file format",
        details: {
          database: { imported: 0, skipped: 0, errors: ["Invalid format"] },
          aiData: { success: false, message: "Invalid format" },
        },
      };
    }

    // Restore database
    const dbRestore = await importDatabase(data.database);

    // Restore AI data
    const aiRestore = await importAITrainingData(data.aiTrainingData);

    const success = dbRestore.success && aiRestore.success;

    return {
      success,
      message: success
        ? "Full backup restored successfully"
        : "Backup restored with some errors",
      details: {
        database: dbRestore,
        aiData: aiRestore,
      },
    };
  } catch (error) {
    console.error("Full backup restore error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
      details: {
        database: { imported: 0, skipped: 0, errors: [String(error)] },
        aiData: { success: false, message: String(error) },
      },
    };
  }
}

/**
 * List all available backups
 */
export async function listBackups(): Promise<{
  success: boolean;
  backups: Array<{
    fileName: string;
    filePath: string;
    size: number;
    createdAt: Date;
  }>;
  error?: string;
}> {
  try {
    const backupDir = path.join(process.cwd(), "backups");

    try {
      await fs.access(backupDir);
    } catch {
      return {
        success: true,
        backups: [],
      };
    }

    const files = await fs.readdir(backupDir);
    const backups = [];

    for (const file of files) {
      if (file.endsWith(".json")) {
        const filePath = path.join(backupDir, file);
        const stats = await fs.stat(filePath);
        backups.push({
          fileName: file,
          filePath,
          size: stats.size,
          createdAt: stats.mtime,
        });
      }
    }

    // Sort by date (newest first)
    backups.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return {
      success: true,
      backups,
    };
  } catch (error) {
    console.error("List backups error:", error);
    return {
      success: false,
      backups: [],
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Delete a backup file
 */
export async function deleteBackup(fileName: string): Promise<{
  success: boolean;
  message: string;
}> {
  try {
    const backupDir = path.join(process.cwd(), "backups");
    const filePath = path.join(backupDir, fileName);

    // Security check: ensure file is in backups directory
    if (!filePath.startsWith(backupDir)) {
      return {
        success: false,
        message: "Invalid file path",
      };
    }

    await fs.unlink(filePath);

    return {
      success: true,
      message: "Backup deleted successfully",
    };
  } catch (error) {
    console.error("Delete backup error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
    };
  }
}
