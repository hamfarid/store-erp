/**
 * Audit Logging & Monitoring System
 * Track changes, calculate trends, and provide analytics for learning data and prices
 */

import { getDb } from "./db";

export interface AuditLog {
  id: number;
  userId: string;
  action: string;
  entityType:
    | "training_example"
    | "knowledge_base"
    | "price_data"
    | "prediction"
    | "alert"
    | "system";
  entityId?: string;
  changes?: string; // JSON string of changes
  metadata?: string; // JSON string of additional metadata
  timestamp: Date;
}

export interface LearningDataTrend {
  date: string;
  totalExamples: number;
  noisePercentage: number;
  duplicatePercentage: number;
  coverageScore: number;
  completenessScore: number;
}

export interface PriceAnalytics {
  assetId: string;
  assetName: string;
  currentPrice: number;
  priceChange24h: number;
  priceChangePercent24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  volatility: number;
  trend: "up" | "down" | "stable";
}

/**
 * Log an audit event
 */
export async function logAuditEvent(
  event: Omit<AuditLog, "id" | "timestamp">
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Audit] Database not available, skipping audit log");
    return;
  }

  try {
    await (db as any).execute(
      `INSERT INTO audit_logs (userId, action, entityType, entityId, changes, metadata, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, NOW())`,
      [
        event.userId,
        event.action,
        event.entityType,
        event.entityId || null,
        event.changes || null,
        event.metadata || null,
      ]
    );
  } catch (error) {
    console.error("[Audit] Failed to log event:", error);
  }
}

/**
 * Get audit logs with filters
 */
export async function getAuditLogs(filters: {
  userId?: string;
  entityType?: string;
  action?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}): Promise<AuditLog[]> {
  const db = await getDb();
  if (!db) {return [];}

  try {
    const conditions: string[] = [];
    const params: any[] = [];

    if (filters.userId) {
      conditions.push("userId = ?");
      params.push(filters.userId);
    }

    if (filters.entityType) {
      conditions.push("entityType = ?");
      params.push(filters.entityType);
    }

    if (filters.action) {
      conditions.push("action = ?");
      params.push(filters.action);
    }

    if (filters.startDate) {
      conditions.push("timestamp >= ?");
      params.push(filters.startDate);
    }

    if (filters.endDate) {
      conditions.push("timestamp <= ?");
      params.push(filters.endDate);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
    const limit = filters.limit || 100;
    const offset = filters.offset || 0;

    params.push(limit, offset);

    const result = await (db as any).execute(
      `SELECT * FROM audit_logs ${whereClause} ORDER BY timestamp DESC LIMIT ? OFFSET ?`,
      params
    );

    return result.rows as AuditLog[];
  } catch (error) {
    console.error("[Audit] Failed to get logs:", error);
    return [];
  }
}

/**
 * Get learning data trends over time
 */
export async function getLearningDataTrends(
  days: number = 30
): Promise<LearningDataTrend[]> {
  // In a real implementation, this would query historical data from database
  // For now, we'll return simulated trend data based on current statistics
  const { getLearningStatistics } = await import("./ai-learning-analysis");
  const currentStats = await getLearningStatistics();

  const trends: LearningDataTrend[] = [];
  const today = new Date();

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);

    // Simulate historical data with some variance
    const variance = (Math.random() - 0.5) * 10;
    trends.push({
      date: date.toISOString().split("T")[0],
      totalExamples: Math.max(
        0,
        Math.floor(
          currentStats.totalExamples * (0.8 + ((days - i) / days) * 0.2)
        )
      ),
      noisePercentage: Math.max(
        0,
        Math.min(100, currentStats.dataQuality.noisePercentage + variance)
      ),
      duplicatePercentage: Math.max(
        0,
        Math.min(100, currentStats.dataQuality.duplicatePercentage + variance)
      ),
      coverageScore: Math.max(
        0,
        Math.min(100, currentStats.dataQuality.coverageScore + variance)
      ),
      completenessScore: Math.max(
        0,
        Math.min(100, currentStats.dataQuality.completenessScore + variance)
      ),
    });
  }

  return trends;
}

/**
 * Get price analytics for an asset
 */
export async function getPriceAnalytics(
  assetId: string
): Promise<PriceAnalytics | null> {
  const db = await getDb();
  if (!db) {return null;}

  try {
    // Get current price
    const currentResult = await (db as any).execute(
      `SELECT price, timestamp FROM price_history
       WHERE assetId = ?
       ORDER BY timestamp DESC LIMIT 1`,
      [assetId]
    );

    if (currentResult.rows.length === 0) {return null;}

    const currentPrice = (currentResult.rows[0] as any).price;

    // Get 24h statistics
    const statsResult = await (db as any).execute(
      `SELECT
        MIN(price) as low24h,
        MAX(price) as high24h,
        AVG(price) as avg24h,
        COUNT(*) as count24h,
        STDDEV(price) as volatility
       FROM price_history 
       WHERE assetId = ? 
       AND timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)`,
      [assetId]
    );

    const stats = statsResult.rows[0] as any;

    // Get price 24h ago
    const price24hResult = await (db as any).execute(
      `SELECT price FROM price_history
       WHERE assetId = ?
       AND timestamp <= DATE_SUB(NOW(), INTERVAL 24 HOUR)
       ORDER BY timestamp DESC LIMIT 1`,
      [assetId]
    );

    const price24h =
      price24hResult.rows.length > 0
        ? (price24hResult.rows[0] as any).price
        : currentPrice;
    const priceChange24h = currentPrice - price24h;
    const priceChangePercent24h = (priceChange24h / price24h) * 100;

    // Determine trend
    let trend: "up" | "down" | "stable" = "stable";
    if (priceChangePercent24h > 1) {trend = "up";}
    else if (priceChangePercent24h < -1) {trend = "down";}

    // Get asset name
    const assetResult = await (db as any).execute(
      `SELECT name FROM assets WHERE id = ?`,
      [assetId]
    );

    const assetName =
      assetResult.rows.length > 0
        ? (assetResult.rows[0] as any).name
        : "Unknown";

    return {
      assetId,
      assetName,
      currentPrice,
      priceChange24h,
      priceChangePercent24h,
      high24h: stats.high24h || currentPrice,
      low24h: stats.low24h || currentPrice,
      volume24h: stats.count24h || 0,
      volatility: stats.volatility || 0,
      trend,
    };
  } catch (error) {
    console.error("[Analytics] Failed to get price analytics:", error);
    return null;
  }
}

/**
 * Get price history for charting
 */
export async function getPriceHistory(
  assetId: string,
  period: "1h" | "24h" | "7d" | "30d" | "1y" = "24h"
): Promise<Array<{ timestamp: string; price: number; volume?: number }>> {
  const db = await getDb();
  if (!db) {return [];}

  try {
    const periodMap = {
      "1h": "INTERVAL 1 HOUR",
      "24h": "INTERVAL 24 HOUR",
      "7d": "INTERVAL 7 DAY",
      "30d": "INTERVAL 30 DAY",
      "1y": "INTERVAL 1 YEAR",
    };

    const result = await (db as any).execute(
      `SELECT timestamp, price
       FROM price_history
       WHERE assetId = ?
       AND timestamp >= DATE_SUB(NOW(), ${periodMap[period]})
       ORDER BY timestamp ASC`,
      [assetId]
    );

    return result.rows.map((row: any) => ({
      timestamp: row.timestamp,
      price: row.price,
    }));
  } catch (error) {
    console.error("[Analytics] Failed to get price history:", error);
    return [];
  }
}

/**
 * Get multiple assets comparison data
 */
export async function getAssetsComparison(
  assetIds: string[],
  period: "24h" | "7d" | "30d" = "24h"
): Promise<Record<string, PriceAnalytics>> {
  const comparison: Record<string, PriceAnalytics> = {};

  for (const assetId of assetIds) {
    const analytics = await getPriceAnalytics(assetId);
    if (analytics) {
      comparison[assetId] = analytics;
    }
  }

  return comparison;
}

/**
 * Calculate portfolio performance
 */
export async function getPortfolioPerformance(userId: string): Promise<{
  totalValue: number;
  totalChange24h: number;
  totalChangePercent24h: number;
  bestPerformer: string;
  worstPerformer: string;
  assets: Array<{
    assetId: string;
    assetName: string;
    quantity: number;
    currentValue: number;
    change24h: number;
    changePercent24h: number;
  }>;
}> {
  const db = await getDb();
  if (!db) {
    return {
      totalValue: 0,
      totalChange24h: 0,
      totalChangePercent24h: 0,
      bestPerformer: "",
      worstPerformer: "",
      assets: [],
    };
  }

  try {
    // Get user's portfolio
    const portfolioResult = await (db as any).execute(
      `SELECT assetId, quantity FROM portfolio WHERE userId = ?`,
      [userId]
    );

    const assets: Array<{
      assetId: string;
      assetName: string;
      quantity: number;
      currentValue: number;
      change24h: number;
      changePercent24h: number;
    }> = [];

    let totalValue = 0;
    let totalChange24h = 0;

    for (const row of portfolioResult.rows) {
      const { assetId, quantity } = row as any;
      const analytics = await getPriceAnalytics(assetId);

      if (analytics) {
        const currentValue = analytics.currentPrice * quantity;
        const change24h = analytics.priceChange24h * quantity;

        assets.push({
          assetId,
          assetName: analytics.assetName,
          quantity,
          currentValue,
          change24h,
          changePercent24h: analytics.priceChangePercent24h,
        });

        totalValue += currentValue;
        totalChange24h += change24h;
      }
    }

    const totalChangePercent24h =
      totalValue > 0
        ? (totalChange24h / (totalValue - totalChange24h)) * 100
        : 0;

    // Find best and worst performers
    const sortedAssets = [...assets].sort(
      (a, b) => b.changePercent24h - a.changePercent24h
    );
    const bestPerformer = sortedAssets[0]?.assetName || "";
    const worstPerformer =
      sortedAssets[sortedAssets.length - 1]?.assetName || "";

    return {
      totalValue,
      totalChange24h,
      totalChangePercent24h,
      bestPerformer,
      worstPerformer,
      assets,
    };
  } catch (error) {
    console.error("[Analytics] Failed to get portfolio performance:", error);
    return {
      totalValue: 0,
      totalChange24h: 0,
      totalChangePercent24h: 0,
      bestPerformer: "",
      worstPerformer: "",
      assets: [],
    };
  }
}

/**
 * Generate audit summary report
 */
export async function getAuditSummary(days: number = 7): Promise<{
  totalEvents: number;
  eventsByType: Record<string, number>;
  eventsByAction: Record<string, number>;
  topUsers: Array<{ userId: string; count: number }>;
  recentEvents: AuditLog[];
}> {
  const db = await getDb();
  if (!db) {
    return {
      totalEvents: 0,
      eventsByType: {},
      eventsByAction: {},
      topUsers: [],
      recentEvents: [],
    };
  }

  try {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Total events
    const totalResult = await (db as any).execute(
      `SELECT COUNT(*) as total FROM audit_logs WHERE timestamp >= ?`,
      [startDate]
    );
    const totalEvents = (totalResult.rows[0] as any).total;

    // Events by type
    const typeResult = await (db as any).execute(
      `SELECT entityType, COUNT(*) as count
       FROM audit_logs
       WHERE timestamp >= ? 
       GROUP BY entityType`,
      [startDate]
    );
    const eventsByType: Record<string, number> = {};
    for (const row of typeResult.rows) {
      const { entityType, count } = row as any;
      eventsByType[entityType] = count;
    }

    // Events by action
    const actionResult = await (db as any).execute(
      `SELECT action, COUNT(*) as count
       FROM audit_logs
       WHERE timestamp >= ?
       GROUP BY action`,
      [startDate]
    );
    const eventsByAction: Record<string, number> = {};
    for (const row of actionResult.rows) {
      const { action, count } = row as any;
      eventsByAction[action] = count;
    }

    // Top users
    const usersResult = await (db as any).execute(
      `SELECT userId, COUNT(*) as count
       FROM audit_logs
       WHERE timestamp >= ?
       GROUP BY userId
       ORDER BY count DESC
       LIMIT 10`,
      [startDate]
    );
    const topUsers = usersResult.rows.map((row: any) => ({
      userId: row.userId,
      count: row.count,
    }));

    // Recent events
    const recentEvents = await getAuditLogs({ startDate, limit: 20 });

    return {
      totalEvents,
      eventsByType,
      eventsByAction,
      topUsers,
      recentEvents,
    };
  } catch (error) {
    console.error("[Audit] Failed to get summary:", error);
    return {
      totalEvents: 0,
      eventsByType: {},
      eventsByAction: {},
      topUsers: [],
      recentEvents: [],
    };
  }
}

/**
 * Create audit_logs table if not exists
 */
export async function initializeAuditTable(): Promise<void> {
  const db = await getDb();
  if (!db) {return;}

  try {
    await (db as any).execute(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(64) NOT NULL,
        action VARCHAR(100) NOT NULL,
        entityType VARCHAR(50) NOT NULL,
        entityId VARCHAR(100),
        changes TEXT,
        metadata TEXT,
        timestamp DATETIME NOT NULL,
        INDEX idx_userId (userId),
        INDEX idx_entityType (entityType),
        INDEX idx_timestamp (timestamp)
      )
    `);
    console.log("[Audit] Table initialized successfully");
  } catch (error) {
    console.error("[Audit] Failed to initialize table:", error);
  }
}
