/**
 * FILE: server/jobs/learningWorker.ts
 * PURPOSE: Learning queue worker (Bull/BullMQ)
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { Worker, Job } from 'bullmq';
import { redis } from '../cache/redis';
import { processLearningJob, type LearningJobData } from './learningQueue';

// Create worker
export const learningWorker = new Worker<LearningJobData>(
  'learning',
  async (job: Job<LearningJobData>) => {
    console.log(`[Learning Worker] Processing job ${job.id}`);
    
    try {
      // Use the centralized processor function
      const result = await processLearningJob(job);
      
      console.log(`[Learning Worker] Job ${job.id} completed`);
      return result;
    } catch (error) {
      console.error(`[Learning Worker] Job ${job.id} failed:`, error);
      throw error;
    }
  },
  {
    connection: redis,
    concurrency: parseInt(process.env.QUEUE_CONCURRENCY || '5'),
    limiter: {
      max: parseInt(process.env.QUEUE_MAX_JOBS_PER_SECOND || '10'),
      duration: 1000, // Max jobs per second
    },
  }
);

// Worker events
learningWorker.on('completed', (job) => {
  console.log(`[Learning Worker] Completed job ${job.id}`);
});

learningWorker.on('failed', (job, error) => {
  console.error(`[Learning Worker] Failed job ${job?.id}:`, error);
});

learningWorker.on('error', (error) => {
  console.error('[Learning Worker] Error:', error);
});

// Cleanup
export async function closeLearningWorker() {
  await learningWorker.close();
  console.log('[Learning Worker] Closed');
}

process.on('SIGTERM', closeLearningWorker);
process.on('SIGINT', closeLearningWorker);
