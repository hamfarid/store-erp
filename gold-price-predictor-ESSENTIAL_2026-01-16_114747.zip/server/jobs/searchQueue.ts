/**
 * FILE: server/jobs/searchQueue.ts
 * PURPOSE: Search job processor (Bull/BullMQ)
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 * UPDATED: 2026-01-15 - Migrated to Bull/BullMQ
 */

import type { Job } from 'bullmq';
import { searchOrchestrator } from '../services/search';
import type { SearchOperationType } from '../services/search';
import { addSearchJob as bullAddSearchJob, getQueueStats, cancelJob } from './bullQueues';

export interface SearchJobData {
  operationId: string;
  type: string;
  keywords: string[];
  sources: number[];
  dateRange?: { from: string; to: string };
  userId?: string;
}

/**
 * Process a search job (called by Bull worker)
 */
export async function processSearchJob(
  job: Job<SearchJobData>
): Promise<unknown> {
  const { operationId, type, keywords, sources, dateRange } = job.data;
  
  console.log(`[SearchQueue] Processing job ${job.id}: ${type}`);
  
  // Set up progress listener
  const progressHandler = (progress: { operationId: string; progress?: number }) => {
    if (progress.operationId === operationId && progress.progress !== undefined) {
      job.updateProgress(progress.progress).catch(console.error);
    }
  };
  
  searchOrchestrator.on('progress', progressHandler);
  
  try {
    // Run the operation - pass input object
    const result = await searchOrchestrator.startOperation(
      operationId,
      type as SearchOperationType,
      { keywords, sources, dateRange }
    );
    
    return result;
  } finally {
    searchOrchestrator.off('progress', progressHandler);
  }
}

/**
 * Add a search job to the Bull queue
 */
export async function addSearchJob(
  operationId: string,
  type: SearchOperationType,
  keywords: string[],
  sources: number[],
  dateRange?: { from: string; to: string },
  userId?: string
): Promise<{ id: string }> {
  const job = await bullAddSearchJob({
    operationId,
    type,
    keywords,
    sources,
    dateRange,
    userId,
  });
  
  console.log(`[SearchQueue] Added job ${job.id} for operation ${operationId}`);
  
  return { id: job.id || operationId };
}

/**
 * Cancel a search job
 */
export async function cancelSearchJob(operationId: string): Promise<boolean> {
  // Try to cancel the job in Bull queue
  const cancelled = await cancelJob('search', operationId);
  
  // Also cancel in orchestrator (if it's already running)
  await searchOrchestrator.cancelOperation(operationId);
  
  console.log(`[SearchQueue] Cancelled operation ${operationId}: ${cancelled}`);
  return cancelled;
}

/**
 * Get search queue stats
 */
export async function getSearchQueueStats(): Promise<{
  pending: number;
  running: number;
  completed: number;
  failed: number;
  waiting: number;
  active: number;
  delayed: number;
  total: number;
}> {
  const stats = await getQueueStats('search');
  
  return {
    pending: stats.waiting,
    running: stats.active,
    completed: stats.completed,
    failed: stats.failed,
    waiting: stats.waiting,
    active: stats.active,
    delayed: stats.delayed,
    total: stats.total,
  };
}
