/**
 * FILE: server/jobs/bullQueues.ts
 * PURPOSE: Bull queue setup and configuration (production-ready replacement for SimpleQueue)
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { Queue, Worker, Job, QueueEvents } from 'bullmq';
import { redis } from '../cache/redis';
import { nanoid } from 'nanoid';

// ==================== Queue Configuration ====================

const queueConfig = {
  connection: redis,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential' as const,
      delay: 2000,
    },
    removeOnComplete: {
      count: 100, // Keep last 100 completed jobs
      age: 24 * 3600, // 24 hours
    },
    removeOnFail: {
      count: 50, // Keep last 50 failed jobs
      age: 7 * 24 * 3600, // 7 days
    },
  },
};

// ==================== Queue Instances ====================

export const learningQueue = new Queue('learning', queueConfig);
export const searchQueue = new Queue('search', queueConfig);
export const notificationQueue = new Queue('notification', queueConfig);

// ==================== Queue Events ====================

const learningEvents = new QueueEvents('learning', { connection: redis });
const searchEvents = new QueueEvents('search', { connection: redis });

learningEvents.on('completed', ({ jobId, returnvalue }) => {
  console.log(`[Learning Queue] Job ${jobId} completed:`, returnvalue);
});

learningEvents.on('failed', ({ jobId, failedReason }) => {
  console.error(`[Learning Queue] Job ${jobId} failed:`, failedReason);
});

searchEvents.on('completed', ({ jobId, returnvalue }) => {
  console.log(`[Search Queue] Job ${jobId} completed:`, returnvalue);
});

searchEvents.on('failed', ({ jobId, failedReason }) => {
  console.error(`[Search Queue] Job ${jobId} failed:`, failedReason);
});

// ==================== Job Types ====================

export interface LearningJobData {
  operationId: string;
  type: 'prediction_comparison' | 'pattern_detection' | 'correlation_analysis' 
      | 'model_training' | 'insight_generation' | 'adjustment_application';
  input: Record<string, unknown>;
  userId?: string;
}

export interface SearchJobData {
  operationId: string;
  type: 'keyword_search' | 'event_discovery' | 'news_scraping' | 'sentiment_analysis' | 'entity_extraction';
  keywords: string[];
  sources: number[];
  dateRange?: { from: string; to: string };
  userId?: string;
}

// ==================== Job Functions ====================

/**
 * Add learning job to queue
 */
export async function addLearningJob(data: LearningJobData) {
  const jobId = nanoid();
  
  const job = await learningQueue.add(
    'learning-operation',
    data,
    {
      jobId,
      priority: data.type === 'prediction_comparison' ? 1 : 2,
    }
  );
  
  console.log(`[Learning Queue] Added job ${job.id}`);
  return job;
}

/**
 * Add search job to queue
 */
export async function addSearchJob(data: SearchJobData) {
  const jobId = nanoid();
  
  const job = await searchQueue.add(
    'search-operation',
    data,
    {
      jobId,
      priority: data.type === 'event_discovery' ? 1 : 2,
    }
  );
  
  console.log(`[Search Queue] Added job ${job.id}`);
  return job;
}

/**
 * Cancel job by ID
 */
export async function cancelJob(
  queueName: 'learning' | 'search',
  jobId: string
): Promise<boolean> {
  try {
    const queue = queueName === 'learning' ? learningQueue : searchQueue;
    const job = await queue.getJob(jobId);
    
    if (job) {
      await job.remove();
      console.log(`[${queueName} Queue] Job ${jobId} cancelled`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`[${queueName} Queue] Cancel failed:`, error);
    return false;
  }
}

/**
 * Get job status
 */
export async function getJobStatus(
  queueName: 'learning' | 'search',
  jobId: string
) {
  try {
    const queue = queueName === 'learning' ? learningQueue : searchQueue;
    const job = await queue.getJob(jobId);
    
    if (!job) {
      return { status: 'not_found' };
    }
    
    const state = await job.getState();
    const progress = job.progress;
    
    return {
      id: job.id,
      status: state,
      progress,
      data: job.data,
      returnvalue: job.returnvalue,
      failedReason: job.failedReason,
      processedOn: job.processedOn,
      finishedOn: job.finishedOn,
    };
  } catch (error) {
    console.error(`[${queueName} Queue] Get status failed:`, error);
    return { status: 'error', error: (error as Error).message };
  }
}

/**
 * Get queue statistics
 */
export async function getQueueStats(queueName: 'learning' | 'search') {
  const queue = queueName === 'learning' ? learningQueue : searchQueue;
  
  const [waiting, active, completed, failed, delayed] = await Promise.all([
    queue.getWaitingCount(),
    queue.getActiveCount(),
    queue.getCompletedCount(),
    queue.getFailedCount(),
    queue.getDelayedCount(),
  ]);
  
  return {
    waiting,
    active,
    completed,
    failed,
    delayed,
    total: waiting + active + completed + failed + delayed,
  };
}

/**
 * Pause queue
 */
export async function pauseQueue(queueName: 'learning' | 'search') {
  const queue = queueName === 'learning' ? learningQueue : searchQueue;
  await queue.pause();
  console.log(`[${queueName} Queue] Paused`);
}

/**
 * Resume queue
 */
export async function resumeQueue(queueName: 'learning' | 'search') {
  const queue = queueName === 'learning' ? learningQueue : searchQueue;
  await queue.resume();
  console.log(`[${queueName} Queue] Resumed`);
}

/**
 * Clean old jobs
 */
export async function cleanQueue(
  queueName: 'learning' | 'search',
  grace: number = 24 * 3600 * 1000 // 24 hours
) {
  const queue = queueName === 'learning' ? learningQueue : searchQueue;
  
  await queue.clean(grace, 100, 'completed');
  await queue.clean(grace * 7, 50, 'failed'); // Keep failed longer
  
  console.log(`[${queueName} Queue] Cleaned old jobs`);
}

// ==================== Cleanup ====================

export async function closeQueues() {
  await learningQueue.close();
  await searchQueue.close();
  await notificationQueue.close();
  await learningEvents.close();
  await searchEvents.close();
  console.log('[Queues] All queues closed');
}

process.on('SIGTERM', closeQueues);
process.on('SIGINT', closeQueues);
