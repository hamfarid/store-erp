/**
 * FILE: server/jobs/index.ts
 * PURPOSE: Export job queue functionality
 * CREATED: 2026-01-15
 */

export {
  SimpleQueue,
  learningQueue,
  searchQueue,
  initializeQueues,
  shutdownQueues,
} from './queues';

export type { QueueJob, QueueOptions } from './queues';

export {
  processLearningJob,
  addLearningJob,
  cancelLearningJob,
  getLearningQueueStats,
} from './learningQueue';

export {
  processSearchJob,
  addSearchJob,
  cancelSearchJob,
  getSearchQueueStats,
} from './searchQueue';
