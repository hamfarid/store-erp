/**
 * FILE: server/jobs/learningQueue.ts
 * PURPOSE: Learning job processor (Bull/BullMQ)
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 * UPDATED: 2026-01-15 - Migrated to Bull/BullMQ
 */

import type { Job } from 'bullmq';
import { learningOrchestrator } from '../services/learning';
import type { LearningOperationType } from '../services/learning';
import { addLearningJob as bullAddJob, getQueueStats, cancelJob } from './bullQueues';

export interface LearningJobData {
  operationId: string;
  type: string;
  input: Record<string, unknown>;
  userId?: string;
}

/**
 * Process a learning job (called by Bull worker)
 */
export async function processLearningJob(
  job: Job<LearningJobData>
): Promise<unknown> {
  const { operationId, type, input } = job.data;
  
  console.log(`[LearningQueue] Processing job ${job.id}: ${type}`);
  
  // Set up progress listener
  const progressHandler = (progress: { operationId: string; progress?: number }) => {
    if (progress.operationId === operationId && progress.progress !== undefined) {
      job.updateProgress(progress.progress).catch(console.error);
    }
  };
  
  learningOrchestrator.on('progress', progressHandler);
  
  try {
    // Run the operation
    const result = await learningOrchestrator.startOperation(
      operationId,
      type as LearningOperationType,
      input
    );
    
    return result;
  } finally {
    learningOrchestrator.off('progress', progressHandler);
  }
}

/**
 * Add a learning job to the Bull queue
 */
export async function addLearningJob(
  operationId: string,
  type: LearningOperationType,
  input: Record<string, unknown> = {},
  userId?: string
): Promise<{ id: string }> {
  const job = await bullAddJob({
    operationId,
    type,
    input,
    userId,
  });
  
  console.log(`[LearningQueue] Added job ${job.id} for operation ${operationId}`);
  
  return { id: job.id || operationId };
}

/**
 * Cancel a learning job
 */
export async function cancelLearningJob(operationId: string): Promise<boolean> {
  // Try to cancel the job in Bull queue
  const cancelled = await cancelJob('learning', operationId);
  
  // Also cancel in orchestrator (if it's already running)
  await learningOrchestrator.cancelOperation(operationId);
  
  console.log(`[LearningQueue] Cancelled operation ${operationId}: ${cancelled}`);
  return cancelled;
}

/**
 * Get learning queue stats
 */
export async function getLearningQueueStats(): Promise<{
  pending: number;
  running: number;
  completed: number;
  failed: number;
  waiting: number;
  active: number;
  delayed: number;
  total: number;
}> {
  const stats = await getQueueStats('learning');
  
  return {
    pending: stats.waiting,
    running: stats.active,
    completed: stats.completed,
    failed: stats.failed,
    waiting: stats.waiting,
    active: stats.active,
    delayed: stats.delayed,
    total: stats.total,
  };
}
