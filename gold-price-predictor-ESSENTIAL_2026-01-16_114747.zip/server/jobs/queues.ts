/**
 * FILE: server/jobs/queues.ts
 * PURPOSE: Queue configuration and initialization
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { EventEmitter } from 'events';

// ==================== Types ====================

export interface QueueJob<T = unknown> {
  id: string;
  type: string;
  data: T;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  error?: string;
  result?: unknown;
}

export interface QueueOptions {
  maxConcurrency?: number;
  retryAttempts?: number;
  retryDelay?: number;
}

// ==================== In-Memory Queue (Lightweight Alternative to Bull) ====================
// Note: For production, replace with Bull/BullMQ for Redis-backed queues
// This implementation provides the same interface without Redis dependency

export class SimpleQueue<T = unknown> extends EventEmitter {
  private jobs: Map<string, QueueJob<T>> = new Map();
  private processing: Set<string> = new Set();
  private processor?: (job: QueueJob<T>) => Promise<unknown>;
  private options: Required<QueueOptions>;
  private isProcessing: boolean = false;

  constructor(
    public readonly name: string,
    options: QueueOptions = {}
  ) {
    super();
    this.options = {
      maxConcurrency: options.maxConcurrency ?? 3,
      retryAttempts: options.retryAttempts ?? 3,
      retryDelay: options.retryDelay ?? 1000,
    };
  }

  /**
   * Add a job to the queue
   */
  async add(type: string, data: T): Promise<QueueJob<T>> {
    const id = `${this.name}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    
    const job: QueueJob<T> = {
      id,
      type,
      data,
      status: 'pending',
      progress: 0,
      createdAt: new Date(),
    };
    
    this.jobs.set(id, job);
    this.emit('added', job);
    
    // Start processing if not already running
    this.processNext();
    
    return job;
  }

  /**
   * Set the job processor function
   */
  process(processor: (job: QueueJob<T>) => Promise<unknown>): void {
    this.processor = processor;
    this.processNext();
  }

  /**
   * Get a job by ID
   */
  getJob(id: string): QueueJob<T> | undefined {
    return this.jobs.get(id);
  }

  /**
   * Update job progress
   */
  updateProgress(id: string, progress: number): void {
    const job = this.jobs.get(id);
    if (job) {
      job.progress = progress;
      this.emit('progress', job);
    }
  }

  /**
   * Cancel a job
   */
  async cancel(id: string): Promise<boolean> {
    const job = this.jobs.get(id);
    if (job && (job.status === 'pending' || job.status === 'running')) {
      job.status = 'cancelled';
      this.emit('cancelled', job);
      return true;
    }
    return false;
  }

  /**
   * Get all jobs
   */
  getJobs(status?: QueueJob<T>['status']): QueueJob<T>[] {
    const jobs = Array.from(this.jobs.values());
    return status ? jobs.filter(j => j.status === status) : jobs;
  }

  /**
   * Get queue stats
   */
  getStats(): { pending: number; running: number; completed: number; failed: number } {
    const jobs = Array.from(this.jobs.values());
    return {
      pending: jobs.filter(j => j.status === 'pending').length,
      running: jobs.filter(j => j.status === 'running').length,
      completed: jobs.filter(j => j.status === 'completed').length,
      failed: jobs.filter(j => j.status === 'failed').length,
    };
  }

  /**
   * Clear completed and failed jobs
   */
  clean(): void {
    for (const [id, job] of this.jobs) {
      if (job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled') {
        this.jobs.delete(id);
      }
    }
  }

  /**
   * Process next pending job
   */
  private async processNext(): Promise<void> {
    if (!this.processor || this.isProcessing) return;
    if (this.processing.size >= this.options.maxConcurrency) return;
    
    // Find next pending job
    const pendingJob = Array.from(this.jobs.values()).find(
      j => j.status === 'pending' && !this.processing.has(j.id)
    );
    
    if (!pendingJob) return;
    
    this.processing.add(pendingJob.id);
    pendingJob.status = 'running';
    pendingJob.startedAt = new Date();
    this.emit('started', pendingJob);
    
    try {
      const result = await this.processor(pendingJob);
      
      // Check if cancelled during processing (status can be changed by cancel() during async processing)
      if ((pendingJob.status as string) === 'cancelled') {
        return;
      }
      
      pendingJob.status = 'completed';
      pendingJob.completedAt = new Date();
      pendingJob.progress = 100;
      pendingJob.result = result;
      this.emit('completed', pendingJob);
      
    } catch (error) {
      pendingJob.status = 'failed';
      pendingJob.completedAt = new Date();
      pendingJob.error = error instanceof Error ? error.message : 'Unknown error';
      this.emit('failed', pendingJob);
      
    } finally {
      this.processing.delete(pendingJob.id);
      // Process next job
      setImmediate(() => this.processNext());
    }
  }

  /**
   * Shutdown the queue
   */
  async shutdown(): Promise<void> {
    this.isProcessing = false;
    // Wait for current jobs to finish
    while (this.processing.size > 0) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    this.emit('shutdown');
  }
}

// ==================== Queue Instances ====================

export const learningQueue = new SimpleQueue<{
  operationId: string;
  type: string;
  input: Record<string, unknown>;
}>('learning', {
  maxConcurrency: 2,
  retryAttempts: 3,
});

export const searchQueue = new SimpleQueue<{
  operationId: string;
  type: string;
  keywords: string[];
  sources: number[];
  dateRange?: { from: string; to: string };
}>('search', {
  maxConcurrency: 3,
  retryAttempts: 2,
});

// ==================== Initialization ====================

let initialized = false;

/**
 * Initialize SimpleQueue with basic processors
 * Note: For Redis-backed queues, use BullMQ via bullQueues.ts
 * This SimpleQueue is a fallback for environments without Redis
 */
export async function initializeQueues(): Promise<void> {
  if (initialized) return;
  
  // Simple processor adapters for SimpleQueue (in-memory fallback)
  // These are lightweight processors that call the orchestrators directly
  const simpleProcessLearning = async (job: QueueJob<{
    operationId: string;
    type: string;
    input: Record<string, unknown>;
  }>) => {
    const { learningOrchestrator } = await import('../services/learning');
    return learningOrchestrator.startOperation(
      job.data.operationId,
      job.data.type as any,
      job.data.input
    );
  };

  const simpleProcessSearch = async (job: QueueJob<{
    operationId: string;
    type: string;
    keywords: string[];
    sources: number[];
    dateRange?: { from: string; to: string };
  }>) => {
    const { searchOrchestrator } = await import('../services/search');
    return searchOrchestrator.startOperation(
      job.data.operationId,
      job.data.type as any,
      {
        keywords: job.data.keywords,
        sources: job.data.sources,
        dateRange: job.data.dateRange,
      }
    );
  };
  
  // Set processors
  learningQueue.process(simpleProcessLearning);
  searchQueue.process(simpleProcessSearch);
  
  // Set up event handlers
  learningQueue.on('started', (job) => {
    console.log(`[SimpleQueue:Learning] Job started: ${job.id} - ${job.type}`);
  });
  
  learningQueue.on('completed', (job) => {
    console.log(`[SimpleQueue:Learning] Job completed: ${job.id}`);
  });
  
  learningQueue.on('failed', (job) => {
    console.error(`[SimpleQueue:Learning] Job failed: ${job.id} - ${job.error}`);
  });
  
  searchQueue.on('started', (job) => {
    console.log(`[SimpleQueue:Search] Job started: ${job.id} - ${job.type}`);
  });
  
  searchQueue.on('completed', (job) => {
    console.log(`[SimpleQueue:Search] Job completed: ${job.id}`);
  });
  
  searchQueue.on('failed', (job) => {
    console.error(`[SimpleQueue:Search] Job failed: ${job.id} - ${job.error}`);
  });
  
  initialized = true;
  console.log('[SimpleQueue] Initialized (in-memory fallback mode)');
}

export async function shutdownQueues(): Promise<void> {
  await learningQueue.shutdown();
  await searchQueue.shutdown();
  console.log('[SimpleQueue] Shutdown complete');
}
