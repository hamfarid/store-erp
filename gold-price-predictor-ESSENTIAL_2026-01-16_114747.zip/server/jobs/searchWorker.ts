/**
 * FILE: server/jobs/searchWorker.ts
 * PURPOSE: Search queue worker (Bull/BullMQ)
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { Worker, Job } from 'bullmq';
import { redis } from '../cache/redis';
import { processSearchJob, type SearchJobData } from './searchQueue';

// Create worker
export const searchWorker = new Worker<SearchJobData>(
  'search',
  async (job: Job<SearchJobData>) => {
    console.log(`[Search Worker] Processing job ${job.id}`);
    
    try {
      // Use the centralized processor function
      const result = await processSearchJob(job);
      
      console.log(`[Search Worker] Job ${job.id} completed`);
      return result;
    } catch (error) {
      console.error(`[Search Worker] Job ${job.id} failed:`, error);
      throw error;
    }
  },
  {
    connection: redis,
    concurrency: 3, // Search is more intensive, use lower concurrency
    limiter: {
      max: 5,
      duration: 1000, // Max 5 jobs per second
    },
  }
);

// Worker events
searchWorker.on('completed', (job) => {
  console.log(`[Search Worker] Completed job ${job.id}`);
});

searchWorker.on('failed', (job, error) => {
  console.error(`[Search Worker] Failed job ${job?.id}:`, error);
});

searchWorker.on('error', (error) => {
  console.error('[Search Worker] Error:', error);
});

// Cleanup
export async function closeSearchWorker() {
  await searchWorker.close();
  console.log('[Search Worker] Closed');
}

process.on('SIGTERM', closeSearchWorker);
process.on('SIGINT', closeSearchWorker);
