/**
 * AI Training Data & Knowledge Base
 * Contains training examples, FAQs, and domain knowledge for AI assistants
 */

export interface TrainingExample {
  question: string;
  answer: string;
  category: string;
  language: 'ar' | 'en';
  assistantType: 'free' | 'paid' | 'both';
}

export interface DomainKnowledge {
  topic: string;
  content: string;
  keywords: string[];
  language: 'ar' | 'en';
}

/**
 * Training Examples for AI Assistants
 */
export const TRAINING_EXAMPLES: TrainingExample[] = [
  // Arabic - Basic Questions
  {
    question: "ما هو الذهب؟",
    answer: "الذهب هو معدن ثمين يُستخدم كمخزن للقيمة وملاذ آمن في أوقات عدم الاستقرار الاقتصادي. يتم تداوله في الأسواق العالمية ويُقاس سعره بالأونصة (حوالي 31.1 جرام). الذهب يحافظ على قيمته عبر الزمن ويُعتبر تحوطاً ضد التضخم.",
    category: "basics",
    language: "ar",
    assistantType: "both"
  },
  {
    question: "كيف أبدأ في الاستثمار؟",
    answer: "للبدء في الاستثمار:\n1. حدد أهدافك المالية (قصيرة/متوسطة/طويلة الأجل)\n2. قيّم مستوى تحملك للمخاطر\n3. ابدأ بمبلغ صغير يمكنك تحمل خسارته\n4. نوّع استثماراتك (لا تضع كل أموالك في أصل واحد)\n5. تعلم باستمرار وتابع الأسواق\n6. استخدم منصتنا للحصول على توقعات مدعومة بالذكاء الاصطناعي",
    category: "investment",
    language: "ar",
    assistantType: "both"
  },
  {
    question: "ما الفرق بين التداول والاستثمار؟",
    answer: "**التداول:**\n- شراء وبيع متكرر على المدى القصير\n- يهدف للربح من تقلبات الأسعار اليومية\n- يتطلب وقتاً ومتابعة مستمرة\n- مخاطر أعلى\n\n**الاستثمار:**\n- شراء أصول والاحتفاظ بها لفترة طويلة\n- يهدف للنمو والعوائد على المدى البعيد\n- أقل حاجة للمتابعة اليومية\n- مخاطر أقل نسبياً",
    category: "basics",
    language: "ar",
    assistantType: "both"
  },

  // Arabic - Platform Usage
  {
    question: "كيف أستخدم نظام التوقعات؟",
    answer: "لاستخدام نظام التوقعات:\n1. اذهب إلى صفحة 'التوقعات'\n2. اختر الأصل الذي تريد التوقع له (ذهب، نفط، عملات، إلخ)\n3. حدد نوع النموذج (LSTM, GRU, Transformer, أو Ensemble)\n4. اختر الأفق الزمني (قصير/متوسط/طويل الأجل)\n5. اضغط 'إنشاء توقع'\n6. ستحصل على توقع مع مستوى الثقة والنطاق المتوقع",
    category: "platform",
    language: "ar",
    assistantType: "both"
  },
  {
    question: "كيف أنشئ تنبيهاً للسعر؟",
    answer: "لإنشاء تنبيه:\n1. اذهب إلى صفحة 'التنبيهات'\n2. اضغط 'إنشاء تنبيه جديد'\n3. اختر الأصل\n4. حدد نوع التنبيه (أعلى من، أقل من، أو تغيير بنسبة)\n5. أدخل السعر المستهدف\n6. اختر طريقة الإشعار (push، email، أو كلاهما)\n7. احفظ التنبيه\n\nسيتم إرسال إشعار فوري عندما يصل السعر للهدف المحدد.",
    category: "platform",
    language: "ar",
    assistantType: "both"
  },

  // Arabic - Technical Analysis
  {
    question: "ما هي المؤشرات الفنية؟",
    answer: "المؤشرات الفنية هي حسابات رياضية تستند إلى بيانات الأسعار والحجم لمساعدة المتداولين في اتخاذ القرارات. أشهرها:\n\n**مؤشرات الاتجاه:**\n- المتوسطات المتحركة (MA)\n- MACD\n\n**مؤشرات الزخم:**\n- RSI (مؤشر القوة النسبية)\n- Stochastic\n\n**مؤشرات التقلب:**\n- Bollinger Bands\n- ATR\n\nنظامنا يستخدم هذه المؤشرات ضمن نماذج الذكاء الاصطناعي لتحسين دقة التوقعات.",
    category: "technical",
    language: "ar",
    assistantType: "paid"
  },

  // Arabic - AI Models
  {
    question: "ما الفرق بين نماذج الذكاء الاصطناعي المختلفة؟",
    answer: "نوفر 4 نماذج للتوقع:\n\n**1. LSTM (Long Short-Term Memory):**\n- ممتاز للأنماط طويلة الأجل\n- دقة عالية للأصول المستقرة\n- الأفضل للذهب والمعادن\n\n**2. GRU (Gated Recurrent Unit):**\n- أسرع من LSTM\n- جيد للتوقعات قصيرة المدى\n- مناسب للعملات الرقمية\n\n**3. Transformer:**\n- يفهم العلاقات المعقدة\n- ممتاز للأسواق المتقلبة\n- الأفضل للنفط والأسهم\n\n**4. Ensemble (مجمّع):**\n- يجمع النماذج الثلاثة\n- أعلى دقة (95%+)\n- موصى به للقرارات المهمة",
    category: "ai",
    language: "ar",
    assistantType: "paid"
  },

  // English - Basic Questions
  {
    question: "What is cryptocurrency?",
    answer: "Cryptocurrency is a digital or virtual currency that uses cryptography for security. Key features:\n\n- **Decentralized:** Not controlled by any government or bank\n- **Blockchain-based:** Transactions recorded on a distributed ledger\n- **Volatile:** Prices can change rapidly\n- **24/7 Trading:** Markets never close\n\nPopular examples: Bitcoin (BTC), Ethereum (ETH), and others. Our platform provides AI-powered predictions for major cryptocurrencies.",
    category: "basics",
    language: "en",
    assistantType: "both"
  },

  // Risk Management
  {
    question: "كيف أدير المخاطر في التداول؟",
    answer: "إدارة المخاطر أساسية للنجاح:\n\n**1. لا تستثمر أكثر مما تستطيع خسارته**\n\n**2. استخدم أوامر وقف الخسارة (Stop Loss)**\n\n**3. نوّع محفظتك:**\n- لا تضع كل أموالك في أصل واحد\n- وزّع بين أصول مختلفة (ذهب، عملات، أسهم)\n\n**4. حدد نسبة المخاطرة:**\n- لا تخاطر بأكثر من 2-3% من رأس المال في صفقة واحدة\n\n**5. استخدم توقعاتنا:**\n- راجع مستوى الثقة في التوقع\n- انتبه للنطاق المتوقع (أعلى/أقل)\n\n**6. لا تتداول بناءً على العواطف**\n- التزم بخطتك\n- لا تطارد الخسائر",
    category: "risk",
    language: "ar",
    assistantType: "paid"
  },

  // Market Analysis
  {
    question: "كيف تؤثر الأخبار على الأسعار؟",
    answer: "الأخبار لها تأثير كبير على الأسواق:\n\n**أخبار إيجابية → ارتفاع الأسعار:**\n- قرارات البنوك المركزية بخفض الفائدة\n- أرباح الشركات أعلى من المتوقع\n- بيانات اقتصادية قوية\n\n**أخبار سلبية → انخفاض الأسعار:**\n- رفع أسعار الفائدة\n- توترات جيوسياسية\n- ركود اقتصادي\n\n**ميزتنا:**\nنظامنا يحلل الأخبار تلقائياً باستخدام الذكاء الاصطناعي ويدمج تحليل المشاعر في التوقعات (متوفر للمساعد المدفوع).",
    category: "analysis",
    language: "ar",
    assistantType: "paid"
  },

  // Portfolio Management
  {
    question: "كيف أبني محفظة استثمارية متوازنة؟",
    answer: "لبناء محفظة متوازنة:\n\n**1. حدد نسب التوزيع:**\n- 40% أصول آمنة (ذهب، سندات)\n- 40% أصول متوسطة المخاطر (أسهم كبرى)\n- 20% أصول عالية المخاطر (عملات رقمية)\n\n**2. نوّع جغرافياً:**\n- لا تركز على سوق واحد\n- استثمر في أسواق مختلفة\n\n**3. أعد التوازن دورياً:**\n- راجع محفظتك كل 3-6 أشهر\n- أعد توزيع الأصول حسب الأداء\n\n**4. استخدم ميزة المحفظة في منصتنا:**\n- تتبع أداء استثماراتك\n- احصل على تقارير تلقائية\n- شاهد توصيات مخصصة",
    category: "portfolio",
    language: "ar",
    assistantType: "paid"
  }
];

/**
 * Domain Knowledge Base
 */
export const DOMAIN_KNOWLEDGE: DomainKnowledge[] = [
  {
    topic: "Gold Trading",
    content: `Gold (XAU/USD) is one of the most traded commodities globally. Key factors affecting gold prices:
    
1. **US Dollar Strength:** Inverse relationship - stronger dollar = lower gold prices
2. **Interest Rates:** Higher rates make gold less attractive (no yield)
3. **Inflation:** Gold is a hedge against inflation
4. **Geopolitical Tensions:** Safe-haven demand increases during crises
5. **Central Bank Policies:** Large gold reserves and buying/selling activities
6. **Jewelry Demand:** Especially from India and China

Trading Hours: 24/5 (Sunday 6 PM - Friday 5 PM EST)
Standard Lot: 100 troy ounces
Typical Spread: 0.3-0.5 pips`,
    keywords: ['gold', 'XAU', 'precious metals', 'safe haven', 'ذهب'],
    language: 'en'
  },
  {
    topic: "تداول النفط",
    content: `النفط الخام (Crude Oil) من أهم السلع المتداولة عالمياً. هناك نوعان رئيسيان:

**1. WTI (West Texas Intermediate):**
- نفط أمريكي
- أخف وأقل كثافة
- معيار لأسعار النفط في أمريكا الشمالية

**2. Brent Crude:**
- نفط من بحر الشمال
- معيار عالمي (يمثل 2/3 من التداولات)

**العوامل المؤثرة على الأسعار:**
1. العرض والطلب العالمي
2. قرارات أوبك (OPEC)
3. المخزونات الأمريكية (تقرير EIA الأسبوعي)
4. التوترات الجيوسياسية في الشرق الأوسط
5. قوة الاقتصاد العالمي
6. التحول للطاقة المتجددة

**ساعات التداول:** 24/5
**وحدة القياس:** البرميل (159 لتر)`,
    keywords: ['oil', 'crude', 'WTI', 'Brent', 'نفط', 'برميل'],
    language: 'ar'
  },
  {
    topic: "Cryptocurrency Basics",
    content: `Cryptocurrencies are digital assets that use blockchain technology. Key concepts:

**Bitcoin (BTC):**
- First cryptocurrency (2009)
- Limited supply: 21 million coins
- "Digital gold" - store of value
- Most liquid and widely accepted

**Ethereum (ETH):**
- Smart contract platform
- Powers DeFi and NFTs
- Proof of Stake (since 2022)
- Second largest by market cap

**Key Characteristics:**
1. **Volatility:** Can swing 10%+ in a day
2. **24/7 Trading:** No market close
3. **Decentralized:** No central authority
4. **Transparent:** All transactions on blockchain
5. **Global:** Borderless transfers

**Risk Factors:**
- Regulatory uncertainty
- Security risks (hacking)
- Market manipulation
- Technology risks`,
    keywords: ['bitcoin', 'ethereum', 'crypto', 'blockchain', 'BTC', 'ETH', 'عملات رقمية'],
    language: 'en'
  },
  {
    topic: "التحليل الفني",
    content: `التحليل الفني هو دراسة حركة الأسعار التاريخية للتنبؤ بالاتجاهات المستقبلية.

**المبادئ الأساسية:**
1. السعر يعكس كل شيء
2. الأسعار تتحرك في اتجاهات
3. التاريخ يعيد نفسه

**أنواع الرسوم البيانية:**
- **الخطي:** بسيط، يربط أسعار الإغلاق
- **الشموع اليابانية:** الأكثر شيوعاً، يظهر الافتتاح والإغلاق والقمة والقاع
- **الأعمدة:** مشابه للشموع

**المؤشرات الأساسية:**
1. **المتوسطات المتحركة (MA):** تنعيم الأسعار لرؤية الاتجاه
2. **RSI:** قياس قوة الزخم (0-100)
3. **MACD:** تقاطع المتوسطات لتحديد الاتجاه
4. **Bollinger Bands:** قياس التقلب

**أنماط الرسوم:**
- الرأس والكتفين
- القمم والقيعان المزدوجة
- المثلثات
- الأعلام والرايات

نظامنا يستخدم كل هذه الأدوات في نماذج الذكاء الاصطناعي.`,
    keywords: ['technical analysis', 'indicators', 'charts', 'تحليل فني', 'مؤشرات'],
    language: 'ar'
  }
];

/**
 * Common FAQs
 */
export const COMMON_FAQS = [
  {
    question: "ما هي دقة التوقعات؟",
    answer: "نماذجنا تحقق دقة 95%+ باستخدام نموذج Ensemble. الدقة تختلف حسب:\n- نوع الأصل (الذهب أكثر استقراراً من العملات الرقمية)\n- الأفق الزمني (قصير المدى أدق من طويل المدى)\n- ظروف السوق (الأسواق المستقرة أسهل للتوقع)\n\nنعرض مستوى الثقة مع كل توقع لمساعدتك في اتخاذ القرار."
  },
  {
    question: "هل التوقعات مضمونة؟",
    answer: "لا، التوقعات ليست مضمونة. الأسواق المالية معقدة ومتقلبة، وأي توقع يحمل درجة من عدم اليقين.\n\n**ما نوفره:**\n- توقعات مبنية على بيانات تاريخية وتحليل متقدم\n- مستوى ثقة واضح لكل توقع\n- نطاق متوقع (أعلى/أقل)\n\n**نصيحتنا:**\n- استخدم التوقعات كأداة مساعدة، ليس كقرار نهائي\n- نوّع استثماراتك\n- لا تستثمر أكثر مما تستطيع خسارته"
  },
  {
    question: "What's the difference between free and paid assistant?",
    answer: "**Free Assistant:**\n- 10 messages per day\n- General market information\n- Basic platform help\n- No personalized analysis\n\n**Paid Assistant:**\n- 100 messages per day\n- Personalized predictions\n- News sentiment analysis\n- Portfolio recommendations\n- Priority support\n- Advanced technical analysis\n\nUpgrade to unlock all features!"
  }
];

/**
 * Get relevant training examples based on query
 */
export function getRelevantExamples(query: string, limit: number = 5): TrainingExample[] {
  const queryLower = query.toLowerCase();
  
  // Score each example based on keyword matches
  const scored = TRAINING_EXAMPLES.map(example => {
    const questionLower = example.question.toLowerCase();
    const answerLower = example.answer.toLowerCase();
    
    let score = 0;
    
    // Exact question match
    if (questionLower.includes(queryLower) || queryLower.includes(questionLower)) {
      score += 10;
    }
    
    // Word matches in question
    const queryWords = queryLower.split(/\s+/);
    queryWords.forEach(word => {
      if (word.length > 3) {
        if (questionLower.includes(word)) {score += 2;}
        if (answerLower.includes(word)) {score += 1;}
      }
    });
    
    return { example, score };
  });
  
  // Sort by score and return top results
  return scored
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.example);
}

/**
 * Get relevant domain knowledge
 */
export function getRelevantKnowledge(query: string, limit: number = 3): DomainKnowledge[] {
  const queryLower = query.toLowerCase();
  
  const scored = DOMAIN_KNOWLEDGE.map(knowledge => {
    let score = 0;
    
    // Check keywords
    knowledge.keywords.forEach(keyword => {
      if (queryLower.includes(keyword.toLowerCase())) {
        score += 5;
      }
    });
    
    // Check topic
    if (queryLower.includes(knowledge.topic.toLowerCase())) {
      score += 3;
    }
    
    return { knowledge, score };
  });
  
  return scored
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.knowledge);
}

/**
 * Build enhanced context for AI from training data
 */
export function buildEnhancedContext(query: string): string {
  const examples = getRelevantExamples(query, 3);
  const knowledge = getRelevantKnowledge(query, 2);
  
  let context = '';
  
  if (examples.length > 0) {
    context += '\n\n**أمثلة ذات صلة:**\n';
    examples.forEach((ex, i) => {
      context += `\n${i + 1}. س: ${ex.question}\nج: ${ex.answer.substring(0, 200)}...\n`;
    });
  }
  
  if (knowledge.length > 0) {
    context += '\n\n**معلومات إضافية:**\n';
    knowledge.forEach((k, i) => {
      context += `\n${i + 1}. ${k.topic}:\n${k.content.substring(0, 300)}...\n`;
    });
  }
  
  return context;
}

