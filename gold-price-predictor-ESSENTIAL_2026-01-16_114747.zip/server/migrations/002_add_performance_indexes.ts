/**
 * Migration: Add performance indexes to database
 * Adds indexes for frequently queried columns per Global Professional Core Prompt
 */

import Database from "better-sqlite3";
import { join } from "path";

export async function up() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  console.log("[Migration 002] Database path:", dbPath);
  const db = new Database(dbPath);

  try {
    console.log("[Migration 002] Adding performance indexes...");

    // Users table indexes
    const userIndexes = [
      { name: "idx_users_email", table: "users", column: "email" },
      { name: "idx_users_role", table: "users", column: "role" },
      { name: "idx_users_login_method", table: "users", column: "loginMethod" },
      { name: "idx_users_created_at", table: "users", column: "createdAt" },
    ];

    // Assets table indexes
    const assetIndexes = [
      { name: "idx_assets_symbol", table: "assets", column: "symbol" },
      { name: "idx_assets_category", table: "assets", column: "category" },
      { name: "idx_assets_is_active", table: "assets", column: "isActive" },
      { name: "idx_assets_yahoo_symbol", table: "assets", column: "yahooSymbol" },
    ];

    // Alerts table indexes
    const alertIndexes = [
      { name: "idx_alerts_user_id", table: "alerts", column: "userId" },
      { name: "idx_alerts_asset_id", table: "alerts", column: "assetId" },
      { name: "idx_alerts_is_active", table: "alerts", column: "isActive" },
      { name: "idx_alerts_is_triggered", table: "alerts", column: "isTriggered" },
      { name: "idx_alerts_created_at", table: "alerts", column: "createdAt" },
    ];

    // Predictions table indexes
    const predictionIndexes = [
      { name: "idx_predictions_asset_id", table: "predictions", column: "assetId" },
      { name: "idx_predictions_created_at", table: "predictions", column: "createdAt" },
      { name: "idx_predictions_target_date", table: "predictions", column: "targetDate" },
      { name: "idx_predictions_model_type", table: "predictions", column: "modelType" },
    ];

    // Historical prices indexes
    const historicalPriceIndexes = [
      { name: "idx_historical_prices_asset_id", table: "historical_prices", column: "assetId" },
      { name: "idx_historical_prices_date", table: "historical_prices", column: "date" },
      { name: "idx_historical_prices_timestamp", table: "historical_prices", column: "timestamp" },
    ];

    // Notifications indexes (using correct column names)
    const notificationIndexes = [
      { name: "idx_notifications_user_id", table: "notifications", column: "userId" },
      { name: "idx_notifications_is_read", table: "notifications", column: "isRead" },
      { name: "idx_notifications_created_at", table: "notifications", column: "createdAt" },
    ];

    // User permissions indexes
    const permissionIndexes = [
      { name: "idx_user_permissions_user_id", table: "user_permissions", column: "userId" },
      { name: "idx_user_permissions_permission", table: "user_permissions", column: "permission" },
    ];

    // AI conversations indexes
    const aiConversationIndexes = [
      { name: "idx_ai_conversations_user_id", table: "ai_conversations", column: "userId" },
      { name: "idx_ai_conversations_assistant_type", table: "ai_conversations", column: "assistantType" },
      { name: "idx_ai_conversations_created_at", table: "ai_conversations", column: "createdAt" },
    ];

    // AI memories indexes
    const aiMemoryIndexes = [
      { name: "idx_ai_memories_user_id", table: "ai_memories", column: "userId" },
      { name: "idx_ai_memories_type", table: "ai_memories", column: "type" },
      { name: "idx_ai_memories_keywords", table: "ai_memories", column: "keywords" },
    ];

    // Expert opinions indexes
    const expertOpinionsIndexes = [
      { name: "idx_expert_opinions_asset_id", table: "expert_opinions", column: "assetId" },
      { name: "idx_expert_opinions_sentiment", table: "expert_opinions", column: "sentiment" },
    ];

    // Drift detections indexes
    const driftDetectionsIndexes = [
      { name: "idx_drift_detections_model", table: "drift_detections", column: "modelType" },
      { name: "idx_drift_detections_severity", table: "drift_detections", column: "severity" },
    ];

    // Learning paths indexes
    const learningPathsIndexes = [
      { name: "idx_learning_paths_user_id", table: "learning_paths", column: "userId" },
      { name: "idx_learning_paths_status", table: "learning_paths", column: "status" },
    ];

    // Trading signals indexes
    const tradingSignalsIndexes = [
      { name: "idx_trading_signals_asset_id", table: "trading_signals", column: "assetId" },
      { name: "idx_trading_signals_type", table: "trading_signals", column: "signalType" },
    ];

    // Technical indicators indexes
    const technicalIndicatorsIndexes = [
      { name: "idx_technical_indicators_asset_id", table: "technical_indicators", column: "assetId" },
      { name: "idx_technical_indicators_type", table: "technical_indicators", column: "indicatorType" },
    ];

    // Model performance indexes
    const modelPerformanceIndexes = [
      { name: "idx_model_performance_type", table: "model_performance", column: "modelType" },
    ];

    // Combine all indexes
    const allIndexes = [
      ...userIndexes,
      ...assetIndexes,
      ...alertIndexes,
      ...predictionIndexes,
      ...historicalPriceIndexes,
      ...notificationIndexes,
      ...permissionIndexes,
      ...aiConversationIndexes,
      ...aiMemoryIndexes,
      ...expertOpinionsIndexes,
      ...driftDetectionsIndexes,
      ...learningPathsIndexes,
      ...tradingSignalsIndexes,
      ...technicalIndicatorsIndexes,
      ...modelPerformanceIndexes,
    ];

    // Get existing indexes
    const existingIndexes = db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'index'")
      .all() as { name: string }[];
    const existingIndexNames = new Set(existingIndexes.map(idx => idx.name));

    let created = 0;
    let skipped = 0;

    for (const idx of allIndexes) {
      if (existingIndexNames.has(idx.name)) {
        console.log(`[Migration 002] ⏭️  Index ${idx.name} already exists`);
        skipped++;
        continue;
      }

      try {
        // Check if table exists
        const tableExists = db
          .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?")
          .get(idx.table);

        if (!tableExists) {
          console.log(`[Migration 002] ⏭️  Table ${idx.table} does not exist, skipping ${idx.name}`);
          skipped++;
          continue;
        }

        // Check if column exists
        const columns = db.prepare(`PRAGMA table_info(${idx.table})`).all() as { name: string }[];
        const columnExists = columns.some(col => col.name === idx.column);

        if (!columnExists) {
          console.log(`[Migration 002] ⏭️  Column ${idx.column} does not exist in ${idx.table}, skipping ${idx.name}`);
          skipped++;
          continue;
        }

        db.exec(`CREATE INDEX IF NOT EXISTS ${idx.name} ON ${idx.table}(${idx.column})`);
        console.log(`[Migration 002] ✅ Created index: ${idx.name} ON ${idx.table}(${idx.column})`);
        created++;
      } catch (error: any) {
        console.log(`[Migration 002] ⚠️  Failed to create ${idx.name}: ${error.message}`);
        skipped++;
      }
    }

    // Create composite indexes for common query patterns
    const compositeIndexes = [
      {
        name: "idx_alerts_user_active",
        sql: "CREATE INDEX IF NOT EXISTS idx_alerts_user_active ON alerts(userId, isActive)",
      },
      {
        name: "idx_predictions_asset_date",
        sql: "CREATE INDEX IF NOT EXISTS idx_predictions_asset_date ON predictions(assetId, createdAt DESC)",
      },
      {
        name: "idx_historical_prices_asset_date",
        sql: "CREATE INDEX IF NOT EXISTS idx_historical_prices_asset_date ON historical_prices(assetId, date DESC)",
      },
      {
        name: "idx_notifications_user_read",
        sql: "CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(userId, isRead)",
      },
      // Additional important composite indexes
      {
        name: "idx_ai_memories_user_type",
        sql: "CREATE INDEX IF NOT EXISTS idx_ai_memories_user_type ON ai_memories(userId, type)",
      },
      {
        name: "idx_trading_signals_asset_type",
        sql: "CREATE INDEX IF NOT EXISTS idx_trading_signals_asset_type ON trading_signals(assetId, signalType)",
      },
    ];

    for (const idx of compositeIndexes) {
      if (existingIndexNames.has(idx.name)) {
        console.log(`[Migration 002] ⏭️  Composite index ${idx.name} already exists`);
        skipped++;
        continue;
      }

      try {
        db.exec(idx.sql);
        console.log(`[Migration 002] ✅ Created composite index: ${idx.name}`);
        created++;
      } catch (error: any) {
        console.log(`[Migration 002] ⚠️  Failed to create ${idx.name}: ${error.message}`);
        skipped++;
      }
    }

    console.log(`\n[Migration 002] Summary: ${created} indexes created, ${skipped} skipped`);
    console.log("[Migration 002] ✅ Performance indexes migration completed");
  } catch (error) {
    console.error("[Migration 002] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

export function down() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  const db = new Database(dbPath);

  try {
    console.log("[Migration 002] Removing performance indexes...");

    // List of indexes to remove (only custom ones, not primary key indexes)
    const indexesToRemove = [
      "idx_users_email",
      "idx_users_role",
      "idx_users_login_method",
      "idx_users_created_at",
      "idx_assets_symbol",
      "idx_assets_category",
      "idx_assets_is_active",
      "idx_assets_yahoo_symbol",
      "idx_alerts_user_id",
      "idx_alerts_asset_id",
      "idx_alerts_is_active",
      "idx_alerts_is_triggered",
      "idx_alerts_created_at",
      "idx_predictions_asset_id",
      "idx_predictions_created_at",
      "idx_predictions_target_date",
      "idx_predictions_model_type",
      "idx_historical_prices_asset_id",
      "idx_historical_prices_date",
      "idx_historical_prices_timestamp",
      "idx_notifications_user_id",
      "idx_notifications_is_read",
      "idx_notifications_created_at",
      "idx_user_permissions_user_id",
      "idx_user_permissions_permission",
      "idx_ai_conversations_user_id",
      "idx_ai_conversations_assistant_type",
      "idx_ai_conversations_created_at",
      "idx_ai_memories_user_id",
      "idx_ai_memories_type",
      "idx_ai_memories_keywords",
      "idx_alerts_user_active",
      "idx_predictions_asset_date",
      "idx_historical_prices_asset_date",
      "idx_notifications_user_read",
    ];

    for (const idx of indexesToRemove) {
      try {
        db.exec(`DROP INDEX IF EXISTS ${idx}`);
        console.log(`[Migration 002] ✅ Dropped index: ${idx}`);
      } catch (error: any) {
        console.log(`[Migration 002] ⚠️  Failed to drop ${idx}: ${error.message}`);
      }
    }

    console.log("[Migration 002] ✅ Performance indexes rollback completed");
  } catch (error) {
    console.error("[Migration 002] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

// Run migration if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  up()
    .then(() => {
      console.log("[Migration 002] Migration completed successfully");
      process.exit(0);
    })
    .catch(error => {
      console.error("[Migration 002] Migration failed:", error);
      process.exit(1);
    });
}

