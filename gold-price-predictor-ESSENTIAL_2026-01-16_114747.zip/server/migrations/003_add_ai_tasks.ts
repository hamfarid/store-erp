/**
 * Migration: Add AI Scheduled Tasks tables
 */

import Database from "better-sqlite3";
import { join } from "path";

export async function up() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  console.log("[Migration] Database path:", dbPath);
  const db = new Database(dbPath);

  try {
    // Check if ai_scheduled_tasks table exists
    const tableExists = db
      .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_scheduled_tasks'")
      .get() as any;

    if (!tableExists) {
      console.log("[Migration] ai_scheduled_tasks table does not exist. Creating it...");
      db.exec(`
        CREATE TABLE IF NOT EXISTS ai_scheduled_tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId TEXT NOT NULL,
          assistantId INTEGER DEFAULT 1,
          taskName TEXT NOT NULL,
          description TEXT,
          taskType TEXT NOT NULL,
          taskConfig TEXT,
          scheduleType TEXT NOT NULL,
          cronExpression TEXT NOT NULL,
          timezone TEXT DEFAULT 'UTC',
          isActive INTEGER DEFAULT 1 NOT NULL,
          lastRunAt INTEGER,
          nextRunAt INTEGER,
          notifyOnCompletion INTEGER DEFAULT 1 NOT NULL,
          notifyOnError INTEGER DEFAULT 1 NOT NULL,
          createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000) NOT NULL,
          updatedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000) NOT NULL
        );
      `);
      console.log("[Migration] ✅ ai_scheduled_tasks table created");
    } else {
        console.log("[Migration] ⏭️  ai_scheduled_tasks table already exists");
    }

    // Check if ai_task_results table exists
    const resultsTableExists = db
      .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_task_results'")
      .get() as any;

    if (!resultsTableExists) {
      console.log("[Migration] ai_task_results table does not exist. Creating it...");
      db.exec(`
        CREATE TABLE IF NOT EXISTS ai_task_results (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          taskId INTEGER NOT NULL,
          status TEXT NOT NULL,
          result TEXT,
          errorMessage TEXT,
          executionTime INTEGER,
          tokensUsed INTEGER,
          executedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000) NOT NULL
        );
      `);
      console.log("[Migration] ✅ ai_task_results table created");
    } else {
        console.log("[Migration] ⏭️  ai_task_results table already exists");
    }

  } catch (error) {
    console.error("[Migration] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

export function down() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  const db = new Database(dbPath);

  try {
    console.log("[Migration] Removing AI tasks tables...");
    db.exec(`DROP TABLE IF EXISTS ai_scheduled_tasks;`);
    db.exec(`DROP TABLE IF EXISTS ai_task_results;`);
    console.log("[Migration] ✅ Tables removed successfully");
  } catch (error) {
    console.error("[Migration] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

// Run migration if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  up()
    .then(() => {
      console.log("[Migration] Migration completed successfully");
      process.exit(0);
    })
    .catch(error => {
      console.error("[Migration] Migration failed:", error);
      process.exit(1);
    });
}
