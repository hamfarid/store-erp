/**
 * Migration: Add password field to users table
 * Adds passwordHash field for local authentication
 */

import Database from "better-sqlite3";
import { join } from "path";
import bcrypt from "bcryptjs";

export async function up() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  console.log("[Migration] Database path:", dbPath);
  const db = new Database(dbPath);

  try {
    // Check if users table exists
    const tableExists = db
      .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
      .get() as any;

    if (!tableExists) {
      console.log("[Migration] Users table does not exist. Creating it...");
      db.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          passwordHash TEXT,
          loginMethod TEXT DEFAULT 'local',
          role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
          createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
          lastSignedIn INTEGER,
          updatedAt INTEGER
        )
      `);
      console.log("[Migration] ✅ Users table created");
    }

    // Check if column already exists
    console.log("[Migration] Checking table structure...");
    const columns = db.prepare("PRAGMA table_info(users)").all() as any[];
    console.log(
      "[Migration] Current columns:",
      columns.map((c: any) => c.name).join(", ")
    );

    const hasPassword = columns.some((col: any) => col.name === "passwordHash");

    if (!hasPassword) {
      console.log("[Migration] Adding passwordHash column to users table...");
      db.exec(`ALTER TABLE users ADD COLUMN passwordHash TEXT;`);
      console.log("[Migration] ✅ passwordHash column added successfully");

      // Verify it was added
      const newColumns = db.prepare("PRAGMA table_info(users)").all() as any[];
      console.log(
        "[Migration] New columns:",
        newColumns.map((c: any) => c.name).join(", ")
      );
    } else {
      console.log("[Migration] ⏭️  passwordHash column already exists");
    }

    // Create default admin user if no users exist
    const userCount = db
      .prepare("SELECT COUNT(*) as count FROM users")
      .get() as any;

    if (userCount.count === 0) {
      console.log("[Migration] Creating default admin user...");
      const passwordHash = await bcrypt.hash("Admin@123456", 10);

      db.prepare(
        `
        INSERT INTO users (id, name, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `
      ).run(
        "admin_default",
        "System Administrator",
        "admin@goldpredictor.com",
        passwordHash,
        "local",
        "admin",
        Date.now(),
        Date.now()
      );

      console.log("[Migration] ✅ Default admin user created:");
      console.log("   Email: admin@goldpredictor.com");
      console.log("   Password: Admin@123456");
      console.log("   ⚠️  Please change this password after first login!");
    }
  } catch (error) {
    console.error("[Migration] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

export function down() {
  const dbPath = join(process.cwd(), "data", "asset_predictor.db");
  const db = new Database(dbPath);

  try {
    console.log("[Migration] Removing passwordHash column from users table...");
    // SQLite doesn't support DROP COLUMN directly, need to recreate table
    db.exec(`
      CREATE TABLE users_backup AS SELECT id, name, email, loginMethod, role, createdAt, lastSignedIn FROM users;
      DROP TABLE users;
      ALTER TABLE users_backup RENAME TO users;
    `);
    console.log("[Migration] ✅ passwordHash column removed successfully");
  } catch (error) {
    console.error("[Migration] ❌ Error:", error);
    throw error;
  } finally {
    db.close();
  }
}

// Run migration if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  up()
    .then(() => {
      console.log("[Migration] Migration completed successfully");
      process.exit(0);
    })
    .catch(error => {
      console.error("[Migration] Migration failed:", error);
      process.exit(1);
    });
}
