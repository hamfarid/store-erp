/**
 * Automatic Monitoring System
 * - Generates predictions every 4 hours
 * - Compares with actual prices
 * - Searches for influencing factors
 * - Sends email report to Hady.m.farid@gmail.com
 */

import * as db from "./db";

const MONITORING_INTERVAL = 4 * 60 * 60 * 1000; // 4 hours in milliseconds
const ADMIN_EMAIL = "Hady.m.farid@gmail.com";
const PYTHON_API_URL = process.env.PYTHON_API_URL || process.env.ML_SERVICE_URL || "http://localhost:2105";
const MIN_ACCURACY = 0.8; // 80% minimum

interface PredictionResult {
  assetId: number;
  assetName: string;
  currentPrice: number;
  predictedPrice: number;
  actualPrice: number;
  accuracy: number;
  difference: number;
  percentDifference: number;
}

interface MonitoringReport {
  timestamp: string;
  totalAssets: number;
  successfulPredictions: number;
  failedPredictions: number;
  averageAccuracy: number;
  results: PredictionResult[];
  influencingFactors: string[];
}

/**
 * Generate prediction for an asset
 */
async function generatePrediction(assetId: number): Promise<any> {
  try {
    const response = await fetch(`${PYTHON_API_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        assetId,
        horizon: "short",
        modelType: "ensemble",
        confidenceLevel: 0.95,
      }),
    });

    if (!response.ok) {
      throw new Error(`Python API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error(
      `[Monitoring] Failed to generate prediction for asset ${assetId}:`,
      error
    );
    return null;
  }
}

/**
 * Search for influencing factors (news, events)
 */
async function searchInfluencingFactors(
  assetName: string,
  priceDiff: number
): Promise<string[]> {
  const factors: string[] = [];

  // Simple heuristics for now
  // TODO: Integrate with news APIs

  if (Math.abs(priceDiff) > 5) {
    factors.push(
      `Large price movement detected for ${assetName}: ${priceDiff.toFixed(2)}%`
    );
  }

  if (priceDiff > 3) {
    factors.push(
      `Possible bullish sentiment or positive news for ${assetName}`
    );
  } else if (priceDiff < -3) {
    factors.push(
      `Possible bearish sentiment or negative news for ${assetName}`
    );
  }

  // Check for specific asset types
  if (assetName.includes("Gold") || assetName.includes("Silver")) {
    factors.push(
      "Precious metals may be affected by inflation concerns or safe-haven demand"
    );
  } else if (assetName.includes("Bitcoin") || assetName.includes("Ethereum")) {
    factors.push(
      "Cryptocurrency prices may be affected by regulatory news or market sentiment"
    );
  } else if (assetName.includes("Oil") || assetName.includes("Brent")) {
    factors.push(
      "Oil prices may be affected by OPEC decisions or geopolitical events"
    );
  }

  return factors;
}

/**
 * Send email report
 */
async function sendEmailReport(report: MonitoringReport): Promise<boolean> {
  try {
    // Format email content
    const emailContent = `
# Asset Price Prediction Report
**Generated:** ${report.timestamp}

## Summary
- Total Assets Monitored: ${report.totalAssets}
- Successful Predictions: ${report.successfulPredictions}
- Failed Predictions: ${report.failedPredictions}
- Average Accuracy: ${(report.averageAccuracy * 100).toFixed(2)}%

## Detailed Results

${report.results
  .map(
    r => `
### ${r.assetName}
- Current Price: $${r.currentPrice.toFixed(2)}
- Predicted Price: $${r.predictedPrice.toFixed(2)}
- Actual Price: $${r.actualPrice.toFixed(2)}
- Accuracy: ${(r.accuracy * 100).toFixed(2)}%
- Difference: ${r.difference.toFixed(2)} (${r.percentDifference.toFixed(2)}%)
`
  )
  .join("\n")}

## Influencing Factors
${report.influencingFactors.map(f => `- ${f}`).join("\n")}

---
*This is an automated report from Asset Predictor System*
`;

    // TODO: Implement actual email sending
    // For now, just log
    console.log("[Monitoring] Email Report:", emailContent);

    // Save to logs
    // Map to db logging schema
    await db.logPredictionDb({
      assetId: 0, // System-wide log
      modelType: "monitoring",
      status: "success",
      inputData: { horizon: "short", confidenceLevel: 0.95 },
      outputData: {
        predictedPrice: 0,
        actualPrice: 0,
        accuracy: report.averageAccuracy,
        report: report 
      },
      userId: "system",
      executionTime: 0
    });

    return true;
  } catch (error) {
    console.error("[Monitoring] Failed to send email:", error);
    return false;
  }
}

/**
 * Run monitoring cycle
 */
async function runMonitoringCycle(): Promise<void> {
  console.log("[Monitoring] Starting monitoring cycle...");

  try {
    // Get all assets
    const allAssets = await db.getAllAssets();
    console.log(`[Monitoring] Found ${allAssets.length} assets to monitor`);

    const results: PredictionResult[] = [];
    const allFactors: string[] = [];

    for (const asset of allAssets) {
      console.log(`[Monitoring] Processing asset: ${asset.name}`);

      // Generate prediction
      const prediction = await generatePrediction(asset.id);

      if (!prediction) {
        console.log(
          `[Monitoring] Skipping asset ${asset.name} - prediction failed`
        );
        continue;
      }

      // Calculate accuracy
      const currentPrice = prediction.currentPrice;
      const predictedPrice = prediction.predictedPrice;
      const actualPrice = currentPrice; // In real scenario, this would be fetched after 4 hours

      const difference = actualPrice - predictedPrice;
      const percentDifference = (difference / predictedPrice) * 100;
      const accuracy = 1 - Math.abs(percentDifference) / 100;

      // Check if accuracy meets minimum threshold
      if (accuracy < MIN_ACCURACY) {
        console.log(
          `[Monitoring] Asset ${asset.name} accuracy ${(accuracy * 100).toFixed(2)}% is below minimum ${MIN_ACCURACY * 100}%`
        );

        // Search for influencing factors
        const factors = await searchInfluencingFactors(
          asset.name,
          percentDifference
        );
        allFactors.push(...factors);
      }

      results.push({
        assetId: asset.id,
        assetName: asset.name,
        currentPrice,
        predictedPrice,
        actualPrice,
        accuracy,
        difference,
        percentDifference,
      });

      // Save prediction to database
      // Map extra fields to metadata if needed
      await db.insertPrediction({
        assetId: asset.id,
        userId: "system", // default for automated monitoring
        modelType: "ensemble",
        horizon: "short",
        predictedPrice,
        confidenceLevel: 0.95,
        predictionDate: new Date(prediction.targetDate).getTime(),
        accuracy: prediction.accuracy,
        metadata: JSON.stringify({
          confidenceLower: prediction.confidenceLower,
          confidenceUpper: prediction.confidenceUpper,
          daysAhead: prediction.daysAhead
        }),
        createdAt: Date.now()
      });
    }

    // Calculate summary
    const successfulPredictions = results.filter(
      r => r.accuracy >= MIN_ACCURACY
    ).length;
    const failedPredictions = results.length - successfulPredictions;
    const averageAccuracy =
      results.reduce((sum, r) => sum + r.accuracy, 0) / (results.length || 1);

    // Create report
    const report: MonitoringReport = {
      timestamp: new Date().toISOString(),
      totalAssets: results.length,
      successfulPredictions,
      failedPredictions,
      averageAccuracy,
      results,
      influencingFactors: Array.from(new Set(allFactors)), // Remove duplicates
    };

    // Send email report
    await sendEmailReport(report);

    console.log("[Monitoring] Monitoring cycle completed successfully");
  } catch (error) {
    console.error("[Monitoring] Monitoring cycle failed:", error);
  }
}

/**
 * Start monitoring system
 */
export function startMonitoringSystem(): void {
  console.log("[Monitoring] Starting automatic monitoring system...");
  console.log(
    `[Monitoring] Will run every ${MONITORING_INTERVAL / 1000 / 60 / 60} hours`
  );
  console.log(`[Monitoring] Reports will be sent to: ${ADMIN_EMAIL}`);
  console.log(
    `[Monitoring] Minimum accuracy threshold: ${MIN_ACCURACY * 100}%`
  );

  // Run immediately on start
  runMonitoringCycle();

  // Schedule to run every 4 hours
  setInterval(runMonitoringCycle, MONITORING_INTERVAL);
}

/**
 * Stop monitoring system
 */
export function stopMonitoringSystem(): void {
  console.log("[Monitoring] Stopping monitoring system...");
  // Note: In production, you'd want to track the interval ID to clear it
}
