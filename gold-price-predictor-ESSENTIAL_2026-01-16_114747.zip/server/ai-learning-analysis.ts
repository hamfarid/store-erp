/**
 * AI Learning Analysis Utilities
 * Analyze training data quality, extract keywords, calculate metrics
 */

import {
  TRAINING_EXAMPLES as trainingExamples,
  DOMAIN_KNOWLEDGE as knowledgeBase,
} from "./ai-training-data";
import { promises as fs } from "fs";
import path from "path";

export interface LearningStatistics {
  totalExamples: number;
  totalKnowledge: number;
  totalSize: number; // in bytes
  averagePromptLength: number;
  averageResponseLength: number;
  categories: Record<string, number>;
  keywords: Array<{ word: string; frequency: number }>;
  dataQuality: {
    noisePercentage: number;
    duplicatePercentage: number;
    coverageScore: number;
    completenessScore: number;
  };
  storageInfo: {
    trainingDataSize: number;
    conversationsSize: number;
    totalSize: number;
  };
}

/**
 * Extract keywords from text
 */
function extractKeywords(text: string): string[] {
  // Remove special characters and convert to lowercase
  const cleaned = text.toLowerCase().replace(/[^\u0600-\u06FFa-z0-9\s]/g, " ");

  // Split into words
  const words = cleaned.split(/\s+/).filter(w => w.length > 2);

  // Arabic stopwords
  const arabicStopwords = [
    "في",
    "من",
    "إلى",
    "على",
    "عن",
    "مع",
    "هذا",
    "هذه",
    "ذلك",
    "التي",
    "الذي",
    "هل",
    "ما",
    "كيف",
    "متى",
    "أين",
    "لماذا",
    "كم",
    "هو",
    "هي",
    "أن",
    "أو",
    "لا",
    "نعم",
    "قد",
    "كان",
    "يكون",
    "لم",
    "لن",
    "سوف",
    "the",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "have",
    "has",
    "had",
    "do",
    "does",
    "did",
    "will",
    "would",
    "should",
    "could",
    "may",
    "might",
    "must",
    "can",
    "this",
    "that",
    "these",
    "those",
    "and",
    "or",
    "but",
    "not",
    "for",
    "with",
    "from",
    "to",
    "of",
    "in",
    "on",
    "at",
    "by",
  ];

  // Filter out stopwords
  return words.filter(w => !arabicStopwords.includes(w));
}

/**
 * Calculate keyword frequency
 */
function calculateKeywordFrequency(
  texts: string[]
): Array<{ word: string; frequency: number }> {
  const frequencyMap = new Map<string, number>();

  for (const text of texts) {
    const keywords = extractKeywords(text);
    for (const keyword of keywords) {
      frequencyMap.set(keyword, (frequencyMap.get(keyword) || 0) + 1);
    }
  }

  // Convert to array and sort by frequency
  const result = Array.from(frequencyMap.entries())
    .map(([word, frequency]) => ({ word, frequency }))
    .sort((a, b) => b.frequency - a.frequency)
    .slice(0, 50); // Top 50 keywords

  return result;
}

/**
 * Calculate data noise percentage
 */
function calculateNoisePercentage(examples: any[]): number {
  let noiseCount = 0;

  for (const example of examples) {
    // Check for very short responses (likely incomplete)
    if (example.answer.length < 20) {
      noiseCount++;
      continue;
    }

    // Check for repetitive content
    const words = example.answer.split(/\s+/);
    const uniqueWords = new Set(words);
    if (uniqueWords.size < words.length * 0.3) {
      noiseCount++;
      continue;
    }

    // Check for missing context
    if (!example.question || example.question.length < 5) {
      noiseCount++;
      continue;
    }
  }

  return examples.length > 0 ? (noiseCount / examples.length) * 100 : 0;
}

/**
 * Calculate duplicate percentage
 */
function calculateDuplicatePercentage(examples: any[]): number {
  const seen = new Set<string>();
  let duplicates = 0;

  for (const example of examples) {
    const key = `${example.question}:${example.answer}`;
    if (seen.has(key)) {
      duplicates++;
    } else {
      seen.add(key);
    }
  }

  return examples.length > 0 ? (duplicates / examples.length) * 100 : 0;
}

/**
 * Calculate coverage score (how well the training data covers different topics)
 */
function calculateCoverageScore(examples: any[]): number {
  const categories = new Set<string>();

  for (const example of examples) {
    if (example.category) {
      categories.add(example.category);
    }
  }

  // Expected categories for asset prediction system
  const expectedCategories = [
    "price_prediction",
    "portfolio_management",
    "alerts",
    "technical_analysis",
    "news_analysis",
    "risk_management",
    "market_trends",
    "asset_comparison",
  ];

  const coverage = categories.size / expectedCategories.length;
  return Math.min(coverage * 100, 100);
}

/**
 * Calculate completeness score (how complete the training examples are)
 */
function calculateCompletenessScore(examples: any[]): number {
  let completeCount = 0;

  for (const example of examples) {
    // Check if example has all required fields
    const hasPrompt = example.question && example.question.length > 10;
    const hasResponse = example.answer && example.answer.length > 20;
    const hasCategory = !!example.category;

    if (hasPrompt && hasResponse && hasCategory) {
      completeCount++;
    }
  }

  return examples.length > 0 ? (completeCount / examples.length) * 100 : 0;
}

/**
 * Calculate storage size for training data
 */
async function calculateStorageSize(): Promise<{
  trainingDataSize: number;
  conversationsSize: number;
  totalSize: number;
}> {
  try {
    // Calculate training data file size
    const trainingDataPath = path.join(
      process.cwd(),
      "server",
      "ai-training-data.ts"
    );
    let trainingDataSize = 0;
    try {
      const stats = await fs.stat(trainingDataPath);
      trainingDataSize = stats.size;
    } catch {
      // File might not exist or not accessible
      trainingDataSize = 0;
    }

    // Estimate conversations size from database
    const { getDb } = await import("./db");
    const db = await getDb();
    let conversationsSize = 0;

    if (db) {
      try {
        const result = await (db as any).execute(
          "SELECT SUM(LENGTH(message) + LENGTH(response)) as total FROM ai_conversations"
        );
        conversationsSize = (result.rows[0] as any)?.total || 0;
      } catch {
        conversationsSize = 0;
      }
    }

    return {
      trainingDataSize,
      conversationsSize,
      totalSize: trainingDataSize + conversationsSize,
    };
  } catch (error) {
    console.error("Storage size calculation error:", error);
    return {
      trainingDataSize: 0,
      conversationsSize: 0,
      totalSize: 0,
    };
  }
}

/**
 * Get comprehensive learning statistics
 */
export async function getLearningStatistics(): Promise<LearningStatistics> {
  // Calculate basic statistics
  const totalExamples = trainingExamples.length;
  const totalKnowledge = knowledgeBase.length;

  // Calculate average lengths
  const totalPromptLength = trainingExamples.reduce(
    (sum, ex) => sum + ex.question.length,
    0
  );
  const totalResponseLength = trainingExamples.reduce(
    (sum, ex) => sum + ex.answer.length,
    0
  );

  const averagePromptLength =
    totalExamples > 0 ? totalPromptLength / totalExamples : 0;
  const averageResponseLength =
    totalExamples > 0 ? totalResponseLength / totalExamples : 0;

  // Count categories
  const categories: Record<string, number> = {};
  for (const example of trainingExamples) {
    if (example.category) {
      categories[example.category] = (categories[example.category] || 0) + 1;
    }
  }

  // Extract keywords
  const allTexts = [
    ...trainingExamples.map(ex => ex.question),
    ...trainingExamples.map(ex => ex.answer),
    ...knowledgeBase.map(kb => kb.content),
  ];
  const keywords = calculateKeywordFrequency(allTexts);

  // Calculate data quality metrics
  const noisePercentage = calculateNoisePercentage(trainingExamples);
  const duplicatePercentage = calculateDuplicatePercentage(trainingExamples);
  const coverageScore = calculateCoverageScore(trainingExamples);
  const completenessScore = calculateCompletenessScore(trainingExamples);

  // Calculate storage info
  const storageInfo = await calculateStorageSize();

  // Estimate total size (training data + knowledge base)
  const totalSize = JSON.stringify({ trainingExamples, knowledgeBase }).length;

  return {
    totalExamples,
    totalKnowledge,
    totalSize,
    averagePromptLength,
    averageResponseLength,
    categories,
    keywords,
    dataQuality: {
      noisePercentage,
      duplicatePercentage,
      coverageScore,
      completenessScore,
    },
    storageInfo,
  };
}

/**
 * Search training examples by keyword
 */
export function searchTrainingExamples(keyword: string): any[] {
  const lowerKeyword = keyword.toLowerCase();
  return trainingExamples.filter(
    ex =>
      ex.question.toLowerCase().includes(lowerKeyword) ||
      ex.answer.toLowerCase().includes(lowerKeyword) ||
      ex.category?.toLowerCase().includes(lowerKeyword)
  );
}

/**
 * Get training examples by category
 */
export function getExamplesByCategory(category: string): any[] {
  return trainingExamples.filter(ex => ex.category === category);
}

/**
 * Get knowledge base by topic
 */
export function getKnowledgeByTopic(topic: string): any[] {
  const lowerTopic = topic.toLowerCase();
  return knowledgeBase.filter(kb =>
    kb.topic.toLowerCase().includes(lowerTopic)
  );
}

/**
 * Validate training example
 */
export function validateTrainingExample(example: {
  question: string;
  answer: string;
  category?: string;
}): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!example.question || example.question.trim().length < 10) {
    errors.push("Question must be at least 10 characters");
  }

  if (!example.answer || example.answer.trim().length < 20) {
    errors.push("Answer must be at least 20 characters");
  }

  if (example.category && example.category.trim().length === 0) {
    errors.push("Category cannot be empty if provided");
  }

  // Check for repetitive content
  if (example.answer) {
    const words = example.answer.split(/\s+/);
    const uniqueWords = new Set(words);
    if (uniqueWords.size < words.length * 0.3) {
      errors.push("Response appears to be repetitive");
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Get data quality recommendations
 */
export function getQualityRecommendations(stats: LearningStatistics): string[] {
  const recommendations: string[] = [];

  if (stats.dataQuality.noisePercentage > 20) {
    recommendations.push(
      `نسبة التشوه عالية (${stats.dataQuality.noisePercentage.toFixed(1)}%). يُنصح بمراجعة وتنظيف البيانات.`
    );
  }

  if (stats.dataQuality.duplicatePercentage > 10) {
    recommendations.push(
      `يوجد ${stats.dataQuality.duplicatePercentage.toFixed(1)}% بيانات مكررة. يُنصح بإزالة التكرارات.`
    );
  }

  if (stats.dataQuality.coverageScore < 60) {
    recommendations.push(
      `التغطية منخفضة (${stats.dataQuality.coverageScore.toFixed(1)}%). أضف أمثلة لفئات جديدة.`
    );
  }

  if (stats.dataQuality.completenessScore < 80) {
    recommendations.push(
      `الاكتمال منخفض (${stats.dataQuality.completenessScore.toFixed(1)}%). تأكد من اكتمال جميع الحقول.`
    );
  }

  if (stats.totalExamples < 50) {
    recommendations.push(
      `عدد الأمثلة قليل (${stats.totalExamples}). يُنصح بإضافة المزيد من أمثلة التدريب.`
    );
  }

  if (recommendations.length === 0) {
    recommendations.push("جودة البيانات جيدة! استمر في إضافة أمثلة متنوعة.");
  }

  return recommendations;
}
