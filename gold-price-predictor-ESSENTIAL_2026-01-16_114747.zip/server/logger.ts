import * as db from "./db";

/**
 * Log an error to the database
 */
export async function logError(params: {
  level?: "error" | "warn" | "info";
  source: string;
  component: string;
  message: string;
  stack?: string;
  userId?: string;
  metadata?: Record<string, any>;
}) {
  try {
    await db.logErrorDb({
      level: params.level || "error",
      source: params.source,
      component: params.component,
      message: params.message,
      stack: params.stack,
      userId: params.userId,
      metadata: params.metadata ? JSON.stringify(params.metadata) : null,
    });

    // Also log to console
    console.error(`[${params.source}/${params.component}]`, params.message);
    if (params.stack) {
      console.error(params.stack);
    }
  } catch (error) {
    // Fallback to console if DB logging fails
    console.error("[Logger] Failed to log error:", error);
    console.error("[Original Error]", params);
  }
}

/**
 * Log ML training session
 */
export async function logMLTraining(params: {
  assetId: number;
  modelType: string;
  trainingDuration?: number;
  trainScore?: string;
  testScore?: string;
  mape?: string;
  hyperparameters?: Record<string, any>;
  datasetSize?: number;
  status: "started" | "completed" | "failed";
  errorMessage?: string;
}) {
  try {
    const result = await db.logMLTrainingDb({
      assetId: params.assetId,
      modelType: params.modelType,
      trainingDuration: params.trainingDuration,
      trainScore: params.trainScore,
      testScore: params.testScore,
      mape: params.mape,
      hyperparameters: params.hyperparameters
        ? JSON.stringify(params.hyperparameters)
        : null,
      datasetSize: params.datasetSize,
      status: params.status,
      errorMessage: params.errorMessage,
    });

    console.log(
      `[ML Training] ${params.modelType} for asset ${params.assetId}: ${params.status}`
    );
    return result;
  } catch (error) {
    console.error("[Logger] Failed to log ML training:", error);
  }
}

/**
 * Log prediction
 */
export async function logPrediction(params: {
  predictionId?: number;
  assetId: number;
  modelType: string;
  inputData?: Record<string, any>;
  outputData?: Record<string, any>;
  executionTime?: number;
  userId?: string;
  status: "success" | "failed";
  errorMessage?: string;
}) {
  try {
    const result = await db.logPredictionDb({
      predictionId: params.predictionId,
      assetId: params.assetId,
      modelType: params.modelType,
      inputData: params.inputData ? JSON.stringify(params.inputData) : null,
      outputData: params.outputData ? JSON.stringify(params.outputData) : null,
      executionTime: params.executionTime,
      userId: params.userId,
      status: params.status,
      errorMessage: params.errorMessage,
    });

    console.log(
      `[Prediction] ${params.modelType} for asset ${params.assetId}: ${params.status}`
    );
    return result;
  } catch (error) {
    console.error("[Logger] Failed to log prediction:", error);
  }
}

/**
 * Log API request
 */
export async function logAPIRequest(params: {
  method: string;
  endpoint: string;
  userId?: string;
  statusCode: number;
  responseTime: number;
  ipAddress?: string;
  userAgent?: string;
  errorMessage?: string;
}) {
  try {
    await db.logAPIRequestDb({
      method: params.method,
      endpoint: params.endpoint,
      userId: params.userId,
      statusCode: params.statusCode,
      responseTime: params.responseTime,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
      errorMessage: params.errorMessage,
    });
  } catch (error) {
    console.error("[Logger] Failed to log API request:", error);
  }
}

/**
 * Get recent errors
 */
export async function getRecentErrors(limit: number = 50) {
  return await db.getRecentErrors(limit);
}

/**
 * Get ML training history
 */
export async function getMLTrainingHistory(
  assetId?: number,
  limit: number = 50
) {
  return await db.getMLTrainingHistory(assetId, limit);
}

/**
 * Get prediction history with logs
 */
export async function getPredictionHistory(
  userId?: string,
  limit: number = 50
) {
  return await db.getPredictionLogs(userId, limit);
}

/**
 * Get API request statistics
 */
export async function getAPIStats(hours: number = 24) {
  return await db.getAPIStats(hours);
}
