/**
 * AI Scheduled Tasks Database Operations
 * REFACTORED: To use db-compat raw queries
 */

import { query, usePostgres } from "./db-compat";
import type { InsertAIScheduledTask } from "../drizzle/schema"; // Type only

// Helper for Boolean values (SQLite uses 0/1)
function bool(val: boolean | number | undefined | null) {
  if (val === undefined || val === null) {return null;}
  if (usePostgres) {return !!val;}
  return val ? 1 : 0;
}

// Helper for JSON fields (SQLite uses string)
function prepJson(val: any) {
  if (val === undefined || val === null) {return null;}
  if (usePostgres) {return val;}
  return typeof val === 'string' ? val : JSON.stringify(val);
}

// Columns quoted for Postgres case sensitivity (matching Drizzle schema)
const TASK_COLS = `"id", "userId", "assistantId", "taskName", "description", "taskType", "taskConfig", "scheduleType", "cronExpression", "timezone", "isActive", "lastRunAt", "nextRunAt", "notifyOnCompletion", "notifyOnError", "createdAt", "updatedAt"`;
const RESULT_COLS = `"id", "taskId", "status", "result", "errorMessage", "executionTime", "tokensUsed", "executedAt"`;

/**
 * Create a new scheduled task
 */
export async function createScheduledTask(data: InsertAIScheduledTask) {
  const fields = ["userId", "assistantId", "taskName", "description", "taskType", "taskConfig", "scheduleType", "cronExpression", "timezone", "isActive", "notifyOnCompletion", "notifyOnError"];
  const vals = [
    data.userId, 
    data.assistantId || 1, 
    data.taskName, 
    data.description || null, 
    data.taskType, 
    prepJson(data.taskConfig), 
    data.scheduleType, 
    data.cronExpression, 
    data.timezone || "UTC",
    bool(data.isActive ?? true), 
    bool(data.notifyOnCompletion ?? true), 
    bool(data.notifyOnError ?? true)
  ];

  const cols = fields.map(f => `"${f}"`).join(',');
  const ph = fields.map(() => '?').join(',');
  const sql = `INSERT INTO ai_scheduled_tasks (${cols}) VALUES (${ph})`;

  if (usePostgres) {
    const res = await query(sql + ' RETURNING id', vals);
    return getScheduledTask(res.rows[0].id, data.userId);
  }
  
  const res = await query(sql, vals);
  return getScheduledTask(res.lastInsertRowid as number, data.userId);
}

/**
 * Get user's scheduled tasks
 */
export async function getUserScheduledTasks(userId: string) {
  const sql = `SELECT ${TASK_COLS} FROM ai_scheduled_tasks WHERE "userId" = ? ORDER BY "createdAt" DESC`;
  const res = await query(sql, [userId]);
  return res.rows.map(mapTask);
}

/**
 * Get single scheduled task
 */
export async function getScheduledTask(taskId: number, userId: string) {
  const sql = `SELECT ${TASK_COLS} FROM ai_scheduled_tasks WHERE "id" = ? AND "userId" = ?`;
  const res = await query(sql, [taskId, userId]);
  if (res.rows.length === 0) {return null;}
  return mapTask(res.rows[0]);
}

/**
 * Update scheduled task
 */
export async function updateScheduledTask(
  taskId: number,
  userId: string,
  data: Partial<InsertAIScheduledTask>
) {
  const fields: string[] = [];
  const vals: any[] = [];

  if (data.taskName !== undefined) { fields.push('"taskName" = ?'); vals.push(data.taskName); }
  if (data.description !== undefined) { fields.push('"description" = ?'); vals.push(data.description); }
  if (data.assistantId !== undefined) { fields.push('"assistantId" = ?'); vals.push(data.assistantId); }
  if (data.taskType !== undefined) { fields.push('"taskType" = ?'); vals.push(data.taskType); }
  if (data.taskConfig !== undefined) { fields.push('"taskConfig" = ?'); vals.push(prepJson(data.taskConfig)); }
  if (data.scheduleType !== undefined) { fields.push('"scheduleType" = ?'); vals.push(data.scheduleType); }
  if (data.cronExpression !== undefined) { fields.push('"cronExpression" = ?'); vals.push(data.cronExpression); }
  if (data.timezone !== undefined) { fields.push('"timezone" = ?'); vals.push(data.timezone); }
  
  if (data.isActive !== undefined) { fields.push('"isActive" = ?'); vals.push(bool(data.isActive)); }
  if (data.notifyOnCompletion !== undefined) { fields.push('"notifyOnCompletion" = ?'); vals.push(bool(data.notifyOnCompletion)); }
  if (data.notifyOnError !== undefined) { fields.push('"notifyOnError" = ?'); vals.push(bool(data.notifyOnError)); }
  
  if (data.lastRunAt !== undefined) { 
      fields.push('"lastRunAt" = ?'); 
      vals.push(data.lastRunAt instanceof Date ? data.lastRunAt : new Date(data.lastRunAt as any)); 
  }
  if (data.nextRunAt !== undefined) { 
      fields.push('"nextRunAt" = ?'); 
      vals.push(data.nextRunAt instanceof Date ? data.nextRunAt : new Date(data.nextRunAt as any)); 
  }

  fields.push('"updatedAt" = ?'); vals.push(new Date());
  
  if (fields.length === 1) {return;} // nothing to update

  vals.push(taskId, userId);
  
  const sql = `UPDATE ai_scheduled_tasks SET ${fields.join(', ')} WHERE "id" = ? AND "userId" = ?`;
  await query(sql, vals);
}

/**
 * Delete scheduled task
 */
export async function deleteScheduledTask(taskId: number, userId: string) {
  // Delete results first
  await query(`DELETE FROM ai_task_results WHERE "taskId" = ?`, [taskId]);
  // Delete task
  await query(`DELETE FROM ai_scheduled_tasks WHERE "id" = ? AND "userId" = ?`, [taskId, userId]);
}

/**
 * Get task results
 */
export async function getTaskResults(taskId: number, limit: number = 10) {
  const sql = `SELECT ${RESULT_COLS} FROM ai_task_results WHERE "taskId" = ? ORDER BY "executedAt" DESC LIMIT ?`;
  const res = await query(sql, [taskId, limit]);
  return res.rows.map(mapResult);
}

/**
 * Get all active tasks (system level)
 */
export async function getActiveTasks() {
  const isActiveVal = usePostgres ? true : 1;
  const sql = `SELECT ${TASK_COLS} FROM ai_scheduled_tasks WHERE "isActive" = ?`;
  const res = await query(sql, [isActiveVal]);
  return res.rows.map(mapTask);
}

// Mappers
function mapTask(row: any) {
  return {
    ...row,
    isActive: row.isActive === 1 || row.isActive === true,
    notifyOnCompletion: row.notifyOnCompletion === 1 || row.notifyOnCompletion === true,
    notifyOnError: row.notifyOnError === 1 || row.notifyOnError === true,
    taskConfig: (typeof row.taskConfig === 'string') ? JSON.parse(row.taskConfig) : row.taskConfig,
    createdAt: new Date(row.createdAt),
    updatedAt: new Date(row.updatedAt),
    lastRunAt: row.lastRunAt ? new Date(row.lastRunAt) : null,
    nextRunAt: row.nextRunAt ? new Date(row.nextRunAt) : null,
  };
}

function mapResult(row: any) {
  return {
    ...row,
    executedAt: new Date(row.executedAt),
  };
}
