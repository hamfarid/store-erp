/**
 * AI Scheduler - Manages scheduled AI tasks with cron jobs
 */

import * as cron from "node-cron";
import * as db from "./db-compat";
import { FreeAIAssistant } from "./ai-free";
import { PaidAIAssistant } from "./ai-paid";

interface ScheduledTask {
  id: number;
  userId: string;
  taskName: string;
  taskType:
    | "price_analysis"
    | "portfolio_report"
    | "news_summary"
    | "prediction_update"
    | "alert_check"
    | "custom_query";
  scheduleType: "daily" | "weekly" | "monthly" | "custom";
  cronExpression: string;
  assistantId: number | null;
  taskConfig: string | null;
  isActive: boolean;
}

class AIScheduler {
  private jobs: Map<number, any> = new Map();
  private isInitialized = false;

  /**
   * Initialize scheduler and load all active tasks
   */
  async initialize() {
    if (this.isInitialized) {
      console.log("[AIScheduler] Already initialized");
      return;
    }

    console.log("[AIScheduler] Initializing...");

    try {
      // Load all active tasks
      const tasks = await db.getActiveScheduledTasks() as ScheduledTask[];

      console.log(`[AIScheduler] Found ${tasks.length} active tasks`);

      for (const task of tasks) {
        await this.scheduleTask(task);
      }

      this.isInitialized = true;
      console.log("[AIScheduler] Initialization complete");
    } catch (error) {
      console.error("[AIScheduler] Initialization failed:", error);
    }
  }

  /**
   * Schedule a task
   */
  async scheduleTask(task: ScheduledTask) {
    try {
      // Validate cron expression
      if (!cron.validate(task.cronExpression)) {
        console.error(
          `[AIScheduler] Invalid cron expression for task ${task.id}: ${task.cronExpression}`
        );
        return;
      }

      // Remove existing job if any
      if (this.jobs.has(task.id)) {
        this.jobs.get(task.id)?.stop();
        this.jobs.delete(task.id);
      }

      // Create new cron job
      const job = cron.schedule(task.cronExpression, async () => {
        await this.executeTask(task);
      });

      this.jobs.set(task.id, job);
      console.log(
        `[AIScheduler] Scheduled task ${task.id} (${task.taskName}) with cron: ${task.cronExpression}`
      );
    } catch (error) {
      console.error(`[AIScheduler] Failed to schedule task ${task.id}:`, error);
    }
  }

  /**
   * Execute a scheduled task
   */
  private async executeTask(task: ScheduledTask) {
    const startTime = Date.now();
    console.log(
      `[AIScheduler] Executing task ${task.id} (${task.taskName})...`
    );

    try {
      // Build prompt based on task type
      const prompt = this.buildPrompt(task);

      // Get AI assistant (free or paid)
      const assistant =
        task.assistantId === 1 || !task.assistantId
          ? new FreeAIAssistant()
          : new PaidAIAssistant();

      // Execute AI query
      const response = await assistant.chat(task.userId, prompt);

      const executionTime = Date.now() - startTime;

      // Save result
      await db.insertTaskResult({
        taskId: task.id,
        result: response.message,
        status: "success",
        executionTime,
        tokensUsed: response.tokensUsed,
      });

      // Update task's last run and next run
      const nextRun = this.calculateNextRun(task.cronExpression);
      await db.updateScheduledTask(task.id, {
        lastRunAt: new Date(),
        nextRunAt: nextRun,
        updatedAt: new Date(),
      });

      console.log(
        `[AIScheduler] Task ${task.id} completed successfully in ${executionTime}ms`
      );
    } catch (error: any) {
      const executionTime = Date.now() - startTime;
      console.error(`[AIScheduler] Task ${task.id} failed:`, error);

      // Save error result
      await db.insertTaskResult({
        taskId: task.id,
        result: null,
        status: "error",
        executionTime,
        errorMessage: error.message || "Unknown error",
      });
    }
  }

  /**
   * Build prompt based on task type
   */
  private buildPrompt(task: ScheduledTask): string {
    const params = task.taskConfig ? JSON.parse(task.taskConfig) : {};

    switch (task.taskType) {
      case "price_analysis":
        return `قم بتحليل شامل لأسعار ${params.assetName || "الأصول"} الحالية. اذكر الاتجاهات، العوامل المؤثرة، والتوقعات قصيرة المدى.`;

      case "portfolio_report":
        return `أنشئ تقرير شامل عن أداء المحفظة الاستثمارية. اذكر القيمة الحالية، العائد على الاستثمار، توزيع الأصول، والتوصيات.`;

      case "news_summary":
        return `لخص أهم الأخبار الاقتصادية والمالية اليوم التي قد تؤثر على أسعار ${params.assetName || "الأصول"}. ركز على الأحداث عالية التأثير.`;

      case "prediction_update":
        return `حدّث التوقعات لأسعار ${params.assetName || "الأصول"} بناءً على آخر البيانات والأخبار. اذكر التغييرات الرئيسية والأسباب.`;

      case "alert_check":
        return `تحقق من التنبيهات النشطة وأبلغني بأي تنبيهات قريبة من التفعيل أو تم تفعيلها مؤخراً.`;

      case "custom_query":
        return params.query || "قم بتحليل عام للسوق";

      default:
        return "قم بتحليل عام للسوق";
    }
  }

  /**
   * Calculate next run time based on cron expression
   */
  private calculateNextRun(cronExpression: string): Date {
    // Simple calculation - in production, use a proper cron parser
    const now = new Date();
    const nextRun = new Date(now.getTime() + 24 * 60 * 60 * 1000); // Default: 24 hours from now
    return nextRun;
  }

  /**
   * Unschedule a task
   */
  async unscheduleTask(taskId: number) {
    if (this.jobs.has(taskId)) {
      this.jobs.get(taskId)?.stop();
      this.jobs.delete(taskId);
      console.log(`[AIScheduler] Unscheduled task ${taskId}`);
    }
  }

  /**
   * Reschedule a task (update)
   */
  async rescheduleTask(task: ScheduledTask) {
    await this.unscheduleTask(task.id);
    if (task.isActive) {
      await this.scheduleTask(task);
    }
  }

  /**
   * Stop all scheduled tasks
   */
  stopAll() {
    console.log(
      `[AIScheduler] Stopping all ${this.jobs.size} scheduled tasks...`
    );
    for (const [taskId, job] of Array.from(this.jobs.entries())) {
      job.stop();
    }
    this.jobs.clear();
    this.isInitialized = false;
    console.log("[AIScheduler] All tasks stopped");
  }

  /**
   * Get scheduler status
   */
  getStatus() {
    return {
      isInitialized: this.isInitialized,
      activeJobs: this.jobs.size,
      jobIds: Array.from(this.jobs.keys()),
    };
  }
}

// Singleton instance
export const aiScheduler = new AIScheduler();

// Auto-initialize on module load (enabled now that we have compatible helpers)
aiScheduler.initialize().catch(console.error);
