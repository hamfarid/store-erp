// This file is now a proxy to the compatibility layer
// which supports both SQLite and PostgreSQL (via Docker).
// Legacy Drizzle code should be refactored to use the helpers exported here.

export * from "./db-compat";
