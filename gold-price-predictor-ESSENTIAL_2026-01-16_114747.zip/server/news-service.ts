/**
 * News Service
 * Searches for financial/economic/political news and analyzes their impact
 */

import { invokeLLM } from "./_core/llm";

export interface NewsArticle {
  title: string;
  description: string;
  url: string;
  publishedAt: string;
  source: string;
  category: "political" | "economic" | "financial";
  sentiment?: "positive" | "negative" | "neutral";
  impact?: "high" | "medium" | "low";
}

export interface NewsEvent {
  type: string;
  description: string;
  severity: "high" | "medium" | "low";
  sentiment: "positive" | "negative" | "neutral";
  relatedAssets: string[];
  timestamp: Date;
}

export class NewsService {
  private cache: Map<string, { data: any; timestamp: number }> = new Map();
  private readonly CACHE_DURATION = 30 * 60 * 1000; // 30 minutes

  /**
   * Search for news using Google search (free alternative)
   */
  async searchNews(
    query: string,
    category: "political" | "economic" | "financial" = "economic",
    limit: number = 10
  ): Promise<NewsArticle[]> {
    const cacheKey = `news_${query}_${category}`;
    const cached = this.getFromCache(cacheKey);
    if (cached) {return cached;}

    try {
      // Use Gemini to search for and summarize recent news
      const prompt = `
        ابحث عن آخر الأخبار ${category === "political" ? "السياسية" : category === "economic" ? "الاقتصادية" : "المالية"} 
        المتعلقة بـ: ${query}
        
        أرجع قائمة بأهم ${limit} أخبار في صيغة JSON:
        [
          {
            "title": "عنوان الخبر",
            "description": "ملخص قصير",
            "source": "مصدر الخبر",
            "publishedAt": "تاريخ النشر",
            "category": "${category}"
          }
        ]
        
        ركز على الأخبار الحديثة (آخر 7 أيام) والمؤثرة على الأسعار.
      `;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content:
              "أنت محلل أخبار مالية متخصص. أرجع فقط JSON صالح بدون أي نص إضافي.",
          },
          { role: "user", content: prompt },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "news_articles",
            strict: true,
            schema: {
              type: "object",
              properties: {
                articles: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      source: { type: "string" },
                      publishedAt: { type: "string" },
                      category: { type: "string" },
                    },
                    required: [
                      "title",
                      "description",
                      "source",
                      "publishedAt",
                      "category",
                    ],
                    additionalProperties: false,
                  },
                },
              },
              required: ["articles"],
              additionalProperties: false,
            },
          },
        },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {return [];}

      const parsed = JSON.parse(content as string);
      const articles: NewsArticle[] = parsed.articles.map((a: any) => ({
        ...a,
        url: `https://www.google.com/search?q=${encodeURIComponent(a.title)}`,
        category,
      }));

      this.saveToCache(cacheKey, articles);
      return articles;
    } catch (error) {
      console.error("[NewsService] Failed to search news:", error);
      return [];
    }
  }

  /**
   * Analyze sentiment of text using Gemini
   */
  async analyzeSentiment(
    text: string
  ): Promise<"positive" | "negative" | "neutral"> {
    try {
      const prompt = `
        حلل المشاعر (sentiment) للنص التالي وحدد إذا كان:
        - positive (إيجابي): أخبار جيدة، نمو، ارتفاع
        - negative (سلبي): أخبار سيئة، انخفاض، مشاكل
        - neutral (محايد): معلومات عادية بدون تأثير واضح
        
        النص: "${text}"
        
        أرجع كلمة واحدة فقط: positive أو negative أو neutral
      `;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "أنت محلل مشاعر متخصص. أرجع كلمة واحدة فقط.",
          },
          { role: "user", content: prompt },
        ],
      });

      const sentiment = (response.choices[0]?.message?.content as string)
        ?.trim()
        .toLowerCase();

      if (sentiment?.includes("positive")) {return "positive";}
      if (sentiment?.includes("negative")) {return "negative";}
      return "neutral";
    } catch (error) {
      console.error("[NewsService] Failed to analyze sentiment:", error);
      return "neutral";
    }
  }

  /**
   * Extract important events from news articles
   */
  async extractEvents(articles: NewsArticle[]): Promise<NewsEvent[]> {
    if (articles.length === 0) {return [];}

    try {
      const articlesText = articles
        .map(a => `${a.title}: ${a.description}`)
        .join("\n\n");

      const prompt = `
        من الأخبار التالية، استخرج الأحداث المهمة التي قد تؤثر على أسعار الأصول المالية:
        
        ${articlesText}
        
        أرجع قائمة JSON بالأحداث:
        [
          {
            "type": "نوع الحدث (مثل: قرار بنك مركزي، حرب، اتفاقية تجارية)",
            "description": "وصف مختصر",
            "severity": "high أو medium أو low",
            "sentiment": "positive أو negative أو neutral",
            "relatedAssets": ["Gold", "Oil", "USD", إلخ]
          }
        ]
        
        ركز على الأحداث ذات التأثير العالي (high severity).
      `;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "أنت محلل أحداث مالية. أرجع فقط JSON صالح.",
          },
          { role: "user", content: prompt },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "news_events",
            strict: true,
            schema: {
              type: "object",
              properties: {
                events: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      type: { type: "string" },
                      description: { type: "string" },
                      severity: { type: "string" },
                      sentiment: { type: "string" },
                      relatedAssets: {
                        type: "array",
                        items: { type: "string" },
                      },
                    },
                    required: [
                      "type",
                      "description",
                      "severity",
                      "sentiment",
                      "relatedAssets",
                    ],
                    additionalProperties: false,
                  },
                },
              },
              required: ["events"],
              additionalProperties: false,
            },
          },
        },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {return [];}

      const parsed = JSON.parse(content as string);
      return parsed.events.map((e: any) => ({
        ...e,
        timestamp: new Date(),
      }));
    } catch (error) {
      console.error("[NewsService] Failed to extract events:", error);
      return [];
    }
  }

  /**
   * Get comprehensive analysis for an asset
   */
  async getAssetNewsAnalysis(assetName: string, assetSymbol: string) {
    // Search for news
    const [economicNews, politicalNews, financialNews] = await Promise.all([
      this.searchNews(`${assetName} ${assetSymbol}`, "economic", 5),
      this.searchNews(`${assetName} ${assetSymbol}`, "political", 5),
      this.searchNews(`${assetName} ${assetSymbol}`, "financial", 5),
    ]);

    const allNews = [...economicNews, ...politicalNews, ...financialNews];

    // Analyze sentiment for each article
    for (const article of allNews) {
      article.sentiment = await this.analyzeSentiment(
        article.title + " " + article.description
      );
    }

    // Extract events
    const events = await this.extractEvents(allNews);

    // Calculate overall sentiment
    const sentiments = allNews.map(a => a.sentiment).filter(Boolean);
    const positiveCount = sentiments.filter(s => s === "positive").length;
    const negativeCount = sentiments.filter(s => s === "negative").length;

    let overallSentiment: "positive" | "negative" | "neutral" = "neutral";
    if (positiveCount > negativeCount) {overallSentiment = "positive";}
    else if (negativeCount > positiveCount) {overallSentiment = "negative";}

    return {
      assetName,
      assetSymbol,
      news: allNews,
      events,
      overallSentiment,
      summary: {
        totalArticles: allNews.length,
        positiveArticles: positiveCount,
        negativeArticles: negativeCount,
        neutralArticles: sentiments.length - positiveCount - negativeCount,
        highImpactEvents: events.filter(e => e.severity === "high").length,
      },
    };
  }

  /**
   * Cache helpers
   */
  private getFromCache(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) {return null;}

    const now = Date.now();
    if (now - cached.timestamp > this.CACHE_DURATION) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  private saveToCache(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    });
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }
}

// Export singleton instance
export const newsService = new NewsService();
