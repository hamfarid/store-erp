/**
 * Free AI Assistant (Gemini)
 * Limited features with 10 messages per day
 */

import { AIAssistantBase, ChatContext } from "./ai-assistant";
import { FREE_AI_PERMISSIONS } from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";
import { getFreeAIWelcomeMessage } from "./ai-free-welcome";

export class FreeAIAssistant extends AIAssistantBase {
  constructor() {
    super(
      1, // ID
      "مساعد مجاني",
      "free",
      "gemini-2.5-flash",
      `أنت مساعد ذكاء اصطناعي مجاني متخصص في الأصول المالية والتوقعات.

**دورك:**
- الإجابة على أسئلة عامة عن الأسعار والأصول المالية
- شرح مفاهيم التداول الأساسية بطريقة بسيطة
- تقديم نصائح عامة (غير مخصصة)
- مساعدة المستخدمين في فهم واجهة المنصة

**قيودك:**
- لا يمكنك إنشاء توقعات مخصصة
- لا يمكنك الوصول لبيانات المستخدم الخاصة
- لا يمكنك البحث عن الأخبار الحديثة
- لديك حد أقصى 10 رسائل يومياً

**أسلوبك:**
- استخدم اللغة العربية الفصحى البسيطة
- كن ودوداً ومساعداً
- اشرح المفاهيم بطريقة واضحة
- اقترح الترقية للنسخة المدفوعة للميزات المتقدمة عند الحاجة

**مثال على إجاباتك:**
- "الذهب هو معدن ثمين يُستخدم كملاذ آمن في أوقات عدم الاستقرار الاقتصادي..."
- "لفهم التوقعات بشكل أفضل، يمكنك الترقية للمساعد المدفوع الذي يوفر تحليلات مخصصة..."`,
      FREE_AI_PERMISSIONS
    );
  }

  /**
   * Get welcome message with assistant info
   */
  getWelcomeMessage(): string {
    return getFreeAIWelcomeMessage(this.name);
  }

  /**
   * Override callAI to use Gemini
   */
  protected async callAI(
    message: string,
    context: ChatContext
  ): Promise<string> {
    // Build context string
    let contextStr = this.buildContextString(context);

    // Add reminder about limitations
    contextStr +=
      "\n\n**تذكير:** أنت المساعد المجاني. لا تقدم توقعات مخصصة أو تحليلات أخبار. اقترح الترقية للميزات المتقدمة.";

    try {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: this.systemPrompt + contextStr },
          { role: "user", content: message },
        ],
      });

      let answer =
        (response.choices[0]?.message?.content as string) ||
        "عذراً، لم أتمكن من معالجة طلبك.";

      // Add upgrade suggestion for advanced queries
      if (this.shouldSuggestUpgrade(message)) {
        answer +=
          "\n\n💎 **للحصول على تحليل أعمق وتوقعات مخصصة، جرب المساعد المدفوع!**";
      }

      return answer;
    } catch (error) {
      console.error("[FreeAI] Error calling Gemini:", error);
      return "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.";
    }
  }

  /**
   * Build context string from ChatContext
   */
  private buildContextString(context: ChatContext): string {
    let contextStr = "";

    if (context.currentPrices && context.currentPrices.length > 0) {
      contextStr += "\n\n**الأسعار المتاحة:**\n";
      context.currentPrices.forEach(asset => {
        contextStr += `- ${asset.name} (${asset.symbol}): ${asset.category}\n`;
      });
    }

    if (context.predictions && context.predictions.length > 0) {
      contextStr += "\n\n**آخر التوقعات العامة:**\n";
      contextStr += `عدد التوقعات: ${context.predictions.length}\n`;
      contextStr +=
        "ملاحظة: لا يمكنك عرض تفاصيل التوقعات في النسخة المجانية.\n";
    }

    return contextStr;
  }

  /**
   * Check if message requires advanced features
   */
  private shouldSuggestUpgrade(message: string): boolean {
    const advancedKeywords = [
      "توقع",
      "تنبؤ",
      "أخبار",
      "تحليل",
      "محفظة",
      "استثمار",
      "predict",
      "forecast",
      "news",
      "analysis",
      "portfolio",
    ];

    return advancedKeywords.some(keyword =>
      message.toLowerCase().includes(keyword)
    );
  }
}

// Export singleton instance
export const freeAI = new FreeAIAssistant();
