import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import {
  publicProcedure,
  protectedProcedure,
  adminProcedure,
  router,
} from "./_core/trpc";
import { z } from "zod";
import * as db from "./db-compat";
import { exportRouter } from "./routers-export";
import { logsRouter } from "./routers-logs";
import { dashboardRouter } from "./routers/dashboard-router";
import { notificationsRouter } from "./routers/notifications";
import { aiRouter } from "./routers/ai-router";
import { portfolioRouter } from "./routers/portfolio-router";
import { aiTasksRouter } from "./routers/ai-tasks-router";
import { settingsRouter } from "./routers/settings-router";
import { reportsRouter } from "./routers/reports-router";
import { adminRouter } from "./routers/admin-router";
import { technicalIndicatorsRouter } from "./routers/technical-indicators-router";
import { comprehensiveRouter } from "./routers/comprehensive-router";
import { predictionsRouter } from "./routers/predictions-router";
import { driftRouter } from "./routers/drift";
import { learningPathRouter } from "./routers/learning-path";
import { expertOpinionsRouter } from "./routers/expert-opinions";
import { securityRouter } from "./routers/security-router";
import { modelsRouter } from "./routers/models";
import { fearGreedRouter } from "./routers/fear-greed-router";
import { newsSentimentRouter } from "./routers/news-sentiment-router";
import { learningControlRouter } from "./routers/learning-control";
import { eventsRouter } from "./routers/events";
import { learningRouter } from "./routers/learning";
import { cacheRouter } from "./routers/cache";
import { twoFactorRouter } from "./routers/twoFactor";
import {
  exportDatabase,
  importDatabase,
  exportAITrainingData,
  importAITrainingData,
  createFullBackup,
  restoreFullBackup,
  listBackups,
  deleteBackup,
} from "./backup-utils";
import {
  saveBackup,
  exportNewsData,
  importNewsData,
  exportAIConversations,
  importAIConversations,
  getAvailableStorageOptions,
  type BackupStorageType,
} from "./backup-advanced";
import {
  getLearningStatistics,
  searchTrainingExamples,
  getExamplesByCategory,
  getKnowledgeByTopic,
  validateTrainingExample,
  getQualityRecommendations,
} from "./ai-learning-analysis";
import {
  TRAINING_EXAMPLES as trainingExamples,
  DOMAIN_KNOWLEDGE as knowledgeBase,
} from "./ai-training-data";
import {
  logAuditEvent,
  getAuditLogs,
  getLearningDataTrends,
  getPriceAnalytics,
  getPriceHistory,
  getAssetsComparison,
  getPortfolioPerformance,
  getAuditSummary,
  initializeAuditTable,
} from "./audit-monitoring";

export const appRouter = router({
  system: systemRouter,
  export: exportRouter,
  logs: logsRouter,
  dashboard: dashboardRouter,
  notifications: notificationsRouter,
  ai: aiRouter,
  aiTasks: aiTasksRouter,
  portfolio: portfolioRouter,
  settings: settingsRouter,
  reports: reportsRouter,
  admin: adminRouter,
  technicalIndicators: technicalIndicatorsRouter,
  predictions: predictionsRouter, // Alias for backward compatibility
  predictionsAdvanced: predictionsRouter,
  drift: driftRouter,
  learningPath: learningPathRouter,
  expertOpinions: expertOpinionsRouter,
  security: securityRouter,
  models: modelsRouter,
  fearGreed: fearGreedRouter,
  newsSentiment: newsSentimentRouter,
  learningControl: learningControlRouter,
  events: eventsRouter,
  learning: learningRouter,
  cache: cacheRouter,
  twoFactor: twoFactorRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),

    logout: publicProcedure.mutation(async ({ ctx }) => {
      // Invalidate session security
      if (ctx.user) {
        const { invalidateSession, logSecurityEvent } = await import(
          "./_core/security"
        );
        invalidateSession(ctx.user.id);
        logSecurityEvent("logout", ctx.user.id, ctx.req);
      }

      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),

    // Local authentication
    register: publicProcedure
      .input(
        z.object({
          name: z.string().min(2).max(100),
          email: z.string().email(),
          password: z.string().min(8),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const {
          hashPassword,
          generateUserId,
          isValidEmail,
          getPasswordValidationError,
        } = await import("./_core/auth-local");

        // Validate email
        if (!isValidEmail(input.email)) {
          throw new Error("Invalid email format");
        }

        // Validate password
        const passwordError = getPasswordValidationError(input.password);
        if (passwordError) {
          throw new Error(passwordError);
        }

        // Check if user already exists
        const existingUser = await db.getUserByEmail(input.email);
        if (existingUser) {
          throw new Error("User with this email already exists");
        }

        // Hash password
        const passwordHash = await hashPassword(input.password);

        // Create user
        const userId = generateUserId();
        const user = (await db.createUser({
          id: userId,
          name: input.name,
          email: input.email,
          passwordHash,
          loginMethod: "local",
          role: "user",
        })) as {
          id: string;
          name: string | null;
          email: string | null;
          role: string;
        };

        // Send email verification
        try {
          const { emailService } = await import("./services/emailService");
          const { nanoid } = await import("nanoid");
          const verificationToken = nanoid(32);
          const verificationLink = `${process.env.FRONTEND_URL || "http://localhost:2505"}/verify-email/${verificationToken}`;

          await emailService.sendEmail({
            to: input.email,
            subject: "تأكيد البريد الإلكتروني - Gold Price Predictor",
            html: `
              <div dir="rtl" style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>مرحباً ${input.name}!</h2>
                <p>شكراً لتسجيلك في Gold Price Predictor</p>
                <p>يرجى النقر على الرابط التالي لتأكيد بريدك الإلكتروني:</p>
                <p><a href="${verificationLink}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">تأكيد البريد الإلكتروني</a></p>
                <p>أو انسخ الرابط التالي:</p>
                <p>${verificationLink}</p>
                <p>إذا لم تقم بالتسجيل، يرجى تجاهل هذا البريد.</p>
              </div>
            `,
          });

          // Store verification token in database (you may need to add a field for this)
          console.log(`[Auth] Verification email sent to ${input.email}`);
        } catch (emailError) {
          console.warn("[Auth] Failed to send verification email:", emailError);
          // Don't fail registration if email fails
        }

        // Create session
        const { sdk } = await import("./_core/sdk");
        const sessionToken = await sdk.createSessionToken(userId, {
          name: input.name,
        });
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, cookieOptions);

        return {
          success: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
          message:
            "تم التسجيل بنجاح. يرجى التحقق من بريدك الإلكتروني لتأكيد الحساب.",
        };
      }),

    login: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          password: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        console.log("[Auth] Login attempt for:", input.email);
        const { verifyPassword } = await import("./_core/auth-local");
        const {
          checkRateLimit,
          clearRateLimit,
          createSessionSecurity,
          generateCSRFToken,
          logSecurityEvent,
          getClientIP,
        } = await import("./_core/security");

        // Check rate limit for brute force protection
        const clientIP = getClientIP(ctx.req);
        const rateLimit = checkRateLimit(`login:${clientIP}`);

        if (!rateLimit.allowed) {
          logSecurityEvent("login_rate_limited", null, ctx.req, {
            email: input.email,
          });
          throw new Error(
            rateLimit.message ||
              "Too many login attempts. Please try again later."
          );
        }

        // Find user by email
        const user = db.getUserByEmail(input.email) as any;
        console.log(
          "[Auth] User found:",
          user ? "Yes" : "No",
          user ? { id: user.id, email: user.email } : null
        );
        if (!user) {
          console.log("[Auth] Login failed: User not found");
          logSecurityEvent("login_failed", null, ctx.req, {
            email: input.email,
            reason: "user_not_found",
          });
          throw new Error("Invalid email or password");
        }

        // Check if user has a password (local auth)
        if (!user.passwordHash) {
          logSecurityEvent("login_failed", user.id, ctx.req, {
            reason: "oauth_account",
          });
          throw new Error("هذا الحساب يستخدم OAuth. يرجى تسجيل الدخول باستخدام OAuth.");
        }

        // Verify password
        const isValid = await verifyPassword(input.password, user.passwordHash);
        console.log("[Auth] Password valid:", isValid);
        if (!isValid) {
          console.log("[Auth] Login failed: Invalid password");
          logSecurityEvent("login_failed", user.id, ctx.req, {
            reason: "invalid_password",
          });
          throw new Error("Invalid email or password");
        }
        console.log("[Auth] Login successful for:", user.email);

        // Clear rate limit on successful login
        clearRateLimit(`login:${clientIP}`);

        // Update last signed in
        db.upsertUser({
          id: user.id,
          lastSignedIn: Date.now(),
        });

        // Create session with security binding (IP + User-Agent)
        createSessionSecurity(user.id, ctx.req);

        // Generate CSRF token
        const csrfToken = generateCSRFToken(user.id);

        // Create access token (15 minutes)
        const { sdk } = await import("./_core/sdk");
        const accessToken = await sdk.createSessionToken(user.id, {
          name: user.name,
          isRefreshToken: false,
        });

        // Create refresh token (7 days)
        const refreshToken = await sdk.createSessionToken(user.id, {
          name: user.name,
          isRefreshToken: true,
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, accessToken, cookieOptions);

        // Log successful login
        logSecurityEvent("login_success", user.id, ctx.req);

        return {
          success: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
          csrfToken, // Send CSRF token to client
          refreshToken, // Send refresh token to client (store in httpOnly cookie or localStorage)
        };
      }),

    refresh: publicProcedure
      .input(
        z.object({
          refreshToken: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { sdk } = await import("./_core/sdk");
        const { blacklistToken, isTokenBlacklisted, logSecurityEvent } =
          await import("./_core/security");

        // Check if refresh token is blacklisted
        if (isTokenBlacklisted(input.refreshToken)) {
          logSecurityEvent("refresh_token_blacklisted", null, ctx.req);
          throw new Error("Invalid refresh token");
        }

        // Verify refresh token
        const session = await sdk.verifySession(input.refreshToken);
        if (!session) {
          logSecurityEvent("refresh_token_invalid", null, ctx.req);
          throw new Error("Invalid refresh token");
        }

        // Get user
        const user = db.getUser(session.openId) as any;
        if (!user) {
          throw new Error("User not found");
        }

        // Blacklist old refresh token
        try {
          const { jwtVerify } = await import("jose");
          const { ENV } = await import("./_core/env");
          const secretKey = new TextEncoder().encode(ENV.cookieSecret);
          const { payload } = await jwtVerify(input.refreshToken, secretKey);
          const exp = (payload as any).exp;
          if (exp) {
            blacklistToken(input.refreshToken, exp * 1000);
          }
        } catch (error) {
          // Ignore errors in blacklisting
        }

        // Create new access token
        const accessToken = await sdk.createSessionToken(user.id, {
          name: user.name,
          isRefreshToken: false,
        });

        // Create new refresh token (rotate)
        const newRefreshToken = await sdk.createSessionToken(user.id, {
          name: user.name,
          isRefreshToken: true,
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, accessToken, cookieOptions);

        logSecurityEvent("token_refreshed", user.id, ctx.req);

        return {
          success: true,
          accessToken,
          refreshToken: newRefreshToken,
        };
      }),

    unlock: adminProcedure
      .input(
        z.object({
          username: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { clearRateLimit, logSecurityEvent } = await import(
          "./_core/security"
        );

        // Find user by email or username
        const user: any =
          await db.getUserByEmail(input.username) ||
          (await db.getUser(input.username));
        if (!user) {
          throw new Error("User not found");
        }

        // Clear rate limit
        clearRateLimit(`login:${input.username}`);

        logSecurityEvent("account_unlocked", user.id, ctx.req, {
          unlockedBy: ctx.user.id,
        });

        return {
          success: true,
          message: `Account unlocked for ${input.username}`,
        };
      }),
  }),

  // Assets router
  assets: router({
    getAll: publicProcedure.query(async () => {
      return await db.getAllAssets();
    }),

    list: publicProcedure.query(async () => {
      return await db.getAllAssets();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getAssetById(input.id);
      }),

    getCurrentPrices: publicProcedure.query(async () => {
      return await db.getCurrentPrices();
    }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          symbol: z.string().min(1),
          type: z.enum(["commodity", "crypto", "currency", "stock"]),
          yahooSymbol: z.string().min(1),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createAsset(input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).optional(),
          symbol: z.string().min(1).optional(),
          type: z.enum(["commodity", "crypto", "currency", "stock"]).optional(),
          yahooSymbol: z.string().min(1).optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateAsset(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteAsset(input.id);
      }),
  }),

  // Basic Predictions router (legacy)
  predictionsBasic: router({
    generate: protectedProcedure
      .input(
        z.object({
          assetId: z.number(),
          horizon: z.enum(["short", "medium", "long"]), // 1-7, 7-30, 30+ days
          modelType: z.enum(["simple", "advanced", "ensemble"]),
          confidenceLevel: z.number().min(0.8).max(0.99).default(0.95),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // This will call the Python backend
        return await db.generatePrediction({
          assetId: input.assetId,
          predictedPrice: 0, // Placeholder
          confidence: input.confidenceLevel,
          modelType: input.modelType,
          horizon: input.horizon,
        });
      }),

    getHistory: protectedProcedure
      .input(
        z.object({
          assetId: z.number().optional(),
          limit: z.number().default(10),
        })
      )
      .query(async ({ input, ctx }) => {
        return await db.getPredictionHistory({
          userId: ctx.user.id,
          assetId: input.assetId,
          limit: input.limit,
        });
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getPredictionById(input.id);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          modelType: z.enum(["simple", "advanced", "ensemble"]).optional(),
          accuracy: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updatePrediction(id, {
          model: data.modelType
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deletePrediction(input.id);
      }),

    getAccuracyComparison: protectedProcedure
      .input(
        z.object({
          assetId: z.number().optional(),
          days: z.number().default(30),
        })
      )
      .query(async ({ input }) => {
        return await db.getPredictionAccuracyComparison(input);
      }),
  }),

  // Alerts router
  alerts: router({
    // Alias for list - used by frontend
    getAll: protectedProcedure.query(async ({ ctx }) => {
      return await db.getAlertsByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          assetId: z.number(),
          condition: z.enum(["above", "below", "change"]),
          threshold: z.string(), // decimal as string for precision
          channels: z.array(z.enum(["email", "push", "telegram"])),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createAlert({
          ...input,
          userId: ctx.user.id,
        });
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getAlertsByUserId(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          isActive: z.boolean(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.updateAlert(input.id, { isActive: input.isActive });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return await db.deleteAlert(input.id);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getAlertById(input.id);
      }),
  }),

  // Users Management router (Admin Only)
  users: router({
    list: adminProcedure
      .input(
        z.object({
          limit: z.number().default(100),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return await db.getAllUsersAdmin(input);
      }),

    getById: adminProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ input }) => {
        return await db.getUserByIdAdmin(input.id);
      }),

    updateRole: adminProcedure
      .input(
        z.object({
          id: z.string(),
          role: z.enum(["admin", "user"]),
        })
      )
      .mutation(async ({ input }) => {
        return await db.updateUserRole(input.id, input.role);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.string() }))
      .mutation(async ({ input }) => {
        return await db.deleteUser(input.id);
      }),
  }),

  // Backup & Import/Export router
  backup: router({
    exportDatabase: adminProcedure.query(async () => {
      return await exportDatabase();
    }),

    importDatabase: adminProcedure
      .input(z.any())
      .mutation(async ({ input }) => {
        return await importDatabase(input);
      }),

    exportAIData: adminProcedure.query(async () => {
      return await exportAITrainingData();
    }),

    importAIData: adminProcedure.input(z.any()).mutation(async ({ input }) => {
      return await importAITrainingData(input);
    }),

    createFullBackup: adminProcedure.mutation(async () => {
      return await createFullBackup();
    }),

    restoreFullBackup: adminProcedure
      .input(z.any())
      .mutation(async ({ input }) => {
        return await restoreFullBackup(input);
      }),

    listBackups: adminProcedure.query(async () => {
      return await listBackups();
    }),

    deleteBackup: adminProcedure
      .input(z.object({ fileName: z.string() }))
      .mutation(async ({ input }) => {
        return await deleteBackup(input.fileName);
      }),

    // Advanced backup with storage options
    saveBackupAdvanced: adminProcedure
      .input(
        z.object({
          data: z.any(),
          storageType: z.enum(["internal", "external", "google_drive", "s3"]),
          fileName: z.string().optional(),
          metadata: z.record(z.string(), z.any()).optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await saveBackup(input.data, {
          storageType: input.storageType as BackupStorageType,
          fileName: input.fileName,
          metadata: input.metadata,
        });
      }),

    // Export news data
    exportNews: adminProcedure.query(async () => {
      return await exportNewsData();
    }),

    // Import news data
    importNews: adminProcedure.input(z.any()).mutation(async ({ input }) => {
      return await importNewsData(input.data);
    }),

    // Export AI conversations
    exportAIConversations: adminProcedure.query(async () => {
      return await exportAIConversations();
    }),

    // Import AI conversations
    importAIConversations: adminProcedure
      .input(z.any())
      .mutation(async ({ input }) => {
        return await importAIConversations(input);
      }),

    // Get available storage options
    getStorageOptions: adminProcedure.query(() => {
      return getAvailableStorageOptions();
    }),
  }),

  // AI Learning Management router
  aiLearning: router({
    // Get learning statistics
    getStatistics: adminProcedure.query(async () => {
      const stats = await getLearningStatistics();
      const recommendations = getQualityRecommendations(stats);
      return { ...stats, recommendations };
    }),

    // Search training examples
    searchExamples: adminProcedure
      .input(z.object({ keyword: z.string() }))
      .query(({ input }) => {
        return searchTrainingExamples(input.keyword);
      }),

    // Get examples by category
    getExamplesByCategory: adminProcedure
      .input(z.object({ category: z.string() }))
      .query(({ input }) => {
        return getExamplesByCategory(input.category);
      }),

    // Get knowledge by topic
    getKnowledgeByTopic: adminProcedure
      .input(z.object({ topic: z.string() }))
      .query(({ input }) => {
        return getKnowledgeByTopic(input.topic);
      }),

    // Get all training examples
    getAllExamples: adminProcedure.query(() => {
      return trainingExamples;
    }),

    // Get all knowledge base
    getAllKnowledge: adminProcedure.query(() => {
      return knowledgeBase;
    }),

    // Validate training example
    validateExample: adminProcedure
      .input(
        z.object({
          question: z.string(),
          answer: z.string(),
          category: z.string().optional(),
        })
      )
      .query(({ input }) => {
        return validateTrainingExample(input);
      }),
  }),

  // Monitoring & Analytics router
  comprehensive: comprehensiveRouter,

  monitoring: router({
    // Get learning data trends
    getLearningTrends: adminProcedure
      .input(z.object({ days: z.number().optional() }))
      .query(async ({ input }) => {
        return await getLearningDataTrends(input.days || 30);
      }),

    // Get audit logs
    getAuditLogs: adminProcedure
      .input(
        z.object({
          userId: z.string().optional(),
          entityType: z.string().optional(),
          action: z.string().optional(),
          startDate: z.date().optional(),
          endDate: z.date().optional(),
          limit: z.number().optional(),
          offset: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getAuditLogs(input);
      }),

    // Get audit summary
    getAuditSummary: adminProcedure
      .input(z.object({ days: z.number().optional() }))
      .query(async ({ input }) => {
        return await getAuditSummary(input.days || 7);
      }),

    // Get price analytics
    getPriceAnalytics: protectedProcedure
      .input(z.object({ assetId: z.string() }))
      .query(async ({ input }) => {
        return await getPriceAnalytics(input.assetId);
      }),

    // Get price history
    getPriceHistory: protectedProcedure
      .input(
        z.object({
          assetId: z.string(),
          period: z.enum(["1h", "24h", "7d", "30d", "1y"]).optional(),
        })
      )
      .query(async ({ input }) => {
        return await getPriceHistory(input.assetId, input.period || "24h");
      }),

    // Get assets comparison
    getAssetsComparison: protectedProcedure
      .input(
        z.object({
          assetIds: z.array(z.string()),
          period: z.enum(["24h", "7d", "30d"]).optional(),
        })
      )
      .query(async ({ input }) => {
        return await getAssetsComparison(input.assetIds, input.period || "24h");
      }),

    // Get portfolio performance
    getPortfolioPerformance: protectedProcedure.query(async ({ ctx }) => {
      return await getPortfolioPerformance(ctx.user.id);
    }),

    // Initialize audit table
    initializeAuditTable: adminProcedure.mutation(async () => {
      await initializeAuditTable();
      return { success: true };
    }),
  }),

  // Permissions router
  permissions: router({
    getUserPermissions: adminProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        return await db.getUserPermissions(input.userId);
      }),

    create: adminProcedure
      .input(
        z.object({
          userId: z.string(),
          resource: z.string(),
          action: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createPermission({
          userId: input.userId,
          resource: input.resource,
          action: input.action,
        });
      }),

    revoke: adminProcedure
      .input(z.object({ userId: z.string(), permission: z.string() }))
      .mutation(async ({ input }) => {
        return await db.revokePermission(input.userId, input.permission);
      }),

    check: protectedProcedure
      .input(z.object({ permission: z.string() }))
      .query(async ({ input, ctx }) => {
        const [resource, action] = input.permission.split(":");
        if (!resource || !action) {return false;}
        return await db.hasPermission(ctx.user.id, input.permission);
      }),
  }),

  // Historical Prices router
  historicalPrices: router({
    list: publicProcedure
      .input(
        z.object({
          assetId: z.number(),
          limit: z.number().default(100),
        })
      )
      .query(async ({ input }) => {
        return await db.getHistoricalPrices(input.assetId, input.limit);
      }),

    getByAsset: publicProcedure
      .input(
        z.object({
          assetId: z.number(),
          limit: z.number().default(100),
        })
      )
      .query(async ({ input }) => {
        return await db.getHistoricalPricesByAsset(input.assetId, input.limit);
      }),

    getLatest: publicProcedure
      .input(z.object({ assetId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLatestPrice(input.assetId);
      }),
  }),

  // Trading Signals router
  tradingSignals: router({
    calculate: protectedProcedure
      .input(z.object({ assetId: z.number() }))
      .mutation(async ({ input }) => {
        const signal = await db.calculateTradingSignals(input.assetId);
        if (signal) {
          return await db.createTradingSignal({ ...signal, assetId: input.assetId });
        }
        return null;
      }),

    list: publicProcedure
      .input(
        z
          .object({
            assetId: z.number().optional(),
            isActive: z.boolean().optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return await db.getTradingSignals(input?.assetId || 0);
      }),

    getByAsset: publicProcedure
      .input(z.object({ assetId: z.number() }))
      .query(async ({ input }) => {
        return await db.getTradingSignals(input.assetId);
      }),
  }),

  // Breakout Points router
  breakoutPoints: router({
    calculate: protectedProcedure
      .input(z.object({ assetId: z.number() }))
      .mutation(async ({ input }) => {
        const point = await db.calculateBreakoutPoints(input.assetId);
        const results = [];
        if (point) {
          results.push(await db.createBreakoutPoint({
            assetId: input.assetId,
            ...point
          }));
        }
        return results;
      }),

    list: publicProcedure
      .input(
        z
          .object({
            assetId: z.number().optional(),
            breached: z.boolean().optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return await db.getBreakoutPoints(input?.assetId || 0);
      }),
  }),

  // Break-Even Points router
  breakEvenPoints: router({
    calculate: protectedProcedure
      .input(
        z.object({
          assetId: z.number(),
          buyPrice: z.number(),
          quantity: z.number(),
          fees: z.number().default(0),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const breakEvenPrice =
          (input.buyPrice * input.quantity + input.fees) / input.quantity;
        const point = {
          userId: ctx.user!.id,
          assetId: input.assetId,
          buyPrice: input.buyPrice,
          quantity: input.quantity,
          fees: input.fees,
          breakEvenPrice,
          currentPrice: null,
          profitLoss: null,
          profitLossPercent: null,
          purchaseDate: new Date(),
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        return await db.createBreakEvenPoint(point);
      }),

    list: protectedProcedure
      .input(z.object({ assetId: z.number().optional() }).optional())
      .query(async ({ input, ctx }) => {
        return await db.getBreakEvenPoints(input?.assetId || 0);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteBreakEvenPoint(input.id);
        return { success: true };
      }),
  }),

  // Inflection Points router
  inflectionPoints: router({
    calculate: protectedProcedure
      .input(z.object({ assetId: z.number() }))
      .mutation(async ({ input }) => {
        const points = await db.calculateInflectionPoints(input.assetId);
        const results = [];
        for (const point of points) {
          results.push(await db.createInflectionPoint(point));
        }
        return results;
      }),

    list: publicProcedure
      .input(
        z
          .object({
            assetId: z.number().optional(),
            pointType: z
              .enum(["peak", "trough", "reversal_up", "reversal_down"])
              .optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return await db.getInflectionPoints(input?.assetId || 0);
      }),
  }),

  // Performance router
  performance: router({
    getModelComparison: publicProcedure
      .input(z.object({ assetId: z.number() }))
      .query(async ({ input }) => {
        return await db.getModelPerformance(input.assetId);
      }),

    getAccuracyHistory: publicProcedure
      .input(
        z.object({
          assetId: z.number(),
          days: z.number().default(30),
        })
      )
      .query(async ({ input }) => {
        return await db.getAccuracyHistory(input.assetId, input.days);
      }),
  }),
});

export type AppRouter = typeof appRouter;

