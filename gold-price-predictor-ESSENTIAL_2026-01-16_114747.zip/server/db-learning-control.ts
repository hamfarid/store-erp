/**
 * FILE: server/db-learning-control.ts
 * PURPOSE: Database helper functions for Learning & Search Control Dashboard
 * REFACTORED: To use db-compat raw queries (Postgres/SQLite compatible)
 */

import { query, usePostgres } from "./db-compat";
import type {
  SearchKeyword,
  InsertSearchKeyword,
  SearchSource,
  InsertSearchSource,
  LearningOperation,
  InsertLearningOperation,
  SearchOperation,
  InsertSearchOperation,
  OperationLog,
  InsertOperationLog,
} from "../drizzle/schema-learning-control";

// Helper for JSON fields
function prepJson(val: any) {
  if (val === undefined || val === null) {return null;}
  if (usePostgres) {return val;} // Postgres driver handles object->json
  return JSON.stringify(val);
}

function parseJson(val: any) {
  if (val === null) {return null;}
  if (typeof val === 'string') {
    try { return JSON.parse(val); } catch (e) { return val; }
  }
  return val;
}

// Mappers (if needed, but we try to use SQL aliases)
// But for JSON fields we need specific handling if driver doesn't do it automatically for SELECT.
// SQLite returns string for JSON. Postgres returns object.
function mapSource(row: any): SearchSource {
  return {
    ...row,
    config: parseJson(row.config),
    headers: parseJson(row.headers),
    enabled: row.enabled === 1 || row.enabled === true,
  };
}

function mapLearningOp(row: any): LearningOperation {
  return {
    ...row,
    input: parseJson(row.input),
    output: parseJson(row.output),
  };
}

function mapSearchOp(row: any): SearchOperation {
  return {
    ...row,
    keywords: parseJson(row.keywords),
    sources: parseJson(row.sources),
    dateRange: parseJson(row.dateRange || row.date_range), // handle snake just in case
  };
}

function mapLog(row: any): OperationLog {
  return {
    ...row,
    data: parseJson(row.data),
  };
}


// Common Column Selectors with Aliases
const KEYWORD_COLS = `
  id, keyword, category, priority, enabled, 
  search_count as "searchCount", last_used as "lastUsed", results_found as "resultsFound",
  created_by as "createdBy", created_at as "createdAt", updated_at as "updatedAt"
`;

const SOURCE_COLS = `
  id, name, type, url, enabled, config, headers, rate_limit as "rateLimit",
  request_count as "requestCount", success_count as "successCount", error_count as "errorCount",
  last_used as "lastUsed", last_error as "lastError", avg_response_time as "avgResponseTime",
  reliability, created_by as "createdBy", created_at as "createdAt", updated_at as "updatedAt"
`;

const LEARNING_OP_COLS = `
  id, type, status, progress, current_step as "currentStep", total_steps as "totalSteps",
  input, output, error, started_at as "startedAt", completed_at as "completedAt", duration,
  results_count as "resultsCount", insights_generated as "insightsGenerated", 
  adjustments_proposed as "adjustmentsProposed", triggered_by as "triggeredBy",
  created_at as "createdAt", updated_at as "updatedAt"
`;

const SEARCH_OP_COLS = `
  id, type, status, keywords, sources, date_range as "dateRange",
  progress, current_source as "currentSource", sources_processed as "sourcesProcessed",
  total_sources as "totalSources", results_found as "resultsFound", 
  events_created as "eventsCreated", error, started_at as "startedAt", 
  completed_at as "completedAt", duration, triggered_by as "triggeredBy",
  created_at as "createdAt", updated_at as "updatedAt"
`;

const LOG_COLS = `
  id, operation_id as "operationId", operation_type as "operationType",
  level, message, data, timestamp
`;

// ==================== Search Keywords ====================

export async function getAllKeywords(filters?: {
  category?: string;
  priority?: string;
  enabled?: boolean;
}) {
  let sql = `SELECT ${KEYWORD_COLS} FROM search_keywords`;
  const params: any[] = [];
  const clauses: string[] = [];

  if (filters) {
    if (filters.category) {
      clauses.push('category = ?');
      params.push(filters.category);
    }
    if (filters.priority) {
      clauses.push('priority = ?');
      params.push(filters.priority);
    }
    if (filters.enabled !== undefined) {
      clauses.push('enabled = ?');
      params.push(filters.enabled ? 1 : 0); // Postgres acts weird with bool=0? No, PG needs boolean.
      // Drizzle boolean uses 0/1 in SQLite, true/false in PG?
      // db-compat query auto-converts parameters? No.
      // I should pass boolean for PG, 0/1 for SQLite? 
      // better-sqlite3 handles boolean -> 1/0? Usually.
      // But let's check.
    }
  }

  // FIX: handle boolean param diff vs SQLite 1/0
  if (filters?.enabled !== undefined) {
      // Remove the last param and clause to re-add correctly
      clauses.pop(); 
      params.pop();
      clauses.push('enabled = ?');
      params.push(usePostgres ? filters.enabled : (filters.enabled ? 1 : 0));
  }

  if (clauses.length > 0) {
    sql += ' WHERE ' + clauses.join(' AND ');
  }
  sql += ' ORDER BY created_at DESC';

  const res = await query(sql, params);
  return res.rows.map(row => ({ 
      ...row, 
      enabled: row.enabled === 1 || row.enabled === true 
  }));
}

export async function getKeywordById(id: number): Promise<SearchKeyword | undefined> {
  const sql = `SELECT ${KEYWORD_COLS} FROM search_keywords WHERE id = ?`;
  const res = await query(sql, [id]);
  if (res.rows.length === 0) {return undefined;}
  const row = res.rows[0];
  return { ...row, enabled: row.enabled === 1 || row.enabled === true };
}

export async function createKeyword(data: InsertSearchKeyword): Promise<SearchKeyword> {
  const fields = ["keyword", "category", "priority", "enabled", "created_by"];
  const vals: any[] = [data.keyword, data.category, data.priority || "medium", data.enabled ?? true, data.createdBy || null];
  
  if (usePostgres) {
    // PG uses boolean
  } else {
     // SQLite uses 1/0 for boolean enabled
     vals[3] = vals[3] ? 1 : 0;
  }
  
  // Handling timestamp defaults in DB, but better to be explicit? 
  // Schema has defaultNow(). DB should handle it if omitted.
  
  const placeholders = fields.map(() => '?').join(',');
  const sql = `INSERT INTO search_keywords (${fields.join(',')}) VALUES (${placeholders})`;
  
  if (usePostgres) {
    const res = await query(sql + ' RETURNING id', vals);
    return getKeywordById(res.rows[0].id) as Promise<SearchKeyword>;
  }
  
  const res = await query(sql, vals);
  return getKeywordById(res.lastInsertRowid as number) as Promise<SearchKeyword>;
}

export async function updateKeyword(id: number, updates: Partial<InsertSearchKeyword>): Promise<SearchKeyword | undefined> {
    const fields: string[] = [];
    const vals: any[] = [];
    
    if (updates.keyword !== undefined) { fields.push('keyword = ?'); vals.push(updates.keyword); }
    if (updates.category !== undefined) { fields.push('category = ?'); vals.push(updates.category); }
    if (updates.priority !== undefined) { fields.push('priority = ?'); vals.push(updates.priority); }
    if (updates.enabled !== undefined) { 
        fields.push('enabled = ?'); 
        vals.push(usePostgres ? updates.enabled : (updates.enabled ? 1 : 0)); 
    }
    
    fields.push('updated_at = ?');
    vals.push(new Date());
    
    vals.push(id);
    
    if (fields.length === 1) {return getKeywordById(id);} // only updated_at
    
    const sql = `UPDATE search_keywords SET ${fields.join(', ')} WHERE id = ?`;
    await query(sql, vals);
    return getKeywordById(id);
}

export async function deleteKeyword(id: number): Promise<boolean> {
    await query('DELETE FROM search_keywords WHERE id = ?', [id]);
    return true;
}

export async function incrementKeywordStats(id: number, resultsFound: number = 0) {
    const sql = `UPDATE search_keywords SET search_count = search_count + 1, results_found = results_found + ?, last_used = ? WHERE id = ?`;
    await query(sql, [resultsFound, new Date(), id]);
}


// ==================== Search Sources ====================

export async function getAllSources(filters?: { type?: string; enabled?: boolean; }) {
  let sql = `SELECT ${SOURCE_COLS} FROM search_sources`;
  const params: any[] = [];
  const clauses: string[] = [];

  if (filters) {
    if (filters.type) { clauses.push('type = ?'); params.push(filters.type); }
    if (filters.enabled !== undefined) { 
        clauses.push('enabled = ?'); 
        params.push(usePostgres ? filters.enabled : (filters.enabled ? 1 : 0)); 
    }
  }

  if (clauses.length > 0) { sql += ' WHERE ' + clauses.join(' AND '); }
  sql += ' ORDER BY created_at DESC';

  const res = await query(sql, params);
  return res.rows.map(mapSource);
}

export async function getSourceById(id: number): Promise<SearchSource | undefined> {
    const res = await query(`SELECT ${SOURCE_COLS} FROM search_sources WHERE id = ?`, [id]);
    if (res.rows.length === 0) {return undefined;}
    return mapSource(res.rows[0]);
}

export async function createSource(data: InsertSearchSource): Promise<SearchSource> {
    const fields = ["name", "type", "url", "enabled", "config", "headers", "rate_limit", "created_by"];
    // data.config/headers Need stringify for SQLite? Yes.
    
    const vals = [
        data.name, 
        data.type, 
        data.url, 
        usePostgres ? (data.enabled ?? true) : ((data.enabled ?? true) ? 1 : 0),
        prepJson(data.config),
        prepJson(data.headers),
        data.rateLimit || 60,
        data.createdBy || null
    ];
    
    const ph = fields.map(() => '?').join(',');
    const sql = `INSERT INTO search_sources (${fields.join(',')}) VALUES (${ph})`;
    
    if (usePostgres) {
        const res = await query(sql + ' RETURNING id', vals);
        return getSourceById(res.rows[0].id) as Promise<SearchSource>;
    }
    const res = await query(sql, vals);
    return getSourceById(res.lastInsertRowid as number) as Promise<SearchSource>;
}

export async function updateSource(id: number, updates: Partial<InsertSearchSource>): Promise<SearchSource | undefined> {
    const fields: string[] = [];
    const vals: any[] = [];
    
    if (updates.name !== undefined) { fields.push('name = ?'); vals.push(updates.name); }
    if (updates.type !== undefined) { fields.push('type = ?'); vals.push(updates.type); }
    if (updates.url !== undefined) { fields.push('url = ?'); vals.push(updates.url); }
    if (updates.enabled !== undefined) { 
        fields.push('enabled = ?'); vals.push(usePostgres ? updates.enabled : (updates.enabled ? 1 : 0)); 
    }
    if (updates.config !== undefined) { fields.push('config = ?'); vals.push(prepJson(updates.config)); }
    if (updates.headers !== undefined) { fields.push('headers = ?'); vals.push(prepJson(updates.headers)); }
    if (updates.rateLimit !== undefined) { fields.push('rate_limit = ?'); vals.push(updates.rateLimit); }
    
    fields.push('updated_at = ?'); vals.push(new Date());
    vals.push(id);
    
    const sql = `UPDATE search_sources SET ${fields.join(', ')} WHERE id = ?`;
    await query(sql, vals);
    return getSourceById(id);
}

export async function deleteSource(id: number): Promise<boolean> {
    await query('DELETE FROM search_sources WHERE id = ?', [id]);
    return true;
}

export async function updateSourceStats(id: number, success: boolean, responseTime?: number, error?: string) {
    // Need to read old stats first to calc avg?
    // Doing strict SQL update is complex for running average.
    // Read -> Calc -> Update is easier and what legacy code did.
    const source = await getSourceById(id);
    if (!source) {return;}
    
    const requestCount = (source.requestCount || 0) + 1;
    const successCount = success ? (source.successCount || 0) + 1 : source.successCount || 0;
    const errorCount = success ? source.errorCount || 0 : (source.errorCount || 0) + 1;
    const reliability = requestCount > 0 ? Math.round((successCount / requestCount) * 100) : 100;
    
    const avgResponseTime = responseTime 
        ? (source.avgResponseTime ? Math.round((source.avgResponseTime + responseTime) / 2) : responseTime)
        : source.avgResponseTime;
        
    const fields = [
        'request_count = ?', 'success_count = ?', 'error_count = ?', 
        'reliability = ?', 'avg_response_time = ?', 'last_used = ?'
    ];
    const vals: any[] = [requestCount, successCount, errorCount, reliability, avgResponseTime, new Date()];
    
    if (error) {
        fields.push('last_error = ?');
        vals.push(error);
    }
    
    vals.push(id);
    await query(`UPDATE search_sources SET ${fields.join(', ')} WHERE id = ?`, vals);
}


// ==================== Learning Operations ====================

export async function getAllLearningOperations(filters?: { type?: string; status?: string; triggeredBy?: string; }) {
    let sql = `SELECT ${LEARNING_OP_COLS} FROM learning_operations`;
    const params: any[] = [];
    const clauses: string[] = [];
    
    if (filters) {
        if (filters.type) { clauses.push('type = ?'); params.push(filters.type); }
        if (filters.status) { clauses.push('status = ?'); params.push(filters.status); }
        if (filters.triggeredBy) { clauses.push('triggered_by = ?'); params.push(filters.triggeredBy); }
    }
    
    if (clauses.length > 0) { sql += ' WHERE ' + clauses.join(' AND '); }
    sql += ' ORDER BY created_at DESC';
    
    const res = await query(sql, params);
    return res.rows.map(mapLearningOp);
}

export async function getLearningOperationById(id: string): Promise<LearningOperation | undefined> {
    const res = await query(`SELECT ${LEARNING_OP_COLS} FROM learning_operations WHERE id = ?`, [id]);
    if (res.rows.length === 0) {return undefined;}
    return mapLearningOp(res.rows[0]);
}

export async function createLearningOperation(data: InsertLearningOperation): Promise<LearningOperation> {
    const fields = ["id", "type", "status", "triggered_by", "input", "output", "error", "total_steps"];
    const vals = [
        data.id, data.type, data.status || 'pending', data.triggeredBy,
        prepJson(data.input), prepJson(data.output), data.error, data.totalSteps
    ];
    
    const ph = fields.map(() => '?').join(',');
    await query(`INSERT INTO learning_operations (${fields.join(',')}) VALUES (${ph})`, vals);
    return getLearningOperationById(data.id) as Promise<LearningOperation>;
}

export async function updateLearningOperation(id: string, updates: Partial<InsertLearningOperation> & { duration?: number; completedAt?: Date; startedAt?: Date; }) {
    const fields: string[] = [];
    const vals: any[] = [];
    
    if (updates.status) { fields.push('status = ?'); vals.push(updates.status); }
    if (updates.progress !== undefined) { fields.push('progress = ?'); vals.push(updates.progress); }
    if (updates.currentStep) { fields.push('current_step = ?'); vals.push(updates.currentStep); }
    if (updates.input) { fields.push('input = ?'); vals.push(prepJson(updates.input)); }
    if (updates.output) { fields.push('output = ?'); vals.push(prepJson(updates.output)); }
    if (updates.error) { fields.push('error = ?'); vals.push(updates.error); }
    
    if (updates.startedAt) { fields.push('started_at = ?'); vals.push(updates.startedAt); }
    if (updates.completedAt) { fields.push('completed_at = ?'); vals.push(updates.completedAt); }
    if (updates.duration) { fields.push('duration = ?'); vals.push(updates.duration); }
    
    fields.push('updated_at = ?'); vals.push(new Date());
    vals.push(id);
    
    await query(`UPDATE learning_operations SET ${fields.join(', ')} WHERE id = ?`, vals);
    return getLearningOperationById(id);
}

export async function incrementOperationProgress(id: string, progress: number, currentStep?: string) {
    const fields = ['progress = progress + ?', 'updated_at = ?'];
    const vals: any[] = [progress, new Date()];
    
    if (currentStep) {
        fields.push('current_step = ?');
        vals.push(currentStep);
    }
    vals.push(id);
    
    await query(`UPDATE learning_operations SET ${fields.join(', ')} WHERE id = ?`, vals);
    return getLearningOperationById(id);
}

export async function deleteLearningOperation(id: string): Promise<boolean> {
    await query('DELETE FROM learning_operations WHERE id = ?', [id]);
    return true;
}

export async function getActiveLearningOperations() {
    // OR condition: status pending or running
    const sql = `SELECT ${LEARNING_OP_COLS} FROM learning_operations WHERE status = ? OR status = ? ORDER BY created_at DESC`;
    const res = await query(sql, ['pending', 'running']);
    return res.rows.map(mapLearningOp);
}


// ==================== Search Operations ====================

export async function getAllSearchOperations(filters?: { type?: string; status?: string; triggeredBy?: string; }) {
    let sql = `SELECT ${SEARCH_OP_COLS} FROM search_operations`;
    const params: any[] = [];
    const clauses: string[] = [];
    
    if (filters) {
        if (filters.type) { clauses.push('type = ?'); params.push(filters.type); }
        if (filters.status) { clauses.push('status = ?'); params.push(filters.status); }
        if (filters.triggeredBy) { clauses.push('triggered_by = ?'); params.push(filters.triggeredBy); }
    }
    if (clauses.length > 0) { sql += ' WHERE ' + clauses.join(' AND '); }
    sql += ' ORDER BY created_at DESC';
    
    const res = await query(sql, params);
    return res.rows.map(mapSearchOp);
}

export async function getSearchOperationById(id: string): Promise<SearchOperation | undefined> {
    const res = await query(`SELECT ${SEARCH_OP_COLS} FROM search_operations WHERE id = ?`, [id]);
    if (res.rows.length === 0) {return undefined;}
    return mapSearchOp(res.rows[0]);
}

export async function createSearchOperation(data: InsertSearchOperation): Promise<SearchOperation> {
    const fields = ["id", "type", "status", "keywords", "sources", "date_range", "triggered_by"];
    const vals = [
        data.id, data.type, data.status || 'pending', 
        prepJson(data.keywords), prepJson(data.sources), prepJson(data.dateRange), 
        data.triggeredBy
    ];
    
    const ph = fields.map(() => '?').join(',');
    await query(`INSERT INTO search_operations (${fields.join(',')}) VALUES (${ph})`, vals);
    return getSearchOperationById(data.id) as Promise<SearchOperation>;
}


export async function createSearchOperationWithLogs(
  operationData: InsertSearchOperation,
  initialLog?: { level: string; message: string; data?: any; }
): Promise<{ operation: SearchOperation; log?: OperationLog }> {
    // Transaction simulation
    try {
        if (!usePostgres) { await query('BEGIN'); }
        else { await query('BEGIN'); }
        
        // Insert Op
        const fields = ["id", "type", "status", "keywords", "sources", "date_range", "triggered_by"];
        const vals = [
            operationData.id, operationData.type, operationData.status || 'pending', 
            prepJson(operationData.keywords), prepJson(operationData.sources), prepJson(operationData.dateRange), 
            operationData.triggeredBy
        ];
        const ph = fields.map(() => '?').join(',');
        await query(`INSERT INTO search_operations (${fields.join(',')}) VALUES (${ph})`, vals);
        
        let log: OperationLog | undefined;
        
        if (initialLog) {
            const lFields = ["operation_id", "operation_type", "level", "message", "data"];
            const lVals = [
                operationData.id, "search", initialLog.level, initialLog.message, prepJson(initialLog.data)
            ];
            const lPh = lFields.map(() => '?').join(',');
            let lSql = `INSERT INTO operation_logs (${lFields.join(',')}) VALUES (${lPh})`;
            
            if (usePostgres) {
                const res = await query(lSql + ' RETURNING id', lVals);
                const logRows = await query(`SELECT ${LOG_COLS} FROM operation_logs WHERE id = ?`, [res.rows[0].id]);
                if (logRows.rows.length > 0) { log = mapLog(logRows.rows[0]); }
            } else {
                const res = await query(lSql, lVals);
                const logRows = await query(`SELECT ${LOG_COLS} FROM operation_logs WHERE id = ?`, [res.lastInsertRowid]);
                if (logRows.rows.length > 0) { log = mapLog(logRows.rows[0]); }
            }
        }
        
        await query('COMMIT');
        
        const op = await getSearchOperationById(operationData.id);
        if (!op) { throw new Error("Created operation not found"); }
        
        return { operation: op, log };
        
    } catch (e) {
        await query('ROLLBACK');
        throw e;
    }
}

export async function updateSearchOperation(id: string, updates: Partial<InsertSearchOperation> & { duration?: number; completedAt?: Date; startedAt?: Date; }) {
    const fields: string[] = [];
    const vals: any[] = [];
    
    // Generic update mapping...
    if (updates.status) { fields.push('status = ?'); vals.push(updates.status); }
    if (updates.progress !== undefined) { fields.push('progress = ?'); vals.push(updates.progress); }
    if (updates.currentSource) { fields.push('current_source = ?'); vals.push(updates.currentSource); }
    if (updates.sourcesProcessed !== undefined) { fields.push('sources_processed = ?'); vals.push(updates.sourcesProcessed); }
    if (updates.resultsFound !== undefined) { fields.push('results_found = ?'); vals.push(updates.resultsFound); }
    if (updates.eventsCreated !== undefined) { fields.push('events_created = ?'); vals.push(updates.eventsCreated); }
    if (updates.error) { fields.push('error = ?'); vals.push(updates.error); }
    
    if (updates.startedAt) { fields.push('started_at = ?'); vals.push(updates.startedAt); }
    if (updates.completedAt) { fields.push('completed_at = ?'); vals.push(updates.completedAt); }
    if (updates.duration) { fields.push('duration = ?'); vals.push(updates.duration); }
    
    fields.push('updated_at = ?'); vals.push(new Date());
    vals.push(id);
    
    await query(`UPDATE search_operations SET ${fields.join(', ')} WHERE id = ?`, vals);
    return getSearchOperationById(id);
}

export async function deleteSearchOperation(id: string): Promise<boolean> {
    await query('DELETE FROM search_operations WHERE id = ?', [id]);
    return true;
}

export async function getActiveSearchOperations() {
    const sql = `SELECT ${SEARCH_OP_COLS} FROM search_operations WHERE status = ? OR status = ? ORDER BY created_at DESC`;
    const res = await query(sql, ['pending', 'running']);
    return res.rows.map(mapSearchOp);
}


// ==================== Operation Logs ====================

export async function getOperationLogs(operationId: string, filters?: { level?: string; limit?: number; }) {
    let sql = `SELECT ${LOG_COLS} FROM operation_logs WHERE operation_id = ?`;
    const params: any[] = [operationId];
    
    if (filters?.level) {
        sql += ' AND level = ?';
        params.push(filters.level);
    }
    
    sql += ' ORDER BY timestamp DESC';
    
    if (filters?.limit) {
        sql += ' LIMIT ?';
        params.push(filters.limit);
    }
    
    const res = await query(sql, params);
    return res.rows.map(mapLog);
}

export async function createOperationLog(data: InsertOperationLog): Promise<OperationLog> {
    const fields = ["operation_id", "operation_type", "level", "message", "data"];
    const vals = [data.operationId, data.operationType, data.level, data.message, prepJson(data.data)];
    
    const ph = fields.map(() => '?').join(',');
    const sql = `INSERT INTO operation_logs (${fields.join(',')}) VALUES (${ph})`;
    
    if (usePostgres) {
        const res = await query(sql + ' RETURNING id', vals);
        const rows = await query(`SELECT ${LOG_COLS} FROM operation_logs WHERE id = ?`, [res.rows[0].id]);
        return mapLog(rows.rows[0]);
    }
    const res = await query(sql, vals);
    const rows = await query(`SELECT ${LOG_COLS} FROM operation_logs WHERE id = ?`, [res.lastInsertRowid]);
    return mapLog(rows.rows[0]);
}


// ==================== Statistics ====================

export async function getLearningControlStats() {
    try {
        const p1 = query('SELECT COUNT(*) as c FROM search_keywords');
        const p2 = query('SELECT COUNT(*) as c FROM search_sources');
        const p3 = query(`SELECT COUNT(*) as c FROM learning_operations WHERE status IN ('running', 'pending')`);
        const p4 = query(`SELECT COUNT(*) as c FROM search_operations WHERE status IN ('running', 'pending')`);
        const p5 = query('SELECT COUNT(*) as c FROM learning_operations');
        const p6 = query('SELECT COUNT(*) as c FROM search_operations');
        
        // SQLite: IN ('a', 'b') works.
        // Postgres: Works.
        
        const [r1, r2, r3, r4, r5, r6] = await Promise.all([p1, p2, p3, p4, p5, p6]);
        
        // Helper to get count from result row
        const getC = (r: any) => {
            if (r.rows.length === 0) {return 0;}
            return Number(r.rows[0].c || r.rows[0].count || 0); // Postgres might return count as string?
        };
        
        return {
            keywordsCount: getC(r1),
            sourcesCount: getC(r2),
            activeLearningOps: getC(r3),
            activeSearchOps: getC(r4),
            totalLearningOps: getC(r5),
            totalSearchOps: getC(r6),
        };
    } catch (e) {
        console.error("Error stats", e);
        return { keywordsCount: 0, sourcesCount: 0, activeLearningOps: 0, activeSearchOps: 0, totalLearningOps: 0, totalSearchOps: 0 };
    }
}
