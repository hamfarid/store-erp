/**
 * Swagger API Endpoint Examples
 * JSDoc comments for OpenAPI documentation
 */

/**
 * @swagger
 * /api/trpc/auth.me:
 *   get:
 *     tags: [Auth]
 *     summary: Get current user
 *     description: Returns the currently authenticated user
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: User information
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /api/trpc/portfolio.list:
 *   get:
 *     tags: [Portfolio]
 *     summary: Get user portfolio
 *     description: Returns all assets in user's portfolio
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of portfolio items
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Portfolio'
 */

/**
 * @swagger
 * /api/trpc/alerts.create:
 *   post:
 *     tags: [Alerts]
 *     summary: Create price alert
 *     description: Creates a new price alert for an asset
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - assetId
 *               - targetPrice
 *               - condition
 *             properties:
 *               assetId:
 *                 type: integer
 *                 example: 1
 *               targetPrice:
 *                 type: number
 *                 example: 50000
 *               condition:
 *                 type: string
 *                 enum: [above, below]
 *                 example: above
 *     responses:
 *       200:
 *         description: Alert created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Alert'
 */

/**
 * @swagger
 * /api/trpc/comprehensive.sendNotification:
 *   post:
 *     tags: [Notifications]
 *     summary: Send notification
 *     description: Sends a notification to a user
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - type
 *               - title
 *               - message
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [push, email, telegram, in_app]
 *                 example: email
 *               title:
 *                 type: string
 *                 example: "Price Alert"
 *               message:
 *                 type: string
 *                 example: "Bitcoin reached your target price"
 *     responses:
 *       200:
 *         description: Notification sent
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 notificationId:
 *                   type: integer
 */

/**
 * @swagger
 * /api/trpc/comprehensive.generateReport:
 *   post:
 *     tags: [Reports]
 *     summary: Generate report
 *     description: Generates a report in specified format
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - type
 *               - format
 *             properties:
 *               name:
 *                 type: string
 *                 example: "Monthly Portfolio Report"
 *               type:
 *                 type: string
 *                 enum: [portfolio, price_analysis, predictions, alerts]
 *                 example: portfolio
 *               format:
 *                 type: string
 *                 enum: [pdf, excel, csv]
 *                 example: pdf
 *               parameters:
 *                 type: object
 *     responses:
 *       200:
 *         description: Report generated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Report'
 */

/**
 * @swagger
 * /api/trpc/comprehensive.calculateKPIs:
 *   post:
 *     tags: [KPIs]
 *     summary: Calculate KPIs
 *     description: Calculates Key Performance Indicators for user portfolio
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - period
 *             properties:
 *               period:
 *                 type: string
 *                 enum: [daily, weekly, monthly, yearly]
 *                 example: monthly
 *     responses:
 *       200:
 *         description: KPIs calculated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/KPIMetrics'
 */

/**
 * @swagger
 * /api/trpc/aiEnhanced.analyzeSentiment:
 *   post:
 *     tags: [AI]
 *     summary: Analyze sentiment
 *     description: Analyzes sentiment of text using advanced LLM
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - text
 *             properties:
 *               text:
 *                 type: string
 *                 example: "ارتفعت أسعار البيتكوين بشكل كبير"
 *               language:
 *                 type: string
 *                 example: "ar"
 *     responses:
 *       200:
 *         description: Sentiment analysis result
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SentimentAnalysis'
 */

/**
 * @swagger
 * /api/trpc/aiEnhanced.generateSmartRecommendation:
 *   post:
 *     tags: [AI]
 *     summary: Generate AI recommendations
 *     description: Generates smart investment recommendations using AI
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               assetId:
 *                 type: integer
 *                 example: 1
 *     responses:
 *       200:
 *         description: AI recommendations
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/AIRecommendation'
 */

/**
 * @swagger
 * /api/trpc/aiEnhanced.chatWithAI:
 *   post:
 *     tags: [AI]
 *     summary: Chat with AI assistant
 *     description: Chat with AI financial assistant
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - message
 *             properties:
 *               message:
 *                 type: string
 *                 example: "ما هو سعر البيتكوين؟"
 *               conversationHistory:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     role:
 *                       type: string
 *                       enum: [user, assistant]
 *                     content:
 *                       type: string
 *     responses:
 *       200:
 *         description: AI response
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 response:
 *                   type: string
 */

/**
 * @swagger
 * /api/trpc/comprehensive.calculateRiskProfile:
 *   post:
 *     tags: [Risk]
 *     summary: Calculate risk profile
 *     description: Calculates risk profile for portfolio or specific asset
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               assetId:
 *                 type: integer
 *                 example: 1
 *     responses:
 *       200:
 *         description: Risk profile
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/RiskProfile'
 */

/**
 * @swagger
 * /api/trpc/comprehensive.logActivity:
 *   post:
 *     tags: [Activity]
 *     summary: Log activity
 *     description: Logs user activity for tracking
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - action
 *               - entityType
 *             properties:
 *               action:
 *                 type: string
 *                 example: "create"
 *               entityType:
 *                 type: string
 *                 example: "alert"
 *               entityId:
 *                 type: string
 *                 example: "123"
 *               description:
 *                 type: string
 *                 example: "Created new price alert"
 *     responses:
 *       200:
 *         description: Activity logged
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 */

export {};

