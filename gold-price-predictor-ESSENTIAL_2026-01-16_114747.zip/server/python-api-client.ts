// /home/ubuntu/asset_predictor_ui/server/python-api-client.ts
/**
 * Python API Client
 * Handles communication with the secure Python backend
 */

import axios, { AxiosInstance, AxiosError } from 'axios';

// API Configuration
const API_BASE_URL = process.env.PYTHON_API_URL || process.env.ML_API_URL || 'http://localhost:2105';
const API_TIMEOUT = 30000; // 30 seconds

// Types
export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface Asset {
  id: number;
  symbol: string;
  name: string;
  model_available: boolean;
}

export interface Model {
  name: string;
  accuracy: number;
  type: string;
  mae: number;
  rmse: number;
}

export interface PredictionRequest {
  symbol: string;
  horizon: 'short' | 'medium' | 'long';
  confidenceLevel?: number;
}

export interface PredictionResponse {
  symbol: string;
  asset_name: string;
  horizon: string;
  horizon_days: number;
  model_used: string;
  current_price: number;
  predicted_price: number;
  change: number;
  change_percent: number;
  confidence_level: number;
  confidence_interval: {
    lower: number;
    upper: number;
  };
  model_accuracy: number;
  timestamp: string;
}

export interface ApiError {
  error: string;
  message: string;
  detail?: string;
}

/**
 * Python API Client Class
 */
export class PythonApiClient {
  private client: AxiosInstance;
  private accessToken: string | null = null;
  private refreshToken: string | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: API_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor to add auth token
    this.client.interceptors.request.use(
      (config) => {
        if (this.accessToken && config.headers) {
          config.headers.Authorization = `Bearer ${this.accessToken}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      async (error: AxiosError<ApiError>) => {
        if (error.response?.status === 401 && this.refreshToken) {
          // Try to refresh token
          try {
            await this.refreshAccessToken();
            // Retry original request
            if (error.config) {
              return this.client(error.config);
            }
          } catch (refreshError) {
            // Refresh failed, clear tokens
            this.clearTokens();
            throw refreshError;
          }
        }
        throw error;
      }
    );
  }

  /**
   * Set authentication tokens
   */
  setTokens(accessToken: string, refreshToken: string) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
  }

  /**
   * Clear authentication tokens
   */
  clearTokens() {
    this.accessToken = null;
    this.refreshToken = null;
  }

  /**
   * Refresh access token
   */
  private async refreshAccessToken(): Promise<void> {
    // Note: This requires implementing a refresh endpoint in the Python API
    // For now, we'll just clear tokens
    this.clearTokens();
  }

  /**
   * Login to Python API
   */
  async login(username: string, password: string): Promise<LoginResponse> {
    try {
      const response = await this.client.post<LoginResponse>('/auth/login', {
        username,
        password,
      });
      
      this.setTokens(response.data.access_token, response.data.refresh_token);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Get health status
   */
  async getHealth(): Promise<{ status: string; timestamp: string }> {
    try {
      const response = await this.client.get('/health');
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Get all assets
   */
  async getAssets(): Promise<{ assets: Asset[]; total: number }> {
    try {
      const response = await this.client.get('/assets');
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Get all models
   */
  async getModels(): Promise<{ models: Model[]; total: number }> {
    try {
      const response = await this.client.get('/models');
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Make a prediction
   */
  async predict(request: PredictionRequest): Promise<PredictionResponse> {
    try {
      const response = await this.client.post<PredictionResponse>('/predict', request);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Handle API errors
   */
  private handleError(error: unknown): Error {
    if (axios.isAxiosError(error)) {
      const axiosError = error as AxiosError<ApiError>;
      
      if (axiosError.response) {
        // Server responded with error
        const data = axiosError.response.data;
        return new Error(
          data?.message || data?.error || `API Error: ${axiosError.response.status}`
        );
      } else if (axiosError.request) {
        // Request made but no response
        return new Error('No response from API server. Please check if the server is running.');
      }
    }
    
    // Other errors
    return error instanceof Error ? error : new Error('Unknown error occurred');
  }

  /**
   * Check if client is authenticated
   */
  isAuthenticated(): boolean {
    return this.accessToken !== null;
  }
}

// Singleton instance
let pythonApiClient: PythonApiClient | null = null;

/**
 * Get Python API client instance
 */
export function getPythonApiClient(): PythonApiClient {
  if (!pythonApiClient) {
    pythonApiClient = new PythonApiClient();
    
    // Auto-login with default credentials for development
    if (process.env.NODE_ENV === 'development') {
      pythonApiClient.login('admin', 'secret').catch((error) => {
        console.warn('[Python API] Auto-login failed:', error.message);
      });
    }
  }
  return pythonApiClient;
}

export default getPythonApiClient;

