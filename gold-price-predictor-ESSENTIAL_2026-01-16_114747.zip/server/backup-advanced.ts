/**
 * Advanced Backup Utilities
 * Support for multiple storage options: Internal, External, Google Drive
 */

import { promises as fs } from "fs";
import path from "path";
import { storagePut, storageGet } from "./storage";

export type BackupStorageType = "internal" | "external" | "google_drive" | "s3";

export interface BackupOptions {
  storageType: BackupStorageType;
  fileName?: string;
  metadata?: Record<string, any>;
}

export interface BackupResult {
  success: boolean;
  storageType: BackupStorageType;
  location?: string;
  url?: string;
  size?: number;
  error?: string;
  timestamp: string;
}

/**
 * Save backup to internal storage (local server)
 */
async function saveToInternal(
  data: any,
  fileName: string
): Promise<BackupResult> {
  try {
    const backupDir = path.join(process.cwd(), "backups");
    await fs.mkdir(backupDir, { recursive: true });

    const filePath = path.join(backupDir, fileName);
    const content = JSON.stringify(data, null, 2);

    await fs.writeFile(filePath, content, "utf-8");
    const stats = await fs.stat(filePath);

    return {
      success: true,
      storageType: "internal",
      location: filePath,
      size: stats.size,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      storageType: "internal",
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Save backup to S3 storage
 */
async function saveToS3(data: any, fileName: string): Promise<BackupResult> {
  try {
    const content = JSON.stringify(data, null, 2);
    const buffer = Buffer.from(content, "utf-8");

    const result = await storagePut(
      `backups/${fileName}`,
      buffer,
      "application/json"
    );

    return {
      success: true,
      storageType: "s3",
      location: result.key,
      url: result.url,
      size: buffer.length,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      storageType: "s3",
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Save backup to Google Drive
 */
async function saveToGoogleDrive(
  data: any,
  fileName: string
): Promise<BackupResult> {
  try {
    // Check if credentials are available
    const credentials = process.env.GOOGLE_DRIVE_CREDENTIALS;
    const folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;

    if (!credentials || !folderId) {
      return {
        success: false,
        storageType: "google_drive",
        error: "Google Drive credentials not configured",
        timestamp: new Date().toISOString(),
      };
    }

    // Parse credentials
    const credentialsObj = JSON.parse(credentials);

    // Import googleapis dynamically
    const { google } = await import("googleapis");

    // Create JWT client
    const auth = new google.auth.JWT({
      email: credentialsObj.client_email,
      key: credentialsObj.private_key,
      scopes: ["https://www.googleapis.com/auth/drive.file"],
    });

    const drive = google.drive({ version: "v3", auth });

    // Upload file
    const content = JSON.stringify(data, null, 2);
    const buffer = Buffer.from(content, "utf-8");

    const response = await drive.files.create({
      requestBody: {
        name: fileName,
        parents: [folderId],
        mimeType: "application/json",
      },
      media: {
        mimeType: "application/json",
        body: buffer,
      },
      fields: "id, name, size, webViewLink",
    });

    return {
      success: true,
      storageType: "google_drive",
      location: response.data.id || undefined,
      url: response.data.webViewLink || undefined,
      size: parseInt(response.data.size || "0"),
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Google Drive upload error:", error);
    return {
      success: false,
      storageType: "google_drive",
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Save backup to external URL (webhook/API)
 */
async function saveToExternal(
  data: any,
  fileName: string
): Promise<BackupResult> {
  try {
    const externalUrl = process.env.EXTERNAL_BACKUP_URL;
    const token = process.env.EXTERNAL_BACKUP_TOKEN;

    if (!externalUrl) {
      return {
        success: false,
        storageType: "external",
        error: "External backup URL not configured",
        timestamp: new Date().toISOString(),
      };
    }

    const content = JSON.stringify(data, null, 2);

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(externalUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({
        fileName,
        data: content,
        timestamp: new Date().toISOString(),
      }),
    });

    if (!response.ok) {
      throw new Error(
        `External API error: ${response.status} ${response.statusText}`
      );
    }

    const result = await response.json();

    return {
      success: true,
      storageType: "external",
      location: result.location || externalUrl,
      url: result.url,
      size: Buffer.from(content).length,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      storageType: "external",
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Save backup with specified storage type
 */
export async function saveBackup(
  data: any,
  options: BackupOptions
): Promise<BackupResult> {
  const fileName = options.fileName || `backup-${Date.now()}.json`;

  // Add metadata to backup
  const backupData = {
    ...data,
    metadata: {
      ...options.metadata,
      fileName,
      createdAt: new Date().toISOString(),
      storageType: options.storageType,
    },
  };

  switch (options.storageType) {
    case "internal":
      return await saveToInternal(backupData, fileName);

    case "s3":
      return await saveToS3(backupData, fileName);

    case "google_drive":
      return await saveToGoogleDrive(backupData, fileName);

    case "external":
      return await saveToExternal(backupData, fileName);

    default:
      return {
        success: false,
        storageType: options.storageType,
        error: `Unsupported storage type: ${options.storageType}`,
        timestamp: new Date().toISOString(),
      };
  }
}

/**
 * Export news data
 */
export async function exportNewsData(): Promise<{
  success: boolean;
  data?: any;
  error?: string;
  timestamp: string;
}> {
  try {
    const { getDb } = await import("./db");
    const db = await getDb();

    if (!db) {
      return {
        success: false,
        error: "Database not available",
        timestamp: new Date().toISOString(),
      };
    }

    // Export news cache
    const newsResult = await (db as any).execute(
      "SELECT * FROM news_cache ORDER BY publishedAt DESC LIMIT 1000"
    );

    const exportData = {
      version: "1.0",
      exportDate: new Date().toISOString(),
      newsCache: newsResult.rows || [],
      statistics: {
        totalNews: (newsResult.rows || []).length,
        sources: Array.from(
          new Set((newsResult.rows || []).map((n: any) => n.source))
        ),
      },
    };

    return {
      success: true,
      data: exportData,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("News data export error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Import news data
 */
export async function importNewsData(data: any): Promise<{
  success: boolean;
  imported: number;
  skipped: number;
  errors: string[];
}> {
  const result = {
    success: true,
    imported: 0,
    skipped: 0,
    errors: [] as string[],
  };

  try {
    const { getDb } = await import("./db");
    const db = await getDb();

    if (!db) {
      result.success = false;
      result.errors.push("Database not available");
      return result;
    }

    if (!data.newsCache || !Array.isArray(data.newsCache)) {
      result.success = false;
      result.errors.push("Invalid news data format");
      return result;
    }

    // Import news items
    for (const newsItem of data.newsCache) {
      try {
        await (db as any).execute(
          `INSERT INTO news_cache (title, description, url, source, publishedAt, sentiment, category, assetId)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             description=VALUES(description),
             sentiment=VALUES(sentiment),
             category=VALUES(category)`,
          [
            newsItem.title,
            newsItem.description,
            newsItem.url,
            newsItem.source,
            newsItem.publishedAt,
            newsItem.sentiment,
            newsItem.category,
            newsItem.assetId,
          ]
        );
        result.imported++;
      } catch (error) {
        result.errors.push(`Failed to import news item: ${error}`);
        result.skipped++;
      }
    }

    result.success = result.errors.length === 0;
    return result;
  } catch (error) {
    result.success = false;
    result.errors.push(
      error instanceof Error ? error.message : "Unknown error"
    );
    return result;
  }
}

/**
 * Export AI assistant conversations
 */
export async function exportAIConversations(): Promise<{
  success: boolean;
  data?: any;
  error?: string;
  timestamp: string;
}> {
  try {
    const { getDb } = await import("./db");
    const db = await getDb();

    if (!db) {
      return {
        success: false,
        error: "Database not available",
        timestamp: new Date().toISOString(),
      };
    }

    // Export conversations
    const conversationsResult = await (db as any).execute(
      "SELECT * FROM ai_conversations ORDER BY createdAt DESC LIMIT 5000"
    );

    const exportData = {
      version: "1.0",
      exportDate: new Date().toISOString(),
      conversations: conversationsResult.rows || [],
      statistics: {
        totalConversations: (conversationsResult.rows || []).length,
        users: new Set(
          (conversationsResult.rows || []).map((c: any) => c.userId)
        ).size,
      },
    };

    return {
      success: true,
      data: exportData,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("AI conversations export error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Import AI assistant conversations
 */
export async function importAIConversations(data: any): Promise<{
  success: boolean;
  imported: number;
  skipped: number;
  errors: string[];
}> {
  const result = {
    success: true,
    imported: 0,
    skipped: 0,
    errors: [] as string[],
  };

  try {
    const { getDb } = await import("./db");
    const db = await getDb();

    if (!db) {
      result.success = false;
      result.errors.push("Database not available");
      return result;
    }

    if (!data.conversations || !Array.isArray(data.conversations)) {
      result.success = false;
      result.errors.push("Invalid conversations data format");
      return result;
    }

    // Import conversations
    for (const conversation of data.conversations) {
      try {
        await (db as any).execute(
          `INSERT INTO ai_conversations (userId, assistantId, message, response, createdAt)
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             response=VALUES(response)`,
          [
            conversation.userId,
            conversation.assistantId,
            conversation.message,
            conversation.response,
            conversation.createdAt,
          ]
        );
        result.imported++;
      } catch (error) {
        result.errors.push(`Failed to import conversation: ${error}`);
        result.skipped++;
      }
    }

    result.success = result.errors.length === 0;
    return result;
  } catch (error) {
    result.success = false;
    result.errors.push(
      error instanceof Error ? error.message : "Unknown error"
    );
    return result;
  }
}

/**
 * Get available storage options
 */
export function getAvailableStorageOptions(): {
  type: BackupStorageType;
  label: string;
  available: boolean;
  description: string;
}[] {
  return [
    {
      type: "internal",
      label: "تخزين داخلي",
      available: true,
      description: "حفظ النسخة الاحتياطية على الخادم المحلي",
    },
    {
      type: "s3",
      label: "S3 Storage",
      available: !!process.env.S3_BUCKET,
      description: "حفظ النسخة الاحتياطية على Amazon S3 أو خدمة متوافقة",
    },
    {
      type: "google_drive",
      label: "Google Drive",
      available: !!(
        process.env.GOOGLE_DRIVE_CREDENTIALS &&
        process.env.GOOGLE_DRIVE_FOLDER_ID
      ),
      description: "حفظ النسخة الاحتياطية على Google Drive",
    },
    {
      type: "external",
      label: "رابط خارجي",
      available: !!process.env.EXTERNAL_BACKUP_URL,
      description: "إرسال النسخة الاحتياطية إلى رابط خارجي (Webhook/API)",
    },
  ];
}
