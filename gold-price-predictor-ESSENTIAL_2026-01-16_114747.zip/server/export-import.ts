import { getDb } from "./db";
import {
  assets,
  predictions,
  alerts,
  historicalPrices,
  users,
} from "../drizzle/schema";
import * as fs from "fs";
import * as path from "path";

/**
 * Export all data to JSON files
 */
export async function exportAllData(outputDir: string) {
  const db = await getDb();
  if (!db) {throw new Error("Database not available");}

  // Create output directory if it doesn't exist
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const exportData: any = {
    timestamp,
    version: "1.0",
    data: {},
  };

  // Export assets
  const assetsData = await (db as any).select().from(assets);
  exportData.data.assets = assetsData;
  console.log(`✅ Exported ${assetsData.length} assets`);

  // Export predictions
  const predictionsData = await (db as any).select().from(predictions);
  exportData.data.predictions = predictionsData;
  console.log(`✅ Exported ${predictionsData.length} predictions`);

  // Export alerts
  const alertsData = await (db as any).select().from(alerts);
  exportData.data.alerts = alertsData;
  console.log(`✅ Exported ${alertsData.length} alerts`);

  // Export historical prices
  const historicalData = await (db as any).select().from(historicalPrices);
  exportData.data.historicalPrices = historicalData;
  console.log(`✅ Exported ${historicalData.length} historical prices`);

  // Export users (without sensitive data)
  const usersData = await (db as any).select().from(users);
  exportData.data.users = usersData.map((u: any) => ({
    id: u.id,
    name: u.name,
    role: u.role,
    createdAt: u.createdAt,
  }));
  console.log(`✅ Exported ${usersData.length} users (anonymized)`);

  // Write to file
  const filename = `export_${timestamp}.json`;
  const filepath = path.join(outputDir, filename);
  fs.writeFileSync(filepath, JSON.stringify(exportData, null, 2));

  console.log(`\n✅ Export completed: ${filepath}`);
  return filepath;
}

/**
 * Import data from JSON file
 */
export async function importAllData(filepath: string) {
  const db = await getDb();
  if (!db) {throw new Error("Database not available");}

  if (!fs.existsSync(filepath)) {
    throw new Error(`File not found: ${filepath}`);
  }

  const fileContent = fs.readFileSync(filepath, "utf-8");
  const importData = JSON.parse(fileContent);

  console.log(`📥 Importing data from ${importData.timestamp}...`);

  const imported = {
    assets: 0,
    predictions: 0,
    alerts: 0,
    historicalPrices: 0,
  };

  // Import assets
  if (importData.data.assets && importData.data.assets.length > 0) {
    for (const asset of importData.data.assets) {
      try {
        await (db as any).insert(assets).values(asset);
        imported.assets++;
      } catch (error) {
        // Skip duplicates
      }
    }
    console.log(`✅ Imported ${imported.assets} assets`);
  }

  // Import predictions
  if (importData.data.predictions && importData.data.predictions.length > 0) {
    for (const prediction of importData.data.predictions) {
      try {
        await (db as any).insert(predictions).values(prediction);
        imported.predictions++;
      } catch (error) {
        // Skip duplicates
      }
    }
    console.log(`✅ Imported ${imported.predictions} predictions`);
  }

  // Import alerts
  if (importData.data.alerts && importData.data.alerts.length > 0) {
    for (const alert of importData.data.alerts) {
      try {
        await (db as any).insert(alerts).values(alert);
        imported.alerts++;
      } catch (error) {
        // Skip duplicates
      }
    }
    console.log(`✅ Imported ${imported.alerts} alerts`);
  }

  // Import historical prices
  if (
    importData.data.historicalPrices &&
    importData.data.historicalPrices.length > 0
  ) {
    for (const price of importData.data.historicalPrices) {
      try {
        await (db as any).insert(historicalPrices).values(price);
        imported.historicalPrices++;
      } catch (error) {
        // Skip duplicates
      }
    }
    console.log(`✅ Imported ${imported.historicalPrices} historical prices`);
  }

  console.log(`\n✅ Import completed!`);
  return imported;
}

/**
 * Export ML models and training data
 */
export async function exportMLData(outputDir: string) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const mlExportDir = path.join(outputDir, `ml_export_${timestamp}`);

  if (!fs.existsSync(mlExportDir)) {
    fs.mkdirSync(mlExportDir, { recursive: true });
  }

  // Copy models from Python project
  const modelsSource =
    "/home/ubuntu/gold_price_predictor_clean/models/recent_data";
  const modelsTarget = path.join(mlExportDir, "models");

  if (fs.existsSync(modelsSource)) {
    fs.cpSync(modelsSource, modelsTarget, { recursive: true });
    console.log(`✅ Exported ML models to ${modelsTarget}`);
  }

  // Copy training data
  const dataSource =
    "/home/ubuntu/gold_price_predictor_clean/data/extended_dataset.csv";
  const dataTarget = path.join(mlExportDir, "extended_dataset.csv");

  if (fs.existsSync(dataSource)) {
    fs.copyFileSync(dataSource, dataTarget);
    console.log(`✅ Exported training data to ${dataTarget}`);
  }

  // Copy political events
  const eventsSource =
    "/home/ubuntu/gold_price_predictor_clean/data/political_events.csv";
  const eventsTarget = path.join(mlExportDir, "political_events.csv");

  if (fs.existsSync(eventsSource)) {
    fs.copyFileSync(eventsSource, eventsTarget);
    console.log(`✅ Exported political events to ${eventsTarget}`);
  }

  console.log(`\n✅ ML data export completed: ${mlExportDir}`);
  return mlExportDir;
}

/**
 * Create backup of everything
 */
export async function createFullBackup(outputDir: string) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = path.join(outputDir, `full_backup_${timestamp}`);

  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  console.log("📦 Creating full backup...\n");

  // Export database
  const dbExport = await exportAllData(path.join(backupDir, "database"));

  // Export ML data
  const mlExport = await exportMLData(path.join(backupDir, "ml"));

  console.log(`\n✅ Full backup completed: ${backupDir}`);
  return backupDir;
}
