import nodemailer from "nodemailer";
import * as db from "./db-compat";

interface EmailSettings {
  recipientEmail: string;
  smtpHost?: string;
  smtpPort?: number;
  smtpUser?: string;
  smtpPassword?: string;
  fromEmail?: string;
  fromName?: string;
}

class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private settings: EmailSettings | null = null;

  async initialize(settings: EmailSettings) {
    this.settings = settings;

    // Use default Gmail SMTP if not specified
    const smtpConfig = {
      host: settings.smtpHost || "smtp.gmail.com",
      port: settings.smtpPort || 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: settings.smtpUser || process.env.EMAIL_USER,
        pass: settings.smtpPassword || process.env.EMAIL_PASSWORD,
      },
    };

    this.transporter = nodemailer.createTransport(smtpConfig);

    // Verify connection
    try {
      await this.transporter.verify();
      console.log("[Email] SMTP connection verified");
      return true;
    } catch (error) {
      console.error("[Email] SMTP connection failed:", error);
      return false;
    }
  }

  async sendPredictionReport(data: {
    assetName: string;
    predictedPrice: number;
    actualPrice: number;
    accuracy: number;
    events: any[];
    timestamp: string;
  }) {
    if (!this.transporter || !this.settings) {
      console.error("[Email] Email service not initialized");
      return false;
    }

    const {
      assetName,
      predictedPrice,
      actualPrice,
      accuracy,
      events,
      timestamp,
    } = data;

    const errorPercent =
      ((actualPrice - predictedPrice) / predictedPrice) * 100;
    const statusEmoji = accuracy >= 0.95 ? "✅" : accuracy >= 0.8 ? "⚠️" : "❌";

    const eventsHtml =
      events.length > 0
        ? events
            .map(
              e =>
                `<li><strong>${e.type}:</strong> ${e.description} (${e.severity})</li>`
            )
            .join("")
        : "<li>No significant events detected</li>";

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 10px 10px; }
          .metric { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #667eea; }
          .metric-label { font-size: 12px; color: #666; text-transform: uppercase; }
          .metric-value { font-size: 24px; font-weight: bold; color: #333; }
          .events { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
          .status-good { color: #10b981; }
          .status-warning { color: #f59e0b; }
          .status-bad { color: #ef4444; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${statusEmoji} تقرير التوقع - ${assetName}</h1>
            <p>تاريخ: ${new Date(timestamp).toLocaleString("ar-EG")}</p>
          </div>
          <div class="content">
            <div class="metric">
              <div class="metric-label">السعر المتوقع</div>
              <div class="metric-value">$${predictedPrice.toFixed(2)}</div>
            </div>
            
            <div class="metric">
              <div class="metric-label">السعر الفعلي</div>
              <div class="metric-value">$${actualPrice.toFixed(2)}</div>
            </div>
            
            <div class="metric">
              <div class="metric-label">نسبة الخطأ</div>
              <div class="metric-value ${errorPercent > 0 ? "status-bad" : "status-good"}">
                ${errorPercent > 0 ? "+" : ""}${errorPercent.toFixed(2)}%
              </div>
            </div>
            
            <div class="metric">
              <div class="metric-label">دقة التوقع</div>
              <div class="metric-value ${accuracy >= 0.95 ? "status-good" : accuracy >= 0.8 ? "status-warning" : "status-bad"}">
                ${(accuracy * 100).toFixed(2)}%
              </div>
            </div>
            
            <div class="events">
              <h3>الأحداث المؤثرة</h3>
              <ul>${eventsHtml}</ul>
            </div>
            
            ${
              accuracy < 0.8
                ? `
              <div class="metric" style="border-left-color: #ef4444;">
                <p style="color: #ef4444; font-weight: bold;">
                  ⚠️ تحذير: دقة التوقع أقل من 80%. تم إعادة تدريب النموذج تلقائياً.
                </p>
              </div>
            `
                : ""
            }
          </div>
          <div class="footer">
            <p>نظام توقع أسعار الأصول المالية - مدعوم بالذكاء الاصطناعي</p>
            <p>هذا تقرير تلقائي يُرسل كل 4 ساعات</p>
          </div>
        </div>
      </body>
      </html>
    `;

    try {
      await this.transporter.sendMail({
        from: `"${this.settings.fromName || "Asset Predictor"}" <${this.settings.fromEmail || this.settings.smtpUser}>`,
        to: this.settings.recipientEmail,
        subject: `${statusEmoji} تقرير توقع ${assetName} - دقة ${(accuracy * 100).toFixed(0)}%`,
        html: htmlContent,
      });

      console.log(`[Email] Report sent to ${this.settings.recipientEmail}`);
      return true;
    } catch (error) {
      console.error("[Email] Failed to send email:", error);
      return false;
    }
  }

  async sendSystemAlert(data: {
    title: string;
    message: string;
    severity: "info" | "warning" | "error";
  }) {
    if (!this.transporter || !this.settings) {
      console.error("[Email] Email service not initialized");
      return false;
    }

    const { title, message, severity } = data;
    const emoji =
      severity === "error" ? "❌" : severity === "warning" ? "⚠️" : "ℹ️";
    const color =
      severity === "error"
        ? "#ef4444"
        : severity === "warning"
          ? "#f59e0b"
          : "#3b82f6";

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .alert { background: ${color}; color: white; padding: 20px; border-radius: 10px; }
          .content { background: #f9f9f9; padding: 20px; margin-top: 20px; border-radius: 10px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="alert">
            <h1>${emoji} ${title}</h1>
          </div>
          <div class="content">
            <p>${message}</p>
            <p style="color: #666; font-size: 12px; margin-top: 20px;">
              تاريخ: ${new Date().toLocaleString("ar-EG")}
            </p>
          </div>
        </div>
      </body>
      </html>
    `;

    try {
      await this.transporter.sendMail({
        from: `"${this.settings.fromName || "Asset Predictor"}" <${this.settings.fromEmail || this.settings.smtpUser}>`,
        to: this.settings.recipientEmail,
        subject: `${emoji} ${title}`,
        html: htmlContent,
      });

      console.log(`[Email] Alert sent to ${this.settings.recipientEmail}`);
      return true;
    } catch (error) {
      console.error("[Email] Failed to send alert:", error);
      return false;
    }
  }
}

// Singleton instance
export const emailService = new EmailService();

// Initialize with user settings
export async function initializeEmailService(userId: string) {
  try {
    const user = await db.getUser(userId);

    if (!user || !(user as any).email) {
      console.error("[Email] User email not found");
      return false;
    }

    // Initialize with default settings
    // TODO: Add email settings table for custom SMTP config
    const settings: EmailSettings = {
      recipientEmail: (user as any).email,
      fromName: "Asset Predictor System",
    };

    return await emailService.initialize(settings);
  } catch (error) {
    console.error("[Email] Failed to initialize:", error);
    return false;
  }
}
