/**
 * AI Assistant Router
 * Endpoints for chatting with free and paid AI assistants
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { freeAI } from "../ai-free";
import { paidAI } from "../ai-paid";
// import { getDb } from "../db-compat"; // Removed unused import
import { aiMemoryService } from "../ai-memory-service";

export const aiRouter = router({
  /**
   * Chat with free AI assistant
   */
  chatFree: protectedProcedure
    .input(
      z.object({
        message: z.string().min(1).max(2000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const response = await freeAI.chat(ctx.user.id, input.message);

        return {
          success: response.wasSuccessful,
          message: response.message,
          tokensUsed: response.tokensUsed,
          responseTime: response.responseTime,
          errorMessage: response.errorMessage,
          assistantType: "free" as const,
        };
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : "حدث خطأ غير متوقع";
        return {
          success: false,
          message: "",
          tokensUsed: 0,
          responseTime: 0,
          errorMessage,
          assistantType: "free" as const,
        };
      }
    }),

  /**
   * Chat with paid AI assistant
   */
  chatPaid: protectedProcedure
    .input(
      z.object({
        message: z.string().min(1).max(5000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const response = await paidAI.chat(ctx.user.id, input.message);

        return {
          success: response.wasSuccessful,
          message: response.message,
          tokensUsed: response.tokensUsed,
          responseTime: response.responseTime,
          errorMessage: response.errorMessage,
          assistantType: "paid" as const,
        };
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : "حدث خطأ غير متوقع";
        return {
          success: false,
          message: "",
          tokensUsed: 0,
          responseTime: 0,
          errorMessage,
          assistantType: "paid" as const,
        };
      }
    }),

  /**
   * Get conversation history
   */
  getHistory: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
        limit: z.number().min(1).max(100).default(50),
      })
    )
    .query(async ({ ctx, input }) => {
      const { getAIConversations } = await import("../db-compat");
      const assistantId = input.assistantType === "free" ? 1 : 2;

      try {
        return await getAIConversations(ctx.user.id, assistantId, input.limit);
      } catch (error) {
        console.error("[AI Router] Failed to get history:", error);
        return [];
      }
    }),

  /**
   * Get usage statistics
   */
  getUsage: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
      })
    )
    .query(async ({ ctx, input }) => {
      const { getAIUsageLimits, getAIUsageStats } = await import("../db-compat");
      const assistantId = input.assistantType === "free" ? 1 : 2;

      try {
        // Get today's usage
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const limit = await getAIUsageLimits(ctx.user.id, assistantId) as any;

        let messagesToday = 0;
        let tokensToday = 0;

        if (limit) {
          const lastReset = new Date(limit.lastResetDate);
          lastReset.setHours(0, 0, 0, 0);

          // Only count if it's the same day
          if (today.getTime() === lastReset.getTime()) {
            messagesToday = limit.messagesToday || 0;
            tokensToday = limit.tokensToday || 0;
          }
        }

        // Get total usage
        const totalStats = await getAIUsageStats(ctx.user.id, assistantId) as any;

        return {
          messagesToday,
          tokensToday,
          totalMessages: totalStats?.totalMessages || 0,
          totalTokens: totalStats?.totalTokens || 0,
          limit: input.assistantType === "free" ? 10 : null,
          remaining:
            input.assistantType === "free"
              ? Math.max(0, 10 - messagesToday)
              : null,
        };
      } catch (error) {
        console.error("[AI Router] Failed to get usage:", error);
        return {
          messagesToday: 0,
          tokensToday: 0,
          totalMessages: 0,
          totalTokens: 0,
          limit: input.assistantType === "free" ? 10 : null,
          remaining: input.assistantType === "free" ? 10 : null,
        };
      }
    }),

  /**
   * Clear conversation history
   */
  clearHistory: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const assistant = input.assistantType === "free" ? freeAI : paidAI;
      await assistant.clearHistory(ctx.user.id);

      return { success: true };
    }),

  /**
   * Submit feedback for a conversation
   */
  submitFeedback: protectedProcedure
    .input(
      z.object({
        conversationId: z.number(),
        rating: z.number().min(1).max(5),
        feedback: z.string().max(1000).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { insertAIFeedback } = await import("../db-compat");

      await insertAIFeedback({
          conversationId: input.conversationId,
          userId: ctx.user.id,
          rating: input.rating,
          feedback: input.feedback || null,
          createdAt: Date.now()
      });

      return { success: true };
    }),

  /**
   * Get AI assistant info
   */
  getAssistantInfo: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
      })
    )
    .query(async ({ input }) => {
      const assistant = input.assistantType === "free" ? freeAI : paidAI;

      return {
        id: assistant.id,
        name: assistant.name,
        type: assistant.type,
        model: assistant.model,
        permissions: assistant.permissions,
        features:
          input.assistantType === "free"
            ? [
                "إجابات عامة عن الأسعار",
                "شرح مفاهيم التداول",
                "نصائح عامة",
                "10 رسائل يومياً",
              ]
            : [
                "تحليل عميق للأسعار",
                "البحث عن الأخبار المؤثرة",
                "تحليل المشاعر",
                "إنشاء توقعات مخصصة",
                "إنشاء تنبيهات",
                "تحليل المحفظة",
                "رسائل غير محدودة",
              ],
      };
    }),

  /**
   * Advanced: Create prediction (paid only)
   */
  createPrediction: protectedProcedure
    .input(
      z.object({
        assetId: z.number(),
        horizon: z.enum(["short", "medium", "long"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const prediction = await paidAI.createPrediction(
        ctx.user.id,
        input.assetId,
        input.horizon
      );

      return {
        success: true,
        prediction,
      };
    }),

  /**
   * Advanced: Create alert (paid only)
   */
  createAlert: protectedProcedure
    .input(
      z.object({
        assetId: z.number(),
        condition: z.enum(["above", "below"]),
        targetPrice: z.string(), // decimal as string for precision
      })
    )
    .mutation(async ({ ctx, input }) => {
      const alert = await paidAI.createAlert(
        ctx.user.id,
        input.assetId,
        input.condition,
        input.targetPrice
      );

      return {
        success: true,
        alert,
      };
    }),

  /**
   * Memory: Get user's stored memories
   */
  getMemories: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
        memoryType: z
          .enum(["fact", "preference", "context", "summary"])
          .optional(),
        limit: z.number().min(1).max(100).default(20),
      })
    )
    .query(async ({ ctx, input }) => {
      const assistantId = input.assistantType === "free" ? 1 : 2;
      return aiMemoryService.getMemories(ctx.user.id, assistantId, {
        memoryType: input.memoryType,
        limit: input.limit,
      });
    }),

  /**
   * Memory: Store a memory manually
   */
  storeMemory: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
        memoryType: z.enum(["fact", "preference", "context", "summary"]),
        key: z.string().min(1).max(100),
        value: z.string().min(1).max(1000),
        importance: z.number().min(0).max(10).default(5),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const assistantId = input.assistantType === "free" ? 1 : 2;
      const memory = aiMemoryService.storeMemory({
        userId: ctx.user.id,
        assistantId,
        memoryType: input.memoryType,
        key: input.key,
        value: input.value,
        importance: input.importance,
      });

      return { success: !!memory, memory };
    }),

  /**
   * Memory: Delete a specific memory
   */
  deleteMemory: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
        key: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const assistantId = input.assistantType === "free" ? 1 : 2;
      const success = aiMemoryService.deleteMemory(
        ctx.user.id,
        assistantId,
        input.key
      );
      return { success };
    }),

  /**
   * Memory: Clear all memories for an assistant
   */
  clearMemories: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const assistantId = input.assistantType === "free" ? 1 : 2;
      const success = aiMemoryService.clearMemories(ctx.user.id, assistantId);
      return { success };
    }),

  /**
   * Memory: Search memories by keyword
   */
  searchMemories: protectedProcedure
    .input(
      z.object({
        assistantType: z.enum(["free", "paid"]),
        keyword: z.string().min(1),
        limit: z.number().min(1).max(50).default(10),
      })
    )
    .query(async ({ ctx, input }) => {
      const assistantId = input.assistantType === "free" ? 1 : 2;
      return aiMemoryService.searchMemories(
        ctx.user.id,
        assistantId,
        input.keyword,
        input.limit
      );
    }),
});
