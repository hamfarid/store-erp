/**
 * FILE: server/routers/drift.ts
 * PURPOSE: tRPC router for drift detection
 * OWNER: ML Team
 * RELATED: server/ml/drift-detection/, drizzle/schema-drift.ts
 * LAST-AUDITED: 2025-01-18
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import {
  getDriftDetections,
  getDriftAlerts,
  acknowledgeDriftAlert,
  getDriftMetricsHistory,
  getModelRetrainingLog
} from "../db-compat";
import { monitorDrift } from "../ml/drift-detection/drift-monitor";
import { trainAutoencoder } from "../ml/drift-detection/autoencoder-detector";

export const driftRouter = router({
  /**
   * Monitor drift for a symbol
   */
  monitorDrift: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        baselineData: z.record(z.string(), z.array(z.number())),
        currentData: z.record(z.string(), z.array(z.number())),
        usePSI: z.boolean().optional(),
        useKSTest: z.boolean().optional(),
        useAutoencoder: z.boolean().optional(),
        autoencoderData: z.array(z.array(z.number())).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const result = await monitorDrift(
        input.symbol,
        input.baselineData,
        input.currentData,
        {
          usePSI: input.usePSI,
          useKSTest: input.useKSTest,
          useAutoencoder: input.useAutoencoder,
          autoencoderData: input.autoencoderData,
        }
      );

      return result;
    }),

  /**
   * Train autoencoder for a symbol
   */
  trainAutoencoder: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        baselineData: z.array(z.array(z.number())),
        epochs: z.number().optional(),
        latentDim: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const result = await trainAutoencoder(
        input.symbol,
        input.baselineData,
        input.epochs,
        input.latentDim
      );

      return result;
    }),

  /**
   * Get drift detections for a symbol
   */
  getDriftDetections: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const detections = await getDriftDetections({
          symbol: input.symbol,
          limit: input.limit
      });

      return detections.map((d: any) => ({
        ...d,
        details: d.details ? (typeof d.details === 'string' ? JSON.parse(d.details) : d.details) : null,
      }));
    }),

  /**
   * Get drift alerts
   */
  getDriftAlerts: protectedProcedure
    .input(
      z.object({
        acknowledged: z.boolean().optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await getDriftAlerts(input.acknowledged, input.limit);
    }),

  /**
   * Acknowledge drift alert
   */
  acknowledgeDriftAlert: protectedProcedure
    .input(
      z.object({
        alertId: z.string(),
        acknowledgedBy: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      await acknowledgeDriftAlert(input.alertId, input.acknowledgedBy);
      return { success: true };
    }),

  /**
   * Get drift metrics history
   */
  getDriftMetricsHistory: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        detectorType: z.enum(["psi", "ks_test", "autoencoder"]).optional(),
        days: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await getDriftMetricsHistory(input.symbol, input.detectorType, input.days);
    }),

  /**
   * Get model retraining log
   */
  getModelRetrainingLog: protectedProcedure
    .input(
      z.object({
        symbol: z.string().optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const logs = await getModelRetrainingLog(input.symbol, input.limit);

      return logs.map((log: any) => ({
        ...log,
        metrics: log.metrics ? (typeof log.metrics === 'string' ? JSON.parse(log.metrics) : log.metrics) : null,
      }));
    }),
});
