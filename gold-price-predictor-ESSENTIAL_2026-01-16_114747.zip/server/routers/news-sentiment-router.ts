/**
 * News Sentiment Router
 * API endpoints for news sentiment analysis
 */

import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import {
  fetchNewsArticles,
  analyzeSentiment,
  getAssetSentiment,
  getSentimentTrend,
} from "../services/news-sentiment";
import {
  insertSentimentHistory,
  getSentimentHistory
} from "../db-compat";

export const newsSentimentRouter = router({
  /**
   * Get sentiment for a specific asset
   */
  getAssetSentiment: publicProcedure
    .input(
      z.object({
        symbol: z.string().default("XAUUSD"),
        days: z.number().min(1).max(30).default(7),
      })
    )
    .query(async ({ input }) => {
      return await getAssetSentiment(input.symbol, input.days);
    }),

  /**
   * Get sentiment trend over time
   */
  getSentimentTrend: publicProcedure
    .input(
      z.object({
        symbol: z.string().default("XAUUSD"),
        days: z.number().min(7).max(90).default(30),
      })
    )
    .query(async ({ input }) => {
      return await getSentimentTrend(input.symbol, input.days);
    }),

  /**
   * Fetch latest news articles
   */
  getLatestNews: publicProcedure
    .input(
      z.object({
        query: z.string().default("gold price"),
        days: z.number().min(1).max(7).default(3),
      })
    )
    .query(async ({ input }) => {
      const articles = await fetchNewsArticles(
        input.query,
        new Date(Date.now() - input.days * 24 * 60 * 60 * 1000)
      );
      
      // Analyze sentiment for each article
      return articles.slice(0, 20).map(article => ({
        ...article,
        sentiment: analyzeSentiment(`${article.title} ${article.description}`),
      }));
    }),

  /**
   * Analyze custom text sentiment
   */
  analyzeText: publicProcedure
    .input(z.object({ text: z.string() }))
    .mutation(({ input }) => {
      return analyzeSentiment(input.text);
    }),

  /**
   * Get market summary with multiple assets
   */
  getMarketSummary: publicProcedure.query(async () => {
    const assets = [
      { symbol: "XAUUSD", name: "الذهب" },
      { symbol: "XAGUSD", name: "الفضة" },
      { symbol: "BTCUSD", name: "بيتكوين" },
      { symbol: "oil price", name: "النفط" },
    ];

    const results = await Promise.all(
      assets.map(async asset => {
        const sentiment = await getAssetSentiment(asset.symbol, 3);
        return {
          ...asset,
          ...sentiment,
        };
      })
    );

    return results;
  }),

  /**
   * Get news by category
   */
  getNewsByCategory: publicProcedure
    .input(
      z.object({
        category: z.enum([
          "gold",
          "silver",
          "crypto",
          "oil",
          "economy",
          "stocks",
        ]),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const categoryQueries: Record<string, string> = {
        gold: "gold price OR XAUUSD OR gold market",
        silver: "silver price OR XAGUSD OR silver market",
        crypto: "bitcoin OR cryptocurrency OR ethereum",
        oil: "oil price OR crude oil OR WTI OR Brent",
        economy: "economy OR inflation OR interest rates OR Federal Reserve",
        stocks: "stock market OR S&P 500 OR Dow Jones",
      };

      const articles = await fetchNewsArticles(
        categoryQueries[input.category],
        new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
      );

      return articles.slice(0, input.limit).map(article => ({
        ...article,
        sentiment: analyzeSentiment(`${article.title} ${article.description}`),
      }));
    }),

  /**
   * Save sentiment analysis to database
   */
  saveSentimentAnalysis: protectedProcedure
    .input(
      z.object({
        assetSymbol: z.string(),
        score: z.number(),
        label: z.string(),
        articlesCount: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        await insertSentimentHistory(
          ctx.user.id,
          input.assetSymbol,
          input.score,
          input.label,
          input.articlesCount
        );

        return { success: true };
      } catch (error) {
        console.error("Failed to save sentiment analysis:", error);
        return { success: false };
      }
    }),

  /**
   * Get sentiment history from database
   */
  getSentimentHistory: protectedProcedure
    .input(
      z.object({
        assetSymbol: z.string().optional(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        return await getSentimentHistory(
            ctx.user.id,
            input.assetSymbol,
            input.limit
        );
      } catch (error) {
        console.error("Failed to get sentiment history:", error);
        return [];
      }
    }),
});


