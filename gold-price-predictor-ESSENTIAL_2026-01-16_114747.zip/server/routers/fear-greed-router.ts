/**
 * Fear & Greed Index Router
 * Provides Fear & Greed Index data and analysis
 */

import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import {
  fetchCurrentFearGreed,
  fetchFearGreedHistory,
  fetchAlternativeFearGreed,
  calculateAverageFearGreed,
  detectFearGreedTrend,
  getFearGreedSignal,
  calculateFearGreedMomentum,
  getFearGreedColor,
  classifyFearGreed,
} from "../services/fear-greed-index";

export const fearGreedRouter = router({
  /**
   * Get current Fear & Greed Index
   */
  getCurrent: publicProcedure.query(async () => {
    try {
      // Try alternative API first (more reliable)
      const data = await fetchAlternativeFearGreed();
      return {
        ...data,
        color: getFearGreedColor(data.value),
        signal: getFearGreedSignal(data.value),
      };
    } catch (error) {
      console.error("Failed to fetch Fear & Greed Index:", error);
      // Return mock data if API fails
      const mockValue = 45;
      return {
        value: mockValue,
        classification: classifyFearGreed(mockValue),
        timestamp: new Date(),
        color: getFearGreedColor(mockValue),
        signal: getFearGreedSignal(mockValue),
      };
    }
  }),

  /**
   * Get Fear & Greed history
   */
  getHistory: publicProcedure
    .input(z.object({ days: z.number().min(1).max(365).default(30) }))
    .query(async ({ input }) => {
      try {
        const history = await fetchFearGreedHistory(input.days);
        return history.map(item => ({
          ...item,
          color: getFearGreedColor(item.value),
        }));
      } catch (error) {
        console.error("Failed to fetch Fear & Greed history:", error);
        return [];
      }
    }),

  /**
   * Get Fear & Greed analysis
   */
  getAnalysis: publicProcedure
    .input(z.object({ days: z.number().min(7).max(365).default(30) }))
    .query(async ({ input }) => {
      try {
        const history = await fetchFearGreedHistory(input.days);
        const current = await fetchAlternativeFearGreed();
        
        const trend = detectFearGreedTrend(history);
        const average7d = calculateAverageFearGreed(history, 7);
        const average30d = calculateAverageFearGreed(history, Math.min(30, history.length));
        const momentum = calculateFearGreedMomentum(history, 14);
        
        // Find extremes
        const values = history.map(h => h.value);
        const maxValue = Math.max(...values);
        const minValue = Math.min(...values);
        
        // Count days in each zone
        const zoneCount = {
          extremeFear: history.filter(h => h.value <= 25).length,
          fear: history.filter(h => h.value > 25 && h.value <= 45).length,
          neutral: history.filter(h => h.value > 45 && h.value <= 55).length,
          greed: history.filter(h => h.value > 55 && h.value <= 75).length,
          extremeGreed: history.filter(h => h.value > 75).length,
        };
        
        return {
          current: {
            value: current.value,
            classification: current.classification,
            color: getFearGreedColor(current.value),
            signal: getFearGreedSignal(current.value),
          },
          trend,
          momentum,
          averages: {
            days7: average7d,
            days30: average30d,
          },
          extremes: {
            max: maxValue,
            min: minValue,
          },
          zoneDistribution: zoneCount,
          totalDays: history.length,
        };
      } catch (error) {
        console.error("Failed to get Fear & Greed analysis:", error);
        return null;
      }
    }),

  /**
   * Get trading signal based on Fear & Greed
   */
  getSignal: publicProcedure.query(async () => {
    try {
      const current = await fetchAlternativeFearGreed();
      const history = await fetchFearGreedHistory(14);
      
      const trend = detectFearGreedTrend(history);
      const momentum = calculateFearGreedMomentum(history, 14);
      const signal = getFearGreedSignal(current.value);
      
      // Calculate confidence based on momentum and trend alignment
      let confidence = 0.5;
      if (signal === "buy" && trend === "falling") {confidence = 0.7;}
      if (signal === "sell" && trend === "rising") {confidence = 0.7;}
      if (signal === "buy" && momentum < -10) {confidence = 0.8;}
      if (signal === "sell" && momentum > 10) {confidence = 0.8;}
      
      return {
        signal,
        value: current.value,
        classification: current.classification,
        trend,
        momentum,
        confidence,
        reasoning: getSignalReasoning(signal, current.value, trend, momentum),
      };
    } catch (error) {
      console.error("Failed to get Fear & Greed signal:", error);
      return {
        signal: "hold" as const,
        value: 50,
        classification: "Neutral" as const,
        trend: "stable" as const,
        momentum: 0,
        confidence: 0.5,
        reasoning: "Unable to fetch Fear & Greed data",
      };
    }
  }),
});

function getSignalReasoning(
  signal: "buy" | "sell" | "hold",
  value: number,
  trend: "rising" | "falling" | "stable",
  momentum: number
): string {
  if (signal === "buy") {
    if (value <= 20) {
      return "Extreme fear presents a potential buying opportunity. Markets often overreact to negative news.";
    }
    return "Fear levels suggest undervaluation. Consider accumulating positions.";
  }
  
  if (signal === "sell") {
    if (value >= 80) {
      return "Extreme greed indicates market euphoria. Consider taking profits.";
    }
    return "High greed levels suggest potential overvaluation. Consider reducing positions.";
  }
  
  return `Market sentiment is neutral (${value}). No strong contrarian signal at this time.`;
}

