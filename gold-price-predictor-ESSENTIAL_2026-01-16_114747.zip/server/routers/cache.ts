/**
 * FILE: server/routers/cache.ts
 * PURPOSE: tRPC router for cache management
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { z } from 'zod';
import { router, protectedProcedure, adminProcedure } from '../_core/trpc';
import { cacheService, CACHE_KEYS, CACHE_TTL } from '../cache/cacheService';

export const cacheRouter = router({
  // Get cache statistics
  stats: protectedProcedure
    .query(async () => {
      return await cacheService.getStats();
    }),

  // Get specific cache entry
  get: adminProcedure
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const value = await cacheService.get(input.key);
      const ttl = await cacheService.getTTL(input.key);
      return { value, ttl };
    }),

  // Invalidate specific key
  invalidate: adminProcedure
    .input(z.object({ key: z.string() }))
    .mutation(async ({ input }) => {
      const deleted = await cacheService.delete(input.key);
      return { success: deleted };
    }),

  // Invalidate pattern
  invalidatePattern: adminProcedure
    .input(z.object({ pattern: z.string() }))
    .mutation(async ({ input }) => {
      const count = await cacheService.deletePattern(input.pattern);
      return { success: count > 0, count };
    }),

  // Invalidate user cache
  invalidateUser: adminProcedure
    .input(z.object({ userId: z.string() }))
    .mutation(async ({ input }) => {
      await cacheService.invalidateUser(input.userId);
      return { success: true };
    }),

  // Invalidate asset cache
  invalidateAsset: adminProcedure
    .input(z.object({ assetId: z.number() }))
    .mutation(async ({ input }) => {
      await cacheService.invalidateAsset(input.assetId);
      return { success: true };
    }),

  // Get all cache keys
  keys: adminProcedure
    .input(z.object({ pattern: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const pattern = input?.pattern || '*';
      const keys = await cacheService.getKeys(pattern);
      return { keys };
    }),

  // Clear all cache (USE WITH CAUTION!)
  clearAll: adminProcedure
    .mutation(async () => {
      await cacheService.invalidateAll();
      return { success: true };
    }),
});
