import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import axios from "axios";

// ML API base URL (from environment or default)
const ML_API_URL = process.env.ML_API_URL || "http://localhost:2105";

/**
 * Models Router
 * Handles ML model operations and predictions
 */
export const modelsRouter = router({
  /**
   * Get list of available models
   */
  list: publicProcedure.query(async () => {
    try {
      const response = await axios.get(`${ML_API_URL}/models`);
      return response.data;
    } catch (error) {
      console.error("Failed to fetch models:", error);
      throw new Error("Failed to fetch models from ML API");
    }
  }),

  /**
   * Get model information
   */
  getInfo: publicProcedure
    .input(
      z.object({
        asset: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const response = await axios.get(`${ML_API_URL}/models/${input.asset}`);
        return response.data;
      } catch (error) {
        console.error(`Failed to fetch model info for ${input.asset}:`, error);
        throw new Error(`Model not found for asset: ${input.asset}`);
      }
    }),

  /**
   * Make a single prediction
   */
  predict: protectedProcedure
    .input(
      z.object({
        asset: z.string(),
        features: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await axios.post(`${ML_API_URL}/predict`, {
          asset: input.asset,
          features: input.features,
        });
        return response.data;
      } catch (error: any) {
        console.error(`Failed to make prediction for ${input.asset}:`, error);
        throw new Error(
          error.response?.data?.detail || "Failed to make prediction"
        );
      }
    }),

  /**
   * Make predictions for multiple days
   */
  predictMultipleDays: protectedProcedure
    .input(
      z.object({
        asset: z.string(),
        days: z.number().min(1).max(365).default(30),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await axios.post(`${ML_API_URL}/predict/multiple`, {
          asset: input.asset,
          days: input.days,
        });
        return response.data;
      } catch (error: any) {
        console.error(
          `Failed to make multiple predictions for ${input.asset}:`,
          error
        );
        throw new Error(
          error.response?.data?.detail ||
            "Failed to make multiple predictions"
        );
      }
    }),

  /**
   * Get latest data from dataset
   */
  getLatestData: publicProcedure.query(async () => {
    try {
      const response = await axios.get(`${ML_API_URL}/data/latest`);
      return response.data;
    } catch (error) {
      console.error("Failed to fetch latest data:", error);
      throw new Error("Failed to fetch latest data");
    }
  }),

  /**
   * Get historical data
   */
  getHistoricalData: publicProcedure
    .input(
      z.object({
        days: z.number().min(1).max(3650).default(30),
      })
    )
    .query(async ({ input }) => {
      try {
        const response = await axios.get(
          `${ML_API_URL}/data/historical?days=${input.days}`
        );
        return response.data;
      } catch (error) {
        console.error("Failed to fetch historical data:", error);
        throw new Error("Failed to fetch historical data");
      }
    }),

  /**
   * Health check for ML API
   */
  healthCheck: publicProcedure.query(async () => {
    try {
      const response = await axios.get(`${ML_API_URL}/health`);
      return {
        ...response.data,
        api_url: ML_API_URL,
      };
    } catch (error) {
      console.error("ML API health check failed:", error);
      return {
        status: "unhealthy",
        error: "Failed to connect to ML API",
        api_url: ML_API_URL,
      };
    }
  }),
});

