/**
 * FILE: server/routers/events.ts
 * PURPOSE: tRPC router for Events subsystem
 * OWNER: Backend Team
 * RELATED: server/services/events/eventsDb.ts, drizzle/schema-events.ts
 * LAST-AUDITED: 2025-12-18
 */

import { z } from "zod";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import * as db from "../services/events/eventsDb";
import { logError } from "../logger";

// ==================== Events Router ====================

export const eventsRouter = router({
  list: protectedProcedure
    .input(
      z
        .object({
          eventType: z
            .enum([
              "political",
              "economic",
              "geopolitical",
              "monetary_policy",
              "market",
              "commodity",
              "natural_disaster",
              "war",
              "sanctions",
              "other",
            ])
            .optional(),
          severity: z.enum(["low", "medium", "high", "critical"]).optional(),
          verified: z.boolean().optional(),
          startDate: z.string().datetime().optional(), // ISO 8601 datetime string
          endDate: z.string().datetime().optional(), // ISO 8601 datetime string
          limit: z.number().min(1).max(1000).optional(),
          offset: z.number().min(0).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const filters = input
        ? {
            ...input,
            startDate: input.startDate ? new Date(input.startDate) : undefined,
            endDate: input.endDate ? new Date(input.endDate) : undefined,
          }
        : undefined;

      try {
        return await db.getAllEvents(filters);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "events-router",
          component: "list",
          message: `Failed to list events: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { filters },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list events",
        });
      }
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.string().min(1) }))
    .query(async ({ input }) => {
      const event = await db.getEventById(input.id);
      if (!event) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return event;
    }),

  getWithAnalysis: protectedProcedure
    .input(z.object({ id: z.string().min(1) }))
    .query(async ({ input }) => {
      const result = await db.getEventWithAnalysis(input.id);
      if (!result) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return result;
    }),

  getWithImpacts: protectedProcedure
    .input(z.object({ id: z.string().min(1) }))
    .query(async ({ input }) => {
      const result = await db.getEventWithImpacts(input.id);
      if (!result) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return result;
    }),

  create: adminProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        description: z.string().optional(),
        eventType: z.enum([
          "political",
          "economic",
          "geopolitical",
          "monetary_policy",
          "market",
          "commodity",
          "natural_disaster",
          "war",
          "sanctions",
          "other",
        ]),
        eventDate: z.string().datetime(), // ISO 8601 datetime string
        source: z.string().optional(),
        sourceUrl: z
          .string()
          .url({ message: "Invalid URL format" })
          .optional()
          .or(z.literal("")),
        severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        verified: z.boolean().optional(),
        tags: z
          .array(z.string().min(1).max(50))
          .max(20, { message: "Maximum 20 tags allowed" })
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const eventId = nanoid();
        const event = await db.createEvent({
          id: eventId,
          title: input.title,
          description: input.description || null,
          eventType: input.eventType,
          eventDate: new Date(input.eventDate),
          source: input.source || null,
          sourceUrl: input.sourceUrl || null,
          severity: input.severity || "medium",
          verified: input.verified || false,
          tags: input.tags || null,
        });

        return event;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "events-router",
          component: "create",
          message: `Failed to create event: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { input: { ...input, eventDate: input.eventDate } },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create event",
        });
      }
    }),

  update: adminProcedure
    .input(
      z.object({
        id: z.string().min(1),
        title: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        eventType: z
          .enum([
            "political",
            "economic",
            "geopolitical",
            "monetary_policy",
            "market",
            "commodity",
            "natural_disaster",
            "war",
            "sanctions",
            "other",
          ])
          .optional(),
        eventDate: z.string().optional(), // ISO string
        source: z.string().optional(),
        sourceUrl: z
          .string()
          .url({ message: "Invalid URL format" })
          .optional()
          .or(z.literal("")),
        severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        verified: z.boolean().optional(),
        tags: z
          .array(z.string().min(1).max(50))
          .max(20, { message: "Maximum 20 tags allowed" })
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...updates } = input;
      const updateData: any = {};

      if (updates.title !== undefined) {updateData.title = updates.title;}
      if (updates.description !== undefined)
        {updateData.description = updates.description;}
      if (updates.eventType !== undefined)
        {updateData.eventType = updates.eventType;}
      if (updates.eventDate !== undefined)
        {updateData.eventDate = new Date(updates.eventDate);}
      if (updates.source !== undefined) {updateData.source = updates.source;}
      if (updates.sourceUrl !== undefined)
        {updateData.sourceUrl = updates.sourceUrl || null;}
      if (updates.severity !== undefined) {updateData.severity = updates.severity;}
      if (updates.verified !== undefined) {updateData.verified = updates.verified;}
      if (updates.tags !== undefined) {updateData.tags = updates.tags;}

      const event = await db.updateEvent(id, updateData);
      if (!event) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return event;
    }),

  delete: adminProcedure
    .input(z.object({ id: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const success = await db.deleteEvent(input.id);
      if (!success) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return { success: true };
    }),

  createWithAnalysis: adminProcedure
    .input(
      z.object({
        // Event data
        title: z.string().min(1).max(255),
        description: z.string().optional(),
        eventType: z.enum([
          "political",
          "economic",
          "geopolitical",
          "monetary_policy",
          "market",
          "commodity",
          "natural_disaster",
          "war",
          "sanctions",
          "other",
        ]),
        eventDate: z.string().datetime(), // ISO 8601 datetime string
        source: z.string().optional(),
        sourceUrl: z
          .string()
          .url({ message: "Invalid URL format" })
          .optional()
          .or(z.literal("")),
        severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        verified: z.boolean().optional(),
        tags: z
          .array(z.string().min(1).max(50))
          .max(20, { message: "Maximum 20 tags allowed" })
          .optional(),
        // Analysis data
        sentiment: z.enum(["positive", "neutral", "negative"]).optional(),
        sentimentScore: z.string().optional(), // -1 to 1
        impactScore: z.string().optional(), // 0 to 10
        confidence: z.string().optional(), // 0 to 1
        entities: z
          .array(
            z.record(z.string().min(1), z.unknown()).refine(
              (entity) => {
                try {
                  JSON.stringify(entity);
                  return true;
                } catch {
                  return false;
                }
              },
              { message: "Entity must be valid JSON" }
            )
          )
          .max(100, { message: "Maximum 100 entities allowed" })
          .optional(),
        keywords: z.array(z.string()).optional(),
        summary: z.string().optional(),
        analyzerVersion: z.string().optional(),
      })
        .refine(
          (data) => {
            // Business logic: Event date should not be too far in the future
            const eventDate = new Date(data.eventDate);
            const maxFutureDate = new Date();
            maxFutureDate.setFullYear(maxFutureDate.getFullYear() + 1);
            return eventDate <= maxFutureDate;
          },
          {
            message: "Event date cannot be more than 1 year in the future",
            path: ["eventDate"],
          }
        )
        .refine(
          (data) => {
            // Business logic: Impact score should correlate with severity if provided
            if (data.impactScore && data.severity) {
              const impactScore = parseFloat(data.impactScore);
              const severityMap: Record<string, { min: number; max: number }> = {
                low: { min: 0, max: 30 },
                medium: { min: 20, max: 60 },
                high: { min: 50, max: 85 },
                critical: { min: 70, max: 100 },
              };
              const range = severityMap[data.severity];
              if (range) {
                return impactScore >= range.min && impactScore <= range.max;
              }
            }
            return true;
          },
          {
            message: "Impact score does not match event severity",
            path: ["impactScore"],
          }
        )
    )
    .mutation(async ({ input }) => {
      try {
        const eventId = nanoid();
        
        // Create event with analysis in a single transaction
        const result = await db.createEventWithAnalysis(
          {
            id: eventId,
            title: input.title,
            description: input.description || null,
            eventType: input.eventType,
            eventDate: new Date(input.eventDate),
            source: input.source || null,
            sourceUrl: input.sourceUrl || null,
            severity: input.severity || "medium",
            verified: input.verified || false,
            tags: input.tags || null,
          },
          {
            sentiment: input.sentiment || null,
            sentimentScore: input.sentimentScore || null,
            impactScore: input.impactScore || null,
            confidence: input.confidence || null,
            entities: input.entities || null,
            keywords: input.keywords || null,
            summary: input.summary || null,
            analyzerVersion: input.analyzerVersion || null,
          }
        );

        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "events-router",
          component: "createWithAnalysis",
          message: `Failed to create event with analysis: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { 
            eventTitle: input.title,
            eventType: input.eventType,
          },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create event with analysis",
        });
      }
    }),
});

