/**
 * Admin tRPC Router
 * Handles admin operations (user management, system stats)
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import * as db from "../db-compat";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Admin access required',
    });
  }
  return next({ ctx });
});

export const adminRouter = router({
  // Get system statistics
  stats: adminProcedure.query(async () => {
    return await db.getSystemStats();
  }),

  // Get all users
  users: router({
    list: adminProcedure
      .input(
        z.object({
          limit: z.number().default(50),
          offset: z.number().default(0),
          search: z.string().optional(),
          role: z.enum(["all", "admin", "user"]).optional(),
        })
      )
      .query(async ({ input }) => {
        return await db.getAllUsersAdmin(input);
      }),

    get: adminProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        return await db.getUserByIdAdmin(input.userId);
      }),

    update: adminProcedure
      .input(
        z.object({
          userId: z.string(),
          role: z.enum(["admin", "user"]).optional(),
          name: z.string().optional(),
          email: z.string().email().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { userId, ...updates } = input;
        return await db.updateUserAdmin(userId, updates);
      }),

    delete: adminProcedure
      .input(z.object({ userId: z.string() }))
      .mutation(async ({ input }) => {
        return await db.deleteUser(input.userId);
      }),

    stats: adminProcedure.query(async () => {
      return await db.getUserStats();
    }),
  }),

  // Asset management
  assets: router({
    list: adminProcedure.query(async () => {
      return await db.getAllAssetsAdmin();
    }),

    create: adminProcedure
      .input(
        z.object({
          symbol: z.string(),
          name: z.string(),
          type: z.string(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createAssetAdmin(input);
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          symbol: z.string().optional(),
          name: z.string().optional(),
          type: z.string().optional(),
          description: z.string().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await db.updateAssetAdmin(id, updates);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteAssetAdmin(input.id);
      }),
  }),

  // System logs
  logs: router({
    list: adminProcedure
      .input(
        z.object({
          limit: z.number().default(100),
          offset: z.number().default(0),
          level: z.enum(["all", "error", "warn", "info", "debug"]).optional(),
          startDate: z.string().optional(),
          endDate: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return await db.getSystemLogs(input);
      }),

    clear: adminProcedure
      .input(
        z.object({
          olderThan: z.string().optional(), // ISO date string
        })
      )
      .mutation(async ({ input }) => {
        return await db.clearSystemLogs(input.olderThan);
      }),
  }),

  // Database management
  database: router({
    stats: adminProcedure.query(async () => {
      return await db.getDatabaseStats();
    }),

    backup: adminProcedure.mutation(async () => {
      return await db.createDatabaseBackup();
    }),

    optimize: adminProcedure.mutation(async () => {
      return await db.optimizeDatabase();
    }),
  }),

  // System configuration
  config: router({
    get: adminProcedure.query(async () => {
      return await db.getSystemConfig();
    }),

    update: adminProcedure
      .input(
        z.object({
          key: z.string(),
          value: z.any(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.updateSystemConfig(input.key, input.value);
      }),
  }),
});


