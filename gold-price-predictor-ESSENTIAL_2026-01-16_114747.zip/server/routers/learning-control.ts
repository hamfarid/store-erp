/**
 * FILE: server/routers/learning-control.ts
 * PURPOSE: tRPC router for Learning & Search Control Dashboard
 * OWNER: Backend Team
 * RELATED: server/db-learning-control.ts, drizzle/schema-learning-control.ts
 * LAST-AUDITED: 2025-01-18
 */

import { z } from "zod";
import { nanoid } from "nanoid";
import { router, protectedProcedure } from "../_core/trpc";
import * as db from "../db-learning-control";
import { wsManager, WS_CHANNELS } from "../_core/websocket";

// ==================== Keywords ====================

const keywordsRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        category: z.string().optional(),
        priority: z.string().optional(),
        enabled: z.boolean().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      return await db.getAllKeywords(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getKeywordById(input.id);
    }),

  create: protectedProcedure
    .input(
      z.object({
        keyword: z.string().min(1),
        category: z.enum([
          "political",
          "economic",
          "geopolitical",
          "monetary_policy",
          "market",
          "commodity",
          "general",
        ]),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        enabled: z.boolean().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const keyword = await db.createKeyword({
        ...input,
        priority: input.priority || "medium",
        enabled: input.enabled !== undefined ? input.enabled : true,
        createdBy: ctx.user?.id,
      });

      // Broadcast update
      wsManager.broadcast(WS_CHANNELS.KEYWORD_UPDATE, {
        type: "keyword_created",
        data: keyword,
      });

      return keyword;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        keyword: z.string().optional(),
        category: z.enum([
          "political",
          "economic",
          "geopolitical",
          "monetary_policy",
          "market",
          "commodity",
          "general",
        ]).optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        enabled: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...updates } = input;
      const keyword = await db.updateKeyword(id, updates);

      if (keyword) {
        // Broadcast update
        wsManager.broadcast(WS_CHANNELS.KEYWORD_UPDATE, {
          type: "keyword_updated",
          data: keyword,
        });
      }

      return keyword;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const success = await db.deleteKeyword(input.id);

      if (success) {
        // Broadcast update
        wsManager.broadcast(WS_CHANNELS.KEYWORD_UPDATE, {
          type: "keyword_deleted",
          data: { id: input.id },
        });
      }

      return { success };
    }),
});

// ==================== Sources ====================

const sourcesRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        type: z.string().optional(),
        enabled: z.boolean().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      return await db.getAllSources(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getSourceById(input.id);
    }),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        type: z.enum([
          "search_engine",
          "news_site",
          "financial_site",
          "government_site",
          "social_media",
          "api",
        ]),
        url: z
          .string()
          .url({ message: "Invalid URL format" })
          .refine(
            (url) => {
              try {
                const parsed = new URL(url);
                return ["http:", "https:"].includes(parsed.protocol);
              } catch {
                return false;
              }
            },
            { message: "URL must use http or https protocol" }
          ),
        enabled: z.boolean().optional(),
        config: z
          .record(z.string().min(1), z.unknown())
          .refine(data => Object.keys(data).length <= 50, { message: "Maximum 50 config keys allowed" })
          .refine(
            (config) => {
              try {
                JSON.stringify(config);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Config must be valid JSON" }
          )
          .optional(),
        headers: z
          .record(z.string().min(1), z.string())
          .refine(data => Object.keys(data).length <= 20, { message: "Maximum 20 headers allowed" })
          .optional(),
        rateLimit: z.number().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const source = await db.createSource({
        ...input,
        enabled: input.enabled !== undefined ? input.enabled : true,
        rateLimit: input.rateLimit || 60,
        createdBy: ctx.user?.id,
      });

      // Broadcast update
      wsManager.broadcast(WS_CHANNELS.SOURCE_UPDATE, {
        type: "source_created",
        data: source,
      });

      return source;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        type: z.enum([
          "search_engine",
          "news_site",
          "financial_site",
          "government_site",
          "social_media",
          "api",
        ]).optional(),
        url: z.string().url().optional(),
        enabled: z.boolean().optional(),
        config: z
          .record(z.string().min(1), z.unknown())
          .refine(data => Object.keys(data).length <= 50, { message: "Maximum 50 config keys allowed" })
          .refine(
            (config) => {
              try {
                JSON.stringify(config);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Config must be valid JSON" }
          )
          .optional(),
        headers: z
          .record(z.string().min(1), z.string())
          .refine(data => Object.keys(data).length <= 20, { message: "Maximum 20 headers allowed" })
          .optional(),
        rateLimit: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...updates } = input;
      const source = await db.updateSource(id, updates);

      if (source) {
        // Broadcast update
        wsManager.broadcast(WS_CHANNELS.SOURCE_UPDATE, {
          type: "source_updated",
          data: source,
        });
      }

      return source;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const success = await db.deleteSource(input.id);

      if (success) {
        // Broadcast update
        wsManager.broadcast(WS_CHANNELS.SOURCE_UPDATE, {
          type: "source_deleted",
          data: { id: input.id },
        });
      }

      return { success };
    }),
});

// ==================== Learning Operations ====================

const learningRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        type: z.string().optional(), // Will be validated by enum in create/update
        status: z
          .enum(["pending", "running", "completed", "failed", "cancelled"])
          .optional(),
        triggeredBy: z.string().min(1).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      return await db.getAllLearningOperations(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      return await db.getLearningOperationById(input.id);
    }),

  start: protectedProcedure
    .input(
      z.object({
        type: z.enum([
          "prediction_comparison",
          "pattern_detection",
          "correlation_analysis",
          "model_training",
          "insight_generation",
          "adjustment_application",
        ]),
        input: z
          .record(z.string().min(1), z.unknown())
          .refine(data => Object.keys(data).length <= 100, { message: "Maximum 100 input keys allowed" })
          .refine(
            (input) => {
              try {
                JSON.stringify(input);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Input must be valid JSON" }
          )
          .optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const operationId = nanoid();
      const operation = await db.createLearningOperation({
        id: operationId,
        type: input.type,
        status: "pending",
        input: input.input || {},
        triggeredBy: ctx.user?.id,
      });

      // Broadcast new operation
      wsManager.broadcast(WS_CHANNELS.LEARNING_OPERATION_UPDATE, {
        type: "operation_created",
        data: operation,
      });

      // Start actual operation in background via job queue
      try {
        const { addLearningJob } = await import("../jobs/learningQueue");
        await addLearningJob(operationId, input.type, input.input || {});
      } catch (error) {
        console.error("[LearningControl] Failed to queue job:", error);
        // Operation is created but not queued - it will remain pending
      }

      return operation;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        status: z.enum(["pending", "running", "completed", "failed", "cancelled"]).optional(),
        progress: z.number().min(0).max(100).optional(),
        currentStep: z.string().optional(),
        totalSteps: z.number().optional(),
        output: z.record(z.string(), z.unknown()).optional(),
        error: z.string().optional(),
        resultsCount: z.number().optional(),
        insightsGenerated: z.number().optional(),
        adjustmentsProposed: z.number().optional(),
        duration: z.number().optional(),
        completedAt: z.date().optional(),
        startedAt: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...updates } = input;
      
      // Calculate duration if completing
      const updateData: any = { ...updates };
      if (updates.status === "completed" || updates.status === "failed") {
        const operation = await db.getLearningOperationById(id);
        if (operation?.startedAt) {
          const duration = Math.floor(
            (Date.now() - new Date(operation.startedAt).getTime()) / 1000
          );
          updateData.duration = duration;
          updateData.completedAt = new Date();
        }
      }

      // Set startedAt if starting
      if (updates.status === "running" && !updateData.startedAt) {
        updateData.startedAt = new Date();
      }

      const operation = await db.updateLearningOperation(id, updateData);

      if (operation) {
        // Broadcast progress update
        wsManager.broadcast(WS_CHANNELS.LEARNING_OPERATION_PROGRESS, {
          type: "operation_progress",
          data: operation,
        });

        // Broadcast status update using helper
        const { broadcastLearningUpdate } = await import("../_core/websocket");
        broadcastLearningUpdate({
          ...operation,
          status: operation.status || "unknown",
          progress: operation.progress ?? undefined,
          currentStep: operation.currentStep || undefined
        });
      }

      return operation;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      const success = await db.deleteLearningOperation(input.id);

      if (success) {
        wsManager.broadcast(WS_CHANNELS.LEARNING_OPERATION_UPDATE, {
          type: "operation_deleted",
          data: { id: input.id },
        });
      }

      return { success };
    }),

  getLogs: protectedProcedure
    .input(
      z.object({
        operationId: z.string(),
        level: z.enum(["debug", "info", "warning", "error"]).optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await db.getOperationLogs(input.operationId, {
        level: input.level,
        limit: input.limit,
      });
    }),

  active: protectedProcedure.query(async () => {
    return await db.getActiveLearningOperations();
  }),
});

// ==================== Search Operations ====================

const searchRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        type: z.string().optional(), // Will be validated by enum in create/update
        status: z
          .enum(["pending", "running", "completed", "failed", "cancelled"])
          .optional(),
        triggeredBy: z.string().min(1).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      return await db.getAllSearchOperations(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      return await db.getSearchOperationById(input.id);
    }),

  start: protectedProcedure
    .input(
      z.object({
        type: z.enum([
          "keyword_search",
          "event_discovery",
          "news_scraping",
          "sentiment_analysis",
          "entity_extraction",
        ]),
        keywords: z
          .array(z.string().min(1).max(200))
          .min(1, { message: "At least one keyword is required" })
          .max(50, { message: "Maximum 50 keywords allowed" }),
        sources: z
          .array(z.number().positive())
          .min(1, { message: "At least one source is required" })
          .max(20, { message: "Maximum 20 sources allowed" }),
        dateRange: z
          .object({
            from: z.string().datetime(), // ISO 8601 datetime string
            to: z.string().datetime(), // ISO 8601 datetime string
          })
          .optional()
          .refine(
                (data) => {
                  if (!data) {return true;}
                  return new Date(data.from) <= new Date(data.to);
                },
                {
                  message: "Start date must be before or equal to end date",
                }
              )
              .refine(
                (data) => {
                  // Business logic: Date range should not exceed 1 year
                  if (data) {
                    const from = new Date(data.from);
                    const to = new Date(data.to);
                    const oneYearMs = 365 * 24 * 60 * 60 * 1000;
                    return to.getTime() - from.getTime() <= oneYearMs;
                  }
                  return true;
                },
                {
                  message: "Date range cannot exceed 1 year",
                  path: ["dateRange"],
                }
              )
              .refine(
                (data) => {
                  // Business logic: Date range should not be in the future
                  if (data) {
                    const to = new Date(data.to);
                    return to <= new Date();
                  }
                  return true;
                },
                {
                  message: "Date range cannot extend into the future",
                  path: ["dateRange", "to"],
                }
              ),
            })
          )
          .mutation(async ({ input, ctx }) => {
      const operationId = nanoid();
      const operation = await db.createSearchOperation({
        id: operationId,
        type: input.type,
        status: "pending",
        keywords: input.keywords,
        sources: input.sources,
        dateRange: input.dateRange || null,
        totalSources: input.sources.length,
        triggeredBy: ctx.user?.id,
      });

      // Broadcast new operation using helper
      const { broadcastSearchUpdate } = await import("../_core/websocket");
      broadcastSearchUpdate({
        ...operation,
        status: operation.status || "unknown",
        progress: operation.progress ?? undefined,
        currentSource: operation.currentSource || undefined
      });

      // Start actual search in background via job queue
      try {
        const { addSearchJob } = await import("../jobs/searchQueue");
        await addSearchJob(
          operationId,
          input.type,
          input.keywords,
          input.sources,
          input.dateRange
        );
      } catch (error) {
        console.error("[SearchControl] Failed to queue job:", error);
        // Operation is created but not queued - it will remain pending
      }

      return operation;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        status: z.enum(["pending", "running", "completed", "failed", "cancelled"]).optional(),
        progress: z.number().min(0).max(100).optional(),
        currentSource: z.string().optional(),
        sourcesProcessed: z.number().optional(),
        resultsFound: z.number().optional(),
        eventsCreated: z.number().optional(),
        error: z.string().optional(),
        duration: z.number().optional(),
        completedAt: z.date().optional(),
        startedAt: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...updates } = input;
      
      // Calculate duration if completing
      const updateData: any = { ...updates };
      if (updates.status === "completed" || updates.status === "failed") {
        const operation = await db.getSearchOperationById(id);
        if (operation?.startedAt) {
          const duration = Math.floor(
            (Date.now() - new Date(operation.startedAt).getTime()) / 1000
          );
          updateData.duration = duration;
          updateData.completedAt = new Date();
        }
      }

      // Set startedAt if starting
      if (updates.status === "running" && !updateData.startedAt) {
        updateData.startedAt = new Date();
      }

      const operation = await db.updateSearchOperation(id, updateData);

      if (operation) {
        // Broadcast progress update
        wsManager.broadcast(WS_CHANNELS.SEARCH_OPERATION_PROGRESS, {
          type: "operation_progress",
          data: operation,
        });

        // Broadcast status update using helper
        const { broadcastSearchUpdate } = await import("../_core/websocket");
        broadcastSearchUpdate({
          ...operation,
          status: operation.status || "unknown",
          progress: operation.progress ?? undefined,
          currentSource: operation.currentSource || undefined
        });
      }

      return operation;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      const success = await db.deleteSearchOperation(input.id);

      if (success) {
        wsManager.broadcast(WS_CHANNELS.SEARCH_OPERATION_UPDATE, {
          type: "operation_deleted",
          data: { id: input.id },
        });
      }

      return { success };
    }),

  getLogs: protectedProcedure
    .input(
      z.object({
        operationId: z.string(),
        level: z.enum(["debug", "info", "warning", "error"]).optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await db.getOperationLogs(input.operationId, {
        level: input.level,
        limit: input.limit,
      });
    }),

  active: protectedProcedure.query(async () => {
    return await db.getActiveSearchOperations();
  }),
});

// ==================== Operation Logs ====================

const logsRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        operationId: z.string(),
        operationType: z.enum(["learning", "search"]).optional(),
        level: z.enum(["debug", "info", "warning", "error"]).optional(),
        limit: z.number().min(1).max(1000).optional(),
      })
    )
    .query(async ({ input }) => {
      return await db.getOperationLogs(input.operationId, {
        level: input.level,
        limit: input.limit,
      });
    }),

  create: protectedProcedure
    .input(
      z.object({
        operationId: z.string().min(1),
        operationType: z.enum(["learning", "search"]),
        level: z.enum(["debug", "info", "warning", "error"]),
        message: z.string().min(1),
        data: z
          .record(z.string().min(1), z.unknown())
          .refine(data => Object.keys(data).length <= 100, { message: "Maximum 100 data keys allowed" })
          .refine(
            (data) => {
              try {
                JSON.stringify(data);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Data must be valid JSON" }
          )
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const log = await db.createOperationLog({
        operationId: input.operationId,
        operationType: input.operationType,
        level: input.level,
        message: input.message,
        data: input.data || null,
      });

      // Broadcast log via WebSocket
      const { broadcastOperationLog } = await import("../_core/websocket");
      broadcastOperationLog({
        operationId: log.operationId,
        operationType: log.operationType,
        level: log.level,
        message: log.message,
        data: log.data,
      });

      return log;
    }),
});

// ==================== Stats ====================

const statsRouter = router({
  get: protectedProcedure.query(async () => {
    return await db.getLearningControlStats();
  }),
});

// ==================== Main Router ====================

export const learningControlRouter = router({
  keywords: keywordsRouter,
  sources: sourcesRouter,
  learning: learningRouter,
  search: searchRouter,
  logs: logsRouter,
  stats: statsRouter,
});

