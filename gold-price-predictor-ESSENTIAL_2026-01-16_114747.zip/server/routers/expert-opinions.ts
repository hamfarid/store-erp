/**
 * FILE: server/routers/expert-opinions.ts
 * PURPOSE: tRPC router for expert opinions and web scraping
 * OWNER: ML Team
 * RELATED: server/services/web-scraper.ts, server/services/expert-opinion-analyzer.ts
 * LAST-AUDITED: 2025-01-18
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import {
  insertExpertOpinion,
  getExpertOpinions,
  insertSocialSentiment,
  getSentimentTrends,
  insertScrapingJob,
  getScrapingJobs,
} from "../db-compat";
// Correction: db-compat does not have getAggregatedPlatformSentimentHelper.
// The router calls service directly: aggregatePlatformSentiment
import { scrapeUrl } from "../services/web-scraper";
import {
  analyzeOpinion,
  aggregateSentiment,
} from "../services/expert-opinion-analyzer";
import {
  collectSocialSentiment,
  aggregatePlatformSentiment,
} from "../services/social-sentiment";
import { nanoid } from "nanoid";

export const expertOpinionsRouter = router({
  /**
   * Scrape and analyze a URL
   */
  scrapeAndAnalyze: protectedProcedure
    .input(
      z.object({
        url: z.string().url(),
        symbol: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const { url, symbol } = input;

      // Scrape URL
      const scrapingResult = await scrapeUrl(url);

      if (!scrapingResult.success || !scrapingResult.data) {
        throw new Error(scrapingResult.error || "Scraping failed");
      }

      const { content, author, publishedAt } = scrapingResult.data;

      // Analyze opinion
      const analysis = await analyzeOpinion(content, symbol);

      // Save to database
      const opinionId = nanoid();
      await insertExpertOpinion({
        id: opinionId,
        symbol,
        source: new URL(url).hostname,
        sourceUrl: url,
        expertName: author,
        opinionText: content,
        sentiment: analysis.sentiment,
        sentimentScore: analysis.sentimentScore,
        confidence: analysis.confidence,
        targetPrice: analysis.targetPrice,
        timeframe: analysis.timeframe,
        tags: JSON.stringify(analysis.keyPoints),
        scrapedAt: new Date(),
        analyzedAt: new Date(),
      });

      return {
        opinionId,
        analysis,
      };
    }),

  /**
   * Get expert opinions for a symbol
   */
  getOpinions: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        limit: z.number().min(1).max(100).default(20),
        sentiment: z.enum(["bullish", "bearish", "neutral"]).optional(),
      })
    )
    .query(async ({ input }) => {
      const { symbol, limit, sentiment } = input;

      const opinions = await getExpertOpinions({
          symbol,
          sentiment,
          limit
      });

      return opinions;
    }),

  /**
   * Get aggregated sentiment for a symbol
   */
  getAggregatedSentiment: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        days: z.number().min(1).max(90).default(7),
      })
    )
    .query(async ({ input }) => {
      const { symbol, days } = input;

      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);

      const opinions = await getExpertOpinions({
          symbol,
          scrapedAfter: cutoffDate,
          limit: 1000 // High limit to get all relevant for aggregation
      });

      const analyses = opinions.map((op: any) => ({
        sentiment: op.sentiment as "bullish" | "bearish" | "neutral",
        sentimentScore: op.sentimentScore,
        confidence: op.confidence || 0.5,
        targetPrice: op.targetPrice || undefined,
        timeframe: op.timeframe as "short" | "medium" | "long" | undefined,
        keyPoints: [],
        reasoning: "",
      }));

      return aggregateSentiment(analyses);
    }),

  /**
   * Collect social sentiment
   */
  collectSocialSentiment: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        platform: z.enum(["twitter", "reddit", "stocktwits"]),
        timeframe: z.enum(["1h", "24h", "7d", "30d"]).default("24h"),
      })
    )
    .mutation(async ({ input }) => {
      const { symbol, platform, timeframe } = input;

      const sentimentData = await collectSocialSentiment(
        symbol,
        platform,
        timeframe
      );

      // Save to database
      const sentimentId = nanoid();
      await insertSocialSentiment({
        id: sentimentId,
        symbol,
        platform,
        timeframe,
        bullishCount: sentimentData.bullishCount,
        bearishCount: sentimentData.bearishCount,
        neutralCount: sentimentData.neutralCount,
        totalMentions: sentimentData.totalMentions,
        sentimentScore: sentimentData.sentimentScore,
        volumeChange: sentimentData.volumeChange,
        trendingScore: sentimentData.trendingScore,
        topKeywords: JSON.stringify(sentimentData.topKeywords),
        influencerOpinions: JSON.stringify(sentimentData.influencerOpinions),
        collectedAt: new Date(),
      });

      return sentimentData;
    }),

  /**
   * Get aggregated platform sentiment
   */
  getAggregatedPlatformSentiment: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        timeframe: z.enum(["1h", "24h", "7d", "30d"]).default("24h"),
      })
    )
    .query(async ({ input }) => {
      const { symbol, timeframe } = input;
      return await aggregatePlatformSentiment(symbol, timeframe);
    }),

  /**
   * Get sentiment trends
   */
  getSentimentTrends: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        days: z.number().min(1).max(90).default(30),
      })
    )
    .query(async ({ input }) => {
      const { symbol, days } = input;
      return await getSentimentTrends(symbol, days);
    }),

  /**
   * Get scraping jobs
   */
  getScrapingJobs: protectedProcedure
    .input(
      z.object({
        symbol: z.string().optional(),
        status: z
          .enum(["pending", "running", "completed", "failed"])
          .optional(),
        limit: z.number().min(1).max(100).default(20),
      })
    )
    .query(async ({ input }) => {
      const { symbol, status, limit } = input;

      return await getScrapingJobs({
          symbol,
          status,
          limit
      });
    }),

  /**
   * Create scraping job
   */
  createScrapingJob: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        jobType: z.enum(["expert_opinions", "social_sentiment", "news"]),
        sources: z.array(z.string().url()),
      })
    )
    .mutation(async ({ input }) => {
      const { symbol, jobType, sources } = input;

      const jobId = nanoid();
      await insertScrapingJob({
        id: jobId,
        symbol,
        jobType,
        sources: JSON.stringify(sources),
        status: "pending",
        createdAt: new Date(),
      });

      return { jobId };
    }),
});
