// FILE: server/routers/ml.ts | PURPOSE: ML service tRPC router | OWNER: Backend Team | RELATED: server/services/ml-client.ts | LAST-AUDITED: 2025-11-25

import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { mlClient } from "../services/ml-client";

export const mlRouter = router({
  /**
   * Health check for ML service
   */
  health: publicProcedure.query(async () => {
    try {
      const health = await mlClient.healthCheck();
      return {
        available: true,
        ...health,
      };
    } catch (error) {
      return {
        available: false,
        status: "unavailable",
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),

  /**
   * Predict future prices
   */
  predict: publicProcedure
    .input(
      z.object({
        symbol: z.string().min(1, "Symbol is required"),
        days: z.number().min(1).max(90).default(7),
        historicalData: z.array(z.any()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const prediction = await mlClient.predict({
          symbol: input.symbol,
          days: input.days,
          historical_data: input.historicalData,
        });

        return {
          success: true,
          data: prediction,
        };
      } catch (error) {
        console.error("[ML Router] Prediction error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Prediction failed"
        );
      }
    }),

  /**
   * Train a new model (protected - requires authentication)
   */
  train: protectedProcedure
    .input(
      z.object({
        symbol: z.string().min(1, "Symbol is required"),
        dataSource: z.string().default("database"),
        modelType: z
          .enum(["lstm", "prophet", "arima"])
          .default("lstm"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Check if user has permission to train models
        if (ctx.user.role !== "admin") {
          throw new Error("Only admins can train models");
        }

        const result = await mlClient.trainModel({
          symbol: input.symbol,
          data_source: input.dataSource,
          model_type: input.modelType,
        });

        return {
          success: true,
          data: result,
        };
      } catch (error) {
        console.error("[ML Router] Training error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Training failed"
        );
      }
    }),

  /**
   * List available models
   */
  listModels: publicProcedure.query(async () => {
    try {
      const models = await mlClient.listModels();
      return {
        success: true,
        data: models,
      };
    } catch (error) {
      console.error("[ML Router] List models error:", error);
      throw new Error(
        error instanceof Error ? error.message : "Failed to list models"
      );
    }
  }),

  /**
   * Get prediction for specific asset with historical data from database
   */
  predictFromDB: publicProcedure
    .input(
      z.object({
        symbol: z.string().min(1, "Symbol is required"),
        days: z.number().min(1).max(90).default(7),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // TODO: Fetch historical data from PostgreSQL
        // const historicalData = await db.getHistoricalPrices(input.symbol, 60);

        const prediction = await mlClient.predict({
          symbol: input.symbol,
          days: input.days,
          // historical_data: historicalData,
        });

        return {
          success: true,
          data: prediction,
        };
      } catch (error) {
        console.error("[ML Router] Prediction from DB error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Prediction failed"
        );
      }
    }),
});

