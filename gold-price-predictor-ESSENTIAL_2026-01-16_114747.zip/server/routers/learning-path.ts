/**
 * FILE: server/routers/learning-path.ts
 * PURPOSE: tRPC router for learning path optimization
 * OWNER: ML Team
 * RELATED: server/ml/learning-path/
 * LAST-AUDITED: 2025-01-18
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import {
  insertLearningPath,
  getLearningPaths,
  getLearningProgress,
  getPathEvaluations
} from "../db-compat";
import {
  ACOOptimizer,
  type AntSolution,
} from "../ml/learning-path/aco-optimizer";
import {
  RLOptimizer,
  type State,
  type Action,
} from "../ml/learning-path/rl-optimizer";
import {
  evaluatePath,
  validatePathConfig,
  type PathConfig,
} from "../ml/learning-path/path-evaluator";

export const learningPathRouter = router({
  /**
   * Optimize learning path using ACO
   */
  optimizeWithACO: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        modelType: z.enum(["lstm", "gru", "transformer", "ensemble"]),
        availableFeatures: z.array(z.string()),
        hyperparameterRanges: z.record(
          z.string(),
          z.array(z.union([z.number(), z.string()]))
        ),
        numAnts: z.number().optional(),
        numIterations: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const pathId = `path_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // Create ACO optimizer
      const aco = new ACOOptimizer({
        numAnts: input.numAnts || 20,
        numIterations: input.numIterations || 50,
      });

      // Initialize nodes
      aco.initializeNodes(
        input.availableFeatures,
        input.hyperparameterRanges as Record<string, number[]>
      );

      // Evaluation function
      const evaluateFunction = async (
        solution: AntSolution
      ): Promise<number> => {
        const config: PathConfig = {
          symbol: input.symbol,
          modelType: input.modelType,
          features: solution.features,
          hyperparameters: solution.hyperparameters,
        };

        const metrics = await evaluatePath(config);
        return metrics.score;
      };

      // Run optimization
      const result = await aco.optimize(evaluateFunction);

      // Save best path
      await insertLearningPath({
        id: pathId,
        symbol: input.symbol,
        modelType: input.modelType,
        optimizerType: "aco",
        pathConfig: JSON.stringify({
          features: result.bestSolution.features,
          hyperparameters: result.bestSolution.hyperparameters,
        }),
        score: result.bestSolution.score,
        status: "completed",
        completedAt: new Date(),
      });

      return {
        pathId,
        bestSolution: result.bestSolution,
        convergenceHistory: result.convergenceHistory,
        iterations: result.iterations,
      };
    }),

  /**
   * Optimize learning path using RL
   */
  optimizeWithRL: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        modelType: z.enum(["lstm", "gru", "transformer", "ensemble"]),
        initialFeatures: z.array(z.string()),
        initialHyperparameters: z.record(z.string(), z.union([z.number(), z.string()])),
        availableFeatures: z.array(z.string()),
        hyperparameterOptions: z.record(
          z.string(),
          z.array(z.union([z.number(), z.string()]))
        ),
        numEpisodes: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const pathId = `path_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // Create RL optimizer
      const rl = new RLOptimizer({
        numEpisodes: input.numEpisodes || 100,
      });

      // Initial state
      const initialState: State = {
        features: input.initialFeatures,
        hyperparameters: input.initialHyperparameters as Record<string, string | number>,
        performance: 0,
      };

      // Possible actions
      const possibleActions: Action[] = [];

      // Add feature actions
      input.availableFeatures.forEach(feature => {
        possibleActions.push({
          type: "add_feature",
          target: feature,
        });
        possibleActions.push({
          type: "remove_feature",
          target: feature,
        });
      });

      // Hyperparameter adjustment actions
      Object.entries(input.hyperparameterOptions).forEach(([param, values]) => {
        (values as (number | string)[]).forEach(value => {
          possibleActions.push({
            type: "adjust_hyperparameter",
            target: param,
            value,
          });
        });
      });

      // Evaluation function
      const evaluateFunction = async (state: State): Promise<number> => {
        const config: PathConfig = {
          symbol: input.symbol,
          modelType: input.modelType,
          features: state.features,
          hyperparameters: state.hyperparameters,
        };

        const metrics = await evaluatePath(config);
        return metrics.score;
      };

      // Train RL agent
      const result = await rl.train(
        initialState,
        possibleActions,
        evaluateFunction
      );

      // Save best path
      await insertLearningPath({
        id: pathId,
        symbol: input.symbol,
        modelType: input.modelType,
        optimizerType: "rl",
        pathConfig: JSON.stringify({
          features: result.bestState.features,
          hyperparameters: result.bestState.hyperparameters,
        }),
        score: result.bestState.performance,
        status: "completed",
        completedAt: new Date(),
      });

      return {
        pathId,
        bestState: result.bestState,
        convergenceHistory: result.convergenceHistory,
        episodes: result.episodes,
      };
    }),

  /**
   * Get learning paths for a symbol
   */
  getLearningPaths: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        modelType: z
          .enum(["lstm", "gru", "transformer", "ensemble"])
          .optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await getLearningPaths({
          symbol: input.symbol,
          modelType: input.modelType,
          limit: input.limit
      });
    }),

  /**
   * Get learning progress for a path
   */
  getLearningProgress: protectedProcedure
    .input(z.object({ pathId: z.string() }))
    .query(async ({ input }) => {
      return await getLearningProgress(input.pathId);
    }),

  /**
   * Get path evaluations
   */
  getPathEvaluations: protectedProcedure
    .input(z.object({ pathId: z.string() }))
    .query(async ({ input }) => {
      return await getPathEvaluations(input.pathId);
    }),

  /**
   * Validate path configuration
   */
  validatePath: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        modelType: z.enum(["lstm", "gru", "transformer", "ensemble"]),
        features: z.array(z.string()),
        hyperparameters: z.record(z.string(), z.union([z.number(), z.string()])),
      })
    )
    .query(({ input }) => {
      return validatePathConfig(input);
    }),
});
