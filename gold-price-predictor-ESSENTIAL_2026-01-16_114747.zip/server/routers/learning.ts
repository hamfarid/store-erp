/**
 * FILE: server/routers/learning.ts
 * PURPOSE: tRPC router for Learning subsystem (predictions, comparisons, insights, adjustments)
 * OWNER: Backend Team
 * RELATED: server/services/learning/predictionsDb.ts, drizzle/schema-events.ts
 * LAST-AUDITED: 2025-12-31
 */

import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import * as predictionsDb from "../services/learning/predictionsDb";
import * as db from "../db-compat";
import { logError } from "../logger";

// ==================== Predictions ====================

const predictionsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        assetId: z.number().positive(),
        predictionDate: z.string().datetime(), // ISO 8601 datetime string
        targetDate: z.string().datetime(), // ISO 8601 datetime string
        daysAhead: z.number().int().positive(),
        currentPrice: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) > 0, {
            message: "Price must be greater than 0",
          }),
        predictedPrice: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) > 0, {
            message: "Price must be greater than 0",
          }),
        confidenceLower: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) >= 0, {
            message: "Confidence lower must be >= 0",
          })
          .optional(),
        confidenceUpper: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) >= 0, {
            message: "Confidence upper must be >= 0",
          })
          .optional(),
        modelType: z.string().min(1).max(50),
      })
        .refine(
          (data) => {
            // Cross-field validation: confidenceLower < confidenceUpper
            if (data.confidenceLower && data.confidenceUpper) {
              return parseFloat(data.confidenceLower) < parseFloat(data.confidenceUpper);
            }
            return true;
          },
          {
            message: "Confidence lower bound must be less than upper bound",
            path: ["confidenceLower"],
          }
        )
        .refine(
          (data) => {
            // Business logic: predictedPrice should be within confidence interval if provided
            if (data.confidenceLower && data.confidenceUpper && data.predictedPrice) {
              const predicted = parseFloat(data.predictedPrice);
              const lower = parseFloat(data.confidenceLower);
              const upper = parseFloat(data.confidenceUpper);
              return predicted >= lower && predicted <= upper;
            }
            return true;
          },
          {
            message: "Predicted price must be within confidence interval",
            path: ["predictedPrice"],
          }
        )
        .refine(
          (data) => {
            // Business logic: targetDate must be after predictionDate
            if (data.predictionDate && data.targetDate) {
              return new Date(data.targetDate) > new Date(data.predictionDate);
            }
            return true;
          },
          {
            message: "Target date must be after prediction date",
            path: ["targetDate"],
          }
        )
    )
    .mutation(async ({ input }) => {
      try {
        const prediction = await db.insertPrediction({
          assetId: input.assetId,
          predictionDate: new Date(input.predictionDate),
          targetDate: new Date(input.targetDate),
          daysAhead: input.daysAhead,
          currentPrice: input.currentPrice,
          predictedPrice: input.predictedPrice,
          confidenceLower: input.confidenceLower || null,
          confidenceUpper: input.confidenceUpper || null,
          modelType: input.modelType,
        });

        if (!prediction) {
          throw new Error("Failed to create prediction");
        }

        return prediction;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "learning-router",
          component: "predictions.create",
          message: `Failed to create prediction: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { assetId: input.assetId, modelType: input.modelType },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create prediction",
        });
      }
    }),

  list: protectedProcedure
    .input(
      z
        .object({
          assetId: z.number().optional(),
          limit: z.number().min(1).max(1000).optional(),
          offset: z.number().min(0).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      try {
        return await db.getPredictions({
          assetId: input?.assetId,
          limit: input?.limit,
          offset: input?.offset
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "learning-router",
          component: "predictions.list",
          message: `Failed to list predictions: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { filters: input },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list predictions",
        });
      }
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const prediction = await db.getPredictionById(input.id);
        
        if (!prediction) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Prediction not found",
          });
        }

        return prediction;
      } catch (error) {
        if (error instanceof TRPCError) {
          throw error;
        }
        console.error("[Learning Router] Error getting prediction:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to get prediction",
        });
      }
    }),

  updateActual: protectedProcedure
    .input(
      z.object({
        predictionId: z.number(),
        actualPrice: z.string().regex(/^\d+(\.\d+)?$/, "Invalid price format"),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const success = await predictionsDb.updatePredictionActual(
          input.predictionId,
          input.actualPrice
        );
        if (!success) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Prediction not found",
          });
        }
        
        // Get the created/updated comparison
        const comparisons = await predictionsDb.getAllComparisons({
          predictionId: input.predictionId,
          limit: 1,
        });
        
        return { 
          success: true,
          comparison: comparisons[0] || null,
        };
      } catch (error) {
        if (error instanceof TRPCError) {
          throw error;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await logError({
          level: "error",
          source: "learning-router",
          component: "predictions.updateActual",
          message: `Failed to update prediction actual: ${errorMessage}`,
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { predictionId: input.predictionId },
        });
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update prediction actual price",
        });
      }
    }),
});

// ==================== Comparisons ====================

const comparisonsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        predictionId: z.number().positive(),
        actualPrice: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) > 0, {
            message: "Price must be greater than 0",
          }),
        predictedPrice: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid price format")
          .refine((val) => parseFloat(val) > 0, {
            message: "Price must be greater than 0",
          }),
        error: z.string().regex(/^-?\d+(\.\d+)?$/, "Invalid error format").optional(),
        errorPercent: z
          .string()
          .regex(/^-?\d+(\.\d+)?$/, "Invalid error percent format")
          .optional(),
        accuracy: z
          .string()
          .regex(/^\d+(\.\d+)?$/, "Invalid accuracy format")
          .refine((val) => {
            const num = parseFloat(val);
            return num >= 0 && num <= 1;
          }, {
            message: "Accuracy must be between 0 and 1",
          })
          .optional(),
        withinConfidence: z.boolean().optional(),
        modelVersion: z.string().max(50).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const comparison = await predictionsDb.createComparison({
          predictionId: input.predictionId,
          actualPrice: input.actualPrice,
          predictedPrice: input.predictedPrice,
          error: input.error || null,
          errorPercent: input.errorPercent || null,
          accuracy: input.accuracy || null,
          withinConfidence: input.withinConfidence || false,
          modelVersion: input.modelVersion || null,
        });

        return comparison;
      } catch (error) {
        console.error("[Learning Router] Error creating comparison:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create comparison",
        });
      }
    }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const comparison = await predictionsDb.getComparisonById(input.id);
      if (!comparison) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Comparison not found",
        });
      }
      return comparison;
    }),

  list: protectedProcedure
    .input(
      z
        .object({
          predictionId: z.number().optional(),
          minAccuracy: z.number().optional(),
          maxAccuracy: z.number().optional(),
          withinConfidence: z.boolean().optional(),
          limit: z.number().min(1).max(1000).optional(),
          offset: z.number().min(0).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      return await predictionsDb.getAllComparisons(input);
    }),

  listByAccuracy: protectedProcedure
    .input(
      z.object({
        minAccuracy: z.number().min(0).max(1).default(0.8),
        limit: z.number().min(1).max(1000).default(100),
      })
    )
    .query(async ({ input }) => {
      return await predictionsDb.getComparisonsByAccuracy(
        input.minAccuracy,
        input.limit
      );
    }),
});

// ==================== Insights ====================

const insightsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        type: z.enum([
          "pattern",
          "correlation",
          "anomaly",
          "trend",
          "prediction_accuracy",
          "model_performance",
        ]),
        title: z.string().min(1).max(255),
        description: z.string().optional(),
        confidence: z.string().optional(),
        impact: z.enum(["low", "medium", "high", "critical"]).optional(),
        data: z
          .record(z.string().min(1), z.unknown())
          .refine(data => Object.keys(data).length <= 100, { message: "Maximum 100 data keys allowed" })
          .refine(
            (data) => {
              // Validate JSON structure (ensure it's serializable)
              try {
                JSON.stringify(data);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Data must be valid JSON" }
          )
          .optional(),
        relatedPredictions: z
          .array(z.number().positive())
          .max(100, { message: "Maximum 100 related predictions allowed" })
          .optional(),
        relatedEvents: z
          .array(z.string().min(1))
          .max(100, { message: "Maximum 100 related events allowed" })
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const insight = await predictionsDb.createInsight({
          type: input.type,
          title: input.title,
          description: input.description || null,
          confidence: input.confidence || null,
          impact: input.impact || "medium",
          data: input.data || null,
          relatedPredictions: input.relatedPredictions || null,
          relatedEvents: input.relatedEvents || null,
          status: "pending",
        });

        return insight;
      } catch (error) {
        console.error("[Learning Router] Error creating insight:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create insight",
        });
      }
    }),

  list: protectedProcedure
    .input(
      z
        .object({
          type: z
            .enum([
              "pattern",
              "correlation",
              "anomaly",
              "trend",
              "prediction_accuracy",
              "model_performance",
            ])
            .optional(),
          status: z.enum(["pending", "reviewed", "applied", "rejected"]).optional(),
          impact: z.enum(["low", "medium", "high", "critical"]).optional(),
          limit: z.number().min(1).max(1000).optional(),
          offset: z.number().min(0).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      return await predictionsDb.getAllInsights(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const insight = await predictionsDb.getInsightById(input.id);
      if (!insight) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Insight not found",
        });
      }
      return insight;
    }),

  updateStatus: adminProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "reviewed", "applied", "rejected"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const insight = await predictionsDb.updateInsightStatus(
        input.id,
        input.status,
        ctx.user?.id
      );
      if (!insight) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Insight not found",
        });
      }
      return insight;
    }),
});

// ==================== Adjustments ====================

const adjustmentsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        insightId: z.number(),
        adjustmentType: z.enum([
          "parameter_tuning",
          "feature_addition",
          "feature_removal",
          "weight_adjustment",
          "threshold_change",
          "algorithm_change",
        ]),
        description: z.string().optional(),
        parameters: z
          .record(z.string().min(1), z.unknown())
          .refine(params => Object.keys(params).length <= 50, { message: "Maximum 50 parameters allowed" })
          .refine(
            (params) => {
              try {
                JSON.stringify(params);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Parameters must be valid JSON" }
          )
          .optional(),
        modelVersion: z.string().min(1).max(50).optional(),
        previousVersion: z.string().min(1).max(50).optional(),
        performanceBefore: z
          .record(z.string().min(1), z.unknown())
          .refine(perf => Object.keys(perf).length <= 50, { message: "Maximum 50 performance metrics allowed" })
          .refine(
            (perf) => {
              try {
                JSON.stringify(perf);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Performance data must be valid JSON" }
          )
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const adjustment = await predictionsDb.createAdjustment({
          insightId: input.insightId,
          adjustmentType: input.adjustmentType,
          description: input.description || null,
          parameters: input.parameters || null,
          modelVersion: input.modelVersion || null,
          previousVersion: input.previousVersion || null,
          status: "proposed",
          performanceBefore: input.performanceBefore || null,
        });

        return adjustment;
      } catch (error) {
        console.error("[Learning Router] Error creating adjustment:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create adjustment",
        });
      }
    }),

  list: protectedProcedure
    .input(
      z
        .object({
          insightId: z.number().optional(),
          status: z
            .enum(["proposed", "approved", "applied", "reverted", "rejected"])
            .optional(),
          adjustmentType: z
            .enum([
              "parameter_tuning",
              "feature_addition",
              "feature_removal",
              "weight_adjustment",
              "threshold_change",
              "algorithm_change",
            ])
            .optional(),
          limit: z.number().min(1).max(1000).optional(),
          offset: z.number().min(0).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      return await predictionsDb.getAllAdjustments(input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const adjustment = await predictionsDb.getAdjustmentById(input.id);
      if (!adjustment) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Adjustment not found",
        });
      }
      return adjustment;
    }),

  applyAdjustment: adminProcedure
    .input(
      z.object({
        id: z.number(),
        performanceAfter: z
          .record(z.string().min(1), z.unknown())
          .refine(perf => Object.keys(perf).length <= 50, { message: "Maximum 50 performance metrics allowed" })
          .refine(
            (perf) => {
              try {
                JSON.stringify(perf);
                return true;
              } catch {
                return false;
              }
            },
            { message: "Performance data must be valid JSON" }
          )
          .optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const adjustment = await predictionsDb.applyAdjustment(
        input.id,
        ctx.user?.id || "system",
        input.performanceAfter
      );
      if (!adjustment) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Adjustment not found",
        });
      }
      return adjustment;
    }),

  revert: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const adjustment = await predictionsDb.revertAdjustment(
        input.id,
        ctx.user?.id || "system"
      );
      if (!adjustment) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Adjustment not found",
        });
      }
      return adjustment;
    }),
});

// ==================== Main Learning Router ====================

export const learningRouter = router({
  predictions: predictionsRouter,
  comparisons: comparisonsRouter,
  insights: insightsRouter,
  adjustments: adjustmentsRouter,
});
