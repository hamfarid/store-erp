/**
 * Comprehensive System Router
 * All-in-one router for: Notifications, Reports, KPIs, Activity, AI, Risk Management
 */

import { z } from "zod";
import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import * as ComprehensiveSystem from "../comprehensive-system";
// import { getDb } from "../db-compat"; // Removed unused import

export const comprehensiveRouter = router({
  // ==================== NOTIFICATIONS ====================
  notifications: router({
    send: protectedProcedure
      .input(
        z.object({
          type: z.enum(["push", "email", "telegram", "in_app"]),
          channel: z.string().optional(),
          title: z.string(),
          message: z.string(),
          data: z.any().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.sendNotification({
          userId: ctx.user.id,
          ...input,
        });
      }),

    getAll: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return await ComprehensiveSystem.getUserNotifications(
          ctx.user.id,
          input.limit
        );
      }),

    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.markNotificationAsRead(
          input.notificationId,
          ctx.user.id
        );
      }),
  }),

  // ==================== REPORTS ====================
  reports: router({
    generate: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          type: z.enum([
            "portfolio",
            "price_analysis",
            "predictions",
            "alerts",
            "custom",
          ]),
          format: z.enum(["pdf", "excel", "csv"]),
          parameters: z.any().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.generateReport({
          userId: ctx.user.id,
          ...input,
        });
      }),

    schedule: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          type: z.enum([
            "portfolio",
            "price_analysis",
            "predictions",
            "alerts",
            "custom",
          ]),
          format: z.enum(["pdf", "excel", "csv"]),
          frequency: z.enum(["daily", "weekly", "monthly", "custom"]),
          schedule: z.string().optional(),
          recipients: z.array(z.string()).optional(),
          parameters: z.any().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // TODO: Implement report scheduling
        return { success: true, message: "Report scheduled successfully" };
      }),
  }),

  // ==================== EXECUTIVE DASHBOARD (KPIs) ====================
  kpis: router({
    calculate: protectedProcedure
      .input(z.object({ period: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.calculateKPIs(
          ctx.user.id,
          input.period
        );
      }),

    getHistory: protectedProcedure
      .input(z.object({ periods: z.array(z.string()) }))
      .query(async ({ ctx, input }) => {
        return await ComprehensiveSystem.getKPIHistory(
          ctx.user.id,
          input.periods
        );
      }),

    getCurrent: protectedProcedure.query(async ({ ctx }) => {
      const currentPeriod = new Date().toISOString().slice(0, 7); // YYYY-MM
      return await ComprehensiveSystem.calculateKPIs(
        ctx.user.id,
        currentPeriod
      );
    }),
  }),

  // ==================== ACTIVITY TRACKING ====================
  activity: router({
    log: protectedProcedure
      .input(
        z.object({
          action: z.string(),
          entityType: z.string(),
          entityId: z.string().optional(),
          description: z.string().optional(),
          metadata: z.any().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.logActivity({
          userId: ctx.user.id,
          ...input,
        });
      }),

    trackChange: protectedProcedure
      .input(
        z.object({
          entityType: z.string(),
          entityId: z.string(),
          field: z.string(),
          oldValue: z.any(),
          newValue: z.any(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.trackChange({
          userId: ctx.user.id,
          ...input,
        });
      }),

    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(100) }))
      .query(async ({ ctx, input }) => {
        return await ComprehensiveSystem.getUserActivity(
          ctx.user.id,
          input.limit
        );
      }),
  }),

  // ==================== AI RECOMMENDATIONS ====================
  ai: router({
    generateRecommendation: protectedProcedure
      .input(z.object({ assetId: z.number().optional() }))
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.generateAIRecommendation(
          ctx.user.id,
          input.assetId
        );
      }),

    analyzeSentiment: protectedProcedure
      .input(
        z.object({
          text: z.string(),
          assetId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.analyzeSentiment(
          input.text,
          input.assetId
        );
      }),
  }),

  // ==================== RISK MANAGEMENT ====================
  risk: router({
    calculateProfile: protectedProcedure
      .input(z.object({ assetId: z.number().optional() }))
      .mutation(async ({ ctx, input }) => {
        return await ComprehensiveSystem.calculateRiskProfile(
          ctx.user.id,
          input.assetId
        );
      }),

    createStopLoss: protectedProcedure
      .input(
        z.object({
          assetId: z.number(),
          triggerPrice: z.string(), // decimal as string for precision
          quantity: z.string(), // decimal as string for precision
          type: z.enum(["fixed", "trailing", "percentage"]),
          trailingAmount: z.string().optional(),
          expiresAt: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // TODO: Implement stop-loss creation
        return { success: true, message: "Stop-loss order created" };
      }),
  }),

  // ==================== ADMIN FUNCTIONS ====================
  admin: router({
    getAllActivity: adminProcedure
      .input(
        z.object({
          limit: z.number().default(100),
          userId: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const { getSecurityEvents } = await import("../db-compat");
        // getSecurityEvents signature: (limit, offset, filters)
        // We map input to filters
        const filters: any = {};
        if (input.userId) {
            filters.userId = input.userId;
        }
        const result = await getSecurityEvents(input.limit, 0, filters);
        return result.events;
      }),

    getSystemStats: adminProcedure.query(async () => {
      const { getSystemStats } = await import("../db-compat");
      return await getSystemStats();
    }),
  }),
});

