/**
 * AI Scheduled Tasks tRPC Router
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import * as dbAITasks from "../db-ai-tasks";
import { aiScheduler } from "../ai-scheduler";

export const aiTasksRouter = router({
  // Create new scheduled task
  create: protectedProcedure
    .input(
      z.object({
        taskName: z.string().min(1).max(255),
        description: z.string().optional(),
        taskType: z.enum(["price_analysis", "portfolio_report", "news_summary", "prediction_update", "alert_check", "custom_query"]),
        scheduleType: z.enum(["daily", "weekly", "monthly", "custom"]),
        cronExpression: z.string(),
        assistantId: z.number().default(1), // 1 = free, 2 = paid (default: free)
        parameters: z.string().optional(), // JSON string
        isActive: z.boolean().default(true),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await dbAITasks.createScheduledTask({
        userId: ctx.user.id,
        assistantId: input.assistantId,
        taskName: input.taskName,
        description: input.description,
        taskType: input.taskType,
        scheduleType: input.scheduleType,
        cronExpression: input.cronExpression,
        taskConfig: input.parameters,
        isActive: input.isActive,
      });

      // Reload scheduler to pick up new task
      await aiScheduler.initialize();

      return { success: true };
    }),

  // List user's scheduled tasks
  list: protectedProcedure.query(async ({ ctx }) => {
    return await dbAITasks.getUserScheduledTasks(ctx.user.id);
  }),

  // Get single scheduled task
  get: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .query(async ({ ctx, input }) => {
      return await dbAITasks.getScheduledTask(input.taskId, ctx.user.id);
    }),

  // Update scheduled task
  update: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        taskName: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        taskType: z.enum(["price_analysis", "portfolio_report", "news_summary", "prediction_update", "alert_check", "custom_query"]).optional(),
        scheduleType: z.enum(["daily", "weekly", "monthly", "custom"]).optional(),
        cronExpression: z.string().optional(),
        assistantId: z.number().optional(),
        parameters: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { taskId, ...data } = input;
      await dbAITasks.updateScheduledTask(taskId, ctx.user.id, data);

      // Reload scheduler to pick up changes
      await aiScheduler.initialize();

      return { success: true };
    }),

  // Delete scheduled task
  delete: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Unschedule first
      await aiScheduler.unscheduleTask(input.taskId);

      // Then delete from database
      await dbAITasks.deleteScheduledTask(input.taskId, ctx.user.id);

      return { success: true };
    }),

  // Get task results (execution history)
  getResults: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ ctx, input }) => {
      // Verify ownership
      const task = await dbAITasks.getScheduledTask(input.taskId, ctx.user.id);
      if (!task) {
        throw new Error("Task not found");
      }

      return await dbAITasks.getTaskResults(input.taskId, input.limit);
    }),

  // Get scheduler status
  getSchedulerStatus: protectedProcedure.query(async () => {
    return aiScheduler.getStatus();
  }),

  // Manually trigger a task (run now)
  triggerNow: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const task = await dbAITasks.getScheduledTask(input.taskId, ctx.user.id);
      if (!task) {
        throw new Error("Task not found");
      }

      // Execute task immediately (in background)
      // Note: This is a simplified version - in production, use a job queue
      setTimeout(async () => {
        try {
          await (aiScheduler as any).executeTask(task);
        } catch (error) {
          console.error("Failed to execute task:", error);
        }
      }, 0);

      return { success: true, message: "Task execution started" };
    }),
});

