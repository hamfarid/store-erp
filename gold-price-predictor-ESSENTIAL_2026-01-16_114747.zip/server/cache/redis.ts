/**
 * FILE: server/cache/redis.ts
 * PURPOSE: Redis client configuration
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import Redis from 'ioredis';

// Redis connection configuration
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6372'), // Updated to match docker-compose.yml port mapping
  password: process.env.REDIS_PASSWORD,
  db: parseInt(process.env.REDIS_DB || '0'),
  retryStrategy: (times: number) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: null, // Required by BullMQ for blocking operations
  enableReadyCheck: true,
  enableOfflineQueue: true,
};

// Create Redis client
export const redis = new Redis(redisConfig);

// Connection event handlers
redis.on('connect', () => {
  console.log('[Redis] Connected successfully');
});

redis.on('ready', () => {
  console.log('[Redis] Ready to accept commands');
});

redis.on('error', (err) => {
  console.error('[Redis] Connection error:', err);
});

redis.on('close', () => {
  console.warn('[Redis] Connection closed');
});

redis.on('reconnecting', () => {
  console.log('[Redis] Reconnecting...');
});

// Health check
export async function checkRedisHealth(): Promise<boolean> {
  try {
    const result = await redis.ping();
    return result === 'PONG';
  } catch (error) {
    console.error('[Redis] Health check failed:', error);
    return false;
  }
}

// Graceful shutdown
export async function closeRedis(): Promise<void> {
  await redis.quit();
  console.log('[Redis] Connection closed gracefully');
}

// Export for cleanup
process.on('SIGTERM', closeRedis);
process.on('SIGINT', closeRedis);
