/**
 * FILE: server/cache/cacheService.ts
 * PURPOSE: Redis caching service with TTL and invalidation strategies
 * OWNER: Backend Team
 * CREATED: 2026-01-15
 */

import { redis } from './redis';

// ==================== Cache Configuration ====================

export const CACHE_TTL = {
  SHORT: 60,          // 1 minute
  MEDIUM: 300,        // 5 minutes
  LONG: 1800,         // 30 minutes
  HOUR: 3600,         // 1 hour
  DAY: 86400,         // 24 hours
  WEEK: 604800,       // 7 days
} as const;

export const CACHE_KEYS = {
  // User data
  USER: (id: string) => `user:${id}`,
  USER_PERMISSIONS: (id: string) => `user:${id}:permissions`,
  USER_SETTINGS: (id: string) => `user:${id}:settings`,
  
  // Assets
  ASSETS: 'assets:all',
  ASSET: (id: number) => `asset:${id}`,
  ASSET_PRICES: (id: number) => `asset:${id}:prices`,
  
  // Predictions
  PREDICTIONS: (assetId: number) => `predictions:asset:${assetId}`,
  PREDICTION: (id: number) => `prediction:${id}`,
  LATEST_PREDICTION: (assetId: number) => `prediction:latest:${assetId}`,
  
  // Alerts
  USER_ALERTS: (userId: string) => `alerts:user:${userId}`,
  ALERT: (id: number) => `alert:${id}`,
  
  // Notifications
  USER_NOTIFICATIONS: (userId: string) => `notifications:user:${userId}`,
  UNREAD_COUNT: (userId: string) => `notifications:unread:${userId}`,
  
  // Statistics
  STATS: (type: string) => `stats:${type}`,
  DASHBOARD_STATS: 'stats:dashboard',
  
  // API Responses
  API_RESPONSE: (endpoint: string, params?: string) => 
    params ? `api:${endpoint}:${params}` : `api:${endpoint}`,
} as const;

// ==================== Cache Service ====================

export class CacheService {
  /**
   * Get a value from cache
   */
  async get<T = any>(key: string): Promise<T | null> {
    try {
      const value = await redis.get(key);
      if (!value) return null;
      
      return JSON.parse(value) as T;
    } catch (error) {
      console.error('[Cache] Get error:', error);
      return null;
    }
  }

  /**
   * Set a value in cache with TTL
   */
  async set(key: string, value: any, ttl: number = CACHE_TTL.MEDIUM): Promise<boolean> {
    try {
      const serialized = JSON.stringify(value);
      await redis.setex(key, ttl, serialized);
      return true;
    } catch (error) {
      console.error('[Cache] Set error:', error);
      return false;
    }
  }

  /**
   * Delete a specific key
   */
  async delete(key: string): Promise<boolean> {
    try {
      await redis.del(key);
      return true;
    } catch (error) {
      console.error('[Cache] Delete error:', error);
      return false;
    }
  }

  /**
   * Delete multiple keys matching a pattern
   */
  async deletePattern(pattern: string): Promise<number> {
    try {
      const keys = await redis.keys(pattern);
      if (keys.length === 0) return 0;
      
      await redis.del(...keys);
      return keys.length;
    } catch (error) {
      console.error('[Cache] Delete pattern error:', error);
      return 0;
    }
  }

  /**
   * Check if a key exists
   */
  async exists(key: string): Promise<boolean> {
    try {
      const result = await redis.exists(key);
      return result === 1;
    } catch (error) {
      console.error('[Cache] Exists error:', error);
      return false;
    }
  }

  /**
   * Get TTL (time to live) for a key
   */
  async getTTL(key: string): Promise<number> {
    try {
      return await redis.ttl(key);
    } catch (error) {
      console.error('[Cache] Get TTL error:', error);
      return -1;
    }
  }

  /**
   * Extend TTL for an existing key
   */
  async extend(key: string, additionalTTL: number): Promise<boolean> {
    try {
      const currentTTL = await this.getTTL(key);
      if (currentTTL <= 0) return false;
      
      await redis.expire(key, currentTTL + additionalTTL);
      return true;
    } catch (error) {
      console.error('[Cache] Extend error:', error);
      return false;
    }
  }

  /**
   * Get or set pattern (cache-aside strategy)
   */
  async getOrSet<T = any>(
    key: string,
    fetcher: () => Promise<T>,
    ttl: number = CACHE_TTL.MEDIUM
  ): Promise<T> {
    // Try to get from cache first
    const cached = await this.get<T>(key);
    if (cached !== null) {
      return cached;
    }

    // Fetch fresh data
    const fresh = await fetcher();
    
    // Store in cache
    await this.set(key, fresh, ttl);
    
    return fresh;
  }

  /**
   * Invalidate user-related caches
   */
  async invalidateUser(userId: string): Promise<void> {
    await Promise.all([
      this.delete(CACHE_KEYS.USER(userId)),
      this.delete(CACHE_KEYS.USER_PERMISSIONS(userId)),
      this.delete(CACHE_KEYS.USER_SETTINGS(userId)),
      this.delete(CACHE_KEYS.USER_ALERTS(userId)),
      this.delete(CACHE_KEYS.USER_NOTIFICATIONS(userId)),
      this.delete(CACHE_KEYS.UNREAD_COUNT(userId)),
    ]);
  }

  /**
   * Invalidate asset-related caches
   */
  async invalidateAsset(assetId: number): Promise<void> {
    await Promise.all([
      this.delete(CACHE_KEYS.ASSET(assetId)),
      this.delete(CACHE_KEYS.ASSET_PRICES(assetId)),
      this.delete(CACHE_KEYS.PREDICTIONS(assetId)),
      this.delete(CACHE_KEYS.LATEST_PREDICTION(assetId)),
      this.delete(CACHE_KEYS.ASSETS),
    ]);
  }

  /**
   * Invalidate all caches (use sparingly)
   */
  async invalidateAll(): Promise<void> {
    try {
      await redis.flushdb();
      console.log('[Cache] All caches invalidated');
    } catch (error) {
      console.error('[Cache] Invalidate all error:', error);
    }
  }

  /**
   * Get cache statistics
   */
  async getStats(): Promise<{
    keys: number;
    memory: string;
    hits: number;
    misses: number;
    hitRate: string;
  }> {
    try {
      const info = await redis.info('stats');
      const keys = await redis.dbsize();
      
      // Parse info string
      const lines = info.split('\r\n');
      const stats: any = {};
      lines.forEach(line => {
        const [key, value] = line.split(':');
        if (key && value) {
          stats[key] = value;
        }
      });

      const hits = parseInt(stats.keyspace_hits || '0');
      const misses = parseInt(stats.keyspace_misses || '0');
      const total = hits + misses;
      const hitRate = total > 0 ? ((hits / total) * 100).toFixed(2) : '0.00';

      return {
        keys,
        memory: stats.used_memory_human || 'N/A',
        hits,
        misses,
        hitRate: `${hitRate}%`,
      };
    } catch (error) {
      console.error('[Cache] Get stats error:', error);
      return {
        keys: 0,
        memory: 'N/A',
        hits: 0,
        misses: 0,
        hitRate: '0.00%',
      };
    }
  }

  /**
   * Warm up cache with frequently accessed data
   */
  async warmUp(data: { key: string; value: any; ttl?: number }[]): Promise<void> {
    try {
      await Promise.all(
        data.map(({ key, value, ttl }) => this.set(key, value, ttl || CACHE_TTL.LONG))
      );
      console.log(`[Cache] Warmed up ${data.length} keys`);
    } catch (error) {
      console.error('[Cache] Warm up error:', error);
    }
  }

  /**
   * Get all keys matching a pattern
   */
  async getKeys(pattern: string = '*'): Promise<string[]> {
    try {
      return await redis.keys(pattern);
    } catch (error) {
      console.error('[Cache] Get keys error:', error);
      return [];
    }
  }

  /**
   * Increment a counter
   */
  async increment(key: string, by: number = 1): Promise<number> {
    try {
      return await redis.incrby(key, by);
    } catch (error) {
      console.error('[Cache] Increment error:', error);
      return 0;
    }
  }

  /**
   * Decrement a counter
   */
  async decrement(key: string, by: number = 1): Promise<number> {
    try {
      return await redis.decrby(key, by);
    } catch (error) {
      console.error('[Cache] Decrement error:', error);
      return 0;
    }
  }

  /**
   * Set multiple values at once (pipeline)
   */
  async setMany(entries: { key: string; value: any; ttl?: number }[]): Promise<boolean> {
    try {
      const pipeline = redis.pipeline();
      
      entries.forEach(({ key, value, ttl }) => {
        const serialized = JSON.stringify(value);
        if (ttl) {
          pipeline.setex(key, ttl, serialized);
        } else {
          pipeline.set(key, serialized);
        }
      });
      
      await pipeline.exec();
      return true;
    } catch (error) {
      console.error('[Cache] Set many error:', error);
      return false;
    }
  }

  /**
   * Get multiple values at once (pipeline)
   */
  async getMany<T = any>(keys: string[]): Promise<Map<string, T | null>> {
    try {
      const pipeline = redis.pipeline();
      keys.forEach(key => pipeline.get(key));
      
      const results = await pipeline.exec();
      const map = new Map<string, T | null>();
      
      results?.forEach((result, index) => {
        const [error, value] = result;
        if (!error && value) {
          try {
            map.set(keys[index], JSON.parse(value as string) as T);
          } catch {
            map.set(keys[index], null);
          }
        } else {
          map.set(keys[index], null);
        }
      });
      
      return map;
    } catch (error) {
      console.error('[Cache] Get many error:', error);
      return new Map();
    }
  }
}

// Export singleton instance
export const cacheService = new CacheService();
