/**
 * FILE: server/config/vault.ts
 * PURPOSE: Vault configuration for secure secrets management
 * OWNER: Backend Team
 * RELATED: .env, .env.vault, server/_core/env.ts
 * LAST-AUDITED: 2025-01-18
 */

import dotenv from "dotenv";
import { config as dotenvVaultConfig } from "dotenv-vault-core";

/**
 * Load secrets from dotenv-vault in production, .env in development
 */
export function loadSecrets() {
  const isProduction = process.env.NODE_ENV === "production";

  if (isProduction) {
    // Load from encrypted vault in production
    try {
      dotenvVaultConfig();
      console.log("✅ [Vault] Loaded secrets from encrypted vault");
    } catch (error) {
      console.error("❌ [Vault] Failed to load vault:", error);
      throw new Error(
        "Vault configuration failed. Make sure DOTENV_KEY is set."
      );
    }
  } else {
    // Load from .env in development
    dotenv.config();
    console.log("✅ [Vault] Loaded secrets from .env (development mode)");
  }

  // Validate required secrets
  validateSecrets();
}

/**
 * Validate that all required secrets are present
 */
function validateSecrets() {
  const isProduction = process.env.NODE_ENV === "production";

  // In production, require all secrets
  // In development, provide sensible defaults
  if (isProduction) {
    const required = ["DATABASE_URL", "JWT_SECRET"];

    const missing = required.filter(key => !process.env[key]);

    if (missing.length > 0) {
      throw new Error(`❌ Missing required secrets: ${missing.join(", ")}`);
    }

    // Validate JWT_SECRET length
    if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) {
      throw new Error("❌ JWT_SECRET must be at least 32 characters");
    }
  } else {
    // Development mode - provide defaults if not set
    if (!process.env.JWT_SECRET) {
      process.env.JWT_SECRET =
        "development-secret-key-do-not-use-in-production-32chars";
      console.log("⚠️  [Vault] Using default JWT_SECRET for development");
    }

    if (!process.env.DATABASE_URL) {
      // Use SQLite for local development by default
      process.env.DATABASE_URL = "file:./data/asset_predictor.db";
      console.log("⚠️  [Vault] Using SQLite database for development");
    }
  }

  console.log("✅ [Vault] All required secrets validated");
}

/**
 * Export typed environment variables
 */
export const ENV = {
  // Application
  app: {
    nodeEnv: process.env.NODE_ENV || "development",
    port: parseInt(process.env.PORT || "3000"),
    debug: process.env.DEBUG === "true",
  },

  // Database
  database: {
    url: process.env.DATABASE_URL!,
  },

  // Authentication
  auth: {
    jwtSecret: process.env.JWT_SECRET!,
    sessionMaxAge: parseInt(process.env.SESSION_MAX_AGE || "604800000"),
  },

  // Google APIs
  google: {
    searchApiKey: process.env.GOOGLE_SEARCH_API_KEY,
    searchEngineId: process.env.GOOGLE_SEARCH_ENGINE_ID,
    driveCredentials: process.env.GOOGLE_DRIVE_CREDENTIALS,
  },

  // AI Services
  ai: {
    openaiKey: process.env.OPENAI_API_KEY,
    anthropicKey: process.env.ANTHROPIC_API_KEY,
    geminiKey: process.env.GEMINI_API_KEY,
  },

  // Email
  email: {
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587"),
    user: process.env.SMTP_USER,
    password: process.env.SMTP_PASSWORD,
  },

  // Telegram
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN,
  },

  // AWS
  aws: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION || "us-east-1",
    s3Bucket: process.env.AWS_S3_BUCKET,
  },

  // External APIs
  externalApis: {
    alphaVantage: process.env.ALPHA_VANTAGE_API_KEY,
    newsApi: process.env.NEWS_API_KEY,
    coinGecko: process.env.COINGECKO_API_KEY,
  },

  // Redis
  redis: {
    url: process.env.REDIS_URL || "redis://localhost:6379",
  },

  // ML Service
  ml: {
    serviceUrl: process.env.ML_SERVICE_URL || "http://localhost:2105",
  },

  // CORS
  cors: {
    allowedOrigins: (
      process.env.ALLOWED_ORIGINS || "http://localhost:3000"
    ).split(","),
  },

  // Rate Limiting
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || "900000"),
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || "100"),
  },

  // Logging
  logging: {
    level: process.env.LOG_LEVEL || "info",
    sentryDsn: process.env.SENTRY_DSN,
  },

  // Feature Flags
  features: {
    webScraping: process.env.ENABLE_WEB_SCRAPING === "true",
    driftDetection: process.env.ENABLE_DRIFT_DETECTION === "true",
    learningPath: process.env.ENABLE_LEARNING_PATH === "true",
    socialSentiment: process.env.ENABLE_SOCIAL_SENTIMENT === "true",
    swagger: process.env.ENABLE_SWAGGER === "true",
  },
} as const;
