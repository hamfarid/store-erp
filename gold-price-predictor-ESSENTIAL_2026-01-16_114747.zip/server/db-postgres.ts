// FILE: server/db-postgres.ts | PURPOSE: PostgreSQL database connection and operations | OWNER: Backend Team | RELATED: server/db-sqlite.ts | LAST-AUDITED: 2025-11-25

import { Pool, PoolClient } from "pg";
import * as bcrypt from "bcryptjs";
import { config } from "dotenv";

// Database connection pool
let pool: Pool | null = null;

/**
 * Get PostgreSQL connection pool
 */
export function getPool(): Pool {
  if (!pool) {
    // Load .env if not already loaded
    if (!process.env.DATABASE_URL_POSTGRES && !process.env.DATABASE_URL) {
      config();
    }

    const databaseUrl =
      process.env.DATABASE_URL_POSTGRES || process.env.DATABASE_URL;

    if (!databaseUrl || databaseUrl.includes("sqlite")) {
      throw new Error(
        "PostgreSQL DATABASE_URL_POSTGRES is not configured in .env"
      );
    }

    pool = new Pool({
      connectionString: databaseUrl,
      max: 20, // Maximum number of clients in the pool
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    console.log("✅ PostgreSQL connection pool created");
  }

  return pool;
}

/**
 * Execute a query
 */
export async function query(text: string, params?: any[]) {
  const pool = getPool();
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  console.log("Executed query", { text, duration, rows: res.rowCount });
  return res;
}

/**
 * Get a client from the pool for transactions
 */
export async function getClient(): Promise<PoolClient> {
  const pool = getPool();
  return await pool.connect();
}

// Duplicate getDb removed - using the compatibility version at the end of file

/**
 * Initialize database tables
 */
export async function initDatabase() {
  const pool = getPool();

  // Create users table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(64) PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      "passwordHash" VARCHAR(255),
      "loginMethod" VARCHAR(50) NOT NULL DEFAULT 'local',
      role VARCHAR(50) NOT NULL DEFAULT 'user',
      name VARCHAR(255),
      "createdAt" BIGINT NOT NULL,
      "lastSignedIn" BIGINT
    )
  `);

  // Create sessions table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sessions (
      id VARCHAR(64) PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      "expiresAt" BIGINT NOT NULL,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create assets table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS assets (
      id SERIAL PRIMARY KEY,
      symbol VARCHAR(50) NOT NULL UNIQUE,
      name VARCHAR(255) NOT NULL,
      type VARCHAR(50) NOT NULL,
      "currentPrice" DECIMAL(20, 8),
      "lastUpdated" BIGINT,
      active BOOLEAN DEFAULT true
    )
  `);

  // Create predictions table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS predictions (
      id SERIAL PRIMARY KEY,
      "assetId" INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
      "predictedPrice" DECIMAL(20, 8) NOT NULL,
      "predictionDate" BIGINT NOT NULL,
      confidence DECIMAL(5, 2),
      model VARCHAR(100),
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create activity_logs table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
      action VARCHAR(255) NOT NULL,
      details TEXT,
      "ipAddress" VARCHAR(45),
      "userAgent" TEXT,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create alerts table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS alerts (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL,
      "assetId" INTEGER NOT NULL,
      "alertType" VARCHAR(50) NOT NULL,
      "targetPrice" DECIMAL(20,8) NOT NULL,
      "notificationMethod" VARCHAR(255),
      "isActive" BOOLEAN DEFAULT true,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create notifications table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS notifications (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL,
      title VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      type VARCHAR(50) NOT NULL,
      "isRead" BOOLEAN DEFAULT false,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create settings table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS settings (
      "userId" VARCHAR(64) PRIMARY KEY,
      theme VARCHAR(50) DEFAULT 'system',
      "emailNotifications" BOOLEAN DEFAULT true,
      "pushNotifications" BOOLEAN DEFAULT true,
      currency VARCHAR(10) DEFAULT 'USD',
      language VARCHAR(10) DEFAULT 'en',
      "createdAt" BIGINT NOT NULL,
      "updatedAt" BIGINT
    )
  `);

  // Create permissions table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS permissions (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL,
      resource VARCHAR(100) NOT NULL,
      action VARCHAR(100) NOT NULL,
      granted BOOLEAN DEFAULT true,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create historical_prices table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS historical_prices (
      id SERIAL PRIMARY KEY,
      "assetId" INTEGER NOT NULL,
      date BIGINT NOT NULL,
      price DECIMAL(20,8) NOT NULL,
      high DECIMAL(20,8),
      low DECIMAL(20,8),
      open DECIMAL(20,8),
      volume BIGINT,
      change VARCHAR(50),
      "changePercent" VARCHAR(50),
      timestamp BIGINT,
      UNIQUE("assetId", date)
    )
  `);

  // Create trading_signals table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS trading_signals (
      id SERIAL PRIMARY KEY,
      "assetId" INTEGER NOT NULL,
      "signalType" VARCHAR(50),
      strength DECIMAL(5,2),
      confidence DECIMAL(5,2),
      indicators TEXT,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create breakout_points table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS breakout_points (
      id SERIAL PRIMARY KEY,
      "assetId" INTEGER NOT NULL,
      "resistanceLevel" DECIMAL(20,8),
      "supportLevel" DECIMAL(20,8),
      "breakoutProbability" DECIMAL(5,2),
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create break_even_points table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS break_even_points (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64),
      "assetId" INTEGER NOT NULL,
      "buyPrice" DECIMAL(20,8),
      quantity DECIMAL(20,8),
      fees DECIMAL(20,8),
      "breakEvenPrice" DECIMAL(20,8),
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create inflection_points table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS inflection_points (
      id SERIAL PRIMARY KEY,
      "assetId" INTEGER NOT NULL,
      price DECIMAL(20,8),
      "pointType" VARCHAR(50),
      confidence DECIMAL(5,2),
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create ai_conversations table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_conversations (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL,
      "assistantId" INTEGER NOT NULL,
      message TEXT NOT NULL,
      response TEXT NOT NULL,
      "tokensUsed" INTEGER,
      "responseTime" INTEGER,
      "wasSuccessful" BOOLEAN DEFAULT true,
      "errorMessage" TEXT,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create ai_usage_limits table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_usage_limits (
      id SERIAL PRIMARY KEY,
      "userId" VARCHAR(64) NOT NULL,
      "assistantId" INTEGER NOT NULL,
      "messagesToday" INTEGER DEFAULT 0 NOT NULL,
      "tokensToday" INTEGER DEFAULT 0 NOT NULL,
      "lastResetDate" BIGINT NOT NULL,
      "createdAt" BIGINT NOT NULL
    )
  `);

  // Create ai_feedback table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_feedback (
      id SERIAL PRIMARY KEY,
      "conversationId" INTEGER NOT NULL,
      "userId" VARCHAR(64) NOT NULL,
      rating INTEGER NOT NULL,
      feedback TEXT,
      "createdAt" BIGINT NOT NULL
    )
  `);

  console.log("✅ PostgreSQL database tables initialized");
}

/**
 * User operations
 */
export async function getUser(id: string) {
  const result = await query("SELECT * FROM users WHERE id = $1", [id]);
  return result.rows[0] || null;
}

export async function getUserByEmail(email: string) {
  const result = await query("SELECT * FROM users WHERE email = $1", [email]);
  return result.rows[0] || null;
}

export async function createUser(user: {
  id: string;
  name: string;
  email: string;
  passwordHash?: string;
  loginMethod: string;
  role?: string;
}) {
  const now = Date.now();
  const result = await query(
    `INSERT INTO users (id, name, email, "passwordHash", "loginMethod", role, "createdAt", "lastSignedIn")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING *`,
    [
      user.id,
      user.name,
      user.email,
      user.passwordHash || null,
      user.loginMethod,
      user.role || "user",
      now,
      now,
    ]
  );
  return result.rows[0];
}

export async function upsertUser(
  user: Partial<{
    id: string;
    name: string;
    email: string;
    passwordHash: string;
    loginMethod: string;
    role: string;
    lastSignedIn: number;
  }>
) {
  if (!user.id) {
    throw new Error("User ID is required for upsert");
  }

  // Check if user exists
  const existing = await getUser(user.id);

  if (existing) {
    // Update existing user
    const updates: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    if (user.name !== undefined) {
      updates.push(`name = $${paramIndex++}`);
      values.push(user.name);
    }
    if (user.email !== undefined) {
      updates.push(`email = $${paramIndex++}`);
      values.push(user.email);
    }
    if (user.passwordHash !== undefined) {
      updates.push(`"passwordHash" = $${paramIndex++}`);
      values.push(user.passwordHash);
    }
    if (user.loginMethod !== undefined) {
      updates.push(`"loginMethod" = $${paramIndex++}`);
      values.push(user.loginMethod);
    }
    if (user.role !== undefined) {
      updates.push(`role = $${paramIndex++}`);
      values.push(user.role);
    }
    if (user.lastSignedIn !== undefined) {
      updates.push(`"lastSignedIn" = $${paramIndex++}`);
      values.push(user.lastSignedIn);
    }

    if (updates.length > 0) {
      values.push(user.id);
      await query(
        `UPDATE users SET ${updates.join(", ")} WHERE id = $${paramIndex}`,
        values
      );
    }
  } else {
    // Create new user
    await createUser({
      id: user.id,
      name: user.name || "",
      email: user.email || "",
      passwordHash: user.passwordHash,
      loginMethod: user.loginMethod || "local",
      role: user.role || "user",
    });
  }
}

/**
 * Asset operations
 */
export async function getAllAssets() {
  const result = await query(
    'SELECT id, symbol, name, type, "currentPrice", "lastUpdated", active as "isActive" FROM assets WHERE active = true ORDER BY symbol'
  );
  return result.rows;
}

export async function getAssetById(id: number) {
  const result = await query("SELECT * FROM assets WHERE id = $1", [id]);
  return result.rows[0] || null;
}

/**
 * Get current prices for all active assets
 */
export async function getCurrentPrices() {
  try {
    // Get all active assets with their latest prices from historical_prices
    const result = await query(`
      SELECT DISTINCT ON (a.id)
        a.id as "assetId",
        a.symbol,
        a.name,
        hp.close_price as "currentPrice",
        hp.date as "lastUpdated"
      FROM assets a
      LEFT JOIN historical_prices hp ON a.id = hp.asset_id
      WHERE a."isActive" = true
      ORDER BY a.id, hp.date DESC
    `);
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting current prices:", error);
    return [];
  }
}

/**
 * Activity log operations
 */
export async function logActivity(log: {
  userId?: string;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
}) {
  const now = Date.now();
  await query(
    `INSERT INTO activity_logs ("userId", action, details, "ipAddress", "userAgent", "createdAt")
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [
      log.userId || null,
      log.action,
      log.details || null,
      log.ipAddress || null,
      log.userAgent || null,
      now,
    ]
  );
}

/**
 * Get prediction history for a user
 */
export async function getPredictionHistory(params: {
  userId?: string;
  assetId?: number;
  limit?: number;
}) {
  try {
    let queryText = `
      SELECT p.*, a.name as "assetName", a.symbol as "assetSymbol"
      FROM predictions p
      LEFT JOIN assets a ON p."assetId" = a.id
      WHERE 1=1
    `;
    const queryParams: any[] = [];
    let paramIndex = 1;

    if (params.userId) {
      queryText += ` AND p."userId" = $${paramIndex}`;
      queryParams.push(params.userId);
      paramIndex++;
    }
    if (params.assetId) {
      queryText += ` AND p."assetId" = $${paramIndex}`;
      queryParams.push(params.assetId);
      paramIndex++;
    }

    queryText += ` ORDER BY p."createdAt" DESC LIMIT $${paramIndex}`;
    queryParams.push(params.limit || 50);

    const result = await query(queryText, queryParams);
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting prediction history:", error);
    return [];
  }
}

/**
 * Get user alerts
 */
export async function getUserAlerts(userId: string, limit: number = 50) {
  try {
    const result = await query(
      `SELECT a.*, ast.name as "assetName", ast.symbol as "assetSymbol"
       FROM alerts a
       LEFT JOIN assets ast ON a."assetId" = ast.id
       WHERE a."userId" = $1
       ORDER BY a."createdAt" DESC
       LIMIT $2`,
      [userId, limit]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting user alerts:", error);
    return [];
  }
}

/**
 * Asset CRUD operations
 */
export async function createAsset(asset: {
  symbol: string;
  name: string;
  type: string;
  currentPrice?: number;
}) {
  const now = Date.now();
  const result = await query(
    `INSERT INTO assets (symbol, name, type, "currentPrice", "lastUpdated", active)
     VALUES ($1, $2, $3, $4, $5, true)
     RETURNING *`,
    [asset.symbol, asset.name, asset.type, asset.currentPrice || null, now]
  );
  return result.rows[0];
}

export async function updateAsset(
  id: number,
  asset: Partial<{
    symbol: string;
    name: string;
    type: string;
    currentPrice: number;
    active: boolean;
  }>
) {
  const updates: string[] = [];
  const values: any[] = [];
  let paramIndex = 1;

  if (asset.symbol !== undefined) {
    updates.push(`symbol = $${paramIndex++}`);
    values.push(asset.symbol);
  }
  if (asset.name !== undefined) {
    updates.push(`name = $${paramIndex++}`);
    values.push(asset.name);
  }
  if (asset.type !== undefined) {
    updates.push(`type = $${paramIndex++}`);
    values.push(asset.type);
  }
  if (asset.currentPrice !== undefined) {
    updates.push(`"currentPrice" = $${paramIndex++}`);
    values.push(asset.currentPrice);
  }
  if (asset.active !== undefined) {
    updates.push(`active = $${paramIndex++}`);
    values.push(asset.active);
  }

  updates.push(`"lastUpdated" = $${paramIndex++}`);
  values.push(Date.now());
  values.push(id);

  const result = await query(
    `UPDATE assets SET ${updates.join(", ")} WHERE id = $${paramIndex} RETURNING *`,
    values
  );
  return result.rows[0];
}

/**
 * Insert historical price data
 */
export async function getAssetPriceHistory(
  assetId: number,
  startDate?: Date,
  endDate?: Date
): Promise<Array<{ date: Date; price: number; open: number; high: number; low: number; close: number; volume?: number }>> {
  let queryStr = `
    SELECT date, price, open, high, low, close, volume
    FROM historical_prices
    WHERE asset_id = $1
  `;
  
  const params: any[] = [assetId];
  
  if (startDate) {
    params.push(startDate);
    queryStr += ` AND date >= $${params.length}`;
  } else {
    // Default to last 30 days if no start date
    queryStr += ` AND date >= NOW() - INTERVAL '30 days'`;
  }
  
  if (endDate) {
    params.push(endDate);
    queryStr += ` AND date <= $${params.length}`;
  }
  
  queryStr += ` ORDER BY date ASC`;

  const result = await query(queryStr, params);

  return result.rows.map(row => ({
    date: new Date(row.date),
    price: parseFloat(row.price),
    open: parseFloat(row.open),
    high: parseFloat(row.high),
    low: parseFloat(row.low),
    close: parseFloat(row.close),
    volume: row.volume ? parseFloat(row.volume) : undefined
  }));
}

export async function getLatestPredictions(assetId: number, limit: number = 10) {
  const result = await query(
    `
    SELECT *
    FROM predictions
    WHERE asset_id = $1
    ORDER BY created_at DESC
    LIMIT $2
    `,
    [assetId, limit]
  );
  
  return result.rows;
}

export async function insertHistoricalPrice(price: {
  assetId: number;
  date: number;
  price: number;
  high?: number;
  low?: number;
  open?: number;
  volume?: number;
  change?: string;
  changePercent?: string;
  timestamp?: number;
}) {
  try {
    const result = await query(
      `INSERT INTO historical_prices ("assetId", date, price, high, low, open, volume, change, "changePercent", timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT ("assetId", date) DO UPDATE SET
         price = EXCLUDED.price,
         high = EXCLUDED.high,
         low = EXCLUDED.low,
         open = EXCLUDED.open,
         volume = EXCLUDED.volume,
         change = EXCLUDED.change,
         "changePercent" = EXCLUDED."changePercent",
         timestamp = EXCLUDED.timestamp
       RETURNING *`,
      [
        price.assetId,
        price.date,
        price.price,
        price.high || null,
        price.low || null,
        price.open || null,
        price.volume || null,
        price.change || "0.00",
        price.changePercent || "0.00",
        price.timestamp || Date.now(),
      ]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error inserting historical price:", error);
    throw error;
  }
}

export async function deleteAsset(id: number) {
  await query("DELETE FROM assets WHERE id = $1", [id]);
  return { success: true };
}

/**
 * Prediction operations
 */
export async function generatePrediction(prediction: {
  assetId: number;
  predictedPrice: number;
  confidence?: number;
  model?: string;
  horizon?: string;
  modelType?: string;
}) {
  const now = Date.now();
  const result = await query(
    `INSERT INTO predictions ("assetId", "predictedPrice", "predictionDate", confidence, model, "createdAt")
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [
      prediction.assetId,
      prediction.predictedPrice,
      now,
      prediction.confidence || null,
      prediction.model || prediction.modelType || "ensemble",
      now,
    ]
  );
  return result.rows[0];
}

export async function getPredictionById(id: number) {
  const result = await query("SELECT * FROM predictions WHERE id = $1", [id]);
  return result.rows[0] || null;
}

export async function updatePrediction(
  id: number,
  data: Partial<{
    predictedPrice: number;
    confidence: number;
    model: string;
  }>
) {
  const updates: string[] = [];
  const values: any[] = [];
  let paramIndex = 1;

  if (data.predictedPrice !== undefined) {
    updates.push(`"predictedPrice" = $${paramIndex++}`);
    values.push(data.predictedPrice);
  }
  if (data.confidence !== undefined) {
    updates.push(`confidence = $${paramIndex++}`);
    values.push(data.confidence);
  }
  if (data.model !== undefined) {
    updates.push(`model = $${paramIndex++}`);
    values.push(data.model);
  }

  if (updates.length === 0) {return null;}

  values.push(id);
  const result = await query(
    `UPDATE predictions SET ${updates.join(", ")} WHERE id = $${paramIndex} RETURNING *`,
    values
  );
  return result.rows[0];
}

export async function deletePrediction(id: number) {
  await query("DELETE FROM predictions WHERE id = $1", [id]);
  return { success: true };
}

export async function getPredictionAccuracyComparison(params: {
  assetId?: number;
  days?: number;
}) {
  try {
    const result = await query(
      `SELECT model as "modelType",
              AVG(confidence) as accuracy,
              COUNT(*) as count
       FROM predictions
       WHERE ($1::int IS NULL OR "assetId" = $1)
         AND "createdAt" > $2
       GROUP BY model
       ORDER BY accuracy DESC`,
      [
        params.assetId || null,
        Date.now() - (params.days || 30) * 24 * 60 * 60 * 1000,
      ]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting prediction accuracy:", error);
    return [];
  }
}

/**
 * Alert operations
 */
export async function createAlert(alert: {
  userId: string;
  assetId: number;
  condition: string;
  threshold: string;
  channels: string[];
}) {
  const now = Date.now();
  const result = await query(
    `INSERT INTO alerts ("userId", "assetId", "alertType", "targetPrice", "notificationMethod", "isActive", "createdAt")
     VALUES ($1, $2, $3, $4, $5, true, $6)
     RETURNING *`,
    [
      alert.userId,
      alert.assetId,
      alert.condition,
      alert.threshold,
      alert.channels.join(","),
      now,
    ]
  );
  return result.rows[0];
}

export async function updateAlert(
  id: number,
  data: Partial<{
    condition: string;
    threshold: string;
    isActive: boolean;
    channels: string[];
  }>
) {
  const updates: string[] = [];
  const values: any[] = [];
  let paramIndex = 1;

  if (data.condition !== undefined) {
    updates.push(`"alertType" = $${paramIndex++}`);
    values.push(data.condition);
  }
  if (data.threshold !== undefined) {
    updates.push(`"targetPrice" = $${paramIndex++}`);
    values.push(data.threshold);
  }
  if (data.isActive !== undefined) {
    updates.push(`"isActive" = $${paramIndex++}`);
    values.push(data.isActive);
  }
  if (data.channels !== undefined) {
    updates.push(`"notificationMethod" = $${paramIndex++}`);
    values.push(data.channels.join(","));
  }

  if (updates.length === 0) {return null;}

  values.push(id);
  const result = await query(
    `UPDATE alerts SET ${updates.join(", ")} WHERE id = $${paramIndex} RETURNING *`,
    values
  );
  return result.rows[0];
}

export async function deleteAlert(id: number) {
  await query("DELETE FROM alerts WHERE id = $1", [id]);
  return { success: true };
}

export async function getAlertById(id: number) {
  const result = await query("SELECT * FROM alerts WHERE id = $1", [id]);
  return result.rows[0] || null;
}

/**
 * User admin operations
 */
export async function getAllUsers(params: { limit?: number; offset?: number }) {
  const result = await query(
    `SELECT id, name, email, role, "loginMethod", "createdAt", "lastSignedIn"
     FROM users
     ORDER BY "createdAt" DESC
     LIMIT $1 OFFSET $2`,
    [params.limit || 100, params.offset || 0]
  );
  return result.rows;
}

export async function getUserByIdAdmin(id: string) {
  const result = await query(
    `SELECT id, name, email, role, "loginMethod", "createdAt", "lastSignedIn"
     FROM users WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

export async function updateUserRole(id: string, role: string) {
  const result = await query(
    `UPDATE users SET role = $1 WHERE id = $2 RETURNING id, name, email, role`,
    [role, id]
  );
  return result.rows[0];
}

export async function deleteUser(id: string) {
  await query("DELETE FROM users WHERE id = $1", [id]);
  return { success: true };
}

/**
 * Permission operations
 */
export async function getUserPermissions(userId: string) {
  try {
    const result = await query(
      `SELECT * FROM permissions WHERE "userId" = $1`,
      [userId]
    );
    return result.rows;
  } catch (error) {
    // Table might not exist yet
    return [];
  }
}

export async function createPermission(permission: {
  userId: string;
  resource: string;
  action: string;
}) {
  const now = Date.now();
  try {
    const result = await query(
      `INSERT INTO permissions ("userId", resource, action, granted, "createdAt")
       VALUES ($1, $2, $3, true, $4)
       RETURNING *`,
      [permission.userId, permission.resource, permission.action, now]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error creating permission:", error);
    return null;
  }
}

export async function revokePermission(userId: string, permission: string) {
  try {
    await query(
      `DELETE FROM permissions WHERE "userId" = $1 AND (resource = $2 OR action = $2)`,
      [userId, permission]
    );
    return { success: true };
  } catch (error) {
    return { success: false };
  }
}

export async function hasPermission(
  userId: string,
  resource: string,
  action: string
) {
  try {
    const result = await query(
      `SELECT * FROM permissions
       WHERE "userId" = $1 AND resource = $2 AND action = $3 AND granted = true`,
      [userId, resource, action]
    );
    return result.rows.length > 0;
  } catch (error) {
    return false;
  }
}

/**
 * Historical prices operations
 */
export async function getHistoricalPrices(params: {
  limit?: number;
  assetId?: number;
}) {
  try {
    const result = await query(
      `SELECT * FROM historical_prices
       WHERE ($1::int IS NULL OR asset_id = $1)
       ORDER BY date DESC
       LIMIT $2`,
      [params.assetId || null, params.limit || 100]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting historical prices:", error);
    return [];
  }
}

export async function getHistoricalPricesByAsset(
  assetId: number,
  limit: number = 100
) {
  try {
    const result = await query(
      `SELECT * FROM historical_prices
       WHERE asset_id = $1
       ORDER BY date DESC
       LIMIT $2`,
      [assetId, limit]
    );
    return result.rows;
  } catch (error) {
    console.error(
      "[Database] Error getting historical prices by asset:",
      error
    );
    return [];
  }
}

export async function getLatestPrice(assetId: number) {
  try {
    const result = await query(
      `SELECT * FROM historical_prices
       WHERE asset_id = $1
       ORDER BY date DESC
       LIMIT 1`,
      [assetId]
    );
    return result.rows[0] || null;
  } catch (error) {
    console.error("[Database] Error getting latest price:", error);
    return null;
  }
}

/**
 * Trading signals operations
 */
export async function calculateTradingSignals(assetId: number) {
  // This would typically call ML model - returning mock for now
  return {
    signalType: "hold",
    strength: 50,
    confidence: 0.7,
    indicators: {},
  };
}

export async function createTradingSignal(signal: {
  assetId: number;
  signalType: string;
  strength: number;
  confidence: number;
  indicators?: any;
}) {
  const now = Date.now();
  try {
    const result = await query(
      `INSERT INTO trading_signals ("assetId", "signalType", strength, confidence, indicators, "createdAt")
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        signal.assetId,
        signal.signalType,
        signal.strength,
        signal.confidence,
        JSON.stringify(signal.indicators || {}),
        now,
      ]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error creating trading signal:", error);
    return null;
  }
}

export async function getTradingSignals(params: {
  assetId?: number;
  isActive?: boolean;
  limit?: number;
}) {
  try {
    const result = await query(
      `SELECT * FROM trading_signals
       WHERE ($1::int IS NULL OR "assetId" = $1)
       ORDER BY "createdAt" DESC
       LIMIT $2`,
      [params.assetId || null, params.limit || 50]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting trading signals:", error);
    return [];
  }
}

/**
 * Breakout points operations
 */
export async function calculateBreakoutPoints(assetId: number) {
  // This would typically call analysis function - returning mock for now
  return {
    resistanceLevel: 2000,
    supportLevel: 1900,
    breakoutProbability: 0.65,
  };
}

export async function createBreakoutPoint(point: {
  assetId: number;
  resistanceLevel: number;
  supportLevel: number;
  breakoutProbability: number;
}) {
  const now = Date.now();
  try {
    const result = await query(
      `INSERT INTO breakout_points ("assetId", "resistanceLevel", "supportLevel", "breakoutProbability", "createdAt")
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        point.assetId,
        point.resistanceLevel,
        point.supportLevel,
        point.breakoutProbability,
        now,
      ]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error creating breakout point:", error);
    return null;
  }
}

export async function getBreakoutPoints(params: {
  assetId?: number;
  limit?: number;
}) {
  try {
    const result = await query(
      `SELECT * FROM breakout_points
       WHERE ($1::int IS NULL OR "assetId" = $1)
       ORDER BY "createdAt" DESC
       LIMIT $2`,
      [params.assetId || null, params.limit || 50]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting breakout points:", error);
    return [];
  }
}

/**
 * Break-even points operations
 */
export async function createBreakEvenPoint(point: {
  userId: string;
  assetId: number;
  buyPrice: number;
  quantity: number;
  fees?: number;
}) {
  const now = Date.now();
  const breakEvenPrice = point.buyPrice + (point.fees || 0) / point.quantity;
  try {
    const result = await query(
      `INSERT INTO break_even_points ("userId", "assetId", "buyPrice", quantity, fees, "breakEvenPrice", "createdAt")
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        point.userId,
        point.assetId,
        point.buyPrice,
        point.quantity,
        point.fees || 0,
        breakEvenPrice,
        now,
      ]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error creating break-even point:", error);
    return null;
  }
}

export async function getBreakEvenPoints(params: {
  userId?: string;
  assetId?: number;
}) {
  try {
    const result = await query(
      `SELECT * FROM break_even_points
       WHERE ($1::text IS NULL OR "userId" = $1)
         AND ($2::int IS NULL OR "assetId" = $2)
       ORDER BY "createdAt" DESC`,
      [params.userId || null, params.assetId || null]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting break-even points:", error);
    return [];
  }
}

export async function deleteBreakEvenPoint(id: number) {
  await query("DELETE FROM break_even_points WHERE id = $1", [id]);
  return { success: true };
}

/**
 * Inflection points operations
 */
export async function calculateInflectionPoints(assetId: number) {
  // This would typically call analysis function - returning mock for now
  return {
    points: [],
    trend: "neutral",
  };
}

export async function createInflectionPoint(point: {
  assetId: number;
  price: number;
  pointType: string;
  confidence: number;
}) {
  const now = Date.now();
  try {
    const result = await query(
      `INSERT INTO inflection_points ("assetId", price, "pointType", confidence, "createdAt")
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [point.assetId, point.price, point.pointType, point.confidence, now]
    );
    return result.rows[0];
  } catch (error) {
    console.error("[Database] Error creating inflection point:", error);
    return null;
  }
}

export async function getInflectionPoints(params: {
  assetId?: number;
  limit?: number;
}) {
  try {
    const result = await query(
      `SELECT * FROM inflection_points
       WHERE ($1::int IS NULL OR "assetId" = $1)
       ORDER BY "createdAt" DESC
       LIMIT $2`,
      [params.assetId || null, params.limit || 50]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting inflection points:", error);
    return [];
  }
}

/**
 * Model performance operations
 */
/**
 * Alerts - Additional functions for compatibility with SQLite
 */
export async function getAlertsByUserId(userId: string) {
  return await getUserAlerts(userId, 1000); // Get all alerts
}

/**
 * Notifications - Compatibility functions
 */
export async function getUserNotifications(
  userId: string,
  limit: number = 50,
  offset: number = 0
) {
  try {
    const result = await query(
      `SELECT * FROM notifications
       WHERE "userId" = $1
       ORDER BY "createdAt" DESC
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting user notifications:", error);
    return [];
  }
}

export async function getUnreadNotificationsCount(userId: string) {
  try {
    const result = await query(
      `SELECT COUNT(*) as count FROM notifications WHERE "userId" = $1 AND "isRead" = false`,
      [userId]
    );
    return parseInt(result.rows[0]?.count || "0", 10);
  } catch (error) {
    console.error(
      "[Database] Error getting unread notifications count:",
      error
    );
    return 0;
  }
}

/**
 * Admin / System Operations
 */
export async function getSystemStats() {
  try {
    const users = await query('SELECT COUNT(*) FROM users');
    const assets = await query('SELECT COUNT(*) FROM assets');
    const predictions = await query('SELECT COUNT(*) FROM predictions');
    const alerts = await query('SELECT COUNT(*) FROM alerts');
    
    return {
      users: parseInt(users.rows[0].count),
      assets: parseInt(assets.rows[0].count),
      predictions: parseInt(predictions.rows[0].count),
      alerts: parseInt(alerts.rows[0].count),
      timestamp: Date.now()
    };
  } catch (e) {
    console.error("Error getting system stats", e);
    return { users: 0, assets: 0, predictions: 0, alerts: 0, timestamp: Date.now() };
  }
}

export const getAllUsersAdmin = getAllUsers;

export async function updateUserAdmin(id: string, updates: any) {
  // upsertUser expects 'id' in the object
  return upsertUser({ id, ...updates });
}

export async function getUserStats() {
  try {
    const total = await query('SELECT COUNT(*) FROM users');
    // Using simple counts for now
    const active = await query('SELECT COUNT(*) FROM users'); 
    const newUsers = await query('SELECT COUNT(*) FROM users'); 
    
    return {
      total: parseInt(total.rows[0].count),
      active: parseInt(active.rows[0].count),
      new: parseInt(newUsers.rows[0].count)
    };
  } catch (e) {
    return { total: 0, active: 0, new: 0 };
  }
}

export const getAllAssetsAdmin = getAllAssets;

export async function createAssetAdmin(asset: any) {
  return createAsset(asset);
}

export async function updateAssetAdmin(id: number, updates: any) {
  return updateAsset(id, updates);
}

export async function deleteAssetAdmin(id: number) {
  return deleteAsset(id);
}

export async function getSystemLogs(params: { limit: number; offset: number; level?: string }) {
  try {
    let sql = 'SELECT * FROM activity_logs WHERE 1=1';
    const queryParams: any[] = [];
    let idx = 1;
    
    sql += ` ORDER BY "createdAt" DESC LIMIT $${idx++} OFFSET $${idx++}`;
    queryParams.push(params.limit || 100, params.offset || 0);
    
    const result = await query(sql, queryParams);
    return result.rows;
  } catch (e) {
    return [];
  }
}

export async function clearSystemLogs(olderThan?: string) {
  if (olderThan) {
    const timestamp = new Date(olderThan).getTime();
    await query('DELETE FROM activity_logs WHERE "createdAt" < $1', [timestamp]);
  } else {
    await query('DELETE FROM activity_logs');
  }
  return { success: true };
}

export async function getDatabaseStats() {
  try {
    const size = await query("SELECT pg_size_pretty(pg_database_size(current_database())) as size");
    return {
      size: size.rows[0]?.size || "0 MB",
      tables: 12,
      connections: (getPool() as any).totalCount || 0
    };
  } catch (e) {
    return { size: "Unknown", tables: 0, connections: 0 };
  }
}

export async function createDatabaseBackup() {
  return { success: true, timestamp: new Date().toISOString(), url: 'backup-url-mock' };
}

export async function optimizeDatabase() {
  // await query('VACUUM'); // Requires permissions usually, safely skip or try
  return { success: true };
}

export async function getSystemConfig() {
  return {
    maintenanceMode: false,
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0'
  };
}

export async function updateSystemConfig(key: string, value: any) {
  return { success: true };
}

/**
 * Notifications & Settings
 */
export async function markNotificationAsRead(id: number, userId: string) {
  await query('UPDATE notifications SET "isRead" = true WHERE id = $1 AND "userId" = $2', [id, userId]);
  return { success: true };
}

export async function markAllNotificationsAsRead(userId: string) {
  await query('UPDATE notifications SET "isRead" = true WHERE "userId" = $1', [userId]);
  return { success: true };
}

export async function deleteNotification(id: number, userId: string) {
  await query('DELETE FROM notifications WHERE id = $1 AND "userId" = $2', [id, userId]);
  return { success: true };
}

export async function deleteAllReadNotifications(userId: string) {
  await query('DELETE FROM notifications WHERE "userId" = $1 AND "isRead" = true', [userId]);
  return { success: true };
}

export async function createNotification(notification: { userId: string; title: string; message: string; type: string }) {
  try {
    const result = await query(
      `INSERT INTO notifications ("userId", title, message, type, "isRead", "createdAt")
       VALUES ($1, $2, $3, $4, false, $5) RETURNING *`,
      [notification.userId, notification.title, notification.message, notification.type, Date.now()]
    );
    return result.rows[0];
  } catch (e) {
    console.error("Error creating notification", e);
    return null;
  }
}

export async function getUserSettings(userId: string) {
  try {
    const result = await query('SELECT * FROM settings WHERE "userId" = $1', [userId]);
    if (!result.rows[0]) {
      await query(
        `INSERT INTO settings ("userId", theme, "emailNotifications", "pushNotifications", currency, language, "createdAt", "updatedAt")
         VALUES ($1, 'system', true, true, 'USD', 'en', $2, $2)`,
        [userId, Date.now()]
      );
      return (await query('SELECT * FROM settings WHERE "userId" = $1', [userId])).rows[0];
    }
    return result.rows[0];
  } catch (e) {
    console.error("Error getting settings", e);
    return null;
  }
}

export async function updateUserSettings(userId: string, settings: any) {
  try {
    const existing = await getUserSettings(userId);
    const updates: string[] = [];
    const values: any[] = [];
    let idx = 1;
    
    if (settings.theme !== undefined) { updates.push(`theme = $${idx++}`); values.push(settings.theme); }
    if (settings.currency !== undefined) { updates.push(`currency = $${idx++}`); values.push(settings.currency); }
    if (settings.language !== undefined) { updates.push(`language = $${idx++}`); values.push(settings.language); }
    if (settings.emailNotifications !== undefined) { updates.push(`"emailNotifications" = $${idx++}`); values.push(settings.emailNotifications); }
    if (settings.pushNotifications !== undefined) { updates.push(`"pushNotifications" = $${idx++}`); values.push(settings.pushNotifications); }
    
    if (updates.length > 0) {
      updates.push(`"updatedAt" = $${idx++}`);
      values.push(Date.now());
      values.push(userId);
      await query(`UPDATE settings SET ${updates.join(', ')} WHERE "userId" = $${idx}`, values);
    }
    return await getUserSettings(userId);
  } catch (e) {
    console.error("Error updating settings", e);
    return null;
  }
}

export async function resetUserSettings(userId: string) {
  await query('DELETE FROM settings WHERE "userId" = $1', [userId]);
  return getUserSettings(userId);
}

/**
 * Reports & Others
 */
export async function getAllPredictions(params: { limit?: number; offset?: number } = {}) {
  try {
    const result = await query('SELECT * FROM predictions ORDER BY "createdAt" DESC LIMIT $1 OFFSET $2', [params.limit || 100, params.offset || 0]);
    return result.rows;
  } catch (e) {
    return [];
  }
}

export async function generatePortfolioReport(userId: string, params: any) { return { url: 'mock-report-url' }; }
export async function generateAccuracyReport(userId: string, params: any) { return { url: 'mock-report-url' }; }
export async function generateAlertsReport(userId: string, params: any) { return { url: 'mock-report-url' }; }
export async function generatePriceHistoryReport(params: any) { return { url: 'mock-report-url' }; }
export async function convertToCSV(data: any) { return "id,name\n1,test"; }
export async function getReportHistory(userId: string, limit: number, offset: number) { return [];}
export async function saveReport(userId: string, report: any) { return { id: 1 }; }
export async function deleteReport(id: number, userId: string) { return { success: true }; }


export async function getLatestPrices(limit: number = 50) {
  try {
    const result = await query('SELECT * FROM historical_prices ORDER BY date DESC LIMIT $1', [limit]);
    return result.rows;
  } catch (e) {
    return [];
  }
}

/**
 * Compatibility function: getDb() for PostgreSQL
 * Returns a mock object that matches SQLite's getDb() interface
 * This allows code that uses getDb() to work with PostgreSQL
 */
export function getDb() {
  // Return a mock object that provides a 'prepare' method
  // This is a compatibility layer for code expecting SQLite's getDb()
  return {
    prepare: (sql: string) => {
      // Convert SQLite-style queries to PostgreSQL
      const pgSql = sql.replace(/\?/g, (match, offset) => {
        const before = sql.substring(0, offset);
        const paramIndex = (before.match(/\?/g) || []).length + 1;
        return `$${paramIndex}`;
      });

      return {
        all: async (...params: any[]) => {
          const result = await query(pgSql, params);
          return result.rows;
        },
        get: async (...params: any[]) => {
          const result = await query(pgSql, params);
          return result.rows[0] || null;
        },
        run: async (...params: any[]) => {
          await query(pgSql, params);
          return { changes: 0, lastInsertRowid: null };
        },
      };
    },
  };
}

export async function getModelPerformance(assetId: number) {
  try {
    const result = await query(
      `SELECT model as "modelType",
              AVG(confidence) as accuracy,
              COUNT(*) as "totalPredictions",
              0 as mse,
              0 as rmse,
              0 as mae
       FROM predictions
       WHERE "assetId" = $1
       GROUP BY model`,
      [assetId]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting model performance:", error);
    return [];
  }
}

export async function getAccuracyHistory(params: {
  assetId: number;
  days: number;
}) {
  try {
    const result = await query(
      `SELECT DATE(to_timestamp("createdAt" / 1000)) as date,
              AVG(confidence) as accuracy,
              model as "modelType"
       FROM predictions
       WHERE "assetId" = $1
         AND "createdAt" > $2
       GROUP BY DATE(to_timestamp("createdAt" / 1000)), model
       ORDER BY date DESC`,
      [params.assetId, Date.now() - params.days * 24 * 60 * 60 * 1000]
    );
    return result.rows;
  } catch (error) {
    console.error("[Database] Error getting accuracy history:", error);
    return [];
  }
}

/**
 * Close database connection
 */
export async function closeDatabase() {
  if (pool) {
    await pool.end();
    pool = null;
    console.log("✅ PostgreSQL connection pool closed");
  }
}
