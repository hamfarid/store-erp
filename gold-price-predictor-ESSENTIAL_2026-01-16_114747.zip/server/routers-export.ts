import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { exportAllData, importAllData, exportMLData, createFullBackup } from "./export-import";
import * as path from "path";

export const exportRouter = router({
  // Export database to JSON
  exportDatabase: protectedProcedure
    .mutation(async () => {
      const outputDir = path.join(process.cwd(), 'exports');
      const filepath = await exportAllData(outputDir);
      return {
        success: true,
        filepath,
        message: "Database exported successfully",
      };
    }),
  
  // Export ML models and data
  exportMLModels: protectedProcedure
    .mutation(async () => {
      const outputDir = path.join(process.cwd(), 'exports');
      const dirpath = await exportMLData(outputDir);
      return {
        success: true,
        dirpath,
        message: "ML models exported successfully",
      };
    }),
  
  // Create full backup
  createBackup: protectedProcedure
    .mutation(async () => {
      const outputDir = path.join(process.cwd(), 'backups');
      const backupPath = await createFullBackup(outputDir);
      return {
        success: true,
        backupPath,
        message: "Full backup created successfully",
      };
    }),
  
  // Import data from file
  importData: protectedProcedure
    .input(z.object({
      filepath: z.string(),
    }))
    .mutation(async ({ input }) => {
      const imported = await importAllData(input.filepath);
      return {
        success: true,
        imported,
        message: "Data imported successfully",
      };
    }),
  
  // List available exports
  listExports: protectedProcedure
    .query(async () => {
      const fs = await import('fs');
      const exportsDir = path.join(process.cwd(), 'exports');
      
      if (!fs.existsSync(exportsDir)) {
        return [];
      }
      
      const files = fs.readdirSync(exportsDir);
      return files.map(file => ({
        name: file,
        path: path.join(exportsDir, file),
        size: fs.statSync(path.join(exportsDir, file)).size,
        created: fs.statSync(path.join(exportsDir, file)).mtime,
      }));
    }),
  
  // List available backups
  listBackups: protectedProcedure
    .query(async () => {
      const fs = await import('fs');
      const backupsDir = path.join(process.cwd(), 'backups');
      
      if (!fs.existsSync(backupsDir)) {
        return [];
      }
      
      const dirs = fs.readdirSync(backupsDir);
      return dirs.map(dir => ({
        name: dir,
        path: path.join(backupsDir, dir),
        created: fs.statSync(path.join(backupsDir, dir)).mtime,
      }));
    }),
});

