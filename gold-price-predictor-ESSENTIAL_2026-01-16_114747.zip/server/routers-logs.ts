import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  logError,
  logMLTraining,
  logPrediction,
  getRecentErrors,
  getMLTrainingHistory,
  getPredictionHistory,
  getAPIStats,
} from "./logger";

export const logsRouter = router({
  // Log error from frontend
  logError: publicProcedure
    .input(
      z.object({
        source: z.string(),
        component: z.string(),
        message: z.string(),
        stack: z.string().optional(),
        metadata: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await logError({
        source: input.source,
        component: input.component,
        message: input.message,
        stack: input.stack,
        userId: ctx.user?.id,
        metadata: input.metadata,
      });
      return { success: true };
    }),

  // Get recent errors (admin only)
  getErrors: protectedProcedure
    .input(
      z.object({
        limit: z.number().optional().default(50),
      })
    )
    .query(async ({ input }) => {
      return await getRecentErrors(input.limit);
    }),

  // Get ML training history
  getMLTrainingHistory: protectedProcedure
    .input(
      z.object({
        assetId: z.number().optional(),
        limit: z.number().optional().default(50),
      })
    )
    .query(async ({ input }) => {
      return await getMLTrainingHistory(input.assetId, input.limit);
    }),

  // Get prediction history with logs
  getPredictionLogs: protectedProcedure
    .input(
      z.object({
        limit: z.number().optional().default(50),
      })
    )
    .query(async ({ input, ctx }) => {
      return await getPredictionHistory(ctx.user.id, input.limit);
    }),

  // Get API statistics
  getAPIStats: protectedProcedure
    .input(
      z.object({
        hours: z.number().optional().default(24),
      })
    )
    .query(async ({ input }) => {
      return await getAPIStats(input.hours);
    }),

  // Get system health
  getSystemHealth: protectedProcedure.query(async () => {
    const errors = await getRecentErrors(10);
    const recentErrors = errors.filter((e: any) => {
      const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
      return e.timestamp && e.timestamp > hourAgo;
    });

    const apiStats = await getAPIStats(1);

    return {
      status: recentErrors.length > 10 ? "unhealthy" : "healthy",
      recentErrors: recentErrors.length,
      apiStats,
      timestamp: new Date(),
    };
  }),
});
