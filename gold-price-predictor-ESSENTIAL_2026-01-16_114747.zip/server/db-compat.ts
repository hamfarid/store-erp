/**
 * Database Compatibility Layer
 * Abstracts between SQLite (local) and PostgreSQL (production/docker)
 * Delegates to the appropriate implementation based on DATABASE_URL
 */

// Load .env before anything else
import dotenv from "dotenv";
dotenv.config();

import * as dbSqlite from "./db-sqlite";
import * as dbPostgres from "./db-postgres";

// Check if PostgreSQL is configured
export const usePostgres = !!(process.env.DATABASE_URL?.includes("postgres") || process.env.DATABASE_URL_POSTGRES);

console.log(`[DB-Compat] DATABASE_URL: ${process.env.DATABASE_URL?.substring(0, 50)}...`);
console.log(`[DB-Compat] Using database: ${usePostgres ? "PostgreSQL" : "SQLite"}`);

export function getDb() {
  if (usePostgres) {
    return dbPostgres.getDb();
  }
  return dbSqlite.getDb();
}

export interface QueryResult {
  rows: any[];
  rowCount?: number | null;
  lastInsertRowid?: number | bigint;
}

export async function query(sql: string, params: any[] = []): Promise<QueryResult> {
  if (usePostgres) {
    // Convert ? to $1, $2, etc.
    let pIdx = 1;
    const pgSql = sql.replace(/\?/g, () => `$${pIdx++}`);
    return dbPostgres.query(pgSql, params);
  }
  const db = dbSqlite.getDb();
  try {
    const stmt = db.prepare(sql);
    const lowerSql = sql.trim().toLowerCase();
    if (lowerSql.startsWith("select") || lowerSql.startsWith("with") || lowerSql.includes("returning")) {
      const rows = stmt.all(...params);
      return { rows, rowCount: rows.length };
    } else {
      const info = stmt.run(...params);
      return { rows: [], rowCount: info.changes, lastInsertRowid: info.lastInsertRowid };
    }
  } catch (error) {
    console.error("[DB-Compat] SQLite query error:", error);
    throw error;
  }
}

// ----------------------------------------------------------------------
// Unified Helper Functions
// Delegates to strict implementation
// ----------------------------------------------------------------------

// Users
export async function getUser(id: string) {
  const db = getDb();
  const stmt = db.prepare("SELECT * FROM users WHERE id = ?");
  // @ts-ignore - Handle shim promise vs better-sqlite3 sync
  return stmt.get ? await stmt.get(id) : stmt.run ? await stmt.run(id) : null; 
  // Wait, better-sqlite3 get is sync. await works.
  // But stmt might be ShimStatement (async get) or Statement (sync get).
  // await stmt.get(id) works for both.
}

// Alias for getUser (used by twoFactor router)
export async function getUserById(id: string) {
  return getUser(id);
}

// Update user data
export async function updateUser(userId: string, updates: Record<string, any>) {
  const db = getDb();
  const setClauses: string[] = [];
  const params: any[] = [];
  
  for (const [key, value] of Object.entries(updates)) {
    if (value !== undefined) {
      // Handle camelCase to snake_case conversion for common fields
      const columnName = key === 'twoFactorSecret' ? '"twoFactorSecret"' :
                         key === 'twoFactorEnabled' ? '"twoFactorEnabled"' :
                         key === 'twoFactorBackupCodes' ? '"twoFactorBackupCodes"' :
                         key === 'passwordHash' ? '"passwordHash"' :
                         key === 'loginMethod' ? '"loginMethod"' :
                         key === 'lastSignedIn' ? '"lastSignedIn"' :
                         key === 'createdAt' ? '"createdAt"' :
                         key;
      setClauses.push(`${columnName} = ?`);
      // Handle JSON fields
      params.push(Array.isArray(value) || typeof value === 'object' ? JSON.stringify(value) : value);
    }
  }
  
  if (setClauses.length === 0) {
    return getUser(userId);
  }
  
  params.push(userId);
  const sql = `UPDATE users SET ${setClauses.join(', ')} WHERE id = ?`;
  
  try {
    const stmt = db.prepare(sql);
    await stmt.run(...params);
    return getUser(userId);
  } catch (error) {
    console.error('[DB-Compat] updateUser error:', error);
    throw error;
  }
}

export async function getUserByEmail(email: string) {
  const db = getDb();
  return await db.prepare("SELECT * FROM users WHERE email = ?").get(email);
}

export async function createUser(user: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO users (id, name, email, passwordHash, loginMethod, role, "createdAt", "lastSignedIn")
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  await stmt.run(
    user.id,
    user.name,
    user.email,
    user.passwordHash || null,
    user.loginMethod,
    user.role || "user",
    Date.now(),
    Date.now()
  );

  return getUser(user.id);
}

export async function upsertUser(user: any) {
  const db = getDb();
  const existingUser = await getUser(user.id);
  
  if (existingUser) {
    const updates: string[] = [];
    const params: any[] = [];
    
    if (user.name !== undefined) { updates.push('name = ?'); params.push(user.name); }
    if (user.email !== undefined) { updates.push('email = ?'); params.push(user.email); }
    if (user.passwordHash !== undefined) { updates.push('"passwordHash" = ?'); params.push(user.passwordHash); }
    if (user.loginMethod !== undefined) { updates.push('"loginMethod" = ?'); params.push(user.loginMethod); }
    if (user.role !== undefined) { updates.push('role = ?'); params.push(user.role); }
    if (user.lastSignedIn !== undefined) { updates.push('"lastSignedIn" = ?'); params.push(user.lastSignedIn); }
    
    if (updates.length > 0) {
      params.push(user.id);
      const stmt = db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`);
      await stmt.run(...params);
    }
  } else {
    const stmt = db.prepare(`
      INSERT INTO users (id, name, email, "passwordHash", "loginMethod", role, "createdAt", "lastSignedIn")
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    await stmt.run(
      user.id,
      user.name || 'User',
      user.email || null,
      user.passwordHash || null,
      user.loginMethod || null,
      user.role || 'user',
      user.createdAt || Date.now(),
      user.lastSignedIn || Date.now()
    );
  }
}

// Assets
export async function getAllAssets() {
  try {
    const db = getDb();
    return await db.prepare("SELECT * FROM assets ORDER BY id").all();
  } catch (error) {
    console.error("[Database] Error getting assets:", error);
    return [];
  }
}

export async function getAssetById(id: number): Promise<any> {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM assets WHERE id = $1", [id]).then((res: any) => res.rows[0]);
  }
  return await db.prepare("SELECT * FROM assets WHERE id = ?").get(id);
}

export async function getAssetBySymbol(symbol: string) {
  const db = getDb();
  return await db.prepare("SELECT * FROM assets WHERE symbol = ?").get(symbol);
}

export async function createAsset(asset: any) {
  if (usePostgres) {
      return dbPostgres.query(`
        INSERT INTO assets (symbol, name, "assetType", exchange, currency, "currentPrice", sector, description, "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING id
      `, [
        asset.symbol, asset.name, asset.type || asset.assetType, asset.exchange || null, asset.currency || "USD",
        asset.currentPrice || null, asset.sector || null, asset.description || null, Date.now()
      ]).then((res: any) => ({ id: res.rows[0].id, ...asset }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO assets (symbol, name, assetType, exchange, currency, currentPrice, sector, description, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    asset.symbol,
    asset.name,
    asset.type || asset.assetType,
    asset.exchange || null,
    asset.currency || "USD",
    asset.currentPrice || null,
    asset.sector || null,
    asset.description || null,
    Date.now()
  );

  return { id: result.lastInsertRowid, ...asset };
}

export async function updateAsset(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.name) { fields.push("name = ?"); values.push(updates.name); }
  if (updates.symbol) { fields.push("symbol = ?"); values.push(updates.symbol); }
  if (updates.type || updates.assetType) { fields.push('"assetType" = ?'); values.push(updates.type || updates.assetType); }
  if (updates.currentPrice) { fields.push('"currentPrice" = ?'); values.push(updates.currentPrice); }
  if (updates.description) { fields.push("description = ?"); values.push(updates.description); }

  fields.push('"updatedAt" = ?');
  values.push(Date.now());

  if (fields.length === 1) {return;} 

  values.push(id);
  const stmt = db.prepare(`UPDATE assets SET ${fields.join(", ")} WHERE id = ?`);
  return await stmt.run(...values);
}

export async function deleteAsset(id: number) {
  const db = getDb();
  return await db.prepare("DELETE FROM assets WHERE id = ?").run(id);
}

export async function getCurrentPrices() {
  const db = getDb();
  return await db.prepare("SELECT id, symbol, name, \"currentPrice\", \"updatedAt\" FROM assets WHERE \"currentPrice\" IS NOT NULL").all();
}

// Historical Prices
export async function getHistoricalPricesByAssetId(assetId: number, limit: number = 100) {
  const db = getDb();
  return await db.prepare(`
    SELECT * FROM historical_prices
    WHERE assetId = ?
    ORDER BY date DESC
    LIMIT ?
  `).all(assetId, limit);
}

export async function insertHistoricalPrice(price: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO historical_prices (assetId, date, price, high, low, open, volume, change, changePercent, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `, [
      price.assetId, price.date, price.price, price.high || null, price.low || null, price.open || null,
      price.volume || null, price.change || "0.00", price.changePercent || "0.00", price.timestamp
    ]).then((res: any) => ({ id: res.rows[0].id, ...price }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO historical_prices (assetId, date, price, high, low, open, volume, change, changePercent, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    price.assetId,
    price.date,
    price.price,
    price.high || null,
    price.low || null,
    price.open || null,
    price.volume || null,
    price.change || "0.00",
    price.changePercent || "0.00",
    price.timestamp
  );

  return { id: result.lastInsertRowid, ...price };
}

export async function getLatestPrices(limit: number = 50) {
    // Assuming implementation based on db-sqlite (though not seen in truncated view)
    // Actually db-postgres.ts exported getLatestPrices.
    const db = getDb();
    // Implementation?
    return await db.prepare("SELECT * FROM historical_prices ORDER BY date DESC LIMIT ?").all(limit);
}

export async function getAssetPriceHistory(assetId: number, startDate?: Date, endDate?: Date, limit: number = 1000) {
    const db = getDb();
    let sql = "SELECT * FROM historical_prices WHERE assetId = ?";
    const params: any[] = [assetId];

    if (startDate) { sql += " AND date >= ?"; params.push(startDate); }
    if (endDate) { sql += " AND date <= ?"; params.push(endDate); }
    
    sql += " ORDER BY date ASC LIMIT ?";
    params.push(limit);
    
    return await db.prepare(sql).all(...params);
}

// Predictions
export async function getAllPredictions(limit: number = 50, offset: number = 0) {
  try {
    const db = getDb();
    return await db.prepare("SELECT * FROM predictions ORDER BY createdAt DESC LIMIT ? OFFSET ?").all(limit, offset);
  } catch (error) {
    console.error("[Database] Error getting predictions:", error);
    return [];
  }
}

export async function getPredictionsByAssetId(assetId: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM predictions WHERE assetId = ? ORDER BY createdAt DESC").all(assetId);
}

export async function getPredictionsByUserId(userId: string) {
  const db = getDb();
  return await db.prepare("SELECT * FROM predictions WHERE userId = ? ORDER BY createdAt DESC").all(userId);
}

export async function insertPrediction(prediction: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO predictions (assetId, userId, modelType, horizon, predictedPrice, confidenceLevel, predictionDate, accuracy, metadata, createdAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `, [
      prediction.assetId, prediction.userId, prediction.modelType, prediction.horizon, prediction.predictedPrice,
      prediction.confidenceLevel, prediction.predictionDate, prediction.accuracy || null, prediction.metadata || null, prediction.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...prediction }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO predictions (assetId, userId, modelType, horizon, predictedPrice, confidenceLevel, predictionDate, accuracy, metadata, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    prediction.assetId,
    prediction.userId,
    prediction.modelType,
    prediction.horizon,
    prediction.predictedPrice,
    prediction.confidenceLevel,
    prediction.predictionDate,
    prediction.accuracy || null,
    prediction.metadata || null,
    prediction.createdAt || Date.now()
  );

  return { id: result.lastInsertRowid, ...prediction };
}

export async function getPredictionById(id: number): Promise<any> {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM predictions WHERE id = $1", [id]).then((res: any) => res.rows[0]);
  }
  return await db.prepare("SELECT * FROM predictions WHERE id = ?").get(id);
}

export async function updatePrediction(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.modelType) { fields.push("modelType = ?"); values.push(updates.modelType); }
  if (updates.accuracy) { fields.push("accuracy = ?"); values.push(updates.accuracy); }
  if (updates.metadata) { fields.push("metadata = ?"); values.push(updates.metadata); }

  if (fields.length === 0) {return;}

  values.push(id);
  const stmt = db.prepare(`UPDATE predictions SET ${fields.join(", ")} WHERE id = ?`);
  return await stmt.run(...values);
}

export async function deletePrediction(id: number) {
  const db = getDb();
  return await db.prepare("DELETE FROM predictions WHERE id = ?").run(id);
}

export async function generatePrediction(params: any) {
  const asset = await getAssetById(params.assetId);
  if (!asset) {
    throw new Error("Asset not found");
  }

  const currentPrice = parseFloat((asset as any).currentPrice || "0");
  const randomChange = (Math.random() - 0.5) * 0.1; // ±5%
  const predictedPrice = (currentPrice * (1 + randomChange)).toFixed(2);

  const prediction = {
    assetId: params.assetId,
    userId: params.userId,
    modelType: params.modelType,
    horizon: params.horizon,
    predictedPrice: predictedPrice,
    confidenceLevel: params.confidenceLevel.toString(),
    predictionDate: Date.now(),
    accuracy: null,
    metadata: JSON.stringify({ generated: true }),
    createdAt: Date.now(),
  };

  return await insertPrediction(prediction);
}

export async function getPredictionHistory(params: any) {
  // Logic from db-sqlite (not seen but assuming simple select or filters)
  const db = getDb();
  let sql = "SELECT * FROM predictions WHERE 1=1";
  const p = [];
  if (params.userId) { sql += " AND userId = ?"; p.push(params.userId); }
  if (params.assetId) { sql += " AND assetId = ?"; p.push(params.assetId); }
  sql += " ORDER BY createdAt DESC LIMIT 50";
  return await db.prepare(sql).all(...p);
}

export async function getPredictionAccuracyComparison(input?: any) {
  const db = getDb();
  return await db.prepare(`
    SELECT
      modelType,
      COUNT(*) as totalPredictions,
      AVG(CAST(accuracy AS REAL)) as avgAccuracy,
      AVG(CAST(confidenceLevel AS REAL)) as avgConfidence
    FROM predictions
    WHERE accuracy IS NOT NULL
    GROUP BY modelType
  `).all();
}

// Alerts
export async function getAllAlerts() {
  try {
    const db = getDb();
    return await db.prepare("SELECT * FROM alerts ORDER BY createdAt DESC").all();
  } catch (error) {
    console.error("[Database] Error getting alerts:", error);
    return [];
  }
}

export async function getAlertsByUserId(userId: string) {
  const db = getDb();
  return await db.prepare("SELECT * FROM alerts WHERE userId = ? ORDER BY createdAt DESC").all(userId);
}

export async function getAlertsByAssetId(assetId: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM alerts WHERE assetId = ? ORDER BY createdAt DESC").all(assetId);
}

export async function insertAlert(alert: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO alerts (userId, assetId, alertType, condition, threshold, isActive, isTriggered, createdAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [
      alert.userId, alert.assetId, alert.alertType, alert.condition, alert.threshold,
      alert.isActive !== undefined ? (alert.isActive ? 1 : 0) : 1,
      alert.isTriggered !== undefined ? (alert.isTriggered ? 1 : 0) : 0,
      alert.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...alert }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO alerts (userId, assetId, alertType, condition, threshold, isActive, isTriggered, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    alert.userId,
    alert.assetId,
    alert.alertType,
    alert.condition,
    alert.threshold,
    alert.isActive !== undefined ? (alert.isActive ? 1 : 0) : 1,
    alert.isTriggered !== undefined ? (alert.isTriggered ? 1 : 0) : 0,
    alert.createdAt || Date.now()
  );

  return { id: result.lastInsertRowid, ...alert };
}

export async function updateAlert(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.isActive !== undefined) { fields.push("isActive = ?"); values.push(updates.isActive ? 1 : 0); }
  if (updates.isTriggered !== undefined) { fields.push("isTriggered = ?"); values.push(updates.isTriggered ? 1 : 0); }
  if (updates.threshold !== undefined) { fields.push("threshold = ?"); values.push(updates.threshold); }

  if (fields.length === 0) {return;}

  values.push(id);
  const stmt = db.prepare(`UPDATE alerts SET ${fields.join(", ")} WHERE id = ?`);
  return await stmt.run(...values);
}

export async function deleteAlert(id: number) {
  const db = getDb();
  return await db.prepare("DELETE FROM alerts WHERE id = ?").run(id);
}

export async function getAlertById(id: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM alerts WHERE id = ?").get(id);
}

export async function createAlert(alert: any) {
  return await insertAlert(alert);
}

export async function getUserAlerts(userId: string) {
  return await getAlertsByUserId(userId);
}

// Statistics
export async function getAssetCount() {
  const db = getDb();
  return await db.prepare("SELECT COUNT(*) as count FROM assets").get();
}

export async function getPredictionCount() {
  const db = getDb();
  return await db.prepare("SELECT COUNT(*) as count FROM predictions").get();
}

export async function getAlertCount() {
  const db = getDb();
  return await db.prepare("SELECT COUNT(*) as count FROM alerts").get();
}

export async function getActiveAlertCount() {
  const db = getDb();
  return await db.prepare("SELECT COUNT(*) as count FROM alerts WHERE isActive = 1").get();
}

// Admin User Management Functions
export async function getAllUsers() {
  const db = getDb();
  return await db.prepare(`
    SELECT id, name, email, role, loginMethod, createdAt, lastSignedIn
    FROM users
    ORDER BY createdAt DESC
  `).all();
}

export async function getUserByIdAdmin(userId: string) {
  const db = getDb();
  return await db.prepare(`
    SELECT id, name, email, role, loginMethod, createdAt, lastSignedIn
    FROM users
    WHERE id = ?
  `).get(userId);
}

export async function updateUserRole(userId: string, role: string) {
  const db = getDb();
  const stmt = db.prepare(`
    UPDATE users
    SET role = ?, updatedAt = ?
    WHERE id = ?
  `);
  return await stmt.run(role, Date.now(), userId);
}

export async function deleteUser(userId: string) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM users WHERE id = ?");
  return await stmt.run(userId);
}

// User Permissions Functions
export async function getUserPermissions(userId: string) {
  const db = getDb();
  return await db.prepare(`
    SELECT * FROM user_permissions
    WHERE userId = ?
  `).all(userId);
}

export async function createPermission(permission: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO user_permissions (userId, permission, createdAt)
      VALUES ($1, $2, $3)
      RETURNING id
    `, [permission.userId, permission.permission, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...permission }));
  }

  const stmt = db.prepare(`
    INSERT INTO user_permissions (userId, permission, createdAt)
    VALUES (?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(permission.userId, permission.permission, Date.now());
  return { id: result.lastInsertRowid, ...permission };
}

export async function updatePermission(id: number, permission: any) {
  const db = getDb();
  const stmt = db.prepare(`
    UPDATE user_permissions
    SET permission = ?, updatedAt = ?
    WHERE id = ?
  `);
  return await stmt.run(permission.permission, Date.now(), id);
}

export async function deletePermission(id: number) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM user_permissions WHERE id = ?");
  return await stmt.run(id);
}

export async function revokePermission(userId: string, permission: string) {
  const db = getDb();
  const stmt = db.prepare(
    "DELETE FROM user_permissions WHERE userId = ? AND permission = ?"
  );
  return await stmt.run(userId, permission);
}

export async function hasPermission(userId: string, permission: string) {
  const db = getDb();
  const result = await db
    .prepare(
      "SELECT * FROM user_permissions WHERE userId = ? AND permission = ?"
    )
    .get(userId, permission);
  return !!result;
}

// User Settings Functions
export async function getUserSettings(userId: string) {
  const db = getDb();
  const result = await db.prepare("SELECT * FROM user_settings WHERE userId = ?").get(userId);

  if (!result) {
    return {
      userId,
      emailEnabled: false,
      notifyPriceChanges: true,
      notifyAlerts: true,
      notifyPredictions: true,
      notifyReports: false,
      language: "ar",
      theme: "light",
      currency: "USD",
    };
  }

  return result;
}

export async function updateUserSettings(userId: string, settings: any) {
  const db = getDb();

  // Check if settings exist (reusing generic logic but Async)
  const existing = await db.prepare("SELECT userId FROM user_settings WHERE userId = ?").get(userId);

  if (existing) {
    const fields = Object.keys(settings).map(key => `${key} = ?`).join(", ");
    const values = [...Object.values(settings), userId];

    const stmt = db.prepare(`UPDATE user_settings SET ${fields}, updatedAt = ? WHERE userId = ?`);
    return await stmt.run(...values, Date.now(), userId);
  } else {
    // Insert
    const keys = Object.keys(settings);
    const placeholders = keys.map(() => usePostgres ? `$${keys.indexOf(keys.find(k=>k)!)+2}` : "?").join(", "); 
    // Wait, dynamic placeholders for Postgres ($1, $2...) vs SQLite (?)
    // If I use db.prepare (shim), `?` is converted to `$1`.
    // So I can use `?`.
    
    const stmt = db.prepare(`
      INSERT INTO user_settings (userId, ${keys.join(", ")}, createdAt, updatedAt)
      VALUES (?, ${keys.map(() => "?").join(", ")}, ?, ?)
    `);
    return await stmt.run(userId, ...Object.values(settings), Date.now(), Date.now());
  }
}

export async function resetUserSettings(userId: string) {
  const db = getDb();
  const stmt = db.prepare("DELETE FROM user_settings WHERE userId = ?");
  return await stmt.run(userId);
}

// Reports Generation Functions
export async function generatePortfolioReport(userId: string, params: any) {
  const db = getDb();
  const { portfolioId, startDate, endDate } = params;

  try {
    // Compatibility check for table existence
    let tableExists = false;
    if (usePostgres) {
        const res: any = await dbPostgres.query("SELECT table_name FROM information_schema.tables WHERE table_name = 'portfolios'");
        tableExists = res.rowCount > 0;
    } else {
        const res = await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolios'").get();
        tableExists = !!res;
    }

    if (!tableExists) {
      console.warn("[Reports] Portfolios table does not exist");
      return {
        summary: { totalPortfolios: 0, totalAssets: 0, totalInvested: 0, totalReturns: 0 },
        portfolios: [],
        message: "لا توجد محافظ متاحة",
      };
    }
  } catch (error) {
    console.error("[Reports] Error checking portfolios table:", error);
    return {
      summary: { totalPortfolios: 0, totalAssets: 0, totalInvested: 0, totalReturns: 0 },
      portfolios: [],
      message: "خطأ في قاعدة البيانات",
    };
  }

  let query = `
    SELECT
      p.id as portfolioId,
      p.name as portfolioName,
      COUNT(DISTINCT t.assetId) as totalAssets,
      COALESCE(SUM(CASE WHEN t.transactionType = 'buy' THEN t.totalAmount ELSE 0 END), 0) as totalInvested,
      COALESCE(SUM(CASE WHEN t.transactionType = 'sell' THEN t.totalAmount ELSE 0 END), 0) as totalReturns
    FROM portfolios p
    LEFT JOIN transactions t ON p.id = t.portfolioId
    WHERE p.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (portfolioId) { query += " AND p.id = ?"; queryParams.push(portfolioId); }
  if (startDate) { query += " AND t.transactionDate >= ?"; queryParams.push(startDate); }
  if (endDate) { query += " AND t.transactionDate <= ?"; queryParams.push(endDate); }

  query += " GROUP BY p.id";

  const portfolios = await db.prepare(query).all(...queryParams) as any[];
  
  const summary = {
    totalPortfolios: portfolios.length,
    totalAssets: portfolios.reduce((sum, p) => sum + (p.totalAssets || 0), 0),
    totalInvested: portfolios.reduce((sum, p) => sum + (p.totalInvested || 0), 0),
    totalReturns: portfolios.reduce((sum, p) => sum + (p.totalReturns || 0), 0),
  };

  return { summary, portfolios, generatedAt: new Date().toISOString() };
}

export async function generateAccuracyReport(userId: string, params: any) {
  const db = getDb();
  const { assetId, modelType, startDate, endDate } = params;

  let query = `
    SELECT
      p.modelType,
      p.assetId,
      a.symbol,
      a.name as assetName,
      COUNT(*) as totalPredictions,
      COALESCE(AVG(CAST(p.accuracy AS REAL)), 0) as avgAccuracy,
      COALESCE(AVG(CAST(p.confidenceLevel AS REAL)), 0) as avgConfidence,
      COALESCE(MIN(CAST(p.accuracy AS REAL)), 0) as minAccuracy,
      COALESCE(MAX(CAST(p.accuracy AS REAL)), 0) as maxAccuracy
    FROM predictions p
    LEFT JOIN assets a ON p.assetId = a.id
    WHERE p.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (assetId) { query += " AND p.assetId = ?"; queryParams.push(assetId); }
  if (modelType) { query += " AND p.modelType = ?"; queryParams.push(modelType); }
  if (startDate) { query += " AND p.createdAt >= ?"; queryParams.push(new Date(startDate).getTime()); }
  if (endDate) { query += " AND p.createdAt <= ?"; queryParams.push(new Date(endDate).getTime()); }

  query += " GROUP BY p.modelType, p.assetId";

  const results = await db.prepare(query).all(...queryParams) as any[];
  
  return {
    summary: {
      totalPredictions: results.reduce((sum, r) => sum + (r.totalPredictions || 0), 0),
      avgAccuracy: results.length > 0 ? results.reduce((sum, r) => sum + (r.avgAccuracy || 0), 0) / results.length : 0,
      avgConfidence: results.length > 0 ? results.reduce((sum, r) => sum + (r.avgConfidence || 0), 0) / results.length : 0,
    },
    details: results,
    generatedAt: new Date().toISOString(),
  };
}

export async function generateAlertsReport(userId: string, params: any) {
  const db = getDb();
  const { startDate, endDate, status } = params;

  let query = `
    SELECT
      a.*,
      ast.symbol,
      ast.name as assetName
    FROM alerts a
    LEFT JOIN assets ast ON a.assetId = ast.id
    WHERE a.userId = ?
  `;

  const queryParams: any[] = [userId];

  if (status && status !== "all") {
    if (status === "triggered") { query += " AND a.isTriggered = 1"; }
    else if (status === "active") { query += " AND a.isActive = 1 AND a.isTriggered = 0"; }
    else if (status === "inactive") { query += " AND a.isActive = 0"; }
  }

  if (startDate) { query += " AND a.createdAt >= ?"; queryParams.push(new Date(startDate).getTime()); }
  if (endDate) { query += " AND a.createdAt <= ?"; queryParams.push(new Date(endDate).getTime()); }

  query += " ORDER BY a.createdAt DESC";

  const alerts = await db.prepare(query).all(...queryParams) as any[];
  
  const summary = {
    total: alerts.length,
    triggered: alerts.filter(a => a.isTriggered).length,
    active: alerts.filter(a => a.isActive && !a.isTriggered).length,
    inactive: alerts.filter(a => !a.isActive).length,
  };

  return { summary, alerts, generatedAt: new Date().toISOString() };
}

export async function generatePriceHistoryReport(params: any) {
  const db = getDb();
  const { assetId, startDate, endDate, interval = "daily" } = params;

  let query = `
    SELECT hp.*, a.symbol, a.name as assetName
    FROM historical_prices hp
    JOIN assets a ON hp.assetId = a.id
    WHERE hp.assetId = ?
  `;

  const queryParams: any[] = [assetId];

  if (startDate) { query += " AND hp.timestamp >= ?"; queryParams.push(new Date(startDate).getTime()); }
  if (endDate) { query += " AND hp.timestamp <= ?"; queryParams.push(new Date(endDate).getTime()); }

  query += " ORDER BY hp.timestamp ASC";

  return await db.prepare(query).all(...queryParams);
}

export function convertToCSV(data: any[]) {
    if (!data || data.length === 0) {return "";}
  
    const headers = Object.keys(data[0]);
    const rows = data.map(row =>
      headers.map(header => {
          const value = row[header];
          if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        })
        .join(",")
    );
  
    return [headers.join(","), ...rows].join("\n");
}

export async function getReportHistory(userId: string, limit: number, offset: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM saved_reports WHERE userId = ? ORDER BY createdAt DESC LIMIT ? OFFSET ?").all(userId, limit, offset);
}

export async function saveReport(userId: string, report: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO saved_reports (userId, reportType, title, description, data, createdAt)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [userId, report.reportType, report.title, report.description || null, JSON.stringify(report.data), Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...report }));
  }

  const stmt = db.prepare(`
    INSERT INTO saved_reports (userId, reportType, title, description, data, createdAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const result: any = await stmt.run(userId, report.reportType, report.title, report.description || null, JSON.stringify(report.data), Date.now());
  return { id: result.lastInsertRowid, ...report };
}

export async function deleteReport(reportId: number, userId: string) {
  const db = getDb();
  return await db.prepare("DELETE FROM saved_reports WHERE id = ? AND userId = ?").run(reportId, userId);
}

// Admin Functions
// Duplicate getSystemStats removed (use newer version at end of file)


export async function getAllUsersAdmin(params: any) {
  const db = getDb();
  const { limit, offset, search, role } = params;

  let query = "SELECT * FROM users WHERE 1=1";
  const queryParams: any[] = [];

  if (search) {
    query += " AND (name LIKE ? OR email LIKE ?)";
    queryParams.push(`%${search}%`, `%${search}%`);
  }

  if (role && role !== "all") {
    query += " AND role = ?";
    queryParams.push(role);
  }

  query += " ORDER BY createdAt DESC LIMIT ? OFFSET ?";
  queryParams.push(limit, offset);

  return await db.prepare(query).all(...queryParams);
}

export async function updateUserAdmin(userId: string, updates: any) {
  const db = getDb();
  const fields = Object.keys(updates).map(key => `${key} = ?`).join(", ");
  const values = [...Object.values(updates), userId];

  const stmt = db.prepare(`UPDATE users SET ${fields} WHERE id = ?`);
  return await stmt.run(...values);
}

export async function getUserStats() {
  const db = getDb();
  const total = (await db.prepare("SELECT COUNT(*) as count FROM users").get() as any).count;
  const admins = (await db.prepare('SELECT COUNT(*) as count FROM users WHERE role = "admin"').get() as any).count;
  const active = (await db.prepare("SELECT COUNT(*) as count FROM users WHERE \"lastSignedIn\" > ?").get(Date.now() - 30 * 24 * 60 * 60 * 1000) as any).count;

  return { total, admins, active };
}

export async function getAllAssetsAdmin() {
  const db = getDb();
  return await db.prepare("SELECT * FROM assets ORDER BY \"createdAt\" DESC").all();
}

export async function createAssetAdmin(asset: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO assets (symbol, name, type, description, "createdAt", "updatedAt")
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [asset.symbol, asset.name, asset.type, asset.description || null, Date.now(), Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...asset }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO assets (symbol, name, type, description, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(asset.symbol, asset.name, asset.type, asset.description || null, Date.now(), Date.now());
  return { id: result.lastInsertRowid, ...asset };
}

export async function updateAssetAdmin(id: number, updates: any) {
  const db = getDb();
  const fields = Object.keys(updates).map(key => `${key} = ?`).join(", ");
  const values = [...Object.values(updates), Date.now(), id];

  const stmt = db.prepare(`UPDATE assets SET ${fields}, "updatedAt" = ? WHERE id = ?`);
  return await stmt.run(...values);
}

export async function deleteAssetAdmin(id: number) {
  const db = getDb();
  return await db.prepare("DELETE FROM assets WHERE id = ?").run(id);
}

export async function getSystemLogs(params: any) {
  const db = getDb();
  const { limit, offset, level, startDate, endDate } = params;

  let query = "SELECT * FROM system_logs WHERE 1=1";
  const queryParams: any[] = [];

  if (level && level !== "all") { query += " AND level = ?"; queryParams.push(level); }
  if (startDate) { query += " AND timestamp >= ?"; queryParams.push(new Date(startDate).getTime()); }
  if (endDate) { query += " AND timestamp <= ?"; queryParams.push(new Date(endDate).getTime()); }

  query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?";
  queryParams.push(limit, offset);

  return await db.prepare(query).all(...queryParams);
}

export async function clearSystemLogs(olderThan?: string) {
  const db = getDb();
  if (olderThan) {
    const stmt = db.prepare("DELETE FROM system_logs WHERE timestamp < ?");
    return await stmt.run(new Date(olderThan).getTime());
  } else {
    const stmt = db.prepare("DELETE FROM system_logs");
    return await stmt.run();
  }
}

export async function getDatabaseStats() {
  const db = getDb();
  const tables = ["users", "assets", "predictions", "alerts", "portfolios", "transactions", "historical_prices"];
  const stats: any = {};

  for (const table of tables) {
     try {
         // Postgres check or unified?
         // On postgres, table might not exist in public schema if not created?
         // db.prepare works.
         const res = await db.prepare(`SELECT COUNT(*) as count FROM ${table}`).get() as any;
         stats[table] = res ? res.count : 0;
     } catch(e) {
         stats[table] = 0;
     }
  }
  return stats;
}

export async function createDatabaseBackup() {
  return { success: true, backupPath: `/backups/db_${Date.now()}.sqlite`, timestamp: Date.now() };
}

export async function optimizeDatabase() {
  if (usePostgres) { return { success: true, timestamp: Date.now() }; }
  const db = getDb();
  // @ts-ignore
  await db.prepare("VACUUM").run();
  // @ts-ignore
  await db.prepare("ANALYZE").run();
  return { success: true, timestamp: Date.now() };
}

export async function getSystemConfig() {
  const db = getDb();
  return await db.prepare("SELECT * FROM system_config").all();
}

export async function updateSystemConfig(key: string, value: any) {
  const db = getDb();
  const valueStr = JSON.stringify(value);
  
  if (usePostgres) {
      // Postgres Upsert
      return dbPostgres.query(`
        INSERT INTO system_config (key, value, "updatedAt") VALUES ($1, $2, $3)
        ON CONFLICT(key) DO UPDATE SET value = $4, "updatedAt" = $5
      `, [key, valueStr, Date.now(), valueStr, Date.now()]);
  }

  const stmt = db.prepare(`
    INSERT INTO system_config (key, value, updatedAt)
    VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET value = ?, updatedAt = ?
  `);
  return await stmt.run(key, valueStr, Date.now(), valueStr, Date.now());
}

// Additional functions for routers.ts
export async function getHistoricalPrices(assetId: number, limit: number = 100) {
  return await getHistoricalPricesByAssetId(assetId, limit);
}

export async function getHistoricalPricesByAsset(assetId: number, limit: number = 100) {
  return await getHistoricalPricesByAssetId(assetId, limit);
}

export async function getLatestPrice(assetId: number): Promise<any> {
  const db = getDb();
  if (usePostgres) {
     return dbPostgres.query("SELECT * FROM historical_prices WHERE \"assetId\" = $1 ORDER BY timestamp DESC LIMIT 1", [assetId])
        .then((res: any) => res.rows[0]);
  }
  return await db.prepare("SELECT * FROM historical_prices WHERE assetId = ? ORDER BY timestamp DESC LIMIT 1").get(assetId);
}

// Trading Placeholders
export async function calculateTradingSignals(assetId: number) { return []; }
export async function createTradingSignal(signal: any) { return { id: Date.now(), ...signal }; }
export async function getTradingSignals(assetId: number) { return []; }
export async function calculateBreakoutPoints(assetId: number) { return []; }
export async function createBreakoutPoint(point: any) { return { id: Date.now(), ...point }; }
export async function getBreakoutPoints(assetId: number) { return []; }
export async function createBreakEvenPoint(point: any) { return { id: Date.now(), ...point }; }
export async function getBreakEvenPoints(assetId: number) { return []; }
export async function deleteBreakEvenPoint(id: number) { return true; }
export async function calculateInflectionPoints(assetId: number) { return []; }
export async function createInflectionPoint(point: any) { return { id: Date.now(), ...point }; }
export async function getInflectionPoints(assetId: number) { return []; }
export async function getModelPerformance(assetId: number) { return { accuracy: 0, precision: 0, recall: 0 }; }
export async function getAccuracyHistory(assetId: number, days: number) { return []; }

// Notifications moved to Comprehensive block


export async function createNotification(data: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO notifications (userId, title, message, type, "isRead", "createdAt")
      VALUES ($1, $2, $3, $4, 0, $5)
      RETURNING id
    `, [data.userId, data.title, data.message, data.type || 'info', Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...data }));
  }
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO notifications (userId, title, message, type, isRead, createdAt)
    VALUES (?, ?, ?, ?, 0, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(data.userId, data.title, data.message, data.type || 'info', Date.now());
  return { id: result.lastInsertRowid, ...data };
}



// Trading Signals (Real DB)
export async function getAssetTradingSignals(assetId: number, limit: number = 50) {
  const db = getDb();
  return await db.prepare("SELECT * FROM trading_signals WHERE assetId = ? AND (validUntil IS NULL OR validUntil > ?) ORDER BY createdAt DESC LIMIT ?").all(assetId, Date.now(), limit);
}

export async function createTradingSignalDb(signal: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO trading_signals (assetId, signalType, strength, price, targetPrice, stopLoss, confidence, validUntil, createdAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [signal.assetId, signal.signalType, signal.strength || 'moderate', signal.price, signal.targetPrice || null, signal.stopLoss || null, signal.confidence || 0.5, signal.validUntil || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...signal }));
  }

  const stmt = db.prepare(`
    INSERT INTO trading_signals (assetId, signalType, strength, price, targetPrice, stopLoss, confidence, validUntil, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(signal.assetId, signal.signalType, signal.strength || 'moderate', signal.price, signal.targetPrice || null, signal.stopLoss || null, signal.confidence || 0.5, signal.validUntil || null, Date.now());
  return { id: result.lastInsertRowid, ...signal };
}

// Technical Indicators
export async function getAssetTechnicalIndicators(assetId: number, indicatorType?: string) {
  const db = getDb();
  if (indicatorType) {
    return await db.prepare("SELECT * FROM technical_indicators WHERE assetId = ? AND indicatorType = ? ORDER BY calculatedAt DESC LIMIT 1").get(assetId, indicatorType);
  }
  return await db.prepare("SELECT * FROM technical_indicators WHERE assetId = ? ORDER BY calculatedAt DESC").all(assetId);
}

export async function saveTechnicalIndicator(indicator: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO technical_indicators (assetId, indicatorType, value, period, calculatedAt)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id
    `, [indicator.assetId, indicator.indicatorType, indicator.value, indicator.period || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...indicator }));
  }

  const stmt = db.prepare(`
    INSERT INTO technical_indicators (assetId, indicatorType, value, period, calculatedAt)
    VALUES (?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(indicator.assetId, indicator.indicatorType, indicator.value, indicator.period || null, Date.now());
  return { id: result.lastInsertRowid, ...indicator };
}

// Model Performance
export async function getModelPerformanceHistory(modelType?: string, limit: number = 50) {
  const db = getDb();
  if (modelType) {
    return await db.prepare("SELECT * FROM model_performance WHERE modelType = ? ORDER BY evaluatedAt DESC LIMIT ?").all(modelType, limit);
  }
  return await db.prepare("SELECT * FROM model_performance ORDER BY evaluatedAt DESC LIMIT ?").all(limit);
}

export async function saveModelPerformance(performance: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO model_performance (modelType, accuracy, mae, rmse, mape, evaluatedAt)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [performance.modelType, performance.accuracy || null, performance.mae || null, performance.rmse || null, performance.mape || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...performance }));
  }

  const stmt = db.prepare(`
    INSERT INTO model_performance (modelType, accuracy, mae, rmse, mape, evaluatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(performance.modelType, performance.accuracy || null, performance.mae || null, performance.rmse || null, performance.mape || null, Date.now());
  return { id: result.lastInsertRowid, ...performance };
}

// AI Conversations
// Duplicate getAIConversations removed (use newer version at end of file)


export async function createAIConversation(conversation: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO ai_conversations (userId, assistantType, messages, tokensUsed, createdAt)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id
    `, [conversation.userId, conversation.assistantType || 'general', conversation.messages, conversation.tokensUsed || 0, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...conversation }));
  }

  const stmt = db.prepare(`
    INSERT INTO ai_conversations (userId, assistantType, messages, tokensUsed, createdAt)
    VALUES (?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(conversation.userId, conversation.assistantType || 'general', conversation.messages, conversation.tokensUsed || 0, Date.now());
  return { id: result.lastInsertRowid, ...conversation };
}

export async function updateAIConversation(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.messages) { fields.push("messages = ?"); values.push(updates.messages); }
  if (updates.tokensUsed !== undefined) { fields.push("tokensUsed = ?"); values.push(updates.tokensUsed); }
  
  fields.push("updatedAt = ?");
  values.push(Date.now());
  values.push(id);

  const stmt = db.prepare(`UPDATE ai_conversations SET ${fields.join(", ")} WHERE id = ?`);
  return await stmt.run(...values);
}

// AI Memories
export async function getAIMemories(userId: string, type?: string, limit: number = 50) {
  const db = getDb();
  if (type) {
    return await db.prepare("SELECT * FROM ai_memories WHERE userId = ? AND type = ? ORDER BY relevanceScore DESC LIMIT ?").all(userId, type, limit);
  }
  return await db.prepare("SELECT * FROM ai_memories WHERE userId = ? ORDER BY relevanceScore DESC LIMIT ?").all(userId, limit);
}

export async function createAIMemory(memory: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO ai_memories (userId, type, content, keywords, relevanceScore, createdAt)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [memory.userId, memory.type || 'fact', memory.content, memory.keywords || null, memory.relevanceScore || 1.0, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...memory }));
  }

  const stmt = db.prepare(`
    INSERT INTO ai_memories (userId, type, content, keywords, relevanceScore, createdAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(memory.userId, memory.type || 'fact', memory.content, memory.keywords || null, memory.relevanceScore || 1.0, Date.now());
  return { id: result.lastInsertRowid, ...memory };
}

export async function deleteAIMemory(id: number, userId: string) {
  const db = getDb();
  return await db.prepare("DELETE FROM ai_memories WHERE id = ? AND userId = ?").run(id, userId);
}

export async function searchAIMemories(userId: string, searchTerm: string, limit: number = 10) {
  const db = getDb();
  return await db.prepare(`
    SELECT * FROM ai_memories
    WHERE userId = ? AND (content LIKE ? OR keywords LIKE ?)
    ORDER BY relevanceScore DESC
    LIMIT ?
  `).all(userId, `%${searchTerm}%`, `%${searchTerm}%`, limit);
}



// Logging Functions
export async function logErrorDb(data: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO error_logs (level, source, component, message, stack, userId, metadata, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [data.level, data.source, data.component, data.message, data.stack || null, data.userId || null, data.metadata || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...data }));
  }
  const stmt = db.prepare(`
    INSERT INTO error_logs (level, source, component, message, stack, userId, metadata, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(data.level, data.source, data.component, data.message, data.stack || null, data.userId || null, data.metadata || null, Date.now());
  return { id: result.lastInsertRowid, ...data };
}

export async function logMLTrainingDb(data: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO ml_training_logs (assetId, modelType, trainingDuration, trainScore, testScore, mape, hyperparameters, datasetSize, status, errorMessage, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [data.assetId, data.modelType, data.trainingDuration || 0, data.trainScore, data.testScore, data.mape, data.hyperparameters, data.datasetSize || 0, data.status, data.errorMessage || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...data }));
  }
  const stmt = db.prepare(`
    INSERT INTO ml_training_logs (assetId, modelType, trainingDuration, trainScore, testScore, mape, hyperparameters, datasetSize, status, errorMessage, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(data.assetId, data.modelType, data.trainingDuration || 0, data.trainScore, data.testScore, data.mape, data.hyperparameters, data.datasetSize || 0, data.status, data.errorMessage || null, Date.now());
  return { id: result.lastInsertRowid, ...data };
}

export async function logPredictionDb(data: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO prediction_logs (predictionId, assetId, modelType, inputData, outputData, executionTime, userId, status, errorMessage, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `, [data.predictionId || null, data.assetId, data.modelType, data.inputData, data.outputData, data.executionTime || 0, data.userId || null, data.status, data.errorMessage || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...data }));
  }
  const stmt = db.prepare(`
    INSERT INTO prediction_logs (predictionId, assetId, modelType, inputData, outputData, executionTime, userId, status, errorMessage, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(data.predictionId || null, data.assetId, data.modelType, data.inputData, data.outputData, data.executionTime || 0, data.userId || null, data.status, data.errorMessage || null, Date.now());
  return { id: result.lastInsertRowid, ...data };
}

export async function logAPIRequestDb(data: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO api_request_logs (method, endpoint, userId, statusCode, responseTime, ipAddress, userAgent, errorMessage, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [data.method, data.endpoint, data.userId || null, data.statusCode, data.responseTime, data.ipAddress || null, data.userAgent || null, data.errorMessage || null, Date.now()])
    .then((res: any) => ({ id: res.rows[0].id, ...data }));
  }
  const stmt = db.prepare(`
    INSERT INTO api_request_logs (method, endpoint, userId, statusCode, responseTime, ipAddress, userAgent, errorMessage, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const result = await stmt.run(data.method, data.endpoint, data.userId || null, data.statusCode, data.responseTime, data.ipAddress || null, data.userAgent || null, data.errorMessage || null, Date.now());
  return { id: result.lastInsertRowid, ...data };
}

export async function getRecentErrors(limit: number = 50) {
  const db = getDb();
  return await db.prepare("SELECT * FROM error_logs ORDER BY timestamp DESC LIMIT ?").all(limit);
}

export async function getMLTrainingHistory(assetId?: number, limit: number = 50) {
  const db = getDb();
  if (assetId) {
    return await db.prepare("SELECT * FROM ml_training_logs WHERE assetId = ? ORDER BY timestamp DESC LIMIT ?").all(assetId, limit);
  }
  return await db.prepare("SELECT * FROM ml_training_logs ORDER BY timestamp DESC LIMIT ?").all(limit);
}

export async function getPredictionLogs(userId?: string, limit: number = 50) {
  const db = getDb();
  if (userId) {
    return await db.prepare("SELECT * FROM prediction_logs WHERE userId = ? ORDER BY timestamp DESC LIMIT ?").all(userId, limit);
  }
  return await db.prepare("SELECT * FROM prediction_logs ORDER BY timestamp DESC LIMIT ?").all(limit);
}

export async function getAPIStats(hours: number = 24) {
  const db = getDb();
  const cutoff = Date.now() - (hours * 60 * 60 * 1000);
  const logs: any[] = await db.prepare("SELECT * FROM api_request_logs WHERE timestamp >= ?").all(cutoff);
  
  const total = logs.length;
  const success = logs.filter(l => l.statusCode >= 200 && l.statusCode < 300).length;
  const failed = logs.filter(l => l.statusCode >= 400).length;
  const avgTime = total > 0 ? logs.reduce((sum, l) => sum + (l.responseTime || 0), 0) / total : 0;

  return {
    totalRequests: total,
    successfulRequests: success,
    failedRequests: failed,
    successRate: total > 0 ? (success / total) * 100 : 0,
    avgResponseTime: Math.round(avgTime)
  };
}

// ----------------------------------------------------------------------
// Learning System Extensions
// ----------------------------------------------------------------------

// Predictions (Filtered)
export async function getPredictions(filters?: {
  assetId?: number;
  limit?: number;
  offset?: number;
}) {
  const db = getDb();
  let sql = "SELECT * FROM predictions WHERE 1=1";
  const params: any[] = [];

  if (filters?.assetId) {
    sql += " AND assetId = ?";
    params.push(filters.assetId);
  }

  sql += " ORDER BY createdAt DESC";

  if (filters?.limit) {
    sql += " LIMIT ?";
    params.push(filters.limit);
  }
  if (filters?.offset) {
    sql += " OFFSET ?";
    params.push(filters.offset);
  }

  return await db.prepare(sql).all(...params);
}

// Prediction Comparisons
export async function getAllComparisons(filters?: {
  predictionId?: number;
  minAccuracy?: number;
  maxAccuracy?: number;
  withinConfidence?: boolean;
  limit?: number;
  offset?: number;
}) {
  const db = getDb();
  let sql = "SELECT * FROM prediction_comparisons WHERE 1=1";
  const params: any[] = [];

  if (filters?.predictionId) {
    sql += " AND predictionId = ?";
    params.push(filters.predictionId);
  }
  if (filters?.withinConfidence !== undefined) {
    sql += " AND withinConfidence = ?";
    params.push(filters.withinConfidence ? 1 : 0);
  }
  if (filters?.minAccuracy !== undefined) {
    sql += " AND accuracy >= ?";
    params.push(filters.minAccuracy);
  }
  if (filters?.maxAccuracy !== undefined) {
    sql += " AND accuracy <= ?";
    params.push(filters.maxAccuracy);
  }

  sql += " ORDER BY comparedAt DESC";

  if (filters?.limit) {
    sql += " LIMIT ?";
    params.push(filters.limit);
  }
  if (filters?.offset) {
    sql += " OFFSET ?";
    params.push(filters.offset);
  }

  return await db.prepare(sql).all(...params);
}

export async function getComparisonById(id: number): Promise<any> {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM prediction_comparisons WHERE id = $1", [id]).then((res: any) => res.rows[0]);
  }
  return await db.prepare("SELECT * FROM prediction_comparisons WHERE id = ?").get(id);
}

export async function getComparisonByPredictionId(predictionId: number): Promise<any> {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM prediction_comparisons WHERE \"prediction_id\" = $1 LIMIT 1", [predictionId]).then((res: any) => res.rows[0]);
  }
  return await db.prepare("SELECT * FROM prediction_comparisons WHERE predictionId = ? LIMIT 1").get(predictionId);
}

export async function createComparison(data: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO prediction_comparisons (predictionId, actualPrice, predictedPrice, error, errorPercent, accuracy, withinConfidence, modelVersion, comparedAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [
      data.predictionId, data.actualPrice, data.predictedPrice, data.error, data.errorPercent,
      data.accuracy, data.withinConfidence ? 1 : 0, data.modelVersion || null, data.comparedAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...data }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO prediction_comparisons (predictionId, actualPrice, predictedPrice, error, errorPercent, accuracy, withinConfidence, modelVersion, comparedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    data.predictionId, data.actualPrice, data.predictedPrice, data.error, data.errorPercent,
    data.accuracy, data.withinConfidence ? 1 : 0, data.modelVersion || null, data.comparedAt || Date.now()
  );

  return { id: result.lastInsertRowid, ...data };
}

export async function updateComparison(id: number, updates: any) {
  const db = getDb();
  const fields = [];
  const values = [];

  if (updates.actualPrice) { fields.push("actualPrice = ?"); values.push(updates.actualPrice); }
  if (updates.predictedPrice) { fields.push("predictedPrice = ?"); values.push(updates.predictedPrice); }
  if (updates.error) { fields.push("error = ?"); values.push(updates.error); }
  if (updates.errorPercent) { fields.push("errorPercent = ?"); values.push(updates.errorPercent); }
  if (updates.accuracy) { fields.push("accuracy = ?"); values.push(updates.accuracy); }
  if (updates.withinConfidence !== undefined) { fields.push("withinConfidence = ?"); values.push(updates.withinConfidence ? 1 : 0); }
  
  fields.push("comparedAt = ?");
  values.push(Date.now());

  if (fields.length === 1) {return;}

  values.push(id);
  const stmt = db.prepare(`UPDATE prediction_comparisons SET ${fields.join(", ")} WHERE id = ?`);
  return await stmt.run(...values);
}

// Learning Insights
export async function getAllInsights(filters?: {
  type?: string;
  status?: string;
  impact?: string;
  limit?: number;
  offset?: number;
}) {
  const db = getDb();
  let sql = "SELECT * FROM learning_insights WHERE 1=1";
  const params: any[] = [];

  if (filters?.type) {
    sql += " AND type = ?";
    params.push(filters.type);
  }
  if (filters?.status) {
    sql += " AND status = ?";
    params.push(filters.status);
  }
  if (filters?.impact) {
    sql += " AND impact = ?";
    params.push(filters.impact);
  }

  sql += " ORDER BY createdAt DESC";

  if (filters?.limit) {
    sql += " LIMIT ?";
    params.push(filters.limit);
  }
  if (filters?.offset) {
    sql += " OFFSET ?";
    params.push(filters.offset);
  }

  return await db.prepare(sql).all(...params);
}

export async function getInsightById(id: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM learning_insights WHERE id = ?").get(id);
}

export async function createInsight(data: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO learning_insights (type, title, description, confidence, impact, data, relatedPredictions, relatedEvents, status, createdAt, updatedAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [
      data.type, data.title, data.description || null, data.confidence || null, data.impact || "medium",
      data.data ? JSON.stringify(data.data) : null, 
      data.relatedPredictions ? JSON.stringify(data.relatedPredictions) : null,
      data.relatedEvents ? JSON.stringify(data.relatedEvents) : null,
      data.status || "pending", data.createdAt || Date.now(), data.updatedAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...data }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO learning_insights (type, title, description, confidence, impact, data, relatedPredictions, relatedEvents, status, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    data.type, data.title, data.description || null, data.confidence || null, data.impact || "medium",
    data.data ? JSON.stringify(data.data) : null, 
    data.relatedPredictions ? JSON.stringify(data.relatedPredictions) : null,
    data.relatedEvents ? JSON.stringify(data.relatedEvents) : null,
    data.status || "pending", data.createdAt || Date.now(), data.updatedAt || Date.now()
  );

  return { id: result.lastInsertRowid, ...data };
}

export async function updateInsightStatus(id: number, status: string, reviewedBy?: string) {
  const db = getDb();
  const updates: string[] = ["status = ?", "updatedAt = ?"];
  const params: any[] = [status, Date.now()];

  if (reviewedBy) {
    updates.push("reviewedBy = ?");
    params.push(reviewedBy);
    updates.push("reviewedAt = ?");
    params.push(Date.now());
  }

  params.push(id);
  const stmt = db.prepare(`UPDATE learning_insights SET ${updates.join(", ")} WHERE id = ?`);
  await stmt.run(...params);
  return getInsightById(id);
}

// Model Adjustments
export async function getAllAdjustments(filters?: {
  insightId?: number;
  status?: string;
  adjustmentType?: string;
  limit?: number;
  offset?: number;
}) {
  const db = getDb();
  let sql = "SELECT * FROM model_adjustments WHERE 1=1";
  const params: any[] = [];

  if (filters?.insightId) {
    sql += " AND insightId = ?";
    params.push(filters.insightId);
  }
  if (filters?.status) {
    sql += " AND status = ?";
    params.push(filters.status);
  }
  if (filters?.adjustmentType) {
    sql += " AND adjustmentType = ?";
    params.push(filters.adjustmentType);
  }

  sql += " ORDER BY createdAt DESC";

  if (filters?.limit) {
    sql += " LIMIT ?";
    params.push(filters.limit);
  }
  if (filters?.offset) {
    sql += " OFFSET ?";
    params.push(filters.offset);
  }

  return await db.prepare(sql).all(...params);
}

export async function getAdjustmentById(id: number) {
  const db = getDb();
  return await db.prepare("SELECT * FROM model_adjustments WHERE id = ?").get(id);
}

export async function createAdjustment(data: any) {
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO model_adjustments (insightId, adjustmentType, description, parameters, modelVersion, previousVersion, status, performanceBefore, createdAt, updatedAt)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `, [
      data.insightId, data.adjustmentType, data.description || null, 
      data.parameters ? JSON.stringify(data.parameters) : null,
      data.modelVersion || null, data.previousVersion || null, data.status || "proposed",
      data.performanceBefore ? JSON.stringify(data.performanceBefore) : null,
      data.createdAt || Date.now(), data.updatedAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...data }));
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO model_adjustments (insightId, adjustmentType, description, parameters, modelVersion, previousVersion, status, performanceBefore, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // @ts-ignore
  const result = await stmt.run(
    data.insightId, data.adjustmentType, data.description || null, 
    data.parameters ? JSON.stringify(data.parameters) : null,
    data.modelVersion || null, data.previousVersion || null, data.status || "proposed",
    data.performanceBefore ? JSON.stringify(data.performanceBefore) : null,
    data.createdAt || Date.now(), data.updatedAt || Date.now()
  );

  return { id: result.lastInsertRowid, ...data };
}

export async function updateAdjustmentStatus(id: number, status: string, appliedBy?: string, performanceAfter?: any, revertedBy?: string) {
  const db = getDb();
  const updates: string[] = ["status = ?", "updatedAt = ?"];
  const params: any[] = [status, Date.now()];

  if (appliedBy) {
    updates.push("appliedBy = ?");
    params.push(appliedBy);
    updates.push("appliedAt = ?");
    params.push(Date.now());
  }
  if (performanceAfter) {
    updates.push("performanceAfter = ?");
    params.push(JSON.stringify(performanceAfter));
  }
  if (revertedBy) {
    updates.push("revertedBy = ?");
    params.push(revertedBy);
    updates.push("revertedAt = ?");
    params.push(Date.now());
  }

  params.push(id);
  const stmt = db.prepare(`UPDATE model_adjustments SET ${updates.join(", ")} WHERE id = ?`);
  await stmt.run(...params);
  return getAdjustmentById(id);
}

export async function applyAdjustmentWithInsight(id: number, appliedBy: string, performanceAfter?: any) {
  // Note: Cross-DB transaction abstraction is hard.
  // We will execute sequentially for now, or implement specific logic.
  // For SQLite/Postgres we could technically use BEGIN/COMMIT but we are hiding the db object.
  
  // Sequential execution (Atomic enough for this context)
  const adjustment = await updateAdjustmentStatus(id, "applied", appliedBy, performanceAfter);
  
  if (adjustment && (adjustment as any).insightId) {
     await updateInsightStatus((adjustment as any).insightId, "applied", appliedBy);
  }
  
  return adjustment;
}

export async function createPredictionWithComparison(predictionData: any, actualPrice: string) {
  // 1. Create prediction
  const prediction = await insertPrediction(predictionData);
  
  // 2. Calculate comparison stats
  const predictedPrice = parseFloat((prediction as any).predictedPrice || "0");
  const actual = parseFloat(actualPrice);
  const error = actual - predictedPrice;
  const errorPercent = predictedPrice !== 0 ? ((error / predictedPrice) * 100).toFixed(4) : "0";
  const accuracy = predictedPrice !== 0 
    ? Math.max(0, Math.min(1, 1 - Math.abs(error / predictedPrice))) 
    : 0;

  const confLower = (prediction as any).confidenceLower ? parseFloat((prediction as any).confidenceLower) : null;
  const confUpper = (prediction as any).confidenceUpper ? parseFloat((prediction as any).confidenceUpper) : null;
  const withinConfidence = (confLower !== null && confUpper !== null) 
    ? (actual >= confLower && actual <= confUpper) 
    : false;

  // 3. Create comparison
  const comparison = await createComparison({
    predictionId: (prediction as any).id,
    actualPrice: actualPrice,
    predictedPrice: (prediction as any).predictedPrice,
    error: error.toFixed(8),
    errorPercent: errorPercent,
    accuracy: accuracy.toFixed(6),
    withinConfidence: withinConfidence,
    modelVersion: (prediction as any).modelType,
    comparedAt: Date.now()
  });

  return { prediction, comparison };
}

// ==================== Learning Path System ====================

export async function insertLearningPath(path: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO learning_paths (id, symbol, model_type, optimizer_type, path_config, score, accuracy, training_time, status, created_at, completed_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [
      path.id, path.symbol, path.modelType, path.optimizerType, 
      path.pathConfig, path.score, path.accuracy || null, 
      path.trainingTime || null, path.status || 'pending', 
      path.createdAt || Date.now(), path.completedAt || null
    ]).then((res: any) => ({ id: res.rows[0].id, ...path }));
  }

  const stmt = db.prepare(`
    INSERT INTO learning_paths (id, symbol, model_type, optimizer_type, path_config, score, accuracy, training_time, status, created_at, completed_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    path.id, path.symbol, path.modelType, path.optimizerType, 
    path.pathConfig, path.score, path.accuracy || null, 
    path.trainingTime || null, path.status || 'pending', 
    path.createdAt || Date.now(), path.completedAt || null
  );
  return path;
}

export async function getLearningPaths(filters: { symbol?: string, modelType?: string, limit?: number }) {
  const db = getDb();
  if (usePostgres) {
    let query = "SELECT * FROM learning_paths WHERE 1=1";
    const params: any[] = [];
    let pIdx = 1;
    if (filters.symbol) { query += ` AND symbol = $${pIdx++}`; params.push(filters.symbol); }
    if (filters.modelType) { query += ` AND model_type = $${pIdx++}`; params.push(filters.modelType); }
    query += ` ORDER BY score DESC LIMIT $${pIdx}`;
    params.push(filters.limit || 10);
    return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  let query = "SELECT * FROM learning_paths WHERE 1=1";
  const params: any[] = [];
  if (filters.symbol) { query += " AND symbol = ?"; params.push(filters.symbol); }
  if (filters.modelType) { query += " AND model_type = ?"; params.push(filters.modelType); }
  query += " ORDER BY score DESC LIMIT ?";
  params.push(filters.limit || 10);
  return db.prepare(query).all(...params);
}

export async function insertLearningProgress(progress: any) {
  const db = getDb();
  const id = progress.id || `lp_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO learning_progress (id, path_id, iteration, optimizer_type, current_score, best_score, parameters, metrics, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [
      id, progress.pathId, progress.iteration, progress.optimizerType,
      progress.currentScore, progress.bestScore, progress.parameters,
      progress.metrics || null, progress.timestamp || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...progress }));
  }

  const stmt = db.prepare(`
    INSERT INTO learning_progress (id, path_id, iteration, optimizer_type, current_score, best_score, parameters, metrics, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    id, progress.pathId, progress.iteration, progress.optimizerType,
    progress.currentScore, progress.bestScore, progress.parameters,
    progress.metrics || null, progress.timestamp || Date.now()
  );
  return { id, ...progress };
}

export async function getLearningProgress(pathId: string) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM learning_progress WHERE path_id = $1 ORDER BY iteration ASC", [pathId])
      .then((res: any) => res.rows);
  }
  return db.prepare("SELECT * FROM learning_progress WHERE path_id = ? ORDER BY iteration ASC").all(pathId);
}

export async function insertPathEvaluation(evalData: any) {
  const db = getDb();
  const id = evalData.id || `pe_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO path_evaluations (id, path_id, evaluation_type, accuracy, precision, recall, f1_score, mae, rmse, metrics, evaluated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [
      id, evalData.pathId, evalData.evaluationType, evalData.accuracy,
      evalData.precision || null, evalData.recall || null, evalData.f1Score || null,
      evalData.mae || null, evalData.rmse || null, evalData.metrics || null,
      evalData.evaluatedAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...evalData }));
  }

  const stmt = db.prepare(`
    INSERT INTO path_evaluations (id, path_id, evaluation_type, accuracy, precision, recall, f1_score, mae, rmse, metrics, evaluated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    id, evalData.pathId, evalData.evaluationType, evalData.accuracy,
    evalData.precision || null, evalData.recall || null, evalData.f1Score || null,
    evalData.mae || null, evalData.rmse || null, evalData.metrics || null,
    evalData.evaluatedAt || Date.now()
  );
  return { id, ...evalData };
}

export async function getPathEvaluations(pathId: string) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM path_evaluations WHERE path_id = $1 ORDER BY evaluated_at DESC", [pathId])
      .then((res: any) => res.rows);
  }
  return db.prepare("SELECT * FROM path_evaluations WHERE path_id = ? ORDER BY evaluated_at DESC").all(pathId);
}

// ==================== Expert Opinions ====================

export async function insertExpertOpinion(opinion: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO expert_opinions (id, symbol, source, source_url, expert_name, expert_credibility, opinion_text, sentiment, sentiment_score, confidence, target_price, timeframe, tags, language, scraped_at, analyzed_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
      RETURNING id
    `, [
      opinion.id, opinion.symbol, opinion.source, opinion.sourceUrl || null,
      opinion.expertName || null, opinion.expertCredibility || 0.5,
      opinion.opinionText, opinion.sentiment, opinion.sentimentScore,
      opinion.confidence || null, opinion.targetPrice || null,
      opinion.timeframe || null, opinion.tags || null,
      opinion.language || 'en', opinion.scrapedAt || Date.now(),
      opinion.analyzedAt || null
    ]).then((res: any) => ({ id: res.rows[0].id, ...opinion }));
  }

  const stmt = db.prepare(`
    INSERT INTO expert_opinions (id, symbol, source, source_url, expert_name, expert_credibility, opinion_text, sentiment, sentiment_score, confidence, target_price, timeframe, tags, language, scraped_at, analyzed_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    opinion.id, opinion.symbol, opinion.source, opinion.sourceUrl || null,
    opinion.expertName || null, opinion.expertCredibility || 0.5,
    opinion.opinionText, opinion.sentiment, opinion.sentimentScore,
    opinion.confidence || null, opinion.targetPrice || null,
    opinion.timeframe || null, opinion.tags || null,
    opinion.language || 'en', opinion.scrapedAt || Date.now(),
    opinion.analyzedAt || null
  );
  return opinion;
}

export async function getExpertOpinions(filters: any) {
  const db = getDb();
  // Simplified query builder
  let query = "SELECT * FROM expert_opinions WHERE 1=1";
  const params: any[] = [];
  
  if (usePostgres) {
      let idx = 1;
      if (filters.symbol) { query += ` AND symbol = $${idx++}`; params.push(filters.symbol); }
      if (filters.source) { query += ` AND source = $${idx++}`; params.push(filters.source); }
      if (filters.sentiment) { query += ` AND sentiment = $${idx++}`; params.push(filters.sentiment); }
      if (filters.scrapedAfter) { query += ` AND scraped_at >= $${idx++}`; params.push(filters.scrapedAfter); }
      query += ` ORDER BY scraped_at DESC LIMIT $${idx}`;
      params.push(filters.limit || 50);
      return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  if (filters.symbol) { query += " AND symbol = ?"; params.push(filters.symbol); }
  if (filters.source) { query += " AND source = ?"; params.push(filters.source); }
  if (filters.sentiment) { query += " AND sentiment = ?"; params.push(filters.sentiment); }
  if (filters.scrapedAfter) { query += " AND scraped_at >= ?"; params.push(filters.scrapedAfter); }
  query += " ORDER BY scraped_at DESC LIMIT ?";
  params.push(filters.limit || 50);
  return db.prepare(query).all(...params);
}

// ==================== Drift Detection ====================

export async function insertDriftDetection(drift: any) {
  const db = getDb();
  const id = drift.id || `drift_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO drift_detections (id, symbol, "detectorType", "driftScore", severity, details, "actionTaken", "detectedAt", "createdAt")
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [
      id, drift.symbol, drift.detectorType, drift.driftScore,
      drift.severity, drift.details || null, drift.actionTaken || null,
      drift.detectedAt || Date.now(), drift.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...drift }));
  }

  const stmt = db.prepare(`
    INSERT INTO drift_detections (id, symbol, detectorType, driftScore, severity, details, actionTaken, detectedAt, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    id, drift.symbol, drift.detectorType, drift.driftScore,
    drift.severity, drift.details || null, drift.actionTaken || null,
    drift.detectedAt || Date.now(), drift.createdAt || Date.now()
  );
  return { id, ...drift };
}

export async function getDriftDetections(filters: any) {
  const db = getDb();
  let query = "SELECT * FROM drift_detections WHERE 1=1";
  const params: any[] = [];

  if (usePostgres) {
      let idx = 1;
      if (filters.symbol) { query += ` AND symbol = $${idx++}`; params.push(filters.symbol); }
      if (filters.severity) { query += ` AND severity = $${idx++}`; params.push(filters.severity); }
      query += ` ORDER BY "detectedAt" DESC LIMIT $${idx}`;
      params.push(filters.limit || 50);
      return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  if (filters.symbol) { query += " AND symbol = ?"; params.push(filters.symbol); }
  if (filters.severity) { query += " AND severity = ?"; params.push(filters.severity); }
  query += " ORDER BY detectedAt DESC LIMIT ?";
  params.push(filters.limit || 50);
  return db.prepare(query).all(...params);
}

// ==================== AI Scheduled Tasks ====================

export async function insertAIScheduledTask(task: any) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            INSERT INTO ai_scheduled_tasks ("userId", "assistantId", "taskName", description, "taskType", "taskConfig", "scheduleType", "cronExpression", timezone, "isActive", "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING id
        `, [
            task.userId, task.assistantId || 1, task.taskName, task.description || null,
            task.taskType, task.taskConfig || null, task.scheduleType,
            task.cronExpression, task.timezone || 'UTC', task.isActive !== false,
            Date.now(), Date.now()
        ]).then((res: any) => ({ id: res.rows[0].id, ...task }));
    }
    
    // SQLite
     const stmt = db.prepare(`
        INSERT INTO ai_scheduled_tasks (userId, assistantId, taskName, description, taskType, taskConfig, scheduleType, cronExpression, timezone, isActive, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    // @ts-ignore
    const result = await stmt.run(
            task.userId, task.assistantId || 1, task.taskName, task.description || null,
            task.taskType, task.taskConfig || null, task.scheduleType,
            task.cronExpression, task.timezone || 'UTC', task.isActive !== false ? 1 : 0, // SQLite boolean
            Date.now(), Date.now()
    );
     return { id: result.lastInsertRowid, ...task };
}

export async function getAIScheduledTasks(userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM ai_scheduled_tasks WHERE "userId" = $1 ORDER BY "createdAt" DESC', [userId])
            .then((res: any) => res.rows);
    }
    return db.prepare("SELECT * FROM ai_scheduled_tasks WHERE userId = ? ORDER BY createdAt DESC").all(userId);
}

// ==================== Expert Opinions Extras ====================

export async function insertSocialSentiment(sentiment: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO social_sentiment (id, symbol, platform, timeframe, bullish_count, bearish_count, neutral_count, total_mentions, sentiment_score, volume_change, trending_score, top_keywords, influencer_opinions, collected_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING id
    `, [
      sentiment.id, sentiment.symbol, sentiment.platform, sentiment.timeframe,
      sentiment.bullishCount || 0, sentiment.bearishCount || 0, sentiment.neutralCount || 0,
      sentiment.totalMentions || 0, sentiment.sentimentScore,
      sentiment.volumeChange || null, sentiment.trendingScore || null,
      sentiment.topKeywords || null, sentiment.influencerOpinions || null,
      sentiment.collectedAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...sentiment }));
  }

  const stmt = db.prepare(`
    INSERT INTO social_sentiment (id, symbol, platform, timeframe, bullish_count, bearish_count, neutral_count, total_mentions, sentiment_score, volume_change, trending_score, top_keywords, influencer_opinions, collected_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    sentiment.id, sentiment.symbol, sentiment.platform, sentiment.timeframe,
    sentiment.bullishCount || 0, sentiment.bearishCount || 0, sentiment.neutralCount || 0,
    sentiment.totalMentions || 0, sentiment.sentimentScore,
    sentiment.volumeChange || null, sentiment.trendingScore || null,
    sentiment.topKeywords || null, sentiment.influencerOpinions || null,
    sentiment.collectedAt || Date.now()
  );
  return sentiment;
}

export async function insertScrapingJob(job: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO scraping_jobs (id, symbol, job_type, sources, status, items_scraped, items_failed, error_message, started_at, completed_at, created_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [
      job.id, job.symbol, job.jobType, job.sources,
      job.status || 'pending', job.itemsScraped || 0, job.itemsFailed || 0,
      job.errorMessage || null, job.startedAt || null, job.completedAt || null,
      job.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...job }));
  }

  const stmt = db.prepare(`
    INSERT INTO scraping_jobs (id, symbol, job_type, sources, status, items_scraped, items_failed, error_message, started_at, completed_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    job.id, job.symbol, job.jobType, job.sources,
    job.status || 'pending', job.itemsScraped || 0, job.itemsFailed || 0,
    job.errorMessage || null, job.startedAt || null, job.completedAt || null,
    job.createdAt || Date.now()
  );
  return job;
}

export async function getScrapingJobs(filters: any) {
  const db = getDb();
  let query = "SELECT * FROM scraping_jobs WHERE 1=1";
  const params: any[] = [];
  
  if (usePostgres) {
    let idx = 1;
    if (filters.symbol) { query += ` AND symbol = $${idx++}`; params.push(filters.symbol); }
    if (filters.status) { query += ` AND status = $${idx++}`; params.push(filters.status); }
    query += ` ORDER BY created_at DESC LIMIT $${idx}`;
    params.push(filters.limit || 20);
    return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  if (filters.symbol) { query += " AND symbol = ?"; params.push(filters.symbol); }
  if (filters.status) { query += " AND status = ?"; params.push(filters.status); }
  query += " ORDER BY created_at DESC LIMIT ?";
  params.push(filters.limit || 20);
  return db.prepare(query).all(...params);
}

export async function getSentimentTrends(symbol: string, days: number = 30) {
  const db = getDb();
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffStr = cutoff.toISOString().split('T')[0];

  if (usePostgres) {
    return dbPostgres.query("SELECT * FROM sentiment_trends WHERE symbol = $1 AND date >= $2 ORDER BY date DESC", [symbol, cutoffStr])
      .then((res: any) => res.rows);
  }
  return db.prepare("SELECT * FROM sentiment_trends WHERE symbol = ? AND date >= ? ORDER BY date DESC").all(symbol, cutoffStr);
}

// ==================== Learning Extras (ACO, RL) ====================

export async function insertAcoPheromone(pheromone: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO aco_pheromones (id, symbol, model_type, feature_path, pheromone_level, visit_count, avg_score, last_updated)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [
      pheromone.id, pheromone.symbol, pheromone.modelType, pheromone.featurePath,
      pheromone.pheromoneLevel || 1.0, pheromone.visitCount || 0,
      pheromone.avgScore || null, pheromone.lastUpdated || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...pheromone }));
  }

  const stmt = db.prepare(`
    INSERT INTO aco_pheromones (id, symbol, model_type, feature_path, pheromone_level, visit_count, avg_score, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    pheromone.id, pheromone.symbol, pheromone.modelType, pheromone.featurePath,
    pheromone.pheromoneLevel || 1.0, pheromone.visitCount || 0,
    pheromone.avgScore || null, pheromone.lastUpdated || Date.now()
  );
  return pheromone;
}

export async function insertRlState(state: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO rl_states (id, symbol, model_type, state, action, q_value, reward, next_state, episode, step, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id
    `, [
      state.id, state.symbol, state.modelType, state.state, state.action,
      state.qValue, state.reward, state.nextState || null,
      state.episode, state.step, state.timestamp || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...state }));
  }

  const stmt = db.prepare(`
    INSERT INTO rl_states (id, symbol, model_type, state, action, q_value, reward, next_state, episode, step, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    state.id, state.symbol, state.modelType, state.state, state.action,
    state.qValue, state.reward, state.nextState || null,
    state.episode, state.step, state.timestamp || Date.now()
  );
  return state;
}

// ==================== Drift Extras ====================

export async function getDriftAlerts(acknowledged?: boolean, limit: number = 50) {
  const db = getDb();
  if (usePostgres) {
    let query = "SELECT * FROM drift_alerts WHERE 1=1";
    const params: any[] = [];
    if (acknowledged !== undefined) {
      query += " AND acknowledged = $1";
      params.push(acknowledged);
    }
    query += ` ORDER BY "createdAt" DESC LIMIT $${params.length + 1}`;
    params.push(limit);
    return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  let query = "SELECT * FROM drift_alerts WHERE 1=1";
  const params: any[] = [];
  if (acknowledged !== undefined) {
    query += " AND acknowledged = ?";
    params.push(acknowledged ? 1 : 0);
  }
  query += " ORDER BY createdAt DESC LIMIT ?";
  params.push(limit);
  return db.prepare(query).all(...params);
}

export async function acknowledgeDriftAlert(id: string, by: string) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query('UPDATE drift_alerts SET acknowledged = true, "acknowledgedBy" = $1, "acknowledgedAt" = $2 WHERE id = $3', [by, Date.now(), id]);
  }
  return db.prepare("UPDATE drift_alerts SET acknowledged = 1, acknowledgedBy = ?, acknowledgedAt = ? WHERE id = ?").run(by, Date.now(), id);
}

export async function getDriftMetricsHistory(symbol: string, detectorType?: string, days?: number) {
  const db = getDb();
  let query = "SELECT * FROM drift_metrics_history WHERE symbol = ?";
  const params: any[] = [symbol];
  
  // Note: Simplified for brevity, might need full builder for multiple conditions
  if (detectorType) {
    query += usePostgres ? " AND \"detectorType\" = $2" : " AND detectorType = ?";
    params.push(detectorType);
  }
  
  if (usePostgres) {
    query += " ORDER BY timestamp DESC"; // Postgres doesn't need param idx mapping for simple append if carefully done, but better to be safe. 
    // Actually standard Postgres driver needs $1, $2. 
    // Re-doing strict builder for Postgres:
     let pQuery = "SELECT * FROM drift_metrics_history WHERE symbol = $1";
     const pParams: any[] = [symbol];
     let pIdx = 2;
     if (detectorType) { pQuery += ` AND "detectorType" = $${pIdx++}`; pParams.push(detectorType); }
     if (days) {
         const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - days);
         pQuery += ` AND timestamp >= $${pIdx++}`; pParams.push(cutoff);
     }
     pQuery += " ORDER BY timestamp DESC";
     return dbPostgres.query(pQuery, pParams).then((res: any) => res.rows);
  }

  // SQLite
  if (detectorType) { query += " AND detectorType = ?"; } // already pushed param
  if (days) {
      const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - days);
      query += " AND timestamp >= ?";
      params.push(cutoff);
  }
  query += " ORDER BY timestamp DESC";
  return db.prepare(query).all(...params);
}

export async function getModelRetrainingLog(symbol?: string, limit: number = 50) {
  const db = getDb();
  if (usePostgres) {
    let query = "SELECT * FROM model_retraining_log WHERE 1=1";
    const params: any[] = [];
    if (symbol) { query += " AND symbol = $1"; params.push(symbol); }
    query += ` ORDER BY "createdAt" DESC LIMIT $${params.length + 1}`;
    params.push(limit);
    return dbPostgres.query(query, params).then((res: any) => res.rows);
  }

  let query = "SELECT * FROM model_retraining_log WHERE 1=1";
  const params: any[] = [];
  if (symbol) { query += " AND symbol = ?"; params.push(symbol); }
  query += " ORDER BY createdAt DESC LIMIT ?";
  params.push(limit);
  return db.prepare(query).all(...params);
}

export async function insertDriftAlert(alert: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO drift_alerts (id, "driftDetectionId", severity, message, acknowledged, "acknowledgedBy", "acknowledgedAt", "createdAt")
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [
      alert.id, alert.driftDetectionId, alert.severity, alert.message,
      alert.acknowledged, alert.acknowledgedBy || null,
      alert.acknowledgedAt || null, alert.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...alert }));
  }

  const stmt = db.prepare(`
    INSERT INTO drift_alerts (id, driftDetectionId, severity, message, acknowledged, acknowledgedBy, acknowledgedAt, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    alert.id, alert.driftDetectionId, alert.severity, alert.message,
    alert.acknowledged ? 1 : 0, alert.acknowledgedBy || null,
    alert.acknowledgedAt || null, alert.createdAt || Date.now()
  );
  return alert;
}

export async function insertDriftMetricsHistory(metrics: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO drift_metrics_history (id, symbol, "detectorType", "metricValue", severity, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [
      metrics.id, metrics.symbol, metrics.detectorType, metrics.metricValue,
      metrics.severity, metrics.timestamp || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...metrics }));
  }

  const stmt = db.prepare(`
    INSERT INTO drift_metrics_history (id, symbol, detectorType, metricValue, severity, timestamp)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    metrics.id, metrics.symbol, metrics.detectorType, metrics.metricValue,
    metrics.severity, metrics.timestamp || Date.now()
  );
  return metrics;
}

export async function insertModelRetrainingLog(log: any) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      INSERT INTO model_retraining_log (id, symbol, "reason", "startedAt", "completedAt", status, metrics, "createdAt")
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [
      log.id, log.symbol, log.reason, log.startedAt || Date.now(),
      log.completedAt || null, log.status, log.metrics || null,
      log.createdAt || Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...log }));
  }

  const stmt = db.prepare(`
    INSERT INTO model_retraining_log (id, symbol, reason, startedAt, completedAt, status, metrics, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    log.id, log.symbol, log.reason, log.startedAt || Date.now(),
    log.completedAt || null, log.status, log.metrics || null,
    log.createdAt || Date.now()
  );
  return log;
}

// ==================== News Sentiment & Security Extras ====================

export async function insertSentimentHistory(userId: string, assetSymbol: string, score: number, label: string, articlesCount: number) {
  const db = getDb();
  if (usePostgres) {
    // Ensure table exists
    await dbPostgres.query(`
      CREATE TABLE IF NOT EXISTS sentiment_history (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL,
        "assetSymbol" TEXT NOT NULL,
        score REAL NOT NULL,
        label TEXT NOT NULL,
        "articlesCount" INTEGER DEFAULT 0,
        "createdAt" BIGINT NOT NULL
      )
    `).catch(() => {});

    return dbPostgres.query(`
      INSERT INTO sentiment_history ("userId", "assetSymbol", "score", "label", "articlesCount", "createdAt")
      VALUES ($1, $2, $3, $4, $5, $6)
    `, [userId, assetSymbol, score, label, articlesCount, Date.now()]);
  }

  // SQLite
  db.prepare(`
    CREATE TABLE IF NOT EXISTS sentiment_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      assetSymbol TEXT NOT NULL,
      score REAL NOT NULL,
      label TEXT NOT NULL,
      articlesCount INTEGER DEFAULT 0,
      createdAt INTEGER NOT NULL
    )
  `).run();

  db.prepare(`
    INSERT INTO sentiment_history (userId, assetSymbol, score, label, articlesCount, createdAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(userId, assetSymbol, score, label, articlesCount, Date.now());
}

export async function getSentimentHistory(userId: string, assetSymbol?: string, limit: number = 50) {
  const db = getDb();
  if (usePostgres) {
     let query = `SELECT * FROM sentiment_history WHERE "userId" = $1`;
     const params: any[] = [userId];
     if (assetSymbol) { query += ` AND "assetSymbol" = $2`; params.push(assetSymbol); }
     query += ` ORDER BY "createdAt" DESC LIMIT $${params.length + 1}`;
     params.push(limit);
     return dbPostgres.query(query, params).then((res: any) => res.rows);
  }
  
  let query = `SELECT * FROM sentiment_history WHERE userId = ?`;
  const params: any[] = [userId];
  if (assetSymbol) { query += ` AND assetSymbol = ?`; params.push(assetSymbol); }
  query += ` ORDER BY createdAt DESC LIMIT ?`;
  params.push(limit);
  return db.prepare(query).all(...params);
}

// Duplicate Security Events block removed








// ==================== Comprehensive System Extras ====================

export async function insertNotification(notification: any) {
  const db = getDb();
  if (usePostgres) {
    await dbPostgres.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL,
        type VARCHAR(32) NOT NULL,
        channel VARCHAR(32),
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        data TEXT,
        status VARCHAR(16) DEFAULT 'pending',
        "readAt" BIGINT,
        "createdAt" BIGINT NOT NULL
      )
    `).catch(() => {});

    return dbPostgres.query(`
      INSERT INTO notifications ("userId", type, channel, title, message, data, status, "createdAt")
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [
      notification.userId, notification.type, notification.channel || null,
      notification.title, notification.message, notification.data ? JSON.stringify(notification.data) : null,
      'pending', Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...notification }));
  }

  db.prepare(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      type TEXT NOT NULL,
      channel TEXT,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      data TEXT,
      status TEXT DEFAULT 'pending',
      readAt INTEGER,
      createdAt INTEGER NOT NULL
    )
  `).run();

  const stmt = db.prepare(`
    INSERT INTO notifications (userId, type, channel, title, message, data, status, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  const res: any = stmt.run(
    notification.userId, notification.type, notification.channel || null,
    notification.title, notification.message, notification.data ? JSON.stringify(notification.data) : null,
    'pending', Date.now()
  );
  return { id: res.lastInsertRowid, ...notification };
}

export async function getUserNotifications(userId: string, limit: number = 50, offset: number = 0) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`
      SELECT * FROM notifications 
      WHERE "userId" = $1 
      ORDER BY "createdAt" DESC 
      LIMIT $2 OFFSET $3
    `, [userId, limit, offset]).then((res: any) => res.rows);
  }
  return db.prepare("SELECT * FROM notifications WHERE userId = ? ORDER BY createdAt DESC LIMIT ? OFFSET ?").all(userId, limit, offset);
}

export async function getUnreadNotificationsCount(userId: string) {
  const db = getDb();
  if (usePostgres) {
      const res = await dbPostgres.query('SELECT COUNT(*) as count FROM notifications WHERE "userId" = $1 AND "isRead" = 0', [userId]);
      return Number(res.rows[0]?.count || 0);
  }
  const result: any = db.prepare("SELECT COUNT(*) as count FROM notifications WHERE userId = ? AND isRead = 0").get(userId);
  return result?.count || 0;
}

export async function markNotificationAsRead(id: number, userId: string) {
  const db = getDb();
  if (usePostgres) {
      return dbPostgres.query('UPDATE notifications SET "isRead" = 1 WHERE id = $1 AND "userId" = $2', [id, userId]);
  }
  return db.prepare("UPDATE notifications SET isRead = 1 WHERE id = ? AND userId = ?").run(id, userId);
}

export async function markAllNotificationsAsRead(userId: string) {
  const db = getDb();
  if (usePostgres) {
      return dbPostgres.query('UPDATE notifications SET "isRead" = 1 WHERE "userId" = $1', [userId]);
  }
  return db.prepare("UPDATE notifications SET isRead = 1 WHERE userId = ?").run(userId);
}

export async function deleteNotification(id: number, userId: string) {
  const db = getDb();
  if (usePostgres) {
      return dbPostgres.query('DELETE FROM notifications WHERE id = $1 AND "userId" = $2', [id, userId]);
  }
  return db.prepare("DELETE FROM notifications WHERE id = ? AND userId = ?").run(id, userId);
}

export async function insertKPIMetrics(kpi: any) {
  const db = getDb();
  if (usePostgres) {
    await dbPostgres.query(`
      CREATE TABLE IF NOT EXISTS kpi_metrics (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL,
        period VARCHAR(16) NOT NULL,
        "totalValue" REAL,
        "totalInvested" REAL,
        "totalProfit" REAL,
        "totalLoss" REAL,
        roi REAL,
        "winRate" REAL,
        "avgProfit" REAL,
        "avgLoss" REAL,
        "profitFactor" REAL,
        "calculatedAt" BIGINT
      )
    `).catch(() => {});

    // Upsert logic (simplified delete then insert for compatibility if unique constraint missing, or usage ON CONFLICT)
    // Assuming unique check on userId + period
    const existing = await dbPostgres.query('SELECT id FROM kpi_metrics WHERE "userId"=$1 AND period=$2', [kpi.userId, kpi.period]);
    if (existing.rows.length > 0) {
       await dbPostgres.query('DELETE FROM kpi_metrics WHERE id=$1', [existing.rows[0].id]);
    }

    return dbPostgres.query(`
      INSERT INTO kpi_metrics ("userId", period, "totalValue", "totalInvested", "totalProfit", "totalLoss", roi, "winRate", "avgProfit", "avgLoss", "profitFactor", "calculatedAt")
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING id
    `, [
      kpi.userId, kpi.period, kpi.totalValue, kpi.totalInvested, kpi.totalProfit, kpi.totalLoss,
      kpi.roi, kpi.winRate, kpi.avgProfit, kpi.avgLoss, kpi.profitFactor, Date.now()
    ]).then((res: any) => ({ id: res.rows[0].id, ...kpi }));
  }

  db.prepare(`
    CREATE TABLE IF NOT EXISTS kpi_metrics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      period TEXT NOT NULL,
      totalValue REAL,
      totalInvested REAL,
      totalProfit REAL,
      totalLoss REAL,
      roi REAL,
      winRate REAL,
      avgProfit REAL,
      avgLoss REAL,
      profitFactor REAL,
      calculatedAt INTEGER
    )
  `).run();

  const existing = db.prepare('SELECT id FROM kpi_metrics WHERE userId=? AND period=?').get(kpi.userId, kpi.period) as any;
  if (existing) {
     db.prepare('DELETE FROM kpi_metrics WHERE id=?').run(existing.id);
  }

  const stmt = db.prepare(`
    INSERT INTO kpi_metrics (userId, period, totalValue, totalInvested, totalProfit, totalLoss, roi, winRate, avgProfit, avgLoss, profitFactor, calculatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  // @ts-ignore
  stmt.run(
    kpi.userId, kpi.period, kpi.totalValue, kpi.totalInvested, kpi.totalProfit, kpi.totalLoss,
    kpi.roi, kpi.winRate, kpi.avgProfit, kpi.avgLoss, kpi.profitFactor, Date.now()
  );
  return kpi;
}

export async function getKPIHistory(userId: string, periods: string[]) {
  const db = getDb();
  if (usePostgres) {
     const placeholders = periods.map((_, i) => `$${i + 2}`).join(',');
     const result = await dbPostgres.query(`
       SELECT * FROM kpi_metrics 
       WHERE "userId" = $1 AND period IN (${placeholders})
       ORDER BY period DESC
     `, [userId, ...periods]);
     return result.rows;
  }
  
  const placeholders = periods.map(() => '?').join(',');
  return db.prepare(`SELECT * FROM kpi_metrics WHERE userId = ? AND period IN (${placeholders}) ORDER BY period DESC`)
           .all(userId, ...periods);
}

export async function insertActivityLog(activity: any) {
  const db = getDb();
  if (usePostgres) {
    await dbPostgres.query(`
      CREATE TABLE IF NOT EXISTS activity_log (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL,
        action TEXT NOT NULL,
        "entityType" TEXT NOT NULL,
        "entityId" TEXT,
        description TEXT,
        "ipAddress" TEXT,
        "userAgent" TEXT,
        metadata TEXT,
        timestamp BIGINT
      )
    `).catch(() => {});

    return dbPostgres.query(`
      INSERT INTO activity_log ("userId", action, "entityType", "entityId", description, "ipAddress", "userAgent", metadata, timestamp)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [
      activity.userId, activity.action, activity.entityType, activity.entityId || null,
      activity.description || null, activity.ipAddress || null, activity.userAgent || null,
      activity.metadata ? JSON.stringify(activity.metadata) : null, Date.now()
    ]);
  }

  db.prepare(`
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      action TEXT NOT NULL,
      entityType TEXT NOT NULL,
      entityId TEXT,
      description TEXT,
      ipAddress TEXT,
      userAgent TEXT,
      metadata TEXT,
      timestamp INTEGER
    )
  `).run();

  db.prepare(`
    INSERT INTO activity_log (userId, action, entityType, entityId, description, ipAddress, userAgent, metadata, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    activity.userId, activity.action, activity.entityType, activity.entityId || null,
    activity.description || null, activity.ipAddress || null, activity.userAgent || null,
    activity.metadata ? JSON.stringify(activity.metadata) : null, Date.now()
  );
  return { success: true };
}

export async function getUserActivity(userId: string, limit: number = 100) {
  const db = getDb();
  if (usePostgres) {
    return dbPostgres.query(`SELECT * FROM activity_log WHERE "userId" = $1 ORDER BY timestamp DESC LIMIT $2`, [userId, limit])
      .then((res: any) => res.rows);
  }
  return db.prepare("SELECT * FROM activity_log WHERE userId = ? ORDER BY timestamp DESC LIMIT ?").all(userId, limit);
}

export async function insertChangeTracking(change: any) {
    const db = getDb();
    if (usePostgres) {
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS change_tracking (
                id SERIAL PRIMARY KEY,
                "userId" VARCHAR(64) NOT NULL,
                "entityType" TEXT NOT NULL,
                "entityId" TEXT NOT NULL,
                field TEXT NOT NULL,
                "oldValue" TEXT,
                "newValue" TEXT,
                timestamp BIGINT
            )
        `).catch(() => {});
        return dbPostgres.query(`
            INSERT INTO change_tracking ("userId", "entityType", "entityId", field, "oldValue", "newValue", timestamp)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [
            change.userId, change.entityType, change.entityId, change.field,
            String(change.oldValue), String(change.newValue), Date.now()
        ]);
    }
    db.prepare(`
        CREATE TABLE IF NOT EXISTS change_tracking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            entityType TEXT NOT NULL,
            entityId TEXT NOT NULL,
            field TEXT NOT NULL,
            oldValue TEXT,
            newValue TEXT,
            timestamp INTEGER
        )
    `).run();
    db.prepare(`
        INSERT INTO change_tracking (userId, entityType, entityId, field, oldValue, newValue, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
        change.userId, change.entityType, change.entityId, change.field,
        String(change.oldValue), String(change.newValue), Date.now()
    );
    return { success: true };
}

export async function insertAIRecommendation(rec: any) {
    const db = getDb();
    const reasoning = JSON.stringify(rec.reasoning || []);
    const ts = Date.now();

    if (usePostgres) {
        await dbPostgres.query(`
           CREATE TABLE IF NOT EXISTS ai_recommendations (
               id SERIAL PRIMARY KEY,
               "userId" VARCHAR(64) NOT NULL,
               type VARCHAR(32),
               "assetId" INTEGER,
               title TEXT,
               description TEXT,
               confidence REAL,
               reasoning TEXT,
               "expectedReturn" REAL,
               "riskLevel" VARCHAR(16),
               timeframe VARCHAR(16),
               priority VARCHAR(16),
               status VARCHAR(16) DEFAULT 'pending',
               "createdAt" BIGINT,
               "actualReturn" REAL,
               accuracy REAL,
               "evaluatedAt" BIGINT
           )
        `).catch(() => {});
        return dbPostgres.query(`
           INSERT INTO ai_recommendations 
           ("userId", type, "assetId", title, description, confidence, reasoning, "expectedReturn", "riskLevel", timeframe, priority, status, "createdAt")
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        `, [
            rec.userId, rec.type, rec.assetId || null, rec.title, rec.description, rec.confidence,
            reasoning, rec.expectedReturn || null, rec.riskLevel, rec.timeframe, rec.priority, 'pending', ts
        ]);
    }
    db.prepare(`
       CREATE TABLE IF NOT EXISTS ai_recommendations (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           userId TEXT NOT NULL,
           type TEXT,
           assetId INTEGER,
           title TEXT,
           description TEXT,
           confidence REAL,
           reasoning TEXT,
           expectedReturn REAL,
           riskLevel TEXT,
           timeframe TEXT,
           priority TEXT,
           status TEXT DEFAULT 'pending',
           createdAt INTEGER,
           actualReturn REAL,
           accuracy REAL,
           evaluatedAt INTEGER
       )
    `).run();
    db.prepare(`
       INSERT INTO ai_recommendations 
       (userId, type, assetId, title, description, confidence, reasoning, expectedReturn, riskLevel, timeframe, priority, status, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
        rec.userId, rec.type, rec.assetId || null, rec.title, rec.description, rec.confidence,
        reasoning, rec.expectedReturn || null, rec.riskLevel, rec.timeframe, rec.priority, 'pending', ts
    );
    return { success: true };
}

export async function updateAIRecommendation(id: number, updates: any) {
    const db = getDb();
    const fields = [];
    const values = [];
    
    if (updates.actualReturn !== undefined) { fields.push(usePostgres ? '"actualReturn" = ?' : 'actualReturn = ?'); values.push(updates.actualReturn); }
    if (updates.accuracy !== undefined) { fields.push('accuracy = ?'); values.push(updates.accuracy); }
    if (updates.status) { fields.push('status = ?'); values.push(updates.status); }
    
    fields.push(usePostgres ? '"evaluatedAt" = ?' : 'evaluatedAt = ?');
    values.push(Date.now());
    
    values.push(id);
    
    if (usePostgres) {
        const setClause = fields.map((f, i) => f.replace('?', `$${i+1}`)).join(', ');
        return dbPostgres.query(`UPDATE ai_recommendations SET ${setClause} WHERE id = $${values.length}`, values);
    }
    const stmt = db.prepare(`UPDATE ai_recommendations SET ${fields.join(', ')} WHERE id = ?`);
    return stmt.run(...values);
}

export async function insertAIConversation(conv: any) {
    const db = getDb();
    const ts = Date.now();
    if (usePostgres) {
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS ai_conversations (
                id SERIAL PRIMARY KEY,
                "userId" VARCHAR(64) NOT NULL,
                "userMessage" TEXT,
                "assistantResponse" TEXT,
                "assistantId" INTEGER,
                "tokensUsed" INTEGER,
                "timestamp" BIGINT
            )
        `).catch(() => {});
        return dbPostgres.query(`
            INSERT INTO ai_conversations ("userId", "userMessage", "assistantResponse", "timestamp")
            VALUES ($1, $2, $3, $4)
        `, [conv.userId, conv.userMessage, conv.assistantResponse, ts]);
    }
    
    db.prepare(`
        CREATE TABLE IF NOT EXISTS ai_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            userMessage TEXT,
            assistantResponse TEXT,
            assistantId INTEGER,
            tokensUsed INTEGER,
            timestamp INTEGER
        )
    `).run();
    db.prepare(`
        INSERT INTO ai_conversations (userId, userMessage, assistantResponse, timestamp)
        VALUES (?, ?, ?, ?)
    `).run(conv.userId, conv.userMessage, conv.assistantResponse, ts);
}

export async function getPendingAIRecommendations(userId: string, limit: number = 5) {
     const db = getDb();
     if (usePostgres) {
         return dbPostgres.query(`
             SELECT * FROM ai_recommendations WHERE "userId" = $1 AND status = 'pending' ORDER BY "createdAt" DESC LIMIT $2
         `, [userId, limit]).then((res: any) => res.rows);
     }
     return db.prepare("SELECT * FROM ai_recommendations WHERE userId = ? AND status = 'pending' ORDER BY createdAt DESC LIMIT ?")
              .all(userId, limit);
}

export async function insertRiskProfile(profile: any) {
  const db = getDb();
  if (usePostgres) {
      await dbPostgres.query(`
          CREATE TABLE IF NOT EXISTS risk_profiles (
              id SERIAL PRIMARY KEY,
              "userId" VARCHAR(64) NOT NULL,
              "assetId" INTEGER,
              "riskScore" REAL,
              "riskLevel" VARCHAR(16),
              volatility REAL,
              "calculatedAt" BIGINT
          )
      `).catch(() => {});
      return dbPostgres.query(`
          INSERT INTO risk_profiles ("userId", "assetId", "riskScore", "riskLevel", volatility, "calculatedAt")
          VALUES ($1, $2, $3, $4, $5, $6)
      `, [profile.userId, profile.assetId || null, profile.riskScore, profile.riskLevel, profile.volatility, Date.now()]);
  }
  db.prepare(`
      CREATE TABLE IF NOT EXISTS risk_profiles (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId TEXT NOT NULL,
          assetId INTEGER,
          riskScore REAL,
          riskLevel TEXT,
          volatility REAL,
          calculatedAt INTEGER
      )
  `).run();
  db.prepare(`
      INSERT INTO risk_profiles (userId, assetId, riskScore, riskLevel, volatility, calculatedAt)
      VALUES (?, ?, ?, ?, ?, ?)
  `).run(profile.userId, profile.assetId || null, profile.riskScore, profile.riskLevel, profile.volatility, Date.now());
  return { success: true };
}

export async function insertSentimentAnalysis(analysis: any) {
    const db = getDb();
    const columns = [
        "content", "language", "sentiment", "score", "confidence", 
        "keywords", "entities", "summary", "impact", "analyzedAt"
    ];
    
    // Convert arrays/objects to strings for storage
    const keywords = JSON.stringify(analysis.keywords || []);
    const entities = JSON.stringify(analysis.entities || []);
    const ts = Date.now();

    if (usePostgres) {
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS sentiment_analysis (
                id SERIAL PRIMARY KEY,
                content TEXT,
                language VARCHAR(10),
                sentiment VARCHAR(32),
                score REAL,
                confidence REAL,
                keywords TEXT,
                entities TEXT,
                summary TEXT,
                impact VARCHAR(16),
                "analyzedAt" BIGINT
            )
        `).catch(() => {});
        return dbPostgres.query(`
            INSERT INTO sentiment_analysis (content, language, sentiment, score, confidence, keywords, entities, summary, impact, "analyzedAt")
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `, [
            analysis.text || analysis.content, analysis.language || 'en', analysis.sentiment, 
            analysis.score, analysis.confidence, keywords, entities, 
            analysis.summary, analysis.impact, ts
        ]);
    }
    
    db.prepare(`
        CREATE TABLE IF NOT EXISTS sentiment_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT,
            language TEXT,
            sentiment TEXT,
            score REAL,
            confidence REAL,
            keywords TEXT,
            entities TEXT,
            summary TEXT,
            impact TEXT,
            analyzedAt INTEGER
        )
    `).run();
    db.prepare(`
        INSERT INTO sentiment_analysis (content, language, sentiment, score, confidence, keywords, entities, summary, impact, analyzedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
        analysis.text || analysis.content, analysis.language || 'en', analysis.sentiment, 
        analysis.score, analysis.confidence, keywords, entities, 
        analysis.summary, analysis.impact, ts
    );
    return { success: true };
}

// AI Scheduler Helpers
export async function getActiveScheduledTasks() {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM ai_scheduled_tasks WHERE "isActive" = true').then((res: any) => res.rows);
    }
    // Ensure table exists (SQLite)
    db.prepare(`
        CREATE TABLE IF NOT EXISTS ai_scheduled_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            taskName TEXT NOT NULL,
            taskType TEXT NOT NULL,
            scheduleType TEXT NOT NULL,
            cronExpression TEXT NOT NULL,
            assistantId INTEGER,
            taskConfig TEXT,
            isActive INTEGER DEFAULT 1,
            lastRunAt INTEGER,
            nextRunAt INTEGER,
            createdAt INTEGER,
            updatedAt INTEGER
        )
    `).run();
    return db.prepare('SELECT * FROM ai_scheduled_tasks WHERE enabled = 1').all();
}

export async function insertTaskResult(result: any) {
    const db = getDb();
    const ts = Date.now();
    if (usePostgres) {
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS ai_task_results (
                id SERIAL PRIMARY KEY,
                "taskId" INTEGER NOT NULL,
                result TEXT,
                status VARCHAR(32),
                "executionTime" INTEGER,
                "tokensUsed" INTEGER,
                "errorMessage" TEXT,
                "createdAt" BIGINT
            )
        `).catch(() => {});
        return dbPostgres.query(`
            INSERT INTO ai_task_results ("taskId", result, status, "executionTime", "tokensUsed", "errorMessage", "createdAt")
            VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [result.taskId, result.result, result.status, result.executionTime, result.tokensUsed || 0, result.errorMessage || null, ts]);
    }

    db.prepare(`
        CREATE TABLE IF NOT EXISTS ai_task_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            taskId INTEGER NOT NULL,
            result TEXT,
            status TEXT,
            executionTime INTEGER,
            tokensUsed INTEGER,
            errorMessage TEXT,
            createdAt INTEGER
        )
    `).run();
    db.prepare(`
        INSERT INTO ai_task_results (taskId, result, status, executionTime, tokensUsed, errorMessage, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(result.taskId, result.result, result.status, result.executionTime, result.tokensUsed || 0, result.errorMessage || null, ts);
}

export async function updateScheduledTask(id: number, updates: any) {
    const db = getDb(); // Using generic logic
    // Implementation for DB agnostic update
    const fields = [];
    const values = [];
    
    if (updates.nextRunAt) { 
        fields.push(usePostgres ? '"nextRunAt" = ?' : 'nextRunAt = ?'); 
        values.push(updates.nextRunAt instanceof Date ? updates.nextRunAt.getTime() : updates.nextRunAt);
    }
    if (updates.lastRunAt) {
        fields.push(usePostgres ? '"lastRunAt" = ?' : 'lastRunAt = ?');
        values.push(updates.lastRunAt instanceof Date ? updates.lastRunAt.getTime() : updates.lastRunAt);
    }
    
    fields.push(usePostgres ? '"updatedAt" = ?' : 'updatedAt = ?');
    values.push(Date.now());
    
    if (fields.length === 1) {return;}
    values.push(id);
    
    if (usePostgres) {
        const setClause = fields.map((f, i) => f.replace('?', `$${i+1}`)).join(', ');
        return dbPostgres.query(`UPDATE ai_scheduled_tasks SET ${setClause} WHERE id = $${values.length}`, values);
    }
    
    const stmt = db.prepare(`UPDATE ai_scheduled_tasks SET ${fields.join(', ')} WHERE id = ?`);
    return stmt.run(...values);
}
export async function getPriceHistoryForAI(userId: string, days: number = 90) {
    const db = getDb();
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT "assetId", price, "timestamp"
            FROM price_history
            WHERE "assetId" IN (SELECT "assetId" FROM portfolio WHERE "userId" = $1)
            AND "timestamp" >= $2
            ORDER BY "timestamp" DESC
        `, [userId, cutoff]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT assetId, price, timestamp
        FROM price_history
        WHERE assetId IN (SELECT assetId FROM portfolio WHERE userId = ?)
        AND timestamp >= ?
        ORDER BY timestamp DESC
    `).all(userId, cutoff);
}

export async function getRecentNewsForAI(days: number = 7) {
    const db = getDb();
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT title, content, sentiment, "publishedAt"
            FROM news_cache
            WHERE "publishedAt" >= $1
            ORDER BY "publishedAt" DESC
            LIMIT 20
        `, [cutoff]).then((res: any) => res.rows);
    }
    db.prepare(`
        CREATE TABLE IF NOT EXISTS news_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            content TEXT,
            sentiment TEXT,
            publishedAt INTEGER,
            source TEXT,
            url TEXT
        )
    `).run();
    
    return db.prepare(`
        SELECT title, content, sentiment, publishedAt
        FROM news_cache
        WHERE publishedAt >= ?
        ORDER BY publishedAt DESC
        LIMIT 20
    `).all(cutoff);
}

export async function getMarketTrendsForAI(days: number = 1) {
    const db = getDb();
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT "assetId", "trendDirection", strength, confidence
            FROM market_trends
            WHERE "calculatedAt" >= $1
        `, [cutoff]).catch(() => ({rows:[]})).then((res: any) => res.rows);
    }
    
    db.prepare(`
        CREATE TABLE IF NOT EXISTS market_trends (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            assetId INTEGER,
            trendDirection TEXT,
            strength REAL,
            confidence REAL,
            calculatedAt INTEGER
        )
    `).run();

    return db.prepare(`
        SELECT assetId, trendDirection, strength, confidence
        FROM market_trends
        WHERE calculatedAt >= ?
    `).all(cutoff);
}

export async function getAIRecommendationById(id: number) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM ai_recommendations WHERE id = $1', [id]).then((res: any) => res.rows[0]);
    }
    return db.prepare('SELECT * FROM ai_recommendations WHERE id = ?').get(id);
}
// ... (end of getAIRecommendationById)

export async function getChatHistory(userId: string, limit: number = 50) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT "userMessage", "assistantResponse", "timestamp"
            FROM ai_conversations
            WHERE "userId" = $1
            ORDER BY "timestamp" DESC
            LIMIT $2
        `, [userId, limit]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT userMessage, assistantResponse, timestamp
        FROM ai_conversations
        WHERE userId = ?
        ORDER BY timestamp DESC
        LIMIT ?
    `).all(userId, limit);
}

export async function getAssetPriceHistoryAfter(assetId: number, timestamp: number, limit: number = 2) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT price, "timestamp"
            FROM price_history
            WHERE "assetId" = $1 AND "timestamp" >= $2
            ORDER BY "timestamp" ASC
            LIMIT $3
        `, [assetId, timestamp, limit]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT price, timestamp
        FROM price_history
        WHERE assetId = ? AND timestamp >= ?
        ORDER BY timestamp ASC
        LIMIT ?
    `).all(assetId, timestamp, limit);
}

export async function getSystemStats() {
    const db = getDb();
    let stats = {
        totalUsers: 0, activeUsers: 0, totalNotifications: 0,
        totalReports: 0, totalActivities: 0, totalAssets: 0,
        totalPredictions: 0, totalAlerts: 0
    };

    const runCount = async (table: string, where?: string, params: any[] = []) => {
        try {
            if (usePostgres) {
                 const q = `SELECT COUNT(*) as count FROM ${table} ${where ? 'WHERE '+where : ''}`;
                 const res = await dbPostgres.query(q, params);
                 return Number(res.rows[0].count);
            }
            const q = `SELECT COUNT(*) as count FROM ${table} ${where ? 'WHERE '+where : ''}`;
            const res = db.prepare(q).get(...params) as any;
            return Number(res.count);
        } catch { return 0; }
    };

    stats.totalUsers = await runCount('users');
    const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
    stats.activeUsers = await runCount('users', usePostgres ? '"lastSignedIn" > $1' : 'lastSignedIn > ?', [cutoff24h]);
    
    // Check if tables exist before counting (implicit in try/catch of runCount, but tables might not exist)
    stats.totalNotifications = await runCount('notifications');
    stats.totalReports = await runCount('saved_reports');
    stats.totalActivities = await runCount('security_events'); // Using security_events as activity proxy as per router logic
    stats.totalAssets = await runCount('assets');
    stats.totalPredictions = await runCount('predictions');
    stats.totalAlerts = await runCount('alerts');

    return stats;
}



export async function getPredictionsJoined(userId: string, limit: number = 100) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT p.*, a.symbol, a.name 
            FROM predictions p
            JOIN assets a ON p."assetId" = a.id
            WHERE p."userId" = $1
            ORDER BY p."createdAt" DESC
            LIMIT $2
        `, [userId, limit]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT p.*, a.symbol, a.name
        FROM predictions p
        JOIN assets a ON p.assetId = a.id
        WHERE p.userId = ?
        ORDER BY p.createdAt DESC
        LIMIT ?
    `).all(userId, limit);
}

export async function getAlertsJoined(userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT al.*, a.symbol, a.name
            FROM alerts al
            JOIN assets a ON al."assetId" = a.id
            WHERE al."userId" = $1
            ORDER BY al."createdAt" DESC
        `, [userId]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT al.*, a.symbol, a.name
        FROM alerts al
        JOIN assets a ON al.assetId = a.id
        WHERE al.userId = ?
        ORDER BY al.createdAt DESC
    `).all(userId);
}

export async function getAIConversations(userId: string, assistantId: number, limit: number = 50) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM ai_conversations WHERE "userId" = $1 AND "assistantId" = $2 ORDER BY "createdAt" DESC LIMIT $3', [userId, assistantId, limit]).then((res: any) => res.rows);
    }
    return db.prepare('SELECT * FROM ai_conversations WHERE userId = ? AND assistantId = ? ORDER BY createdAt DESC LIMIT ?').all(userId, assistantId, limit);
}


export async function getAIUsageLimits(userId: string, assistantId: number) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM ai_usage_limits WHERE "userId" = $1 AND "assistantId" = $2', [userId, assistantId]).then((res: any) => res.rows[0]);
    }
    return db.prepare('SELECT * FROM ai_usage_limits WHERE userId = ? AND assistantId = ?').get(userId, assistantId);
}

export async function getAIUsageStats(userId: string, assistantId: number) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT COUNT(*) as "totalMessages", COALESCE(SUM("tokensUsed"), 0) as "totalTokens"
            FROM ai_conversations
            WHERE "userId" = $1 AND "assistantId" = $2
        `, [userId, assistantId]).then((res: any) => res.rows[0]);
    }
    return db.prepare(`
        SELECT COUNT(*) as totalMessages, COALESCE(SUM(tokensUsed), 0) as totalTokens
        FROM ai_conversations
        WHERE userId = ? AND assistantId = ?
    `).get(userId, assistantId);
}

export async function insertAIFeedback(feedback: any) {
    const db = getDb();
    if (usePostgres) {
         // Create table if not exists (Postgres style)
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS ai_feedback (
                id SERIAL PRIMARY KEY,
                "conversationId" INTEGER NOT NULL,
                "userId" TEXT NOT NULL,
                rating INTEGER NOT NULL,
                feedback TEXT,
                "createdAt" BIGINT NOT NULL
            )
        `);
        return dbPostgres.query(`
            INSERT INTO ai_feedback ("conversationId", "userId", rating, feedback, "createdAt")
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
        `, [feedback.conversationId, feedback.userId, feedback.rating, feedback.feedback, feedback.createdAt]).then((res: any) => res.rows[0]);
    }
    
    // SQLite style
    db.prepare(`
        CREATE TABLE IF NOT EXISTS ai_feedback (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          conversationId INTEGER NOT NULL,
          userId TEXT NOT NULL,
          rating INTEGER NOT NULL,
          feedback TEXT,
          createdAt INTEGER NOT NULL
        )
    `).run();

    return db.prepare(`
        INSERT INTO ai_feedback (conversationId, userId, rating, feedback, createdAt)
        VALUES (?, ?, ?, ?, ?)
    `).run(feedback.conversationId, feedback.userId, feedback.rating, feedback.feedback, feedback.createdAt);
}

export async function insertSecurityEvent(event: any) {
    // Adapted from legacy block (lines 2613+) to use timestamp and consistent logic
    const db = getDb();
    const details = event.details ? JSON.stringify(event.details) : null;
    const ts = Date.now();

    if (usePostgres) {
        await dbPostgres.query(`
            CREATE TABLE IF NOT EXISTS security_events (
                id SERIAL PRIMARY KEY,
                "eventType" VARCHAR(32) NOT NULL,
                "userId" VARCHAR(64),
                "ipAddress" VARCHAR(45),
                "userAgent" TEXT,
                details TEXT,
                "timestamp" BIGINT DEFAULT 0
            )
        `).catch(() => {});
        return dbPostgres.query(`
            INSERT INTO security_events ("eventType", "userId", "ipAddress", "userAgent", details, "timestamp")
            VALUES ($1, $2, $3, $4, $5, $6)
             RETURNING id
        `, [event.eventType, event.userId || null, event.ip || null, event.userAgent || null, details, ts])
        .then((res: any) => ({ id: res.rows[0].id, ...event }));
    }
    db.prepare(`
        CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            eventType TEXT NOT NULL,
            userId TEXT,
            ipAddress TEXT,
            userAgent TEXT,
            details TEXT,
            timestamp INTEGER DEFAULT 0
        )
    `).run();
    const res: any = db.prepare(`
        INSERT INTO security_events (eventType, userId, ipAddress, userAgent, details, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(event.eventType, event.userId || null, event.ip || null, event.userAgent || null, details, ts);
    return { id: res.lastInsertRowid, ...event };
}

export async function getSecurityEvents(limit: number = 100, offset: number = 0, filters: any = {}) {
    const db = getDb();
    let query = "SELECT * FROM security_events WHERE 1=1";
    const params: any[] = [];
    
    if (filters.userId) {
        if (usePostgres) { query += ' AND "userId" = $' + (params.length + 1); } 
        else { query += ' AND userId = ?'; }
        params.push(filters.userId);
    }
    
    if (filters.eventType) {
         if (usePostgres) { query += ' AND "eventType" = $' + (params.length + 1); } 
         else { query += ' AND eventType = ?'; }
         params.push(filters.eventType);
    }

    if (usePostgres) {
        query += ` ORDER BY "timestamp" DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
        params.push(limit, offset);
        return dbPostgres.query(query, params).then((res: any) => ({ events: res.rows, total: 0 }));
    }

    query += ` ORDER BY timestamp DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);
    const events = db.prepare(query).all(...params);
    return { events, total: 0 };
}

export async function getSecuritySummary(days: number = 7) {
    const db = getDb();
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
   
    if (usePostgres) {
       const stats = await dbPostgres.query(`
           SELECT "eventType", COUNT(*) as count
           FROM security_events
           WHERE "timestamp" > $1
           GROUP BY "eventType"
       `, [cutoff]).then((res: any) => res.rows);
       
       const recent = await dbPostgres.query(`
           SELECT * FROM security_events
           WHERE "timestamp" > $1
           ORDER BY "timestamp" DESC
           LIMIT 10
       `, [cutoff]).then((res: any) => res.rows);
       return { stats, recent };
    }

    const stats = db.prepare(`
           SELECT eventType, COUNT(*) as count
           FROM security_events
           WHERE timestamp > ?
           GROUP BY eventType
    `).all(cutoff);

    const recent = db.prepare(`
           SELECT * FROM security_events
           WHERE timestamp > ?
           ORDER BY timestamp DESC
           LIMIT 10
    `).all(cutoff);
    return { stats, recent };
}

export async function getActiveSessionsCount() {
    const db = getDb();
    const cutoff = Date.now() - 30 * 60 * 1000;
    if (usePostgres) {
        const res = await dbPostgres.query(`
            SELECT COUNT(DISTINCT "userId") as count
            FROM security_events
            WHERE "eventType" = 'login_success' AND "timestamp" > $1
        `, [cutoff]);
        return Number(res.rows[0]?.count || 0);
    }
    const res = db.prepare(`
        SELECT COUNT(DISTINCT userId) as count
        FROM security_events
        WHERE eventType = 'login_success' AND timestamp > ?
    `).get(cutoff) as any;
    return Number(res?.count || 0);
}

export async function getBlockedIPs() {
    const db = getDb();
    const cutoff = Date.now() - 60 * 60 * 1000;
    if (usePostgres) {
        return dbPostgres.query(`
            SELECT "ipAddress", COUNT(*) as count
            FROM security_events
            WHERE "eventType" = 'rate_limit_exceeded' AND "timestamp" > $1
            GROUP BY "ipAddress"
            ORDER BY count DESC
            LIMIT 20
        `, [cutoff]).then((res: any) => res.rows);
    }
    return db.prepare(`
        SELECT ipAddress, COUNT(*) as count
        FROM security_events
        WHERE eventType = 'rate_limit_exceeded' AND timestamp > ?
        GROUP BY ipAddress
        ORDER BY count DESC
        LIMIT 20
    `).all(cutoff);
}

// ==========================================
// PORTFOLIO MANAGEMENT HELPERS
// ==========================================

export async function getPortfolioJoined(userId: string) {
    const db = getDb();
    const sql = `
        SELECT 
            t.assetId,
            a.symbol,
            a.name,
            a.currentPrice,
            a.volatility,
            a.marketCap,
            SUM(CASE WHEN t."transactionType" = 'buy' THEN t.quantity ELSE -t.quantity END) as quantity,
            SUM(CASE WHEN t."transactionType" = 'buy' THEN t."totalAmount" ELSE -t."totalAmount" END) as totalInvested
        FROM transactions t
        JOIN assets a ON t."assetId" = a.id
        WHERE t."userId" = ${usePostgres ? '$1' : '?'}
        GROUP BY t."assetId", a.symbol, a.name, a."currentPrice", a.volatility, a."marketCap"
        HAVING quantity > 0
    `;
    
    if (usePostgres) {
        return dbPostgres.query(sql, [userId]).then((res: any) => res.rows);
    }
    const sqliteSql = `
        SELECT 
            t.assetId,
            a.symbol,
            a.name,
            a.currentPrice,
            a.volatility,
            a.marketCap,
            SUM(CASE WHEN t.transactionType = 'buy' THEN t.quantity ELSE -t.quantity END) as quantity,
            SUM(CASE WHEN t.transactionType = 'buy' THEN t.totalAmount ELSE -t.totalAmount END) as totalInvested
        FROM transactions t
        JOIN assets a ON t.assetId = a.id
        WHERE t.userId = ?
        GROUP BY t.assetId, a.symbol, a.name, a.currentPrice, a.volatility, a.marketCap
        HAVING quantity > 0
    `;
    return db.prepare(sqliteSql).all(userId);
}

export async function createPortfolio(data: any) {
    const db = getDb();
    const ts = new Date(); 
    const fields = ["userId", "name", "description", "isDefault", "createdAt", "updatedAt"];
    const vals = [data.userId, data.name, data.description, data.isDefault || false, ts, ts];
    
    if (usePostgres) {
        const ph = fields.map((_, i) => `$${i+1}`).join(',');
        return dbPostgres.query(
            `INSERT INTO portfolios (${fields.map(f=>`"${f}"`).join(',')}) VALUES (${ph}) RETURNING id`, 
            vals
        ).then((res: any) => ({insertId: res.rows[0].id}));
    }
    
    const ph = fields.map(() => '?').join(',');
    return db.prepare(`INSERT INTO portfolios (${fields.join(',')}) VALUES (${ph})`).run(...vals);
}

export async function getUserPortfolios(userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM portfolios WHERE "userId" = $1 ORDER BY "createdAt" DESC', [userId])
            .then((res: any) => res.rows);
    }
    return db.prepare('SELECT * FROM portfolios WHERE userId = ? ORDER BY createdAt DESC').all(userId);
}

export async function getPortfolio(portfolioId: number, userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM portfolios WHERE id = $1 AND "userId" = $2', [portfolioId, userId])
            .then((res: any) => res.rows[0]);
    }
    return db.prepare('SELECT * FROM portfolios WHERE id = ? AND userId = ?').get(portfolioId, userId);
}

export async function updatePortfolio(portfolioId: number, userId: string, data: any) {
    const db = getDb();
    const fields = [];
    const values = [];
    
    if (data.name !== undefined) { fields.push(usePostgres?'"name" = ?':'name = ?'); values.push(data.name); }
    if (data.description !== undefined) { fields.push(usePostgres?'"description" = ?':'description = ?'); values.push(data.description); }
    if (data.isDefault !== undefined) { fields.push(usePostgres?'"isDefault" = ?':'isDefault = ?'); values.push(data.isDefault); }
    
    fields.push(usePostgres?'"updatedAt" = ?':'updatedAt = ?');
    values.push(new Date());
    
    values.push(portfolioId, userId); 
    
    if (usePostgres) {
        const setClause = fields.map((f, i) => f.replace('?', `$${i+1}`)).join(', ');
        const whereClause = `WHERE id = $${values.length-1} AND "userId" = $${values.length}`;
        return dbPostgres.query(`UPDATE portfolios SET ${setClause} ${whereClause}`, values);
    }
    
    const setClause = fields.join(', ');
    return db.prepare(`UPDATE portfolios SET ${setClause} WHERE id = ? AND userId = ?`).run(...values);
}

export async function deletePortfolio(portfolioId: number, userId: string) {
    const db = getDb();
    if (usePostgres) {
        await dbPostgres.query('DELETE FROM transactions WHERE "portfolioId" = $1', [portfolioId]);
        await dbPostgres.query('DELETE FROM portfolio_snapshots WHERE "portfolioId" = $1', [portfolioId]);
        return dbPostgres.query('DELETE FROM portfolios WHERE id = $1 AND "userId" = $2', [portfolioId, userId]);
    }
    
    db.prepare('DELETE FROM transactions WHERE portfolioId = ?').run(portfolioId);
    db.prepare('DELETE FROM portfolio_snapshots WHERE portfolioId = ?').run(portfolioId);
    return db.prepare('DELETE FROM portfolios WHERE id = ? AND userId = ?').run(portfolioId, userId);
}

export async function addTransaction(data: any) {
    const db = getDb();
    const ts = new Date();
    const fields = ["portfolioId", "userId", "assetId", "transactionType", "quantity", "pricePerUnit", "totalAmount", "fees", "transactionDate", "notes", "createdAt", "updatedAt"];
    
    const vals = [
        data.portfolioId, data.userId, data.assetId, data.transactionType, 
        data.quantity, data.pricePerUnit, data.totalAmount, data.fees || 0,
        data.transactionDate, data.notes, ts, ts
    ];
    
    if (usePostgres) {
        const placeholders = fields.map((_, i) => `$${i+1}`).join(',');
        const cols = fields.map(f => `"${f}"`).join(',');
        return dbPostgres.query(`INSERT INTO transactions (${cols}) VALUES (${placeholders}) RETURNING id`, vals)
            .then((res: any) => ({insertId: res.rows[0].id}));
    }
    
    const placeholders = fields.map(() => '?').join(',');
    return db.prepare(`INSERT INTO transactions (${fields.join(',')}) VALUES (${placeholders})`).run(...vals);
}

export async function getTransactions(portfolioId: number, userId?: string, filters: any = {}) {
    const db = getDb();
    if (usePostgres) {
        const pgParams: any[] = [];
        let pIdx = 1;
        let pgSqlBuilder = `SELECT * FROM transactions WHERE "portfolioId" = $${pIdx++}`;
        pgParams.push(portfolioId);
        
        if (userId) { pgSqlBuilder += ` AND "userId" = $${pIdx++}`; pgParams.push(userId); }
        
        if (filters.assetId) { pgSqlBuilder += ` AND "assetId" = $${pIdx++}`; pgParams.push(filters.assetId); }
        if (filters.transactionType) { pgSqlBuilder += ` AND "transactionType" = $${pIdx++}`; pgParams.push(filters.transactionType); }
        if (filters.startDate) { pgSqlBuilder += ` AND "transactionDate" >= $${pIdx++}`; pgParams.push(filters.startDate); }
        if (filters.endDate) { pgSqlBuilder += ` AND "transactionDate" <= $${pIdx++}`; pgParams.push(filters.endDate); }
        
        pgSqlBuilder += ' ORDER BY "transactionDate" DESC';
        return dbPostgres.query(pgSqlBuilder, pgParams).then((res: any) => res.rows);
    }

    let sql = `SELECT * FROM transactions WHERE portfolioId = ?`;
    const params: any[] = [portfolioId];
    if (userId) { sql += ` AND userId = ?`; params.push(userId); }
    
    if (filters.assetId) { sql += ` AND assetId = ?`; params.push(filters.assetId); }
    if (filters.transactionType) { sql += ` AND transactionType = ?`; params.push(filters.transactionType); }
    if (filters.startDate) { sql += ` AND transactionDate >= ?`; params.push(filters.startDate); }
    if (filters.endDate) { sql += ` AND transactionDate <= ?`; params.push(filters.endDate); }
    
    sql += ` ORDER BY transactionDate DESC`;
    return db.prepare(sql).all(...params);
}

export async function getTransaction(transactionId: number, userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM transactions WHERE id = $1 AND "userId" = $2', [transactionId, userId])
            .then((res: any) => res.rows[0]);
    }
    return db.prepare('SELECT * FROM transactions WHERE id = ? AND userId = ?').get(transactionId, userId);
}

export async function updateTransaction(transactionId: number, userId: string, data: any) {
    const db = getDb();
    const fields = [];
    const values = [];
    const possibleFields = ["quantity", "pricePerUnit", "totalAmount", "fees", "transactionDate", "notes", "transactionType"];
    
    possibleFields.forEach(key => {
        if (data[key] !== undefined) {
            fields.push(usePostgres ? `"${key}" = ?` : `${key} = ?`);
            values.push(data[key]);
        }
    });

    fields.push(usePostgres ? '"updatedAt" = ?' : 'updatedAt = ?');
    values.push(new Date());
    
    values.push(transactionId, userId);
    
    if (fields.length === 1) {return;} 

    if (usePostgres) {
        const setClause = fields.map((f, i) => f.replace('?', `$${i+1}`)).join(', ');
        return dbPostgres.query(`UPDATE transactions SET ${setClause} WHERE id = $${values.length-1} AND "userId" = $${values.length}`, values);
    }
    const setClause = fields.join(', ');
    return db.prepare(`UPDATE transactions SET ${setClause} WHERE id = ? AND userId = ?`).run(...values);
}

export async function deleteTransaction(transactionId: number, userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('DELETE FROM transactions WHERE id = $1 AND "userId" = $2', [transactionId, userId]);
    }
    return db.prepare('DELETE FROM transactions WHERE id = ? AND userId = ?').run(transactionId, userId);
}

export async function getPortfolioSnapshots(portfolioId: number, startDate?: Date, endDate?: Date) {
    const db = getDb();
    if (usePostgres) {
        const pgParams: any[] = [];
        let idx = 1;
        let pSql = `SELECT * FROM portfolio_snapshots WHERE "portfolioId" = $${idx++}`;
        pgParams.push(portfolioId);
        
        if (startDate) { pSql += ` AND "snapshotDate" >= $${idx++}`; pgParams.push(startDate); }
        if (endDate) { pSql += ` AND "snapshotDate" <= $${idx++}`; pgParams.push(endDate); }
        
        pSql += ' ORDER BY "snapshotDate" DESC';
        return dbPostgres.query(pSql, pgParams).then((res: any) => res.rows);
    }
    
    let sql = `SELECT * FROM portfolio_snapshots WHERE portfolioId = ?`;
    const params: any[] = [portfolioId];
    if (startDate) { sql += ` AND snapshotDate >= ?`; params.push(startDate); }
    if (endDate) { sql += ` AND snapshotDate <= ?`; params.push(endDate); }
    sql += ` ORDER BY snapshotDate DESC`;
    
    return db.prepare(sql).all(...params);
}

export async function createPortfolioSnapshot(snapshot: any) {
    const db = getDb();
    const ts = new Date(); 
    const sDate = snapshot.snapshotDate || ts;
    let breakdown = snapshot.assetBreakdown;
    if (typeof breakdown === 'object') { breakdown = JSON.stringify(breakdown); }
    
    const fields = ["portfolioId", "snapshotDate", "totalValue", "totalInvested", "totalReturn", "returnPercent", "assetBreakdown", "createdAt"];
    const vals = [
        snapshot.portfolioId, sDate, snapshot.totalValue, snapshot.totalInvested, 
        snapshot.totalReturn, snapshot.returnPercent, breakdown || null, ts
    ];
    
    if (usePostgres) {
        const ph = fields.map((_, i) => `$${i+1}`).join(',');
        const cols = fields.map(f => `"${f}"`).join(',');
        return dbPostgres.query(`INSERT INTO portfolio_snapshots (${cols}) VALUES (${ph}) RETURNING id`, vals)
            .then((res: any) => ({insertId: res.rows[0].id}));
    }
    
    const ph = fields.map(() => '?').join(',');
    return db.prepare(`INSERT INTO portfolio_snapshots (${fields.join(',')}) VALUES (${ph})`).run(...vals);
}

export const createTransaction = addTransaction;
export const getPortfolios = getUserPortfolios;

export async function getPortfolioById(id: number) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM portfolios WHERE id = $1', [id]).then((res: any) => res.rows[0]);
    }
    return db.prepare('SELECT * FROM portfolios WHERE id = ?').get(id);
}

export async function deleteAllReadNotifications(userId: string) {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('DELETE FROM notifications WHERE "userId" = $1 AND "isRead" = true', [userId]);
    }
    return db.prepare('DELETE FROM notifications WHERE userId = ? AND isRead = 1').run(userId);
}

export async function getTransactionsByAsset(portfolioId: number, assetId: number): Promise<any[]> {
    const db = getDb();
    if (usePostgres) {
        return dbPostgres.query('SELECT * FROM transactions WHERE "portfolioId" = $1 AND "assetId" = $2 ORDER BY "transactionDate" DESC', [portfolioId, assetId])
            .then((res: any) => res.rows);
    }
    return db.prepare('SELECT * FROM transactions WHERE portfolioId = ? AND assetId = ? ORDER BY transactionDate DESC').all(portfolioId, assetId);
}



