-- Migration: Add User Email Index and Additional Optimizations
-- Created: 2025-12-01
-- Purpose: Add index on users.email for faster authentication lookups

-- Users table email index (critical for login performance)
CREATE INDEX IF NOT EXISTS `idx_users_email` ON `users` (`email`);

-- Users table role index (for admin queries)
CREATE INDEX IF NOT EXISTS `idx_users_role` ON `users` (`role`);

-- Users table last signed in index (for activity tracking)
CREATE INDEX IF NOT EXISTS `idx_users_lastSignedIn` ON `users` (`lastSignedIn`);

-- Email settings user index
CREATE INDEX IF NOT EXISTS `idx_email_settings_userId` ON `email_settings` (`userId`);

-- Error logs index for recent errors query
CREATE INDEX IF NOT EXISTS `idx_error_logs_timestamp` ON `error_logs` (`timestamp`);
CREATE INDEX IF NOT EXISTS `idx_error_logs_level` ON `error_logs` (`level`);

-- API request logs composite index
CREATE INDEX IF NOT EXISTS `idx_api_request_logs_timestamp` ON `api_request_logs` (`timestamp`);
CREATE INDEX IF NOT EXISTS `idx_api_request_logs_endpoint` ON `api_request_logs` (`endpoint`);

-- ML training logs index
CREATE INDEX IF NOT EXISTS `idx_ml_training_logs_assetId` ON `ml_training_logs` (`assetId`);
CREATE INDEX IF NOT EXISTS `idx_ml_training_logs_status` ON `ml_training_logs` (`status`);

-- Prediction logs index
CREATE INDEX IF NOT EXISTS `idx_prediction_logs_assetId` ON `prediction_logs` (`assetId`);
CREATE INDEX IF NOT EXISTS `idx_prediction_logs_userId` ON `prediction_logs` (`userId`);

