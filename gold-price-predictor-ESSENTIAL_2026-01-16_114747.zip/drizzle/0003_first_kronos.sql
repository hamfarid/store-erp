CREATE TABLE `inflectionPoints` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assetId` integer NOT NULL,
	`pointType` text NOT NULL,
	`price` real NOT NULL,
	`date` integer NOT NULL,
	`strength` real NOT NULL,
	`confidence` real NOT NULL,
	`priceChange` real,
	`percentChange` real,
	`volumeAtPoint` real,
	`identifiedAt` integer NOT NULL,
	`createdAt` integer NOT NULL,
	FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON UPDATE no action ON DELETE cascade
);
