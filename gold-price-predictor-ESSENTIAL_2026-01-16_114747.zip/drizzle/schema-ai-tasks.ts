/**
 * AI Scheduled Tasks Database Schema
 */

import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

/**
 * AI Scheduled Tasks table
 * Stores user-defined tasks for AI assistants to execute on schedule
 */
export const aiScheduledTasks = sqliteTable("ai_scheduled_tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: text("userId").notNull(),
  assistantId: integer("assistantId").default(1), // 1 = free, 2 = paid
  taskName: text("taskName").notNull(),
  description: text("description"),
  
  // Task type
  taskType: text("taskType", { enum: [
    "price_analysis",      // Analyze specific asset prices
    "portfolio_report",    // Generate portfolio performance report
    "news_summary",        // Summarize latest news for assets
    "prediction_update",   // Generate new predictions
    "alert_check",         // Check if any alerts should be triggered
    "custom_query"         // Custom user query
  ]}).notNull(),
  
  // Task configuration (JSON string)
  taskConfig: text("taskConfig"), // e.g., {"assetIds": [1,2,3], "query": "..."}
  
  // Schedule configuration
  scheduleType: text("scheduleType", { enum: [
    "daily",    // Every day at specific time
    "weekly",   // Specific day of week
    "monthly",  // Specific day of month
    "custom"    // Custom cron expression
  ]}).notNull(),
  
  cronExpression: text("cronExpression").notNull(), // e.g., "0 9 * * *" for 9 AM daily
  timezone: text("timezone").default("UTC"),
  
  // Status
  isActive: integer("isActive", { mode: "boolean" }).default(true).notNull(),
  lastRunAt: integer("lastRunAt", { mode: "timestamp" }),
  nextRunAt: integer("nextRunAt", { mode: "timestamp" }),
  
  // Notification settings
  notifyOnCompletion: integer("notifyOnCompletion", { mode: "boolean" }).default(true).notNull(),
  notifyOnError: integer("notifyOnError", { mode: "boolean" }).default(true).notNull(),
  
  // Metadata
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
});

/**
 * AI Task Results table
 * Stores execution results of scheduled tasks
 */
export const aiTaskResults = sqliteTable("ai_task_results", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  taskId: integer("taskId").notNull(),
  
  // Execution details
  status: text("status", { enum: ["success", "error", "partial"] }).notNull(),
  result: text("result"), // AI response or analysis
  errorMessage: text("errorMessage"),
  
  // Performance metrics
  executionTime: integer("executionTime"), // milliseconds
  tokensUsed: integer("tokensUsed"),
  
  // Metadata
  executedAt: integer("executedAt", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
});

export type AIScheduledTask = typeof aiScheduledTasks.$inferSelect;
export type InsertAIScheduledTask = typeof aiScheduledTasks.$inferInsert;
export type AITaskResult = typeof aiTaskResults.$inferSelect;
export type InsertAITaskResult = typeof aiTaskResults.$inferInsert;
