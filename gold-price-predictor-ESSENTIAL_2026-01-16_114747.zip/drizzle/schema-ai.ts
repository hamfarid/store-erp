import { mysqlTable, int, varchar, text, timestamp, boolean, json, mysqlEnum, index } from "drizzle-orm/mysql-core";

/**
 * AI Assistants Schema
 * Supports multiple AI assistants (free and paid) with different capabilities
 */

/**
 * AI Assistants table - stores AI assistant configurations
 */
export const aiAssistants = mysqlTable("ai_assistants", {
  id: int("id").primaryKey().autoincrement(),
  name: varchar("name", { length: 100 }).notNull(),
  type: mysqlEnum("type", ["free", "paid"]).notNull(),
  model: varchar("model", { length: 50 }).notNull(), // 'gemini-2.5-flash' or 'claude-3-opus'
  avatarUrl: varchar("avatarUrl", { length: 255 }),
  systemPrompt: text("systemPrompt").notNull(),
  permissions: json("permissions").notNull(), // AIPermissions object
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
});

export type AIAssistant = typeof aiAssistants.$inferSelect;
export type InsertAIAssistant = typeof aiAssistants.$inferInsert;

/**
 * AI Conversations table - stores chat history
 */
export const aiConversations = mysqlTable("ai_conversations", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  assistantId: int("assistantId").notNull(),
  message: text("message").notNull(),
  response: text("response").notNull(),
  tokensUsed: int("tokensUsed"),
  responseTime: int("responseTime"), // milliseconds
  wasSuccessful: boolean("wasSuccessful").default(true).notNull(),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow(),
}, (table) => ({
  userIdIdx: index("ai_conversations_user_id_idx").on(table.userId),
  assistantIdIdx: index("ai_conversations_assistant_id_idx").on(table.assistantId),
  createdAtIdx: index("ai_conversations_created_at_idx").on(table.createdAt),
}));

export type AIConversation = typeof aiConversations.$inferSelect;
export type InsertAIConversation = typeof aiConversations.$inferInsert;

/**
 * AI Usage Limits table - tracks daily usage per user
 */
export const aiUsageLimits = mysqlTable("ai_usage_limits", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  assistantId: int("assistantId").notNull(),
  messagesToday: int("messagesToday").default(0).notNull(),
  tokensToday: int("tokensToday").default(0).notNull(),
  lastResetDate: timestamp("lastResetDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
}, (table) => ({
  userAssistantIdx: index("ai_usage_limits_user_assistant_idx").on(table.userId, table.assistantId),
}));

export type AIUsageLimit = typeof aiUsageLimits.$inferSelect;
export type InsertAIUsageLimit = typeof aiUsageLimits.$inferInsert;

/**
 * AI Feedback table - stores user ratings and feedback
 */
export const aiFeedback = mysqlTable("ai_feedback", {
  id: int("id").primaryKey().autoincrement(),
  conversationId: int("conversationId").notNull(),
  userId: varchar("userId", { length: 64 }).notNull(),
  rating: int("rating").notNull(), // 1-5 stars
  feedback: text("feedback"),
  createdAt: timestamp("createdAt").defaultNow(),
}, (table) => ({
  conversationIdIdx: index("ai_feedback_conversation_id_idx").on(table.conversationId),
  userIdIdx: index("ai_feedback_user_id_idx").on(table.userId),
}));

export type AIFeedback = typeof aiFeedback.$inferSelect;
export type InsertAIFeedback = typeof aiFeedback.$inferInsert;

/**
 * News Cache table - caches news articles to reduce API calls
 */
export const newsCache = mysqlTable("news_cache", {
  id: int("id").primaryKey().autoincrement(),
  query: varchar("query", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["political", "economic", "financial"]).notNull(),
  articles: json("articles").notNull(), // Array of NewsArticle
  events: json("events"), // Array of NewsEvent
  overallSentiment: mysqlEnum("overallSentiment", ["positive", "negative", "neutral"]),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
}, (table) => ({
  queryIdx: index("news_cache_query_idx").on(table.query),
  expiresAtIdx: index("news_cache_expires_at_idx").on(table.expiresAt),
}));

export type NewsCache = typeof newsCache.$inferSelect;
export type InsertNewsCache = typeof newsCache.$inferInsert;

/**
 * AI Permissions interface (stored as JSON)
 */
export interface AIPermissions {
  // قراءة البيانات
  canReadPrices: boolean;
  canReadPredictions: boolean;
  canReadUserData: boolean;
  canReadAlerts: boolean;
  canReadHistory: boolean;
  
  // كتابة البيانات
  canCreatePredictions: boolean;
  canCreateAlerts: boolean;
  canModifySettings: boolean;
  canDeleteData: boolean;
  
  // وظائف متقدمة
  canSearchNews: boolean;
  canAnalyzeSentiment: boolean;
  canGenerateReports: boolean;
  canAccessPortfolio: boolean;
  
  // حدود الاستخدام
  dailyMessageLimit: number | null; // null = unlimited
  canAccessPremiumFeatures: boolean;
}

/**
 * Predefined permissions for free and paid assistants
 */
export const FREE_AI_PERMISSIONS: AIPermissions = {
  canReadPrices: true,
  canReadPredictions: true,
  canReadUserData: false,
  canReadAlerts: false,
  canReadHistory: false,
  
  canCreatePredictions: false,
  canCreateAlerts: false,
  canModifySettings: false,
  canDeleteData: false,
  
  canSearchNews: false,
  canAnalyzeSentiment: false,
  canGenerateReports: false,
  canAccessPortfolio: false,
  
  dailyMessageLimit: 10,
  canAccessPremiumFeatures: false,
};

export const PAID_AI_PERMISSIONS: AIPermissions = {
  canReadPrices: true,
  canReadPredictions: true,
  canReadUserData: true,
  canReadAlerts: true,
  canReadHistory: true,
  
  canCreatePredictions: true,
  canCreateAlerts: true,
  canModifySettings: false,
  canDeleteData: false,
  
  canSearchNews: true,
  canAnalyzeSentiment: true,
  canGenerateReports: true,
  canAccessPortfolio: true,
  
  dailyMessageLimit: null,
  canAccessPremiumFeatures: true,
};

