/**
 * FILE: drizzle/schema-opinions.ts
 * PURPOSE: Database schema for expert opinions and web scraping
 * OWNER: ML Team
 * RELATED: server/services/web-scraper.ts, server/services/expert-opinion-analyzer.ts
 * LAST-AUDITED: 2025-01-18
 */

import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

/**
 * Expert Opinions Table
 * Stores expert opinions scraped from various sources
 */
export const expertOpinions = sqliteTable("expert_opinions", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  source: text("source").notNull(), // website, twitter, reddit, etc.
  sourceUrl: text("source_url"),
  expertName: text("expert_name"),
  expertCredibility: real("expert_credibility").default(0.5), // 0-1 score
  opinionText: text("opinion_text").notNull(),
  sentiment: text("sentiment").notNull(), // bullish, bearish, neutral
  sentimentScore: real("sentiment_score").notNull(), // -1 to 1
  confidence: real("confidence"), // 0-1
  targetPrice: real("target_price"),
  timeframe: text("timeframe"), // short, medium, long
  tags: text("tags"), // JSON array of tags
  language: text("language").default("en"),
  scrapedAt: integer("scraped_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
  analyzedAt: integer("analyzed_at", { mode: "timestamp" }),
});

/**
 * Social Sentiment Table
 * Aggregated sentiment from social media
 */
export const socialSentiment = sqliteTable("social_sentiment", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  platform: text("platform").notNull(), // twitter, reddit, stocktwits
  timeframe: text("timeframe").notNull(), // 1h, 24h, 7d, 30d
  bullishCount: integer("bullish_count").notNull().default(0),
  bearishCount: integer("bearish_count").notNull().default(0),
  neutralCount: integer("neutral_count").notNull().default(0),
  totalMentions: integer("total_mentions").notNull().default(0),
  sentimentScore: real("sentiment_score").notNull(), // -1 to 1
  volumeChange: real("volume_change"), // % change from previous period
  trendingScore: real("trending_score"), // 0-1
  topKeywords: text("top_keywords"), // JSON array
  influencerOpinions: text("influencer_opinions"), // JSON array
  collectedAt: integer("collected_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

/**
 * Scraping Jobs Table
 * Tracks web scraping jobs
 */
export const scrapingJobs = sqliteTable("scraping_jobs", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  jobType: text("job_type").notNull(), // expert_opinions, social_sentiment, news
  sources: text("sources").notNull(), // JSON array of URLs
  status: text("status").notNull().default("pending"), // pending, running, completed, failed
  itemsScraped: integer("items_scraped").default(0),
  itemsFailed: integer("items_failed").default(0),
  errorMessage: text("error_message"),
  startedAt: integer("started_at", { mode: "timestamp" }),
  completedAt: integer("completed_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

/**
 * Opinion Analysis Cache
 * Caches LLM analysis results
 */
export const opinionAnalysisCache = sqliteTable("opinion_analysis_cache", {
  id: text("id").primaryKey(),
  opinionId: text("opinion_id")
    .notNull()
    .references(() => expertOpinions.id),
  analysisType: text("analysis_type").notNull(), // sentiment, entity, summary
  result: text("result").notNull(), // JSON result
  model: text("model"), // gpt-4, claude, gemini
  tokensUsed: integer("tokens_used"),
  cachedAt: integer("cached_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
  expiresAt: integer("expires_at", { mode: "timestamp" }),
});

/**
 * Sentiment Trends Table
 * Historical sentiment trends
 */
export const sentimentTrends = sqliteTable("sentiment_trends", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  expertSentiment: real("expert_sentiment"), // -1 to 1
  socialSentiment: real("social_sentiment"), // -1 to 1
  newsSentiment: real("news_sentiment"), // -1 to 1
  overallSentiment: real("overall_sentiment").notNull(), // -1 to 1
  bullishPercentage: real("bullish_percentage"),
  bearishPercentage: real("bearish_percentage"),
  volumeScore: real("volume_score"), // Normalized mention volume
  confidenceScore: real("confidence_score"), // 0-1
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

// TypeScript types
export type ExpertOpinion = typeof expertOpinions.$inferSelect;
export type InsertExpertOpinion = typeof expertOpinions.$inferInsert;

export type SocialSentiment = typeof socialSentiment.$inferSelect;
export type InsertSocialSentiment = typeof socialSentiment.$inferInsert;

export type ScrapingJob = typeof scrapingJobs.$inferSelect;
export type InsertScrapingJob = typeof scrapingJobs.$inferInsert;

export type OpinionAnalysisCache = typeof opinionAnalysisCache.$inferSelect;
export type InsertOpinionAnalysisCache = typeof opinionAnalysisCache.$inferInsert;

export type SentimentTrend = typeof sentimentTrends.$inferSelect;
export type InsertSentimentTrend = typeof sentimentTrends.$inferInsert;

