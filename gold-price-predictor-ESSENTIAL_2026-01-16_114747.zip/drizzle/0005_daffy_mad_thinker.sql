CREATE TABLE `ai_scheduled_tasks` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`userId` text NOT NULL,
	`assistantId` integer DEFAULT 1,
	`taskName` text NOT NULL,
	`description` text,
	`taskType` text NOT NULL,
	`taskConfig` text,
	`scheduleType` text NOT NULL,
	`cronExpression` text NOT NULL,
	`timezone` text DEFAULT 'UTC',
	`isActive` integer DEFAULT true NOT NULL,
	`lastRunAt` integer,
	`nextRunAt` integer,
	`notifyOnCompletion` integer DEFAULT true NOT NULL,
	`notifyOnError` integer DEFAULT true NOT NULL,
	`createdAt` integer DEFAULT (unixepoch()) NOT NULL,
	`updatedAt` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ai_task_results` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`taskId` integer NOT NULL,
	`status` text NOT NULL,
	`result` text,
	`errorMessage` text,
	`executionTime` integer,
	`tokensUsed` integer,
	`executedAt` integer DEFAULT (unixepoch()) NOT NULL
);
