/**
 * Portfolio Management Database Schema
 */

import { mysqlTable, varchar, text, int, decimal, datetime, timestamp, mysqlEnum, index, boolean } from "drizzle-orm/mysql-core";

/**
 * Portfolios table - stores user portfolios
 */
export const portfolios = mysqlTable("portfolios", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isDefault: boolean("isDefault").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("portfolios_userId_idx").on(table.userId),
}));

export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = typeof portfolios.$inferInsert;

/**
 * Transactions table - stores buy/sell transactions
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").primaryKey().autoincrement(),
  portfolioId: int("portfolioId").notNull(),
  userId: varchar("userId", { length: 64 }).notNull(),
  assetId: int("assetId").notNull(),
  
  // Transaction details
  transactionType: mysqlEnum("transactionType", ["buy", "sell"]).notNull(),
  quantity: decimal("quantity", { precision: 20, scale: 8 }).notNull(), // grams or units
  pricePerUnit: decimal("pricePerUnit", { precision: 20, scale: 8 }).notNull(), // price per gram/unit
  totalAmount: decimal("totalAmount", { precision: 20, scale: 2 }).notNull(), // total transaction value
  fees: decimal("fees", { precision: 20, scale: 2 }).default("0").notNull(), // transaction fees
  
  // Metadata
  transactionDate: datetime("transactionDate").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
}, (table) => ({
  portfolioIdIdx: index("transactions_portfolioId_idx").on(table.portfolioId),
  userIdIdx: index("transactions_userId_idx").on(table.userId),
  assetIdIdx: index("transactions_assetId_idx").on(table.assetId),
  transactionDateIdx: index("transactions_date_idx").on(table.transactionDate),
  transactionTypeIdx: index("transactions_type_idx").on(table.transactionType),
}));

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Portfolio Snapshots table - stores daily portfolio values for historical tracking
 */
export const portfolioSnapshots = mysqlTable("portfolio_snapshots", {
  id: int("id").primaryKey().autoincrement(),
  portfolioId: int("portfolioId").notNull(),
  
  // Snapshot date
  snapshotDate: datetime("snapshotDate").notNull(),
  
  // Portfolio metrics
  totalValue: decimal("totalValue", { precision: 20, scale: 2 }).notNull(), // current market value
  totalInvested: decimal("totalInvested", { precision: 20, scale: 2 }).notNull(), // total amount invested
  totalReturn: decimal("totalReturn", { precision: 20, scale: 2 }).notNull(), // profit/loss amount
  returnPercent: decimal("returnPercent", { precision: 10, scale: 4 }).notNull(), // ROI percentage
  
  // Asset breakdown (JSON string)
  assetBreakdown: text("assetBreakdown"), // {"1": {"quantity": 10, "value": 1000}, "2": {...}}
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  portfolioIdIdx: index("snapshots_portfolioId_idx").on(table.portfolioId),
  snapshotDateIdx: index("snapshots_date_idx").on(table.snapshotDate),
}));

export type PortfolioSnapshot = typeof portfolioSnapshots.$inferSelect;
export type InsertPortfolioSnapshot = typeof portfolioSnapshots.$inferInsert;

