import { mysqlTable, varchar, timestamp, int, text, mysqlEnum, index } from "drizzle-orm/mysql-core";

/**
 * Error logs table - tracks all system errors
 */
export const errorLogs = mysqlTable("error_logs", {
  id: int("id").primaryKey().autoincrement(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  level: mysqlEnum("level", ["error", "warn", "info"]).default("error").notNull(),
  source: varchar("source", { length: 50 }),
  component: varchar("component", { length: 100 }),
  message: text("message"),
  stack: text("stack"),
  userId: varchar("userId", { length: 64 }),
  metadata: text("metadata"),
}, (table) => ({
  timestampIdx: index("error_logs_timestamp_idx").on(table.timestamp),
  levelIdx: index("error_logs_level_idx").on(table.level),
}));

/**
 * ML training logs - tracks model training sessions
 */
export const mlTrainingLogs = mysqlTable("ml_training_logs", {
  id: int("id").primaryKey().autoincrement(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  assetId: int("assetId"),
  modelType: varchar("modelType", { length: 50 }),
  trainingDuration: int("trainingDuration"),
  trainScore: varchar("trainScore", { length: 50 }),
  testScore: varchar("testScore", { length: 50 }),
  mape: varchar("mape", { length: 50 }),
  hyperparameters: text("hyperparameters"),
  datasetSize: int("datasetSize"),
  status: mysqlEnum("status", ["started", "completed", "failed"]).default("started").notNull(),
  errorMessage: text("errorMessage"),
}, (table) => ({
  timestampIdx: index("ml_training_logs_timestamp_idx").on(table.timestamp),
  assetIdIdx: index("ml_training_logs_asset_id_idx").on(table.assetId),
}));

/**
 * Prediction logs - tracks all predictions made
 */
export const predictionLogs = mysqlTable("prediction_logs", {
  id: int("id").primaryKey().autoincrement(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  predictionId: int("predictionId"),
  assetId: int("assetId"),
  modelType: varchar("modelType", { length: 50 }),
  inputData: text("inputData"),
  outputData: text("outputData"),
  executionTime: int("executionTime"),
  userId: varchar("userId", { length: 64 }),
  status: mysqlEnum("status", ["success", "failed"]).default("success").notNull(),
  errorMessage: text("errorMessage"),
}, (table) => ({
  timestampIdx: index("prediction_logs_timestamp_idx").on(table.timestamp),
  assetIdIdx: index("prediction_logs_asset_id_idx").on(table.assetId),
}));

/**
 * API request logs - tracks all API calls
 */
export const apiRequestLogs = mysqlTable("api_request_logs", {
  id: int("id").primaryKey().autoincrement(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  method: varchar("method", { length: 10 }),
  endpoint: varchar("endpoint", { length: 255 }),
  userId: varchar("userId", { length: 64 }),
  statusCode: int("statusCode"),
  responseTime: int("responseTime"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  errorMessage: text("errorMessage"),
}, (table) => ({
  timestampIdx: index("api_request_logs_timestamp_idx").on(table.timestamp),
  userIdIdx: index("api_request_logs_user_id_idx").on(table.userId),
}));

export type ErrorLog = typeof errorLogs.$inferSelect;
export type InsertErrorLog = typeof errorLogs.$inferInsert;

export type MLTrainingLog = typeof mlTrainingLogs.$inferSelect;
export type InsertMLTrainingLog = typeof mlTrainingLogs.$inferInsert;

export type PredictionLog = typeof predictionLogs.$inferSelect;
export type InsertPredictionLog = typeof predictionLogs.$inferInsert;

export type APIRequestLog = typeof apiRequestLogs.$inferSelect;
export type InsertAPIRequestLog = typeof apiRequestLogs.$inferInsert;

