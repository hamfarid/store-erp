-- Migration: Drift Detection System
-- Created: 2025-01-18
-- Purpose: Add tables for drift detection, alerts, metrics, and retraining logs

-- Drift Detections Table
CREATE TABLE IF NOT EXISTS drift_detections (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  detectorType TEXT NOT NULL CHECK(detectorType IN ('psi', 'ks_test', 'autoencoder')),
  driftScore REAL NOT NULL,
  severity TEXT NOT NULL CHECK(severity IN ('none', 'low', 'medium', 'high')),
  details TEXT,
  actionTaken TEXT,
  detectedAt INTEGER DEFAULT (unixepoch()),
  createdAt INTEGER DEFAULT (unixepoch())
);

-- Drift Metrics History Table
CREATE TABLE IF NOT EXISTS drift_metrics_history (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  detectorType TEXT NOT NULL CHECK(detectorType IN ('psi', 'ks_test', 'autoencoder')),
  metricName TEXT NOT NULL,
  metricValue REAL NOT NULL,
  threshold REAL,
  timestamp INTEGER DEFAULT (unixepoch())
);

-- Drift Alerts Table
CREATE TABLE IF NOT EXISTS drift_alerts (
  id TEXT PRIMARY KEY,
  driftDetectionId TEXT NOT NULL,
  severity TEXT NOT NULL CHECK(severity IN ('low', 'medium', 'high', 'critical')),
  message TEXT NOT NULL,
  acknowledged INTEGER DEFAULT 0,
  acknowledgedBy TEXT,
  acknowledgedAt INTEGER,
  createdAt INTEGER DEFAULT (unixepoch())
);

-- Model Retraining Log Table
CREATE TABLE IF NOT EXISTS model_retraining_log (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  modelType TEXT NOT NULL,
  reason TEXT NOT NULL,
  driftDetectionId TEXT,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'completed', 'failed')),
  startedAt INTEGER,
  completedAt INTEGER,
  metrics TEXT,
  createdAt INTEGER DEFAULT (unixepoch())
);

-- Data Quality Metrics Table
CREATE TABLE IF NOT EXISTS data_quality_metrics (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  metricType TEXT NOT NULL CHECK(metricType IN ('completeness', 'consistency', 'accuracy', 'timeliness')),
  score REAL NOT NULL,
  details TEXT,
  timestamp INTEGER DEFAULT (unixepoch())
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_drift_detections_symbol ON drift_detections(symbol);
CREATE INDEX IF NOT EXISTS idx_drift_detections_severity ON drift_detections(severity);
CREATE INDEX IF NOT EXISTS idx_drift_detections_detected_at ON drift_detections(detectedAt);

CREATE INDEX IF NOT EXISTS idx_drift_metrics_history_symbol ON drift_metrics_history(symbol);
CREATE INDEX IF NOT EXISTS idx_drift_metrics_history_detector_type ON drift_metrics_history(detectorType);
CREATE INDEX IF NOT EXISTS idx_drift_metrics_history_timestamp ON drift_metrics_history(timestamp);

CREATE INDEX IF NOT EXISTS idx_drift_alerts_acknowledged ON drift_alerts(acknowledged);
CREATE INDEX IF NOT EXISTS idx_drift_alerts_severity ON drift_alerts(severity);
CREATE INDEX IF NOT EXISTS idx_drift_alerts_created_at ON drift_alerts(createdAt);

CREATE INDEX IF NOT EXISTS idx_model_retraining_log_symbol ON model_retraining_log(symbol);
CREATE INDEX IF NOT EXISTS idx_model_retraining_log_status ON model_retraining_log(status);
CREATE INDEX IF NOT EXISTS idx_model_retraining_log_created_at ON model_retraining_log(createdAt);

CREATE INDEX IF NOT EXISTS idx_data_quality_metrics_symbol ON data_quality_metrics(symbol);
CREATE INDEX IF NOT EXISTS idx_data_quality_metrics_metric_type ON data_quality_metrics(metricType);
CREATE INDEX IF NOT EXISTS idx_data_quality_metrics_timestamp ON data_quality_metrics(timestamp);

