-- Migration: Learning Path Optimization System
-- Created: 2025-01-18

-- Learning Paths Table
CREATE TABLE IF NOT EXISTS learning_paths (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  model_type TEXT NOT NULL,
  optimizer_type TEXT NOT NULL,
  path_config TEXT NOT NULL,
  score REAL NOT NULL,
  accuracy REAL,
  training_time INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL DEFAULT (unixepoch()),
  completed_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_learning_paths_symbol ON learning_paths(symbol);
CREATE INDEX IF NOT EXISTS idx_learning_paths_status ON learning_paths(status);
CREATE INDEX IF NOT EXISTS idx_learning_paths_score ON learning_paths(score DESC);

-- Learning Progress Table
CREATE TABLE IF NOT EXISTS learning_progress (
  id TEXT PRIMARY KEY,
  path_id TEXT NOT NULL REFERENCES learning_paths(id),
  iteration INTEGER NOT NULL,
  optimizer_type TEXT NOT NULL,
  current_score REAL NOT NULL,
  best_score REAL NOT NULL,
  parameters TEXT NOT NULL,
  metrics TEXT,
  timestamp INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_learning_progress_path_id ON learning_progress(path_id);
CREATE INDEX IF NOT EXISTS idx_learning_progress_iteration ON learning_progress(iteration);

-- Path Evaluations Table
CREATE TABLE IF NOT EXISTS path_evaluations (
  id TEXT PRIMARY KEY,
  path_id TEXT NOT NULL REFERENCES learning_paths(id),
  evaluation_type TEXT NOT NULL,
  accuracy REAL NOT NULL,
  precision REAL,
  recall REAL,
  f1_score REAL,
  mae REAL,
  rmse REAL,
  metrics TEXT,
  evaluated_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_path_evaluations_path_id ON path_evaluations(path_id);
CREATE INDEX IF NOT EXISTS idx_path_evaluations_type ON path_evaluations(evaluation_type);

-- ACO Pheromones Table
CREATE TABLE IF NOT EXISTS aco_pheromones (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  model_type TEXT NOT NULL,
  feature_path TEXT NOT NULL,
  pheromone_level REAL NOT NULL DEFAULT 1.0,
  visit_count INTEGER NOT NULL DEFAULT 0,
  avg_score REAL,
  last_updated INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_aco_pheromones_symbol ON aco_pheromones(symbol);
CREATE INDEX IF NOT EXISTS idx_aco_pheromones_model_type ON aco_pheromones(model_type);

-- RL States Table
CREATE TABLE IF NOT EXISTS rl_states (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  model_type TEXT NOT NULL,
  state TEXT NOT NULL,
  action TEXT NOT NULL,
  q_value REAL NOT NULL,
  reward REAL NOT NULL,
  next_state TEXT,
  episode INTEGER NOT NULL,
  step INTEGER NOT NULL,
  timestamp INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_rl_states_symbol ON rl_states(symbol);
CREATE INDEX IF NOT EXISTS idx_rl_states_episode ON rl_states(episode);

