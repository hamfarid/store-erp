-- Migration: Expert Opinions & Web Scraping System
-- Created: 2025-01-18

-- Expert Opinions Table
CREATE TABLE IF NOT EXISTS expert_opinions (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT,
  expert_name TEXT,
  expert_credibility REAL DEFAULT 0.5,
  opinion_text TEXT NOT NULL,
  sentiment TEXT NOT NULL,
  sentiment_score REAL NOT NULL,
  confidence REAL,
  target_price REAL,
  timeframe TEXT,
  tags TEXT,
  language TEXT DEFAULT 'en',
  scraped_at INTEGER NOT NULL DEFAULT (unixepoch()),
  analyzed_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_expert_opinions_symbol ON expert_opinions(symbol);
CREATE INDEX IF NOT EXISTS idx_expert_opinions_sentiment ON expert_opinions(sentiment);
CREATE INDEX IF NOT EXISTS idx_expert_opinions_scraped_at ON expert_opinions(scraped_at DESC);

-- Social Sentiment Table
CREATE TABLE IF NOT EXISTS social_sentiment (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  platform TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  bullish_count INTEGER NOT NULL DEFAULT 0,
  bearish_count INTEGER NOT NULL DEFAULT 0,
  neutral_count INTEGER NOT NULL DEFAULT 0,
  total_mentions INTEGER NOT NULL DEFAULT 0,
  sentiment_score REAL NOT NULL,
  volume_change REAL,
  trending_score REAL,
  top_keywords TEXT,
  influencer_opinions TEXT,
  collected_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_social_sentiment_symbol ON social_sentiment(symbol);
CREATE INDEX IF NOT EXISTS idx_social_sentiment_platform ON social_sentiment(platform);
CREATE INDEX IF NOT EXISTS idx_social_sentiment_collected_at ON social_sentiment(collected_at DESC);

-- Scraping Jobs Table
CREATE TABLE IF NOT EXISTS scraping_jobs (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  job_type TEXT NOT NULL,
  sources TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  items_scraped INTEGER DEFAULT 0,
  items_failed INTEGER DEFAULT 0,
  error_message TEXT,
  started_at INTEGER,
  completed_at INTEGER,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_scraping_jobs_symbol ON scraping_jobs(symbol);
CREATE INDEX IF NOT EXISTS idx_scraping_jobs_status ON scraping_jobs(status);

-- Opinion Analysis Cache Table
CREATE TABLE IF NOT EXISTS opinion_analysis_cache (
  id TEXT PRIMARY KEY,
  opinion_id TEXT NOT NULL REFERENCES expert_opinions(id),
  analysis_type TEXT NOT NULL,
  result TEXT NOT NULL,
  model TEXT,
  tokens_used INTEGER,
  cached_at INTEGER NOT NULL DEFAULT (unixepoch()),
  expires_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_opinion_analysis_cache_opinion_id ON opinion_analysis_cache(opinion_id);
CREATE INDEX IF NOT EXISTS idx_opinion_analysis_cache_expires_at ON opinion_analysis_cache(expires_at);

-- Sentiment Trends Table
CREATE TABLE IF NOT EXISTS sentiment_trends (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  date TEXT NOT NULL,
  expert_sentiment REAL,
  social_sentiment REAL,
  news_sentiment REAL,
  overall_sentiment REAL NOT NULL,
  bullish_percentage REAL,
  bearish_percentage REAL,
  volume_score REAL,
  confidence_score REAL,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_sentiment_trends_symbol ON sentiment_trends(symbol);
CREATE INDEX IF NOT EXISTS idx_sentiment_trends_date ON sentiment_trends(date DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_sentiment_trends_symbol_date ON sentiment_trends(symbol, date);

