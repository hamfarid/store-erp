-- Migration: Add Learning Control Dashboard Tables
-- Date: 2025-01-18
-- Description: Creates tables for Learning & Search Control Dashboard

-- ==================== Search Keywords Table ====================
CREATE TABLE IF NOT EXISTS search_keywords (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  keyword VARCHAR(255) NOT NULL UNIQUE,
  category ENUM('political', 'economic', 'geopolitical', 'monetary_policy', 'market', 'commodity', 'general') NOT NULL,
  priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  enabled BOOLEAN DEFAULT TRUE,
  search_count INT DEFAULT 0,
  last_used TIMESTAMP NULL,
  results_found INT DEFAULT 0,
  created_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_category (category),
  INDEX idx_priority (priority),
  INDEX idx_enabled (enabled)
);

-- ==================== Search Sources Table ====================
CREATE TABLE IF NOT EXISTS search_sources (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type ENUM('search_engine', 'news_site', 'financial_site', 'government_site', 'social_media', 'api') NOT NULL,
  url TEXT NOT NULL,
  enabled BOOLEAN DEFAULT TRUE,
  config JSON,
  headers JSON,
  rate_limit INT DEFAULT 60,
  request_count INT DEFAULT 0,
  success_count INT DEFAULT 0,
  error_count INT DEFAULT 0,
  last_used TIMESTAMP NULL,
  last_error TEXT,
  avg_response_time INT,
  reliability INT DEFAULT 100,
  created_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_type (type),
  INDEX idx_enabled (enabled)
);

-- ==================== Learning Operations Table ====================
CREATE TABLE IF NOT EXISTS learning_operations (
  id VARCHAR(64) PRIMARY KEY,
  type ENUM('prediction_comparison', 'pattern_detection', 'correlation_analysis', 'model_training', 'insight_generation', 'adjustment_application') NOT NULL,
  status ENUM('pending', 'running', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
  progress INT DEFAULT 0,
  current_step VARCHAR(255),
  total_steps INT,
  input JSON,
  output JSON,
  error TEXT,
  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  duration INT,
  results_count INT DEFAULT 0,
  insights_generated INT DEFAULT 0,
  adjustments_proposed INT DEFAULT 0,
  triggered_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_type (type),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);

-- ==================== Search Operations Table ====================
CREATE TABLE IF NOT EXISTS search_operations (
  id VARCHAR(64) PRIMARY KEY,
  type ENUM('keyword_search', 'event_discovery', 'news_scraping', 'sentiment_analysis', 'entity_extraction') NOT NULL,
  status ENUM('pending', 'running', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
  keywords JSON NOT NULL,
  sources JSON NOT NULL,
  date_range JSON,
  progress INT DEFAULT 0,
  current_source VARCHAR(255),
  sources_processed INT DEFAULT 0,
  total_sources INT,
  results_found INT DEFAULT 0,
  events_created INT DEFAULT 0,
  error TEXT,
  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  duration INT,
  triggered_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_type (type),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);

-- ==================== Operation Logs Table ====================
CREATE TABLE IF NOT EXISTS operation_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  operation_id VARCHAR(64) NOT NULL,
  operation_type ENUM('learning', 'search') NOT NULL,
  level ENUM('debug', 'info', 'warning', 'error') NOT NULL,
  message TEXT NOT NULL,
  data JSON,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_operation_id (operation_id),
  INDEX idx_level (level),
  INDEX idx_timestamp (timestamp)
);

