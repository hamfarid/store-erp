/**
 * FILE: drizzle/schema-learning-control.ts
 * PURPOSE: Database schema for Learning & Search Control Dashboard
 * OWNER: Backend Team
 * RELATED: server/db/learning-control.ts, server/routers/learning-control.ts
 * LAST-AUDITED: 2025-01-18
 */

import {
  mysqlTable,
  varchar,
  text,
  mysqlEnum,
  timestamp,
  json,
  bigint,
  boolean,
  int,
  index,
} from "drizzle-orm/mysql-core";

// ==================== Search Keywords ====================

export const searchKeywords = mysqlTable(
  "search_keywords",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    keyword: varchar("keyword", { length: 255 }).notNull().unique(),
    category: mysqlEnum("category", [
      "political",
      "economic",
      "geopolitical",
      "monetary_policy",
      "market",
      "commodity",
      "general",
    ]).notNull(),
    priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium"),
    enabled: boolean("enabled").default(true),
    
    // Usage stats
    searchCount: int("search_count").default(0),
    lastUsed: timestamp("last_used"),
    resultsFound: int("results_found").default(0),
    
    // Metadata
    createdBy: varchar("created_by", { length: 64 }),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    categoryIdx: index("idx_category").on(table.category),
    priorityIdx: index("idx_priority").on(table.priority),
    enabledIdx: index("idx_enabled").on(table.enabled),
  })
);

export type SearchKeyword = typeof searchKeywords.$inferSelect;
export type InsertSearchKeyword = typeof searchKeywords.$inferInsert;

// ==================== Search Sources ====================

export const searchSources = mysqlTable(
  "search_sources",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    name: varchar("name", { length: 255 }).notNull(),
    type: mysqlEnum("type", [
      "search_engine",
      "news_site",
      "financial_site",
      "government_site",
      "social_media",
      "api",
    ]).notNull(),
    url: text("url").notNull(),
    enabled: boolean("enabled").default(true),
    
    // Configuration
    config: json("config"),
    headers: json("headers"),
    rateLimit: int("rate_limit").default(60), // requests per minute
    
    // Stats
    requestCount: int("request_count").default(0),
    successCount: int("success_count").default(0),
    errorCount: int("error_count").default(0),
    lastUsed: timestamp("last_used"),
    lastError: text("last_error"),
    
    // Performance
    avgResponseTime: int("avg_response_time"), // milliseconds
    reliability: int("reliability").default(100), // 0-100%
    
    // Metadata
    createdBy: varchar("created_by", { length: 64 }),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    typeIdx: index("idx_type").on(table.type),
    enabledIdx: index("idx_enabled").on(table.enabled),
  })
);

export type SearchSource = typeof searchSources.$inferSelect;
export type InsertSearchSource = typeof searchSources.$inferInsert;

// ==================== Learning Operations ====================

export const learningOperations = mysqlTable(
  "learning_operations",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    type: mysqlEnum("type", [
      "prediction_comparison",
      "pattern_detection",
      "correlation_analysis",
      "model_training",
      "insight_generation",
      "adjustment_application",
    ]).notNull(),
    status: mysqlEnum("status", [
      "pending",
      "running",
      "completed",
      "failed",
      "cancelled",
    ]).default("pending"),
    
    // Progress
    progress: int("progress").default(0), // 0-100%
    currentStep: varchar("current_step", { length: 255 }),
    totalSteps: int("total_steps"),
    
    // Input/Output
    input: json("input"),
    output: json("output"),
    error: text("error"),
    
    // Timing
    startedAt: timestamp("started_at"),
    completedAt: timestamp("completed_at"),
    duration: int("duration"), // seconds
    
    // Results
    resultsCount: int("results_count").default(0),
    insightsGenerated: int("insights_generated").default(0),
    adjustmentsProposed: int("adjustments_proposed").default(0),
    
    // Metadata
    triggeredBy: varchar("triggered_by", { length: 64 }),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    typeIdx: index("idx_type").on(table.type),
    statusIdx: index("idx_status").on(table.status),
    createdAtIdx: index("idx_created_at").on(table.createdAt),
  })
);

export type LearningOperation = typeof learningOperations.$inferSelect;
export type InsertLearningOperation = typeof learningOperations.$inferInsert;

// ==================== Search Operations ====================

export const searchOperations = mysqlTable(
  "search_operations",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    type: mysqlEnum("type", [
      "keyword_search",
      "event_discovery",
      "news_scraping",
      "sentiment_analysis",
      "entity_extraction",
    ]).notNull(),
    status: mysqlEnum("status", [
      "pending",
      "running",
      "completed",
      "failed",
      "cancelled",
    ]).default("pending"),
    
    // Search params
    keywords: json("keywords").notNull(),
    sources: json("sources").notNull(),
    dateRange: json("date_range"),
    
    // Progress
    progress: int("progress").default(0), // 0-100%
    currentSource: varchar("current_source", { length: 255 }),
    sourcesProcessed: int("sources_processed").default(0),
    totalSources: int("total_sources"),
    
    // Results
    resultsFound: int("results_found").default(0),
    eventsCreated: int("events_created").default(0),
    error: text("error"),
    
    // Timing
    startedAt: timestamp("started_at"),
    completedAt: timestamp("completed_at"),
    duration: int("duration"), // seconds
    
    // Metadata
    triggeredBy: varchar("triggered_by", { length: 64 }),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    typeIdx: index("idx_type").on(table.type),
    statusIdx: index("idx_status").on(table.status),
    createdAtIdx: index("idx_created_at").on(table.createdAt),
  })
);

export type SearchOperation = typeof searchOperations.$inferSelect;
export type InsertSearchOperation = typeof searchOperations.$inferInsert;

// ==================== Operation Logs ====================

export const operationLogs = mysqlTable(
  "operation_logs",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    operationId: varchar("operation_id", { length: 64 }).notNull(),
    operationType: mysqlEnum("operation_type", ["learning", "search"]).notNull(),
    
    level: mysqlEnum("level", ["debug", "info", "warning", "error"]).notNull(),
    message: text("message").notNull(),
    data: json("data"),
    
    timestamp: timestamp("timestamp").defaultNow(),
  },
  (table) => ({
    operationIdIdx: index("idx_operation_id").on(table.operationId),
    levelIdx: index("idx_level").on(table.level),
    timestampIdx: index("idx_timestamp").on(table.timestamp),
  })
);

export type OperationLog = typeof operationLogs.$inferSelect;
export type InsertOperationLog = typeof operationLogs.$inferInsert;

