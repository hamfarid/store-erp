import { int, mysqlTable, varchar, text, timestamp } from "drizzle-orm/mysql-core";

/**
 * Permissions table - defines available permissions in the system
 */
export const permissions = mysqlTable("permissions", {
  id: int("id").primaryKey().autoincrement(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  description: text("description"),
  category: varchar("category", { length: 100 }), // e.g., "assets", "predictions", "users"
  createdAt: timestamp("createdAt").defaultNow(),
});

/**
 * User Permissions junction table - assigns permissions to users
 */
export const userPermissions = mysqlTable("user_permissions", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  permissionId: int("permissionId").notNull(),
  grantedBy: varchar("grantedBy", { length: 64 }), // admin who granted the permission
  grantedAt: timestamp("grantedAt").defaultNow(),
});

export type Permission = typeof permissions.$inferSelect;
export type InsertPermission = typeof permissions.$inferInsert;
export type UserPermission = typeof userPermissions.$inferSelect;
export type InsertUserPermission = typeof userPermissions.$inferInsert;

