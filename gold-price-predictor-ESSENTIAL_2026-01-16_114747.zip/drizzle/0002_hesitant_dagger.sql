CREATE TABLE `breakEvenPoints` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`userId` text NOT NULL,
	`assetId` integer NOT NULL,
	`buyPrice` real NOT NULL,
	`quantity` real NOT NULL,
	`fees` real DEFAULT 0 NOT NULL,
	`breakEvenPrice` real NOT NULL,
	`currentPrice` real,
	`profitLoss` real,
	`profitLossPercent` real,
	`purchaseDate` integer NOT NULL,
	`createdAt` integer NOT NULL,
	`updatedAt` integer NOT NULL,
	FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `breakoutPoints` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assetId` integer NOT NULL,
	`pointType` text NOT NULL,
	`price` real NOT NULL,
	`strength` real NOT NULL,
	`confidence` real NOT NULL,
	`identifiedAt` integer NOT NULL,
	`validUntil` integer,
	`breached` integer DEFAULT false NOT NULL,
	`breachedAt` integer,
	`createdAt` integer NOT NULL,
	FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `tradingSignals` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assetId` integer NOT NULL,
	`signalType` text NOT NULL,
	`price` real NOT NULL,
	`targetPrice` real,
	`stopLoss` real,
	`strength` real NOT NULL,
	`confidence` real NOT NULL,
	`reason` text,
	`timestamp` integer NOT NULL,
	`expiresAt` integer,
	`isActive` integer DEFAULT true NOT NULL,
	`createdAt` integer NOT NULL,
	FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON UPDATE no action ON DELETE cascade
);
