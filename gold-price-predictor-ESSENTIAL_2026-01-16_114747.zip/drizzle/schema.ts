import {
  mysqlTable,
  varchar,
  boolean,
  timestamp,
  int,
  text,
  decimal,
  mysqlEnum,
  index,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const accessCodes = mysqlTable("access_codes", {
  id: int("id").primaryKey().autoincrement(),
  code: varchar("code", { length: 255 }).notNull().unique(),
  userId: varchar("userId", { length: 64 }),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const users = mysqlTable("users", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: text("passwordHash"), // For local authentication
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow(),
  // Two-Factor Authentication fields
  twoFactorSecret: text("two_factor_secret"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  twoFactorBackupCodes: text("two_factor_backup_codes"), // JSON array of hashed codes
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Import logging tables
export * from "./schema-logs";

// Import notifications table
export * from "./schema-notifications";

// Import trading signals and breakout points
export * from "./schema-trading";

// Import permissions
export * from "./schema-permissions";

// Import AI assistants
export * from "./schema-ai";

// Import AI scheduled tasks
export * from "./schema-ai-tasks";

// Import portfolio management
export * from "./schema-portfolio";

// Import learning control schema
export * from "./schema-learning-control";

// Import events schema
export * from "./schema-events";

/**
 * Assets table - stores information about supported assets
 */
export const assets = mysqlTable(
  "assets",
  {
    id: int("id").primaryKey().autoincrement(),
    name: varchar("name", { length: 255 }).notNull(),
    symbol: varchar("symbol", { length: 50 }).notNull(),
    type: varchar("type", { length: 50 }),
    yahooSymbol: varchar("yahooSymbol", { length: 50 }),
    description: text("description"),
    category: mysqlEnum("category", [
      "commodity",
      "crypto",
      "currency",
      "stock",
    ]).notNull(),
    currentPrice: decimal("currentPrice", { precision: 20, scale: 8 }),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow(),
    updatedAt: timestamp("updatedAt").defaultNow(),
  },
  table => ({
    symbolIdx: index("assets_symbol_idx").on(table.symbol),
    categoryIdx: index("assets_category_idx").on(table.category),
  })
);

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = typeof assets.$inferInsert;

// Email Settings
export const emailSettings = mysqlTable("email_settings", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
  smtpHost: varchar("smtpHost", { length: 255 }),
  smtpPort: int("smtpPort"),
  smtpUser: varchar("smtpUser", { length: 255 }),
  smtpPassword: varchar("smtpPassword", { length: 255 }),
  fromEmail: varchar("fromEmail", { length: 320 }),
  fromName: varchar("fromName", { length: 255 }),
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow(),
});

export type EmailSettings = typeof emailSettings.$inferSelect;
export type InsertEmailSettings = typeof emailSettings.$inferInsert;

/**
 * Predictions table - stores price predictions for assets
 */
export const predictions = mysqlTable(
  "predictions",
  {
    id: int("id").primaryKey().autoincrement(),
    assetId: int("assetId").notNull(),
    predictionDate: timestamp("predictionDate").notNull(),
    targetDate: timestamp("targetDate").notNull(),
    daysAhead: int("daysAhead").notNull(),
    currentPrice: decimal("currentPrice", {
      precision: 20,
      scale: 8,
    }).notNull(),
    predictedPrice: decimal("predictedPrice", {
      precision: 20,
      scale: 8,
    }).notNull(),
    confidenceLower: decimal("confidenceLower", { precision: 20, scale: 8 }),
    confidenceUpper: decimal("confidenceUpper", { precision: 20, scale: 8 }),
    modelType: varchar("modelType", { length: 50 }).notNull(),
    accuracy: decimal("accuracy", { precision: 10, scale: 6 }),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  table => ({
    assetIdIdx: index("predictions_asset_id_idx").on(table.assetId),
    createdAtIdx: index("predictions_created_at_idx").on(table.createdAt),
    targetDateIdx: index("predictions_target_date_idx").on(table.targetDate),
  })
);

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

/**
 * Alerts table - stores user-defined price alerts
 */
export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").primaryKey().autoincrement(),
    userId: varchar("userId", { length: 64 }).notNull(),
    assetId: int("assetId").notNull(),
    alertType: mysqlEnum("alertType", ["above", "below", "change"]).notNull(),
    targetPrice: decimal("targetPrice", { precision: 20, scale: 8 }),
    changePercent: decimal("changePercent", { precision: 10, scale: 4 }),
    isActive: boolean("isActive").default(true).notNull(),
    isTriggered: boolean("isTriggered").default(false).notNull(),
    triggeredAt: timestamp("triggeredAt"),
    notificationMethod: mysqlEnum("notificationMethod", [
      "email",
      "push",
      "both",
    ])
      .default("email")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  table => ({
    assetIdIdx: index("alerts_asset_id_idx").on(table.assetId),
    userIdIdx: index("alerts_user_id_idx").on(table.userId),
    isActiveIdx: index("alerts_is_active_idx").on(table.isActive),
  })
);

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

/**
 * Historical prices table - stores actual prices for comparison
 */
export const historicalPrices = mysqlTable(
  "historicalPrices",
  {
    id: int("id").primaryKey().autoincrement(),
    assetId: int("assetId").notNull(),
    date: timestamp("date").notNull(),
    price: decimal("price", { precision: 20, scale: 8 }).notNull(),
    high: decimal("high", { precision: 20, scale: 8 }),
    low: decimal("low", { precision: 20, scale: 8 }),
    volume: decimal("volume", { precision: 30, scale: 2 }),
    change: decimal("change", { precision: 20, scale: 8 }),
    changePercent: decimal("changePercent", { precision: 10, scale: 4 }),
    timestamp: timestamp("timestamp").notNull(),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  table => ({
    assetIdIdx: index("historical_prices_asset_id_idx").on(table.assetId),
    dateIdx: index("historical_prices_date_idx").on(table.date),
    timestampIdx: index("historical_prices_timestamp_idx").on(table.timestamp),
  })
);

export type HistoricalPrice = typeof historicalPrices.$inferSelect;
export type InsertHistoricalPrice = typeof historicalPrices.$inferInsert;
