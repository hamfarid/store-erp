/**
 * FILE: drizzle/schema-events.ts
 * PURPOSE: Database schema for Events & Learning subsystem
 * OWNER: Backend Team
 * RELATED: server/services/events/eventsDb.ts, server/routers/events.ts
 * LAST-AUDITED: 2025-12-18
 */

import {
  mysqlTable,
  varchar,
  text,
  mysqlEnum,
  timestamp,
  json,
  bigint,
  boolean,
  int,
  decimal,
  index,
} from "drizzle-orm/mysql-core";

// ==================== Events ====================

export const events = mysqlTable(
  "events",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description"),
    eventType: mysqlEnum("event_type", [
      "political",
      "economic",
      "geopolitical",
      "monetary_policy",
      "market",
      "commodity",
      "natural_disaster",
      "war",
      "sanctions",
      "other",
    ]).notNull(),
    eventDate: timestamp("event_date").notNull(),
    source: varchar("source", { length: 255 }),
    sourceUrl: text("source_url"),
    
    // Metadata
    severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).default("medium"),
    verified: boolean("verified").default(false),
    tags: json("tags"), // Array of strings
    
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    eventTypeIdx: index("idx_event_type").on(table.eventType),
    eventDateIdx: index("idx_event_date").on(table.eventDate),
    severityIdx: index("idx_severity").on(table.severity),
    createdAtIdx: index("idx_created_at").on(table.createdAt),
  })
);

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

// ==================== Event Analyses ====================

export const eventAnalyses = mysqlTable(
  "event_analyses",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    eventId: varchar("event_id", { length: 64 }).notNull(),
    
    // Analysis results
    sentiment: mysqlEnum("sentiment", ["positive", "neutral", "negative"]),
    sentimentScore: decimal("sentiment_score", { precision: 5, scale: 2 }), // -1 to 1
    impactScore: decimal("impact_score", { precision: 5, scale: 2 }), // 0 to 10
    confidence: decimal("confidence", { precision: 5, scale: 2 }), // 0 to 1
    
    // Extracted data
    entities: json("entities"), // Array of {type, name, relevance}
    keywords: json("keywords"), // Array of strings
    summary: text("summary"),
    
    // Analysis metadata
    analyzerVersion: varchar("analyzer_version", { length: 50 }),
    analysisDate: timestamp("analysis_date").defaultNow(),
    
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    eventIdIdx: index("idx_event_id").on(table.eventId),
    sentimentIdx: index("idx_sentiment").on(table.sentiment),
    analysisDateIdx: index("idx_analysis_date").on(table.analysisDate),
  })
);

export type EventAnalysis = typeof eventAnalyses.$inferSelect;
export type InsertEventAnalysis = typeof eventAnalyses.$inferInsert;

// ==================== Historical Prices (for event impact analysis) ====================
// Note: historicalPrices table is defined in schema.ts
// We import it here to ensure proper type references for FK relationships
import { historicalPrices } from "./schema";

// ==================== Event Price Impacts ====================

export const eventPriceImpacts = mysqlTable(
  "event_price_impacts",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    eventId: varchar("event_id", { length: 64 }).notNull(),
    historicalPriceId: bigint("historical_price_id", { mode: "number" }).notNull(),
    assetId: int("asset_id").notNull(),
    
    // Impact metrics
    priceChange: decimal("price_change", { precision: 20, scale: 8 }),
    priceChangePercent: decimal("price_change_percent", { precision: 10, scale: 4 }),
    timeToImpact: int("time_to_impact"), // seconds from event to price change
    
    // Correlation
    correlationScore: decimal("correlation_score", { precision: 5, scale: 2 }), // -1 to 1
    
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    eventIdIdx: index("idx_event_id_impact").on(table.eventId),
    historicalPriceIdIdx: index("idx_historical_price_id").on(table.historicalPriceId),
    assetIdIdx: index("idx_asset_id_impact").on(table.assetId),
  })
);

export type EventPriceImpact = typeof eventPriceImpacts.$inferSelect;
export type InsertEventPriceImpact = typeof eventPriceImpacts.$inferInsert;

// ==================== Predictions (extended for learning) ====================
// Note: Base predictions table exists in schema.ts, this is for learning-specific extensions

// ==================== Prediction Comparisons ====================

export const predictionComparisons = mysqlTable(
  "prediction_comparisons",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    predictionId: int("prediction_id").notNull(),
    
    // Comparison data
    actualPrice: decimal("actual_price", { precision: 20, scale: 8 }),
    predictedPrice: decimal("predicted_price", { precision: 20, scale: 8 }),
    error: decimal("error", { precision: 20, scale: 8 }),
    errorPercent: decimal("error_percent", { precision: 10, scale: 4 }),
    
    // Accuracy metrics
    accuracy: decimal("accuracy", { precision: 10, scale: 6 }), // 0 to 1
    withinConfidence: boolean("within_confidence"),
    
    // Comparison metadata
    comparedAt: timestamp("compared_at").defaultNow(),
    modelVersion: varchar("model_version", { length: 50 }),
    
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    predictionIdIdx: index("idx_prediction_id").on(table.predictionId),
    comparedAtIdx: index("idx_compared_at").on(table.comparedAt),
  })
);

export type PredictionComparison = typeof predictionComparisons.$inferSelect;
export type InsertPredictionComparison = typeof predictionComparisons.$inferInsert;

// ==================== Learning Insights ====================

export const learningInsights = mysqlTable(
  "learning_insights",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    
    // Insight data
    type: mysqlEnum("type", [
      "pattern",
      "correlation",
      "anomaly",
      "trend",
      "prediction_accuracy",
      "model_performance",
    ]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description"),
    
    // Insight metrics
    confidence: decimal("confidence", { precision: 5, scale: 2 }), // 0 to 1
    impact: mysqlEnum("impact", ["low", "medium", "high", "critical"]).default("medium"),
    
    // Data
    data: json("data"), // Flexible payload
    relatedPredictions: json("related_predictions"), // Array of prediction IDs
    relatedEvents: json("related_events"), // Array of event IDs
    
    // Status
    status: mysqlEnum("status", ["pending", "reviewed", "applied", "rejected"]).default("pending"),
    reviewedBy: varchar("reviewed_by", { length: 64 }),
    reviewedAt: timestamp("reviewed_at"),
    
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    typeIdx: index("idx_insight_type").on(table.type),
    statusIdx: index("idx_insight_status").on(table.status),
    createdAtIdx: index("idx_insight_created_at").on(table.createdAt),
  })
);

export type LearningInsight = typeof learningInsights.$inferSelect;
export type InsertLearningInsight = typeof learningInsights.$inferInsert;

// ==================== Model Adjustments ====================

export const modelAdjustments = mysqlTable(
  "model_adjustments",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    insightId: bigint("insight_id", { mode: "number" }).notNull(),
    
    // Adjustment data
    adjustmentType: mysqlEnum("adjustment_type", [
      "parameter_tuning",
      "feature_addition",
      "feature_removal",
      "weight_adjustment",
      "threshold_change",
      "algorithm_change",
    ]).notNull(),
    description: text("description"),
    
    // Adjustment details
    parameters: json("parameters"), // Map of parameter changes
    modelVersion: varchar("model_version", { length: 50 }),
    previousVersion: varchar("previous_version", { length: 50 }),
    
    // Status
    status: mysqlEnum("status", ["proposed", "approved", "applied", "reverted", "rejected"]).default("proposed"),
    appliedBy: varchar("applied_by", { length: 64 }),
    appliedAt: timestamp("applied_at"),
    revertedBy: varchar("reverted_by", { length: 64 }),
    revertedAt: timestamp("reverted_at"),
    
    // Results
    performanceBefore: json("performance_before"),
    performanceAfter: json("performance_after"),
    improvement: decimal("improvement", { precision: 10, scale: 4 }), // Percentage
    
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    insightIdIdx: index("idx_insight_id").on(table.insightId),
    statusIdx: index("idx_adjustment_status").on(table.status),
    createdAtIdx: index("idx_adjustment_created_at").on(table.createdAt),
  })
);

export type ModelAdjustment = typeof modelAdjustments.$inferSelect;
export type InsertModelAdjustment = typeof modelAdjustments.$inferInsert;

// ==================== Chart Snapshots ====================

export const chartSnapshots = mysqlTable(
  "chart_snapshots",
  {
    id: bigint("id", { mode: "number" }).primaryKey().autoincrement(),
    
    // Snapshot metadata
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    chartType: mysqlEnum("chart_type", [
      "price_history",
      "prediction_comparison",
      "event_impact",
      "correlation",
      "performance",
    ]).notNull(),
    
    // Chart data
    data: json("data").notNull(), // Chart configuration + data
    config: json("config"), // Chart.js or other config
    
    // Related entities
    relatedAssetId: int("related_asset_id"),
    relatedEventId: varchar("related_event_id", { length: 64 }),
    relatedPredictionId: int("related_prediction_id"),
    
    // Metadata
    createdBy: varchar("created_by", { length: 64 }),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    chartTypeIdx: index("idx_chart_type").on(table.chartType),
    relatedAssetIdIdx: index("idx_related_asset_id").on(table.relatedAssetId),
    createdAtIdx: index("idx_chart_created_at").on(table.createdAt),
  })
);

export type ChartSnapshot = typeof chartSnapshots.$inferSelect;
export type InsertChartSnapshot = typeof chartSnapshots.$inferInsert;

