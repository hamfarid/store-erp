#!/usr/bin/env node
/**
 * Database Seeding Script
 * Seeds the database with real market data from Friday
 */

import { drizzle } from 'drizzle-orm/mysql2';
import { assets, historicalPrices, users, predictions } from '../drizzle/schema.js';
import { readFileSync } from 'fs';

// Read market data
const marketData = JSON.parse(readFileSync('/tmp/friday_market_data.json', 'utf-8'));

console.log('🌱 Starting database seeding...\n');

// Check if DATABASE_URL is set
if (!process.env.DATABASE_URL) {
  console.error('❌ ERROR: DATABASE_URL is not set!');
  console.error('Please configure DATABASE_URL in Settings → Secrets');
  process.exit(1);
}

const db = drizzle(process.env.DATABASE_URL);

async function seedDatabase() {
  try {
    console.log('📊 Seeding users table...');
    // Seed demo user
    await db.insert(users).values({
      id: 'demo-user-1',
      name: 'Demo User',
      email: 'demo@assetpredictor.com',
      role: 'user',
      loginMethod: 'oauth',
    }).onDuplicateKeyUpdate({ set: { lastSignedIn: new Date() } });
    
    console.log('✅ Users seeded\n');

    console.log('📊 Seeding assets table...');
    // Seed assets from market data
    const assetValues = marketData.map((item, index) => ({
      id: index + 1,
      symbol: item.symbol,
      name: item.name,
      assetType: item.type,
      exchange: item.exchange,
      currency: item.currency,
      currentPrice: item.close.toString(),
      sector: item.type === 'stock' ? 'Technology' : item.type === 'crypto' ? 'Cryptocurrency' : 'Commodities',
      description: `${item.name} - ${item.exchange}`,
      updatedAt: new Date(),
    }));

    for (const asset of assetValues) {
      await db.insert(assets).values(asset)
        .onDuplicateKeyUpdate({ set: { 
          currentPrice: asset.currentPrice,
          updatedAt: asset.updatedAt 
        } });
    }
    
    console.log(`✅ ${assetValues.length} assets seeded\n`);

    console.log('📊 Seeding historical_prices table...');
    // Seed historical prices
    const priceValues = marketData.map((item, index) => ({
      assetId: index + 1,
      date: new Date(item.date),
      price: item.close.toString(),
      high: item.high ? item.high.toString() : null,
      low: item.low ? item.low.toString() : null,
      open: item.open ? item.open.toString() : null,
      volume: item.volume ? item.volume.toString() : null,
      change: '0.00',
      changePercent: '0.00',
      timestamp: new Date(item.timestamp * 1000),
    }));

    for (const price of priceValues) {
      await db.insert(historicalPrices).values(price);
    }
    
    console.log(`✅ ${priceValues.length} historical prices seeded\n`);

    console.log('📊 Seeding predictions table...');
    // Seed sample predictions
    const predictionValues = marketData.slice(0, 5).map((item, index) => ({
      assetId: index + 1,
      userId: 'demo-user-1',
      modelType: ['simple', 'advanced', 'ensemble'][index % 3],
      horizon: ['short', 'medium', 'long'][index % 3],
      predictedPrice: (item.close * (1 + (Math.random() * 0.1 - 0.05))).toFixed(2),
      confidenceLevel: (0.85 + Math.random() * 0.1).toFixed(2),
      predictionDate: new Date(Date.now() + (index + 1) * 24 * 60 * 60 * 1000),
      accuracy: (0.80 + Math.random() * 0.15).toFixed(2),
      metadata: JSON.stringify({
        features: ['price', 'volume', 'sentiment'],
        model_version: '1.0',
      }),
    }));

    for (const prediction of predictionValues) {
      await db.insert(predictions).values(prediction);
    }
    
    console.log(`✅ ${predictionValues.length} predictions seeded\n`);

    console.log('🎉 Database seeding completed successfully!');
    console.log('\n📈 Summary:');
    console.log(`  - Users: 1`);
    console.log(`  - Assets: ${assetValues.length}`);
    console.log(`  - Historical Prices: ${priceValues.length}`);
    console.log(`  - Predictions: ${predictionValues.length}`);
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    throw error;
  }
}

// Run seeding
seedDatabase()
  .then(() => {
    console.log('\n✅ Seeding script completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Seeding script failed:', error);
    process.exit(1);
  });

