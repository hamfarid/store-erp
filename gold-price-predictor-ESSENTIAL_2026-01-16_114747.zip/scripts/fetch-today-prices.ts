// FILE: scripts/fetch-today-prices.ts | PURPOSE: Fetch today's prices for all assets | OWNER: Data Team | LAST-AUDITED: 2025-11-25

import axios from 'axios';
import { getPool } from '../server/db-postgres';

interface YahooQuote {
  symbol: string;
  regularMarketPrice: number;
  regularMarketChange: number;
  regularMarketChangePercent: number;
  regularMarketTime: number;
  regularMarketOpen: number;
  regularMarketDayHigh: number;
  regularMarketDayLow: number;
  regularMarketVolume: number;
}

async function fetchTodayPrices() {
  console.log('\n💰 جلب أسعار اليوم...\n');
  console.log('='.repeat(80));

  const pool = getPool();

  try {
    // Get all active assets
    const assetsResult = await pool.query(
      'SELECT id, symbol, name FROM assets WHERE is_active = true ORDER BY symbol'
    );

    const assets = assetsResult.rows;
    console.log(`\n📊 تم العثور على ${assets.length} أصول نشطة\n`);

    for (const asset of assets) {
      try {
        console.log(`\n🔍 جلب سعر ${asset.name} (${asset.symbol})...`);

        // Fetch from Yahoo Finance
        const url = `https://query1.finance.yahoo.com/v8/finance/chart/${asset.symbol}`;
        const params = {
          interval: '1d',
          range: '1d',
        };

        const response = await axios.get(url, { params, timeout: 10000 });
        const result = response.data.chart.result[0];

        if (!result) {
          console.log(`   ⚠️  لا توجد بيانات متاحة`);
          continue;
        }

        const meta = result.meta;
        const quote = result.indicators.quote[0];
        const timestamp = result.timestamp[result.timestamp.length - 1];

        const currentPrice = meta.regularMarketPrice || quote.close[quote.close.length - 1];
        const open = quote.open[quote.open.length - 1];
        const high = quote.high[quote.high.length - 1];
        const low = quote.low[quote.low.length - 1];
        const volume = quote.volume[quote.volume.length - 1];

        const change = currentPrice - open;
        const changePercent = (change / open) * 100;

        // Display current price
        console.log(`   💵 السعر الحالي: $${currentPrice.toFixed(2)}`);
        console.log(`   📈 الافتتاح: $${open.toFixed(2)}`);
        console.log(`   ⬆️  الأعلى: $${high.toFixed(2)}`);
        console.log(`   ⬇️  الأدنى: $${low.toFixed(2)}`);
        console.log(`   📊 الحجم: ${volume.toLocaleString()}`);
        
        const changeIcon = change >= 0 ? '🟢' : '🔴';
        const changeSign = change >= 0 ? '+' : '';
        console.log(`   ${changeIcon} التغيير: ${changeSign}$${change.toFixed(2)} (${changeSign}${changePercent.toFixed(2)}%)`);

        // Insert into database
        const priceId = `price_${asset.id}_${timestamp * 1000}`;
        await pool.query(
          `INSERT INTO price_history (id, asset_id, timestamp, open, high, low, close, volume, source, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
           ON CONFLICT (id) DO UPDATE SET
             open = EXCLUDED.open,
             high = EXCLUDED.high,
             low = EXCLUDED.low,
             close = EXCLUDED.close,
             volume = EXCLUDED.volume`,
          [
            priceId,
            asset.id,
            timestamp * 1000,
            open,
            high,
            low,
            currentPrice,
            volume,
            'yahoo_finance',
            Date.now(),
          ]
        );

        console.log(`   ✅ تم حفظ السعر في قاعدة البيانات`);

      } catch (error: any) {
        console.log(`   ❌ خطأ: ${error.message}`);
      }

      // Wait 1 second between requests to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    console.log('\n' + '='.repeat(80));
    console.log('\n✅ تم جلب جميع الأسعار بنجاح!\n');

  } catch (error: any) {
    console.error(`\n❌ خطأ: ${error.message}\n`);
  } finally {
    await pool.end();
  }
}

fetchTodayPrices().catch(console.error);

