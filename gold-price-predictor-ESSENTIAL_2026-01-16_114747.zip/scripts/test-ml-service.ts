// FILE: scripts/test-ml-service.ts | PURPOSE: Test ML service endpoints | OWNER: ML Team | LAST-AUDITED: 2025-11-25

import axios from 'axios';

const ML_SERVICE_URL = process.env.ML_SERVICE_URL || 'http://localhost:2105';

async function testMLService() {
  console.log('\n🔍 Testing ML Service...\n');
  console.log('='.repeat(50));

  try {
    // 1. Health Check
    console.log('\n1️⃣ Testing Health Check');
    const healthResponse = await axios.get(`${ML_SERVICE_URL}/health`);
    console.log('Status:', healthResponse.status);
    console.log('Response:', JSON.stringify(healthResponse.data, null, 2));
    console.log('✅ Health check passed!');

    // 2. Prediction
    console.log('\n2️⃣ Testing Prediction');
    const predictionRequest = {
      symbol: 'GC=F',
      days: 7,
    };
    console.log('Request:', JSON.stringify(predictionRequest, null, 2));
    
    const predictionResponse = await axios.post(
      `${ML_SERVICE_URL}/predict`,
      predictionRequest
    );
    console.log('Status:', predictionResponse.status);
    console.log('Response:', JSON.stringify(predictionResponse.data, null, 2));
    console.log('✅ Prediction successful!');
    console.log(`   Predicted ${predictionResponse.data.predictions.length} days`);
    console.log(`   Confidence: ${predictionResponse.data.confidence * 100}%`);
    console.log(`   Model: ${predictionResponse.data.model_used}`);

    // 3. List Models
    console.log('\n3️⃣ Testing List Models');
    const modelsResponse = await axios.get(`${ML_SERVICE_URL}/models`);
    console.log('Status:', modelsResponse.status);
    console.log('Response:', JSON.stringify(modelsResponse.data, null, 2));
    console.log('✅ List models successful!');

    console.log('\n' + '='.repeat(50));
    console.log('\n✅ All tests passed!\n');

  } catch (error: any) {
    console.error('\n❌ Test failed!');
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    } else {
      console.error('Error:', error.message);
    }
    console.log('\n' + '='.repeat(50));
    process.exit(1);
  }
}

testMLService();

