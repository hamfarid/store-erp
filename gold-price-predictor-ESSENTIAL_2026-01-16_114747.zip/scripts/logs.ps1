# FILE: scripts/logs.ps1 | PURPOSE: View service logs | OWNER: DevOps Team | RELATED: start.ps1 | LAST-AUDITED: 2025-11-27

<#
.SYNOPSIS
    View service logs for Gold Price Predictor

.DESCRIPTION
    Shows logs for all or specific services

.PARAMETER Service
    Service name (backend, frontend, postgres, redis, nginx)

.PARAMETER Production
    Use production configuration

.PARAMETER Follow
    Follow log output

.PARAMETER Tail
    Number of lines to show (default: 100)

.EXAMPLE
    .\scripts\logs.ps1
    .\scripts\logs.ps1 -Service backend -Follow
    .\scripts\logs.ps1 -Production -Tail 50
#>

param(
    [Parameter(Mandatory=$false)]
    [string]$Service,

    [Parameter(Mandatory=$false)]
    [switch]$Production,

    [Parameter(Mandatory=$false)]
    [switch]$Follow,

    [Parameter(Mandatory=$false)]
    [int]$Tail = 100
)

# Change to project root
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

# Determine compose file
$composeFile = if ($Production) {
    "docker-compose.production.yml"
} else {
    "docker-compose.yml"
}

# Build command
$logArgs = @("-f", $composeFile, "logs", "--tail=$Tail")

if ($Follow) {
    $logArgs += "-f"
}

if ($Service) {
    $logArgs += $Service
    Write-Host "Viewing logs for: $Service" -ForegroundColor Cyan
} else {
    Write-Host "Viewing logs for: All services" -ForegroundColor Cyan
}

Write-Host "Press Ctrl+C to stop" -ForegroundColor Gray
Write-Host ""

# Show logs
docker compose @logArgs
