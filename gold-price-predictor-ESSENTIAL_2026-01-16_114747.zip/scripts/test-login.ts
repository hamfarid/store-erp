/**
 * FILE: scripts/test-login.ts
 * PURPOSE: Test login functionality
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import bcrypt from "bcryptjs";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🔐 Testing Login Functionality");
console.log("=".repeat(50));

async function testLogin() {
  const sqlite = new Database(dbPath);

  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";

  console.log(`\n📧 Email: ${email}`);
  console.log(`🔑 Password: ${password}`);

  // Find user
  console.log("\n1️⃣ Finding user...");
  const user = sqlite
    .prepare("SELECT * FROM users WHERE email = ?")
    .get(email) as any;

  if (!user) {
    console.log("❌ User not found!");
    sqlite.close();
    return;
  }

  console.log("✅ User found:");
  console.log(`   ID: ${user.id}`);
  console.log(`   Email: ${user.email}`);
  console.log(`   Role: ${user.role}`);
  console.log(`   Login Method: ${user.loginMethod}`);
  console.log(`   Has Password Hash: ${user.passwordHash ? "Yes" : "No"}`);

  if (!user.passwordHash) {
    console.log("\n❌ User has no password hash!");
    sqlite.close();
    return;
  }

  // Verify password
  console.log("\n2️⃣ Verifying password...");
  const isValid = await bcrypt.compare(password, user.passwordHash);

  if (isValid) {
    console.log("✅ Password is correct!");
  } else {
    console.log("❌ Password is incorrect!");
  }

  // Check JWT_SECRET
  console.log("\n3️⃣ Checking environment variables...");
  console.log(`   JWT_SECRET: ${process.env.JWT_SECRET ? "Set ✅" : "Missing ❌"}`);
  console.log(`   SECRET_KEY: ${process.env.SECRET_KEY ? "Set ✅" : "Missing ❌"}`);
  console.log(
    `   DATABASE_URL: ${process.env.DATABASE_URL ? "Set ✅" : "Missing ❌"}`
  );

  sqlite.close();

  console.log("\n" + "=".repeat(50));
  if (isValid) {
    console.log("✅ Login test PASSED!");
    console.log("\n💡 You can now login with:");
    console.log(`   Email: ${email}`);
    console.log(`   Password: ${password}`);
  } else {
    console.log("❌ Login test FAILED!");
  }
  console.log("=".repeat(50));
}

testLogin().catch((error) => {
  console.error("❌ Error:", error);
  process.exit(1);
});

