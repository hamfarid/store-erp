/**
 * FILE: scripts/migrate-drift.ts
 * PURPOSE: Apply drift detection migration
 * OWNER: ML Team
 * RELATED: drizzle/migrations/0001_drift_detection.sql
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = process.env.DATABASE_URL || resolve(__dirname, "../data/app.db");
const migrationPath = resolve(
  __dirname,
  "../drizzle/migrations/0001_drift_detection.sql"
);

console.log("🚀 Starting drift detection migration...");
console.log("📁 Database:", dbPath);
console.log("📄 Migration:", migrationPath);

try {
  // Open database
  const db = new Database(dbPath);

  // Read migration SQL
  const migrationSQL = readFileSync(migrationPath, "utf-8");

  // Execute migration
  db.exec(migrationSQL);

  console.log("✅ Migration completed successfully!");

  // Verify tables were created
  const tables = db
    .prepare(
      `
    SELECT name FROM sqlite_master
    WHERE type='table'
    AND name IN (
      'drift_detections',
      'drift_metrics_history',
      'drift_alerts',
      'model_retraining_log',
      'data_quality_metrics'
    )
  `
    )
    .all();

  console.log("\n📊 Created tables:");
  tables.forEach((table: any) => {
    console.log(`  ✓ ${table.name}`);
  });

  // Close database
  db.close();

  console.log("\n🎉 Drift detection system is ready!");
} catch (error) {
  console.error("❌ Migration failed:", error);
  process.exit(1);
}
