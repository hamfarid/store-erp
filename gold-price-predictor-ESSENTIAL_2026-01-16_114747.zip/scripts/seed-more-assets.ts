#!/usr/bin/env tsx
/**
 * Add more currency assets
 */

import { drizzle } from "drizzle-orm/mysql2";
import { assets } from "../drizzle/schema";

const db = drizzle(process.env.DATABASE_URL!);

const newAssets = [
  // Major Currencies
  { name: "اليورو", symbol: "EUR=X", category: "currency" as const },
  { name: "الدولار الأمريكي (Index)", symbol: "DX-Y.NYB", category: "currency" as const },
  { name: "الريال السعودي", symbol: "SAR=X", category: "currency" as const },
  { name: "الدرهم الإماراتي", symbol: "AED=X", category: "currency" as const },
  { name: "الريال العماني", symbol: "OMR=X", category: "currency" as const },
];

async function seed() {
  console.log("🌱 Adding new currency assets...");
  
  try {
    for (const asset of newAssets) {
      await db.insert(assets).values(asset);
      console.log(`✅ Added: ${asset.name} (${asset.symbol})`);
    }
    
    console.log("\n✅ New assets added successfully!");
    console.log(`📊 Total assets: ${12 + newAssets.length}`);
    process.exit(0);
  } catch (error) {
    console.error("❌ Failed to add assets:", error);
    process.exit(1);
  }
}

seed();

