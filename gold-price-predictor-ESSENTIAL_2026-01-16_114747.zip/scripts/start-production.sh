#!/bin/bash
# ============================================
# Production Startup Script
# Starts all services for production
# ============================================

echo ""
echo "══════════════════════════════════════════════════════════════"
echo "  🚀 Starting Gold Price Predictor - Production Mode"
echo "══════════════════════════════════════════════════════════════"
echo ""

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ Error: .env file not found!"
    echo "   Please copy env.example to .env and configure it."
    exit 1
fi

# Check if DATABASE_URL_POSTGRES is set
if ! grep -q "DATABASE_URL_POSTGRES" .env; then
    echo "⚠️  Warning: DATABASE_URL_POSTGRES not found in .env"
    echo "   Make sure PostgreSQL connection string is configured."
    echo ""
fi

# Step 1: Stop existing containers
echo "1️⃣  Stopping existing containers..."
docker-compose -f docker-compose.production.yml down 2>/dev/null
echo "   ✅ Done"
echo ""

# Step 2: Remove old containers and volumes (optional)
read -p "   Remove old containers and volumes? (y/N): " remove_old
if [ "$remove_old" = "y" ] || [ "$remove_old" = "Y" ]; then
    echo "   🗑️  Removing old containers and volumes..."
    docker-compose -f docker-compose.production.yml down -v 2>/dev/null
    echo "   ✅ Done"
    echo ""
fi

# Step 3: Initialize PostgreSQL database
echo "2️⃣  Initializing PostgreSQL database..."
if npx tsx scripts/setup-postgres.ts; then
    echo "   ✅ Database initialized"
else
    echo "   ⚠️  Database initialization failed or already exists"
fi
echo ""

# Step 4: Build Docker images
echo "3️⃣  Building Docker images..."
if ! docker-compose -f docker-compose.production.yml build; then
    echo "   ❌ Build failed!"
    exit 1
fi
echo "   ✅ Build completed"
echo ""

# Step 5: Start containers
echo "4️⃣  Starting containers..."
if ! docker-compose -f docker-compose.production.yml up -d; then
    echo "   ❌ Failed to start containers!"
    exit 1
fi
echo "   ✅ Containers started"
echo ""

# Step 6: Wait for services to be ready
echo "5️⃣  Waiting for services to be ready..."
sleep 10

# Check PostgreSQL
max_retries=30
retry_count=0
postgres_ready=false

while [ $retry_count -lt $max_retries ] && [ "$postgres_ready" = false ]; do
    if docker exec gold-predictor-postgres pg_isready -U postgres >/dev/null 2>&1; then
        postgres_ready=true
        echo "   ✅ PostgreSQL is ready"
    else
        retry_count=$((retry_count + 1))
        echo "   ⏳ Waiting for PostgreSQL... ($retry_count/$max_retries)"
        sleep 2
    fi
done

if [ "$postgres_ready" = false ]; then
    echo "   ⚠️  PostgreSQL may not be ready yet"
fi

echo ""

# Step 7: Show container status
echo "6️⃣  Container Status:"
docker-compose -f docker-compose.production.yml ps
echo ""

# Step 8: Show service URLs
echo "══════════════════════════════════════════════════════════════"
echo "  ✅ Production Services Started!"
echo "══════════════════════════════════════════════════════════════"
echo ""
echo "📋 Service URLs:"
echo "   Frontend:     http://localhost:2505"
echo "   Backend API:  http://localhost:2505/api"
echo "   ML Service:   http://localhost:2105"
echo "   Grafana:      http://localhost:3001"
echo "   Prometheus:   http://localhost:9090"
echo "   Portainer:    http://localhost:9000"
echo ""
echo "📊 Database:"
echo "   PostgreSQL:   localhost:5432"
echo "   Redis:        localhost:6379"
echo ""
echo "🔧 Useful Commands:"
echo "   View logs:    docker-compose -f docker-compose.production.yml logs -f"
echo "   Stop all:     docker-compose -f docker-compose.production.yml down"
echo "   Restart:      docker-compose -f docker-compose.production.yml restart"
echo ""
echo "══════════════════════════════════════════════════════════════"
echo ""

