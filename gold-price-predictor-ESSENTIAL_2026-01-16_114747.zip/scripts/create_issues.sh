#!/bin/bash

# Security Issues
gh issue create --title "🔒 إصلاح مشاكل CORS الأمنية" \
  --body "## المشكلة
CORS مفتوح للجميع مع credentials، مما يشكل خطراً أمنياً كبيراً.

## الحل المقترح
- تقييد CORS للنطاقات المصرح بها فقط
- إزالة credentials=True إذا لم يكن ضرورياً
- استخدام قائمة بيضاء للنطاقات المسموحة

## الأولوية
🔴 حرجة - يجب الإصلاح فوراً" \
  --label "security,critical,backend"

gh issue create --title "🔐 إضافة نظام مصادقة JWT" \
  --body "## المشكلة
لا يوجد نظام مصادقة حالياً، مما يعني أن أي شخص يمكنه الوصول للـ API.

## الحل المقترح
- تطبيق JWT Authentication
- إضافة endpoints للتسجيل وتسجيل الدخول
- حماية جميع endpoints الحساسة

## الأولوية
🔴 حرجة" \
  --label "security,critical,backend,enhancement"

gh issue create --title "⚡ إضافة Rate Limiting" \
  --body "## المشكلة
عدم وجود rate limiting يعرض النظام لهجمات DDoS.

## الحل المقترح
- استخدام slowapi أو مكتبة مشابهة
- تحديد عدد الطلبات لكل مستخدم/IP
- إضافة Redis للتخزين المؤقت

## الأولوية
🟠 عالية" \
  --label "security,high,backend,enhancement"

# Software Engineering Issues
gh issue create --title "🏗️ تطبيق Repository Pattern" \
  --body "## الهدف
تحسين البنية المعمارية باستخدام Repository Pattern.

## التفاصيل
- فصل منطق الوصول للبيانات
- تطبيق SOLID principles
- تحسين قابلية الاختبار

## الأولوية
🟡 متوسطة" \
  --label "enhancement,backend,architecture"

gh issue create --title "📝 إضافة اختبارات شاملة" \
  --body "## الهدف
زيادة تغطية الاختبارات إلى 80%+.

## المطلوب
- Unit tests لجميع الوحدات
- Integration tests للـ API
- End-to-end tests للواجهة الأمامية

## الأولوية
🟡 متوسطة" \
  --label "testing,enhancement"

gh issue create --title "🚀 إضافة Cache Layer" \
  --body "## الهدف
تحسين الأداء باستخدام Redis للتخزين المؤقت.

## الفوائد
- تقليل وقت الاستجابة
- تقليل الحمل على النماذج
- تحسين تجربة المستخدم

## الأولوية
🟡 متوسطة" \
  --label "performance,enhancement,backend"

# Feature Requests
gh issue create --title "📱 إنشاء تطبيق موبايل" \
  --body "## الهدف
تطوير تطبيق موبايل لنظامي iOS و Android.

## التقنيات المقترحة
- React Native أو Flutter
- مشاركة الكود مع الواجهة الأمامية

## الأولوية
🟢 منخفضة" \
  --label "enhancement,mobile,future"

gh issue create --title "🔔 إضافة نظام تنبيهات فوري" \
  --body "## الهدف
إضافة تنبيهات فورية عبر Email, Telegram, Discord.

## الميزات
- تنبيهات تغير الأسعار
- تنبيهات الفرص الاستثمارية
- تنبيهات مخصصة للمستخدمين

## الأولوية
🟡 متوسطة" \
  --label "enhancement,feature,backend"

gh issue create --title "📊 إضافة لوحة تحكم احترافية" \
  --body "## الهدف
تطوير لوحة تحكم احترافية مع رسوم بيانية تفاعلية.

## المكونات
- Real-time charts
- Historical data visualization
- Portfolio management
- Custom alerts

## الأولوية
🟡 متوسطة" \
  --label "enhancement,frontend,ui/ux"

# Documentation
gh issue create --title "📚 تحسين التوثيق" \
  --body "## الهدف
إنشاء توثيق شامل للمشروع.

## المطلوب
- API documentation (OpenAPI/Swagger)
- User guide
- Developer guide
- Deployment guide

## الأولوية
🟡 متوسطة" \
  --label "documentation"

echo "✅ تم إنشاء جميع Issues بنجاح!"
