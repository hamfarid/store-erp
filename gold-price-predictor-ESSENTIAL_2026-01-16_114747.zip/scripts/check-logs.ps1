# Quick log checker for troubleshooting
Write-Host "`n══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🔍 فحص سجلات الحاويات المتعثرة" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Check Backend logs
Write-Host "1️⃣  Backend Logs (آخر 30 سطر):" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker logs gold-predictor-backend --tail 30 2>&1
Write-Host ""

# Check ML Service logs
Write-Host "2️⃣  ML Service Logs (آخر 30 سطر):" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker logs gold-predictor-ml --tail 30 2>&1
Write-Host ""

# Check Prometheus logs
Write-Host "3️⃣  Prometheus Logs (آخر 20 سطر):" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker logs gold-predictor-prometheus --tail 20 2>&1
Write-Host ""

# Check container status
Write-Host "4️⃣  حالة الحاويات:" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker ps -a --filter "name=gold-predictor" --format "table {{.Names}}\t{{.Status}}"
Write-Host ""

