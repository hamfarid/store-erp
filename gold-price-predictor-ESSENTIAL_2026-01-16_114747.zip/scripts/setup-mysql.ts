/**
 * MySQL Database Setup Script
 * Creates all necessary tables and indexes for MySQL
 * 
 * Usage: npx tsx scripts/setup-mysql.ts
 */

import mysql from "mysql2/promise";
import { config } from "dotenv";

// Load environment variables
config();

async function setupMySQL() {
  console.log("🗄️  MySQL Database Setup Script");
  console.log("=".repeat(50));

  const databaseUrl = process.env.DATABASE_URL;

  if (!databaseUrl || databaseUrl.startsWith("file:")) {
    console.error("❌ DATABASE_URL is not set or points to SQLite");
    console.log("💡 Set DATABASE_URL=mysql://user:password@host:port/database");
    process.exit(1);
  }

  // Parse MySQL connection string
  const url = new URL(databaseUrl.replace("mysql://", "http://"));
  const dbName = url.pathname.slice(1); // Remove leading /
  
  // Create connection without database first
  const connectionConfig = {
    host: url.hostname,
    port: parseInt(url.port || "3306", 10),
    user: url.username,
    password: url.password,
    multipleStatements: true,
  };

  let connection: mysql.Connection;

  try {
    console.log(`📂 Connecting to MySQL server at ${connectionConfig.host}:${connectionConfig.port}...`);
    connection = await mysql.createConnection(connectionConfig);

    // Create database if it doesn't exist
    console.log(`📊 Creating database '${dbName}' if it doesn't exist...`);
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    console.log(`✅ Database '${dbName}' ready`);

    // Connect to the database
    await connection.query(`USE \`${dbName}\``);
    console.log(`✅ Connected to database '${dbName}'`);

    // Create tables
    console.log("\n🔨 Creating tables...");

    // Users table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        passwordHash VARCHAR(255),
        loginMethod VARCHAR(50) DEFAULT 'local',
        role VARCHAR(50) DEFAULT 'user' CHECK(role IN ('admin', 'user')),
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        lastSignedIn BIGINT,
        updatedAt BIGINT,
        INDEX idx_users_email (email),
        INDEX idx_users_role (role),
        INDEX idx_users_login_method (loginMethod),
        INDEX idx_users_created_at (createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ users");

    // Assets table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS assets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        symbol VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        assetType VARCHAR(50) DEFAULT 'commodity',
        exchange VARCHAR(100),
        currency VARCHAR(10) DEFAULT 'USD',
        currentPrice DECIMAL(20, 8),
        sector VARCHAR(100),
        description TEXT,
        yahooSymbol VARCHAR(50),
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        updatedAt BIGINT,
        INDEX idx_assets_symbol (symbol),
        INDEX idx_assets_asset_type (assetType),
        INDEX idx_assets_yahoo_symbol (yahooSymbol)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ assets");

    // Historical prices table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS historical_prices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        assetId INT NOT NULL,
        date DATE NOT NULL,
        price DECIMAL(20, 8) NOT NULL,
        high DECIMAL(20, 8),
        low DECIMAL(20, 8),
        open DECIMAL(20, 8),
        volume DECIMAL(20, 2),
        change DECIMAL(20, 8) DEFAULT 0.00,
        changePercent DECIMAL(10, 4) DEFAULT 0.00,
        timestamp BIGINT NOT NULL,
        FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
        INDEX idx_historical_prices_asset_id (assetId),
        INDEX idx_historical_prices_date (date),
        INDEX idx_historical_prices_timestamp (timestamp),
        INDEX idx_historical_prices_asset_date (assetId, date)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ historical_prices");

    // Predictions table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS predictions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        assetId INT NOT NULL,
        userId VARCHAR(255),
        modelType VARCHAR(50) DEFAULT 'simple',
        horizon VARCHAR(50) DEFAULT 'short',
        predictedPrice DECIMAL(20, 8) NOT NULL,
        confidenceLevel DECIMAL(5, 4) DEFAULT 0.95,
        predictionDate BIGINT NOT NULL,
        accuracy DECIMAL(10, 4),
        metadata TEXT,
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_predictions_asset_id (assetId),
        INDEX idx_predictions_user_id (userId),
        INDEX idx_predictions_created_at (createdAt),
        INDEX idx_predictions_model_type (modelType),
        INDEX idx_predictions_asset_date (assetId, predictionDate)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ predictions");

    // Alerts table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS alerts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(255) NOT NULL,
        assetId INT NOT NULL,
        alertType VARCHAR(50) DEFAULT 'price',
        condition VARCHAR(50) NOT NULL,
        threshold DECIMAL(20, 8) NOT NULL,
        isActive TINYINT(1) DEFAULT 1,
        isTriggered TINYINT(1) DEFAULT 0,
        triggeredAt BIGINT,
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
        INDEX idx_alerts_user_id (userId),
        INDEX idx_alerts_asset_id (assetId),
        INDEX idx_alerts_is_active (isActive),
        INDEX idx_alerts_is_triggered (isTriggered),
        INDEX idx_alerts_created_at (createdAt),
        INDEX idx_alerts_user_active (userId, isActive)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ alerts");

    // Notifications table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(255) NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        isRead TINYINT(1) DEFAULT 0,
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_notifications_user_id (userId),
        INDEX idx_notifications_is_read (isRead),
        INDEX idx_notifications_created_at (createdAt),
        INDEX idx_notifications_user_read (userId, isRead)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ notifications");

    // User permissions table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS user_permissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(255) NOT NULL,
        permission VARCHAR(100) NOT NULL,
        resource VARCHAR(100),
        action VARCHAR(50),
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_permissions_user_id (userId),
        INDEX idx_user_permissions_permission (permission)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ user_permissions");

    // AI conversations table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS ai_conversations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(255) NOT NULL,
        assistantType VARCHAR(50) DEFAULT 'general',
        messages TEXT NOT NULL,
        tokensUsed INT DEFAULT 0,
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        updatedAt BIGINT,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_ai_conversations_user_id (userId),
        INDEX idx_ai_conversations_assistant_type (assistantType),
        INDEX idx_ai_conversations_created_at (createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ ai_conversations");

    // AI memories table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS ai_memories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(255) NOT NULL,
        type VARCHAR(50) DEFAULT 'fact',
        content TEXT NOT NULL,
        keywords TEXT,
        relevanceScore DECIMAL(5, 4) DEFAULT 1.0,
        createdAt BIGINT DEFAULT (UNIX_TIMESTAMP() * 1000),
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_ai_memories_user_id (userId),
        INDEX idx_ai_memories_type (type),
        INDEX idx_ai_memories_keywords (keywords(255)),
        INDEX idx_ai_memories_user_type (userId, type)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    console.log("  ✅ ai_memories");

    console.log("\n✅ MySQL database setup complete!");
    console.log(`📊 Database: ${dbName}`);
    console.log(`🔗 Connection: ${connectionConfig.host}:${connectionConfig.port}`);

  } catch (error: any) {
    console.error("❌ Setup failed:", error.message);
    process.exit(1);
  } finally {
    if (connection!) {
      await connection.end();
    }
  }
}

// Run setup
setupMySQL();

