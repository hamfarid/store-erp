/**
 * FILE: scripts/init-database.ts
 * PURPOSE: Initialize database with all tables
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import * as schema from "../drizzle/schema";
import * as schemaDrift from "../drizzle/schema-drift";
import * as schemaLearning from "../drizzle/schema-learning";
import * as schemaOpinions from "../drizzle/schema-opinions";
import { resolve } from "path";
import { existsSync, mkdirSync } from "fs";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🗄️  Database Initialization Script");
console.log("=" .repeat(50));
console.log(`Database Path: ${dbPath}`);

// Ensure data directory exists
const dataDir = resolve(process.cwd(), "data");
if (!existsSync(dataDir)) {
  console.log("📁 Creating data directory...");
  mkdirSync(dataDir, { recursive: true });
}

// Initialize database
console.log("\n📊 Initializing database...");
const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");

const db = drizzle(sqlite, {
  schema: {
    ...schema,
    ...schemaDrift,
    ...schemaLearning,
    ...schemaOpinions,
  },
});

console.log("✅ Database connection established");

// Create tables
console.log("\n🔨 Creating tables...");

const tables = [
  // Core tables
  "users",
  "assets",
  "historical_prices",
  "predictions",
  "alerts",
  "access_codes",
  "email_settings",
  
  // Logging tables
  "api_request_logs",
  "error_logs",
  "ml_training_logs",
  "prediction_logs",
  "notifications",
  
  // Analysis tables
  "break_even_points",
  "breakout_points",
  "inflection_points",
  
  // Drift detection tables
  "drift_detections",
  "drift_alerts",
  "drift_metrics_history",
  "model_retraining_log",
  "data_quality_metrics",
  
  // Learning path tables
  "learning_paths",
  "path_evaluations",
  "hyperparameter_configs",
  "feature_selections",
  "optimization_history",
  
  // Expert opinions tables
  "expert_opinions",
  "social_sentiments",
  "sentiment_trends",
  "scraped_urls",
  "sentiment_aggregations",
];

console.log(`📋 Total tables to create: ${tables.length}`);

// Get existing tables
const existingTables = sqlite
  .prepare(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
  )
  .all() as { name: string }[];

console.log(`\n📊 Existing tables: ${existingTables.length}`);
existingTables.forEach((t) => console.log(`  - ${t.name}`));

// Count tables
const createdCount = existingTables.length;
const missingCount = tables.length - createdCount;

console.log("\n" + "=".repeat(50));
console.log("📊 Database Status:");
console.log(`  ✅ Created: ${createdCount} tables`);
console.log(`  ⏳ Missing: ${missingCount} tables`);
console.log("=".repeat(50));

if (missingCount > 0) {
  console.log("\n⚠️  Some tables are missing!");
  console.log("💡 Run: npx drizzle-kit push");
  console.log("   This will create all missing tables.");
} else {
  console.log("\n✅ All tables exist!");
}

// Close connection
sqlite.close();
console.log("\n✅ Database initialization complete!");

