# FILE: scripts/generate-ssl-cert.ps1 | PURPOSE: Generate self-signed SSL certificate | OWNER: DevOps Team | RELATED: nginx/ssl/ | LAST-AUDITED: 2025-11-27

<#
.SYNOPSIS
    Generate self-signed SSL certificate for development

.DESCRIPTION
    Creates self-signed SSL certificate and key for local HTTPS testing

.EXAMPLE
    .\scripts\generate-ssl-cert.ps1

.NOTES
    For production, use Let's Encrypt or a trusted CA
#>

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "SSL Certificate Generator" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Check if OpenSSL is installed
$opensslPath = Get-Command openssl -ErrorAction SilentlyContinue

if (-not $opensslPath) {
    Write-Host "ERROR: OpenSSL not found!" -ForegroundColor Red
    Write-Host "Please install OpenSSL:" -ForegroundColor Yellow
    Write-Host "  - Windows: choco install openssl" -ForegroundColor Yellow
    Write-Host "  - Or download from: https://slproweb.com/products/Win32OpenSSL.html" -ForegroundColor Yellow
    exit 1
}

# Create SSL directory if not exists
$sslDir = Join-Path $PSScriptRoot "..\nginx\ssl"
if (-not (Test-Path $sslDir)) {
    New-Item -ItemType Directory -Path $sslDir -Force | Out-Null
}

# Certificate configuration
$certFile = Join-Path $sslDir "cert.pem"
$keyFile = Join-Path $sslDir "key.pem"
$days = 365
$subject = "/C=EG/ST=Cairo/L=Cairo/O=GoldPredictor/OU=Development/CN=localhost"

Write-Host ""
Write-Host "Generating self-signed certificate..." -ForegroundColor Yellow
Write-Host "  Certificate: $certFile" -ForegroundColor Gray
Write-Host "  Private Key: $keyFile" -ForegroundColor Gray
Write-Host "  Valid for: $days days" -ForegroundColor Gray
Write-Host ""

# Generate certificate
$opensslCmd = "openssl req -x509 -nodes -days $days -newkey rsa:2048 -keyout `"$keyFile`" -out `"$certFile`" -subj `"$subject`" 2>&1"

try {
    $output = Invoke-Expression $opensslCmd

    if (Test-Path $certFile -and Test-Path $keyFile) {
        Write-Host "SUCCESS: SSL certificate generated!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Certificate details:" -ForegroundColor Cyan

        # Show certificate info
        $certInfo = & openssl x509 -in $certFile -text -noout | Select-String -Pattern "(Issuer|Subject|Not Before|Not After)" -Context 0,0
        $certInfo | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }

        Write-Host ""
        Write-Host "Files created:" -ForegroundColor Cyan
        Write-Host "  - $certFile" -ForegroundColor Green
        Write-Host "  - $keyFile" -ForegroundColor Green

        Write-Host ""
        Write-Host "NOTE: This is a self-signed certificate for development only!" -ForegroundColor Yellow
        Write-Host "Browsers will show a security warning. This is normal." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "To use in production, obtain a certificate from:" -ForegroundColor Cyan
        Write-Host "  - Let's Encrypt (free): https://letsencrypt.org" -ForegroundColor Gray
        Write-Host "  - Commercial CA: DigiCert, Comodo, etc." -ForegroundColor Gray

    } else {
        Write-Host "ERROR: Certificate files not created!" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "ERROR: Failed to generate certificate!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Update .env.production with correct values" -ForegroundColor Yellow
Write-Host "2. Run: docker compose -f docker-compose.production.yml up -d" -ForegroundColor Yellow
Write-Host "3. Access via: https://localhost:442" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
