"""
Migrate Secrets to AWS Secrets Manager

This script migrates secrets from .env file to AWS Secrets Manager.

Usage:
    python scripts/migrate_secrets_to_aws.py

Requirements:
    - AWS CLI configured with credentials
    - boto3 installed: pip install boto3
    - .env file with secrets to migrate

Example:
    $ python scripts/migrate_secrets_to_aws.py
    ✅ Created secret: gold-predictor/database
    ✅ Created secret: gold-predictor/jwt
    ✅ Created secret: gold-predictor/redis
    ✅ Created secret: gold-predictor/api-keys
    
    Migration complete! 4 secrets created.
"""

import json
import os
import sys
from typing import Dict, Any
import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()


class SecretsMigrator:
    """
    Migrate secrets from environment variables to AWS Secrets Manager.
    
    This class reads secrets from .env file and creates them in AWS
    Secrets Manager with proper naming and structure.
    """
    
    def __init__(self, region_name: str = 'us-east-1'):
        """
        Initialize AWS Secrets Manager client.
        
        Args:
            region_name: AWS region for secrets storage
        """
        self.region_name = region_name
        self.client = boto3.client('secretsmanager', region_name=region_name)
        print(f"📍 Using AWS region: {region_name}")
    
    def create_secret(self, secret_name: str, secret_value: Dict[str, Any]) -> bool:
        """
        Create a secret in AWS Secrets Manager.
        
        Args:
            secret_name: Name of the secret
            secret_value: Dictionary containing secret data
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.client.create_secret(
                Name=secret_name,
                SecretString=json.dumps(secret_value),
                Description=f"Gold Price Predictor - {secret_name.split('/')[-1]}"
            )
            print(f"✅ Created secret: {secret_name}")
            return True
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            
            if error_code == 'ResourceExistsException':
                print(f"⚠️  Secret already exists: {secret_name}")
                
                # Update existing secret
                try:
                    self.client.update_secret(
                        SecretId=secret_name,
                        SecretString=json.dumps(secret_value)
                    )
                    print(f"✅ Updated secret: {secret_name}")
                    return True
                except ClientError as update_error:
                    print(f"❌ Failed to update secret: {update_error}")
                    return False
            else:
                print(f"❌ Failed to create secret: {e}")
                return False
    
    def migrate_database_secrets(self) -> bool:
        """
        Migrate database secrets to AWS Secrets Manager.
        
        Returns:
            True if successful
        """
        print("\n📦 Migrating database secrets...")
        
        db_secret = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': int(os.getenv('DB_PORT', '5432')),
            'user': os.getenv('DB_USER', 'postgres'),
            'password': os.getenv('DB_PASSWORD', ''),
            'database': os.getenv('DB_NAME', 'gold_predictor'),
        }
        
        # Add read replicas if configured
        if os.getenv('DB_READ_REPLICA_1_HOST'):
            db_secret['read_replica_1_host'] = os.getenv('DB_READ_REPLICA_1_HOST')
        
        if os.getenv('DB_READ_REPLICA_2_HOST'):
            db_secret['read_replica_2_host'] = os.getenv('DB_READ_REPLICA_2_HOST')
        
        return self.create_secret('gold-predictor/database', db_secret)
    
    def migrate_jwt_secrets(self) -> bool:
        """
        Migrate JWT secrets to AWS Secrets Manager.
        
        Returns:
            True if successful
        """
        print("\n🔐 Migrating JWT secrets...")
        
        jwt_secret = {
            'secret_key': os.getenv('JWT_SECRET_KEY', ''),
            'algorithm': os.getenv('JWT_ALGORITHM', 'HS256'),
            'access_token_expire_minutes': int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES', '15')),
            'refresh_token_expire_days': int(os.getenv('REFRESH_TOKEN_EXPIRE_DAYS', '7')),
        }
        
        return self.create_secret('gold-predictor/jwt', jwt_secret)
    
    def migrate_redis_secrets(self) -> bool:
        """
        Migrate Redis secrets to AWS Secrets Manager.
        
        Returns:
            True if successful
        """
        print("\n🔴 Migrating Redis secrets...")
        
        redis_secret = {
            'host': os.getenv('REDIS_HOST', 'localhost'),
            'port': int(os.getenv('REDIS_PORT', '6379')),
            'password': os.getenv('REDIS_PASSWORD', ''),
            'db': int(os.getenv('REDIS_DB', '0')),
        }
        
        # Add cluster endpoint if configured
        if os.getenv('REDIS_CLUSTER_ENDPOINT'):
            redis_secret['cluster_endpoint'] = os.getenv('REDIS_CLUSTER_ENDPOINT')
        
        return self.create_secret('gold-predictor/redis', redis_secret)
    
    def migrate_api_keys(self) -> bool:
        """
        Migrate API keys to AWS Secrets Manager.
        
        Returns:
            True if successful
        """
        print("\n🔑 Migrating API keys...")
        
        api_keys = {}
        
        if os.getenv('ALPHA_VANTAGE_API_KEY'):
            api_keys['alpha_vantage'] = os.getenv('ALPHA_VANTAGE_API_KEY')
        
        if os.getenv('OPENAI_API_KEY'):
            api_keys['openai'] = os.getenv('OPENAI_API_KEY')
        
        if not api_keys:
            print("ℹ️  No API keys found in .env file")
            return True
        
        return self.create_secret('gold-predictor/api-keys', api_keys)
    
    def migrate_all(self) -> bool:
        """
        Migrate all secrets to AWS Secrets Manager.
        
        Returns:
            True if all migrations successful
        """
        print("🚀 Starting secrets migration to AWS Secrets Manager...")
        print("=" * 60)
        
        results = [
            self.migrate_database_secrets(),
            self.migrate_jwt_secrets(),
            self.migrate_redis_secrets(),
            self.migrate_api_keys(),
        ]
        
        print("\n" + "=" * 60)
        
        if all(results):
            print("✅ Migration complete! All secrets created successfully.")
            print("\n📝 Next steps:")
            print("1. Update backend/app/core/config.py to use secrets.py")
            print("2. Test application with AWS Secrets Manager")
            print("3. Remove .env file: git rm .env")
            print("4. Update .gitignore to prevent .env commits")
            return True
        else:
            print("❌ Migration failed! Some secrets could not be created.")
            return False


def main():
    """Main entry point"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║       AWS Secrets Manager Migration Tool                    ║
║       Gold Price Predictor                                   ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    # Check if AWS credentials are configured
    try:
        boto3.client('sts').get_caller_identity()
        print("✅ AWS credentials configured")
    except Exception as e:
        print("❌ AWS credentials not configured!")
        print("\nPlease run: aws configure")
        print("Or set environment variables:")
        print("  - AWS_ACCESS_KEY_ID")
        print("  - AWS_SECRET_ACCESS_KEY")
        print("  - AWS_DEFAULT_REGION")
        sys.exit(1)
    
    # Check if .env file exists
    if not os.path.exists('.env'):
        print("❌ .env file not found!")
        print("\nPlease create .env file with your secrets.")
        sys.exit(1)
    
    print("✅ .env file found")
    
    # Confirm migration
    print("\n⚠️  This will create/update secrets in AWS Secrets Manager.")
    print("   Estimated cost: $0.40/month per secret (~$1.60/month total)")
    
    confirm = input("\nProceed with migration? (yes/no): ")
    if confirm.lower() not in ['yes', 'y']:
        print("❌ Migration cancelled.")
        sys.exit(0)
    
    # Run migration
    migrator = SecretsMigrator()
    success = migrator.migrate_all()
    
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()

