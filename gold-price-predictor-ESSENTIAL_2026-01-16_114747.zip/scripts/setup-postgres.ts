// FILE: scripts/setup-postgres.ts | PURPOSE: Setup PostgreSQL database and create admin user | OWNER: Backend Team | RELATED: server/db-postgres.ts | LAST-AUDITED: 2025-11-25

import { Pool } from "pg";
import * as bcrypt from "bcryptjs";
import * as dotenv from "dotenv";

// Load environment variables
dotenv.config();

const databaseUrl =
  process.env.DATABASE_URL_POSTGRES || process.env.DATABASE_URL;

if (!databaseUrl || databaseUrl.includes("sqlite")) {
  console.error(
    "❌ PostgreSQL DATABASE_URL_POSTGRES is not configured in .env"
  );
  process.exit(1);
}

async function setupPostgreSQL() {
  console.log("\n🔧 Setting up PostgreSQL Database...\n");
  console.log("=".repeat(50));

  const pool = new Pool({
    connectionString: databaseUrl,
  });

  try {
    // Test connection
    console.log("\n1️⃣ Testing PostgreSQL connection...");
    await pool.query("SELECT NOW()");
    console.log("   ✅ Connection successful!");

    // Create tables
    console.log("\n2️⃣ Creating database tables...");

    // Users table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(64) PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        "passwordHash" VARCHAR(255),
        "loginMethod" VARCHAR(50) NOT NULL DEFAULT 'local',
        role VARCHAR(50) NOT NULL DEFAULT 'user',
        name VARCHAR(255),
        "createdAt" BIGINT NOT NULL,
        "lastSignedIn" BIGINT
      )
    `);
    console.log("   ✅ Users table created");

    // Sessions table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS sessions (
        id VARCHAR(64) PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        "expiresAt" BIGINT NOT NULL,
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Sessions table created");

    // Assets table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS assets (
        id SERIAL PRIMARY KEY,
        symbol VARCHAR(50) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL,
        "currentPrice" DECIMAL(20, 8),
        "lastUpdated" BIGINT,
        active BOOLEAN DEFAULT true
      )
    `);
    console.log("   ✅ Assets table created");

    // Predictions table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS predictions (
        id SERIAL PRIMARY KEY,
        "assetId" INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
        "predictedPrice" DECIMAL(20, 8) NOT NULL,
        "predictionDate" BIGINT NOT NULL,
        confidence DECIMAL(5, 2),
        model VARCHAR(100),
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Predictions table created");

    // Activity logs table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS activity_logs (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
        action VARCHAR(255) NOT NULL,
        details TEXT,
        "ipAddress" VARCHAR(45),
        "userAgent" TEXT,
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Activity logs table created");

    // Alerts table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS alerts (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        "assetId" INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
        "alertType" VARCHAR(50) DEFAULT 'price',
        condition VARCHAR(50) NOT NULL,
        threshold DECIMAL(20, 8) NOT NULL,
        "isActive" BOOLEAN DEFAULT true,
        "isTriggered" BOOLEAN DEFAULT false,
        "triggeredAt" BIGINT,
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Alerts table created");

    // Notifications table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        "userId" VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        "isRead" BOOLEAN DEFAULT false,
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Notifications table created");

    // Historical prices table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS historical_prices (
        id SERIAL PRIMARY KEY,
        "assetId" INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
        date BIGINT NOT NULL,
        close_price DECIMAL(20, 8) NOT NULL,
        high_price DECIMAL(20, 8),
        low_price DECIMAL(20, 8),
        open_price DECIMAL(20, 8),
        volume DECIMAL(20, 8),
        "createdAt" BIGINT NOT NULL
      )
    `);
    console.log("   ✅ Historical prices table created");

    // Create admin user
    console.log("\n3️⃣ Creating admin user...");

    const email = "admin@gaaraholding.com";
    const password = "Admin@2025!";
    const name = "Admin User";
    const role = "admin";

    // Check if admin user already exists
    const existingUser = await pool.query(
      "SELECT id FROM users WHERE email = $1",
      [email]
    );

    if (existingUser.rows.length > 0) {
      console.log(`   ⚠️  Admin user already exists: ${email}`);
      console.log("   🔄 Updating password and loginMethod...");

      const hashedPassword = await bcrypt.hash(password, 10);
      await pool.query(
        'UPDATE users SET "passwordHash" = $1, "loginMethod" = $2, "lastSignedIn" = $3 WHERE email = $4',
        [hashedPassword, "local", Date.now(), email]
      );
      console.log("   ✅ Password and loginMethod updated to local");
    } else {
      const userId = `user_${Date.now()}_${Math.random().toString(36).substring(7)}`;
      const hashedPassword = await bcrypt.hash(password, 10);
      const now = Date.now();

      await pool.query(
        `INSERT INTO users (id, email, "passwordHash", "loginMethod", role, name, "createdAt", "lastSignedIn")
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [userId, email, hashedPassword, "local", role, name, now, now]
      );
      console.log(`   ✅ Admin user created: ${email}`);
    }

    // Verify admin user
    console.log("\n4️⃣ Verifying admin user...");
    const adminUser = await pool.query(
      "SELECT id, email, role, name FROM users WHERE email = $1",
      [email]
    );

    if (adminUser.rows.length > 0) {
      const user = adminUser.rows[0];
      console.log("   ✅ Admin user verified:");
      console.log(`      ID: ${user.id}`);
      console.log(`      Email: ${user.email}`);
      console.log(`      Role: ${user.role}`);
      console.log(`      Name: ${user.name}`);
    }

    console.log("\n" + "=".repeat(50));
    console.log("✅ PostgreSQL setup completed successfully!");
    console.log("=".repeat(50));
    console.log("\n📝 Login Credentials:");
    console.log(`   Email:    ${email}`);
    console.log(`   Password: ${password}`);
    console.log("\n");
  } catch (error) {
    console.error("\n❌ Error setting up PostgreSQL:", error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run setup
setupPostgreSQL().catch(error => {
  console.error("Fatal error:", error);
  process.exit(1);
});
