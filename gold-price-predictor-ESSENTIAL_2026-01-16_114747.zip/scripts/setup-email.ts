import { drizzle } from 'drizzle-orm/mysql2';
import { emailSettings } from '../drizzle/schema';

async function main() {
  const db = drizzle(process.env.DATABASE_URL!);
  
  // Add email settings for the owner
  const ownerUserId = process.env.OWNER_OPEN_ID || '9rGBgymMj5UfpE45q89aiD';
  const recipientEmail = 'Hady.m.farid@gmail.com';
  
  try {
    await db.insert(emailSettings).values({
      userId: ownerUserId,
      recipientEmail: recipientEmail,
      fromName: 'Asset Predictor System',
      enabled: true,
    });
    
    console.log(`✅ Email settings added for ${recipientEmail}`);
  } catch (error: any) {
    if (error.message?.includes('Duplicate entry')) {
      console.log('ℹ️  Email settings already exist');
    } else {
      console.error('❌ Error adding email settings:', error);
    }
  }
  
  process.exit(0);
}

main();

