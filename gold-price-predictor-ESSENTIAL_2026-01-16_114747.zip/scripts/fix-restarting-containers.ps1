# Fix Restarting Containers
Write-Host "`n══════════════════════════════════════════════════════════════" -ForegroundColor Red
Write-Host "  🔧 إصلاح الحاويات التي تعيد التشغيل" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Red
Write-Host ""

# Step 1: Stop all containers
Write-Host "1️⃣  إيقاف جميع الحاويات..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml stop
Write-Host "   ✅ تم" -ForegroundColor Green
Write-Host ""

# Step 2: Check if .env file exists
Write-Host "2️⃣  التحقق من ملف .env..." -ForegroundColor Yellow
if (Test-Path .env) {
    Write-Host "   ✅ ملف .env موجود" -ForegroundColor Green
} else {
    Write-Host "   ❌ ملف .env غير موجود!" -ForegroundColor Red
    Write-Host "   ⚠️  يرجى إنشاء ملف .env من env.example" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Step 3: Check required environment variables
Write-Host "3️⃣  التحقق من متغيرات البيئة المطلوبة..." -ForegroundColor Yellow
$envContent = Get-Content .env -Raw
$requiredVars = @("POSTGRES_USER", "POSTGRES_PASSWORD", "JWT_SECRET_KEY", "SECRET_KEY")
$missingVars = @()

foreach ($var in $requiredVars) {
    if ($envContent -notmatch "$var=") {
        $missingVars += $var
    }
}

if ($missingVars.Count -gt 0) {
    Write-Host "   ❌ متغيرات مفقودة: $($missingVars -join ', ')" -ForegroundColor Red
    Write-Host "   ⚠️  يرجى إضافة هذه المتغيرات إلى ملف .env" -ForegroundColor Yellow
} else {
    Write-Host "   ✅ جميع المتغيرات المطلوبة موجودة" -ForegroundColor Green
}
Write-Host ""

# Step 4: Remove problematic containers
Write-Host "4️⃣  إزالة الحاويات المتعثرة..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml rm -f backend ml-service prometheus
Write-Host "   ✅ تم" -ForegroundColor Green
Write-Host ""

# Step 5: Rebuild only affected containers
Write-Host "5️⃣  إعادة بناء الحاويات المتأثرة..." -ForegroundColor Yellow
Write-Host "   ⏳ هذا قد يستغرق بضع دقائق..." -ForegroundColor Gray
docker-compose -f docker-compose.production.yml build --no-cache backend ml-service
Write-Host "   ✅ تم" -ForegroundColor Green
Write-Host ""

# Step 6: Start services in order
Write-Host "6️⃣  تشغيل الخدمات بالترتيب..." -ForegroundColor Yellow
Write-Host "   أ) PostgreSQL و Redis..." -ForegroundColor Gray
docker-compose -f docker-compose.production.yml up -d postgres redis
Start-Sleep -Seconds 10

Write-Host "   ب) Backend و ML Service..." -ForegroundColor Gray
docker-compose -f docker-compose.production.yml up -d backend ml-service
Start-Sleep -Seconds 15

Write-Host "   ج) باقي الخدمات..." -ForegroundColor Gray
docker-compose -f docker-compose.production.yml up -d
Write-Host "   ✅ تم" -ForegroundColor Green
Write-Host ""

# Step 7: Wait and check status
Write-Host "7️⃣  انتظار 20 ثانية وفحص الحالة..." -ForegroundColor Yellow
Start-Sleep -Seconds 20
Write-Host ""

Write-Host "8️⃣  حالة الحاويات:" -ForegroundColor Cyan
docker-compose -f docker-compose.production.yml ps
Write-Host ""

# Step 8: Show logs for troubleshooting
Write-Host "9️⃣  سجلات Backend (آخر 20 سطر):" -ForegroundColor Cyan
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker-compose -f docker-compose.production.yml logs --tail=20 backend
Write-Host ""

Write-Host "🔟 سجلات ML Service (آخر 20 سطر):" -ForegroundColor Cyan
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker-compose -f docker-compose.production.yml logs --tail=20 ml-service
Write-Host ""

Write-Host "✅ تم!" -ForegroundColor Green
Write-Host ""

