import { drizzle } from 'drizzle-orm/mysql2';
import { accessCodes } from '../drizzle/schema';

async function main() {
  const db = drizzle(process.env.DATABASE_URL!);
  
  try {
    await db.insert(accessCodes).values({ code: '270483' });
    console.log('✅ Access code 270483 added successfully');
  } catch (error: any) {
    if (error.message?.includes('Duplicate entry')) {
      console.log('ℹ️  Access code 270483 already exists');
    } else {
      console.error('❌ Error adding access code:', error);
    }
  }
  
  process.exit(0);
}

main();

