/**
 * Database Seeding Script
 * Populates the database with initial/demo data
 * 
 * Usage: pnpm tsx scripts/seed-database.ts
 */

import { drizzle } from "drizzle-orm/mysql2";
import { assets, predictions, alerts, users } from "../drizzle/schema";

const db = drizzle(process.env.DATABASE_URL!);

async function seed() {
  console.log("🌱 Starting database seeding...");

  try {
    // Seed Assets
    console.log("📊 Seeding assets...");
    const assetData = [
      { symbol: "GOLD", name: "Gold", type: "commodity", currentPrice: "2050.00" },
      { symbol: "BTC", name: "Bitcoin", type: "cryptocurrency", currentPrice: "45000.00" },
      { symbol: "ETH", name: "Ethereum", type: "cryptocurrency", currentPrice: "2500.00" },
      { symbol: "OIL", name: "Crude Oil", type: "commodity", currentPrice: "75.00" },
      { symbol: "EURUSD", name: "EUR/USD", type: "forex", currentPrice: "1.08" },
      { symbol: "GBPUSD", name: "GBP/USD", type: "forex", currentPrice: "1.27" },
      { symbol: "SILVER", name: "Silver", type: "commodity", currentPrice: "24.50" },
      { symbol: "AAPL", name: "Apple Inc.", type: "stock", currentPrice: "175.00" },
      { symbol: "GOOGL", name: "Alphabet Inc.", type: "stock", currentPrice: "140.00" },
      { symbol: "TSLA", name: "Tesla Inc.", type: "stock", currentPrice: "250.00" },
      { symbol: "MSFT", name: "Microsoft", type: "stock", currentPrice: "380.00" },
      { symbol: "AMZN", name: "Amazon", type: "stock", currentPrice: "155.00" },
      { symbol: "SPY", name: "S&P 500 ETF", type: "etf", currentPrice: "470.00" },
      { symbol: "USO", name: "United States Oil Fund", type: "etf", currentPrice: "75.00" },
      { symbol: "GLD", name: "SPDR Gold Shares", type: "etf", currentPrice: "190.00" },
      { symbol: "DOGE", name: "Dogecoin", type: "cryptocurrency", currentPrice: "0.08" },
      { symbol: "SOL", name: "Solana", type: "cryptocurrency", currentPrice: "100.00" },
    ];

    await db.insert(assets).values(assetData);
    console.log(`✅ Seeded ${assetData.length} assets`);

    // Seed Demo User (if needed)
    console.log("👤 Checking for demo user...");
    const demoUser = {
      id: "demo-user-123",
      name: "Demo User",
      email: "demo@assetpredictor.com",
      loginMethod: "demo",
      role: "user" as const,
    };

    try {
      await db.insert(users).values(demoUser);
      console.log("✅ Created demo user");
    } catch (error) {
      console.log("ℹ️  Demo user already exists");
    }

    // Seed Sample Predictions
    console.log("🔮 Seeding sample predictions...");
    const predictionData = [
      {
        userId: demoUser.id,
        assetId: 1, // GOLD
        modelType: "LSTM",
        predictionDate: new Date(),
        targetDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        predictedPrice: "2100.00",
        confidence: "0.95",
        status: "pending" as const,
      },
      {
        userId: demoUser.id,
        assetId: 2, // BTC
        modelType: "Ensemble",
        predictionDate: new Date(),
        targetDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        predictedPrice: "48000.00",
        confidence: "0.92",
        status: "pending" as const,
      },
    ];

    await db.insert(predictions).values(predictionData);
    console.log(`✅ Seeded ${predictionData.length} predictions`);

    // Seed Sample Alerts
    console.log("🔔 Seeding sample alerts...");
    const alertData = [
      {
        userId: demoUser.id,
        assetId: 1, // GOLD
        alertType: "price_above" as const,
        targetPrice: "2100.00",
        isActive: true,
        notificationChannels: "email,push",
      },
      {
        userId: demoUser.id,
        assetId: 2, // BTC
        alertType: "price_below" as const,
        targetPrice: "40000.00",
        isActive: true,
        notificationChannels: "email,telegram",
      },
    ];

    await db.insert(alerts).values(alertData);
    console.log(`✅ Seeded ${alertData.length} alerts`);

    console.log("✅ Database seeding completed successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

// Run seeding
seed()
  .then(() => {
    console.log("🎉 Seeding finished!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  });

