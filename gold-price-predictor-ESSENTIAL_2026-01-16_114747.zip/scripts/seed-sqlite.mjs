#!/usr/bin/env node
/**
 * SQLite Database Seeding Script
 * Seeds the SQLite database with real market data
 */

import Database from 'better-sqlite3';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Read market data
const marketDataPath = '/tmp/friday_market_data.json';
const marketData = JSON.parse(readFileSync(marketDataPath, 'utf-8'));

console.log('🌱 Starting SQLite database seeding...\n');

// Connect to SQLite
const dbPath = join(__dirname, '../data/asset_predictor.db');
const db = new Database(dbPath);

// Enable foreign keys
db.pragma('foreign_keys = ON');

try {
  console.log('📊 Seeding users table...');
  
  const insertUser = db.prepare(`
    INSERT OR REPLACE INTO users (id, name, email, role, loginMethod, createdAt, lastSignedIn)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  
  insertUser.run(
    'demo-user-1',
    'Demo User',
    'demo@assetpredictor.com',
    'user',
    'oauth',
    Date.now(),
    Date.now()
  );
  
  console.log('✅ Users seeded\n');

  console.log('📊 Seeding assets table...');
  
  const insertAsset = db.prepare(`
    INSERT OR REPLACE INTO assets (id, symbol, name, assetType, exchange, currency, currentPrice, sector, description, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  marketData.forEach((item, index) => {
    insertAsset.run(
      index + 1,
      item.symbol,
      item.name,
      item.type,
      item.exchange,
      item.currency,
      item.close.toString(),
      item.type === 'stock' ? 'Technology' : item.type === 'crypto' ? 'Cryptocurrency' : 'Commodities',
      `${item.name} - ${item.exchange}`,
      Date.now()
    );
  });
  
  console.log(`✅ ${marketData.length} assets seeded\n`);

  console.log('📊 Seeding historical_prices table...');
  
  const insertPrice = db.prepare(`
    INSERT INTO historical_prices (assetId, date, price, high, low, open, volume, change, changePercent, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  marketData.forEach((item, index) => {
    insertPrice.run(
      index + 1,
      new Date(item.date).getTime(),
      item.close.toString(),
      item.high ? item.high.toString() : null,
      item.low ? item.low.toString() : null,
      item.open ? item.open.toString() : null,
      item.volume ? item.volume.toString() : null,
      '0.00',
      '0.00',
      new Date(item.timestamp * 1000).getTime()
    );
  });
  
  console.log(`✅ ${marketData.length} historical prices seeded\n`);

  console.log('📊 Seeding predictions table...');
  
  const insertPrediction = db.prepare(`
    INSERT INTO predictions (assetId, userId, modelType, horizon, predictedPrice, confidenceLevel, predictionDate, accuracy, metadata)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  const modelTypes = ['simple', 'advanced', 'ensemble'];
  const horizons = ['short', 'medium', 'long'];
  
  marketData.slice(0, 5).forEach((item, index) => {
    const predictedPrice = (item.close * (1 + (Math.random() * 0.1 - 0.05))).toFixed(2);
    const confidenceLevel = (0.85 + Math.random() * 0.1).toFixed(2);
    const accuracy = (0.80 + Math.random() * 0.15).toFixed(2);
    
    insertPrediction.run(
      index + 1,
      'demo-user-1',
      modelTypes[index % 3],
      horizons[index % 3],
      predictedPrice,
      confidenceLevel,
      Date.now() + (index + 1) * 24 * 60 * 60 * 1000,
      accuracy,
      JSON.stringify({
        features: ['price', 'volume', 'sentiment'],
        model_version: '1.0',
      })
    );
  });
  
  console.log(`✅ 5 predictions seeded\n`);

  // Get counts
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const assetCount = db.prepare('SELECT COUNT(*) as count FROM assets').get().count;
  const priceCount = db.prepare('SELECT COUNT(*) as count FROM historical_prices').get().count;
  const predictionCount = db.prepare('SELECT COUNT(*) as count FROM predictions').get().count;

  console.log('🎉 Database seeding completed successfully!');
  console.log('\n📈 Summary:');
  console.log(`  - Users: ${userCount}`);
  console.log(`  - Assets: ${assetCount}`);
  console.log(`  - Historical Prices: ${priceCount}`);
  console.log(`  - Predictions: ${predictionCount}`);
  
  db.close();
  
  console.log('\n✅ Seeding script completed');
  process.exit(0);
  
} catch (error) {
  console.error('❌ Error seeding database:', error);
  db.close();
  process.exit(1);
}

