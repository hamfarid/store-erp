// FILE: scripts/fetch-news.ts | PURPOSE: Fetch latest news for assets | OWNER: Data Team | LAST-AUDITED: 2025-11-25

import axios from 'axios';
import { getPool } from '../server/db-postgres';

interface NewsArticle {
  title: string;
  link: string;
  publisher: string;
  publishedAt: number;
  summary?: string;
  thumbnail?: string;
}

async function fetchNews() {
  console.log('\n📰 جلب آخر الأخبار...\n');
  console.log('='.repeat(80));

  const pool = getPool();

  try {
    // Get all active assets
    const assetsResult = await pool.query(
      'SELECT id, symbol, name FROM assets WHERE is_active = true ORDER BY symbol'
    );

    const assets = assetsResult.rows;
    console.log(`\n📊 البحث عن أخبار ${assets.length} أصول\n`);

    // Create news table if not exists
    await pool.query(`
      CREATE TABLE IF NOT EXISTS news (
        id VARCHAR(255) PRIMARY KEY,
        asset_id VARCHAR(255) REFERENCES assets(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        link TEXT NOT NULL,
        publisher VARCHAR(255),
        summary TEXT,
        thumbnail TEXT,
        published_at BIGINT NOT NULL,
        sentiment VARCHAR(50),
        created_at BIGINT NOT NULL
      );
    `);

    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_news_asset_id ON news(asset_id);
      CREATE INDEX IF NOT EXISTS idx_news_published_at ON news(published_at DESC);
    `);

    console.log('✅ تم إنشاء جدول الأخبار\n');

    for (const asset of assets) {
      try {
        console.log(`\n🔍 البحث عن أخبار ${asset.name} (${asset.symbol})...`);

        // Fetch news from Yahoo Finance
        const url = `https://query1.finance.yahoo.com/v1/finance/search`;
        const params = {
          q: asset.symbol,
          quotesCount: 0,
          newsCount: 10,
          enableFuzzyQuery: false,
        };

        const response = await axios.get(url, { params, timeout: 10000 });
        const news = response.data.news || [];

        if (news.length === 0) {
          console.log(`   ⚠️  لا توجد أخبار متاحة`);
          continue;
        }

        console.log(`   📰 تم العثور على ${news.length} خبر\n`);

        let insertedCount = 0;
        for (const article of news) {
          try {
            const newsId = `news_${asset.id}_${article.uuid || Date.now()}`;
            const publishedAt = article.providerPublishTime * 1000;

            await pool.query(
              `INSERT INTO news (id, asset_id, title, link, publisher, summary, thumbnail, published_at, created_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
               ON CONFLICT (id) DO NOTHING`,
              [
                newsId,
                asset.id,
                article.title,
                article.link,
                article.publisher,
                article.summary || null,
                article.thumbnail?.resolutions?.[0]?.url || null,
                publishedAt,
                Date.now(),
              ]
            );

            insertedCount++;

            // Display article
            const date = new Date(publishedAt);
            console.log(`   📄 ${article.title}`);
            console.log(`      🏢 ${article.publisher}`);
            console.log(`      📅 ${date.toLocaleString('ar-EG')}`);
            console.log(`      🔗 ${article.link}`);
            console.log('');

          } catch (error: any) {
            // Ignore duplicate errors
            if (!error.message.includes('duplicate')) {
              console.log(`      ⚠️  خطأ في حفظ الخبر: ${error.message}`);
            }
          }
        }

        console.log(`   ✅ تم حفظ ${insertedCount} خبر جديد`);

      } catch (error: any) {
        console.log(`   ❌ خطأ: ${error.message}`);
      }

      // Wait 2 seconds between requests to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    // Display summary
    console.log('\n' + '='.repeat(80));
    console.log('\n📊 ملخص الأخبار:\n');

    const summaryResult = await pool.query(`
      SELECT 
        a.name,
        a.symbol,
        COUNT(n.id) as news_count,
        MAX(n.published_at) as latest_news
      FROM assets a
      LEFT JOIN news n ON a.id = n.asset_id
      WHERE a.is_active = true
      GROUP BY a.id, a.name, a.symbol
      ORDER BY a.symbol
    `);

    for (const row of summaryResult.rows) {
      const latestDate = row.latest_news ? new Date(parseInt(row.latest_news)).toLocaleString('ar-EG') : 'لا توجد أخبار';
      console.log(`   ${row.name} (${row.symbol}): ${row.news_count} خبر - آخر خبر: ${latestDate}`);
    }

    console.log('\n✅ تم جلب جميع الأخبار بنجاح!\n');

  } catch (error: any) {
    console.error(`\n❌ خطأ: ${error.message}\n`);
  } finally {
    await pool.end();
  }
}

fetchNews().catch(console.error);

