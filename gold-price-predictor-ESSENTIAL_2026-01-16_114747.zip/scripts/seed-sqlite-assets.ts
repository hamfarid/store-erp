#!/usr/bin/env tsx
/**
 * Seed script to populate SQLite database with initial assets data
 */

import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'asset_predictor.db');
console.log('📂 Database path:', dbPath);

const db = new Database(dbPath);

// First, check what columns exist in the assets table
const tableInfo = db.prepare("PRAGMA table_info(assets)").all() as { name: string }[];
const existingColumns = tableInfo.map(col => col.name);
console.log('📋 Existing columns in assets:', existingColumns);

// If table doesn't have required columns, drop and recreate
if (!existingColumns.includes('category') || existingColumns.length < 5) {
  console.log('🔄 Recreating assets table with correct schema...');
  db.exec('DROP TABLE IF EXISTS assets');
  
  db.exec(`
    CREATE TABLE assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      symbol TEXT NOT NULL UNIQUE,
      type TEXT,
      yahooSymbol TEXT,
      description TEXT,
      category TEXT NOT NULL DEFAULT 'commodity',
      currentPrice REAL DEFAULT 0,
      isActive INTEGER DEFAULT 1,
      createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
      updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  db.exec('CREATE INDEX IF NOT EXISTS assets_symbol_idx ON assets(symbol)');
  db.exec('CREATE INDEX IF NOT EXISTS assets_category_idx ON assets(category)');
  console.log('✅ Assets table recreated successfully');
}

const assetsData = [
  // Commodities
  { name: "الذهب (Gold)", symbol: "GC=F", category: "commodity", currentPrice: 2050.00 },
  { name: "الفضة (Silver)", symbol: "SI=F", category: "commodity", currentPrice: 24.50 },
  { name: "النفط WTI", symbol: "CL=F", category: "commodity", currentPrice: 75.00 },
  { name: "النفط برنت (Brent)", symbol: "BZ=F", category: "commodity", currentPrice: 80.00 },
  { name: "البلاتين (Platinum)", symbol: "PL=F", category: "commodity", currentPrice: 950.00 },
  { name: "النحاس (Copper)", symbol: "HG=F", category: "commodity", currentPrice: 4.20 },
  { name: "الغاز الطبيعي", symbol: "NG=F", category: "commodity", currentPrice: 2.50 },
  
  // Cryptocurrencies
  { name: "البيتكوين (Bitcoin)", symbol: "BTC-USD", category: "crypto", currentPrice: 95000.00 },
  { name: "الإيثيريوم (Ethereum)", symbol: "ETH-USD", category: "crypto", currentPrice: 3500.00 },
  { name: "سولانا (Solana)", symbol: "SOL-USD", category: "crypto", currentPrice: 180.00 },
  
  // Currencies
  { name: "الدولار/الليرة التركية", symbol: "USDTRY=X", category: "currency", currentPrice: 34.50 },
  { name: "الدولار/الجنيه المصري", symbol: "USDEGP=X", category: "currency", currentPrice: 50.00 },
  { name: "اليورو/الدولار", symbol: "EURUSD=X", category: "currency", currentPrice: 1.05 },
];

console.log("🌱 Seeding assets to SQLite database...\n");

const insertStmt = db.prepare(`
  INSERT OR REPLACE INTO assets (name, symbol, category, currentPrice, isActive, updatedAt)
  VALUES (?, ?, ?, ?, 1, datetime('now'))
`);

try {
  const insertMany = db.transaction((assets: typeof assetsData) => {
    for (const asset of assets) {
      insertStmt.run(asset.name, asset.symbol, asset.category, asset.currentPrice);
      console.log(`✅ Added: ${asset.name} (${asset.symbol}) - $${asset.currentPrice}`);
    }
  });

  insertMany(assetsData);
  
  // Verify
  const count = db.prepare('SELECT COUNT(*) as count FROM assets').get() as { count: number };
  console.log(`\n✅ Seeding completed! Total assets: ${count.count}`);
  
  // List all assets
  const allAssets = db.prepare('SELECT id, name, symbol, category, currentPrice FROM assets').all();
  console.log('\n📊 Assets in database:');
  console.table(allAssets);
  
} catch (error) {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
} finally {
  db.close();
}

console.log('\n✅ Database seeded successfully!');

