# ################################################################################
# سكريبت تثبيت وتشغيل نظام التنبؤ بأسعار الأصول - Windows
# Asset Price Prediction System - Windows Setup Script
# ################################################################################

# تشغيل بصلاحيات المسؤول
#Requires -RunAsAdministrator

# الألوان
function Write-Header {
    param([string]$Message)
    Write-Host "================================" -ForegroundColor Blue
    Write-Host $Message -ForegroundColor Blue
    Write-Host "================================" -ForegroundColor Blue
}

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error-Custom {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Warning-Custom {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Cyan
}

# التحقق من صلاحيات المسؤول
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# التحقق من نظام التشغيل
function Test-WindowsOS {
    Write-Header "التحقق من نظام التشغيل"
    
    if ($PSVersionTable.Platform -eq "Win32NT" -or $null -eq $PSVersionTable.Platform) {
        Write-Success "نظام Windows مكتشف"
        Write-Info "الإصدار: $([System.Environment]::OSVersion.VersionString)"
    } else {
        Write-Error-Custom "هذا السكريبت مخصص لـ Windows فقط"
        Write-Info "استخدم setup_linux.sh لـ Linux"
        exit 1
    }
}

# تثبيت Chocolatey
function Install-Chocolatey {
    Write-Header "تثبيت Chocolatey"
    
    if (Get-Command choco -ErrorAction SilentlyContinue) {
        Write-Success "Chocolatey مثبت بالفعل"
    } else {
        Write-Info "تثبيت Chocolatey..."
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        Write-Success "تم تثبيت Chocolatey"
    }
}

# تثبيت المتطلبات الأساسية
function Install-SystemDependencies {
    Write-Header "تثبيت المتطلبات الأساسية"
    
    # تثبيت Git
    if (Get-Command git -ErrorAction SilentlyContinue) {
        Write-Success "Git مثبت بالفعل"
    } else {
        Write-Info "تثبيت Git..."
        choco install git -y
        Write-Success "تم تثبيت Git"
        
        # تحديث PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    }
    
    # تثبيت Python 3.11
    if (Get-Command python -ErrorAction SilentlyContinue) {
        $pythonVersion = python --version
        if ($pythonVersion -match "3\.11") {
            Write-Success "Python 3.11 مثبت بالفعل"
        } else {
            Write-Warning-Custom "Python مثبت لكن ليس الإصدار 3.11"
            Write-Info "تثبيت Python 3.11..."
            choco install python311 -y
            Write-Success "تم تثبيت Python 3.11"
        }
    } else {
        Write-Info "تثبيت Python 3.11..."
        choco install python311 -y
        Write-Success "تم تثبيت Python 3.11"
    }
    
    # تحديث PATH
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    
    # تثبيت Node.js
    if (Get-Command node -ErrorAction SilentlyContinue) {
        Write-Success "Node.js مثبت بالفعل"
    } else {
        Write-Info "تثبيت Node.js..."
        choco install nodejs-lts -y
        Write-Success "تم تثبيت Node.js"
    }
    
    # تحديث PATH
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    
    # تثبيت pnpm
    if (Get-Command pnpm -ErrorAction SilentlyContinue) {
        Write-Success "pnpm مثبت بالفعل"
    } else {
        Write-Info "تثبيت pnpm..."
        npm install -g pnpm
        Write-Success "تم تثبيت pnpm"
    }
}

# استنساخ المشروع من GitHub
function Clone-Project {
    Write-Header "استنساخ المشروع من GitHub"
    
    # المسار الافتراضي
    $ProjectDir = "$env:USERPROFILE\gold-price-predictor"
    
    # استنساخ gold-price-predictor
    if (Test-Path $ProjectDir) {
        Write-Warning-Custom "المجلد موجود بالفعل: $ProjectDir"
        $response = Read-Host "هل تريد حذفه وإعادة الاستنساخ؟ (y/n)"
        if ($response -eq "y" -or $response -eq "Y") {
            Remove-Item -Path $ProjectDir -Recurse -Force
            git clone https://github.com/hamfarid/gold-price-predictor.git $ProjectDir
            Write-Success "تم استنساخ gold-price-predictor"
        } else {
            Write-Info "استخدام المجلد الموجود"
        }
    } else {
        git clone https://github.com/hamfarid/gold-price-predictor.git $ProjectDir
        Write-Success "تم استنساخ gold-price-predictor"
    }
    
    return $ProjectDir
}

# إعداد البيئة الافتراضية لـ Python
function Setup-PythonEnv {
    param([string]$ProjectDir)
    
    Write-Header "إعداد البيئة الافتراضية لـ Python"
    
    Set-Location $ProjectDir
    
    # إنشاء البيئة الافتراضية
    if (Test-Path "venv") {
        Write-Success "البيئة الافتراضية موجودة"
    } else {
        Write-Info "إنشاء البيئة الافتراضية..."
        python -m venv venv
        Write-Success "تم إنشاء البيئة الافتراضية"
    }
    
    # تفعيل البيئة
    & "$ProjectDir\venv\Scripts\Activate.ps1"
    
    # ترقية pip
    Write-Info "ترقية pip..."
    python -m pip install --upgrade pip
    
    # تثبيت المتطلبات
    if (Test-Path "requirements.txt") {
        Write-Info "تثبيت متطلبات Python..."
        pip install -r requirements.txt
        Write-Success "تم تثبيت متطلبات Python"
    } else {
        Write-Warning-Custom "ملف requirements.txt غير موجود"
        Write-Info "تثبيت الحزم الأساسية..."
        pip install fastapi uvicorn yfinance pandas numpy scikit-learn joblib
    }
}

# إعداد Frontend
function Setup-Frontend {
    param([string]$ProjectDir)
    
    Write-Header "إعداد Frontend"
    
    # البحث عن مجلد Frontend
    $FrontendDir = $null
    
    if (Test-Path "$ProjectDir\asset_predictor_ui") {
        $FrontendDir = "$ProjectDir\asset_predictor_ui"
    } elseif (Test-Path "$env:USERPROFILE\asset-predictor-ui") {
        $FrontendDir = "$env:USERPROFILE\asset-predictor-ui"
    } else {
        Write-Warning-Custom "مجلد Frontend غير موجود"
        return
    }
    
    Set-Location $FrontendDir
    
    # تثبيت dependencies
    if (Test-Path "package.json") {
        Write-Info "تثبيت متطلبات Node.js..."
        pnpm install
        Write-Success "تم تثبيت متطلبات Node.js"
    } else {
        Write-Warning-Custom "ملف package.json غير موجود"
    }
}

# إنشاء ملف .env
function Create-EnvFile {
    param([string]$ProjectDir)
    
    Write-Header "إنشاء ملف .env"
    
    Set-Location $ProjectDir
    
    if (Test-Path ".env") {
        Write-Success "ملف .env موجود بالفعل"
    } else {
        $envContent = @"
# Python API
PYTHON_API_PORT=8000

# Database
DATABASE_URL=file:./database.db

# Email (اختياري)
# EMAIL_USER=your-email@gmail.com
# EMAIL_PASSWORD=your-app-password

# Frontend
VITE_API_URL=http://localhost:8000
"@
        $envContent | Out-File -FilePath ".env" -Encoding UTF8
        Write-Success "تم إنشاء ملف .env"
    }
}

# بدء الخدمات
function Start-Services {
    param([string]$ProjectDir)
    
    Write-Header "بدء الخدمات"
    
    # بدء Python API
    Write-Info "بدء Python API..."
    Set-Location $ProjectDir
    
    # إيقاف العمليات القديمة
    Get-Process | Where-Object {$_.ProcessName -like "*python*" -and $_.MainWindowTitle -like "*simple_api*"} | Stop-Process -Force -ErrorAction SilentlyContinue
    
    # بدء API في الخلفية
    $apiJob = Start-Job -ScriptBlock {
        param($dir)
        Set-Location $dir
        & "$dir\venv\Scripts\python.exe" simple_api.py
    } -ArgumentList $ProjectDir
    
    Write-Success "Python API يعمل (Job ID: $($apiJob.Id))"
    Write-Info "السجلات: استخدم Receive-Job $($apiJob.Id)"
    
    # الانتظار قليلاً
    Start-Sleep -Seconds 5
    
    # التحقق من عمل API
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:8000/models" -UseBasicParsing
        Write-Success "Python API يعمل بنجاح!"
    } catch {
        Write-Error-Custom "فشل بدء Python API"
        Write-Info "تحقق من السجلات: Receive-Job $($apiJob.Id)"
    }
    
    # بدء Frontend
    $FrontendDir = $null
    
    if (Test-Path "$ProjectDir\asset_predictor_ui") {
        $FrontendDir = "$ProjectDir\asset_predictor_ui"
    } elseif (Test-Path "$env:USERPROFILE\asset-predictor-ui") {
        $FrontendDir = "$env:USERPROFILE\asset-predictor-ui"
    }
    
    if ($FrontendDir) {
        Write-Info "بدء Frontend..."
        Set-Location $FrontendDir
        
        # بدء Frontend في الخلفية
        $frontendJob = Start-Job -ScriptBlock {
            param($dir)
            Set-Location $dir
            pnpm dev
        } -ArgumentList $FrontendDir
        
        Write-Success "Frontend يعمل (Job ID: $($frontendJob.Id))"
        Write-Info "السجلات: استخدم Receive-Job $($frontendJob.Id)"
        
        Start-Sleep -Seconds 5
        
        Write-Success "Frontend يعمل على http://localhost:3000"
    }
}

# عرض الملخص
function Show-Summary {
    param([string]$ProjectDir)
    
    Write-Header "الملخص"
    
    Write-Host ""
    Write-Success "تم تثبيت وتشغيل النظام بنجاح!"
    Write-Host ""
    Write-Host "الخدمات:" -ForegroundColor Blue
    Write-Host "  • Python API: " -NoNewline
    Write-Host "http://localhost:8000" -ForegroundColor Green
    Write-Host "  • Frontend: " -NoNewline
    Write-Host "http://localhost:3000" -ForegroundColor Green
    Write-Host ""
    Write-Host "الأوامر المفيدة:" -ForegroundColor Blue
    Write-Host "  • عرض الوظائف: " -NoNewline
    Write-Host "Get-Job" -ForegroundColor Yellow
    Write-Host "  • عرض السجلات: " -NoNewline
    Write-Host "Receive-Job <Job-ID>" -ForegroundColor Yellow
    Write-Host "  • إيقاف وظيفة: " -NoNewline
    Write-Host "Stop-Job <Job-ID>" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "البيئة الافتراضية:" -ForegroundColor Blue
    Write-Host "  • تفعيل: " -NoNewline
    Write-Host "$ProjectDir\venv\Scripts\Activate.ps1" -ForegroundColor Yellow
    Write-Host "  • إلغاء التفعيل: " -NoNewline
    Write-Host "deactivate" -ForegroundColor Yellow
    Write-Host ""
}

# الدالة الرئيسية
function Main {
    Clear-Host
    
    Write-Header "نظام التنبؤ بأسعار الأصول - Windows Setup"
    Write-Host ""
    
    if (-not (Test-Administrator)) {
        Write-Warning-Custom "يُفضل تشغيل السكريبت بصلاحيات المسؤول"
        Write-Info "انقر بزر الماوس الأيمن على PowerShell واختر 'Run as Administrator'"
        Write-Host ""
    }
    
    Test-WindowsOS
    
    Write-Host ""
    $response = Read-Host "هل تريد المتابعة؟ (y/n)"
    
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Info "تم الإلغاء"
        exit 0
    }
    
    Install-Chocolatey
    Install-SystemDependencies
    $ProjectDir = Clone-Project
    Setup-PythonEnv -ProjectDir $ProjectDir
    Setup-Frontend -ProjectDir $ProjectDir
    Create-EnvFile -ProjectDir $ProjectDir
    Start-Services -ProjectDir $ProjectDir
    Show-Summary -ProjectDir $ProjectDir
    
    Write-Success "تم بنجاح! 🎉"
}

# تشغيل السكريبت
Main

