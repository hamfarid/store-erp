# Asset Predictor UI - Windows Setup Script
# This script installs all dependencies and sets up the project

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Asset Predictor UI - Windows Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "⚠️  This script requires Administrator privileges" -ForegroundColor Yellow
    Write-Host "Please run PowerShell as Administrator and try again" -ForegroundColor Yellow
    exit 1
}

# Function to check if a command exists
function Test-Command($command) {
    try {
        if (Get-Command $command -ErrorAction Stop) {
            return $true
        }
    }
    catch {
        return $false
    }
}

# Check Node.js
Write-Host "Checking Node.js..." -ForegroundColor Yellow
if (Test-Command "node") {
    $nodeVersion = node --version
    Write-Host "✅ Node.js is installed: $nodeVersion" -ForegroundColor Green
} else {
    Write-Host "❌ Node.js is not installed" -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org/" -ForegroundColor Yellow
    Write-Host "Recommended version: 18.x or higher" -ForegroundColor Yellow
    exit 1
}

# Check pnpm
Write-Host "Checking pnpm..." -ForegroundColor Yellow
if (Test-Command "pnpm") {
    $pnpmVersion = pnpm --version
    Write-Host "✅ pnpm is installed: $pnpmVersion" -ForegroundColor Green
} else {
    Write-Host "❌ pnpm is not installed" -ForegroundColor Red
    Write-Host "Installing pnpm..." -ForegroundColor Yellow
    npm install -g pnpm
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ pnpm installed successfully" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to install pnpm" -ForegroundColor Red
        exit 1
    }
}

# Check Python (for ML models)
Write-Host "Checking Python..." -ForegroundColor Yellow
if (Test-Command "python") {
    $pythonVersion = python --version
    Write-Host "✅ Python is installed: $pythonVersion" -ForegroundColor Green
} else {
    Write-Host "⚠️  Python is not installed (optional for ML features)" -ForegroundColor Yellow
    Write-Host "Install from https://www.python.org/ if you need ML predictions" -ForegroundColor Yellow
}

# Check MySQL
Write-Host "Checking MySQL..." -ForegroundColor Yellow
if (Test-Command "mysql") {
    Write-Host "✅ MySQL is installed" -ForegroundColor Green
} else {
    Write-Host "⚠️  MySQL is not installed" -ForegroundColor Yellow
    Write-Host "Install from https://dev.mysql.com/downloads/installer/" -ForegroundColor Yellow
    Write-Host "Or use a cloud database (TiDB, PlanetScale, etc.)" -ForegroundColor Yellow
}

# Install dependencies
Write-Host ""
Write-Host "Installing project dependencies..." -ForegroundColor Yellow
pnpm install
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Dependencies installed successfully" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to install dependencies" -ForegroundColor Red
    exit 1
}

# Check for .env file
Write-Host ""
Write-Host "Checking environment configuration..." -ForegroundColor Yellow
if (Test-Path ".env") {
    Write-Host "✅ .env file exists" -ForegroundColor Green
} else {
    Write-Host "⚠️  .env file not found" -ForegroundColor Yellow
    Write-Host "Creating .env from template..." -ForegroundColor Yellow
    
    $envContent = @"
# Database Configuration
DATABASE_URL=mysql://user:password@localhost:3306/asset_predictor

# JWT Secret (change this!)
JWT_SECRET=your-secret-key-here-change-this

# Manus OAuth (get from https://manus.im)
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# App Configuration
VITE_APP_TITLE=Asset Predictor UI
VITE_APP_LOGO=

# Owner Configuration (optional)
OWNER_OPEN_ID=
OWNER_NAME=

# Built-in APIs (auto-configured by Manus)
BUILT_IN_FORGE_API_URL=
BUILT_IN_FORGE_API_KEY=

# Analytics (optional)
VITE_ANALYTICS_ENDPOINT=
VITE_ANALYTICS_WEBSITE_ID=
"@
    
    $envContent | Out-File -FilePath ".env" -Encoding UTF8
    Write-Host "✅ .env file created" -ForegroundColor Green
    Write-Host "⚠️  Please edit .env and configure your settings" -ForegroundColor Yellow
}

# Setup database
Write-Host ""
Write-Host "Would you like to setup the database now? (Y/N)" -ForegroundColor Yellow
$setupDb = Read-Host
if ($setupDb -eq "Y" -or $setupDb -eq "y") {
    Write-Host "Running database migrations..." -ForegroundColor Yellow
    pnpm db:push
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Database setup complete" -ForegroundColor Green
    } else {
        Write-Host "❌ Database setup failed" -ForegroundColor Red
        Write-Host "Please check your DATABASE_URL in .env" -ForegroundColor Yellow
    }
}

# Install Python dependencies (optional)
Write-Host ""
Write-Host "Would you like to install Python ML dependencies? (Y/N)" -ForegroundColor Yellow
$setupPython = Read-Host
if ($setupPython -eq "Y" -or $setupPython -eq "y") {
    if (Test-Command "python") {
        Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
        python -m pip install --upgrade pip
        python -m pip install pandas numpy scikit-learn tensorflow yfinance
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Python dependencies installed" -ForegroundColor Green
        } else {
            Write-Host "❌ Failed to install Python dependencies" -ForegroundColor Red
        }
    } else {
        Write-Host "❌ Python is not installed" -ForegroundColor Red
    }
}

# Create desktop shortcut
Write-Host ""
Write-Host "Would you like to create a desktop shortcut? (Y/N)" -ForegroundColor Yellow
$createShortcut = Read-Host
if ($createShortcut -eq "Y" -or $createShortcut -eq "y") {
    $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("$Home\Desktop\Asset Predictor UI.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-NoExit -Command `"cd '$PWD'; pnpm dev`""
    $Shortcut.WorkingDirectory = $PWD
    $Shortcut.IconLocation = "powershell.exe,0"
    $Shortcut.Description = "Asset Predictor UI - Financial Asset Price Prediction System"
    $Shortcut.Save()
    Write-Host "✅ Desktop shortcut created" -ForegroundColor Green
}

# Final message
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "To start the application:" -ForegroundColor Yellow
Write-Host "  1. Make sure your .env file is configured" -ForegroundColor White
Write-Host "  2. Run: pnpm dev" -ForegroundColor White
Write-Host "  3. Open: http://localhost:3000" -ForegroundColor White
Write-Host ""
Write-Host "For production deployment:" -ForegroundColor Yellow
Write-Host "  1. Run: pnpm build" -ForegroundColor White
Write-Host "  2. Run: pnpm start" -ForegroundColor White
Write-Host ""
Write-Host "Documentation: README.md" -ForegroundColor Yellow
Write-Host "Support: https://help.manus.im" -ForegroundColor Yellow
Write-Host ""

