#!/bin/bash
# Full Stack Deployment Script

set -e
echo "🚀 Deploying Full Production Stack..."

# Step 1: Setup ALB
echo "Step 1/5: Setting up Load Balancer..."
./setup_alb.sh

# Step 2: Setup Database Replicas
echo "Step 2/5: Setting up Database Replicas..."
./setup_db_replicas.sh

# Step 3: Setup Redis Cluster
echo "Step 3/5: Setting up Redis Cluster..."
./setup_redis_cluster.sh

# Step 4: Deploy Application
echo "Step 4/5: Deploying Application..."
docker-compose -f docker-compose.prod.yml up -d

# Step 5: Setup Monitoring
echo "Step 5/5: Setting up Monitoring..."
docker-compose -f docker-compose.monitoring.yml up -d

echo "🎉 Full stack deployment complete!"
echo ""
echo "Services:"
echo "- Application: https://api.goldpredictor.com"
echo "- Prometheus: http://localhost:9090"
echo "- Grafana: http://localhost:3000"
