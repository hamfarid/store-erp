#!/bin/bash
# Database Read Replicas Setup Script

set -e
echo "🚀 Setting up Database Read Replicas..."

PROJECT_NAME="gold-predictor"
MASTER_DB="${MASTER_DB:-gold-predictor-master}"

# Create replica 1
aws rds create-db-instance-read-replica \
  --db-instance-identifier ${PROJECT_NAME}-replica-1 \
  --source-db-instance-identifier $MASTER_DB \
  --db-instance-class db.t3.medium \
  --availability-zone us-east-1b

# Create replica 2
aws rds create-db-instance-read-replica \
  --db-instance-identifier ${PROJECT_NAME}-replica-2 \
  --source-db-instance-identifier $MASTER_DB \
  --db-instance-class db.t3.medium \
  --availability-zone us-east-1c

echo "✅ Read replicas creation initiated"
echo "⏳ Waiting for replicas to be available (this may take 10-15 minutes)..."

aws rds wait db-instance-available --db-instance-identifier ${PROJECT_NAME}-replica-1
aws rds wait db-instance-available --db-instance-identifier ${PROJECT_NAME}-replica-2

echo "🎉 Read replicas are ready!"
