#!/bin/bash
# Redis Cluster Setup Script

set -e
echo "🚀 Setting up Redis Cluster..."

PROJECT_NAME="gold-predictor"
SUBNET_GROUP="${SUBNET_GROUP:-my-subnet-group}"
SECURITY_GROUP="${SECURITY_GROUP:-sg-12345678}"

aws elasticache create-replication-group \
  --replication-group-id ${PROJECT_NAME}-redis \
  --replication-group-description "${PROJECT_NAME} Redis Cluster" \
  --engine redis \
  --cache-node-type cache.t3.medium \
  --num-cache-clusters 3 \
  --automatic-failover-enabled \
  --multi-az-enabled \
  --cache-subnet-group-name $SUBNET_GROUP \
  --security-group-ids $SECURITY_GROUP

echo "✅ Redis cluster creation initiated"
echo "⏳ Waiting for cluster to be available..."

aws elasticache wait replication-group-available \
  --replication-group-id ${PROJECT_NAME}-redis

echo "🎉 Redis cluster is ready!"
