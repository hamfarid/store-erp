#!/bin/bash
# AWS Application Load Balancer Setup Script
# Usage: ./setup_alb.sh

set -e

echo "🚀 Setting up AWS Application Load Balancer..."

# Configuration
PROJECT_NAME="gold-predictor"
VPC_ID="${VPC_ID:-vpc-12345678}"
SUBNET_1="${SUBNET_1:-subnet-12345678}"
SUBNET_2="${SUBNET_2:-subnet-87654321}"
CERT_DOMAIN="${CERT_DOMAIN:-api.goldpredictor.com}"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Step 1: Creating Security Groups...${NC}"

# Create ALB security group
ALB_SG_ID=$(aws ec2 create-security-group \
  --group-name ${PROJECT_NAME}-alb-sg \
  --description "Security group for ${PROJECT_NAME} ALB" \
  --vpc-id $VPC_ID \
  --query 'GroupId' \
  --output text)

echo -e "${GREEN}✅ Created ALB security group: $ALB_SG_ID${NC}"

# Allow HTTP & HTTPS
aws ec2 authorize-security-group-ingress --group-id $ALB_SG_ID --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-id $ALB_SG_ID --protocol tcp --port 443 --cidr 0.0.0.0/0

echo -e "${YELLOW}Step 2: Creating Target Group...${NC}"

TG_ARN=$(aws elbv2 create-target-group \
  --name ${PROJECT_NAME}-targets \
  --protocol HTTP \
  --port 8000 \
  --vpc-id $VPC_ID \
  --health-check-path /health \
  --query 'TargetGroups[0].TargetGroupArn' \
  --output text)

echo -e "${GREEN}✅ Created target group: $TG_ARN${NC}"

echo -e "${YELLOW}Step 3: Creating ALB...${NC}"

ALB_ARN=$(aws elbv2 create-load-balancer \
  --name ${PROJECT_NAME}-alb \
  --subnets $SUBNET_1 $SUBNET_2 \
  --security-groups $ALB_SG_ID \
  --query 'LoadBalancers[0].LoadBalancerArn' \
  --output text)

ALB_DNS=$(aws elbv2 describe-load-balancers \
  --load-balancer-arns $ALB_ARN \
  --query 'LoadBalancers[0].DNSName' \
  --output text)

echo -e "${GREEN}✅ Created ALB: $ALB_DNS${NC}"

echo -e "${GREEN}🎉 ALB Setup Complete!${NC}"
echo "ALB DNS: $ALB_DNS"
echo "Target Group: $TG_ARN"
