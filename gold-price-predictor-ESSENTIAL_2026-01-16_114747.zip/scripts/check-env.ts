// FILE: scripts/check-env.ts | PURPOSE: Check environment variables | OWNER: Backend Team | RELATED: .env | LAST-AUDITED: 2025-11-25

import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

console.log('\n🔍 Checking Environment Variables...\n');
console.log('=' .repeat(50));

const vars = [
  'JWT_SECRET',
  'JWT_SECRET_KEY',
  'SECRET_KEY',
  'DATABASE_URL',
  'DATABASE_URL_POSTGRES',
  'NODE_ENV',
];

vars.forEach(varName => {
  const value = process.env[varName];
  if (value) {
    console.log(`✅ ${varName}: ${value.substring(0, 20)}... (length: ${value.length})`);
  } else {
    console.log(`❌ ${varName}: NOT SET`);
  }
});

console.log('=' .repeat(50));
console.log('\n');

