/**
 * Setup Learning Control Tables
 * Creates the 5 tables needed for Learning Control Dashboard using Drizzle
 */

import { getDb } from '../server/db.js';
import Database from 'better-sqlite3';
import { join } from 'path';
import { mkdirSync, existsSync } from 'fs';

async function setupLearningControlTables() {
  console.log('🔧 Setting up Learning Control tables...\n');

  // Get database connection
  const db = await getDb();
  if (!db) {
    console.error('❌ Database connection failed');
    process.exit(1);
  }

  // For SQLite, we need to use raw SQL
  const dbUrl = process.env.DATABASE_URL || 'file:./data/app.db';
  
  if (dbUrl.startsWith('file:')) {
    const dbPath = dbUrl.replace('file:', '');
    const dataDir = join(process.cwd(), 'data');
    
    // Ensure data directory exists
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
      console.log('📂 Created data directory');
    }

    const sqliteDb = new Database(dbPath);
    sqliteDb.pragma('foreign_keys = ON');

    console.log('\n📋 Creating Learning Control tables...');

    // Search Keywords table
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS search_keywords (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        keyword TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL CHECK(category IN ('political', 'economic', 'geopolitical', 'monetary_policy', 'market', 'commodity', 'general')),
        priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high', 'critical')),
        enabled INTEGER DEFAULT 1,
        search_count INTEGER DEFAULT 0,
        last_used INTEGER,
        results_found INTEGER DEFAULT 0,
        created_by TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
        updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
      )
    `);
    console.log('  ✅ search_keywords');

    // Search Sources table
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS search_sources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('search_engine', 'news_site', 'financial_site', 'government_site', 'social_media', 'api')),
        url TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        config TEXT,
        headers TEXT,
        rate_limit INTEGER DEFAULT 60,
        request_count INTEGER DEFAULT 0,
        success_count INTEGER DEFAULT 0,
        error_count INTEGER DEFAULT 0,
        last_used INTEGER,
        last_error TEXT,
        avg_response_time INTEGER,
        reliability INTEGER DEFAULT 100,
        created_by TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
        updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
      )
    `);
    console.log('  ✅ search_sources');

    // Learning Operations table
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS learning_operations (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL CHECK(type IN ('prediction_comparison', 'pattern_detection', 'correlation_analysis', 'model_training', 'insight_generation', 'adjustment_application')),
        status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
        progress INTEGER DEFAULT 0,
        current_step TEXT,
        total_steps INTEGER,
        input TEXT,
        output TEXT,
        error TEXT,
        started_at INTEGER,
        completed_at INTEGER,
        duration INTEGER,
        results_count INTEGER DEFAULT 0,
        insights_generated INTEGER DEFAULT 0,
        adjustments_proposed INTEGER DEFAULT 0,
        triggered_by TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
        updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
      )
    `);
    console.log('  ✅ learning_operations');

    // Search Operations table
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS search_operations (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL CHECK(type IN ('keyword_search', 'event_discovery', 'news_scraping', 'sentiment_analysis', 'entity_extraction')),
        status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
        keywords TEXT NOT NULL,
        sources TEXT NOT NULL,
        date_range TEXT,
        progress INTEGER DEFAULT 0,
        current_source TEXT,
        sources_processed INTEGER DEFAULT 0,
        total_sources INTEGER,
        results_found INTEGER DEFAULT 0,
        events_created INTEGER DEFAULT 0,
        error TEXT,
        started_at INTEGER,
        completed_at INTEGER,
        duration INTEGER,
        triggered_by TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
        updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
      )
    `);
    console.log('  ✅ search_operations');

    // Operation Logs table
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS operation_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id TEXT NOT NULL,
        operation_type TEXT NOT NULL CHECK(operation_type IN ('learning', 'search')),
        level TEXT NOT NULL CHECK(level IN ('debug', 'info', 'warning', 'error')),
        message TEXT NOT NULL,
        data TEXT,
        timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
      )
    `);
    console.log('  ✅ operation_logs');

    // Create indexes
    console.log('\n📋 Creating indexes...');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_category ON search_keywords(category)');
    console.log('  ✅ idx_search_keywords_category');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_priority ON search_keywords(priority)');
    console.log('  ✅ idx_search_keywords_priority');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_enabled ON search_keywords(enabled)');
    console.log('  ✅ idx_search_keywords_enabled');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_type ON search_sources(type)');
    console.log('  ✅ idx_search_sources_type');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_enabled ON search_sources(enabled)');
    console.log('  ✅ idx_search_sources_enabled');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_type ON learning_operations(type)');
    console.log('  ✅ idx_learning_operations_type');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_status ON learning_operations(status)');
    console.log('  ✅ idx_learning_operations_status');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_created_at ON learning_operations(created_at)');
    console.log('  ✅ idx_learning_operations_created_at');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_type ON search_operations(type)');
    console.log('  ✅ idx_search_operations_type');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_status ON search_operations(status)');
    console.log('  ✅ idx_search_operations_status');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_created_at ON search_operations(created_at)');
    console.log('  ✅ idx_search_operations_created_at');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_id ON operation_logs(operation_id)');
    console.log('  ✅ idx_operation_logs_operation_id');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_level ON operation_logs(level)');
    console.log('  ✅ idx_operation_logs_level');

    sqliteDb.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_timestamp ON operation_logs(timestamp)');
    console.log('  ✅ idx_operation_logs_timestamp');

    console.log('\n✅ Learning Control tables setup complete!');

    // Verify tables exist
    console.log('\n📊 Verifying tables...');
    const tables = sqliteDb.prepare(`
      SELECT name FROM sqlite_master 
      WHERE type='table' 
      AND name IN ('search_keywords', 'search_sources', 'learning_operations', 'search_operations', 'operation_logs')
    `).all();
    
    console.log(`✅ Found ${tables.length}/5 tables:`);
    tables.forEach((table: any) => console.log(`   - ${table.name}`));

    sqliteDb.close();
  } else {
    console.log('⚠️  MySQL/PostgreSQL detected. Please run migrations manually or use drizzle-kit push.');
  }
}

// Run setup
setupLearningControlTables().catch(console.error);

