// FILE: scripts/create-assets-table.ts | PURPOSE: Create assets and price history tables | OWNER: Backend Team | LAST-AUDITED: 2025-11-25

import { getPool } from "../server/db-postgres";

async function createAssetsTables() {
  const pool = getPool();

  try {
    console.log("🔧 Creating assets and price history tables...\n");

    // Create assets table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS assets (
        id VARCHAR(255) PRIMARY KEY,
        symbol VARCHAR(50) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL, -- 'gold', 'silver', 'crypto', 'stock'
        currency VARCHAR(10) DEFAULT 'USD',
        exchange VARCHAR(100),
        description TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at BIGINT NOT NULL,
        updated_at BIGINT NOT NULL,
        deleted_at BIGINT
      );
    `);
    console.log("✅ Assets table created");

    // Create price_history table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS price_history (
        id VARCHAR(255) PRIMARY KEY,
        asset_id VARCHAR(255) NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
        timestamp BIGINT NOT NULL,
        open DECIMAL(20, 8) NOT NULL,
        high DECIMAL(20, 8) NOT NULL,
        low DECIMAL(20, 8) NOT NULL,
        close DECIMAL(20, 8) NOT NULL,
        volume BIGINT DEFAULT 0,
        source VARCHAR(100) DEFAULT 'manual',
        created_at BIGINT NOT NULL
      );
    `);
    console.log("✅ Price history table created");

    // Create indexes
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_price_history_asset_id 
      ON price_history(asset_id);
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_price_history_timestamp 
      ON price_history(timestamp DESC);
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_price_history_asset_timestamp 
      ON price_history(asset_id, timestamp DESC);
    `);
    console.log("✅ Indexes created");

    // Insert default assets
    const now = Date.now();
    const assets = [
      {
        id: `asset_${now}_gold`,
        symbol: "GC=F",
        name: "Gold Futures",
        type: "commodity",
        exchange: "COMEX",
        description: "Gold futures contract",
      },
      {
        id: `asset_${now}_silver`,
        symbol: "SI=F",
        name: "Silver Futures",
        type: "commodity",
        exchange: "COMEX",
        description: "Silver futures contract",
      },
      {
        id: `asset_${now}_btc`,
        symbol: "BTC-USD",
        name: "Bitcoin",
        type: "crypto",
        exchange: "Crypto",
        description: "Bitcoin cryptocurrency",
      },
    ];

    for (const asset of assets) {
      await pool.query(
        `
        INSERT INTO assets (id, symbol, name, type, exchange, description, is_active, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        ON CONFLICT (symbol) DO NOTHING
      `,
        [
          asset.id,
          asset.symbol,
          asset.name,
          asset.type,
          asset.exchange,
          asset.description,
          true,
          now,
          now,
        ]
      );
    }
    console.log("✅ Default assets inserted");

    console.log("\n✅ All tables created successfully!");
  } catch (error) {
    console.error("❌ Error creating tables:", error);
    throw error;
  } finally {
    await pool.end();
  }
}

createAssetsTables();

