-- Simplified SQLite Schema for Asset Predictor
-- Core tables only for demonstration

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT,
  email TEXT,
  loginMethod TEXT,
  role TEXT DEFAULT 'user' NOT NULL,
  createdAt INTEGER DEFAULT (unixepoch()),
  lastSignedIn INTEGER DEFAULT (unixepoch())
);

-- Assets table
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  assetType TEXT NOT NULL,
  exchange TEXT,
  currency TEXT DEFAULT 'USD',
  currentPrice TEXT,
  sector TEXT,
  description TEXT,
  updatedAt INTEGER DEFAULT (unixepoch())
);

-- Historical Prices table
CREATE TABLE IF NOT EXISTS historical_prices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  assetId INTEGER NOT NULL,
  date INTEGER NOT NULL,
  price TEXT NOT NULL,
  high TEXT,
  low TEXT,
  open TEXT,
  volume TEXT,
  change TEXT DEFAULT '0.00',
  changePercent TEXT DEFAULT '0.00',
  timestamp INTEGER NOT NULL,
  FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
);

-- Predictions table
CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  assetId INTEGER NOT NULL,
  userId TEXT NOT NULL,
  modelType TEXT NOT NULL,
  horizon TEXT NOT NULL,
  predictedPrice TEXT NOT NULL,
  confidenceLevel TEXT NOT NULL,
  predictionDate INTEGER NOT NULL,
  accuracy TEXT,
  metadata TEXT,
  createdAt INTEGER DEFAULT (unixepoch()),
  FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- Alerts table
CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId TEXT NOT NULL,
  assetId INTEGER NOT NULL,
  alertType TEXT NOT NULL,
  condition TEXT NOT NULL,
  threshold TEXT NOT NULL,
  isActive INTEGER DEFAULT 1,
  isTriggered INTEGER DEFAULT 0,
  createdAt INTEGER DEFAULT (unixepoch()),
  FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_historical_prices_assetId ON historical_prices(assetId);
CREATE INDEX IF NOT EXISTS idx_historical_prices_date ON historical_prices(date);
CREATE INDEX IF NOT EXISTS idx_predictions_assetId ON predictions(assetId);
CREATE INDEX IF NOT EXISTS idx_predictions_userId ON predictions(userId);
CREATE INDEX IF NOT EXISTS idx_alerts_userId ON alerts(userId);
CREATE INDEX IF NOT EXISTS idx_alerts_assetId ON alerts(assetId);

