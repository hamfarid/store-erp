/**
 * Comprehensive API Test Script
 * Tests all backend API endpoints systematically
 */

const BASE_URL = 'http://localhost:2505';
const sessionCookie = '';
let csrfToken = '';

interface TestResult {
  endpoint: string;
  method: string;
  status: 'PASS' | 'FAIL' | 'SKIP';
  statusCode?: number;
  message?: string;
}

const results: TestResult[] = [];

async function makeRequest(
  endpoint: string,
  method: string = 'GET',
  body?: any,
  expectError: boolean = false
): Promise<{ ok: boolean; status: number; data: any }> {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };
  
  if (sessionCookie) {
    headers['Cookie'] = sessionCookie;
  }
  if (csrfToken) {
    headers['X-CSRF-Token'] = csrfToken;
  }

  try {
    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    const data = await response.json().catch(() => ({}));
    
    return {
      ok: response.ok,
      status: response.status,
      data,
    };
  } catch (error: any) {
    return {
      ok: false,
      status: 0,
      data: { error: error.message },
    };
  }
}

async function trpcQuery(procedure: string, input?: any): Promise<any> {
  const inputParam = input ? `&input=${encodeURIComponent(JSON.stringify({ "0": { json: input } }))}` : '';
  const response = await makeRequest(`/api/trpc/${procedure}?batch=1${inputParam}`);
  return response;
}

async function trpcMutation(procedure: string, input: any): Promise<any> {
  const body = { "0": { json: input } };
  const response = await makeRequest(`/api/trpc/${procedure}?batch=1`, 'POST', body);
  return response;
}

function logResult(result: TestResult) {
  const icon = result.status === 'PASS' ? '✅' : result.status === 'FAIL' ? '❌' : '⏭️';
  console.log(`${icon} [${result.method}] ${result.endpoint}: ${result.status} ${result.message || ''}`);
  results.push(result);
}

// ========== AUTH TESTS ==========
async function testAuth() {
  console.log('\n📋 Testing Auth Module...\n');

  // Test login
  const loginResult = await trpcMutation('auth.login', {
    email: 'admin@goldpredictor.com',
    password: 'Admin@123456'
  });

  if (loginResult.ok && loginResult.data?.[0]?.result?.data?.json?.success) {
    const userData = loginResult.data[0].result.data.json;
    csrfToken = userData.csrfToken || '';
    logResult({
      endpoint: 'auth.login',
      method: 'POST',
      status: 'PASS',
      statusCode: loginResult.status,
      message: `Logged in as ${userData.user.email}`
    });
  } else {
    logResult({
      endpoint: 'auth.login',
      method: 'POST',
      status: 'FAIL',
      statusCode: loginResult.status,
      message: JSON.stringify(loginResult.data?.[0]?.error || 'Unknown error')
    });
    return; // Can't continue without auth
  }

  // Test me endpoint
  const meResult = await trpcQuery('auth.me');
  logResult({
    endpoint: 'auth.me',
    method: 'GET',
    status: meResult.ok ? 'PASS' : 'FAIL',
    statusCode: meResult.status,
    message: meResult.ok ? 'User info retrieved' : 'Failed to get user info'
  });
}

// ========== ASSETS TESTS ==========
async function testAssets() {
  console.log('\n📋 Testing Assets Module...\n');

  // Test list assets
  const listResult = await trpcQuery('assets.list');
  logResult({
    endpoint: 'assets.list',
    method: 'GET',
    status: listResult.ok ? 'PASS' : 'FAIL',
    statusCode: listResult.status,
    message: listResult.ok ? `Found ${listResult.data?.[0]?.result?.data?.json?.length || 0} assets` : 'Failed'
  });

  // Test create asset
  const createResult = await trpcMutation('assets.create', {
    name: 'Test Asset',
    symbol: 'TEST' + Date.now(),
    type: 'stock'
  });
  logResult({
    endpoint: 'assets.create',
    method: 'POST',
    status: createResult.ok ? 'PASS' : 'FAIL',
    statusCode: createResult.status,
    message: createResult.ok ? 'Asset created' : 'Failed to create'
  });
}

// ========== ALERTS TESTS ==========
async function testAlerts() {
  console.log('\n📋 Testing Alerts Module...\n');

  // Test list alerts
  const listResult = await trpcQuery('alerts.list');
  logResult({
    endpoint: 'alerts.list',
    method: 'GET',
    status: listResult.ok ? 'PASS' : 'FAIL',
    statusCode: listResult.status,
    message: listResult.ok ? 'Alerts listed' : 'Failed'
  });
}

// ========== NOTIFICATIONS TESTS ==========
async function testNotifications() {
  console.log('\n📋 Testing Notifications Module...\n');

  // Test get notifications
  const listResult = await trpcQuery('notifications.getUserNotifications');
  logResult({
    endpoint: 'notifications.getUserNotifications',
    method: 'GET',
    status: listResult.ok ? 'PASS' : 'FAIL',
    statusCode: listResult.status,
    message: listResult.ok ? 'Notifications retrieved' : 'Failed'
  });

  // Test unread count
  const countResult = await trpcQuery('notifications.getUnreadCount');
  logResult({
    endpoint: 'notifications.getUnreadCount',
    method: 'GET',
    status: countResult.ok ? 'PASS' : 'FAIL',
    statusCode: countResult.status,
    message: countResult.ok ? `Unread: ${countResult.data?.[0]?.result?.data?.json?.count || 0}` : 'Failed'
  });
}

// ========== ADMIN TESTS ==========
async function testAdmin() {
  console.log('\n📋 Testing Admin Module...\n');

  // Test system stats
  const statsResult = await trpcQuery('admin.stats');
  logResult({
    endpoint: 'admin.stats',
    method: 'GET',
    status: statsResult.ok ? 'PASS' : 'FAIL',
    statusCode: statsResult.status,
    message: statsResult.ok ? 'System stats retrieved' : 'Failed'
  });

  // Test users list
  const usersResult = await trpcQuery('admin.users.list');
  logResult({
    endpoint: 'admin.users.list',
    method: 'GET',
    status: usersResult.ok ? 'PASS' : 'FAIL',
    statusCode: usersResult.status,
    message: usersResult.ok ? 'Users listed' : 'Failed'
  });
}

// ========== SECURITY TESTS ==========
async function testSecurity() {
  console.log('\n📋 Testing Security Module...\n');

  // Test get security events
  const eventsResult = await trpcQuery('security.getEvents');
  logResult({
    endpoint: 'security.getEvents',
    method: 'GET',
    status: eventsResult.ok ? 'PASS' : 'FAIL',
    statusCode: eventsResult.status,
    message: eventsResult.ok ? 'Security events retrieved' : 'Failed'
  });

  // Test get summary
  const summaryResult = await trpcQuery('security.getSummary');
  logResult({
    endpoint: 'security.getSummary',
    method: 'GET',
    status: summaryResult.ok ? 'PASS' : 'FAIL',
    statusCode: summaryResult.status,
    message: summaryResult.ok ? 'Security summary retrieved' : 'Failed'
  });
}

// ========== FEAR & GREED TESTS ==========
async function testFearGreed() {
  console.log('\n📋 Testing Fear & Greed Module...\n');

  // Test get current
  const currentResult = await trpcQuery('fearGreed.getCurrent');
  logResult({
    endpoint: 'fearGreed.getCurrent',
    method: 'GET',
    status: currentResult.ok ? 'PASS' : 'FAIL',
    statusCode: currentResult.status,
    message: currentResult.ok ? 'Fear & Greed data retrieved' : 'Failed'
  });
}

// ========== NEWS SENTIMENT TESTS ==========
async function testNewsSentiment() {
  console.log('\n📋 Testing News Sentiment Module...\n');

  // Test get market summary
  const summaryResult = await trpcQuery('newsSentiment.getMarketSummary');
  logResult({
    endpoint: 'newsSentiment.getMarketSummary',
    method: 'GET',
    status: summaryResult.ok ? 'PASS' : 'FAIL',
    statusCode: summaryResult.status,
    message: summaryResult.ok ? 'Market summary retrieved' : 'Failed'
  });
}

// ========== TECHNICAL INDICATORS TESTS ==========
async function testTechnicalIndicators() {
  console.log('\n📋 Testing Technical Indicators Module...\n');

  // Test calculate
  const calcResult = await trpcMutation('technicalIndicators.calculate', {
    assetId: 1,
    period: 14
  });
  logResult({
    endpoint: 'technicalIndicators.calculate',
    method: 'POST',
    status: calcResult.ok || calcResult.status === 500 ? 'PASS' : 'FAIL', // May fail if no data
    statusCode: calcResult.status,
    message: calcResult.ok ? 'Indicators calculated' : 'No data available (expected)'
  });
}

// ========== PREDICTIONS TESTS ==========
async function testPredictions() {
  console.log('\n📋 Testing Predictions Module...\n');

  // Test list
  const listResult = await trpcQuery('predictions.list');
  logResult({
    endpoint: 'predictions.list',
    method: 'GET',
    status: listResult.ok ? 'PASS' : 'FAIL',
    statusCode: listResult.status,
    message: listResult.ok ? 'Predictions listed' : 'Failed'
  });
}

// ========== PORTFOLIO TESTS ==========
async function testPortfolio() {
  console.log('\n📋 Testing Portfolio Module...\n');

  // Test list portfolios
  const listResult = await trpcQuery('portfolio.list');
  logResult({
    endpoint: 'portfolio.list',
    method: 'GET',
    status: listResult.ok ? 'PASS' : 'FAIL',
    statusCode: listResult.status,
    message: listResult.ok ? 'Portfolios listed' : 'Failed'
  });
}

// ========== REPORTS TESTS ==========
async function testReports() {
  console.log('\n📋 Testing Reports Module...\n');

  // Test history
  const historyResult = await trpcQuery('reports.history');
  logResult({
    endpoint: 'reports.history',
    method: 'GET',
    status: historyResult.ok ? 'PASS' : 'FAIL',
    statusCode: historyResult.status,
    message: historyResult.ok ? 'Report history retrieved' : 'Failed'
  });
}

// ========== SETTINGS TESTS ==========
async function testSettings() {
  console.log('\n📋 Testing Settings Module...\n');

  // Test get settings
  const getResult = await trpcQuery('settings.get');
  logResult({
    endpoint: 'settings.get',
    method: 'GET',
    status: getResult.ok ? 'PASS' : 'FAIL',
    statusCode: getResult.status,
    message: getResult.ok ? 'Settings retrieved' : 'Failed'
  });
}

// ========== MAIN ==========
async function runTests() {
  console.log('🚀 Starting Comprehensive API Tests\n');
  console.log('='.repeat(50));

  await testAuth();
  await testAssets();
  await testAlerts();
  await testNotifications();
  await testAdmin();
  await testSecurity();
  await testFearGreed();
  await testNewsSentiment();
  await testTechnicalIndicators();
  await testPredictions();
  await testPortfolio();
  await testReports();
  await testSettings();

  // Summary
  console.log('\n' + '='.repeat(50));
  console.log('📊 TEST SUMMARY\n');

  const passed = results.filter(r => r.status === 'PASS').length;
  const failed = results.filter(r => r.status === 'FAIL').length;
  const skipped = results.filter(r => r.status === 'SKIP').length;

  console.log(`✅ Passed:  ${passed}`);
  console.log(`❌ Failed:  ${failed}`);
  console.log(`⏭️  Skipped: ${skipped}`);
  console.log(`📝 Total:   ${results.length}`);

  const successRate = Math.round((passed / results.length) * 100);
  console.log(`\n📈 Success Rate: ${successRate}%`);

  if (failed > 0) {
    console.log('\n❌ Failed Tests:');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`   - ${r.endpoint}: ${r.message}`);
    });
  }

  console.log('\n' + '='.repeat(50));
}

runTests().catch(console.error);

