# Script to check and validate .env file
# فحص والتحقق من ملف .env

Write-Host "🔍 فحص ملف .env..." -ForegroundColor Cyan

$envFile = ".env"
$requiredVars = @(
    "JWT_SECRET",
    "DATABASE_URL"
)

$recommendedVars = @(
    "SMTP_HOST",
    "SMTP_USER",
    "SMTP_PASS",
    "FRONTEND_URL",
    "PORT"
)

if (-not (Test-Path $envFile)) {
    Write-Host "❌ ملف .env غير موجود!" -ForegroundColor Red
    Write-Host "📝 قم بنسخ env.example إلى .env:" -ForegroundColor Yellow
    Write-Host "   Copy-Item env.example .env" -ForegroundColor White
    exit 1
}

Write-Host "✅ ملف .env موجود" -ForegroundColor Green
Write-Host ""

# Load .env file
$envVars = @{}
Get-Content $envFile | ForEach-Object {
    if ($_ -match "^([A-Z_]+)=(.*)$") {
        $envVars[$matches[1]] = $matches[2]
    }
}

# Check required variables
Write-Host "📋 فحص المتغيرات المطلوبة:" -ForegroundColor Cyan
$missingRequired = @()
foreach ($var in $requiredVars) {
    if ($envVars.ContainsKey($var) -and $envVars[$var] -ne "" -and $envVars[$var] -notmatch "your-|change-me") {
        Write-Host "  ✅ $var" -ForegroundColor Green
    } else {
        Write-Host "  ❌ $var (مفقود أو غير مُعد)" -ForegroundColor Red
        $missingRequired += $var
    }
}

Write-Host ""
Write-Host "📋 فحص المتغيرات الموصى بها:" -ForegroundColor Cyan
$missingRecommended = @()
foreach ($var in $recommendedVars) {
    if ($envVars.ContainsKey($var) -and $envVars[$var] -ne "" -and $envVars[$var] -notmatch "your-|change-me") {
        Write-Host "  ✅ $var" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️  $var (غير مُعد)" -ForegroundColor Yellow
        $missingRecommended += $var
    }
}

Write-Host ""

# Check JWT_SECRET length
if ($envVars.ContainsKey("JWT_SECRET")) {
    $jwtSecret = $envVars["JWT_SECRET"]
    if ($jwtSecret.Length -lt 32) {
        Write-Host "⚠️  JWT_SECRET قصير جداً (يجب أن يكون 32 حرف على الأقل)" -ForegroundColor Yellow
        Write-Host "   الطول الحالي: $($jwtSecret.Length)" -ForegroundColor Yellow
    } else {
        Write-Host "✅ JWT_SECRET طوله مناسب ($($jwtSecret.Length) حرف)" -ForegroundColor Green
    }
}

Write-Host ""

# Summary
if ($missingRequired.Count -eq 0 -and $missingRecommended.Count -eq 0) {
    Write-Host "✅ جميع الإعدادات موجودة!" -ForegroundColor Green
    exit 0
} else {
    if ($missingRequired.Count -gt 0) {
        Write-Host "❌ متغيرات مطلوبة مفقودة:" -ForegroundColor Red
        $missingRequired | ForEach-Object { Write-Host "   - $_" -ForegroundColor Red }
    }
    if ($missingRecommended.Count -gt 0) {
        Write-Host "⚠️  متغيرات موصى بها مفقودة:" -ForegroundColor Yellow
        $missingRecommended | ForEach-Object { Write-Host "   - $_" -ForegroundColor Yellow }
    }
    Write-Host ""
    Write-Host "📝 راجع ملف env.example للحصول على جميع الإعدادات" -ForegroundColor Cyan
    exit 1
}

