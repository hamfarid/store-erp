/**
 * FILE: scripts/check-users.ts
 * PURPOSE: Check existing users in database
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { resolve } from "path";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🔐 Checking Users in Database");
console.log("=".repeat(50));

const sqlite = new Database(dbPath);

// Get all users
const users = sqlite.prepare("SELECT id, email, role, createdAt FROM users").all();

console.log(`\n📊 Total Users: ${users.length}\n`);

if (users.length === 0) {
  console.log("⚠️  No users found in database!");
  console.log("\n💡 You need to create a user first.");
  console.log("   Run: npx tsx scripts/create-admin-user.ts");
} else {
  console.log("Users:");
  users.forEach((user: any) => {
    const date = new Date(user.createdAt).toLocaleString();
    console.log(`  - Email: ${user.email}`);
    console.log(`    Role: ${user.role}`);
    console.log(`    Created: ${date}`);
    console.log("");
  });
}

sqlite.close();
console.log("=".repeat(50));

