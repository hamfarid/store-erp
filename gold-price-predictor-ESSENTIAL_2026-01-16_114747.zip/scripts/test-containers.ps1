# Test Containers Script
Write-Host "`n══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🧪 اختبار الحاويات" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# 1. Container Status
Write-Host "1️⃣  حالة الحاويات:" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker-compose -f docker-compose.production.yml ps
Write-Host ""

# 2. Database Tests
Write-Host "2️⃣  اختبار قواعد البيانات:" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host ""

Write-Host "PostgreSQL..." -ForegroundColor Cyan -NoNewline
$pgTest = docker exec gold-predictor-db pg_isready -U postgres 2>&1
if ($pgTest -match "accepting") {
    Write-Host " ✅ جاهز" -ForegroundColor Green
} else {
    Write-Host " ❌ غير جاهز" -ForegroundColor Red
    Write-Host "   $pgTest" -ForegroundColor Gray
}

Write-Host "Redis..." -ForegroundColor Cyan -NoNewline
$redisTest = docker exec gold-predictor-redis redis-cli ping 2>&1
if ($redisTest -match "PONG") {
    Write-Host " ✅ جاهز" -ForegroundColor Green
} else {
    Write-Host " ❌ غير جاهز" -ForegroundColor Red
    Write-Host "   $redisTest" -ForegroundColor Gray
}
Write-Host ""

# 3. HTTP Endpoints
Write-Host "3️⃣  اختبار HTTP Endpoints:" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host ""

# Frontend
Write-Host "Frontend (http://localhost:2505)..." -ForegroundColor Cyan -NoNewline
try {
    $frontend = Invoke-WebRequest -Uri "http://localhost:2505" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    Write-Host " ✅ HTTP $($frontend.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host " ⚠️  غير متاح" -ForegroundColor Yellow
}

# Backend
Write-Host "Backend Health (http://localhost:2005/health)..." -ForegroundColor Cyan -NoNewline
try {
    $backend = Invoke-WebRequest -Uri "http://localhost:2005/health" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    Write-Host " ✅ HTTP $($backend.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host " ⚠️  غير متاح" -ForegroundColor Yellow
}

# ML Service
Write-Host "ML Service Health (http://localhost:2105/health)..." -ForegroundColor Cyan -NoNewline
try {
    $ml = Invoke-WebRequest -Uri "http://localhost:2105/health" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    Write-Host " ✅ HTTP $($ml.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host " ⚠️  غير متاح" -ForegroundColor Yellow
}

# Grafana
Write-Host "Grafana (http://localhost:3001)..." -ForegroundColor Cyan -NoNewline
try {
    $grafana = Invoke-WebRequest -Uri "http://localhost:3001" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    Write-Host " ✅ HTTP $($grafana.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host " ⚠️  غير متاح" -ForegroundColor Yellow
}
Write-Host ""

# 4. Container Logs Check
Write-Host "4️⃣  حالة الحاويات المتعثرة:" -ForegroundColor Yellow
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host ""

$backendStatus = docker inspect gold-predictor-backend --format='{{.State.Status}}' 2>&1
if ($backendStatus -eq "running") {
    Write-Host "✅ Backend: يعمل" -ForegroundColor Green
} else {
    Write-Host "⚠️  Backend: $backendStatus" -ForegroundColor Yellow
    Write-Host "   آخر 5 أسطر من السجلات:" -ForegroundColor Gray
    docker logs gold-predictor-backend --tail 5 2>&1 | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
}

Write-Host ""

$mlStatus = docker inspect gold-predictor-ml --format='{{.State.Status}}' 2>&1
if ($mlStatus -eq "running") {
    Write-Host "✅ ML Service: يعمل" -ForegroundColor Green
} else {
    Write-Host "⚠️  ML Service: $mlStatus" -ForegroundColor Yellow
    Write-Host "   آخر 5 أسطر من السجلات:" -ForegroundColor Gray
    docker logs gold-predictor-ml --tail 5 2>&1 | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
}

Write-Host ""

$promStatus = docker inspect gold-predictor-prometheus --format='{{.State.Status}}' 2>&1
if ($promStatus -eq "running") {
    Write-Host "✅ Prometheus: يعمل" -ForegroundColor Green
} else {
    Write-Host "⚠️  Prometheus: $promStatus" -ForegroundColor Yellow
    Write-Host "   آخر 5 أسطر من السجلات:" -ForegroundColor Gray
    docker logs gold-predictor-prometheus --tail 5 2>&1 | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
}

Write-Host ""

# 5. Summary
Write-Host "5️⃣  ملخص:" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "📋 روابط الخدمات:" -ForegroundColor Yellow
Write-Host "   Frontend:     http://localhost:2505" -ForegroundColor White
Write-Host "   Backend API:  http://localhost:2005" -ForegroundColor White
Write-Host "   ML Service:   http://localhost:2105" -ForegroundColor White
Write-Host "   Grafana:      http://localhost:3001" -ForegroundColor White
Write-Host "   Prometheus:   http://localhost:9090" -ForegroundColor White
Write-Host "   Portainer:    http://localhost:9000" -ForegroundColor White
Write-Host ""
Write-Host "📊 قواعد البيانات:" -ForegroundColor Yellow
Write-Host "   PostgreSQL:   localhost:5432" -ForegroundColor White
Write-Host "   Redis:        localhost:6382" -ForegroundColor White
Write-Host ""
Write-Host "🔧 أوامر مفيدة:" -ForegroundColor Yellow
Write-Host "   عرض السجلات:  docker-compose -f docker-compose.production.yml logs -f [service]" -ForegroundColor White
Write-Host "   إعادة تشغيل:  docker-compose -f docker-compose.production.yml restart [service]" -ForegroundColor White
Write-Host "   إيقاف:        docker-compose -f docker-compose.production.yml stop" -ForegroundColor White
Write-Host ""
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

