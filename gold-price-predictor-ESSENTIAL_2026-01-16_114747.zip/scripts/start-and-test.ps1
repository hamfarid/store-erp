# ============================================
# Start and Test All Services
# ============================================

Write-Host ""
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🚀 بدء تشغيل جميع المكونات واختبارها" -ForegroundColor Green
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check .env file
if (-not (Test-Path ".env")) {
    Write-Host "❌ ملف .env غير موجود!" -ForegroundColor Red
    Write-Host "   يرجى نسخ env.example إلى .env وتكوينه" -ForegroundColor Yellow
    exit 1
}
Write-Host "✅ ملف .env موجود" -ForegroundColor Green
Write-Host ""

# Step 2: Stop existing containers
Write-Host "1️⃣  إيقاف الحاويات القديمة..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml down 2>$null
Write-Host "   ✅ تم" -ForegroundColor Green
Write-Host ""

# Step 3: Start containers
Write-Host "2️⃣  تشغيل الحاويات..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml up -d
if ($LASTEXITCODE -ne 0) {
    Write-Host "   ❌ فشل تشغيل الحاويات!" -ForegroundColor Red
    exit 1
}
Write-Host "   ✅ تم تشغيل الحاويات" -ForegroundColor Green
Write-Host ""

# Step 4: Wait for services
Write-Host "3️⃣  انتظار تهيئة الخدمات (15 ثانية)..." -ForegroundColor Yellow
Start-Sleep -Seconds 15
Write-Host "   ✅ تم الانتظار" -ForegroundColor Green
Write-Host ""

# Step 5: Show container status
Write-Host "4️⃣  حالة الحاويات:" -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml ps
Write-Host ""

# Step 6: Test services
Write-Host "5️⃣  اختبار الخدمات:" -ForegroundColor Yellow
Write-Host ""

$testResults = @()

# Test PostgreSQL
Write-Host "   اختبار PostgreSQL..." -NoNewline
try {
    $pg = docker exec gold-predictor-db pg_isready -U postgres 2>&1
    if ($LASTEXITCODE -eq 0 -or $pg -match "accepting") {
        Write-Host " ✅" -ForegroundColor Green
        $testResults += "PostgreSQL: ✅ جاهز"
    } else {
        Write-Host " ⚠️" -ForegroundColor Yellow
        $testResults += "PostgreSQL: ⚠️ غير جاهز بعد"
    }
} catch {
    Write-Host " ❌" -ForegroundColor Red
    $testResults += "PostgreSQL: ❌ خطأ"
}

# Test Redis
Write-Host "   اختبار Redis..." -NoNewline
try {
    $redis = docker exec gold-predictor-redis redis-cli ping 2>&1
    if ($redis -match "PONG") {
        Write-Host " ✅" -ForegroundColor Green
        $testResults += "Redis: ✅ جاهز"
    } else {
        Write-Host " ⚠️" -ForegroundColor Yellow
        $testResults += "Redis: ⚠️ غير جاهز بعد"
    }
} catch {
    Write-Host " ❌" -ForegroundColor Red
    $testResults += "Redis: ❌ خطأ"
}

# Test Frontend
Write-Host "   اختبار Frontend..." -NoNewline
try {
    $frontend = Invoke-WebRequest -Uri "http://localhost:2505" -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
    if ($frontend.StatusCode -eq 200) {
        Write-Host " ✅ (HTTP $($frontend.StatusCode))" -ForegroundColor Green
        $testResults += "Frontend: ✅ يعمل"
    } else {
        Write-Host " ⚠️ (HTTP $($frontend.StatusCode))" -ForegroundColor Yellow
        $testResults += "Frontend: ⚠️ HTTP $($frontend.StatusCode)"
    }
} catch {
    Write-Host " ⚠️ (غير متاح بعد)" -ForegroundColor Yellow
    $testResults += "Frontend: ⚠️ غير متاح بعد"
}

# Test Backend
Write-Host "   اختبار Backend..." -NoNewline
try {
    $backend = Invoke-WebRequest -Uri "http://localhost:2005/health" -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
    if ($backend.StatusCode -eq 200) {
        Write-Host " ✅ (HTTP $($backend.StatusCode))" -ForegroundColor Green
        $testResults += "Backend: ✅ يعمل"
    } else {
        Write-Host " ⚠️ (HTTP $($backend.StatusCode))" -ForegroundColor Yellow
        $testResults += "Backend: ⚠️ HTTP $($backend.StatusCode)"
    }
} catch {
    Write-Host " ⚠️ (غير متاح بعد)" -ForegroundColor Yellow
    $testResults += "Backend: ⚠️ غير متاح بعد"
}

# Test ML Service
Write-Host "   اختبار ML Service..." -NoNewline
try {
    $ml = Invoke-WebRequest -Uri "http://localhost:2105/health" -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
    if ($ml.StatusCode -eq 200) {
        Write-Host " ✅ (HTTP $($ml.StatusCode))" -ForegroundColor Green
        $testResults += "ML Service: ✅ يعمل"
    } else {
        Write-Host " ⚠️ (HTTP $($ml.StatusCode))" -ForegroundColor Yellow
        $testResults += "ML Service: ⚠️ HTTP $($ml.StatusCode)"
    }
} catch {
    Write-Host " ⚠️ (غير متاح بعد)" -ForegroundColor Yellow
    $testResults += "ML Service: ⚠️ غير متاح بعد"
}

# Test Grafana
Write-Host "   اختبار Grafana..." -NoNewline
try {
    $grafana = Invoke-WebRequest -Uri "http://localhost:3001" -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
    if ($grafana.StatusCode -eq 200 -or $grafana.StatusCode -eq 302) {
        Write-Host " ✅ (HTTP $($grafana.StatusCode))" -ForegroundColor Green
        $testResults += "Grafana: ✅ يعمل"
    } else {
        Write-Host " ⚠️ (HTTP $($grafana.StatusCode))" -ForegroundColor Yellow
        $testResults += "Grafana: ⚠️ HTTP $($grafana.StatusCode)"
    }
} catch {
    Write-Host " ⚠️ (غير متاح بعد)" -ForegroundColor Yellow
    $testResults += "Grafana: ⚠️ غير متاح بعد"
}

Write-Host ""

# Step 7: Summary
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  📊 ملخص الاختبارات" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
foreach ($result in $testResults) {
    Write-Host "   $result" -ForegroundColor White
}
Write-Host ""

# Step 8: Service URLs
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  ✅ تم تشغيل جميع المكونات!" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "📋 روابط الخدمات:" -ForegroundColor Yellow
Write-Host "   Frontend:     http://localhost:2505" -ForegroundColor White
Write-Host "   Backend API:  http://localhost:2005" -ForegroundColor White
Write-Host "   ML Service:   http://localhost:2105" -ForegroundColor White
Write-Host "   Grafana:      http://localhost:3001" -ForegroundColor White
Write-Host "   Prometheus:   http://localhost:9090" -ForegroundColor White
Write-Host "   Portainer:    http://localhost:9000" -ForegroundColor White
Write-Host ""
Write-Host "📊 قواعد البيانات:" -ForegroundColor Yellow
Write-Host "   PostgreSQL:   localhost:5432" -ForegroundColor White
Write-Host "   Redis:        localhost:6379" -ForegroundColor White
Write-Host ""
Write-Host "🔧 أوامر مفيدة:" -ForegroundColor Yellow
Write-Host "   عرض السجلات:  npm run logs:prod" -ForegroundColor White
Write-Host "   إيقاف:        npm run stop:prod" -ForegroundColor White
Write-Host "   إعادة تشغيل:  npm run restart:prod" -ForegroundColor White
Write-Host ""
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""

