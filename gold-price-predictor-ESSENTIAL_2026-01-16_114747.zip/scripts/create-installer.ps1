# Asset Predictor UI - Create Windows Installer Package
# This script creates a standalone installer using Inno Setup

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Creating Windows Installer Package" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Inno Setup is installed
$innoSetupPath = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if (-not (Test-Path $innoSetupPath)) {
    Write-Host "❌ Inno Setup is not installed" -ForegroundColor Red
    Write-Host "Please download and install from: https://jrsoftware.org/isdl.php" -ForegroundColor Yellow
    exit 1
}

# Create Inno Setup script
$issContent = @"
; Asset Predictor UI - Inno Setup Script
#define MyAppName "Asset Predictor UI"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Manus AI"
#define MyAppURL "https://manus.im"
#define MyAppExeName "start-app.bat"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=LICENSE.txt
OutputDir=installer
OutputBaseFilename=AssetPredictorUI-Setup-{#MyAppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; NOTE: Don't use "Flags: ignoreversion" on any shared system files

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\setup-windows.ps1"; Parameters: "-ExecutionPolicy Bypass"; Flags: runhidden; Description: "Setup dependencies"
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[Code]
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  // Check if Node.js is installed
  if not RegKeyExists(HKLM, 'SOFTWARE\Node.js') and not RegKeyExists(HKCU, 'SOFTWARE\Node.js') then
  begin
    if MsgBox('Node.js is required but not installed. Would you like to download it now?', mbConfirmation, MB_YESNO) = IDYES then
    begin
      ShellExec('open', 'https://nodejs.org/', '', '', SW_SHOW, ewNoWait, ResultCode);
    end;
    Result := False;
    Exit;
  end;
  Result := True;
end;
"@

$issContent | Out-File -FilePath "installer-script.iss" -Encoding UTF8

# Create start script
$startScript = @"
@echo off
echo Starting Asset Predictor UI...
cd /d "%~dp0"
call pnpm dev
pause
"@

$startScript | Out-File -FilePath "start-app.bat" -Encoding ASCII

# Create LICENSE file if not exists
if (-not (Test-Path "LICENSE.txt")) {
    $license = @"
MIT License

Copyright (c) 2025 Manus AI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"@
    $license | Out-File -FilePath "LICENSE.txt" -Encoding UTF8
}

# Build the project first
Write-Host "Building project..." -ForegroundColor Yellow
pnpm build
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Build failed" -ForegroundColor Red
    exit 1
}

# Create installer directory
New-Item -ItemType Directory -Force -Path "installer" | Out-Null

# Run Inno Setup
Write-Host "Creating installer..." -ForegroundColor Yellow
& $innoSetupPath "installer-script.iss"

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✅ Installer created successfully!" -ForegroundColor Green
    Write-Host "Location: installer\AssetPredictorUI-Setup-1.0.0.exe" -ForegroundColor Yellow
} else {
    Write-Host "❌ Failed to create installer" -ForegroundColor Red
    exit 1
}

