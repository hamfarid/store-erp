import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import path from "path";

const dbPath = path.join(process.cwd(), "data", "asset_predictor.db");

console.log("🧪 Testing Direct Login");
console.log("=".repeat(50));

async function testLogin() {
  const sqlite = new Database(dbPath);

  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";

  console.log("\n1️⃣ Finding user by email...");
  const user = sqlite
    .prepare("SELECT * FROM users WHERE email = ?")
    .get(email) as any;

  if (!user) {
    console.log("❌ User not found!");
    return;
  }

  console.log("✅ User found:");
  console.log(`   ID: ${user.id}`);
  console.log(`   Email: ${user.email}`);
  console.log(`   Role: ${user.role}`);
  console.log(`   Name: ${user.name}`);
  console.log(`   Password Hash: ${user.passwordHash?.substring(0, 20)}...`);

  console.log("\n2️⃣ Verifying password...");
  const isValid = await bcrypt.compare(password, user.passwordHash);

  if (isValid) {
    console.log("✅ Password is VALID!");
    console.log("\n" + "=".repeat(50));
    console.log("🎉 LOGIN TEST PASSED!");
    console.log("=".repeat(50));
  } else {
    console.log("❌ Password is INVALID!");
    console.log("\n" + "=".repeat(50));
    console.log("❌ LOGIN TEST FAILED!");
    console.log("=".repeat(50));
  }

  sqlite.close();
}

testLogin().catch(console.error);

