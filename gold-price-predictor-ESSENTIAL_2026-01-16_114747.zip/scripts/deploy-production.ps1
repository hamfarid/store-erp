# FILE: scripts/deploy-production.ps1 | PURPOSE: Production deployment automation | OWNER: DevOps Team | RELATED: docker-compose.production.yml | LAST-AUDITED: 2025-11-27

<#
.SYNOPSIS
    Deploy Gold Price Predictor to production

.DESCRIPTION
    Automated deployment script for production environment
    - Validates configuration
    - Generates SSL certificates
    - Builds Docker images
    - Starts services
    - Runs health checks

.PARAMETER Environment
    Environment to deploy to (production, staging)

.PARAMETER SkipSSL
    Skip SSL certificate generation

.PARAMETER SkipBuild
    Skip Docker image build (use existing images)

.EXAMPLE
    .\scripts\deploy-production.ps1
    .\scripts\deploy-production.ps1 -SkipSSL
    .\scripts\deploy-production.ps1 -Environment staging

.NOTES
    Requires Docker and Docker Compose installed
#>

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("production", "staging")]
    [string]$Environment = "production",

    [Parameter(Mandatory=$false)]
    [switch]$SkipSSL,

    [Parameter(Mandatory=$false)]
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Gold Price Predictor - Production Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Change to project root
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

# Configuration
$composeFile = "docker-compose.production.yml"
$envFile = ".env.production"

# Step 1: Pre-deployment checks
Write-Host "[1/7] Running pre-deployment checks..." -ForegroundColor Yellow

# Check Docker
try {
    $dockerVersion = docker --version
    Write-Host "  ✓ Docker installed: $dockerVersion" -ForegroundColor Green
} catch {
    Write-Host "  ✗ Docker not found! Please install Docker Desktop." -ForegroundColor Red
    exit 1
}

# Check Docker Compose
try {
    $composeVersion = docker compose version
    Write-Host "  ✓ Docker Compose installed: $composeVersion" -ForegroundColor Green
} catch {
    Write-Host "  ✗ Docker Compose not found!" -ForegroundColor Red
    exit 1
}

# Check compose file exists
if (-not (Test-Path $composeFile)) {
    Write-Host "  ✗ Compose file not found: $composeFile" -ForegroundColor Red
    exit 1
}
Write-Host "  ✓ Compose file found: $composeFile" -ForegroundColor Green

# Check .env file
if (-not (Test-Path ".env")) {
    if (Test-Path $envFile) {
        Write-Host "  ⚠ .env not found, copying from $envFile" -ForegroundColor Yellow
        Copy-Item $envFile ".env"
    } else {
        Write-Host "  ✗ .env file not found! Please create it from .env.production" -ForegroundColor Red
        exit 1
    }
}
Write-Host "  ✓ Environment file found: .env" -ForegroundColor Green

# Validate critical environment variables
$envContent = Get-Content ".env" -Raw
$criticalVars = @("POSTGRES_PASSWORD", "REDIS_PASSWORD", "JWT_SECRET_KEY", "SECRET_KEY")
$missingVars = @()

foreach ($var in $criticalVars) {
    if ($envContent -match "$var=CHANGE_THIS" -or $envContent -notmatch "$var=.+") {
        $missingVars += $var
    }
}

if ($missingVars.Count -gt 0) {
    Write-Host "  ✗ Missing or invalid environment variables:" -ForegroundColor Red
    $missingVars | ForEach-Object { Write-Host "    - $_" -ForegroundColor Red }
    Write-Host ""
    Write-Host "Please update .env file with actual values." -ForegroundColor Yellow
    exit 1
}
Write-Host "  ✓ Critical environment variables configured" -ForegroundColor Green

Write-Host ""

# Step 2: SSL Certificate
if (-not $SkipSSL) {
    Write-Host "[2/7] Checking SSL certificate..." -ForegroundColor Yellow

    $certFile = "nginx\ssl\cert.pem"
    $keyFile = "nginx\ssl\key.pem"

    if ((Test-Path $certFile) -and (Test-Path $keyFile)) {
        Write-Host "  ✓ SSL certificate exists" -ForegroundColor Green

        # Check expiration
        $certInfo = & openssl x509 -in $certFile -noout -enddate 2>&1
        Write-Host "  ℹ Certificate expiration: $certInfo" -ForegroundColor Cyan
    } else {
        Write-Host "  ⚠ SSL certificate not found, generating self-signed certificate..." -ForegroundColor Yellow
        & "$scriptDir\generate-ssl-cert.ps1"

        if ($LASTEXITCODE -ne 0) {
            Write-Host "  ✗ Failed to generate SSL certificate!" -ForegroundColor Red
            exit 1
        }
    }
} else {
    Write-Host "[2/7] Skipping SSL certificate check (--SkipSSL)" -ForegroundColor Gray
}

Write-Host ""

# Step 3: Build Docker images
if (-not $SkipBuild) {
    Write-Host "[3/7] Building Docker images..." -ForegroundColor Yellow

    try {
        docker compose -f $composeFile build --no-cache
        Write-Host "  ✓ Docker images built successfully" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ Failed to build Docker images!" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "[3/7] Skipping Docker build (--SkipBuild)" -ForegroundColor Gray
}

Write-Host ""

# Step 4: Stop existing services
Write-Host "[4/7] Stopping existing services..." -ForegroundColor Yellow

$existingContainers = docker ps -a --filter "name=gold-predictor" --format "{{.Names}}"
if ($existingContainers) {
    Write-Host "  ⚠ Found existing containers:" -ForegroundColor Yellow
    $existingContainers | ForEach-Object { Write-Host "    - $_" -ForegroundColor Gray }

    $response = Read-Host "  Stop and remove existing containers? (y/n)"
    if ($response -eq 'y') {
        docker compose -f $composeFile down
        Write-Host "  ✓ Existing containers stopped" -ForegroundColor Green
    } else {
        Write-Host "  ✗ Deployment cancelled by user" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "  ✓ No existing containers found" -ForegroundColor Green
}

Write-Host ""

# Step 5: Start services
Write-Host "[5/7] Starting services..." -ForegroundColor Yellow

try {
    docker compose -f $composeFile up -d
    Write-Host "  ✓ Services started successfully" -ForegroundColor Green
} catch {
    Write-Host "  ✗ Failed to start services!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

Write-Host ""

# Step 6: Health checks
Write-Host "[6/7] Running health checks..." -ForegroundColor Yellow
Write-Host "  Waiting for services to be ready (30 seconds)..." -ForegroundColor Gray
Start-Sleep -Seconds 30

$healthChecks = @(
    @{Name="Nginx"; URL="http://localhost:82/health"},
    @{Name="Backend"; URL="http://localhost:2005/health"},
    @{Name="Frontend"; URL="http://localhost:2505"}
)

$allHealthy = $true
foreach ($check in $healthChecks) {
    try {
        $response = Invoke-WebRequest -Uri $check.URL -UseBasicParsing -TimeoutSec 5
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✓ $($check.Name) is healthy" -ForegroundColor Green
        } else {
            Write-Host "  ✗ $($check.Name) returned status $($response.StatusCode)" -ForegroundColor Red
            $allHealthy = $false
        }
    } catch {
        Write-Host "  ✗ $($check.Name) is not responding" -ForegroundColor Red
        $allHealthy = $false
    }
}

if (-not $allHealthy) {
    Write-Host ""
    Write-Host "  ⚠ Some services are not healthy. Check logs:" -ForegroundColor Yellow
    Write-Host "  docker compose -f $composeFile logs" -ForegroundColor Gray
}

Write-Host ""

# Step 7: Summary
Write-Host "[7/7] Deployment Summary" -ForegroundColor Yellow
Write-Host ""

$services = docker compose -f $composeFile ps --format json | ConvertFrom-Json
$services | ForEach-Object {
    $status = if ($_.State -eq "running") { "✓" } else { "✗" }
    $color = if ($_.State -eq "running") { "Green" } else { "Red" }
    Write-Host "  $status $($_.Service): $($_.State)" -ForegroundColor $color
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Deployment Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Access URLs:" -ForegroundColor Cyan
Write-Host "  Frontend (HTTP):  http://localhost:82" -ForegroundColor Yellow
Write-Host "  Frontend (HTTPS): https://localhost:442" -ForegroundColor Yellow
Write-Host "  Backend API:      http://localhost:2005/api" -ForegroundColor Yellow
Write-Host "  API Docs:         https://localhost:442/docs" -ForegroundColor Yellow
Write-Host "  Grafana:          http://localhost:3001" -ForegroundColor Yellow
Write-Host "  Prometheus:       http://localhost:9090" -ForegroundColor Yellow
Write-Host ""
Write-Host "Useful commands:" -ForegroundColor Cyan
Write-Host "  View logs:        docker compose -f $composeFile logs -f" -ForegroundColor Gray
Write-Host "  Stop services:    docker compose -f $composeFile down" -ForegroundColor Gray
Write-Host "  Restart service:  docker compose -f $composeFile restart <service>" -ForegroundColor Gray
Write-Host ""
