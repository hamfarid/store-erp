# PowerShell script to apply autoflake8 and autopep8 to all Python files

Write-Host "🔧 Applying autoflake8 and autopep8 to Python files..." -ForegroundColor Cyan

# Get all Python files excluding venv, node_modules, __pycache__
$pythonFiles = Get-ChildItem -Path . -Filter "*.py" -Recurse | 
    Where-Object { 
        $_.FullName -notmatch "venv" -and 
        $_.FullName -notmatch "node_modules" -and 
        $_.FullName -notmatch "__pycache__" -and
        $_.FullName -notmatch "\.venv"
    }

Write-Host "Found $($pythonFiles.Count) Python files to process" -ForegroundColor Yellow

$processed = 0
$errors = 0

foreach ($file in $pythonFiles) {
    try {
        Write-Host "Processing: $($file.Name)" -ForegroundColor Gray
        
        # Apply autoflake8 (remove unused imports and variables)
        python -m autoflake --in-place --remove-all-unused-imports --remove-unused-variables $file.FullName 2>&1 | Out-Null
        
        # Apply autopep8 (format code)
        python -m autopep8 --in-place --aggressive --aggressive $file.FullName 2>&1 | Out-Null
        
        $processed++
    } catch {
        Write-Host "Error processing $($file.Name): $_" -ForegroundColor Red
        $errors++
    }
}

Write-Host "`n✅ Processed: $processed files" -ForegroundColor Green
Write-Host "❌ Errors: $errors files" -ForegroundColor $(if ($errors -gt 0) { "Red" } else { "Green" })

