/**
 * FILE: scripts/create-admin-user.ts
 * PURPOSE: Create admin user for production
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import { resolve } from "path";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🔐 Creating Admin User");
console.log("=".repeat(50));

async function createAdminUser() {
  const sqlite = new Database(dbPath);

  // Admin credentials
  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";
  const role = "admin";

  // Check if user already exists
  const existingUser = sqlite
    .prepare("SELECT id, email FROM users WHERE email = ?")
    .get(email);

  if (existingUser) {
    console.log(`\n⚠️  User already exists: ${email}`);
    console.log(`   User ID: ${(existingUser as any).id}`);
    console.log("\n💡 Use this email to login.");
    sqlite.close();
    return;
  }

  // Hash password
  console.log("\n🔒 Hashing password...");
  const hashedPassword = await bcrypt.hash(password, 10);

  // Generate user ID
  const userId = `user_${Date.now()}_${Math.random().toString(36).substring(7)}`;

  // Insert user
  console.log("👤 Creating admin user...");
  const result = sqlite
    .prepare(
      `INSERT INTO users (id, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(userId, email, hashedPassword, "local", role, Date.now(), Date.now());

  console.log("\n✅ Admin user created successfully!");
  console.log("\n" + "=".repeat(50));
  console.log("📋 Login Credentials:");
  console.log("=".repeat(50));
  console.log(`Email:    ${email}`);
  console.log(`Password: ${password}`);
  console.log(`Role:     ${role}`);
  console.log(`User ID:  ${userId}`);
  console.log("=".repeat(50));
  console.log("\n🌐 Login URL: http://localhost:2506/login");
  console.log("\n⚠️  IMPORTANT: Change password after first login!");

  sqlite.close();
}

createAdminUser().catch(error => {
  console.error("❌ Error creating admin user:", error);
  process.exit(1);
});
