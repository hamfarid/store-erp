/**
 * Test Self-Learning System
 * Verifies that ML models exist and can be loaded
 */

import fs from 'fs';
import path from 'path';

const MODELS_DIR = path.join(process.cwd(), 'models');
const DATA_DIR = path.join(process.cwd(), 'data');

interface ModelInfo {
  name: string;
  exists: boolean;
  lastModified: Date | null;
  size: number;
}

interface TrainingSummary {
  [key: string]: {
    asset: string;
    train_r2: number;
    test_r2: number;
    timestamp: string;
    model_type: string;
  };
}

async function testSelfLearning() {
  console.log('\n🔍 Testing Self-Learning System...\n');
  console.log('=' .repeat(60));

  // 1. Check models directory
  console.log('\n📁 1. Checking Models Directory...');
  
  const requiredModels = [
    'Gold_model_v5.pkl',
    'Bitcoin_model_v5.pkl',
    'Ethereum_model_v5.pkl',
    'TRY_USD_model_v5.pkl',
    'EGP_USD_model_v5.pkl'
  ];

  const modelResults: ModelInfo[] = [];

  for (const model of requiredModels) {
    const modelPath = path.join(MODELS_DIR, model);
    const exists = fs.existsSync(modelPath);
    let lastModified: Date | null = null;
    let size = 0;

    if (exists) {
      const stats = fs.statSync(modelPath);
      lastModified = stats.mtime;
      size = stats.size;
    }

    modelResults.push({ name: model, exists, lastModified, size });
  }

  console.log('\n| Model | Status | Last Modified | Size |');
  console.log('|-------|--------|---------------|------|');

  for (const result of modelResults) {
    const status = result.exists ? '✅' : '❌';
    const date = result.lastModified 
      ? result.lastModified.toLocaleDateString('en-GB') 
      : 'N/A';
    const size = result.exists ? `${(result.size / 1024).toFixed(1)}KB` : 'N/A';
    console.log(`| ${result.name} | ${status} | ${date} | ${size} |`);
  }

  // 2. Check training summary
  console.log('\n📊 2. Checking Training Summary...');
  
  const summaryPath = path.join(MODELS_DIR, 'training_summary_v5.json');
  if (fs.existsSync(summaryPath)) {
    const summary: TrainingSummary = JSON.parse(fs.readFileSync(summaryPath, 'utf-8'));
    
    console.log('\n| Asset | Train R² | Test R² | Model | Last Trained |');
    console.log('|-------|----------|---------|-------|--------------|');
    
    for (const [asset, info] of Object.entries(summary)) {
      const trainR2 = (info.train_r2 * 100).toFixed(2) + '%';
      const testR2 = (info.test_r2 * 100).toFixed(2) + '%';
      const date = new Date(info.timestamp).toLocaleDateString('en-GB');
      console.log(`| ${asset} | ${trainR2} | ${testR2} | ${info.model_type} | ${date} |`);
    }
  } else {
    console.log('❌ Training summary not found!');
  }

  // 3. Check data files
  console.log('\n📈 3. Checking Data Files...');
  
  const dataFiles = [
    'extended_dataset_v2.csv',
    'processed/merged_data.csv',
    'processed/btc_dataset.csv',
    'processed/eth_dataset.csv'
  ];

  console.log('\n| File | Status | Size |');
  console.log('|------|--------|------|');

  for (const file of dataFiles) {
    const filePath = path.join(DATA_DIR, file);
    const exists = fs.existsSync(filePath);
    let size = 'N/A';

    if (exists) {
      const stats = fs.statSync(filePath);
      size = `${(stats.size / 1024).toFixed(1)}KB`;
    }

    console.log(`| ${file} | ${exists ? '✅' : '❌'} | ${size} |`);
  }

  // 4. Check auto-updater module
  console.log('\n🔄 4. Checking Auto-Updater Module...');
  
  const autoUpdaterPath = path.join(process.cwd(), 'modules', 'auto_updater.py');
  const selfLearningPath = path.join(process.cwd(), 'self_learning_system.py');
  
  console.log(`| auto_updater.py | ${fs.existsSync(autoUpdaterPath) ? '✅' : '❌'} |`);
  console.log(`| self_learning_system.py | ${fs.existsSync(selfLearningPath) ? '✅' : '❌'} |`);

  // 5. Summary
  console.log('\n' + '=' .repeat(60));
  console.log('📋 SUMMARY');
  console.log('=' .repeat(60));
  
  const modelsExist = modelResults.every(m => m.exists);
  const oldestModel = modelResults
    .filter(m => m.lastModified)
    .sort((a, b) => (a.lastModified?.getTime() || 0) - (b.lastModified?.getTime() || 0))[0];

  console.log(`\n✅ All Required Models Exist: ${modelsExist ? 'YES' : 'NO'}`);
  
  if (oldestModel?.lastModified) {
    const daysSinceUpdate = Math.floor(
      (Date.now() - oldestModel.lastModified.getTime()) / (1000 * 60 * 60 * 24)
    );
    console.log(`📅 Last Model Update: ${oldestModel.lastModified.toLocaleDateString('en-GB')} (${daysSinceUpdate} days ago)`);
    
    if (daysSinceUpdate > 7) {
      console.log('⚠️  WARNING: Models are older than 7 days - consider retraining!');
    }
  }

  console.log('\n🔧 Auto-Update Schedule:');
  console.log('   - Daily Data Update: 02:00 AM');
  console.log('   - Weekly Model Retrain: Sunday 03:00 AM');
  
  console.log('\n' + '=' .repeat(60));
  console.log('✅ Self-Learning System Test Complete!\n');
}

testSelfLearning().catch(console.error);

