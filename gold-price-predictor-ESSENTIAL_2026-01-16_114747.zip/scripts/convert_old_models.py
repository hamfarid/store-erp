#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convert Old Models to Compatible Format
تحويل النماذج القديمة إلى صيغة متوافقة
"""

import os
import pickle
import json


def convert_model(old_path, new_path):
    """
    تحويل نموذج من protocol 4/5 إلى protocol 2
    """
    try:
        # محاولة تحميل بدون encoding
        with open(old_path, 'rb') as f:
            model = pickle.load(f, encoding='latin1')
        
        # حفظ بـ protocol 2
        with open(new_path, 'wb') as f:
            pickle.dump(model, f, protocol=2)
        
        return True
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False


def main():
    """التشغيل الرئيسي"""
    print("="*80)
    print("🔄 Converting Old Models to Compatible Format")
    print("="*80)
    
    # النماذج المراد تحويلها
    conversions = [
        # BTC
        {
            'old': 'models/by_asset/btc/best_model_gradient_boosting.pkl',
            'new': 'models/Bitcoin_model_v5.pkl',
            'scaler_old': 'models/by_asset/btc/scaler.pkl',
            'scaler_new': 'models/Bitcoin_scaler_v5.pkl',
            'features_old': 'models/by_asset/btc/feature_names.pkl',
            'features_new': 'models/Bitcoin_features_v5.pkl',
            'info': 'models/by_asset/btc/model_info.json'
        },
        # ETH
        {
            'old': 'models/by_asset/eth/best_model_gradient_boosting.pkl',
            'new': 'models/Ethereum_model_v5.pkl',
            'scaler_old': 'models/by_asset/eth/scaler.pkl',
            'scaler_new': 'models/Ethereum_scaler_v5.pkl',
            'features_old': 'models/by_asset/eth/feature_names.pkl',
            'features_new': 'models/Ethereum_features_v5.pkl',
            'info': 'models/by_asset/eth/model_info.json'
        },
        # TRY_USD
        {
            'old': 'models/by_asset/try_usd/best_model_gradient_boosting.pkl',
            'new': 'models/TRY_USD_model_v5.pkl',
            'scaler_old': 'models/by_asset/try_usd/scaler.pkl',
            'scaler_new': 'models/TRY_USD_scaler_v5.pkl',
            'features_old': 'models/by_asset/try_usd/feature_names.pkl',
            'features_new': 'models/TRY_USD_features_v5.pkl',
            'info': 'models/by_asset/try_usd/model_info.json'
        },
        # EGP_USD
        {
            'old': 'models/by_asset/egp_usd/best_model_random_forest.pkl',
            'new': 'models/EGP_USD_model_v5.pkl',
            'scaler_old': 'models/by_asset/egp_usd/scaler.pkl',
            'scaler_new': 'models/EGP_USD_scaler_v5.pkl',
            'features_old': 'models/by_asset/egp_usd/feature_names.pkl',
            'features_new': 'models/EGP_USD_features_v5.pkl',
            'info': 'models/by_asset/egp_usd/model_info.json'
        }
    ]
    
    results = {}
    
    for conv in conversions:
        asset_name = os.path.basename(conv['new']).replace('_model_v5.pkl', '')
        print(f"\n{'='*80}")
        print(f"🔄 Converting {asset_name}")
        print(f"{'='*80}")
        
        success = True
        
        # تحويل النموذج
        print(f"   📦 Converting model...")
        if os.path.exists(conv['old']):
            if convert_model(conv['old'], conv['new']):
                print(f"   ✅ Model converted: {conv['new']}")
            else:
                success = False
        else:
            print(f"   ❌ Model not found: {conv['old']}")
            success = False
        
        # تحويل scaler
        print(f"   📦 Converting scaler...")
        if os.path.exists(conv['scaler_old']):
            if convert_model(conv['scaler_old'], conv['scaler_new']):
                print(f"   ✅ Scaler converted: {conv['scaler_new']}")
            else:
                success = False
        else:
            print(f"   ❌ Scaler not found: {conv['scaler_old']}")
            success = False
        
        # تحويل features
        print(f"   📦 Converting features...")
        if os.path.exists(conv['features_old']):
            if convert_model(conv['features_old'], conv['features_new']):
                print(f"   ✅ Features converted: {conv['features_new']}")
            else:
                success = False
        else:
            print(f"   ❌ Features not found: {conv['features_old']}")
            success = False
        
        # نسخ معلومات النموذج
        if os.path.exists(conv['info']):
            with open(conv['info'], 'r') as f:
                info = json.load(f)
            
            info_new_path = conv['new'].replace('_model_v5.pkl', '_info_v5.json')
            with open(info_new_path, 'w') as f:
                json.dump(info, f, indent=2)
            
            print(f"   ✅ Info copied: {info_new_path}")
            
            results[asset_name] = {
                'success': success,
                'r2': info.get('r2', 0),
                'rmse': info.get('rmse', 0),
                'features': info.get('feature_count', 0)
            }
        else:
            results[asset_name] = {
                'success': success,
                'r2': 0,
                'rmse': 0,
                'features': 0
            }
    
    # الذهب - نحتاج لتدريبه من جديد
    print(f"\n{'='*80}")
    print(f"🔧 Gold model needs retraining")
    print(f"{'='*80}")
    
    print(f"\n{'='*80}")
    print("✅ Conversion completed!")
    print(f"{'='*80}")
    
    # عرض ملخص
    print(f"\n📊 Conversion Summary:")
    print(f"{'Asset':<15} {'Status':<10} {'R² Score':<12} {'RMSE':<12}")
    print(f"{'-'*50}")
    for asset, info in results.items():
        status = "✅" if info['success'] else "❌"
        print(f"{asset:<15} {status:<10} {info['r2']:<12.4f} {info['rmse']:<12.4f}")


if __name__ == '__main__':
    main()

