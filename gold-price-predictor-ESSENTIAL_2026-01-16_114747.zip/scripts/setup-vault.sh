#!/bin/bash

# ============================================
# Dotenv Vault Setup Script
# ============================================
# This script initializes dotenv-vault for secure secrets management
# Run this once to set up the vault for your project

set -e  # Exit on error

echo "🔐 Setting up dotenv-vault..."
echo ""

# ============================================
# Step 1: Check if dotenv-vault CLI is installed
# ============================================
echo "📦 Step 1: Checking dotenv-vault CLI..."
if ! command -v dotenv-vault &> /dev/null; then
    echo "⚠️  dotenv-vault CLI not found. Installing..."
    npm install -g dotenv-vault
    echo "✅ dotenv-vault CLI installed successfully"
else
    echo "✅ dotenv-vault CLI already installed"
fi
echo ""

# ============================================
# Step 2: Check if .env file exists
# ============================================
echo "📝 Step 2: Checking .env file..."
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Creating from .env.example..."
    cp .env.example .env
    echo "✅ .env file created. Please fill in your actual secrets before continuing."
    echo ""
    echo "❌ IMPORTANT: Edit .env file with your actual secrets, then run this script again."
    exit 1
else
    echo "✅ .env file found"
fi
echo ""

# ============================================
# Step 3: Initialize vault (if not already initialized)
# ============================================
echo "🔧 Step 3: Initializing vault..."
if [ ! -f .env.vault ]; then
    echo "Creating new vault..."
    dotenv-vault new
    echo "✅ Vault initialized"
else
    echo "✅ Vault already initialized"
fi
echo ""

# ============================================
# Step 4: Push secrets to vault
# ============================================
echo "⬆️  Step 4: Pushing secrets to vault..."
dotenv-vault push
echo "✅ Secrets pushed to vault"
echo ""

# ============================================
# Step 5: Build encrypted vault
# ============================================
echo "🔒 Step 5: Building encrypted vault..."
dotenv-vault build
echo "✅ Encrypted vault built"
echo ""

# ============================================
# Step 6: Generate vault keys
# ============================================
echo "🔑 Step 6: Generating vault keys..."
echo ""
echo "📋 Production Key:"
dotenv-vault keys production
echo ""
echo "📋 Development Key:"
dotenv-vault keys development
echo ""

# ============================================
# Step 7: Create .env.vault.example
# ============================================
echo "📄 Step 7: Creating .env.vault.example..."
cat > .env.vault.example << 'EOF'
# ============================================
# Dotenv Vault Keys
# ============================================
# These keys are used to decrypt the .env.vault file
# NEVER commit these keys to git
# Store them securely in your CI/CD environment

# Production Key (use in production deployment)
# DOTENV_KEY=dotenv://:key_xxxx@dotenv.org/vault/.env.vault?environment=production

# Development Key (use in local development)
# DOTENV_KEY=dotenv://:key_xxxx@dotenv.org/vault/.env.vault?environment=development
EOF
echo "✅ .env.vault.example created"
echo ""

# ============================================
# Step 8: Update .gitignore
# ============================================
echo "🔒 Step 8: Updating .gitignore..."
if ! grep -q ".env.keys" .gitignore 2>/dev/null; then
    cat >> .gitignore << 'EOF'

# Dotenv Vault
.env.keys
.env.me
EOF
    echo "✅ .gitignore updated"
else
    echo "✅ .gitignore already configured"
fi
echo ""

# ============================================
# Final Instructions
# ============================================
echo "✅ Vault setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Save the DOTENV_KEY values securely (password manager, CI/CD secrets)"
echo "2. Add DOTENV_KEY to your production environment variables"
echo "3. Never commit .env or DOTENV_KEY to git"
echo "4. Use .env.vault for deployments"
echo ""
echo "🚀 Usage:"
echo "  Development: Use .env file (already loaded)"
echo "  Production:  Set DOTENV_KEY environment variable"
echo ""
echo "📚 Documentation: https://www.dotenv.org/docs/security/env-vault"
echo ""

