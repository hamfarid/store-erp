"""
Quick script to initialize database and create admin user
"""
import sys
sys.path.insert(0, 'D:/APPS_AI/Gold_Predictor/gold-price-predictor/backend')

from app.database_enhanced import Base, engine, SessionLocal, User, Asset
from app.auth_postgresql import hash_password

# Create tables
print("Creating database tables...")
Base.metadata.create_all(bind=engine)
print("✅ Tables created successfully")

# Create session
db = SessionLocal()

try:
    # Check if admin exists
    admin = db.query(User).filter(User.username == "admin").first()
    
    if not admin:
        print("Creating admin user...")
        admin = User(
            username="admin",
            email="admin@goldpredictor.com",
            hashed_password=hash_password("Admin@123"),
            is_admin=True,
            is_active=True
        )
        db.add(admin)
        db.commit()
        print("✅ Admin user created (username: admin, password: Admin@123)")
    else:
        print("ℹ️ Admin user already exists")
    
    # Seed some basic assets
    assets = [
        {"symbol": "GOLD", "name": "Gold", "category": "Precious Metals"},
        {"symbol": "SILVER", "name": "Silver", "category": "Precious Metals"},
        {"symbol": "BTC", "name": "Bitcoin", "category": "Cryptocurrency"},
        {"symbol": "ETH", "name": "Ethereum", "category": "Cryptocurrency"},
    ]
    
    for asset_data in assets:
        asset = db.query(Asset).filter(Asset.symbol == asset_data["symbol"]).first()
        if not asset:
            asset = Asset(**asset_data)
            db.add(asset)
    
    db.commit()
    print("✅ Assets seeded successfully")
    print("\n🎉 Database initialization complete!")
    print("\nAdmin Credentials:")
    print("  Username: admin")
    print("  Password: Admin@123")
    
except Exception as e:
    print(f"❌ Error: {e}")
    db.rollback()
finally:
    db.close()
