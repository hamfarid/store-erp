/**
 * FILE: scripts/migrate-opinions.ts
 * PURPOSE: Apply expert opinions migration
 * OWNER: ML Team
 * RELATED: drizzle/migrations/0003_expert_opinions.sql
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath =
  process.env.DATABASE_URL?.replace("file:", "") ||
  resolve(__dirname, "../data/app.db");
const migrationPath = resolve(
  __dirname,
  "../drizzle/migrations/0003_expert_opinions.sql"
);

console.log("🚀 Starting expert opinions migration...");
console.log(`📁 Database: ${dbPath}`);
console.log(`📄 Migration: ${migrationPath}`);

try {
  const db = new Database(dbPath);
  const migrationSQL = readFileSync(migrationPath, "utf-8");

  db.exec(migrationSQL);

  console.log("✅ Migration completed successfully!");
  console.log("");
  console.log("📊 Created tables:");

  const tables = db
    .prepare(
      `
    SELECT name FROM sqlite_master
    WHERE type='table'
    AND name IN (
      'expert_opinions',
      'social_sentiment',
      'scraping_jobs',
      'opinion_analysis_cache',
      'sentiment_trends'
    )
  `
    )
    .all();

  tables.forEach((table: any) => {
    console.log(`  ✓ ${table.name}`);
  });

  console.log("");
  console.log("🎉 Expert opinions & web scraping system is ready!");

  db.close();
} catch (error) {
  console.error("❌ Migration failed:", error);
  process.exit(1);
}

