console.log("🧪 Testing tRPC Login Endpoint");
console.log("=".repeat(50));

async function testTRPCLogin() {
  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";

  console.log("\n📤 Sending tRPC login request...");
  console.log(`   Email: ${email}`);
  console.log(`   Password: ${password}`);

  try {
    // tRPC format: POST to /api/trpc/auth.login with input wrapped in "input" key
    const url = "http://localhost:2505/api/trpc/auth.login";
    const body = JSON.stringify({
      input: {
        email,
        password,
      },
    });

    console.log(`\n🔗 URL: ${url}`);
    console.log(`📦 Body: ${body}`);

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body,
    });

    console.log(`\n📥 Response status: ${response.status}`);
    console.log(`   Status text: ${response.statusText}`);

    const contentType = response.headers.get("content-type");
    console.log(`   Content-Type: ${contentType}`);

    const data = await response.text();
    console.log(`\n📄 Response body:`);
    console.log(data);

    // Try to parse as JSON
    try {
      const json = JSON.parse(data);
      console.log(`\n📊 Parsed JSON:`);
      console.log(JSON.stringify(json, null, 2));
    } catch (e) {
      console.log(`   (Not valid JSON)`);
    }

    if (response.ok) {
      console.log("\n" + "=".repeat(50));
      console.log("✅ TRPC LOGIN TEST PASSED!");
      console.log("=".repeat(50));
    } else {
      console.log("\n" + "=".repeat(50));
      console.log("❌ TRPC LOGIN TEST FAILED!");
      console.log("=".repeat(50));
    }
  } catch (error) {
    console.error("\n❌ Error:", error);
    console.log("\n" + "=".repeat(50));
    console.log("❌ TRPC LOGIN TEST FAILED!");
    console.log("=".repeat(50));
  }
}

testTRPCLogin().catch(console.error);
