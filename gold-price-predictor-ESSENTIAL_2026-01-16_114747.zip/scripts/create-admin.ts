/**
 * FILE: scripts/create-admin.ts
 * PURPOSE: Create default admin user
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import { getDb } from "../server/db";
import { users } from "../drizzle/schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

async function createAdmin() {
  console.log("🔐 Creating admin user...");

  const db = await getDb();
  if (!db) {
    console.error("❌ Database not available");
    process.exit(1);
  }

  const email = "admin@gaaraholding.com";
  const password = "admin123"; // Change this after first login!

  try {
    // Check if admin already exists
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (existing.length > 0) {
      console.log("⚠️  Admin user already exists");
      console.log(`📧 Email: ${email}`);
      console.log("🔑 Use existing password");
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create admin user
    await db.insert(users).values({
      email,
      password: hashedPassword,
      role: "admin",
      name: "Administrator",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    console.log("✅ Admin user created successfully!");
    console.log(`📧 Email: ${email}`);
    console.log(`🔑 Password: ${password}`);
    console.log("⚠️  IMPORTANT: Change password after first login!");
  } catch (error) {
    console.error("❌ Error creating admin user:", error);
    process.exit(1);
  }
}

createAdmin()
  .then(() => {
    console.log("✅ Done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Fatal error:", error);
    process.exit(1);
  });

