-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    "openId" VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    "loginMethod" VARCHAR(50) DEFAULT 'local',
    role VARCHAR(50) DEFAULT 'user',
    "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    "lastSignedIn" TIMESTAMP,
    "passwordHash" VARCHAR(255)
);

-- Create admin user
INSERT INTO users ("openId", name, email, "loginMethod", role, "passwordHash")
VALUES ('user_1764073921125_xeqaf', 'Admin User', 'admin@example.com', 'local', 'admin', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4oaC3b4.D2a9C2nG')
ON CONFLICT ("openId") DO NOTHING;

-- Also insert a default test user
INSERT INTO users ("openId", name, email, "loginMethod", role, "passwordHash")
VALUES ('user_test_001', 'Test User', 'test@example.com', 'local', 'user', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4oaC3b4.D2a9C2nG')
ON CONFLICT ("openId") DO NOTHING;

