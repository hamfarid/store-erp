/**
 * FILE: scripts/fix-admin-user.ts
 * PURPOSE: Delete old admin and create new one with email
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import bcrypt from "bcryptjs";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🔧 Fixing Admin User");
console.log("=".repeat(50));

async function fixAdminUser() {
  const sqlite = new Database(dbPath);

  // Delete old admin users (with null email)
  console.log("\n1️⃣ Deleting old admin users...");
  const deleted = sqlite
    .prepare("DELETE FROM users WHERE role = 'admin' AND email IS NULL")
    .run();
  console.log(`   Deleted: ${deleted.changes} admin users`);

  // Create new admin user
  console.log("\n2️⃣ Creating new admin user...");
  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";
  const role = "admin";

  const hashedPassword = await bcrypt.hash(password, 10);
  const userId = `user_${Date.now()}_${Math.random().toString(36).substring(7)}`;

  sqlite
    .prepare(
      `INSERT INTO users (id, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(userId, email, hashedPassword, "local", role, Date.now(), Date.now());

  console.log("   ✅ Admin user created!");

  // Verify
  console.log("\n3️⃣ Verifying...");
  const user = sqlite
    .prepare("SELECT id, email, role FROM users WHERE email = ?")
    .get(email) as any;

  if (user) {
    console.log("   ✅ User found:");
    console.log(`      ID: ${user.id}`);
    console.log(`      Email: ${user.email}`);
    console.log(`      Role: ${user.role}`);
  } else {
    console.log("   ❌ User NOT found!");
  }

  // List all users
  console.log("\n4️⃣ All users:");
  const allUsers = sqlite.prepare("SELECT id, email, role FROM users").all();
  allUsers.forEach((u: any) => {
    console.log(`   - ${u.email || "NO EMAIL"} (${u.role})`);
  });

  sqlite.close();

  console.log("\n" + "=".repeat(50));
  console.log("✅ Admin user fixed!");
  console.log("=".repeat(50));
  console.log(`Email:    ${email}`);
  console.log(`Password: ${password}`);
  console.log("=".repeat(50));
}

fixAdminUser().catch(error => {
  console.error("❌ Error:", error);
  process.exit(1);
});

