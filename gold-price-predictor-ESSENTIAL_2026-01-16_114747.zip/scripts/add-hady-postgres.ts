// Add Hady admin user to PostgreSQL
import { Pool } from "pg";
import * as bcrypt from "bcryptjs";
import * as dotenv from "dotenv";

dotenv.config();

const databaseUrl = process.env.DATABASE_URL_POSTGRES || process.env.DATABASE_URL;

async function addHadyUser() {
  console.log("🔐 Adding Hady Admin User to PostgreSQL...\n");

  const pool = new Pool({ connectionString: databaseUrl });

  try {
    const email = "hady.m.farid@gmail.com";
    const password = "Ha27041983";
    const name = "Hamfarid";
    const role = "admin";

    // Delete existing user if exists
    await pool.query("DELETE FROM users WHERE email = $1", [email]);
    console.log("🗑️  Cleared existing user (if any)");

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("🔒 Password hashed");

    // Generate user ID
    const userId = `user_${Date.now()}_hady`;

    // Insert user
    await pool.query(
      `INSERT INTO users (id, email, "passwordHash", "loginMethod", role, name, "createdAt", "lastSignedIn")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [userId, email, hashedPassword, "local", role, name, Date.now(), Date.now()]
    );

    console.log("✅ User created!\n");
    console.log("📧 Email:", email);
    console.log("🔑 Password:", password);
    console.log("👤 Name:", name);
    console.log("🎭 Role:", role);

    // Verify
    const result = await pool.query(
      "SELECT id, email, role, name FROM users WHERE email = $1",
      [email]
    );
    console.log("\n✔️  Verified:", result.rows[0]);

    await pool.end();
  } catch (error) {
    console.error("❌ Error:", error);
    await pool.end();
    process.exit(1);
  }
}

addHadyUser();

