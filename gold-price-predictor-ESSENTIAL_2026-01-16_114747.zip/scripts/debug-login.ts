/**
 * FILE: scripts/debug-login.ts | PURPOSE: Debug login issue | OWNER: Backend | LAST-AUDITED: 2025-11-24
 */

import Database from "better-sqlite3";
import bcrypt from "bcryptjs";

const DB_PATH = "./data/asset_predictor.db";

async function debugLogin() {
  console.log("🔍 Debugging Login Issue");
  console.log("=".repeat(60));

  const sqlite = new Database(DB_PATH);

  // 1. Check all users
  console.log("\n1️⃣ All users in database:");
  const allUsers = sqlite.prepare("SELECT * FROM users").all() as any[];
  console.log(`   Total users: ${allUsers.length}`);
  allUsers.forEach((user, index) => {
    console.log(`\n   User ${index + 1}:`);
    console.log(`   - ID: ${user.id}`);
    console.log(`   - Email: ${user.email}`);
    console.log(`   - Role: ${user.role}`);
    console.log(`   - Login Method: ${user.loginMethod}`);
    console.log(`   - Has Password Hash: ${user.passwordHash ? "Yes" : "No"}`);
    if (user.passwordHash) {
      console.log(`   - Password Hash: ${user.passwordHash.substring(0, 30)}...`);
    }
  });

  // 2. Test specific user
  console.log("\n2️⃣ Testing admin@gaaraholding.com:");
  const adminUser = sqlite
    .prepare("SELECT * FROM users WHERE email = ?")
    .get("admin@gaaraholding.com") as any;

  if (!adminUser) {
    console.log("   ❌ User not found!");
    sqlite.close();
    return;
  }

  console.log("   ✅ User found");
  console.log(`   - ID: ${adminUser.id}`);
  console.log(`   - Email: ${adminUser.email}`);
  console.log(`   - Password Hash: ${adminUser.passwordHash?.substring(0, 30)}...`);

  // 3. Test password
  console.log("\n3️⃣ Testing password verification:");
  const testPassword = "Admin@2025!";
  
  if (!adminUser.passwordHash) {
    console.log("   ❌ No password hash!");
    sqlite.close();
    return;
  }

  const isValid = await bcrypt.compare(testPassword, adminUser.passwordHash);
  console.log(`   - Password: ${testPassword}`);
  console.log(`   - Valid: ${isValid ? "✅ YES" : "❌ NO"}`);

  // 4. Test with wrong password
  console.log("\n4️⃣ Testing with wrong password:");
  const wrongPassword = "WrongPassword123!";
  const isWrongValid = await bcrypt.compare(wrongPassword, adminUser.passwordHash);
  console.log(`   - Password: ${wrongPassword}`);
  console.log(`   - Valid: ${isWrongValid ? "✅ YES (PROBLEM!)" : "❌ NO (CORRECT)"}`);

  // 5. Check database file
  console.log("\n5️⃣ Database info:");
  const dbInfo = sqlite.prepare("PRAGMA database_list").all() as any[];
  console.log(`   - Database file: ${dbInfo[0].file}`);
  
  const tableCount = sqlite
    .prepare("SELECT COUNT(*) as count FROM sqlite_master WHERE type='table'")
    .get() as any;
  console.log(`   - Total tables: ${tableCount.count}`);

  sqlite.close();

  console.log("\n" + "=".repeat(60));
  console.log("✅ Debug complete");
  console.log("=".repeat(60));
}

debugLogin().catch((error) => {
  console.error("❌ Error:", error);
  process.exit(1);
});

