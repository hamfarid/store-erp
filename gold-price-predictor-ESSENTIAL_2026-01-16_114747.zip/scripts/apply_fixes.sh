#!/bin/bash
# File: /home/ubuntu/gold-price-predictor/scripts/apply_fixes.sh
# سكريبت تلقائي لتطبيق الإصلاحات المطلوبة

set -e  # إيقاف عند أي خطأ

# الألوان للطباعة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "======================================"
echo "🔧 بدء تطبيق الإصلاحات"
echo "======================================"
echo ""

# التحقق من المسار
if [ ! -d "backend/app" ]; then
    echo -e "${RED}❌ خطأ: يجب تشغيل السكريبت من المجلد الجذر للمشروع${NC}"
    exit 1
fi

# 1. تثبيت الأدوات المطلوبة
echo -e "${YELLOW}📦 تثبيت الأدوات المطلوبة...${NC}"
pip3 install -q autopep8 flake8 pipreqs pytest pytest-cov
echo -e "${GREEN}✅ تم تثبيت الأدوات${NC}"
echo ""

# 2. فحص الكود باستخدام flake8
echo -e "${YELLOW}🔍 فحص الكود باستخدام flake8...${NC}"
flake8 backend/app --count --select=E9,F63,F7,F82 --show-source --statistics || true
echo -e "${GREEN}✅ اكتمل فحص flake8${NC}"
echo ""

# 3. تنسيق الكود باستخدام autopep8
echo -e "${YELLOW}✨ تنسيق الكود باستخدام autopep8...${NC}"
find backend/app -name "*.py" -exec autopep8 --in-place --aggressive --aggressive {} \;
echo -e "${GREEN}✅ تم تنسيق الكود${NC}"
echo ""

# 4. تشغيل الاختبارات
echo -e "${YELLOW}🧪 تشغيل الاختبارات...${NC}"
cd backend/app
python3 -m pytest tests/ -v --cov=. --cov-report=html --cov-report=term || true
cd ../..
echo -e "${GREEN}✅ اكتملت الاختبارات${NC}"
echo ""

# 5. إنشاء requirements.txt
echo -e "${YELLOW}📄 إنشاء requirements.txt...${NC}"
cd backend/app
pipreqs . --force --ignore tests || true
cd ../..
echo -e "${GREEN}✅ تم إنشاء requirements.txt${NC}"
echo ""

echo "======================================"
echo -e "${GREEN}✅ اكتملت جميع الإصلاحات الأساسية${NC}"
echo "======================================"
echo ""
echo "الخطوات التالية:"
echo "1. راجع نتائج الاختبارات في backend/app/htmlcov/index.html"
echo "2. راجع TODO_FIXES.md لمتابعة الإصلاحات المتبقية"
echo "3. قم بعمل commit للتغييرات"
echo ""

