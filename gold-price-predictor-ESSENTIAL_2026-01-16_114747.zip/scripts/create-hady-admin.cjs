const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const dbPath = './data/asset_predictor.db';
const sqlite = new Database(dbPath);

const email = 'hady.m.farid@gmail.com';
const password = 'Ha27041983';
const role = 'admin';
const name = 'Hamfarid';

console.log('🔐 Creating Admin User: ' + email);

// Check if user already exists
const existingUser = sqlite.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
if (existingUser) {
  console.log('⚠️  User exists, updating...');
  sqlite.prepare('DELETE FROM users WHERE email = ?').run(email);
}

// Hash password
const hashedPassword = bcrypt.hashSync(password, 10);
const userId = 'user_' + Date.now() + '_admin';

// Insert user
sqlite.prepare(
  'INSERT INTO users (id, email, passwordHash, loginMethod, role, name, createdAt, lastSignedIn) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
).run(userId, email, hashedPassword, 'local', role, name, Date.now(), Date.now());

console.log('✅ Admin user created!');
console.log('📧 Email: ' + email);
console.log('🔑 Password: ' + password);
console.log('👤 Name: ' + name);
console.log('🎭 Role: ' + role);

// Verify
const user = sqlite.prepare('SELECT id, email, role, name FROM users WHERE email = ?').get(email);
console.log('✔️  Verified:', user);

sqlite.close();

