/**
 * FILE: scripts/test-api-login.ts
 * PURPOSE: Test login via API
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-24
 */

const API_URL = "http://localhost:2505/api/trpc";

async function testLogin() {
  console.log("🔐 Testing Login via API");
  console.log("=".repeat(50));

  const email = "admin@gaaraholding.com";
  const password = "Admin@2025!";

  console.log(`\n📧 Email: ${email}`);
  console.log(`🔑 Password: ${password}`);

  try {
    // Test login endpoint
    console.log("\n1️⃣ Sending login request...");

    // tRPC requires input to be in a specific format
    const input = {
      0: {
        json: {
          email,
          password,
        },
      },
    };

    const response = await fetch(`${API_URL}/auth.login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(input),
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);

    const text = await response.text();
    console.log(`\n📄 Response:`);
    console.log(text);

    if (response.ok) {
      console.log("\n✅ Login successful!");

      try {
        const data = JSON.parse(text);
        console.log("\n📊 Response data:");
        console.log(JSON.stringify(data, null, 2));
      } catch (e) {
        console.log("⚠️ Could not parse response as JSON");
      }
    } else {
      console.log("\n❌ Login failed!");
    }
  } catch (error) {
    console.error("\n❌ Error:", error);
  }

  console.log("\n" + "=".repeat(50));
}

testLogin();
