# Show Container Logs - Simple Version
Write-Host "`n" -NoNewline
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🔍 فحص سجلات الحاويات" -ForegroundColor Yellow  
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Backend
Write-Host "[1/3] Backend Logs:" -ForegroundColor Green
docker logs gold-predictor-backend --tail 50
Write-Host ""

# ML Service  
Write-Host "[2/3] ML Service Logs:" -ForegroundColor Green
docker logs gold-predictor-ml --tail 50
Write-Host ""

# Prometheus
Write-Host "[3/3] Prometheus Logs:" -ForegroundColor Green
docker logs gold-predictor-prometheus --tail 30
Write-Host ""

Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "Container Status:" -ForegroundColor Yellow
docker ps -a --filter "name=gold-predictor"
Write-Host ""

