#!/usr/bin/env tsx
/**
 * Seed script to populate assets table with initial data
 */

import { drizzle } from "drizzle-orm/mysql2";
import { assets } from "../drizzle/schema";

const db = drizzle(process.env.DATABASE_URL!);

const assetsData = [
  // Commodities
  { name: "الذهب", symbol: "GC=F", category: "commodity" as const },
  { name: "الفضة", symbol: "SI=F", category: "commodity" as const },
  { name: "النفط WTI", symbol: "CL=F", category: "commodity" as const },
  { name: "النفط برنت", symbol: "BZ=F", category: "commodity" as const },
  { name: "البلاتين", symbol: "PL=F", category: "commodity" as const },
  { name: "البلاديوم", symbol: "PA=F", category: "commodity" as const },
  { name: "النحاس", symbol: "HG=F", category: "commodity" as const },
  { name: "الغاز الطبيعي", symbol: "NG=F", category: "commodity" as const },
  
  // Cryptocurrencies
  { name: "البيتكوين", symbol: "BTC-USD", category: "crypto" as const },
  { name: "الإيثيريوم", symbol: "ETH-USD", category: "crypto" as const },
  
  // Currencies
  { name: "الليرة التركية", symbol: "TRY=X", category: "currency" as const },
  { name: "الجنيه المصري", symbol: "EGP=X", category: "currency" as const },
];

async function seed() {
  console.log("🌱 Seeding assets...");
  
  try {
    for (const asset of assetsData) {
      await db.insert(assets).values(asset);
      console.log(`✅ Added: ${asset.name} (${asset.symbol})`);
    }
    
    console.log("\n✅ Seeding completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
}

seed();

