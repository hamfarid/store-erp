# FILE: scripts/stop.ps1 | PURPOSE: Quick stop script | OWNER: DevOps Team | RELATED: start.ps1 | LAST-AUDITED: 2025-11-27

<#
.SYNOPSIS
    Quick stop script for Gold Price Predictor

.DESCRIPTION
    Stops all services using Docker Compose

.PARAMETER Production
    Stop production configuration

.PARAMETER RemoveVolumes
    Remove volumes (WARNING: Data loss!)

.EXAMPLE
    .\scripts\stop.ps1
    .\scripts\stop.ps1 -Production
    .\scripts\stop.ps1 -RemoveVolumes
#>

param(
    [Parameter(Mandatory=$false)]
    [switch]$Production,

    [Parameter(Mandatory=$false)]
    [switch]$RemoveVolumes
)

$ErrorActionPreference = "Stop"

# Change to project root
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Gold Price Predictor - Quick Stop" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Determine compose file
$composeFile = if ($Production) {
    "docker-compose.production.yml"
} else {
    "docker-compose.yml"
}

$envType = if ($Production) { "Production" } else { "Development" }

Write-Host "Stopping $envType environment..." -ForegroundColor Yellow
Write-Host "Using: $composeFile" -ForegroundColor Gray
Write-Host ""

# Stop services
Write-Host "Stopping services..." -ForegroundColor Yellow

$downArgs = @("-f", $composeFile, "down")
if ($RemoveVolumes) {
    Write-Host ""
    Write-Host "WARNING: This will remove all volumes and data!" -ForegroundColor Red
    $confirm = Read-Host "Are you sure? (yes/no)"

    if ($confirm -eq "yes") {
        $downArgs += "-v"
        Write-Host "Removing volumes..." -ForegroundColor Yellow
    } else {
        Write-Host "Cancelled." -ForegroundColor Yellow
        exit 0
    }
}

try {
    docker compose @downArgs
    Write-Host "✓ Services stopped successfully!" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed to stop services!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Services Stopped!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
