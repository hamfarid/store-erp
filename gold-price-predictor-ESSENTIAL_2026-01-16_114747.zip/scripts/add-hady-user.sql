-- Add Hady admin user
DELETE FROM users WHERE email = 'hady.m.farid@gmail.com';

INSERT INTO users (id, email, "passwordHash", "loginMethod", role, name, "createdAt", "lastSignedIn")
VALUES (
  'user_hady_admin_001',
  'hady.m.farid@gmail.com',
  '$2a$10$Kx7VQXz8YqZ5xN0MwYzOHOqJqJqJqJqJqJqJqJqJqJqJqJqJqJqJq',
  'local',
  'admin',
  'Hamfarid',
  1764242300000,
  1764242300000
);

SELECT id, email, role, name FROM users WHERE email = 'hady.m.farid@gmail.com';

