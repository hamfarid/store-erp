/**
 * Setup Learning Control Tables
 * Creates the 5 tables needed for Learning Control Dashboard
 */

import Database from 'better-sqlite3';
import { join } from 'path';
import { mkdirSync, existsSync } from 'fs';

function setupLearningControlTables() {
  console.log('🔧 Setting up Learning Control tables...\n');

  // Ensure data directory exists
  const dataDir = join(process.cwd(), 'data');
  if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true });
    console.log('📂 Created data directory');
  }

  // Connect to database
  const dbPath = process.env.DATABASE_URL 
    ? process.env.DATABASE_URL.replace('file:', '')
    : join(dataDir, 'app.db');
  
  console.log(`📂 Database path: ${dbPath}`);

  const db = new Database(dbPath);
  db.pragma('foreign_keys = ON');

  console.log('\n📋 Creating Learning Control tables...');

  // Search Keywords table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_keywords (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      keyword TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL CHECK(category IN ('political', 'economic', 'geopolitical', 'monetary_policy', 'market', 'commodity', 'general')),
      priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high', 'critical')),
      enabled INTEGER DEFAULT 1,
      search_count INTEGER DEFAULT 0,
      last_used INTEGER,
      results_found INTEGER DEFAULT 0,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_keywords');

  // Search Sources table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_sources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('search_engine', 'news_site', 'financial_site', 'government_site', 'social_media', 'api')),
      url TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      headers TEXT,
      rate_limit INTEGER DEFAULT 60,
      request_count INTEGER DEFAULT 0,
      success_count INTEGER DEFAULT 0,
      error_count INTEGER DEFAULT 0,
      last_used INTEGER,
      last_error TEXT,
      avg_response_time INTEGER,
      reliability INTEGER DEFAULT 100,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_sources');

  // Learning Operations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS learning_operations (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN ('prediction_comparison', 'pattern_detection', 'correlation_analysis', 'model_training', 'insight_generation', 'adjustment_application')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
      progress INTEGER DEFAULT 0,
      current_step TEXT,
      total_steps INTEGER,
      input TEXT,
      output TEXT,
      error TEXT,
      started_at INTEGER,
      completed_at INTEGER,
      duration INTEGER,
      results_count INTEGER DEFAULT 0,
      insights_generated INTEGER DEFAULT 0,
      adjustments_proposed INTEGER DEFAULT 0,
      triggered_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ learning_operations');

  // Search Operations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_operations (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN ('keyword_search', 'event_discovery', 'news_scraping', 'sentiment_analysis', 'entity_extraction')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
      keywords TEXT NOT NULL,
      sources TEXT NOT NULL,
      date_range TEXT,
      progress INTEGER DEFAULT 0,
      current_source TEXT,
      sources_processed INTEGER DEFAULT 0,
      total_sources INTEGER,
      results_found INTEGER DEFAULT 0,
      events_created INTEGER DEFAULT 0,
      error TEXT,
      started_at INTEGER,
      completed_at INTEGER,
      duration INTEGER,
      triggered_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_operations');

  // Operation Logs table
  db.exec(`
    CREATE TABLE IF NOT EXISTS operation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      operation_id TEXT NOT NULL,
      operation_type TEXT NOT NULL CHECK(operation_type IN ('learning', 'search')),
      level TEXT NOT NULL CHECK(level IN ('debug', 'info', 'warning', 'error')),
      message TEXT NOT NULL,
      data TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ operation_logs');

  // Create indexes
  console.log('\n📋 Creating indexes...');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_category ON search_keywords(category)');
  console.log('  ✅ idx_search_keywords_category');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_priority ON search_keywords(priority)');
  console.log('  ✅ idx_search_keywords_priority');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_enabled ON search_keywords(enabled)');
  console.log('  ✅ idx_search_keywords_enabled');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_type ON search_sources(type)');
  console.log('  ✅ idx_search_sources_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_enabled ON search_sources(enabled)');
  console.log('  ✅ idx_search_sources_enabled');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_type ON learning_operations(type)');
  console.log('  ✅ idx_learning_operations_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_status ON learning_operations(status)');
  console.log('  ✅ idx_learning_operations_status');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_created_at ON learning_operations(created_at)');
  console.log('  ✅ idx_learning_operations_created_at');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_type ON search_operations(type)');
  console.log('  ✅ idx_search_operations_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_status ON search_operations(status)');
  console.log('  ✅ idx_search_operations_status');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_created_at ON search_operations(created_at)');
  console.log('  ✅ idx_search_operations_created_at');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_id ON operation_logs(operation_id)');
  console.log('  ✅ idx_operation_logs_operation_id');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_level ON operation_logs(level)');
  console.log('  ✅ idx_operation_logs_level');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_timestamp ON operation_logs(timestamp)');
  console.log('  ✅ idx_operation_logs_timestamp');

  console.log('\n✅ Learning Control tables setup complete!');

  // Verify tables exist
  console.log('\n📊 Verifying tables...');
  const tables = db.prepare(`
    SELECT name FROM sqlite_master 
    WHERE type='table' 
    AND name IN ('search_keywords', 'search_sources', 'learning_operations', 'search_operations', 'operation_logs')
  `).all();
  
  console.log(`✅ Found ${tables.length}/5 tables:`);
  tables.forEach(table => console.log(`   - ${table.name}`));

  db.close();
}

// Run setup
setupLearningControlTables();

