# Update Port Configuration Script
# Updates all documentation and configuration files to use:
# - Backend: 2005
# - Frontend: 2505

Write-Host "🔧 Updating port configurations..." -ForegroundColor Cyan
Write-Host "   Backend: 8000 → 2005" -ForegroundColor Yellow
Write-Host "   Frontend: 3000/5173 → 2505" -ForegroundColor Yellow
Write-Host ""

$replacements = @(
    @{Pattern = "localhost:8000"; Replacement = "localhost:2005"; Description = "Backend port"},
    @{Pattern = "localhost:3000"; Replacement = "localhost:2505"; Description = "Frontend port (3000)"},
    @{Pattern = "localhost:5173"; Replacement = "localhost:2505"; Description = "Frontend port (5173)"},
    @{Pattern = ":8000/"; Replacement = ":2005/"; Description = "Backend URL path"},
    @{Pattern = ":3000/"; Replacement = ":2505/"; Description = "Frontend URL path"},
    @{Pattern = "port 8000"; Replacement = "port 2005"; Description = "Backend port reference"},
    @{Pattern = "port 3000"; Replacement = "port 2505"; Description = "Frontend port reference"},
    @{Pattern = "Port 8000"; Replacement = "Port 2005"; Description = "Backend port (capitalized)"},
    @{Pattern = "Port 3000"; Replacement = "Port 2505"; Description = "Frontend port (capitalized)"},
    @{Pattern = "backend:8000"; Replacement = "backend:2005"; Description = "Docker backend target"},
    @{Pattern = "'backend:8000'"; Replacement = "'backend:2005'"; Description = "Docker backend target (quoted)"}
)

$filePatterns = @("*.md", "*.txt", "*.json", "*.yml", "*.yaml")
$excludeDirs = @(".git", "node_modules", ".venv", ".venv311", "dist", "build", "__pycache__", "playwright-report")

$totalUpdates = 0

foreach ($replacement in $replacements) {
    Write-Host "📝 Replacing: $($replacement.Description)" -ForegroundColor Green
    Write-Host "   From: $($replacement.Pattern)" -ForegroundColor Gray
    Write-Host "   To:   $($replacement.Replacement)" -ForegroundColor Gray
    
    $fileCount = 0
    
    foreach ($pattern in $filePatterns) {
        $files = Get-ChildItem -Path . -Filter $pattern -Recurse -File | Where-Object {
            $file = $_
            $exclude = $false
            foreach ($dir in $excludeDirs) {
                if ($file.FullName -like "*\$dir\*") {
                    $exclude = $true
                    break
                }
            }
            -not $exclude
        }
        
        foreach ($file in $files) {
            try {
                $content = Get-Content $file.FullName -Raw -ErrorAction Stop
                if ($content -match [regex]::Escape($replacement.Pattern)) {
                    $newContent = $content -replace [regex]::Escape($replacement.Pattern), $replacement.Replacement
                    Set-Content -Path $file.FullName -Value $newContent -NoNewline
                    $fileCount++
                    Write-Host "      ✓ Updated: $($file.FullName.Replace((Get-Location).Path, '.'))" -ForegroundColor DarkGray
                }
            } catch {
                Write-Host "      ✗ Error: $($file.FullName) - $_" -ForegroundColor Red
            }
        }
    }
    
    if ($fileCount -gt 0) {
        Write-Host "   → Updated $fileCount files" -ForegroundColor Cyan
        $totalUpdates += $fileCount
    } else {
        Write-Host "   → No files found" -ForegroundColor DarkGray
    }
    Write-Host ""
}

Write-Host "═════════════════════════════════════════════════��═" -ForegroundColor Cyan
Write-Host "✅ Port update complete!" -ForegroundColor Green
Write-Host "   Total files updated: $totalUpdates" -ForegroundColor Yellow
Write-Host ""
Write-Host "📌 New Configuration:" -ForegroundColor Cyan
Write-Host "   Backend:  http://localhost:2005" -ForegroundColor Yellow
Write-Host "   Frontend: http://localhost:2505" -ForegroundColor Yellow
Write-Host "   Docs:     http://localhost:2005/docs" -ForegroundColor Yellow
Write-Host "   ReDoc:    http://localhost:2005/redoc" -ForegroundColor Yellow
Write-Host "   Grafana:  http://localhost:2505" -ForegroundColor Yellow
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
