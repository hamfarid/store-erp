/**
 * Create User Script
 * Creates a new user in the PostgreSQL database
 *
 * Usage:
 *   npx tsx scripts/create-user.ts --name "John Doe" --email "john@example.com" --password "password123" --role "user"
 *   npx tsx scripts/create-user.ts --name "Admin" --email "admin@example.com" --password "admin123" --role "admin"
 */

/* eslint-disable no-console */
import { config } from "dotenv";
import * as db from "../server/db-postgres";
import { hashPassword, generateUserId } from "../server/_core/auth-local";

// Load environment variables
config();

interface CreateUserOptions {
  name: string;
  email: string;
  password: string;
  role?: "user" | "admin";
}

async function createUser(options: CreateUserOptions) {
  try {
    console.log("🔧 Initializing database connection...");

    // Initialize database tables if needed
    await db.initDatabase();

    console.log("✅ Database connected");

    // Check if user already exists
    const existingUser = await db.getUserByEmail(options.email);
    if (existingUser) {
      console.error(`❌ User with email ${options.email} already exists!`);
      process.exit(1);
    }

    // Generate user ID
    const userId = generateUserId();
    console.log(`📝 Generated user ID: ${userId}`);

    // Hash password
    console.log("🔐 Hashing password...");
    const passwordHash = await hashPassword(options.password);

    // Create user
    console.log("👤 Creating user...");
    const user = await db.createUser({
      id: userId,
      name: options.name,
      email: options.email,
      passwordHash,
      loginMethod: "local",
      role: options.role || "user",
    });

    console.log("\n✅ User created successfully!");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("User Details:");
    console.log(`  ID: ${user.id}`);
    console.log(`  Name: ${user.name}`);
    console.log(`  Email: ${user.email}`);
    console.log(`  Role: ${user.role}`);
    console.log(`  Login Method: ${user.loginMethod}`);
    console.log(`  Created At: ${new Date(user.createdAt).toISOString()}`);
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

    process.exit(0);
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    const errorStack = error instanceof Error ? error.stack : undefined;
    console.error("❌ Error creating user:", errorMessage);
    if (errorStack) {
      console.error(errorStack);
    }
    process.exit(1);
  }
}

// Parse command line arguments
function parseArgs(): CreateUserOptions {
  const args = process.argv.slice(2);
  const options: Partial<CreateUserOptions> = {};

  for (let i = 0; i < args.length; i += 2) {
    const key = args[i]?.replace(/^--/, "");
    const value = args[i + 1];

    if (key === "name") {
      options.name = value;
    } else if (key === "email") {
      options.email = value;
    } else if (key === "password") {
      options.password = value;
    } else if (key === "role") {
      if (value === "admin" || value === "user") {
        options.role = value;
      } else {
        console.error(`❌ Invalid role: ${value}. Must be "user" or "admin"`);
        process.exit(1);
      }
    }
  }

  // Validate required fields
  if (!options.name) {
    console.error("❌ --name is required");
    process.exit(1);
  }
  if (!options.email) {
    console.error("❌ --email is required");
    process.exit(1);
  }
  if (!options.password) {
    console.error("❌ --password is required");
    process.exit(1);
  }

  return options as CreateUserOptions;
}

// Interactive mode if no arguments provided
async function interactiveMode() {
  const { createInterface } = await import("readline");
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = (query: string): Promise<string> => {
    return new Promise(resolve => {
      rl.question(query, resolve);
    });
  };

  try {
    console.log("\n👤 Create New User");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

    const name = await question("Name: ");
    const email = await question("Email: ");
    const password = await question("Password (min 8 characters): ");
    const roleInput = await question("Role (user/admin) [user]: ");

    rl.close();

    if (password.length < 8) {
      console.error("❌ Password must be at least 8 characters long");
      process.exit(1);
    }

    const role = roleInput.trim() === "admin" ? "admin" : "user";

    await createUser({
      name: name.trim(),
      email: email.trim(),
      password: password.trim(),
      role,
    });
  } catch (error: unknown) {
    rl.close();
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("❌ Error:", errorMessage);
    process.exit(1);
  }
}

// Main execution
async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    // Interactive mode
    await interactiveMode();
  } else {
    // Command line arguments mode
    const options = parseArgs();
    await createUser(options);
  }
}

main().catch(error => {
  console.error("❌ Fatal error:", error);
  process.exit(1);
});
