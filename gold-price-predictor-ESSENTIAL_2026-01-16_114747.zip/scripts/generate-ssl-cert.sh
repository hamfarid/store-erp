#!/bin/bash
# FILE: scripts/generate-ssl-cert.sh | PURPOSE: Generate SSL certificate (Linux/macOS) | OWNER: DevOps Team | RELATED: generate-ssl-cert.ps1 | LAST-AUDITED: 2025-11-27

set -e

echo "========================================"
echo "SSL Certificate Generator"
echo "========================================"
echo ""

# Check if OpenSSL is installed
if ! command -v openssl &> /dev/null; then
    echo "ERROR: OpenSSL not found!"
    echo "Please install OpenSSL:"
    echo "  - Ubuntu/Debian: sudo apt-get install openssl"
    echo "  - macOS: brew install openssl"
    exit 1
fi

# Create SSL directory
mkdir -p nginx/ssl

# Certificate configuration
CERT_FILE="nginx/ssl/cert.pem"
KEY_FILE="nginx/ssl/key.pem"
DAYS=365
SUBJECT="/C=EG/ST=Cairo/L=Cairo/O=GoldPredictor/OU=Development/CN=localhost"

echo "Generating self-signed certificate..."
echo "  Certificate: $CERT_FILE"
echo "  Private Key: $KEY_FILE"
echo "  Valid for: $DAYS days"
echo ""

# Generate certificate
openssl req -x509 -nodes -days $DAYS -newkey rsa:2048 \
  -keyout "$KEY_FILE" \
  -out "$CERT_FILE" \
  -subj "$SUBJECT"

if [ -f "$CERT_FILE" ] && [ -f "$KEY_FILE" ]; then
    echo "SUCCESS: SSL certificate generated!"
    echo ""
    echo "Certificate details:"
    openssl x509 -in "$CERT_FILE" -text -noout | grep -E "(Issuer|Subject|Not Before|Not After)"

    echo ""
    echo "Files created:"
    echo "  - $CERT_FILE"
    echo "  - $KEY_FILE"

    # Set permissions
    chmod 600 "$KEY_FILE"
    chmod 644 "$CERT_FILE"

    echo ""
    echo "NOTE: This is a self-signed certificate for development only!"
    echo "Browsers will show a security warning. This is normal."
    echo ""
    echo "To use in production, obtain a certificate from:"
    echo "  - Let's Encrypt (free): https://letsencrypt.org"
    echo "  - Commercial CA: DigiCert, Comodo, etc."
else
    echo "ERROR: Certificate files not created!"
    exit 1
fi

echo ""
echo "========================================"
echo "Next steps:"
echo "1. Update .env.production with correct values"
echo "2. Run: docker compose -f docker-compose.production.yml up -d"
echo "3. Access via: https://localhost:442"
echo "========================================"
