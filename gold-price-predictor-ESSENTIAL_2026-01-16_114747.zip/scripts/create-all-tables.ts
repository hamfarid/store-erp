/**
 * FILE: scripts/create-all-tables.ts
 * PURPOSE: Create all missing database tables
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { resolve } from "path";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🗄️  Creating All Database Tables");
console.log("=".repeat(50));

const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");

// SQL statements for all tables
const createTableStatements = [
  // Logging tables
  `CREATE TABLE IF NOT EXISTS access_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    user_id INTEGER,
    created_at INTEGER NOT NULL,
    expires_at INTEGER,
    used_at INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`,

  `CREATE TABLE IF NOT EXISTS email_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    smtp_host TEXT,
    smtp_port INTEGER,
    smtp_user TEXT,
    smtp_password TEXT,
    from_email TEXT,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`,

  `CREATE TABLE IF NOT EXISTS api_request_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    endpoint TEXT NOT NULL,
    method TEXT NOT NULL,
    status_code INTEGER,
    response_time INTEGER,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`,

  `CREATE TABLE IF NOT EXISTS error_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    error_type TEXT NOT NULL,
    error_message TEXT NOT NULL,
    stack_trace TEXT,
    user_id INTEGER,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`,

  `CREATE TABLE IF NOT EXISTS ml_training_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    model_type TEXT NOT NULL,
    asset_symbol TEXT NOT NULL,
    training_duration INTEGER,
    accuracy REAL,
    loss REAL,
    created_at INTEGER NOT NULL
  )`,

  `CREATE TABLE IF NOT EXISTS prediction_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prediction_id INTEGER NOT NULL,
    actual_price REAL,
    error_percentage REAL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (prediction_id) REFERENCES predictions(id)
  )`,

  `CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL,
    read INTEGER DEFAULT 0,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`,

  // Analysis tables
  `CREATE TABLE IF NOT EXISTS break_even_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL,
    price REAL NOT NULL,
    date INTEGER NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (asset_id) REFERENCES assets(id)
  )`,

  `CREATE TABLE IF NOT EXISTS breakout_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL,
    price REAL NOT NULL,
    direction TEXT NOT NULL,
    date INTEGER NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (asset_id) REFERENCES assets(id)
  )`,

  `CREATE TABLE IF NOT EXISTS inflection_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL,
    price REAL NOT NULL,
    type TEXT NOT NULL,
    date INTEGER NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (asset_id) REFERENCES assets(id)
  )`,

  // Drift detection tables
  `CREATE TABLE IF NOT EXISTS drift_detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    method TEXT NOT NULL,
    drift_score REAL NOT NULL,
    severity TEXT NOT NULL,
    detected_at INTEGER NOT NULL,
    details TEXT
  )`,

  `CREATE TABLE IF NOT EXISTS drift_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    drift_detection_id INTEGER NOT NULL,
    acknowledged INTEGER DEFAULT 0,
    acknowledged_by INTEGER,
    acknowledged_at INTEGER,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (drift_detection_id) REFERENCES drift_detections(id),
    FOREIGN KEY (acknowledged_by) REFERENCES users(id)
  )`,

  `CREATE TABLE IF NOT EXISTS drift_metrics_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL NOT NULL,
    recorded_at INTEGER NOT NULL
  )`,

  `CREATE TABLE IF NOT EXISTS model_retraining_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    trigger_reason TEXT NOT NULL,
    status TEXT NOT NULL,
    started_at INTEGER NOT NULL,
    completed_at INTEGER,
    error_message TEXT
  )`,

  `CREATE TABLE IF NOT EXISTS data_quality_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    completeness REAL,
    accuracy REAL,
    consistency REAL,
    timeliness REAL,
    recorded_at INTEGER NOT NULL
  )`,

  // Learning path tables
  `CREATE TABLE IF NOT EXISTS learning_paths (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    algorithm TEXT NOT NULL,
    path_config TEXT NOT NULL,
    score REAL,
    status TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    completed_at INTEGER
  )`,

  `CREATE TABLE IF NOT EXISTS path_evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    learning_path_id INTEGER NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL NOT NULL,
    evaluated_at INTEGER NOT NULL,
    FOREIGN KEY (learning_path_id) REFERENCES learning_paths(id)
  )`,

  `CREATE TABLE IF NOT EXISTS hyperparameter_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    learning_path_id INTEGER NOT NULL,
    config_json TEXT NOT NULL,
    performance_score REAL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (learning_path_id) REFERENCES learning_paths(id)
  )`,

  `CREATE TABLE IF NOT EXISTS feature_selections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    learning_path_id INTEGER NOT NULL,
    selected_features TEXT NOT NULL,
    importance_scores TEXT,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (learning_path_id) REFERENCES learning_paths(id)
  )`,

  `CREATE TABLE IF NOT EXISTS optimization_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    learning_path_id INTEGER NOT NULL,
    iteration INTEGER NOT NULL,
    score REAL NOT NULL,
    config_snapshot TEXT,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (learning_path_id) REFERENCES learning_paths(id)
  )`,

  // Expert opinions tables
  `CREATE TABLE IF NOT EXISTS expert_opinions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    source_url TEXT NOT NULL,
    expert_name TEXT,
    opinion_text TEXT NOT NULL,
    sentiment_score REAL,
    sentiment_label TEXT,
    confidence REAL,
    scraped_at INTEGER NOT NULL
  )`,

  `CREATE TABLE IF NOT EXISTS social_sentiments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    platform TEXT NOT NULL,
    content TEXT NOT NULL,
    sentiment_score REAL,
    engagement_count INTEGER,
    collected_at INTEGER NOT NULL
  )`,

  `CREATE TABLE IF NOT EXISTS sentiment_trends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    date INTEGER NOT NULL,
    avg_sentiment REAL NOT NULL,
    total_mentions INTEGER NOT NULL,
    bullish_count INTEGER,
    bearish_count INTEGER,
    neutral_count INTEGER
  )`,

  `CREATE TABLE IF NOT EXISTS scraped_urls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL UNIQUE,
    symbol TEXT NOT NULL,
    last_scraped INTEGER NOT NULL,
    status TEXT NOT NULL,
    error_message TEXT
  )`,

  `CREATE TABLE IF NOT EXISTS sentiment_aggregations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    time_period TEXT NOT NULL,
    avg_expert_sentiment REAL,
    avg_social_sentiment REAL,
    combined_sentiment REAL,
    calculated_at INTEGER NOT NULL
  )`,
];

console.log(`📋 Creating ${createTableStatements.length} tables...\n`);

let created = 0;
let skipped = 0;

createTableStatements.forEach((sql, index) => {
  try {
    sqlite.exec(sql);
    const tableName = sql.match(/CREATE TABLE IF NOT EXISTS (\w+)/)?.[1];
    console.log(
      `✅ [${index + 1}/${createTableStatements.length}] ${tableName}`
    );
    created++;
  } catch (error: any) {
    console.log(
      `⏭️  [${index + 1}/${createTableStatements.length}] Skipped (already exists)`
    );
    skipped++;
  }
});

console.log("\n" + "=".repeat(50));
console.log("📊 Summary:");
console.log(`  ✅ Created: ${created} tables`);
console.log(`  ⏭️  Skipped: ${skipped} tables (already exist)`);
console.log("=".repeat(50));

sqlite.close();
console.log("\n✅ All tables created successfully!");
