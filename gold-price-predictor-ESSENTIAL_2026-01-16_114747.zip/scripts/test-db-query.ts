/**
 * FILE: scripts/test-db-query.ts
 * PURPOSE: Test database query for getUserByEmail
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🔍 Testing Database Query");
console.log("=".repeat(50));
console.log(`Database: ${dbPath}\n`);

const sqlite = new Database(dbPath);

// Test 1: Direct SQL query
console.log("1️⃣ Direct SQL Query:");
const email = "admin@gaaraholding.com";
const user1 = sqlite.prepare("SELECT * FROM users WHERE email = ?").get(email);
console.log("Result:", user1);

// Test 2: Using function (simulating db-sqlite.ts)
console.log("\n2️⃣ Using Function:");
function getUserByEmail(email: string) {
  return sqlite.prepare("SELECT * FROM users WHERE email = ?").get(email);
}
const user2 = getUserByEmail(email);
console.log("Result:", user2);

// Test 3: List all users
console.log("\n3️⃣ All Users:");
const allUsers = sqlite.prepare("SELECT id, email, role FROM users").all();
console.log("Total:", allUsers.length);
allUsers.forEach((u: any) => {
  console.log(`  - ${u.email || "NO EMAIL"} (${u.role})`);
});

sqlite.close();

console.log("\n" + "=".repeat(50));
console.log("✅ Test complete!");

