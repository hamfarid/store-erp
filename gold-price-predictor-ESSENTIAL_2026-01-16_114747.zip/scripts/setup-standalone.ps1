# Asset Predictor UI - Standalone Setup Script
# This version works WITHOUT Manus OAuth - uses local JWT authentication
# Run this script in PowerShell as Administrator or in VS Code Terminal

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Asset Predictor UI" -ForegroundColor Cyan
Write-Host "  Standalone Setup (No Manus OAuth)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Function to check if command exists
function Test-Command($command) {
    try {
        if (Get-Command $command -ErrorAction Stop) {
            return $true
        }
    } catch {
        return $false
    }
}

# Function to generate random string
function Get-RandomString($length) {
    return -join ((65..90) + (97..122) + (48..57) | Get-Random -Count $length | ForEach-Object {[char]$_})
}

# Check if running in VS Code Terminal
$inVSCode = $env:TERM_PROGRAM -eq "vscode"
if ($inVSCode) {
    Write-Host "✅ Running in VS Code Terminal" -ForegroundColor Green
} else {
    Write-Host "⚠️  Not running in VS Code Terminal" -ForegroundColor Yellow
    Write-Host "For best experience, open this project in VS Code and run from terminal" -ForegroundColor Yellow
}

# Step 1: Check Node.js
Write-Host "`n[1/7] Checking Node.js..." -ForegroundColor Cyan
if (-not (Test-Command node)) {
    Write-Host "❌ Node.js is not installed" -ForegroundColor Red
    Write-Host "Please install Node.js 22+ from: https://nodejs.org/" -ForegroundColor Yellow
    Write-Host "Then restart this script" -ForegroundColor Yellow
    pause
    exit
} else {
    $nodeVersion = node --version
    Write-Host "✅ Node.js installed: $nodeVersion" -ForegroundColor Green
}

# Step 2: Check/Install pnpm
Write-Host "`n[2/7] Checking pnpm..." -ForegroundColor Cyan
if (-not (Test-Command pnpm)) {
    Write-Host "Installing pnpm..." -ForegroundColor Yellow
    npm install -g pnpm
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ pnpm installed successfully!" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to install pnpm" -ForegroundColor Red
        pause
        exit
    }
} else {
    $pnpmVersion = pnpm --version
    Write-Host "✅ pnpm installed: $pnpmVersion" -ForegroundColor Green
}

# Step 3: Check MySQL
Write-Host "`n[3/7] Checking MySQL..." -ForegroundColor Cyan
if (-not (Test-Command mysql)) {
    Write-Host "⚠️  MySQL is not installed" -ForegroundColor Yellow
    Write-Host "Please install MySQL from: https://dev.mysql.com/downloads/installer/" -ForegroundColor Yellow
    Write-Host "Or you can use a cloud database (TiDB, PlanetScale, etc.)" -ForegroundColor Yellow
    $continueWithoutMySQL = Read-Host "Continue without MySQL? (Y/N)"
    if ($continueWithoutMySQL -ne "Y" -and $continueWithoutMySQL -ne "y") {
        exit
    }
} else {
    Write-Host "✅ MySQL installed" -ForegroundColor Green
}

# Step 4: Install Dependencies
Write-Host "`n[4/7] Installing project dependencies..." -ForegroundColor Cyan
pnpm install

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to install dependencies" -ForegroundColor Red
    pause
    exit
}

# Step 5: Interactive Configuration
Write-Host "`n[5/7] Configuring environment..." -ForegroundColor Cyan
Write-Host "Please provide the following information:" -ForegroundColor Yellow
Write-Host ""

# Database Configuration
Write-Host "--- Database Configuration ---" -ForegroundColor Cyan
$dbHost = Read-Host "MySQL Host (default: localhost)"
if ([string]::IsNullOrWhiteSpace($dbHost)) { $dbHost = "localhost" }

$dbPort = Read-Host "MySQL Port (default: 3306)"
if ([string]::IsNullOrWhiteSpace($dbPort)) { $dbPort = "3306" }

$dbName = Read-Host "Database Name (default: asset_predictor)"
if ([string]::IsNullOrWhiteSpace($dbName)) { $dbName = "asset_predictor" }

$dbUser = Read-Host "MySQL Username (default: root)"
if ([string]::IsNullOrWhiteSpace($dbUser)) { $dbUser = "root" }

$dbPass = Read-Host "MySQL Password (press Enter if empty)"

# JWT Configuration (Standalone)
Write-Host "`n--- Authentication Configuration ---" -ForegroundColor Cyan
Write-Host "This setup uses standalone JWT authentication (no OAuth)" -ForegroundColor Yellow
$jwtSecret = Get-RandomString 64
Write-Host "Generated JWT Secret: $jwtSecret" -ForegroundColor Green

# Admin User Configuration
Write-Host "`n--- Admin User Setup ---" -ForegroundColor Cyan
$adminUsername = Read-Host "Admin Username (default: admin)"
if ([string]::IsNullOrWhiteSpace($adminUsername)) { $adminUsername = "admin" }

$adminPassword = Read-Host "Admin Password" -AsSecureString
$adminPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($adminPassword))

$adminEmail = Read-Host "Admin Email"

# AI API Keys (Optional)
Write-Host "`n--- AI API Keys (Optional) ---" -ForegroundColor Cyan
Write-Host "Press Enter to skip if you don't have them yet" -ForegroundColor Yellow
$geminiKey = Read-Host "Gemini API Key (from https://ai.google.dev/)"
$anthropicKey = Read-Host "Anthropic API Key (from https://www.anthropic.com/)"

# App Information
Write-Host "`n--- App Information ---" -ForegroundColor Cyan
$appTitle = Read-Host "App Title (default: Asset Predictor)"
if ([string]::IsNullOrWhiteSpace($appTitle)) { $appTitle = "Asset Predictor" }

$appLogo = Read-Host "App Logo URL (default: /logo.svg)"
if ([string]::IsNullOrWhiteSpace($appLogo)) { $appLogo = "/logo.svg" }

# Step 6: Create .env file
Write-Host "`n[6/7] Creating .env file..." -ForegroundColor Cyan

$envContent = @"
# Database Configuration
DATABASE_URL=mysql://${dbUser}:${dbPass}@${dbHost}:${dbPort}/${dbName}

# JWT Configuration (Standalone - No OAuth)
JWT_SECRET=$jwtSecret

# Admin User (for initial login)
APP_USERNAME=$adminUsername
APP_PASSWORD=$adminPasswordPlain

# AI API Keys (Optional)
GEMINI_API_KEY=$geminiKey
ANTHROPIC_API_KEY=$anthropicKey

# App Information
VITE_APP_TITLE=$appTitle
VITE_APP_LOGO=$appLogo

# Standalone Mode (No OAuth)
STANDALONE_MODE=true

# Optional: If you want to enable Manus OAuth later, add these:
# VITE_APP_ID=
# OAUTH_SERVER_URL=https://api.manus.im
# VITE_OAUTH_PORTAL_URL=https://portal.manus.im
# OWNER_OPEN_ID=
# OWNER_NAME=
# BUILT_IN_FORGE_API_URL=
# BUILT_IN_FORGE_API_KEY=

# Analytics (Optional)
VITE_ANALYTICS_ENDPOINT=
VITE_ANALYTICS_WEBSITE_ID=
"@

$envPath = ".env"
$envContent | Out-File -FilePath $envPath -Encoding UTF8
Write-Host "✅ .env file created successfully!" -ForegroundColor Green

# Step 7: Create Database
Write-Host "`n[7/7] Setting up database..." -ForegroundColor Cyan

if (Test-Command mysql) {
    $createDb = Read-Host "Do you want to create the database now? (Y/N)"
    if ($createDb -eq "Y" -or $createDb -eq "y") {
        $createDbSql = "CREATE DATABASE IF NOT EXISTS $dbName CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
        
        try {
            if ([string]::IsNullOrWhiteSpace($dbPass)) {
                $mysqlCmd = "mysql -h $dbHost -P $dbPort -u $dbUser -e `"$createDbSql`""
            } else {
                $mysqlCmd = "mysql -h $dbHost -P $dbPort -u $dbUser -p$dbPass -e `"$createDbSql`""
            }
            
            Invoke-Expression $mysqlCmd
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✅ Database created successfully!" -ForegroundColor Green
                
                # Create admin user in database
                Write-Host "Creating admin user..." -ForegroundColor Yellow
                $adminId = Get-RandomString 16
                $insertAdminSql = "INSERT INTO users (id, name, email, role) VALUES ('$adminId', '$adminUsername', '$adminEmail', 'admin') ON DUPLICATE KEY UPDATE email='$adminEmail';"
                
                if ([string]::IsNullOrWhiteSpace($dbPass)) {
                    $mysqlCmd = "mysql -h $dbHost -P $dbPort -u $dbUser $dbName -e `"$insertAdminSql`""
                } else {
                    $mysqlCmd = "mysql -h $dbHost -P $dbPort -u $dbUser -p$dbPass $dbName -e `"$insertAdminSql`""
                }
                
                Invoke-Expression $mysqlCmd
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "✅ Admin user created!" -ForegroundColor Green
                }
            } else {
                Write-Host "⚠️  Failed to create database. You can create it manually later." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "⚠️  Error: $_" -ForegroundColor Yellow
            Write-Host "You can create the database manually using MySQL Workbench" -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "⚠️  MySQL not found. Please create database manually:" -ForegroundColor Yellow
    Write-Host "   CREATE DATABASE $dbName CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" -ForegroundColor Gray
}

# Final Summary
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete! 🎉" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Configuration Summary:" -ForegroundColor Yellow
Write-Host "  Mode: Standalone (No OAuth)" -ForegroundColor White
Write-Host "  Database: $dbName @ $dbHost:$dbPort" -ForegroundColor White
Write-Host "  Admin User: $adminUsername" -ForegroundColor White
Write-Host "  Admin Email: $adminEmail" -ForegroundColor White
Write-Host "  App Title: $appTitle" -ForegroundColor White
Write-Host ""
Write-Host "Login Credentials:" -ForegroundColor Cyan
Write-Host "  Username: $adminUsername" -ForegroundColor White
Write-Host "  Password: $adminPasswordPlain" -ForegroundColor White
Write-Host "  (Save these credentials!)" -ForegroundColor Yellow
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Setup database tables (if not done automatically):" -ForegroundColor White
Write-Host "     mysql -u $dbUser $(if($dbPass){"-p$dbPass"}) $dbName < setup-database.sql" -ForegroundColor Gray
Write-Host ""
Write-Host "  2. Start development server:" -ForegroundColor White
Write-Host "     pnpm dev" -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Open in browser:" -ForegroundColor White
Write-Host "     http://localhost:3000" -ForegroundColor Gray
Write-Host ""
Write-Host "  4. Login with your admin credentials" -ForegroundColor White
Write-Host ""
Write-Host "Documentation:" -ForegroundColor Cyan
Write-Host "  - README.md - Project overview" -ForegroundColor White
Write-Host "  - VSCODE_GUIDE.md - Development guide" -ForegroundColor White
Write-Host "  - DEPENDENCIES.md - All libraries" -ForegroundColor White
Write-Host ""

# Ask to start dev server
$startDev = Read-Host "Start development server now? (Y/N)"
if ($startDev -eq "Y" -or $startDev -eq "y") {
    Write-Host "`nStarting development server..." -ForegroundColor Yellow
    Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Gray
    Write-Host "Open http://localhost:3000 in your browser" -ForegroundColor Gray
    Write-Host ""
    pnpm dev
} else {
    Write-Host "`nTo start the server later, run: pnpm dev" -ForegroundColor Yellow
}

Write-Host "`nThank you for using Asset Predictor UI! 🚀" -ForegroundColor Cyan

