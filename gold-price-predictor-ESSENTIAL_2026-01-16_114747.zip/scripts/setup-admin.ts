/**
 * Admin User Setup Script
 * Creates the initial admin user in the database
 * 
 * Usage: npx tsx scripts/setup-admin.ts
 */

import Database from 'better-sqlite3';
import * as bcrypt from 'bcryptjs';
import { join } from 'path';
import { randomUUID } from 'crypto';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@goldpredictor.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@123456';
const ADMIN_NAME = process.env.ADMIN_NAME || 'System Administrator';

async function setupAdmin() {
  console.log('🔧 Setting up admin user...\n');

  // Connect to database
  const dbPath = join(process.cwd(), 'data', 'asset_predictor.db');
  console.log(`📂 Database path: ${dbPath}`);

  const db = new Database(dbPath);
  db.pragma('foreign_keys = ON');

  // Create users table if not exists
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      passwordHash TEXT,
      loginMethod TEXT DEFAULT 'local',
      role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      lastSignedIn INTEGER,
      updatedAt INTEGER
    )
  `);

  // Create user_permissions table if not exists
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      permission TEXT NOT NULL,
      resource TEXT,
      action TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Check if admin exists
  const existingAdmin = db.prepare('SELECT * FROM users WHERE email = ?').get(ADMIN_EMAIL) as any;

  if (existingAdmin) {
    console.log(`✅ Admin user already exists: ${ADMIN_EMAIL}`);
    console.log(`   Role: ${existingAdmin.role}`);
    
    // Hash password
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 12);
    
    // Update role and password
    db.prepare('UPDATE users SET role = ?, passwordHash = ? WHERE email = ?')
      .run('admin', passwordHash, ADMIN_EMAIL);
    
    console.log('   ✨ Updated role to admin');
    console.log('   ✨ Updated password');
  } else {
    // Hash password
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 12);
    const userId = randomUUID();

    // Create admin user
    db.prepare(`
      INSERT INTO users (id, name, email, passwordHash, loginMethod, role, createdAt, lastSignedIn)
      VALUES (?, ?, ?, ?, 'local', 'admin', ?, ?)
    `).run(userId, ADMIN_NAME, ADMIN_EMAIL, passwordHash, Date.now(), Date.now());

    console.log(`✅ Admin user created successfully!`);
    console.log(`   ID: ${userId}`);
    console.log(`   Name: ${ADMIN_NAME}`);
    console.log(`   Email: ${ADMIN_EMAIL}`);
    console.log(`   Role: admin`);

    // Add default admin permissions
    const permissions = [
      { permission: 'admin:full', resource: '*', action: '*' },
      { permission: 'users:manage', resource: 'users', action: 'manage' },
      { permission: 'assets:manage', resource: 'assets', action: 'manage' },
      { permission: 'predictions:manage', resource: 'predictions', action: 'manage' },
      { permission: 'reports:view', resource: 'reports', action: 'view' },
      { permission: 'backup:create', resource: 'backup', action: 'create' },
      { permission: 'backup:restore', resource: 'backup', action: 'restore' },
    ];

    const insertPermission = db.prepare(`
      INSERT INTO user_permissions (userId, permission, resource, action, createdAt)
      VALUES (?, ?, ?, ?, ?)
    `);

    for (const perm of permissions) {
      insertPermission.run(userId, perm.permission, perm.resource, perm.action, Date.now());
    }

    console.log(`   ✨ Added ${permissions.length} default permissions`);
  }

  // Display login credentials
  console.log('\n' + '='.repeat(50));
  console.log('📋 Admin Login Credentials:');
  console.log('='.repeat(50));
  console.log(`   Email: ${ADMIN_EMAIL}`);
  console.log(`   Password: ${ADMIN_PASSWORD}`);
  console.log('='.repeat(50));
  console.log('\n⚠️  Remember to change the password in production!\n');

  db.close();
}

// Run setup
setupAdmin().catch(console.error);

