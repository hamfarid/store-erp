# Simple log checker
$ErrorActionPreference = "Continue"

Write-Host "`n🔍 فحص سجلات الحاويات..." -ForegroundColor Cyan
Write-Host ""

# Backend
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
Write-Host "BACKEND LOGS (آخر 50 سطر)" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
try {
    docker logs gold-predictor-backend --tail 50 2>&1
} catch {
    Write-Host "خطأ في قراءة سجلات Backend: $_" -ForegroundColor Red
}
Write-Host ""

# ML Service
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
Write-Host "ML SERVICE LOGS (آخر 50 سطر)" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
try {
    docker logs gold-predictor-ml --tail 50 2>&1
} catch {
    Write-Host "خطأ في قراءة سجلات ML Service: $_" -ForegroundColor Red
}
Write-Host ""

# Prometheus
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
Write-Host "PROMETHEUS LOGS (آخر 30 سطر)" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Yellow
try {
    docker logs gold-predictor-prometheus --tail 30 2>&1
} catch {
    Write-Host "خطأ في قراءة سجلات Prometheus: $_" -ForegroundColor Red
}
Write-Host ""

Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "حالة الحاويات:" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
docker ps -a --filter "name=gold-predictor" --format "table {{.Names}}\t{{.Status}}"
Write-Host ""

