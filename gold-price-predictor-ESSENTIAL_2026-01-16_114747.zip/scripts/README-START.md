# 🚀 Quick Start Guide

## Complete Initialization & Start

This guide will help you initialize and start all services (Database, Backend, Frontend, Containers) with a single command.

### Windows (PowerShell)

```powershell
# Full setup (all services)
.\scripts\init-and-start.ps1

# Skip frontend (only containers)
.\scripts\init-and-start.ps1 -SkipFrontend

# Production mode
.\scripts\init-and-start.ps1 -Production
```

### Linux/Mac (Bash)

```bash
# Make script executable (first time only)
chmod +x scripts/init-and-start.sh

# Full setup (all services)
./scripts/init-and-start.sh

# Skip frontend (only containers)
./scripts/init-and-start.sh --skip-frontend

# Production mode
./scripts/init-and-start.sh --production
```

## What the Script Does

1. ✅ **Checks Docker** - Verifies Docker is running
2. ✅ **Creates .env** - Copies `env.example` to `.env` if needed
3. ✅ **Builds Images** - Builds Docker images if needed
4. ✅ **Starts Containers** - Starts all Docker services:
   - PostgreSQL (Database)
   - Redis (Cache)
   - Backend (FastAPI)
   - Prometheus (Monitoring)
   - Grafana (Dashboards)
5. ✅ **Waits for Services** - Ensures services are ready
6. ✅ **Initializes Database** - Runs Alembic migrations
7. ✅ **Starts Frontend** - Launches Vite dev server

## Service URLs

After running the script, access:

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:2005
- **API Docs**: http://localhost:2005/docs
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:2505

## Manual Steps (Alternative)

If you prefer to start services manually:

### 1. Start Docker Containers

```bash
# Windows
docker compose up -d

# Linux/Mac
docker-compose up -d
```

### 2. Initialize Database

```bash
# Wait for PostgreSQL to be ready (about 10-15 seconds)
docker exec -it gold-predictor-backend alembic upgrade head
```

### 3. Start Frontend

```bash
npm install  # First time only
npm run dev
```

### 4. Start Backend (if running locally)

```bash
cd backend
python -m uvicorn app.main:app --reload --port 2005
```

## Troubleshooting

### Docker not running
- **Windows**: Start Docker Desktop
- **Linux**: `sudo systemctl start docker`

### Port already in use
- Check what's using the port: `netstat -ano | findstr :2005` (Windows)
- Stop the conflicting service or change port in `.env`

### Database connection errors
- Wait a bit longer (PostgreSQL needs time to start)
- Check logs: `docker compose logs postgres`

### Frontend not starting
- Make sure `node_modules` exists: `npm install`
- Check if port 5173 is available

## Stop All Services

```powershell
# Windows
.\scripts\stop.ps1

# Linux/Mac
./scripts/stop.sh
```

Or manually:
```bash
docker compose down
```

## View Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f backend
docker compose logs -f postgres
```

## Reset Everything

⚠️ **WARNING**: This will delete all data!

```bash
docker compose down -v
./scripts/init-and-start.sh
```

