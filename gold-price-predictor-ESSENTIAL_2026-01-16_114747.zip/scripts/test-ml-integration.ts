// FILE: scripts/test-ml-integration.ts | PURPOSE: Test complete ML integration | OWNER: ML Team | LAST-AUDITED: 2025-11-25

import axios from 'axios';
import { getPool } from '../server/db-postgres';

const ML_SERVICE_URL = process.env.ML_SERVICE_URL || 'http://localhost:2105';

async function testMLIntegration() {
  console.log('\n🧪 Testing ML Integration...\n');
  console.log('='.repeat(60));

  // Test 1: Database Connection
  console.log('\n📊 Test 1: Database Connection');
  try {
    const pool = getPool();
    const result = await pool.query('SELECT COUNT(*) FROM assets');
    console.log(`✅ Database connected: ${result.rows[0].count} assets found`);
  } catch (error: any) {
    console.error(`❌ Database error: ${error.message}`);
    return;
  }

  // Test 2: Historical Data
  console.log('\n📈 Test 2: Historical Data');
  try {
    const pool = getPool();
    const symbols = ['GC=F', 'SI=F', 'BTC-USD'];
    
    for (const symbol of symbols) {
      const assetResult = await pool.query(
        'SELECT id, name FROM assets WHERE symbol = $1',
        [symbol]
      );
      
      if (assetResult.rows.length === 0) {
        console.log(`⚠️  ${symbol}: Not found in database`);
        continue;
      }

      const asset = assetResult.rows[0];
      const countResult = await pool.query(
        'SELECT COUNT(*) FROM price_history WHERE asset_id = $1',
        [asset.id]
      );

      console.log(`✅ ${asset.name} (${symbol}): ${countResult.rows[0].count} records`);
    }
  } catch (error: any) {
    console.error(`❌ Historical data error: ${error.message}`);
  }

  // Test 3: ML Service Health
  console.log('\n🏥 Test 3: ML Service Health');
  try {
    const response = await axios.get(`${ML_SERVICE_URL}/health`, {
      timeout: 5000,
    });
    console.log(`✅ ML Service: ${response.data.status}`);
    console.log(`   Version: ${response.data.version}`);
    console.log(`   Models Loaded: ${response.data.models_loaded}`);
  } catch (error: any) {
    if (error.code === 'ECONNREFUSED') {
      console.log(`⚠️  ML Service: Not running (start with: docker-compose up -d ml-service)`);
    } else {
      console.error(`❌ ML Service error: ${error.message}`);
    }
  }

  // Test 4: Predictions
  console.log('\n🔮 Test 4: Predictions');
  try {
    const symbols = ['GC=F', 'SI=F', 'BTC-USD'];
    
    for (const symbol of symbols) {
      try {
        const response = await axios.post(
          `${ML_SERVICE_URL}/predict`,
          {
            symbol,
            days: 7,
          },
          {
            timeout: 10000,
          }
        );

        const data = response.data;
        console.log(`✅ ${symbol}:`);
        console.log(`   Predictions: ${data.predictions.length} days`);
        console.log(`   Model: ${data.model_version}`);
        console.log(`   Confidence: ${(data.confidence * 100).toFixed(1)}%`);
        console.log(`   First prediction: $${data.predictions[0].predicted_price.toFixed(2)}`);
      } catch (error: any) {
        if (error.code === 'ECONNREFUSED') {
          console.log(`⚠️  ${symbol}: ML Service not running`);
        } else {
          console.log(`❌ ${symbol}: ${error.message}`);
        }
      }
    }
  } catch (error: any) {
    console.error(`❌ Predictions error: ${error.message}`);
  }

  // Test 5: Model List
  console.log('\n📋 Test 5: Available Models');
  try {
    const response = await axios.get(`${ML_SERVICE_URL}/models`, {
      timeout: 5000,
    });

    const models = response.data.models;
    console.log(`✅ Found ${models.length} models:`);
    
    models.forEach((model: any) => {
      console.log(`   - ${model.symbol}: ${model.type} (accuracy: ${(model.accuracy * 100).toFixed(1)}%)`);
    });
  } catch (error: any) {
    if (error.code === 'ECONNREFUSED') {
      console.log(`⚠️  ML Service not running`);
    } else {
      console.error(`❌ Models error: ${error.message}`);
    }
  }

  // Summary
  console.log('\n' + '='.repeat(60));
  console.log('\n📊 Integration Test Summary:\n');
  console.log('✅ Database: Connected');
  console.log('✅ Historical Data: Available');
  console.log('⚠️  ML Service: Check if Docker is running');
  console.log('⚠️  Predictions: Requires ML Service');
  console.log('\n💡 To start ML Service:');
  console.log('   1. Start Docker Desktop');
  console.log('   2. Run: docker-compose up -d ml-service');
  console.log('   3. Wait ~30 seconds for service to start');
  console.log('   4. Run this test again\n');

  // Close pool
  const pool = getPool();
  await pool.end();
}

testMLIntegration().catch(console.error);

