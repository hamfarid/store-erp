# ============================================
# Production Startup Script
# Starts all services for production
# ============================================

Write-Host ""
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🚀 Starting Gold Price Predictor - Production Mode" -ForegroundColor Green
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Check if .env exists
if (-not (Test-Path ".env")) {
    Write-Host "❌ Error: .env file not found!" -ForegroundColor Red
    Write-Host "   Please copy env.example to .env and configure it." -ForegroundColor Yellow
    exit 1
}

# Check if DATABASE_URL_POSTGRES is set
$envContent = Get-Content ".env" -Raw
if ($envContent -notmatch "DATABASE_URL_POSTGRES") {
    Write-Host "⚠️  Warning: DATABASE_URL_POSTGRES not found in .env" -ForegroundColor Yellow
    Write-Host "   Make sure PostgreSQL connection string is configured." -ForegroundColor Yellow
    Write-Host ""
}

# Step 1: Stop existing containers
Write-Host "1️⃣  Stopping existing containers..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml down 2>$null
Write-Host "   ✅ Done" -ForegroundColor Green
Write-Host ""

# Step 2: Remove old containers and volumes (optional)
$removeOld = Read-Host "   Remove old containers and volumes? (y/N)"
if ($removeOld -eq "y" -or $removeOld -eq "Y") {
    Write-Host "   🗑️  Removing old containers and volumes..." -ForegroundColor Yellow
    docker-compose -f docker-compose.production.yml down -v 2>$null
    Write-Host "   ✅ Done" -ForegroundColor Green
    Write-Host ""
}

# Step 3: Initialize PostgreSQL database
Write-Host "2️⃣  Initializing PostgreSQL database..." -ForegroundColor Yellow
try {
    npx tsx scripts/setup-postgres.ts
    Write-Host "   ✅ Database initialized" -ForegroundColor Green
} catch {
    Write-Host "   ⚠️  Database initialization failed or already exists" -ForegroundColor Yellow
}
Write-Host ""

# Step 4: Build Docker images
Write-Host "3️⃣  Building Docker images..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml build
if ($LASTEXITCODE -ne 0) {
    Write-Host "   ❌ Build failed!" -ForegroundColor Red
    exit 1
}
Write-Host "   ✅ Build completed" -ForegroundColor Green
Write-Host ""

# Step 5: Start containers
Write-Host "4️⃣  Starting containers..." -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml up -d
if ($LASTEXITCODE -ne 0) {
    Write-Host "   ❌ Failed to start containers!" -ForegroundColor Red
    exit 1
}
Write-Host "   ✅ Containers started" -ForegroundColor Green
Write-Host ""

# Step 6: Wait for services to be ready
Write-Host "5️⃣  Waiting for services to be ready..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Check PostgreSQL
$maxRetries = 30
$retryCount = 0
$postgresReady = $false

while ($retryCount -lt $maxRetries -and -not $postgresReady) {
    try {
        $result = docker exec gold-predictor-postgres pg_isready -U postgres 2>$null
        if ($LASTEXITCODE -eq 0) {
            $postgresReady = $true
            Write-Host "   ✅ PostgreSQL is ready" -ForegroundColor Green
        }
    } catch {
        # Continue waiting
    }
    
    if (-not $postgresReady) {
        $retryCount++
        Write-Host "   ⏳ Waiting for PostgreSQL... ($retryCount/$maxRetries)" -ForegroundColor Yellow
        Start-Sleep -Seconds 2
    }
}

if (-not $postgresReady) {
    Write-Host "   ⚠️  PostgreSQL may not be ready yet" -ForegroundColor Yellow
}

Write-Host ""

# Step 7: Show container status
Write-Host "6️⃣  Container Status:" -ForegroundColor Yellow
docker-compose -f docker-compose.production.yml ps
Write-Host ""

# Step 8: Show service URLs
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  ✅ Production Services Started!" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "📋 Service URLs:" -ForegroundColor Yellow
Write-Host "   Frontend:     http://localhost:2505" -ForegroundColor White
Write-Host "   Backend API:  http://localhost:2505/api" -ForegroundColor White
Write-Host "   ML Service:   http://localhost:2105" -ForegroundColor White
Write-Host "   Grafana:      http://localhost:3001" -ForegroundColor White
Write-Host "   Prometheus:   http://localhost:9090" -ForegroundColor White
Write-Host "   Portainer:    http://localhost:9000" -ForegroundColor White
Write-Host ""
Write-Host "📊 Database:" -ForegroundColor Yellow
Write-Host "   PostgreSQL:   localhost:5432" -ForegroundColor White
Write-Host "   Redis:        localhost:6379" -ForegroundColor White
Write-Host ""
Write-Host "🔧 Useful Commands:" -ForegroundColor Yellow
Write-Host "   View logs:    docker-compose -f docker-compose.production.yml logs -f" -ForegroundColor White
Write-Host "   Stop all:     docker-compose -f docker-compose.production.yml down" -ForegroundColor White
Write-Host "   Restart:      docker-compose -f docker-compose.production.yml restart" -ForegroundColor White
Write-Host ""
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""

