/**
 * Database Setup Script
 * Creates all necessary tables and indexes
 * 
 * Usage: npx tsx scripts/setup-database.ts
 */

import Database from 'better-sqlite3';
import { join } from 'path';
import { mkdirSync, existsSync } from 'fs';

function setupDatabase() {
  console.log('🔧 Setting up database...\n');

  // Ensure data directory exists
  const dataDir = join(process.cwd(), 'data');
  if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true });
    console.log('📂 Created data directory');
  }

  // Connect to database
  const dbPath = join(dataDir, 'asset_predictor.db');
  console.log(`📂 Database path: ${dbPath}`);

  const db = new Database(dbPath);
  db.pragma('foreign_keys = ON');

  // Create tables
  console.log('\n📋 Creating tables...');

  // Users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      passwordHash TEXT,
      loginMethod TEXT DEFAULT 'local',
      role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      lastSignedIn INTEGER,
      updatedAt INTEGER
    )
  `);
  console.log('  ✅ users');

  // User permissions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      permission TEXT NOT NULL,
      resource TEXT,
      action TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ user_permissions');

  // User settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_settings (
      userId TEXT PRIMARY KEY,
      emailEnabled INTEGER DEFAULT 0,
      notifyPriceChanges INTEGER DEFAULT 1,
      notifyAlerts INTEGER DEFAULT 1,
      notifyPredictions INTEGER DEFAULT 1,
      notifyReports INTEGER DEFAULT 0,
      language TEXT DEFAULT 'ar',
      theme TEXT DEFAULT 'light',
      currency TEXT DEFAULT 'USD',
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ user_settings');

  // Assets table
  db.exec(`
    CREATE TABLE IF NOT EXISTS assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      assetType TEXT DEFAULT 'commodity',
      exchange TEXT,
      currency TEXT DEFAULT 'USD',
      currentPrice TEXT,
      sector TEXT,
      description TEXT,
      yahooSymbol TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER
    )
  `);
  console.log('  ✅ assets');

  // Historical prices table
  db.exec(`
    CREATE TABLE IF NOT EXISTS historical_prices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      date TEXT NOT NULL,
      price TEXT NOT NULL,
      high TEXT,
      low TEXT,
      open TEXT,
      volume TEXT,
      change TEXT DEFAULT '0.00',
      changePercent TEXT DEFAULT '0.00',
      timestamp INTEGER NOT NULL,
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ historical_prices');

  // Predictions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS predictions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      userId TEXT,
      modelType TEXT DEFAULT 'simple',
      horizon TEXT DEFAULT 'short',
      predictedPrice TEXT NOT NULL,
      confidenceLevel TEXT DEFAULT '0.95',
      predictionDate INTEGER NOT NULL,
      accuracy TEXT,
      metadata TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
    )
  `);
  console.log('  ✅ predictions');

  // Alerts table
  db.exec(`
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      assetId INTEGER NOT NULL,
      alertType TEXT DEFAULT 'price',
      condition TEXT NOT NULL,
      threshold TEXT NOT NULL,
      isActive INTEGER DEFAULT 1,
      isTriggered INTEGER DEFAULT 0,
      triggeredAt INTEGER,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ alerts');

  // Portfolios table
  db.exec(`
    CREATE TABLE IF NOT EXISTS portfolios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      totalValue TEXT DEFAULT '0.00',
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ portfolios');

  // Transactions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      portfolioId INTEGER NOT NULL,
      assetId INTEGER NOT NULL,
      transactionType TEXT NOT NULL CHECK(transactionType IN ('buy', 'sell')),
      quantity TEXT NOT NULL,
      price TEXT NOT NULL,
      totalAmount TEXT NOT NULL,
      fees TEXT DEFAULT '0.00',
      transactionDate INTEGER NOT NULL,
      notes TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (portfolioId) REFERENCES portfolios(id) ON DELETE CASCADE,
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ transactions');

  // System logs table
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      level TEXT DEFAULT 'info',
      message TEXT NOT NULL,
      source TEXT,
      metadata TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ system_logs');

  // System config table
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updatedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ system_config');

  // Saved reports table
  db.exec(`
    CREATE TABLE IF NOT EXISTS saved_reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      reportType TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      data TEXT NOT NULL,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ saved_reports');

  // Notifications table
  db.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT DEFAULT 'info',
      isRead INTEGER DEFAULT 0,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ notifications');

  // AI conversations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      assistantType TEXT DEFAULT 'general',
      messages TEXT NOT NULL,
      tokensUsed INTEGER DEFAULT 0,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ ai_conversations');

  // AI memories table (for RAG)
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      type TEXT DEFAULT 'fact',
      content TEXT NOT NULL,
      keywords TEXT,
      relevanceScore REAL DEFAULT 1.0,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ ai_memories');

  // Expert opinions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS expert_opinions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER,
      expertName TEXT NOT NULL,
      opinion TEXT NOT NULL,
      sentiment TEXT CHECK(sentiment IN ('bullish', 'bearish', 'neutral')),
      confidenceLevel REAL DEFAULT 0.5,
      sourceUrl TEXT,
      publishedAt INTEGER,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE SET NULL
    )
  `);
  console.log('  ✅ expert_opinions');

  // Drift detections table
  db.exec(`
    CREATE TABLE IF NOT EXISTS drift_detections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      modelType TEXT NOT NULL,
      driftType TEXT NOT NULL,
      severity TEXT CHECK(severity IN ('low', 'medium', 'high', 'critical')),
      details TEXT,
      detectedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      resolvedAt INTEGER,
      isResolved INTEGER DEFAULT 0
    )
  `);
  console.log('  ✅ drift_detections');

  // Learning paths table
  db.exec(`
    CREATE TABLE IF NOT EXISTS learning_paths (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      pathName TEXT NOT NULL,
      description TEXT,
      modules TEXT,
      progress REAL DEFAULT 0,
      status TEXT DEFAULT 'active',
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ learning_paths');

  // Trading signals table
  db.exec(`
    CREATE TABLE IF NOT EXISTS trading_signals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      signalType TEXT NOT NULL CHECK(signalType IN ('buy', 'sell', 'hold')),
      strength TEXT CHECK(strength IN ('weak', 'moderate', 'strong')),
      price REAL NOT NULL,
      targetPrice REAL,
      stopLoss REAL,
      confidence REAL DEFAULT 0.5,
      validUntil INTEGER,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ trading_signals');

  // Technical indicators table
  db.exec(`
    CREATE TABLE IF NOT EXISTS technical_indicators (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      indicatorType TEXT NOT NULL,
      value REAL NOT NULL,
      period INTEGER,
      calculatedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ technical_indicators');

  // Model performance table
  db.exec(`
    CREATE TABLE IF NOT EXISTS model_performance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      modelType TEXT NOT NULL,
      accuracy REAL,
      mae REAL,
      rmse REAL,
      mape REAL,
      evaluatedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ model_performance');

  // Security events table (for session hijacking protection)
  db.exec(`
    CREATE TABLE IF NOT EXISTS security_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      eventType TEXT NOT NULL,
      userId TEXT,
      ipAddress TEXT,
      userAgent TEXT,
      details TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ security_events');

  // Breakout points table
  db.exec(`
    CREATE TABLE IF NOT EXISTS breakout_points (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('support', 'resistance')),
      price REAL NOT NULL,
      direction TEXT CHECK(direction IN ('up', 'down')),
      strength REAL DEFAULT 0.5,
      breached INTEGER DEFAULT 0,
      breachedAt INTEGER,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ breakout_points');

  // Inflection points table
  db.exec(`
    CREATE TABLE IF NOT EXISTS inflection_points (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assetId INTEGER NOT NULL,
      pointType TEXT NOT NULL CHECK(pointType IN ('peak', 'trough', 'reversal_up', 'reversal_down')),
      price REAL NOT NULL,
      confidence REAL DEFAULT 0.5,
      significance REAL DEFAULT 0.5,
      detectedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ inflection_points');

  // Break-even points table
  db.exec(`
    CREATE TABLE IF NOT EXISTS break_even_points (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      assetId INTEGER NOT NULL,
      buyPrice REAL NOT NULL,
      quantity REAL NOT NULL,
      fees REAL DEFAULT 0,
      breakEvenPrice REAL NOT NULL,
      currentPrice REAL,
      profitLoss REAL,
      profitLossPercent REAL,
      purchaseDate INTEGER,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (assetId) REFERENCES assets(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ break_even_points');

  // AI scheduled tasks table
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_scheduled_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('prediction', 'analysis', 'report', 'alert_check', 'data_sync', 'cleanup')),
      schedule TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      lastRun INTEGER,
      nextRun INTEGER,
      config TEXT,
      createdBy TEXT,
      createdAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updatedAt INTEGER,
      FOREIGN KEY (createdBy) REFERENCES users(id) ON DELETE SET NULL
    )
  `);
  console.log('  ✅ ai_scheduled_tasks');

  // AI task results table
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_task_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      taskId INTEGER NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('success', 'failed', 'running', 'cancelled')),
      result TEXT,
      error TEXT,
      duration INTEGER,
      executedAt INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (taskId) REFERENCES ai_scheduled_tasks(id) ON DELETE CASCADE
    )
  `);
  console.log('  ✅ ai_task_results');

  // ==================== Learning Control Tables ====================
  console.log('\n📋 Creating Learning Control tables...');

  // Search Keywords table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_keywords (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      keyword TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL CHECK(category IN ('political', 'economic', 'geopolitical', 'monetary_policy', 'market', 'commodity', 'general')),
      priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high', 'critical')),
      enabled INTEGER DEFAULT 1,
      search_count INTEGER DEFAULT 0,
      last_used INTEGER,
      results_found INTEGER DEFAULT 0,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_keywords');

  // Search Sources table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_sources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('search_engine', 'news_site', 'financial_site', 'government_site', 'social_media', 'api')),
      url TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      headers TEXT,
      rate_limit INTEGER DEFAULT 60,
      request_count INTEGER DEFAULT 0,
      success_count INTEGER DEFAULT 0,
      error_count INTEGER DEFAULT 0,
      last_used INTEGER,
      last_error TEXT,
      avg_response_time INTEGER,
      reliability INTEGER DEFAULT 100,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_sources');

  // Learning Operations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS learning_operations (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN ('prediction_comparison', 'pattern_detection', 'correlation_analysis', 'model_training', 'insight_generation', 'adjustment_application')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
      progress INTEGER DEFAULT 0,
      current_step TEXT,
      total_steps INTEGER,
      input TEXT,
      output TEXT,
      error TEXT,
      started_at INTEGER,
      completed_at INTEGER,
      duration INTEGER,
      results_count INTEGER DEFAULT 0,
      insights_generated INTEGER DEFAULT 0,
      adjustments_proposed INTEGER DEFAULT 0,
      triggered_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ learning_operations');

  // Search Operations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS search_operations (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN ('keyword_search', 'event_discovery', 'news_scraping', 'sentiment_analysis', 'entity_extraction')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
      keywords TEXT NOT NULL,
      sources TEXT NOT NULL,
      date_range TEXT,
      progress INTEGER DEFAULT 0,
      current_source TEXT,
      sources_processed INTEGER DEFAULT 0,
      total_sources INTEGER,
      results_found INTEGER DEFAULT 0,
      events_created INTEGER DEFAULT 0,
      error TEXT,
      started_at INTEGER,
      completed_at INTEGER,
      duration INTEGER,
      triggered_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ search_operations');

  // Operation Logs table
  db.exec(`
    CREATE TABLE IF NOT EXISTS operation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      operation_id TEXT NOT NULL,
      operation_type TEXT NOT NULL CHECK(operation_type IN ('learning', 'search')),
      level TEXT NOT NULL CHECK(level IN ('debug', 'info', 'warning', 'error')),
      message TEXT NOT NULL,
      data TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    )
  `);
  console.log('  ✅ operation_logs');

  // Create indexes
  console.log('\n📋 Creating indexes...');

  db.exec('CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)');
  console.log('  ✅ idx_users_email');

  db.exec('CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)');
  console.log('  ✅ idx_users_role');

  db.exec('CREATE INDEX IF NOT EXISTS idx_historical_prices_asset ON historical_prices(assetId)');
  console.log('  ✅ idx_historical_prices_asset');

  db.exec('CREATE INDEX IF NOT EXISTS idx_historical_prices_date ON historical_prices(date)');
  console.log('  ✅ idx_historical_prices_date');

  db.exec('CREATE INDEX IF NOT EXISTS idx_predictions_asset ON predictions(assetId)');
  console.log('  ✅ idx_predictions_asset');

  db.exec('CREATE INDEX IF NOT EXISTS idx_predictions_user ON predictions(userId)');
  console.log('  ✅ idx_predictions_user');

  db.exec('CREATE INDEX IF NOT EXISTS idx_alerts_user ON alerts(userId)');
  console.log('  ✅ idx_alerts_user');

  db.exec('CREATE INDEX IF NOT EXISTS idx_alerts_asset ON alerts(assetId)');
  console.log('  ✅ idx_alerts_asset');

  db.exec('CREATE INDEX IF NOT EXISTS idx_transactions_portfolio ON transactions(portfolioId)');
  console.log('  ✅ idx_transactions_portfolio');

  db.exec('CREATE INDEX IF NOT EXISTS idx_system_logs_timestamp ON system_logs(timestamp)');
  console.log('  ✅ idx_system_logs_timestamp');

  db.exec('CREATE INDEX IF NOT EXISTS idx_security_events_timestamp ON security_events(timestamp)');
  console.log('  ✅ idx_security_events_timestamp');

  db.exec('CREATE INDEX IF NOT EXISTS idx_security_events_user ON security_events(userId)');
  console.log('  ✅ idx_security_events_user');

  db.exec('CREATE INDEX IF NOT EXISTS idx_security_events_type ON security_events(eventType)');
  console.log('  ✅ idx_security_events_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_breakout_points_asset ON breakout_points(assetId)');
  console.log('  ✅ idx_breakout_points_asset');

  db.exec('CREATE INDEX IF NOT EXISTS idx_inflection_points_asset ON inflection_points(assetId)');
  console.log('  ✅ idx_inflection_points_asset');

  db.exec('CREATE INDEX IF NOT EXISTS idx_break_even_user ON break_even_points(userId)');
  console.log('  ✅ idx_break_even_user');

  // Learning Control indexes
  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_category ON search_keywords(category)');
  console.log('  ✅ idx_search_keywords_category');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_priority ON search_keywords(priority)');
  console.log('  ✅ idx_search_keywords_priority');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_keywords_enabled ON search_keywords(enabled)');
  console.log('  ✅ idx_search_keywords_enabled');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_type ON search_sources(type)');
  console.log('  ✅ idx_search_sources_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_sources_enabled ON search_sources(enabled)');
  console.log('  ✅ idx_search_sources_enabled');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_type ON learning_operations(type)');
  console.log('  ✅ idx_learning_operations_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_status ON learning_operations(status)');
  console.log('  ✅ idx_learning_operations_status');

  db.exec('CREATE INDEX IF NOT EXISTS idx_learning_operations_created_at ON learning_operations(created_at)');
  console.log('  ✅ idx_learning_operations_created_at');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_type ON search_operations(type)');
  console.log('  ✅ idx_search_operations_type');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_status ON search_operations(status)');
  console.log('  ✅ idx_search_operations_status');

  db.exec('CREATE INDEX IF NOT EXISTS idx_search_operations_created_at ON search_operations(created_at)');
  console.log('  ✅ idx_search_operations_created_at');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_id ON operation_logs(operation_id)');
  console.log('  ✅ idx_operation_logs_operation_id');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_level ON operation_logs(level)');
  console.log('  ✅ idx_operation_logs_level');

  db.exec('CREATE INDEX IF NOT EXISTS idx_operation_logs_timestamp ON operation_logs(timestamp)');
  console.log('  ✅ idx_operation_logs_timestamp');

  console.log('\n✅ Database setup complete!');

  db.close();
}

// Run setup
setupDatabase();

