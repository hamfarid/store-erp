#!/bin/bash
# ============================================================
# Gold Price Predictor - Database Restore Script
# ============================================================
# Purpose: Restore database from backup file
# Created: 2026-01-15
# Version: 1.0
# Usage: ./restore.sh <backup_file>
# ============================================================

set -e  # Exit on error

# ============================================================
# Configuration
# ============================================================

DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_NAME="${DB_NAME:-gold_price_predictor}"
DB_USER="${DB_USER:-postgres}"
PGPASSWORD="${DB_PASSWORD:-}"
export PGPASSWORD

# ============================================================
# Functions
# ============================================================

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

error() {
    log "ERROR: $1"
    exit 1
}

show_usage() {
    echo "Usage: $0 <backup_file>"
    echo ""
    echo "Options:"
    echo "  backup_file    Path to the .dump backup file"
    echo ""
    echo "Environment Variables:"
    echo "  DB_HOST        Database host (default: localhost)"
    echo "  DB_PORT        Database port (default: 5432)"
    echo "  DB_NAME        Database name (default: gold_price_predictor)"
    echo "  DB_USER        Database user (default: postgres)"
    echo "  DB_PASSWORD    Database password"
    echo ""
    echo "Example:"
    echo "  $0 /backups/daily/backup_gold_price_predictor_20260115_020000.dump"
    exit 1
}

verify_backup_file() {
    local backup_file="$1"
    
    if [[ ! -f "$backup_file" ]]; then
        error "Backup file not found: $backup_file"
    fi
    
    if [[ ! -s "$backup_file" ]]; then
        error "Backup file is empty: $backup_file"
    fi
    
    # Verify it's a valid pg_dump file
    pg_restore -l "$backup_file" > /dev/null 2>&1
    if [[ $? -ne 0 ]]; then
        error "Invalid or corrupted backup file"
    fi
    
    log "Backup file verified: $backup_file"
}

confirm_restore() {
    log "WARNING: This will overwrite the existing database '$DB_NAME'"
    log "Host: $DB_HOST:$DB_PORT"
    echo ""
    read -p "Are you sure you want to continue? (yes/no): " confirm
    
    if [[ "$confirm" != "yes" ]]; then
        log "Restore cancelled by user"
        exit 0
    fi
}

create_database_if_needed() {
    log "Checking if database exists..."
    
    # Check if database exists
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -lqt | cut -d \| -f 1 | grep -qw "$DB_NAME"; then
        log "Database '$DB_NAME' exists, will be dropped and recreated"
        
        # Terminate active connections
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();" \
            > /dev/null 2>&1 || true
        
        # Drop database
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "DROP DATABASE IF EXISTS \"$DB_NAME\";"
    fi
    
    # Create fresh database
    log "Creating database '$DB_NAME'..."
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "CREATE DATABASE \"$DB_NAME\";"
}

perform_restore() {
    local backup_file="$1"
    
    log "Starting database restore..."
    log "Source: $backup_file"
    log "Target: $DB_HOST:$DB_PORT/$DB_NAME"
    
    # Restore the database
    pg_restore \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -v \
        --clean \
        --if-exists \
        --no-owner \
        --no-privileges \
        "$backup_file" \
        2>&1 | while read line; do log "pg_restore: $line"; done
    
    log "Restore completed"
}

verify_restore() {
    log "Verifying restore..."
    
    # Check table count
    local table_count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';")
    
    log "Tables restored: $table_count"
    
    if [[ $table_count -lt 1 ]]; then
        error "Restore verification failed - no tables found"
    fi
    
    # Check critical tables exist
    for table in users assets predictions events; do
        local exists=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
            "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = '$table');")
        
        if [[ "$exists" != *"t"* ]]; then
            log "WARNING: Table '$table' not found"
        fi
    done
    
    log "Restore verification passed"
}

generate_report() {
    local backup_file="$1"
    local start_time=$2
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    local table_count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';")
    
    local row_count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT SUM(n_live_tup) FROM pg_stat_user_tables;")
    
    echo ""
    echo "============================================"
    echo "       DATABASE RESTORE REPORT"
    echo "============================================"
    echo "Source:       $(basename $backup_file)"
    echo "Database:     $DB_NAME"
    echo "Host:         $DB_HOST:$DB_PORT"
    echo "Tables:       $table_count"
    echo "Total Rows:   $row_count"
    echo "Duration:     ${duration}s"
    echo "Status:       SUCCESS"
    echo "Timestamp:    $(date '+%Y-%m-%d %H:%M:%S')"
    echo "============================================"
    echo ""
}

# ============================================================
# Main
# ============================================================

main() {
    if [[ $# -lt 1 ]]; then
        show_usage
    fi
    
    local backup_file="$1"
    local start_time=$(date +%s)
    
    log "============================================"
    log "Gold Price Predictor - Database Restore"
    log "============================================"
    
    verify_backup_file "$backup_file"
    confirm_restore
    create_database_if_needed
    perform_restore "$backup_file"
    verify_restore
    generate_report "$backup_file" $start_time
    
    log "============================================"
    log "Restore process completed successfully"
    log "============================================"
}

# Run main function
main "$@"
