#!/bin/bash
# ============================================================
# Gold Price Predictor - Daily Backup Script
# ============================================================
# Purpose: Perform daily full database backup
# Created: 2026-01-15
# Version: 1.0
# ============================================================

set -e  # Exit on error
set -u  # Exit on undefined variable

# ============================================================
# Configuration
# ============================================================

# Database connection
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_NAME="${DB_NAME:-gold_price_predictor}"
DB_USER="${DB_USER:-postgres}"
PGPASSWORD="${DB_PASSWORD:-}"
export PGPASSWORD

# Backup settings
BACKUP_DIR="${BACKUP_DIR:-/backups}"
BACKUP_RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="backup_${DB_NAME}_${TIMESTAMP}.dump"
BACKUP_PATH="${BACKUP_DIR}/daily/${BACKUP_FILE}"

# S3 settings (optional)
S3_BUCKET="${S3_BUCKET:-}"
S3_PREFIX="${S3_PREFIX:-backups/daily}"

# Notification settings (optional)
SLACK_WEBHOOK="${SLACK_WEBHOOK:-}"

# ============================================================
# Functions
# ============================================================

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

error() {
    log "ERROR: $1"
    send_notification "❌ Backup Failed" "$1"
    exit 1
}

send_notification() {
    local title="$1"
    local message="$2"
    
    if [[ -n "$SLACK_WEBHOOK" ]]; then
        curl -s -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"${title}\n${message}\"}" \
            "$SLACK_WEBHOOK" > /dev/null
    fi
}

create_backup_dir() {
    log "Creating backup directory: ${BACKUP_DIR}/daily"
    mkdir -p "${BACKUP_DIR}/daily"
}

perform_backup() {
    log "Starting database backup: $DB_NAME"
    log "Backup file: $BACKUP_PATH"
    
    # Use pg_dump with custom format for efficient compression
    pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -Fc \
        -v \
        -f "$BACKUP_PATH" \
        2>&1 | while read line; do log "pg_dump: $line"; done
    
    if [[ ! -f "$BACKUP_PATH" ]]; then
        error "Backup file was not created"
    fi
    
    local size=$(du -h "$BACKUP_PATH" | cut -f1)
    log "Backup completed successfully. Size: $size"
}

upload_to_s3() {
    if [[ -z "$S3_BUCKET" ]]; then
        log "S3 upload skipped (S3_BUCKET not configured)"
        return 0
    fi
    
    log "Uploading to S3: s3://${S3_BUCKET}/${S3_PREFIX}/${BACKUP_FILE}"
    
    aws s3 cp "$BACKUP_PATH" "s3://${S3_BUCKET}/${S3_PREFIX}/${BACKUP_FILE}" \
        --storage-class STANDARD_IA
    
    log "S3 upload completed"
}

cleanup_old_backups() {
    log "Cleaning up backups older than ${BACKUP_RETENTION_DAYS} days"
    
    # Local cleanup
    find "${BACKUP_DIR}/daily" -name "backup_*.dump" -type f -mtime +${BACKUP_RETENTION_DAYS} -delete
    
    # S3 cleanup (if configured)
    if [[ -n "$S3_BUCKET" ]]; then
        local cutoff_date=$(date -d "-${BACKUP_RETENTION_DAYS} days" +%Y-%m-%d)
        aws s3 ls "s3://${S3_BUCKET}/${S3_PREFIX}/" | while read -r line; do
            local file_date=$(echo "$line" | awk '{print $1}')
            local file_name=$(echo "$line" | awk '{print $4}')
            if [[ "$file_date" < "$cutoff_date" ]] && [[ -n "$file_name" ]]; then
                log "Deleting old S3 backup: $file_name"
                aws s3 rm "s3://${S3_BUCKET}/${S3_PREFIX}/${file_name}"
            fi
        done
    fi
    
    log "Cleanup completed"
}

verify_backup() {
    log "Verifying backup integrity..."
    
    # Check if file exists and has size > 0
    if [[ ! -s "$BACKUP_PATH" ]]; then
        error "Backup file is empty or does not exist"
    fi
    
    # Try to list contents of the backup
    pg_restore -l "$BACKUP_PATH" > /dev/null 2>&1
    if [[ $? -ne 0 ]]; then
        error "Backup verification failed - file may be corrupted"
    fi
    
    log "Backup verification passed"
}

generate_report() {
    local end_time=$(date +%s)
    local start_time=$1
    local duration=$((end_time - start_time))
    local size=$(du -h "$BACKUP_PATH" | cut -f1)
    local tables=$(pg_restore -l "$BACKUP_PATH" 2>/dev/null | grep -c "TABLE DATA" || echo "N/A")
    
    local report="📦 *Daily Backup Report*
• Database: $DB_NAME
• File: $BACKUP_FILE
• Size: $size
• Tables: $tables
• Duration: ${duration}s
• Status: ✅ Success"
    
    log "$report"
    send_notification "✅ Backup Completed" "$report"
}

# ============================================================
# Main
# ============================================================

main() {
    local start_time=$(date +%s)
    
    log "============================================"
    log "Gold Price Predictor - Daily Backup"
    log "============================================"
    
    create_backup_dir
    perform_backup
    verify_backup
    upload_to_s3
    cleanup_old_backups
    generate_report $start_time
    
    log "============================================"
    log "Backup process completed successfully"
    log "============================================"
}

# Run main function
main "$@"
