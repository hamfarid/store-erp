# ============================================================
# Gold Price Predictor - Daily Backup Script (Windows)
# ============================================================
# Purpose: Perform daily full database backup
# Created: 2026-01-15
# Version: 1.0
# Usage: .\backup-daily.ps1
# ============================================================

param(
    [string]$DbHost = $env:DB_HOST,
    [string]$DbPort = $env:DB_PORT,
    [string]$DbName = $env:DB_NAME,
    [string]$DbUser = $env:DB_USER,
    [string]$DbPassword = $env:DB_PASSWORD,
    [string]$BackupDir = $env:BACKUP_DIR,
    [int]$RetentionDays = 30
)

# ============================================================
# Configuration with defaults
# ============================================================

if (-not $DbHost) { $DbHost = "localhost" }
if (-not $DbPort) { $DbPort = "5432" }
if (-not $DbName) { $DbName = "gold_price_predictor" }
if (-not $DbUser) { $DbUser = "postgres" }
if (-not $BackupDir) { $BackupDir = "D:\backups" }

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupFile = "backup_${DbName}_${Timestamp}.dump"
$BackupPath = Join-Path $BackupDir "daily" $BackupFile

# Set environment variable for pg_dump
$env:PGPASSWORD = $DbPassword

# ============================================================
# Functions
# ============================================================

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message"
}

function Write-Error-Log {
    param([string]$Message)
    Write-Log "ERROR: $Message"
    exit 1
}

function New-BackupDirectory {
    $dailyPath = Join-Path $BackupDir "daily"
    if (-not (Test-Path $dailyPath)) {
        Write-Log "Creating backup directory: $dailyPath"
        New-Item -ItemType Directory -Path $dailyPath -Force | Out-Null
    }
}

function Start-DatabaseBackup {
    Write-Log "Starting database backup: $DbName"
    Write-Log "Backup file: $BackupPath"
    
    # Find pg_dump executable
    $pgDumpPath = "pg_dump"
    
    # Common PostgreSQL installation paths on Windows
    $possiblePaths = @(
        "C:\Program Files\PostgreSQL\14\bin\pg_dump.exe",
        "C:\Program Files\PostgreSQL\15\bin\pg_dump.exe",
        "C:\Program Files\PostgreSQL\16\bin\pg_dump.exe",
        "C:\Program Files\PostgreSQL\17\bin\pg_dump.exe"
    )
    
    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            $pgDumpPath = $path
            break
        }
    }
    
    # Execute pg_dump
    $arguments = @(
        "-h", $DbHost,
        "-p", $DbPort,
        "-U", $DbUser,
        "-d", $DbName,
        "-Fc",
        "-v",
        "-f", $BackupPath
    )
    
    try {
        $process = Start-Process -FilePath $pgDumpPath -ArgumentList $arguments -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -ne 0) {
            Write-Error-Log "pg_dump failed with exit code: $($process.ExitCode)"
        }
    }
    catch {
        Write-Error-Log "Failed to execute pg_dump: $_"
    }
    
    if (-not (Test-Path $BackupPath)) {
        Write-Error-Log "Backup file was not created"
    }
    
    $size = (Get-Item $BackupPath).Length / 1MB
    Write-Log "Backup completed successfully. Size: $([math]::Round($size, 2)) MB"
}

function Test-BackupIntegrity {
    Write-Log "Verifying backup integrity..."
    
    if (-not (Test-Path $BackupPath)) {
        Write-Error-Log "Backup file does not exist"
    }
    
    $fileInfo = Get-Item $BackupPath
    if ($fileInfo.Length -eq 0) {
        Write-Error-Log "Backup file is empty"
    }
    
    Write-Log "Backup verification passed (file exists and has content)"
}

function Remove-OldBackups {
    Write-Log "Cleaning up backups older than $RetentionDays days"
    
    $cutoffDate = (Get-Date).AddDays(-$RetentionDays)
    $dailyPath = Join-Path $BackupDir "daily"
    
    Get-ChildItem -Path $dailyPath -Filter "backup_*.dump" | Where-Object {
        $_.LastWriteTime -lt $cutoffDate
    } | ForEach-Object {
        Write-Log "Deleting old backup: $($_.Name)"
        Remove-Item $_.FullName -Force
    }
    
    Write-Log "Cleanup completed"
}

function Get-BackupReport {
    param([datetime]$StartTime)
    
    $endTime = Get-Date
    $duration = ($endTime - $StartTime).TotalSeconds
    $fileInfo = Get-Item $BackupPath
    $sizeMB = [math]::Round($fileInfo.Length / 1MB, 2)
    
    $report = @"

============================================
       DAILY BACKUP REPORT
============================================
Database:     $DbName
Host:         $DbHost
File:         $BackupFile
Size:         $sizeMB MB
Duration:     $([math]::Round($duration, 1)) seconds
Status:       SUCCESS
Timestamp:    $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
============================================

"@
    
    Write-Host $report
    
    # Optionally save report to file
    $reportPath = Join-Path $BackupDir "daily" "backup_${DbName}_${Timestamp}_report.txt"
    $report | Out-File -FilePath $reportPath -Encoding UTF8
}

# ============================================================
# Main
# ============================================================

function Main {
    $startTime = Get-Date
    
    Write-Log "============================================"
    Write-Log "Gold Price Predictor - Daily Backup"
    Write-Log "============================================"
    
    try {
        New-BackupDirectory
        Start-DatabaseBackup
        Test-BackupIntegrity
        Remove-OldBackups
        Get-BackupReport -StartTime $startTime
        
        Write-Log "============================================"
        Write-Log "Backup process completed successfully"
        Write-Log "============================================"
    }
    catch {
        Write-Error-Log "Backup process failed: $_"
    }
    finally {
        # Clear password from environment
        $env:PGPASSWORD = $null
    }
}

# Run main function
Main
