# View Container Logs
Write-Host "`n══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🔍 فحص سجلات الحاويات المتعثرة" -ForegroundColor Yellow
Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Check if containers exist
$backendExists = docker ps -a --filter "name=gold-predictor-backend" --format "{{.Names}}" 2>&1
$mlExists = docker ps -a --filter "name=gold-predictor-ml" --format "{{.Names}}" 2>&1
$promExists = docker ps -a --filter "name=gold-predictor-prometheus" --format "{{.Names}}" 2>&1

if (-not $backendExists -or $backendExists -eq "") {
    Write-Host "⚠️  حاوية Backend غير موجودة" -ForegroundColor Yellow
} else {
    Write-Host "1️⃣  سجلات Backend (آخر 50 سطر):" -ForegroundColor Yellow
    Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
    docker logs gold-predictor-backend --tail 50 2>&1 | ForEach-Object { Write-Host $_ }
    Write-Host ""
}

if (-not $mlExists -or $mlExists -eq "") {
    Write-Host "⚠️  حاوية ML Service غير موجودة" -ForegroundColor Yellow
} else {
    Write-Host "2️⃣  سجلات ML Service (آخر 50 سطر):" -ForegroundColor Yellow
    Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
    docker logs gold-predictor-ml --tail 50 2>&1 | ForEach-Object { Write-Host $_ }
    Write-Host ""
}

if (-not $promExists -or $promExists -eq "") {
    Write-Host "⚠️  حاوية Prometheus غير موجودة" -ForegroundColor Yellow
} else {
    Write-Host "3️⃣  سجلات Prometheus (آخر 30 سطر):" -ForegroundColor Yellow
    Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
    docker logs gold-predictor-prometheus --tail 30 2>&1 | ForEach-Object { Write-Host $_ }
    Write-Host ""
}

Write-Host "4️⃣  حالة جميع الحاويات:" -ForegroundColor Cyan
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor Gray
docker ps -a --filter "name=gold-predictor" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
Write-Host ""

Write-Host "══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

