#!/bin/bash

# Database Backup Script
# Creates a backup of the MySQL/TiDB database
# Usage: ./scripts/backup-database.sh

set -e

# Load environment variables
if [ -f .env ]; then
  export $(cat .env | grep -v '^#' | xargs)
fi

# Configuration
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/asset_predictor_backup_$TIMESTAMP.sql"

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

echo "🗄️  Starting database backup..."
echo "📅 Timestamp: $TIMESTAMP"

# Extract database connection details from DATABASE_URL
# Format: mysql://user:password@host:port/database
if [ -z "$DATABASE_URL" ]; then
  echo "❌ ERROR: DATABASE_URL environment variable not set"
  exit 1
fi

# Parse DATABASE_URL
DB_USER=$(echo $DATABASE_URL | sed -n 's/.*:\/\/\([^:]*\):.*/\1/p')
DB_PASS=$(echo $DATABASE_URL | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p')
DB_HOST=$(echo $DATABASE_URL | sed -n 's/.*@\([^:]*\):.*/\1/p')
DB_PORT=$(echo $DATABASE_URL | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
DB_NAME=$(echo $DATABASE_URL | sed -n 's/.*\/\([^?]*\).*/\1/p')

echo "📊 Database: $DB_NAME"
echo "🖥️  Host: $DB_HOST:$DB_PORT"

# Create backup using mysqldump
if command -v mysqldump &> /dev/null; then
  echo "🔄 Creating backup..."
  mysqldump \
    --host="$DB_HOST" \
    --port="$DB_PORT" \
    --user="$DB_USER" \
    --password="$DB_PASS" \
    --single-transaction \
    --routines \
    --triggers \
    --events \
    "$DB_NAME" > "$BACKUP_FILE"
  
  # Compress backup
  echo "📦 Compressing backup..."
  gzip "$BACKUP_FILE"
  BACKUP_FILE="$BACKUP_FILE.gz"
  
  # Get file size
  BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
  
  echo "✅ Backup completed successfully!"
  echo "📁 File: $BACKUP_FILE"
  echo "📏 Size: $BACKUP_SIZE"
  
  # Keep only last 10 backups
  echo "🧹 Cleaning old backups (keeping last 10)..."
  ls -t "$BACKUP_DIR"/asset_predictor_backup_*.sql.gz | tail -n +11 | xargs -r rm
  
  echo "🎉 Backup process finished!"
else
  echo "❌ ERROR: mysqldump not found. Please install MySQL client tools."
  exit 1
fi

# Optional: Upload to cloud storage
# Uncomment and configure for your cloud provider
# echo "☁️  Uploading to cloud storage..."
# aws s3 cp "$BACKUP_FILE" "s3://your-bucket/backups/"
# echo "✅ Uploaded to cloud storage"

