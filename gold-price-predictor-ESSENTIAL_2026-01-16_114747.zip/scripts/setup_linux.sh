#!/bin/bash
################################################################################
# سكريبت تثبيت وتشغيل نظام التنبؤ بأسعار الأصول - Linux
# Asset Price Prediction System - Linux Setup Script
################################################################################

set -e  # إيقاف عند أي خطأ

# الألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# دوال مساعدة
print_header() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# التحقق من الصلاحيات
check_sudo() {
    if [ "$EUID" -eq 0 ]; then 
        print_warning "يُفضل عدم تشغيل السكريبت كـ root"
    fi
}

# التحقق من نظام التشغيل
check_os() {
    print_header "التحقق من نظام التشغيل"
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        print_success "نظام Linux مكتشف"
        
        # اكتشاف التوزيعة
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            print_info "التوزيعة: $NAME $VERSION"
        fi
    else
        print_error "هذا السكريبت مخصص لـ Linux فقط"
        print_info "استخدم setup_windows.ps1 لـ Windows"
        exit 1
    fi
}

# تثبيت المتطلبات الأساسية
install_system_dependencies() {
    print_header "تثبيت المتطلبات الأساسية"
    
    # اكتشاف مدير الحزم
    if command -v apt-get &> /dev/null; then
        PKG_MANAGER="apt-get"
        UPDATE_CMD="sudo apt-get update"
        INSTALL_CMD="sudo apt-get install -y"
    elif command -v yum &> /dev/null; then
        PKG_MANAGER="yum"
        UPDATE_CMD="sudo yum check-update || true"
        INSTALL_CMD="sudo yum install -y"
    elif command -v dnf &> /dev/null; then
        PKG_MANAGER="dnf"
        UPDATE_CMD="sudo dnf check-update || true"
        INSTALL_CMD="sudo dnf install -y"
    elif command -v pacman &> /dev/null; then
        PKG_MANAGER="pacman"
        UPDATE_CMD="sudo pacman -Sy"
        INSTALL_CMD="sudo pacman -S --noconfirm"
    else
        print_error "مدير الحزم غير مدعوم"
        exit 1
    fi
    
    print_info "مدير الحزم: $PKG_MANAGER"
    
    # تحديث قائمة الحزم
    print_info "تحديث قائمة الحزم..."
    eval $UPDATE_CMD
    
    # تثبيت Git
    if ! command -v git &> /dev/null; then
        print_info "تثبيت Git..."
        eval $INSTALL_CMD git
        print_success "تم تثبيت Git"
    else
        print_success "Git مثبت بالفعل"
    fi
    
    # تثبيت Python 3.11
    if ! command -v python3.11 &> /dev/null; then
        print_info "تثبيت Python 3.11..."
        
        if [ "$PKG_MANAGER" = "apt-get" ]; then
            # Ubuntu/Debian
            $INSTALL_CMD software-properties-common
            sudo add-apt-repository -y ppa:deadsnakes/ppa
            sudo apt-get update
            $INSTALL_CMD python3.11 python3.11-venv python3.11-dev
        elif [ "$PKG_MANAGER" = "dnf" ] || [ "$PKG_MANAGER" = "yum" ]; then
            # Fedora/RHEL/CentOS
            $INSTALL_CMD python3.11 python3.11-devel
        else
            print_warning "قد تحتاج لتثبيت Python 3.11 يدوياً"
        fi
        
        print_success "تم تثبيت Python 3.11"
    else
        print_success "Python 3.11 مثبت بالفعل"
    fi
    
    # تثبيت pip
    if ! command -v pip3 &> /dev/null; then
        print_info "تثبيت pip..."
        curl -sS https://bootstrap.pypa.io/get-pip.py | python3.11
        print_success "تم تثبيت pip"
    else
        print_success "pip مثبت بالفعل"
    fi
    
    # تثبيت Node.js و pnpm
    if ! command -v node &> /dev/null; then
        print_info "تثبيت Node.js..."
        
        # استخدام nvm
        if [ ! -d "$HOME/.nvm" ]; then
            curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
            export NVM_DIR="$HOME/.nvm"
            [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
        fi
        
        nvm install 22
        nvm use 22
        
        print_success "تم تثبيت Node.js"
    else
        print_success "Node.js مثبت بالفعل"
    fi
    
    # تثبيت pnpm
    if ! command -v pnpm &> /dev/null; then
        print_info "تثبيت pnpm..."
        npm install -g pnpm
        print_success "تم تثبيت pnpm"
    else
        print_success "pnpm مثبت بالفعل"
    fi
}

# استنساخ المشروع من GitHub
clone_project() {
    print_header "استنساخ المشروع من GitHub"
    
    # المسار الافتراضي
    PROJECT_DIR="$HOME/gold-price-predictor"
    UI_DIR="$HOME/asset-predictor-ui"
    
    # استنساخ gold-price-predictor
    if [ -d "$PROJECT_DIR" ]; then
        print_warning "المجلد موجود بالفعل: $PROJECT_DIR"
        read -p "هل تريد حذفه وإعادة الاستنساخ؟ (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$PROJECT_DIR"
            git clone https://github.com/hamfarid/gold-price-predictor.git "$PROJECT_DIR"
            print_success "تم استنساخ gold-price-predictor"
        else
            print_info "استخدام المجلد الموجود"
        fi
    else
        git clone https://github.com/hamfarid/gold-price-predictor.git "$PROJECT_DIR"
        print_success "تم استنساخ gold-price-predictor"
    fi
    
    # ملاحظة: asset-predictor-ui قد يكون في نفس المستودع أو منفصل
    # تحديث هذا حسب بنية المشروع الفعلية
    
    print_success "تم استنساخ المشروع"
}

# إعداد البيئة الافتراضية لـ Python
setup_python_env() {
    print_header "إعداد البيئة الافتراضية لـ Python"
    
    cd "$PROJECT_DIR"
    
    # إنشاء البيئة الافتراضية
    if [ ! -d "venv" ]; then
        print_info "إنشاء البيئة الافتراضية..."
        python3.11 -m venv venv
        print_success "تم إنشاء البيئة الافتراضية"
    else
        print_success "البيئة الافتراضية موجودة"
    fi
    
    # تفعيل البيئة
    source venv/bin/activate
    
    # ترقية pip
    print_info "ترقية pip..."
    pip install --upgrade pip
    
    # تثبيت المتطلبات
    if [ -f "requirements.txt" ]; then
        print_info "تثبيت متطلبات Python..."
        pip install -r requirements.txt
        print_success "تم تثبيت متطلبات Python"
    else
        print_warning "ملف requirements.txt غير موجود"
        print_info "تثبيت الحزم الأساسية..."
        pip install fastapi uvicorn yfinance pandas numpy scikit-learn joblib
    fi
}

# إعداد Frontend
setup_frontend() {
    print_header "إعداد Frontend"
    
    # البحث عن مجلد Frontend
    if [ -d "$PROJECT_DIR/asset_predictor_ui" ]; then
        cd "$PROJECT_DIR/asset_predictor_ui"
    elif [ -d "$HOME/asset-predictor-ui" ]; then
        cd "$HOME/asset-predictor-ui"
    else
        print_warning "مجلد Frontend غير موجود"
        return
    fi
    
    # تثبيت dependencies
    if [ -f "package.json" ]; then
        print_info "تثبيت متطلبات Node.js..."
        pnpm install
        print_success "تم تثبيت متطلبات Node.js"
        
        # إنشاء قاعدة البيانات SQLite
        print_info "إعداد قاعدة البيانات SQLite..."
        mkdir -p data
        
        # تشغيل migrations
        if [ -f "migrate.js" ]; then
            node migrate.js || print_warning "فشل تطبيق migrations"
        fi
        
        # إضافة الأصول الأولية
        if [ -f "seed-assets.js" ]; then
            node seed-assets.js || print_warning "فشل إضافة الأصول"
        fi
        
        print_success "تم إعداد قاعدة البيانات"
    else
        print_warning "ملف package.json غير موجود"
    fi
}

# إنشاء ملف .env
create_env_file() {
    print_header "إنشاء ملف .env"
    
    cd "$PROJECT_DIR"
    
    if [ ! -f ".env" ]; then
        cat > .env << EOF
# Python API
PYTHON_API_PORT=8000

# Database (SQLite)
DATABASE_URL=file:./data/app.db

# Email (اختياري)
# EMAIL_USER=your-email@gmail.com
# EMAIL_PASSWORD=your-app-password

# Frontend
VITE_API_URL=http://localhost:8000
EOF
        print_success "تم إنشاء ملف .env"
    else
        print_success "ملف .env موجود بالفعل"
    fi
    
    # إنشاء .env للـ Frontend أيضاً
    if [ -d "$PROJECT_DIR/asset_predictor_ui" ]; then
        cd "$PROJECT_DIR/asset_predictor_ui"
        if [ ! -f ".env" ]; then
            cat > .env << EOF
# Database (SQLite)
DATABASE_URL=file:./data/app.db

# API URL
VITE_API_URL=http://localhost:8000
EOF
            print_success "تم إنشاء ملف .env للـ Frontend"
        fi
    fi
}

# بدء الخدمات
start_services() {
    print_header "بدء الخدمات"
    
    # بدء Python API
    print_info "بدء Python API..."
    cd "$PROJECT_DIR"
    source venv/bin/activate
    
    # إيقاف العمليات القديمة
    pkill -f "simple_api.py" || true
    
    # بدء API في الخلفية
    nohup python3.11 simple_api.py > api.log 2>&1 &
    API_PID=$!
    
    print_success "Python API يعمل (PID: $API_PID)"
    print_info "السجلات: $PROJECT_DIR/api.log"
    
    # الانتظار قليلاً
    sleep 3
    
    # التحقق من عمل API
    if curl -s http://localhost:8000/models > /dev/null; then
        print_success "Python API يعمل بنجاح!"
    else
        print_error "فشل بدء Python API"
        print_info "تحقق من السجلات: $PROJECT_DIR/api.log"
    fi
    
    # بدء Frontend
    if [ -d "$PROJECT_DIR/asset_predictor_ui" ] || [ -d "$HOME/asset-predictor-ui" ]; then
        print_info "بدء Frontend..."
        
        if [ -d "$PROJECT_DIR/asset_predictor_ui" ]; then
            cd "$PROJECT_DIR/asset_predictor_ui"
        else
            cd "$HOME/asset-predictor-ui"
        fi
        
        # إيقاف العمليات القديمة
        pkill -f "vite" || true
        
        # بدء Frontend في الخلفية
        nohup pnpm dev > frontend.log 2>&1 &
        FRONTEND_PID=$!
        
        print_success "Frontend يعمل (PID: $FRONTEND_PID)"
        print_info "السجلات: frontend.log"
        
        sleep 3
        
        print_success "Frontend يعمل على http://localhost:3000"
    fi
}

# عرض الملخص
show_summary() {
    print_header "الملخص"
    
    echo ""
    echo -e "${GREEN}✅ تم تثبيت وتشغيل النظام بنجاح!${NC}"
    echo ""
    echo -e "${BLUE}الخدمات:${NC}"
    echo -e "  • Python API: ${GREEN}http://localhost:8000${NC}"
    echo -e "  • Frontend: ${GREEN}http://localhost:3000${NC}"
    echo ""
    echo -e "${BLUE}السجلات:${NC}"
    echo -e "  • Python API: ${YELLOW}$PROJECT_DIR/api.log${NC}"
    echo -e "  • Frontend: ${YELLOW}frontend.log${NC}"
    echo ""
    echo -e "${BLUE}الأوامر المفيدة:${NC}"
    echo -e "  • إيقاف Python API: ${YELLOW}pkill -f simple_api.py${NC}"
    echo -e "  • إيقاف Frontend: ${YELLOW}pkill -f vite${NC}"
    echo -e "  • عرض السجلات: ${YELLOW}tail -f $PROJECT_DIR/api.log${NC}"
    echo ""
    echo -e "${BLUE}البيئة الافتراضية:${NC}"
    echo -e "  • تفعيل: ${YELLOW}source $PROJECT_DIR/venv/bin/activate${NC}"
    echo -e "  • إلغاء التفعيل: ${YELLOW}deactivate${NC}"
    echo ""
}

# الدالة الرئيسية
main() {
    clear
    
    print_header "نظام التنبؤ بأسعار الأصول - Linux Setup"
    echo ""
    
    check_sudo
    check_os
    
    echo ""
    read -p "هل تريد المتابعة؟ (y/n) " -n 1 -r
    echo
    
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "تم الإلغاء"
        exit 0
    fi
    
    install_system_dependencies
    clone_project
    setup_python_env
    setup_frontend
    create_env_file
    start_services
    show_summary
    
    print_success "تم بنجاح! 🎉"
}

# تشغيل السكريبت
main

