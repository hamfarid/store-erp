/**
 * FILE: scripts/cleanup-users.ts
 * PURPOSE: Delete test users and invalid admin users
 * OWNER: Backend Team
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";

const DB_PATH = process.env.DATABASE_URL || "file:./data/asset_predictor.db";
const dbPath = DB_PATH.replace("file:", "");

console.log("🧹 Cleaning Up Users");
console.log("=".repeat(50));

const sqlite = new Database(dbPath);

// Delete test users
console.log("\n1️⃣ Deleting test users...");
const testUsersDeleted = sqlite
  .prepare("DELETE FROM users WHERE email LIKE 'testuser%@example.com'")
  .run();
console.log(`   Deleted: ${testUsersDeleted.changes} test users`);

// Delete admin users with null email
console.log("\n2️⃣ Deleting invalid admin users...");
const invalidAdminsDeleted = sqlite
  .prepare("DELETE FROM users WHERE email IS NULL AND role = 'admin'")
  .run();
console.log(`   Deleted: ${invalidAdminsDeleted.changes} invalid admin users`);

// Show remaining users
console.log("\n3️⃣ Remaining users:");
const remainingUsers = sqlite
  .prepare("SELECT id, email, role FROM users")
  .all();
console.log(`   Total: ${remainingUsers.length} users`);
remainingUsers.forEach((user: any) => {
  console.log(`   - ${user.email || "NO EMAIL"} (${user.role})`);
});

sqlite.close();

console.log("\n" + "=".repeat(50));
console.log("✅ Cleanup complete!");
console.log("=".repeat(50));

