// FILE: scripts/test-login-api.ts | PURPOSE: Test login API directly | OWNER: Backend Team | RELATED: server/routers.ts | LAST-AUDITED: 2025-11-25

import fetch from "node-fetch";

const API_URL = "http://localhost:2505/api/trpc";

async function testLogin() {
  console.log("\n🔍 Testing Login API...\n");
  console.log("=".repeat(50));

  try {
    // Test 1: Login (tRPC format)
    console.log("\n1️⃣ Testing POST /api/trpc/auth.login");
    const loginInput = {
      email: "admin@gaaraholding.com",
      password: "Admin@2025!",
    };

    const loginResponse = await fetch(`${API_URL}/auth.login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        json: loginInput, // tRPC expects data in "json" field
      }),
    });

    console.log("Status:", loginResponse.status);
    console.log(
      "Headers:",
      Object.fromEntries(loginResponse.headers.entries())
    );

    const loginText = await loginResponse.text();
    console.log("Response:", loginText);

    if (loginResponse.ok) {
      console.log("✅ Login successful!");
    } else {
      console.log("❌ Login failed!");
    }

    // Test 2: Get current user (me)
    console.log("\n2️⃣ Testing GET /api/trpc/auth.me");

    // Extract cookie from Set-Cookie header
    const setCookie = loginResponse.headers.get("set-cookie");
    console.log("Set-Cookie:", setCookie);

    const cookie = setCookie?.split(";")[0] || "";
    console.log("Cookie to send:", cookie);

    const meResponse = await fetch(`${API_URL}/auth.me`, {
      method: "GET",
      headers: {
        Cookie: cookie,
      },
    });

    console.log("Status:", meResponse.status);
    const meText = await meResponse.text();
    console.log("Response:", meText);

    if (meResponse.ok) {
      const meData = JSON.parse(meText);
      if (meData.result?.data?.json) {
        console.log("✅ User authenticated:", meData.result.data.json);
      } else {
        console.log("❌ User not authenticated (null response)");
      }
    }
  } catch (error) {
    console.error("❌ Error:", error);
  }

  console.log("\n" + "=".repeat(50));
}

testLogin();
