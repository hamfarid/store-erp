// FILE: scripts/fetch-historical-data.ts | PURPOSE: Fetch historical price data from Yahoo Finance | OWNER: Backend Team | LAST-AUDITED: 2025-11-25

import axios from "axios";
import { getPool } from "../server/db-postgres";

interface YahooQuote {
  date: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

async function fetchHistoricalData(
  symbol: string,
  days: number = 365,
  pool: any
) {
  try {
    console.log(`\n📊 Fetching ${days} days of data for ${symbol}...\n`);

    // Calculate date range
    const endDate = Math.floor(Date.now() / 1000);
    const startDate = endDate - days * 24 * 60 * 60;

    // Fetch from Yahoo Finance
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`;
    const params = {
      period1: startDate,
      period2: endDate,
      interval: "1d",
      events: "history",
    };

    console.log(`🌐 Fetching from Yahoo Finance...`);
    const response = await axios.get(url, { params });

    const result = response.data.chart.result[0];
    const timestamps = result.timestamp;
    const quotes = result.indicators.quote[0];

    console.log(`✅ Fetched ${timestamps.length} data points`);

    // Get asset ID
    const assetResult = await pool.query(
      "SELECT id FROM assets WHERE symbol = $1",
      [symbol]
    );

    if (assetResult.rows.length === 0) {
      throw new Error(`Asset ${symbol} not found in database`);
    }

    const assetId = assetResult.rows[0].id;

    // Insert price history
    let inserted = 0;
    let skipped = 0;

    for (let i = 0; i < timestamps.length; i++) {
      const timestamp = timestamps[i] * 1000; // Convert to milliseconds
      const open = quotes.open[i];
      const high = quotes.high[i];
      const low = quotes.low[i];
      const close = quotes.close[i];
      const volume = quotes.volume[i] || 0;

      // Skip if any price is null
      if (!open || !high || !low || !close) {
        skipped++;
        continue;
      }

      const id = `price_${assetId}_${timestamp}`;

      try {
        await pool.query(
          `
          INSERT INTO price_history (id, asset_id, timestamp, open, high, low, close, volume, source, created_at)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
          ON CONFLICT (id) DO NOTHING
        `,
          [
            id,
            assetId,
            timestamp,
            open,
            high,
            low,
            close,
            volume,
            "yahoo_finance",
            Date.now(),
          ]
        );
        inserted++;
      } catch (error) {
        // Ignore duplicate errors
        skipped++;
      }
    }

    console.log(`\n✅ Inserted: ${inserted} records`);
    console.log(`⏭️  Skipped: ${skipped} records`);

    // Verify data
    const countResult = await pool.query(
      "SELECT COUNT(*) FROM price_history WHERE asset_id = $1",
      [assetId]
    );
    console.log(`📊 Total records in DB: ${countResult.rows[0].count}`);

    // Show latest prices
    const latestResult = await pool.query(
      `
      SELECT timestamp, open, high, low, close, volume
      FROM price_history
      WHERE asset_id = $1
      ORDER BY timestamp DESC
      LIMIT 5
    `,
      [assetId]
    );

    console.log(`\n📈 Latest 5 prices:`);
    latestResult.rows.forEach(row => {
      const date = new Date(parseInt(row.timestamp))
        .toISOString()
        .split("T")[0];
      console.log(
        `   ${date}: Open=${row.open}, High=${row.high}, Low=${row.low}, Close=${row.close}, Volume=${row.volume}`
      );
    });

    console.log(`\n✅ Data fetch complete for ${symbol}!`);
  } catch (error: any) {
    console.error(`❌ Error fetching data:`, error.message);
    throw error;
  }
}

// Fetch data for all assets
async function fetchAllAssets() {
  const pool = getPool();
  const symbols = ["GC=F", "SI=F", "BTC-USD"];

  try {
    for (const symbol of symbols) {
      try {
        await fetchHistoricalData(symbol, 365, pool); // 1 year of data
        console.log("\n" + "=".repeat(50) + "\n");
      } catch (error) {
        console.error(`Failed to fetch ${symbol}:`, error);
      }
    }
  } finally {
    await pool.end();
  }
}

fetchAllAssets();
