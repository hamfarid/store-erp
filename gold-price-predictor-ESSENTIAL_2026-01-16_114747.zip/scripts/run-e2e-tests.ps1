# Script to run E2E tests with Playwright
# Ensures server is ready before running tests

Write-Host "🧪 Starting E2E Tests..." -ForegroundColor Cyan

# Check if server is running
$maxAttempts = 30
$attempt = 0
$serverReady = $false

Write-Host "⏳ Waiting for server to be ready..." -ForegroundColor Yellow

while ($attempt -lt $maxAttempts -and -not $serverReady) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:2505" -TimeoutSec 2 -UseBasicParsing -ErrorAction Stop
        $serverReady = $true
        Write-Host "✅ Server is ready!" -ForegroundColor Green
    } catch {
        $attempt++
        Write-Host "  Attempt $attempt/$maxAttempts..." -ForegroundColor Gray
        Start-Sleep -Seconds 2
    }
}

if (-not $serverReady) {
    Write-Host "❌ Server is not ready. Please start the server first:" -ForegroundColor Red
    Write-Host "   npm run dev" -ForegroundColor Yellow
    exit 1
}

# Create screenshots directory
if (-not (Test-Path "screenshots")) {
    New-Item -ItemType Directory -Path "screenshots" | Out-Null
    Write-Host "📁 Created screenshots directory" -ForegroundColor Green
}

# Run tests
Write-Host "`n🚀 Running Playwright tests..." -ForegroundColor Cyan
$env:PLAYWRIGHT_BASE_URL = "http://localhost:2505"

# Run comprehensive tests
Write-Host "`n1️⃣ Running comprehensive pages test..." -ForegroundColor Yellow
npx playwright test e2e/tests/comprehensive-pages-test.spec.ts --project=chromium --workers=1 --timeout=180000

Write-Host "`n2️⃣ Running error analysis test..." -ForegroundColor Yellow
npx playwright test e2e/tests/error-analysis.spec.ts --project=chromium --workers=1 --timeout=180000

Write-Host "`n3️⃣ Running all buttons screenshots test..." -ForegroundColor Yellow
npx playwright test e2e/tests/all-buttons-screenshots.spec.ts --project=chromium --workers=1 --timeout=180000

Write-Host "`n✅ Tests completed!" -ForegroundColor Green
Write-Host "📊 View report: npx playwright show-report" -ForegroundColor Cyan
Write-Host "📸 Screenshots saved in: screenshots/" -ForegroundColor Cyan

