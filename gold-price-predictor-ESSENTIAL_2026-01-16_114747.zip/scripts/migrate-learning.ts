/**
 * FILE: scripts/migrate-learning.ts
 * PURPOSE: Apply learning path optimization migration
 * OWNER: ML Team
 * RELATED: drizzle/migrations/0002_learning_path.sql
 * LAST-AUDITED: 2025-01-18
 */

import Database from "better-sqlite3";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath =
  process.env.DATABASE_URL?.replace("file:", "") ||
  resolve(__dirname, "../data/app.db");
const migrationPath = resolve(
  __dirname,
  "../drizzle/migrations/0002_learning_path.sql"
);

console.log("🚀 Starting learning path migration...");
console.log(`📁 Database: ${dbPath}`);
console.log(`📄 Migration: ${migrationPath}`);

try {
  const db = new Database(dbPath);
  const migrationSQL = readFileSync(migrationPath, "utf-8");

  db.exec(migrationSQL);

  console.log("✅ Migration completed successfully!");
  console.log("");
  console.log("📊 Created tables:");

  const tables = db
    .prepare(
      `
    SELECT name FROM sqlite_master
    WHERE type='table'
    AND name IN (
      'learning_paths',
      'learning_progress',
      'path_evaluations',
      'aco_pheromones',
      'rl_states'
    )
  `
    )
    .all();

  tables.forEach((table: any) => {
    console.log(`  ✓ ${table.name}`);
  });

  console.log("");
  console.log("🎉 Learning path optimization system is ready!");

  db.close();
} catch (error) {
  console.error("❌ Migration failed:", error);
  process.exit(1);
}

