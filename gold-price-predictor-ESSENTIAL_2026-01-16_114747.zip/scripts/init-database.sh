#!/bin/bash
# ============================================
# Database Initialization Script
# ============================================
# This script initializes the database with required tables and data

set -e

echo "🚀 Starting database initialization..."

# Wait for PostgreSQL to be ready
echo "⏳ Waiting for PostgreSQL to be ready..."
until PGPASSWORD=${POSTGRES_PASSWORD:-postgres} psql -h "${POSTGRES_HOST:-localhost}" -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-gold_predictor}" -c '\q' 2>/dev/null; do
  echo "PostgreSQL is unavailable - sleeping"
  sleep 1
done

echo "✅ PostgreSQL is ready!"

# Run Alembic migrations
echo "📦 Running database migrations..."
cd backend
alembic upgrade head

# Seed initial data (if needed)
if [ -f "scripts/seed-data.py" ]; then
    echo "🌱 Seeding initial data..."
    python scripts/seed-data.py
fi

echo "✅ Database initialization complete!"

