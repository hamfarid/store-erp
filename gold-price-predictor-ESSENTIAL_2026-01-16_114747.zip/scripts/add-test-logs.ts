import { drizzle } from 'drizzle-orm/mysql2';
import { errorLogs, mlTrainingLogs, predictionLogs } from '../drizzle/schema';

async function main() {
  const db = drizzle(process.env.DATABASE_URL!);
  
  // Add test error logs
  await db.insert(errorLogs).values([
    {
      level: 'error',
      source: 'frontend',
      component: 'PredictPage',
      message: 'Test error: Failed to load prediction model',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    },
    {
      level: 'warn',
      source: 'backend',
      component: 'PythonAPI',
      message: 'Warning: Model accuracy below threshold',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
    },
    {
      level: 'info',
      source: 'system',
      component: 'MonitoringSystem',
      message: 'System health check completed successfully',
      timestamp: new Date(),
    },
  ]);
  
  // Add test ML training logs
  await db.insert(mlTrainingLogs).values([
    {
      assetId: 1, // Gold
      modelType: 'Ridge',
      trainScore: '0.9953',
      testScore: '0.9950',
      mape: '0.41',
      trainingDuration: 125,
      datasetSize: 2500,
      status: 'completed',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    },
    {
      assetId: 2, // Bitcoin
      modelType: 'LSTM',
      trainScore: '0.9827',
      testScore: '0.9800',
      mape: '0.44',
      trainingDuration: 450,
      datasetSize: 2500,
      status: 'completed',
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
    },
    {
      assetId: 3, // Ethereum
      modelType: 'Ensemble',
      trainScore: '0.9997',
      testScore: '0.9990',
      mape: '0.26',
      trainingDuration: 320,
      datasetSize: 2500,
      status: 'completed',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
    },
  ]);
  
  // Add test prediction logs
  await db.insert(predictionLogs).values([
    {
      assetId: 1,
      modelType: 'Ridge',
      executionTime: 45,
      userId: process.env.OWNER_OPEN_ID || '9rGBgymMj5UfpE45q89aiD',
      status: 'success',
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 mins ago
    },
    {
      assetId: 2,
      modelType: 'LSTM',
      executionTime: 120,
      userId: process.env.OWNER_OPEN_ID || '9rGBgymMj5UfpE45q89aiD',
      status: 'success',
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 mins ago
    },
    {
      assetId: 3,
      modelType: 'Ensemble',
      executionTime: 95,
      userId: process.env.OWNER_OPEN_ID || '9rGBgymMj5UfpE45q89aiD',
      status: 'success',
      timestamp: new Date(),
    },
  ]);
  
  console.log('✅ Test logs added successfully');
  console.log('   - 3 error logs');
  console.log('   - 3 ML training logs');
  console.log('   - 3 prediction logs');
  
  process.exit(0);
}

main().catch(console.error);

