# ============================================
# Gold Price Predictor - Complete Initialization & Start Script
# ============================================
# This script initializes and starts all services:
# - Database (PostgreSQL)
# - Cache (Redis)
# - Backend (FastAPI)
# - Frontend (Vite/React)
# - Monitoring (Prometheus, Grafana)

param(
    [Parameter(Mandatory=$false)]
    [switch]$SkipFrontend,
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipBackend,
    
    [Parameter(Mandatory=$false)]
    [switch]$Production
)

$ErrorActionPreference = "Stop"

# Change to project root
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Gold Price Predictor - Full Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check Docker
Write-Host "[1/7] Checking Docker..." -ForegroundColor Yellow
try {
    docker ps > $null 2>&1
    Write-Host "✓ Docker is running" -ForegroundColor Green
} catch {
    Write-Host "✗ ERROR: Docker is not running!" -ForegroundColor Red
    Write-Host "Please start Docker Desktop and try again." -ForegroundColor Yellow
    exit 1
}

# Step 2: Check/Create .env file
Write-Host "[2/7] Checking environment configuration..." -ForegroundColor Yellow
if (-not (Test-Path ".env")) {
    if (Test-Path "env.example") {
        Write-Host "Creating .env from env.example..." -ForegroundColor Gray
        Copy-Item "env.example" ".env"
        Write-Host "✓ Created .env file" -ForegroundColor Green
        Write-Host "⚠ Please review and update .env with your configuration" -ForegroundColor Yellow
    } else {
        Write-Host "⚠ Warning: No .env or env.example found" -ForegroundColor Yellow
    }
} else {
    Write-Host "✓ .env file exists" -ForegroundColor Green
}

# Step 3: Build Docker images (if needed)
Write-Host "[3/7] Building Docker images..." -ForegroundColor Yellow
$composeFile = if ($Production) { "docker-compose.production.yml" } else { "docker-compose.yml" }
try {
    docker compose -f $composeFile build --no-cache:$false
    Write-Host "✓ Docker images ready" -ForegroundColor Green
} catch {
    Write-Host "⚠ Warning: Some images may need to be built" -ForegroundColor Yellow
}

# Step 4: Start Docker containers
Write-Host "[4/7] Starting Docker containers..." -ForegroundColor Yellow
try {
    docker compose -f $composeFile up -d
    Write-Host "✓ Containers started" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed to start containers!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

# Step 5: Wait for services to be ready
Write-Host "[5/7] Waiting for services to be ready..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

# Check PostgreSQL
Write-Host "  Checking PostgreSQL..." -ForegroundColor Gray
$maxRetries = 30
$retryCount = 0
$postgresReady = $false

while ($retryCount -lt $maxRetries -and -not $postgresReady) {
    try {
        $result = docker exec gold-predictor-db pg_isready -U postgres 2>&1
        if ($LASTEXITCODE -eq 0) {
            $postgresReady = $true
            Write-Host "  ✓ PostgreSQL is ready" -ForegroundColor Green
        }
    } catch {
        # Continue waiting
    }
    
    if (-not $postgresReady) {
        Start-Sleep -Seconds 2
        $retryCount++
        Write-Host "  Waiting for PostgreSQL... ($retryCount/$maxRetries)" -ForegroundColor Gray
    }
}

if (-not $postgresReady) {
    Write-Host "  ⚠ Warning: PostgreSQL may not be fully ready" -ForegroundColor Yellow
}

# Check Redis
Write-Host "  Checking Redis..." -ForegroundColor Gray
try {
    $result = docker exec gold-predictor-redis redis-cli ping 2>&1
    if ($result -match "PONG") {
        Write-Host "  ✓ Redis is ready" -ForegroundColor Green
    }
} catch {
    Write-Host "  ⚠ Warning: Redis may not be fully ready" -ForegroundColor Yellow
}

# Step 6: Initialize Database
Write-Host "[6/7] Initializing database..." -ForegroundColor Yellow
try {
    # Run database initialization inside backend container
    docker exec -it gold-predictor-backend bash -c "cd /app && python -m alembic upgrade head" 2>&1 | Out-Null
    Write-Host "✓ Database initialized" -ForegroundColor Green
} catch {
    Write-Host "⚠ Warning: Database initialization may have issues" -ForegroundColor Yellow
    Write-Host "  You can manually run: docker exec -it gold-predictor-backend alembic upgrade head" -ForegroundColor Gray
}

# Step 7: Start Frontend (if not skipped)
if (-not $SkipFrontend) {
    Write-Host "[7/7] Starting Frontend..." -ForegroundColor Yellow
    
    # Check if node_modules exists
    if (-not (Test-Path "node_modules")) {
        Write-Host "  Installing frontend dependencies..." -ForegroundColor Gray
        npm install
    }
    
    Write-Host "  Starting frontend dev server..." -ForegroundColor Gray
    Write-Host "  (This will run in background)" -ForegroundColor Gray
    
    # Start frontend in new window
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$projectRoot'; npm run dev"
    
    Write-Host "✓ Frontend starting..." -ForegroundColor Green
} else {
    Write-Host "[7/7] Skipping Frontend (use: npm run dev)" -ForegroundColor Yellow
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Service URLs:" -ForegroundColor Cyan
Write-Host "  Frontend:         http://localhost:5173" -ForegroundColor Yellow
Write-Host "  Backend API:      http://localhost:2005" -ForegroundColor Yellow
Write-Host "  API Docs:         http://localhost:2005/docs" -ForegroundColor Yellow
Write-Host "  Prometheus:       http://localhost:9090" -ForegroundColor Yellow
Write-Host "  Grafana:          http://localhost:2505" -ForegroundColor Yellow
Write-Host ""
Write-Host "Container Status:" -ForegroundColor Cyan
docker compose -f $composeFile ps
Write-Host ""
Write-Host "Useful Commands:" -ForegroundColor Cyan
Write-Host "  View logs:        docker compose -f $composeFile logs -f" -ForegroundColor Gray
Write-Host "  Stop all:          .\scripts\stop.ps1" -ForegroundColor Gray
Write-Host "  Restart backend:   docker compose -f $composeFile restart backend" -ForegroundColor Gray
Write-Host "  Database shell:    docker exec -it gold-predictor-db psql -U postgres -d gold_predictor" -ForegroundColor Gray
Write-Host ""

