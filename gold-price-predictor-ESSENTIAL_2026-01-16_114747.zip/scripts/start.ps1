# FILE: scripts/start.ps1 | PURPOSE: Quick start script | OWNER: DevOps Team | RELATED: docker-compose.production.yml | LAST-AUDITED: 2025-11-27

<#
.SYNOPSIS
    Quick start script for Gold Price Predictor

.DESCRIPTION
    Starts all services using Docker Compose

.PARAMETER Production
    Start production configuration

.PARAMETER Development
    Start development configuration (default)

.EXAMPLE
    .\scripts\start.ps1
    .\scripts\start.ps1 -Production
#>

param(
    [Parameter(Mandatory=$false)]
    [switch]$Production,

    [Parameter(Mandatory=$false)]
    [switch]$Development
)

$ErrorActionPreference = "Stop"

# Change to project root
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Gold Price Predictor - Quick Start" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Determine compose file
$composeFile = if ($Production) {
    "docker-compose.production.yml"
} else {
    "docker-compose.yml"
}

$envType = if ($Production) { "Production" } else { "Development" }

Write-Host "Starting $envType environment..." -ForegroundColor Yellow
Write-Host "Using: $composeFile" -ForegroundColor Gray
Write-Host ""

# Check if Docker is running
try {
    docker ps > $null 2>&1
} catch {
    Write-Host "ERROR: Docker is not running!" -ForegroundColor Red
    Write-Host "Please start Docker Desktop and try again." -ForegroundColor Yellow
    exit 1
}

# Start services
Write-Host "Starting services..." -ForegroundColor Yellow
try {
    docker compose -f $composeFile up -d
    Write-Host "✓ Services started successfully!" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed to start services!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Waiting for services to be ready..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Check service status
Write-Host ""
Write-Host "Service Status:" -ForegroundColor Cyan
docker compose -f $composeFile ps

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Services Started!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($Production) {
    Write-Host "Access URLs:" -ForegroundColor Cyan
    Write-Host "  Frontend (HTTP):  http://localhost:82" -ForegroundColor Yellow
    Write-Host "  Frontend (HTTPS): https://localhost:442" -ForegroundColor Yellow
    Write-Host "  Backend API:      http://localhost:2005" -ForegroundColor Yellow
    Write-Host "  Grafana:          http://localhost:3001" -ForegroundColor Yellow
} else {
    Write-Host "Access URLs:" -ForegroundColor Cyan
    Write-Host "  Frontend:         http://localhost:5173" -ForegroundColor Yellow
    Write-Host "  Backend API:      http://localhost:2005" -ForegroundColor Yellow
    Write-Host "  API Docs:         http://localhost:2005/docs" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Useful Commands:" -ForegroundColor Cyan
Write-Host "  View logs:    docker compose -f $composeFile logs -f" -ForegroundColor Gray
Write-Host "  Stop:         .\scripts\stop.ps1" -ForegroundColor Gray
Write-Host "  Restart:      docker compose -f $composeFile restart" -ForegroundColor Gray
Write-Host ""
