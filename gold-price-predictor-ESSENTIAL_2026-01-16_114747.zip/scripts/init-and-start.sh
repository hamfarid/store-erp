#!/bin/bash
# ============================================
# Gold Price Predictor - Complete Initialization & Start Script
# ============================================
# This script initializes and starts all services:
# - Database (PostgreSQL)
# - Cache (Redis)
# - Backend (FastAPI)
# - Frontend (Vite/React)
# - Monitoring (Prometheus, Grafana)

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
GRAY='\033[0;37m'
NC='\033[0m' # No Color

# Parse arguments
SKIP_FRONTEND=false
SKIP_BACKEND=false
PRODUCTION=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-frontend)
            SKIP_FRONTEND=true
            shift
            ;;
        --skip-backend)
            SKIP_BACKEND=true
            shift
            ;;
        --production)
            PRODUCTION=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Change to project root
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PROJECT_ROOT"

echo ""
echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}Gold Price Predictor - Full Setup${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# Step 1: Check Docker
echo -e "${YELLOW}[1/7] Checking Docker...${NC}"
if ! docker ps > /dev/null 2>&1; then
    echo -e "${RED}✗ ERROR: Docker is not running!${NC}"
    echo -e "${YELLOW}Please start Docker and try again.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Docker is running${NC}"

# Step 2: Check/Create .env file
echo -e "${YELLOW}[2/7] Checking environment configuration...${NC}"
if [ ! -f ".env" ]; then
    if [ -f "env.example" ]; then
        echo -e "${GRAY}Creating .env from env.example...${NC}"
        cp env.example .env
        echo -e "${GREEN}✓ Created .env file${NC}"
        echo -e "${YELLOW}⚠ Please review and update .env with your configuration${NC}"
    else
        echo -e "${YELLOW}⚠ Warning: No .env or env.example found${NC}"
    fi
else
    echo -e "${GREEN}✓ .env file exists${NC}"
fi

# Step 3: Build Docker images (if needed)
echo -e "${YELLOW}[3/7] Building Docker images...${NC}"
COMPOSE_FILE="docker-compose.yml"
if [ "$PRODUCTION" = true ]; then
    COMPOSE_FILE="docker-compose.production.yml"
fi

if docker compose -f "$COMPOSE_FILE" build --no-cache 2>&1 | grep -q "error"; then
    echo -e "${YELLOW}⚠ Warning: Some images may need to be built${NC}"
else
    echo -e "${GREEN}✓ Docker images ready${NC}"
fi

# Step 4: Start Docker containers
echo -e "${YELLOW}[4/7] Starting Docker containers...${NC}"
if ! docker compose -f "$COMPOSE_FILE" up -d; then
    echo -e "${RED}✗ Failed to start containers!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Containers started${NC}"

# Step 5: Wait for services to be ready
echo -e "${YELLOW}[5/7] Waiting for services to be ready...${NC}"
sleep 15

# Check PostgreSQL
echo -e "${GRAY}  Checking PostgreSQL...${NC}"
MAX_RETRIES=30
RETRY_COUNT=0
POSTGRES_READY=false

while [ $RETRY_COUNT -lt $MAX_RETRIES ] && [ "$POSTGRES_READY" = false ]; do
    if docker exec gold-predictor-db pg_isready -U postgres > /dev/null 2>&1; then
        POSTGRES_READY=true
        echo -e "${GREEN}  ✓ PostgreSQL is ready${NC}"
    else
        RETRY_COUNT=$((RETRY_COUNT + 1))
        echo -e "${GRAY}  Waiting for PostgreSQL... ($RETRY_COUNT/$MAX_RETRIES)${NC}"
        sleep 2
    fi
done

if [ "$POSTGRES_READY" = false ]; then
    echo -e "${YELLOW}  ⚠ Warning: PostgreSQL may not be fully ready${NC}"
fi

# Check Redis
echo -e "${GRAY}  Checking Redis...${NC}"
if docker exec gold-predictor-redis redis-cli ping 2>&1 | grep -q "PONG"; then
    echo -e "${GREEN}  ✓ Redis is ready${NC}"
else
    echo -e "${YELLOW}  ⚠ Warning: Redis may not be fully ready${NC}"
fi

# Step 6: Initialize Database
echo -e "${YELLOW}[6/7] Initializing database...${NC}"
if docker exec gold-predictor-backend bash -c "cd /app && python -m alembic upgrade head" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Database initialized${NC}"
else
    echo -e "${YELLOW}⚠ Warning: Database initialization may have issues${NC}"
    echo -e "${GRAY}  You can manually run: docker exec -it gold-predictor-backend alembic upgrade head${NC}"
fi

# Step 7: Start Frontend (if not skipped)
if [ "$SKIP_FRONTEND" = false ]; then
    echo -e "${YELLOW}[7/7] Starting Frontend...${NC}"
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        echo -e "${GRAY}  Installing frontend dependencies...${NC}"
        npm install
    fi
    
    echo -e "${GRAY}  Starting frontend dev server...${NC}"
    echo -e "${GRAY}  (This will run in background)${NC}"
    
    # Start frontend in background
    npm run dev > /dev/null 2>&1 &
    FRONTEND_PID=$!
    echo $FRONTEND_PID > .frontend.pid
    
    echo -e "${GREEN}✓ Frontend starting (PID: $FRONTEND_PID)${NC}"
else
    echo -e "${YELLOW}[7/7] Skipping Frontend (use: npm run dev)${NC}"
fi

# Summary
echo ""
echo -e "${CYAN}========================================${NC}"
echo -e "${GREEN}Setup Complete!${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo -e "${CYAN}Service URLs:${NC}"
echo -e "${YELLOW}  Frontend:         http://localhost:5173${NC}"
echo -e "${YELLOW}  Backend API:      http://localhost:2005${NC}"
echo -e "${YELLOW}  API Docs:         http://localhost:2005/docs${NC}"
echo -e "${YELLOW}  Prometheus:       http://localhost:9090${NC}"
echo -e "${YELLOW}  Grafana:          http://localhost:2505${NC}"
echo ""
echo -e "${CYAN}Container Status:${NC}"
docker compose -f "$COMPOSE_FILE" ps
echo ""
echo -e "${CYAN}Useful Commands:${NC}"
echo -e "${GRAY}  View logs:        docker compose -f $COMPOSE_FILE logs -f${NC}"
echo -e "${GRAY}  Stop all:          ./scripts/stop.sh${NC}"
echo -e "${GRAY}  Restart backend:   docker compose -f $COMPOSE_FILE restart backend${NC}"
echo -e "${GRAY}  Database shell:    docker exec -it gold-predictor-db psql -U postgres -d gold_predictor${NC}"
echo ""

