// File: /home/ubuntu/asset_predictor_ui/client/src/providers/ThemeProvider.tsx
import { MantineProvider, ColorSchemeScript, createTheme } from '@mantine/core';
import { useLocalStorage } from '@mantine/hooks';
import '@mantine/core/styles.css';

const theme = createTheme({
  primaryColor: 'blue',
  fontFamily: 'Inter, sans-serif',
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [colorScheme, setColorScheme] = useLocalStorage<'light' | 'dark'>({
    key: 'color-scheme',
    defaultValue: 'light',
  });

  const toggleColorScheme = () => {
    setColorScheme(colorScheme === 'dark' ? 'light' : 'dark');
  };

  return (
    <>
      <ColorSchemeScript defaultColorScheme="light" />
      <MantineProvider theme={theme} defaultColorScheme={colorScheme}>
        <div data-theme={colorScheme}>
          {children}
        </div>
      </MantineProvider>
    </>
  );
}

export { useLocalStorage };

