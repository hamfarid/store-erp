import { NotificationToastProvider } from "@/components/notifications";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Predict from "./pages/Predict";
import Settings from "./pages/Settings";
import SettingsPage from "./pages/SettingsPage";
import PredictionHistory from "./pages/PredictionHistory";
import Alerts from "./pages/Alerts";
import Logs from "./pages/Logs";
import AssetsList from "./pages/AssetsList";
import AssetsCreate from "./pages/AssetsCreate";
import AssetsEdit from "./pages/AssetsEdit";
import AssetsView from "./pages/AssetsView";
import PredictionsView from "./pages/PredictionsView";
import AlertsView from "./pages/AlertsView";
import AlertsEdit from "./pages/AlertsEdit";
import HistoricalPricesList from "./pages/HistoricalPricesList";
import UsersView from "./pages/UsersView";
import PermissionsManagement from "./pages/PermissionsManagement";
import Error403 from "./pages/Error403";
import Error500 from "./pages/Error500";
import Maintenance from "./pages/Maintenance";
import ErrorPage from "./pages/ErrorPage";
// Import all error pages
import {
  Error400,
  Error401,
  Error402,
  Error405,
  Error501,
  Error502,
  Error503,
  Error504,
  Error505,
  Error506,
} from "./pages/errors";
import About from "./pages/About";
import Help from "./pages/Help";
import TradingSignals from "./pages/TradingSignals";
import BreakEvenCalculator from "./pages/BreakEvenCalculator";
import Portfolio from "./pages/Portfolio";
import PortfolioDetails from "./pages/PortfolioDetails";
import AITasks from "./pages/AITasks";
import PredictionAccuracy from "./pages/PredictionAccuracy";
import DashboardEnhanced from "./pages/DashboardEnhanced";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserProfile from "./pages/UserProfile";
import { ChatWidget } from "./components/AIAssistant/ChatWidget";
import { Navigation } from "./components/Navigation";
import MobileNav from "./components/MobileNav";
import AdminUsers from "./pages/AdminUsers";
import AdminAssets from "./pages/AdminAssets";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogs from "./pages/AdminLogs";
import Reports from "./pages/Reports";
import ReportsSetup from "./pages/ReportsSetup";
import ModelTraining from "./pages/ModelTraining";
import ThreeLevelPredictions from "./pages/ThreeLevelPredictions";
import BackupManagementAdvanced from "./pages/BackupManagementAdvanced";
import AILearningManagement from "./pages/AILearningManagement";
import LearningMonitoring from "./pages/LearningMonitoring";
import PriceAnalytics from "./pages/PriceAnalytics";
import ComprehensiveManagement from "./pages/ComprehensiveManagement";
import ModelPerformance from "./pages/ModelPerformance";
import TrainingMonitor from "./pages/TrainingMonitor";
import DriftDetection from "./pages/DriftDetection";
import ExpertOpinions from "./pages/ExpertOpinions";
import Factors from "./pages/Factors";
import Investment from "./pages/Investment";
import Learning from "./pages/Learning";
import LearningPathOptimizer from "./pages/LearningPathOptimizer";
import Predictions from "./pages/Predictions";
import Resources from "./pages/Resources";
import DataManagement from "./pages/DataManagement";
import ModelEvaluation from "./pages/ModelEvaluation";
import BackupManagement from "./pages/BackupManagement";
import Notifications from "./pages/Notifications";
import TechnicalAnalysis from "./pages/TechnicalAnalysis";
import AnalyticsMonitoring from "./pages/AnalyticsMonitoring";
import PricePoints from "./pages/PricePoints";
import MLModels from "./pages/MLModels";
import SystemHealth from "./pages/SystemHealth";
import SecurityDashboard from "./pages/SecurityDashboard";
import FearGreedIndex from "./pages/FearGreedIndex";
import NewsSentiment from "./pages/NewsSentiment";
import LearningControlDashboard from "./pages/LearningControlDashboard";
// New Admin CRUD Pages
import UsersListNew from "./pages/admin/UsersList";
import UserFormNew from "./pages/admin/UserForm";
import AssetsListNew from "./pages/admin/AssetsList";
import AssetsFormNew from "./pages/admin/AssetsForm";
import AlertsListNew from "./pages/admin/AlertsList";
import AlertsFormNew from "./pages/admin/AlertsForm";
import { AdminRoute } from "./components/AdminRoute";
import { ProtectedRoute } from "./components/ProtectedRoute";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/login"} component={Login} />
      <Route path={"/register"} component={Register} />
      <Route path={"/profile"} component={UserProfile} />
      <Route path={"/dashboard"} component={DashboardEnhanced} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/backup" component={BackupManagementAdvanced} />
      <Route path={"/admin/ai-learning"} component={AILearningManagement} />
      <Route
        path={"/admin/learning-monitoring"}
        component={LearningMonitoring}
      />
      <Route path="/analytics" component={PriceAnalytics} />
      <Route path="/comprehensive" component={ComprehensiveManagement} />{" "}
      <Route path={"/admin/assets"} component={AdminAssets} />
      <Route path={"/admin/logs"} component={AdminLogs} />
      <Route path={"/reports"} component={Reports} />
      <Route path={"/reports/setup"} component={ReportsSetup} />
      <Route path={"/predict/:id"} component={Predict} />
      <Route path={"/history"} component={PredictionHistory} />
      <Route path={"/alerts"} component={Alerts} />
      <Route path={"/logs"} component={Logs} />
      <Route path={"/settings"} component={Settings} />
      <Route path={"/settings-page"} component={SettingsPage} />
      <Route path={"/assets"} component={AssetsList} />
      <Route path={"/assets/create"} component={AssetsCreate} />
      <Route path={"/assets/edit/:id"} component={AssetsEdit} />
      <Route path={"/assets/view/:id"} component={AssetsView} />
      <Route path={"/predictions/view/:id"} component={PredictionsView} />
      <Route path={"/alerts/view/:id"} component={AlertsView} />
      <Route path={"/alerts/edit/:id"} component={AlertsEdit} />
      <Route path={"/historical-prices"} component={HistoricalPricesList} />
      {/* New Admin CRUD Routes - Protected */}
      <Route
        path={"/admin/users"}
        component={() => (
          <AdminRoute>
            <UsersListNew />
          </AdminRoute>
        )}
      />
      <Route
        path={"/admin/users/create"}
        component={() => (
          <AdminRoute>
            <UserFormNew />
          </AdminRoute>
        )}
      />
      <Route
        path={"/admin/users/:id"}
        component={() => (
          <AdminRoute>
            <UserFormNew />
          </AdminRoute>
        )}
      />
      <Route
        path={"/admin/assets"}
        component={() => (
          <AdminRoute>
            <AssetsListNew />
          </AdminRoute>
        )}
      />
      <Route
        path={"/admin/assets/create"}
        component={() => (
          <AdminRoute>
            <AssetsFormNew />
          </AdminRoute>
        )}
      />
      <Route
        path={"/admin/assets/:id"}
        component={() => (
          <AdminRoute>
            <AssetsFormNew />
          </AdminRoute>
        )}
      />
      {/* Alerts Routes - Protected (non-admin users can view their own alerts) */}
      <Route
        path={"/alerts"}
        component={() => (
          <ProtectedRoute>
            <AlertsListNew />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/alerts/create"}
        component={() => (
          <ProtectedRoute>
            <AlertsFormNew />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/alerts/:id"}
        component={() => (
          <ProtectedRoute>
            <AlertsFormNew />
          </ProtectedRoute>
        )}
      />
      {/* Additional Feature Pages */}
      <Route path={"/notifications"} component={Notifications} />
      <Route path={"/technical-analysis"} component={TechnicalAnalysis} />
      <Route path={"/analytics-monitoring"} component={AnalyticsMonitoring} />
      <Route path={"/price-points"} component={PricePoints} />
      <Route path={"/ml-models"} component={MLModels} />
      <Route path={"/system-health"} component={SystemHealth} />
      <Route path={"/security"}>
        <AdminRoute>
          <SecurityDashboard />
        </AdminRoute>
      </Route>
      <Route path={"/drift-detection"} component={DriftDetection} />
      <Route path={"/fear-greed"} component={FearGreedIndex} />
      <Route path={"/news-sentiment"} component={NewsSentiment} />
      <Route path={"/expert-opinions"} component={ExpertOpinions} />
      <Route path={"/learning-control"} component={LearningControlDashboard} />
      <Route path={"/factors"} component={Factors} />
      <Route path={"/investment"} component={Investment} />
      <Route path={"/learning"} component={Learning} />
      <Route path={"/learning-path"} component={LearningPathOptimizer} />
      <Route path={"/predictions"} component={Predictions} />
      <Route path={"/resources"} component={Resources} />
      <Route path={"/data-management"} component={DataManagement} />
      <Route path={"/model-evaluation"} component={ModelEvaluation} />
      <Route path={"/backup"} component={BackupManagement} />
      {/* Old routes - keep for backward compatibility */}
      <Route path={"/admin/users/view/:id"} component={UsersView} />
      <Route
        path={"/admin/users/:userId/permissions"}
        component={PermissionsManagement}
      />
      {/* Error Pages - Specific routes must come before catch-all */}
      <Route path={"/error/400"} component={Error400} />
      <Route path={"/error/401"} component={Error401} />
      <Route path={"/error/402"} component={Error402} />
      <Route path={"/error/403"} component={Error403} />
      <Route path={"/error/404"} component={NotFound} />
      <Route path={"/error/405"} component={Error405} />
      <Route path={"/error/500"} component={Error500} />
      <Route path={"/error/501"} component={Error501} />
      <Route path={"/error/502"} component={Error502} />
      <Route path={"/error/503"} component={Error503} />
      <Route path={"/error/504"} component={Error504} />
      <Route path={"/error/505"} component={Error505} />
      <Route path={"/error/506"} component={Error506} />
      {/* Catch-all for other error codes */}
      <Route path={"/error/:code"} component={ErrorPage} />
      {/* Legacy error routes */}
      <Route path={"/400"} component={Error400} />
      <Route path={"/401"} component={Error401} />
      <Route path={"/402"} component={Error402} />
      <Route path={"/403"} component={Error403} />
      <Route path={"/404"} component={NotFound} />
      <Route path={"/405"} component={Error405} />
      <Route path={"/500"} component={Error500} />
      <Route path={"/501"} component={Error501} />
      <Route path={"/502"} component={Error502} />
      <Route path={"/503"} component={Error503} />
      <Route path={"/504"} component={Error504} />
      <Route path={"/505"} component={Error505} />
      <Route path={"/maintenance"} component={Maintenance} />
      <Route path={"/about"} component={About} />
      <Route path={"/help"} component={Help} />
      <Route path={"/trading-signals"} component={TradingSignals} />
      <Route path={"/break-even-calculator"} component={BreakEvenCalculator} />
      <Route path={"/portfolio"} component={Portfolio} />
      <Route path={"/portfolio/:id"} component={PortfolioDetails} />
      <Route path={"/ai-tasks"} component={AITasks} />
      <Route path={"/prediction-accuracy"} component={PredictionAccuracy} />
      <Route path={"/admin/train-models"} component={ModelTraining} />
      <Route path={"/admin/model-performance"} component={ModelPerformance} />
      <Route path={"/admin/training-monitor"} component={TrainingMonitor} />
      <Route
        path={"/predictions/three-level"}
        component={ThreeLevelPredictions}
      />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <NotificationToastProvider />
          <Navigation />
          <Router />
          <ChatWidget />
          <MobileNav />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
