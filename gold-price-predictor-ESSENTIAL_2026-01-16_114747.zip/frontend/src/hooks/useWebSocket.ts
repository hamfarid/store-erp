/**
 * FILE: client/src/hooks/useWebSocket.ts
 * PURPOSE: React hook for WebSocket connection with auto-reconnect and message queuing
 * OWNER: Frontend Team
 * RELATED: server/_core/websocket.ts
 * LAST-AUDITED: 2025-12-18
 */

import { useEffect, useRef, useState, useCallback } from "react";

export interface WebSocketMessage {
  type: string;
  channel?: string;
  data?: unknown;
  timestamp: string;
}

export interface UseWebSocketOptions {
  url?: string;
  autoConnect?: boolean;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
  onMessage?: (message: WebSocketMessage) => void;
  onError?: (error: Event) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const {
    url,
    autoConnect = true,
    reconnectInterval = 3000,
    maxReconnectAttempts = 10,
    onMessage,
    onError,
    onOpen,
    onClose,
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const messageQueueRef = useRef<WebSocketMessage[]>([]);
  const shouldReconnectRef = useRef(true);
  const channelHandlersRef = useRef<Map<string, Set<(message: WebSocketMessage) => void>>>(new Map());

  // Determine WebSocket URL
  const getWebSocketUrl = useCallback(() => {
    if (url) {return url;}
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    return `${protocol}//${host}/ws`;
  }, [url]);

  // Send message helper
  const sendMessage = useCallback((message: Omit<WebSocketMessage, "timestamp">) => {
    const fullMessage: WebSocketMessage = {
      ...message,
      timestamp: new Date().toISOString(),
    };

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(fullMessage));
    } else {
      // Queue message until connection is open
      messageQueueRef.current.push(fullMessage);
    }
  }, []);

  // Subscribe to channel with callback (returns unsubscribe function)
  const subscribe = useCallback((channel: string, callback: (message: WebSocketMessage) => void) => {
    // Add handler
    if (!channelHandlersRef.current.has(channel)) {
      channelHandlersRef.current.set(channel, new Set());
    }
    channelHandlersRef.current.get(channel)!.add(callback);

    // Send subscribe message to server
    sendMessage({
      type: "subscribe",
      channel,
    });

    // Return unsubscribe function
    return () => {
      const handlers = channelHandlersRef.current.get(channel);
      if (handlers) {
        handlers.delete(callback);
        if (handlers.size === 0) {
          channelHandlersRef.current.delete(channel);
          // Send unsubscribe message to server
          sendMessage({
            type: "unsubscribe",
            channel,
          });
        }
      }
    };
  }, [sendMessage]);

  // Unsubscribe from channel (simple version)
  const unsubscribe = useCallback((channel: string) => {
    channelHandlersRef.current.delete(channel);
    sendMessage({
      type: "unsubscribe",
      channel,
    });
  }, [sendMessage]);

  // Authenticate with JWT token
  const authenticate = useCallback((token: string) => {
    sendMessage({
      type: "auth",
      data: { token },
    });
  }, [sendMessage]);

  // Connect to WebSocket
  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    const wsUrl = getWebSocketUrl();
    console.log("[WebSocket] Connecting to:", wsUrl);

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log("[WebSocket] Connected");
        setIsConnected(true);
        reconnectAttemptsRef.current = 0;
        shouldReconnectRef.current = true;

        // Send queued messages
        while (messageQueueRef.current.length > 0) {
          const queuedMessage = messageQueueRef.current.shift();
          if (queuedMessage && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(queuedMessage));
          }
        }

        onOpen?.();
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          setLastMessage(message);
          onMessage?.(message);

          // Call channel-specific handlers
          if (message.channel) {
            const handlers = channelHandlersRef.current.get(message.channel);
            if (handlers) {
              handlers.forEach((handler) => handler(message));
            }
          }
        } catch (error) {
          console.error("[WebSocket] Error parsing message:", error);
        }
      };

      ws.onerror = (error) => {
        console.error("[WebSocket] Error:", error);
        onError?.(error);
      };

      ws.onclose = () => {
        console.log("[WebSocket] Disconnected");
        setIsConnected(false);
        onClose?.();

        // Attempt to reconnect if should reconnect
        if (shouldReconnectRef.current && reconnectAttemptsRef.current < maxReconnectAttempts) {
          const backoffDelay = Math.min(
            reconnectInterval * Math.pow(2, reconnectAttemptsRef.current),
            30000 // Max 30 seconds
          );

          reconnectAttemptsRef.current++;
          console.log(
            `[WebSocket] Reconnecting in ${backoffDelay}ms (attempt ${reconnectAttemptsRef.current}/${maxReconnectAttempts})`
          );

          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, backoffDelay);
        } else if (reconnectAttemptsRef.current >= maxReconnectAttempts) {
          console.error("[WebSocket] Max reconnect attempts reached");
        }
      };
    } catch (error) {
      console.error("[WebSocket] Failed to create connection:", error);
      setIsConnected(false);
    }
  }, [getWebSocketUrl, reconnectInterval, maxReconnectAttempts, onMessage, onError, onOpen, onClose]);

  // Disconnect from WebSocket
  const disconnect = useCallback(() => {
    shouldReconnectRef.current = false;
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  }, []);

  // Auto-connect on mount
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  // Alias sendMessage as send for compatibility
  const send = useCallback((message: Omit<WebSocketMessage, "timestamp">) => {
    sendMessage(message);
  }, [sendMessage]);

  return {
    isConnected,
    lastMessage,
    sendMessage,
    send, // Alias for compatibility
    subscribe,
    unsubscribe,
    authenticate,
    connect,
    disconnect,
    reconnectAttempts: reconnectAttemptsRef.current,
    maxReconnectAttempts,
  };
}
