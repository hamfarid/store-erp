/**
 * Error Handler Hook
 * Centralized error handling for API responses and network errors
 */

import { useCallback } from 'react';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

interface ErrorInfo {
  code: number;
  message: string;
  details?: string;
}

export function useErrorHandler() {
  const [, setLocation] = useLocation();

  const handleError = useCallback((error: any) => {
    console.error('[ErrorHandler]', error);

    // Extract error code
    let errorCode = 500;
    let errorMessage = 'حدث خطأ غير متوقع';

    if (error?.data?.httpStatus) {
      errorCode = error.data.httpStatus;
    } else if (error?.status) {
      errorCode = error.status;
    } else if (error?.code) {
      // TRPC error codes
      const trpcCodeMap: Record<string, number> = {
        'PARSE_ERROR': 400,
        'BAD_REQUEST': 400,
        'UNAUTHORIZED': 401,
        'PAYMENT_REQUIRED': 402,
        'FORBIDDEN': 403,
        'NOT_FOUND': 404,
        'METHOD_NOT_SUPPORTED': 405,
        'TIMEOUT': 504,
        'CONFLICT': 409,
        'PRECONDITION_FAILED': 412,
        'PAYLOAD_TOO_LARGE': 413,
        'UNPROCESSABLE_CONTENT': 422,
        'TOO_MANY_REQUESTS': 429,
        'CLIENT_CLOSED_REQUEST': 499,
        'INTERNAL_SERVER_ERROR': 500,
        'NOT_IMPLEMENTED': 501,
        'BAD_GATEWAY': 502,
        'SERVICE_UNAVAILABLE': 503,
        'GATEWAY_TIMEOUT': 504,
      };
      errorCode = trpcCodeMap[error.code] || 500;
    }

    // Get error message
    if (error?.message) {
      errorMessage = error.message;
    }

    // Handle "failed to fetch" error
    if (error?.message?.toLowerCase().includes('failed to fetch') || 
        error?.message?.toLowerCase().includes('network') ||
        error?.message?.toLowerCase().includes('fetch')) {
      errorCode = 503;
      errorMessage = 'فشل الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت.';
    }

    // Map error codes to messages
    const errorMessages: Record<number, string> = {
      400: 'طلب غير صالح',
      401: 'يجب تسجيل الدخول للوصول',
      402: 'الدفع مطلوب',
      403: 'ليس لديك صلاحية للوصول',
      404: 'الصفحة غير موجودة',
      405: 'الطريقة غير مسموحة',
      408: 'انتهت مهلة الطلب',
      409: 'تعارض في البيانات',
      422: 'بيانات غير صالحة',
      429: 'طلبات كثيرة جداً',
      500: 'خطأ في الخادم',
      501: 'الميزة غير متوفرة',
      502: 'بوابة غير صالحة',
      503: 'الخدمة غير متوفرة',
      504: 'انتهت مهلة الخادم',
      505: 'إصدار غير مدعوم',
      506: 'خطأ في التفاوض',
    };

    const displayMessage = errorMessages[errorCode] || errorMessage;

    // Show toast notification
    toast.error(displayMessage);

    return {
      code: errorCode,
      message: displayMessage,
      details: errorMessage,
    };
  }, []);

  const navigateToErrorPage = useCallback((errorCode: number) => {
    const errorRoutes: Record<number, string> = {
      400: '/error/400',
      401: '/error/401',
      402: '/error/402',
      403: '/error/403',
      404: '/error/404',
      405: '/error/405',
      500: '/error/500',
      501: '/error/501',
      502: '/error/502',
      503: '/error/503',
      504: '/error/504',
      505: '/error/505',
      506: '/error/506',
    };

    const route = errorRoutes[errorCode] || '/error/500';
    setLocation(route);
  }, [setLocation]);

  const handleApiError = useCallback((error: any, options?: { redirect?: boolean }) => {
    const errorInfo = handleError(error);
    
    if (options?.redirect) {
      navigateToErrorPage(errorInfo.code);
    }

    return errorInfo;
  }, [handleError, navigateToErrorPage]);

  return {
    handleError,
    handleApiError,
    navigateToErrorPage,
  };
}

export default useErrorHandler;

