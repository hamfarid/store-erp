/**
 * useTranslation Hook
 * React hook for accessing translations with language context
 *
 * Constitution Principle I: Arabic-First with RTL Excellence
 */

import { useCallback, useMemo } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import {
  translate,
  getDirection,
  formatNumber,
  formatCurrency,
  formatDate,
  formatRelativeTime,
  type Language,
} from '../lib/i18n';

interface UseTranslationReturn {
  /** Current language */
  language: Language;
  /** Set current language */
  setLanguage: (lang: Language) => void;
  /** Toggle between languages */
  toggleLanguage: () => void;
  /** Translation function */
  t: (key: string, params?: Record<string, string | number>) => string;
  /** Current text direction */
  dir: 'rtl' | 'ltr';
  /** Whether current language is RTL */
  isRtl: boolean;
  /** Format a number */
  formatNum: (value: number) => string;
  /** Format currency */
  formatCur: (value: number, currency?: string) => string;
  /** Format date */
  formatDt: (date: Date | string, options?: Intl.DateTimeFormatOptions) => string;
  /** Format relative time */
  formatRelative: (date: Date | string) => string;
}

/**
 * Hook for accessing i18n functionality
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { t, dir, formatCur } = useTranslation();
 *
 *   return (
 *     <div dir={dir}>
 *       <h1>{t('dashboard.title')}</h1>
 *       <p>{formatCur(1234.56)}</p>
 *     </div>
 *   );
 * }
 * ```
 */
export function useTranslation(): UseTranslationReturn {
  const { language, setLanguage, toggleLanguage } = useLanguage();

  const t = useCallback(
    (key: string, params?: Record<string, string | number>) => {
      return translate(key, language, params);
    },
    [language]
  );

  const dir = useMemo(() => getDirection(language), [language]);
  const isRtl = useMemo(() => language === 'ar', [language]);

  const formatNum = useCallback(
    (value: number) => formatNumber(value, language),
    [language]
  );

  const formatCur = useCallback(
    (value: number, currency: string = 'USD') =>
      formatCurrency(value, language, currency),
    [language]
  );

  const formatDt = useCallback(
    (date: Date | string, options?: Intl.DateTimeFormatOptions) =>
      formatDate(date, language, options),
    [language]
  );

  const formatRelative = useCallback(
    (date: Date | string) => formatRelativeTime(date, language),
    [language]
  );

  return {
    language,
    setLanguage,
    toggleLanguage,
    t,
    dir,
    isRtl,
    formatNum,
    formatCur,
    formatDt,
    formatRelative,
  };
}

export default useTranslation;
