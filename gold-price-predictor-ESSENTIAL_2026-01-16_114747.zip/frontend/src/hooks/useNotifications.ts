/**
 * useNotifications Hook - WebSocket-based Real-time Notifications
 * Part of Global Professional Core Prompt v23.0 Implementation
 * Task: T123 (Phase 5 - Alerts Frontend)
 */

import { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';

export interface Notification {
  id: string;
  type: 'alert' | 'insight' | 'system' | 'warning';
  title: string;
  titleAr: string;
  message: string;
  messageAr: string;
  isRead: boolean;
  createdAt: string;
  metadata?: {
    alertId?: string;
    assetId?: string;
    insightId?: string;
    currentPrice?: number;
    targetValue?: number;
  };
}

export interface AlertTriggeredPayload {
  alertId: string;
  assetId: string;
  assetName: string;
  assetNameAr: string;
  condition: 'gt' | 'lt' | 'eq' | 'gte' | 'lte';
  targetValue: number;
  currentPrice: number;
  triggeredAt: string;
}

interface UseNotificationsReturn {
  notifications: Notification[];
  unreadCount: number;
  isConnected: boolean;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  refetch: () => void;
}

/**
 * Hook to manage real-time notifications with WebSocket integration
 * 
 * Features:
 * - WebSocket connection for real-time updates
 * - Alert triggered notifications
 * - Toast notifications with Arabic RTL
 * - Unread count tracking
 * - Auto-reconnection with exponential backoff
 */
export function useNotifications(): UseNotificationsReturn {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isConnected, setIsConnected] = useState(false);

  // tRPC queries for initial data
  const { data: notificationsData, refetch } = trpc.notifications.getUserNotifications.useQuery(
    { limit: 50, offset: 0 },
    { enabled: isAuthenticated }
  );

  const { data: unreadData, refetch: refetchUnread } = trpc.notifications.getUnreadCount.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // tRPC mutations
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation({
    onSuccess: () => {
      refetch();
      refetchUnread();
    },
  });

  const markAllAsReadMutation = trpc.notifications.markAllAsRead.useMutation({
    onSuccess: () => {
      refetch();
      refetchUnread();
      toast.success('تم تعليم جميع الإشعارات كمقروءة');
    },
  });

  const deleteNotificationMutation = trpc.notifications.deleteNotification.useMutation({
    onSuccess: () => {
      refetch();
      refetchUnread();
    },
  });

  // Update local state when data changes
  useEffect(() => {
    if (notificationsData) {
      setNotifications(notificationsData as any[]);
    }
  }, [notificationsData]);

  useEffect(() => {
    if (unreadData) {
      setUnreadCount(unreadData.count || 0);
    }
  }, [unreadData]);

  // WebSocket connection (TODO: Implement when WebSocket service is ready)
  useEffect(() => {
    if (!isAuthenticated || !user) return;

    // Placeholder for WebSocket connection
    // This will be implemented when server WebSocket infrastructure is ready
    // Following ADR-003-websocket-architecture.md specifications
    
    /*
    const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3000';
    const socket = io(`${WS_URL}/notifications`, {
      auth: { token: localStorage.getItem('auth_token') },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 10,
    });

    socket.on('connect', () => {
      console.log('[WS] Connected to notifications namespace');
      setIsConnected(true);
      socket.emit('join:user', user.id);
    });

    socket.on('disconnect', () => {
      console.log('[WS] Disconnected from notifications');
      setIsConnected(false);
    });

    socket.on('connect_error', (err) => {
      console.error('[WS] Connection error:', err.message);
    });

    // Listen for new notifications
    socket.on('notification:new', (notification: Notification) => {
      setNotifications((prev) => [notification, ...prev]);
      setUnreadCount((prev) => prev + 1);
      
      // Show toast
      toast(notification.titleAr, {
        description: notification.messageAr,
        duration: 5000,
      });
    });

    // Listen for alert triggered events
    socket.on('alert:triggered', (alert: AlertTriggeredPayload) => {
      setUnreadCount((prev) => prev + 1);
      
      const conditionText = {
        gt: 'تجاوز',
        gte: 'وصل إلى',
        lt: 'انخفض عن',
        lte: 'وصل إلى',
        eq: 'يساوي',
      }[alert.condition] || 'تحقق';

      // Show special alert toast
      toast.warning('🔔 تم تفعيل التنبيه', {
        description: `${alert.assetNameAr} ${conditionText} ${alert.targetValue} (السعر الحالي: ${alert.currentPrice})`,
        duration: 10000,
        action: {
          label: 'عرض',
          onClick: () => {
            window.location.href = `/alerts/view/${alert.alertId}`;
          },
        },
      });
      
      // Refetch to get updated data
      refetch();
      refetchUnread();
    });

    return () => {
      socket.disconnect();
    };
    */

    // For now, use polling as fallback
    const pollInterval = setInterval(() => {
      refetch();
      refetchUnread();
    }, 30000); // Poll every 30 seconds

    return () => {
      clearInterval(pollInterval);
    };
  }, [isAuthenticated, user, refetch, refetchUnread]);

  // Handler functions
  const markAsRead = useCallback((id: string) => {
    markAsReadMutation.mutate({ id: parseInt(id) });
  }, [markAsReadMutation]);

  const markAllAsRead = useCallback(() => {
    markAllAsReadMutation.mutate();
  }, [markAllAsReadMutation]);

  const deleteNotification = useCallback((id: string) => {
    deleteNotificationMutation.mutate({ id: parseInt(id) });
  }, [deleteNotificationMutation]);

  return {
    notifications,
    unreadCount,
    isConnected,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    refetch,
  };
}

/**
 * Utility function to format relative time in Arabic
 */
export function formatRelativeTime(date: string | Date): string {
  const now = new Date();
  const then = new Date(date);
  const diffMs = now.getTime() - then.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'الآن';
  if (diffMins === 1) return 'منذ دقيقة';
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  if (diffHours === 1) return 'منذ ساعة';
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;
  if (diffDays === 1) return 'منذ يوم';
  if (diffDays < 30) return `منذ ${diffDays} يوم`;
  
  return then.toLocaleDateString('ar-EG');
}

/**
 * Get icon for notification type
 */
export function getNotificationIcon(type: Notification['type']): string {
  const icons = {
    alert: '🔔',
    insight: '📊',
    system: 'ℹ️',
    warning: '⚠️',
  };
  return icons[type] || 'ℹ️';
}

/**
 * Get color class for notification type
 */
export function getNotificationColor(type: Notification['type']): string {
  const colors = {
    alert: 'text-amber-600 dark:text-amber-400',
    insight: 'text-blue-600 dark:text-blue-400',
    system: 'text-gray-600 dark:text-gray-400',
    warning: 'text-red-600 dark:text-red-400',
  };
  return colors[type] || colors.system;
}
