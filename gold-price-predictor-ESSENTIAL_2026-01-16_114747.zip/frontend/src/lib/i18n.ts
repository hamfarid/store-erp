/**
 * i18n Configuration
 * Internationalization setup for Arabic-first multilingual support
 *
 * Constitution Principle I: Arabic-First with RTL Excellence
 */

import arLocale from '../locales/ar.json';
import enLocale from '../locales/en.json';

export type Language = 'ar' | 'en';

export type TranslationKey = string;

type NestedKeyOf<ObjectType extends object> = {
  [Key in keyof ObjectType & (string | number)]: ObjectType[Key] extends object
    ? `${Key}` | `${Key}.${NestedKeyOf<ObjectType[Key]>}`
    : `${Key}`;
}[keyof ObjectType & (string | number)];

type Translations = typeof arLocale;

const locales: Record<Language, Translations> = {
  ar: arLocale,
  en: enLocale,
};

/**
 * Get nested value from object using dot notation
 */
function getNestedValue(obj: Record<string, unknown>, path: string): string {
  const keys = path.split('.');
  let current: unknown = obj;

  for (const key of keys) {
    if (current && typeof current === 'object' && key in current) {
      current = (current as Record<string, unknown>)[key];
    } else {
      return path; // Return the key if translation not found
    }
  }

  return typeof current === 'string' ? current : path;
}

/**
 * Translate a key with optional interpolation
 * @param key - Translation key in dot notation (e.g., 'common.loading')
 * @param language - Target language
 * @param params - Optional parameters for interpolation
 */
export function translate(
  key: string,
  language: Language = 'ar',
  params?: Record<string, string | number>
): string {
  const locale = locales[language];
  let translation = getNestedValue(locale as unknown as Record<string, unknown>, key);

  // Handle interpolation (e.g., {{name}} -> value)
  if (params) {
    Object.entries(params).forEach(([paramKey, value]) => {
      translation = translation.replace(
        new RegExp(`{{${paramKey}}}`, 'g'),
        String(value)
      );
    });
  }

  return translation;
}

/**
 * Get all translations for a namespace
 */
export function getNamespace(namespace: keyof Translations, language: Language = 'ar'): Record<string, string> {
  return locales[language][namespace] as Record<string, string>;
}

/**
 * Check if a translation key exists
 */
export function hasTranslation(key: string, language: Language = 'ar'): boolean {
  const translation = getNestedValue(locales[language] as unknown as Record<string, unknown>, key);
  return translation !== key;
}

/**
 * Get RTL direction for language
 */
export function getDirection(language: Language): 'rtl' | 'ltr' {
  return language === 'ar' ? 'rtl' : 'ltr';
}

/**
 * Get locale code for date formatting
 */
export function getLocaleCode(language: Language): string {
  return language === 'ar' ? 'ar-SA' : 'en-US';
}

/**
 * Format number according to locale
 */
export function formatNumber(value: number, language: Language = 'ar'): string {
  return new Intl.NumberFormat(getLocaleCode(language)).format(value);
}

/**
 * Format currency according to locale
 */
export function formatCurrency(
  value: number,
  language: Language = 'ar',
  currency: string = 'USD'
): string {
  return new Intl.NumberFormat(getLocaleCode(language), {
    style: 'currency',
    currency,
  }).format(value);
}

/**
 * Format date according to locale
 */
export function formatDate(
  date: Date | string,
  language: Language = 'ar',
  options?: Intl.DateTimeFormatOptions
): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat(getLocaleCode(language), options).format(dateObj);
}

/**
 * Format relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(
  date: Date | string,
  language: Language = 'ar'
): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffMs = now.getTime() - dateObj.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  const rtf = new Intl.RelativeTimeFormat(getLocaleCode(language), {
    numeric: 'auto',
  });

  if (diffDays > 0) {
    return rtf.format(-diffDays, 'day');
  } else if (diffHours > 0) {
    return rtf.format(-diffHours, 'hour');
  } else if (diffMinutes > 0) {
    return rtf.format(-diffMinutes, 'minute');
  } else {
    return rtf.format(-diffSeconds, 'second');
  }
}

export default {
  translate,
  getNamespace,
  hasTranslation,
  getDirection,
  getLocaleCode,
  formatNumber,
  formatCurrency,
  formatDate,
  formatRelativeTime,
};
