// Placeholder file to fix TypeScript error
export default null;

