import { trpc } from "@/lib/trpc";
import { UNAUTHED_ERR_MSG } from '@shared/const';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { getLoginUrl } from "./const";
import "./index.css";

// Error message mappings for better UX
const ERROR_MESSAGES: Record<string, string> = {
  'Failed to fetch': 'فشل الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت.',
  'Network Error': 'خطأ في الشبكة. يرجى التحقق من اتصالك.',
  'UNAUTHORIZED': 'يجب تسجيل الدخول للوصول',
  'FORBIDDEN': 'ليس لديك صلاحية للوصول',
  'NOT_FOUND': 'المورد غير موجود',
  'INTERNAL_SERVER_ERROR': 'خطأ في الخادم',
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      refetchOnReconnect: false,
      retry: (failureCount, error) => {
        // Don't retry on auth errors
        if (error instanceof TRPCClientError) {
          const code = error.data?.code;
          if (code === 'UNAUTHORIZED' || code === 'FORBIDDEN') {
            return false;
          }
        }
        // Retry up to 2 times for other errors
        return failureCount < 2;
      },
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
    mutations: {
      retry: false, // Don't retry mutations
    },
  },
});

import { toast } from "sonner";

const handleError = (error: any) => {
  // Handle tRPC errors
  if (error instanceof TRPCClientError) {
    const message = error.message;
    const code = error.data?.code;

    // Check for network errors
    if (message === 'Failed to fetch' || message.includes('network')) {
      toast.error('فشل الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت.');
      return;
    }

    // Handle unauthorized errors
    if (code === 'UNAUTHORIZED' || message === UNAUTHED_ERR_MSG) {
      if (typeof window !== "undefined" && !window.location.pathname.includes('/login')) {
        toast.error('يجب تسجيل الدخول للوصول');
        setTimeout(() => {
          window.location.href = getLoginUrl();
        }, 1000);
      }
      return;
    }

    const displayText = ERROR_MESSAGES[code] || message || 'حدث خطأ غير متوقع';
    toast.error(displayText);
    return;
  }

  // Handle Axios/Generic errors
  const message = error?.response?.data?.message || error?.message || 'حدث خطأ غير متوقع';
  
  // Custom handling for 403 CSRF
  if (error?.response?.status === 403) {
     toast.error('Security Error: CSRF Token Missing or Invalid');
     return;
  }

  console.error("[API Error]", error);
  toast.error(message);
};

queryClient.getQueryCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    handleError(event.query.state.error);
  }
});

queryClient.getMutationCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    handleError(event.mutation.state.error);
  }
});

// Fetch with timeout and better error handling
const fetchWithTimeout = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout
  
  try {
    const response = await globalThis.fetch(input, {
      ...(init ?? {}),
      credentials: "include",
      signal: controller.signal,
    });
    return response;
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw new Error('Request timeout - الطلب استغرق وقتاً طويلاً');
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
};

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson as any,
      fetch: fetchWithTimeout,
    }),
  ],
});

createRoot(document.getElementById("root")!).render(
  <trpc.Provider client={trpcClient} queryClient={queryClient}>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </trpc.Provider>
);
