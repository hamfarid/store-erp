/**
 * FILE: client/src/pages/LearningControlDashboard.tsx
 * PURPOSE: Learning & Search Control Dashboard page
 * OWNER: Frontend Team
 * RELATED: server/routers/learning-control.ts, client/src/hooks/useWebSocket.ts
 * LAST-AUDITED: 2025-01-18
 */

import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import {
  Brain,
  Search,
  Activity,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Settings,
  Database,
  TrendingUp,
  BarChart3,
  X,
} from "lucide-react";
import { toast } from "sonner";

// ==================== Operation Card Component ====================

function OperationCard({
  operation,
  onViewDetails,
  onDelete,
  isSelected,
}: {
  operation: any;
  onViewDetails?: () => void;
  onDelete?: () => void;
  isSelected?: boolean;
}) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <RefreshCw className="w-4 h-4 animate-spin text-blue-500" />;
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-red-500" />;
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-500" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400";
      case "completed":
        return "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400";
      case "failed":
        return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400";
      case "pending":
        return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400";
      default:
        return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400";
    }
  };

  return (
    <Card className={isSelected ? "border-primary" : ""}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon(operation.status)}
            <CardTitle className="text-base">{operation.type}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={getStatusColor(operation.status)}>
              {operation.status}
            </Badge>
            {onViewDetails && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onViewDetails}
              >
                <Settings className="w-4 h-4" />
              </Button>
            )}
            {onDelete && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
        {operation.currentStep && (
          <CardDescription>{operation.currentStep}</CardDescription>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>التقدم</span>
            <span className="font-medium">{operation.progress || 0}%</span>
          </div>
          <Progress value={operation.progress || 0} />
          {operation.totalSteps && (
            <div className="text-xs text-muted-foreground">
              {operation.currentStep || "بدء العملية"} من {operation.totalSteps} خطوات
            </div>
          )}
          {operation.error && (
            <div className="text-xs text-red-500 mt-2">
              خطأ: {operation.error}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ==================== Overview Tab ====================

function OverviewTab() {
  const { data: stats } = trpc.learningControl.stats.get.useQuery();
  const { data: learningOps, refetch: refetchLearning } = trpc.learningControl.learning.active.useQuery();
  const { data: searchOps, refetch: refetchSearch } = trpc.learningControl.search.active.useQuery();

  const activeOps = [
    ...(learningOps || []),
    ...(searchOps || []),
  ].slice(0, 5);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              عمليات التعلم النشطة
            </CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeLearningOps || 0}</div>
            <p className="text-xs text-muted-foreground">
              من أصل {stats?.totalLearningOps || 0} عملية
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              عمليات البحث النشطة
            </CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeSearchOps || 0}</div>
            <p className="text-xs text-muted-foreground">
              من أصل {stats?.totalSearchOps || 0} عملية
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الكلمات المفتاحية</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.keywordsCount || 0}</div>
            <p className="text-xs text-muted-foreground">كلمة مفتاحية</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المصادر</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.sourcesCount || 0}</div>
            <p className="text-xs text-muted-foreground">مصدر</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>العمليات النشطة</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <div className="space-y-4">
              {activeOps.length > 0 ? (
                activeOps.map((op: any) => (
                  <OperationCard key={op.id} operation={op} />
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  لا توجد عمليات نشطة
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== Learning Operations Tab ====================

function LearningOperationsTab() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [selectedOperation, setSelectedOperation] = useState<string | null>(null);

  const { data: operations, refetch } = trpc.learningControl.learning.list.useQuery({
    status: (statusFilter !== "all" ? statusFilter : undefined) as any,
    type: (typeFilter !== "all" ? typeFilter : undefined) as any,
  });

  const { data: operationLogs } = trpc.learningControl.learning.getLogs.useQuery(
    { operationId: selectedOperation || "", limit: 50 },
    { enabled: !!selectedOperation }
  );

  const startOperation = trpc.learningControl.learning.start.useMutation({
    onSuccess: () => {
      toast.success("تم بدء العملية بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل بدء العملية: ${error.message}`);
    },
  });

  const deleteOperation = trpc.learningControl.learning.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف العملية بنجاح");
      refetch();
      if (selectedOperation) {setSelectedOperation(null);}
    },
    onError: (error) => {
      toast.error(`فشل الحذف: ${error.message}`);
    },
  });

  const handleStart = async (type: string) => {
    try {
      await startOperation.mutateAsync({
        type: type as any,
        input: {},
      });
    } catch (error) {
      console.error("Failed to start operation", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه العملية؟")) {return;}
    try {
      await deleteOperation.mutateAsync({ id });
    } catch (error) {
      console.error("Failed to delete operation", error);
    }
  };

  const filteredOperations = operations?.filter((op: any) => {
    if (statusFilter !== "all" && op.status !== statusFilter) {return false;}
    if (typeFilter !== "all" && op.type !== typeFilter) {return false;}
    return true;
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>بدء عملية تعلم جديدة</CardTitle>
          <CardDescription>
            اختر نوع العملية التي تريد تنفيذها
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-3">
            <Button
              onClick={() => handleStart("prediction_comparison")}
              disabled={startOperation.isPending}
            >
              <Brain className="w-4 h-4 mr-2" />
              مقارنة التوقعات
            </Button>
            <Button
              onClick={() => handleStart("pattern_detection")}
              disabled={startOperation.isPending}
            >
              <Activity className="w-4 h-4 mr-2" />
              اكتشاف الأنماط
            </Button>
            <Button
              onClick={() => handleStart("correlation_analysis")}
              disabled={startOperation.isPending}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              تحليل الارتباطات
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>العمليات ({filteredOperations?.length || 0})</CardTitle>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="حالة العملية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="running">قيد التنفيذ</SelectItem>
                  <SelectItem value="completed">مكتملة</SelectItem>
                  <SelectItem value="failed">فاشلة</SelectItem>
                  <SelectItem value="cancelled">ملغاة</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="نوع العملية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="prediction_comparison">مقارنة التوقعات</SelectItem>
                  <SelectItem value="pattern_detection">اكتشاف الأنماط</SelectItem>
                  <SelectItem value="correlation_analysis">تحليل الارتباطات</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-4">
              {filteredOperations && filteredOperations.length > 0 ? (
                filteredOperations.map((operation: any) => (
                  <div key={operation.id}>
                    <OperationCard
                      operation={operation}
                      onViewDetails={() => setSelectedOperation(operation.id)}
                      onDelete={() => handleDelete(operation.id)}
                      isSelected={selectedOperation === operation.id}
                    />
                    {selectedOperation === operation.id && (
                      <Card className="mt-2">
                        <CardHeader>
                          <CardTitle>تفاصيل العملية</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 text-sm">
                            <div><strong>المعرف:</strong> {operation.id}</div>
                            <div><strong>النوع:</strong> {operation.type}</div>
                            <div><strong>الحالة:</strong> {operation.status}</div>
                            {operation.currentStep && (
                              <div><strong>الخطوة الحالية:</strong> {operation.currentStep}</div>
                            )}
                            {operation.startedAt && (
                              <div><strong>تاريخ البدء:</strong> {new Date(operation.startedAt).toLocaleString("ar-SA")}</div>
                            )}
                            {operation.completedAt && (
                              <div><strong>تاريخ الإكمال:</strong> {new Date(operation.completedAt).toLocaleString("ar-SA")}</div>
                            )}
                            {operation.duration && (
                              <div><strong>المدة:</strong> {operation.duration} ثانية</div>
                            )}
                            {operation.error && (
                              <div className="text-red-500"><strong>خطأ:</strong> {operation.error}</div>
                            )}
                          </div>
                          {operationLogs && operationLogs.length > 0 && (
                            <div className="mt-4">
                              <CardTitle className="text-sm mb-2">السجلات</CardTitle>
                              <ScrollArea className="h-[200px]">
                                <div className="space-y-1">
                                  {operationLogs.map((log: any) => (
                                    <div key={log.id} className="text-xs p-2 border rounded">
                                      <div className="flex items-center justify-between">
                                        <Badge variant={log.level === "error" ? "destructive" : log.level === "warning" ? "default" : "secondary"}>
                                          {log.level}
                                        </Badge>
                                        <span className="text-muted-foreground">
                                          {new Date(log.timestamp).toLocaleString("ar-SA")}
                                        </span>
                                      </div>
                                      <div className="mt-1">{log.message}</div>
                                    </div>
                                  ))}
                                </div>
                              </ScrollArea>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  لا توجد عمليات تعلم
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== Search Operations Tab ====================

function SearchOperationsTab() {
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([]);
  const [selectedSources, setSelectedSources] = useState<number[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [selectedOperation, setSelectedOperation] = useState<string | null>(null);

  const { data: keywords } = trpc.learningControl.keywords.list.useQuery({
    enabled: true,
  });
  const { data: sources } = trpc.learningControl.sources.list.useQuery({
    enabled: true,
  });
  const { data: operations, refetch } = trpc.learningControl.search.list.useQuery({
    status: (statusFilter !== "all" ? statusFilter : undefined) as any,
    type: (typeFilter !== "all" ? typeFilter : undefined) as any,
  });

  const { data: operationLogs } = trpc.learningControl.search.getLogs.useQuery(
    { operationId: selectedOperation || "", limit: 50 },
    { enabled: !!selectedOperation }
  );

  const startSearch = trpc.learningControl.search.start.useMutation({
    onSuccess: () => {
      toast.success("تم بدء عملية البحث بنجاح");
      setSelectedKeywords([]);
      setSelectedSources([]);
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل بدء البحث: ${error.message}`);
    },
  });

  const deleteOperation = trpc.learningControl.search.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف العملية بنجاح");
      refetch();
      if (selectedOperation) {setSelectedOperation(null);}
    },
    onError: (error) => {
      toast.error(`فشل الحذف: ${error.message}`);
    },
  });

  const handleStartSearch = async () => {
    if (selectedKeywords.length === 0 || selectedSources.length === 0) {
      toast.error("يرجى اختيار كلمات مفتاحية ومصادر");
      return;
    }

    try {
      await startSearch.mutateAsync({
        type: "event_discovery",
        keywords: selectedKeywords,
        sources: selectedSources,
      });
    } catch (error) {
      console.error("Failed to start search", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه العملية؟")) {return;}
    try {
      await deleteOperation.mutateAsync({ id });
    } catch (error) {
      console.error("Failed to delete operation", error);
    }
  };

  const filteredOperations = operations?.filter((op: any) => {
    if (statusFilter !== "all" && op.status !== statusFilter) {return false;}
    if (typeFilter !== "all" && op.type !== typeFilter) {return false;}
    return true;
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>بدء عملية بحث جديدة</CardTitle>
          <CardDescription>
            اختر الكلمات المفتاحية والمصادر
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              الكلمات المفتاحية
            </label>
            <div className="flex flex-wrap gap-2">
              {keywords?.map((keyword: any) => (
                <Badge
                  key={keyword.id}
                  variant={selectedKeywords.includes(keyword.keyword) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => {
                    setSelectedKeywords((prev) =>
                      prev.includes(keyword.keyword)
                        ? prev.filter((k) => k !== keyword.keyword)
                        : [...prev, keyword.keyword]
                    );
                  }}
                >
                  {keyword.keyword}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">المصادر</label>
            <div className="flex flex-wrap gap-2">
              {sources?.map((source: any) => (
                <Badge
                  key={source.id}
                  variant={selectedSources.includes(source.id) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => {
                    setSelectedSources((prev) =>
                      prev.includes(source.id)
                        ? prev.filter((s) => s !== source.id)
                        : [...prev, source.id]
                    );
                  }}
                >
                  {source.name}
                </Badge>
              ))}
            </div>
          </div>

          <Button
            onClick={handleStartSearch}
            disabled={
              startSearch.isPending ||
              selectedKeywords.length === 0 ||
              selectedSources.length === 0
            }
            className="w-full"
          >
            <Search className="w-4 h-4 mr-2" />
            بدء البحث
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>العمليات ({filteredOperations?.length || 0})</CardTitle>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="حالة العملية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="running">قيد التنفيذ</SelectItem>
                  <SelectItem value="completed">مكتملة</SelectItem>
                  <SelectItem value="failed">فاشلة</SelectItem>
                  <SelectItem value="cancelled">ملغاة</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="نوع العملية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="keyword_search">بحث بالكلمات</SelectItem>
                  <SelectItem value="event_discovery">اكتشاف الأحداث</SelectItem>
                  <SelectItem value="news_scraping">جلب الأخبار</SelectItem>
                  <SelectItem value="sentiment_analysis">تحليل المشاعر</SelectItem>
                  <SelectItem value="entity_extraction">استخراج الكيانات</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-4">
              {filteredOperations && filteredOperations.length > 0 ? (
                filteredOperations.map((operation: any) => (
                  <div key={operation.id}>
                    <OperationCard
                      operation={operation}
                      onViewDetails={() => setSelectedOperation(operation.id)}
                      onDelete={() => handleDelete(operation.id)}
                      isSelected={selectedOperation === operation.id}
                    />
                    {selectedOperation === operation.id && (
                      <Card className="mt-2">
                        <CardHeader>
                          <CardTitle>تفاصيل العملية</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 text-sm">
                            <div><strong>المعرف:</strong> {operation.id}</div>
                            <div><strong>النوع:</strong> {operation.type}</div>
                            <div><strong>الحالة:</strong> {operation.status}</div>
                            {operation.currentSource && (
                              <div><strong>المصدر الحالي:</strong> {operation.currentSource}</div>
                            )}
                            {operation.sourcesProcessed !== undefined && (
                              <div><strong>المصادر المعالجة:</strong> {operation.sourcesProcessed} / {operation.totalSources || 0}</div>
                            )}
                            {operation.resultsFound !== undefined && (
                              <div><strong>النتائج:</strong> {operation.resultsFound}</div>
                            )}
                            {operation.eventsCreated !== undefined && (
                              <div><strong>الأحداث المنشأة:</strong> {operation.eventsCreated}</div>
                            )}
                            {operation.startedAt && (
                              <div><strong>تاريخ البدء:</strong> {new Date(operation.startedAt).toLocaleString("ar-SA")}</div>
                            )}
                            {operation.completedAt && (
                              <div><strong>تاريخ الإكمال:</strong> {new Date(operation.completedAt).toLocaleString("ar-SA")}</div>
                            )}
                            {operation.duration && (
                              <div><strong>المدة:</strong> {operation.duration} ثانية</div>
                            )}
                            {operation.error && (
                              <div className="text-red-500"><strong>خطأ:</strong> {operation.error}</div>
                            )}
                          </div>
                          {operationLogs && operationLogs.length > 0 && (
                            <div className="mt-4">
                              <CardTitle className="text-sm mb-2">السجلات</CardTitle>
                              <ScrollArea className="h-[200px]">
                                <div className="space-y-1">
                                  {operationLogs.map((log: any) => (
                                    <div key={log.id} className="text-xs p-2 border rounded">
                                      <div className="flex items-center justify-between">
                                        <Badge variant={log.level === "error" ? "destructive" : log.level === "warning" ? "default" : "secondary"}>
                                          {log.level}
                                        </Badge>
                                        <span className="text-muted-foreground">
                                          {new Date(log.timestamp).toLocaleString("ar-SA")}
                                        </span>
                                      </div>
                                      <div className="mt-1">{log.message}</div>
                                    </div>
                                  ))}
                                </div>
                              </ScrollArea>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  لا توجد عمليات بحث
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== Keywords Tab ====================

function KeywordsTab() {
  const { data: keywords, refetch } = trpc.learningControl.keywords.list.useQuery({});
  const createKeyword = trpc.learningControl.keywords.create.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة الكلمة المفتاحية بنجاح");
      setNewKeyword("");
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل الإضافة: ${error.message}`);
    },
  });
  const updateKeyword = trpc.learningControl.keywords.update.useMutation({
    onSuccess: () => {
      toast.success("تم التحديث بنجاح");
      refetch();
    },
  });
  const deleteKeyword = trpc.learningControl.keywords.delete.useMutation({
    onSuccess: () => {
      toast.success("تم الحذف بنجاح");
      refetch();
    },
  });

  const [newKeyword, setNewKeyword] = useState("");
  const [newCategory, setNewCategory] = useState("general");
  const [newPriority, setNewPriority] = useState("medium");

  const handleCreate = async () => {
    if (!newKeyword.trim()) {
      toast.error("يرجى إدخال كلمة مفتاحية");
      return;
    }

    try {
      await createKeyword.mutateAsync({
        keyword: newKeyword,
        category: newCategory as any,
        priority: newPriority as any,
      });
    } catch (error) {
      console.error("Failed to create keyword", error);
    }
  };

  const handleToggle = async (id: number, enabled: boolean) => {
    try {
      await updateKeyword.mutateAsync({
        id,
        enabled: !enabled,
      });
    } catch (error) {
      console.error("Failed to update keyword", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذه الكلمة المفتاحية؟")) {return;}

    try {
      await deleteKeyword.mutateAsync({ id });
    } catch (error) {
      console.error("Failed to delete keyword", error);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>إضافة كلمة مفتاحية جديدة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              type="text"
              value={newKeyword}
              onChange={(e) => setNewKeyword(e.target.value)}
              placeholder="الكلمة المفتاحية"
              className="flex-1"
            />
            <Select value={newCategory} onValueChange={setNewCategory}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">عام</SelectItem>
                <SelectItem value="political">سياسي</SelectItem>
                <SelectItem value="economic">اقتصادي</SelectItem>
                <SelectItem value="geopolitical">جيوسياسي</SelectItem>
                <SelectItem value="monetary_policy">السياسة النقدية</SelectItem>
                <SelectItem value="market">السوق</SelectItem>
                <SelectItem value="commodity">السلع</SelectItem>
              </SelectContent>
            </Select>
            <Select value={newPriority} onValueChange={setNewPriority}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">منخفضة</SelectItem>
                <SelectItem value="medium">متوسطة</SelectItem>
                <SelectItem value="high">عالية</SelectItem>
                <SelectItem value="critical">حرجة</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleCreate} disabled={createKeyword.isPending}>
              إضافة
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>الكلمات المفتاحية ({keywords?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-2">
              {keywords && keywords.length > 0 ? (
                keywords.map((keyword: any) => (
                  <div
                    key={keyword.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={keyword.enabled}
                        onChange={() => handleToggle(keyword.id, keyword.enabled)}
                        className="w-4 h-4"
                      />
                      <div>
                        <div className="font-medium">{keyword.keyword}</div>
                        <div className="text-sm text-muted-foreground">
                          {keyword.category} • {keyword.priority}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {keyword.searchCount || 0} عملية
                      </Badge>
                      <Badge variant="outline">
                        {keyword.resultsFound || 0} نتيجة
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(keyword.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  لا توجد كلمات مفتاحية
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== Sources Tab ====================

function SourcesTab() {
  const { data: sources, refetch } = trpc.learningControl.sources.list.useQuery({});
  const createSource = trpc.learningControl.sources.create.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة المصدر بنجاح");
      setNewName("");
      setNewUrl("");
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل الإضافة: ${error.message}`);
    },
  });
  const updateSource = trpc.learningControl.sources.update.useMutation({
    onSuccess: () => {
      toast.success("تم التحديث بنجاح");
      refetch();
    },
  });
  const deleteSource = trpc.learningControl.sources.delete.useMutation({
    onSuccess: () => {
      toast.success("تم الحذف بنجاح");
      refetch();
    },
  });

  const [newName, setNewName] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newType, setNewType] = useState("news_site");

  const handleCreate = async () => {
    if (!newName.trim() || !newUrl.trim()) {
      toast.error("يرجى إدخال اسم المصدر والرابط");
      return;
    }

    try {
      await createSource.mutateAsync({
        name: newName,
        url: newUrl,
        type: newType as any,
      });
    } catch (error) {
      console.error("Failed to create source", error);
    }
  };

  const handleToggle = async (id: number, enabled: boolean) => {
    try {
      await updateSource.mutateAsync({
        id,
        enabled: !enabled,
      });
    } catch (error) {
      console.error("Failed to update source", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا المصدر؟")) {return;}

    try {
      await deleteSource.mutateAsync({ id });
    } catch (error) {
      console.error("Failed to delete source", error);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>إضافة مصدر جديد</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="اسم المصدر"
            />
            <Input
              type="url"
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              placeholder="https://example.com"
            />
            <div className="flex gap-2">
              <Select value={newType} onValueChange={setNewType}>
                <SelectTrigger className="flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="search_engine">محرك بحث</SelectItem>
                  <SelectItem value="news_site">موقع أخبار</SelectItem>
                  <SelectItem value="financial_site">موقع مالي</SelectItem>
                  <SelectItem value="government_site">موقع حكومي</SelectItem>
                  <SelectItem value="social_media">وسائل التواصل</SelectItem>
                  <SelectItem value="api">API</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={handleCreate} disabled={createSource.isPending}>
                إضافة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>المصادر ({sources?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-2">
              {sources && sources.length > 0 ? (
                sources.map((source: any) => (
                  <div
                    key={source.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={source.enabled}
                        onChange={() => handleToggle(source.id, source.enabled)}
                        className="w-4 h-4"
                      />
                      <div>
                        <div className="font-medium">{source.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {source.type} • {source.url}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {source.reliability || 100}% موثوقية
                      </Badge>
                      <Badge variant="outline">
                        {source.requestCount || 0} طلب
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(source.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  لا توجد مصادر
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== Main Component ====================

export default function LearningControlDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [connectionStatus, setConnectionStatus] = useState<"connected" | "disconnected" | "connecting" | "error">("disconnected");

  const queryClient = useQueryClient();

  // Subscribe to WebSocket updates
  const { isConnected, subscribe, send, connect, disconnect, reconnectAttempts, maxReconnectAttempts } = useWebSocket({
    onOpen: () => {
      setConnectionStatus("connected");
      toast.success("تم الاتصال بنجاح");
    },
    onClose: () => {
      setConnectionStatus("disconnected");
      if (reconnectAttempts < maxReconnectAttempts) {
        setConnectionStatus("connecting");
      }
    },
    onError: () => {
      setConnectionStatus("error");
      toast.error("خطأ في الاتصال");
    },
  });

  // Subscribe to WebSocket updates
  useEffect(() => {
    if (!isConnected) {return;}

    // Subscribe to channels
    send({
      type: "subscribe",
      channel: "learning:operation:update",
    });
    send({
      type: "subscribe",
      channel: "search:operation:update",
    });
    send({
      type: "subscribe",
      channel: "keyword:update",
    });
    send({
      type: "subscribe",
      channel: "source:update",
    });

    // Subscribe to operation logs channel
    send({
      type: "subscribe",
      channel: "operation:log",
    });

    const unsubscribe1 = subscribe("learning:operation:update", (message) => {
      console.log("[WebSocket] Learning operation update:", message);
      
      // Update UI immediately by updating the cache
      if (message.data && typeof message.data === "object" && "id" in message.data) {
        const operationData = message.data as any;
        queryClient.setQueryData(
          [["learningControl", "learning", "list"]],
          (oldData: any) => {
            if (!oldData) {return oldData;}
            return oldData.map((op: any) =>
              op.id === operationData.id ? { ...op, ...operationData } : op
            );
          }
        );
      }
      
      // Also invalidate to ensure fresh data
      queryClient.invalidateQueries({ queryKey: [["learningControl", "learning"]] });
      queryClient.invalidateQueries({ queryKey: [["learningControl", "stats"]] });
      
      toast.info("تحديث عملية تعلم", {
        description: (message.data as any)?.type || "تم تحديث العملية",
      });
    });

    const unsubscribe2 = subscribe("search:operation:update", (message) => {
      console.log("[WebSocket] Search operation update:", message);
      
      // Update UI immediately by updating the cache
      if (message.data && typeof message.data === "object" && "id" in message.data) {
        const operationData = message.data as any;
        queryClient.setQueryData(
          [["learningControl", "search", "list"]],
          (oldData: any) => {
            if (!oldData) {return oldData;}
            return oldData.map((op: any) =>
              op.id === operationData.id ? { ...op, ...operationData } : op
            );
          }
        );
      }
      
      // Also invalidate to ensure fresh data
      queryClient.invalidateQueries({ queryKey: [["learningControl", "search"]] });
      queryClient.invalidateQueries({ queryKey: [["learningControl", "stats"]] });
      
      toast.info("تحديث عملية بحث", {
        description: (message.data as any)?.type || "تم تحديث العملية",
      });
    });

    const unsubscribe3 = subscribe("keyword:update", (message) => {
      console.log("[WebSocket] Keyword update:", message);
      
      // Update UI immediately by updating the cache
      if (message.data && typeof message.data === "object") {
        const keywordData = message.data as any;
        if (keywordData.id) {
          queryClient.setQueryData(
            [["learningControl", "keywords", "list"]],
            (oldData: any) => {
              if (!oldData) {return oldData;}
              if (keywordData.type === "keyword_deleted") {
                return oldData.filter((k: any) => k.id !== keywordData.id);
              }
              const index = oldData.findIndex((k: any) => k.id === keywordData.id);
              if (index >= 0) {
                return oldData.map((k: any, i: number) =>
                  i === index ? { ...k, ...keywordData } : k
                );
              }
              return [...oldData, keywordData];
            }
          );
        }
      }
      
      // Also invalidate to ensure fresh data
      queryClient.invalidateQueries({ queryKey: [["learningControl", "keywords"]] });
      queryClient.invalidateQueries({ queryKey: [["learningControl", "stats"]] });
    });

    const unsubscribe4 = subscribe("source:update", (message) => {
      console.log("[WebSocket] Source update:", message);
      
      // Update UI immediately by updating the cache
      if (message.data && typeof message.data === "object") {
        const sourceData = message.data as any;
        if (sourceData.id) {
          queryClient.setQueryData(
            [["learningControl", "sources", "list"]],
            (oldData: any) => {
              if (!oldData) {return oldData;}
              if (sourceData.type === "source_deleted") {
                return oldData.filter((s: any) => s.id !== sourceData.id);
              }
              const index = oldData.findIndex((s: any) => s.id === sourceData.id);
              if (index >= 0) {
                return oldData.map((s: any, i: number) =>
                  i === index ? { ...s, ...sourceData } : s
                );
              }
              return [...oldData, sourceData];
            }
          );
        }
      }
      
      // Also invalidate to ensure fresh data
      queryClient.invalidateQueries({ queryKey: [["learningControl", "sources"]] });
      queryClient.invalidateQueries({ queryKey: [["learningControl", "stats"]] });
    });

    const unsubscribe5 = subscribe("operation:log", (message) => {
      console.log("[WebSocket] Operation log:", message);
      // Invalidate operation logs queries
      queryClient.invalidateQueries({ queryKey: [["learningControl", "logs"]] });
    });

    return () => {
      unsubscribe1();
      unsubscribe2();
      unsubscribe3();
      unsubscribe4();
      unsubscribe5();
    };
  }, [isConnected, subscribe, send, queryClient, connect]);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">لوحة تحكم التعلم والبحث</h1>
          <p className="text-muted-foreground">
            إدارة عمليات التعلم والبحث والكلمات المفتاحية والمصادر
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge
            variant={
              connectionStatus === "connected"
                ? "default"
                : connectionStatus === "connecting"
                ? "secondary"
                : "destructive"
            }
            className="flex items-center gap-1"
          >
            {connectionStatus === "connected" && (
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            )}
            {connectionStatus === "connecting" && (
              <RefreshCw className="w-3 h-3 animate-spin" />
            )}
            {connectionStatus === "error" && (
              <AlertCircle className="w-3 h-3" />
            )}
            {connectionStatus === "connected"
              ? "متصل"
              : connectionStatus === "connecting"
              ? "جاري الاتصال..."
              : "غير متصل"}
          </Badge>
          {!isConnected && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setConnectionStatus("connecting");
                connect();
              }}
            >
              <RefreshCw className="w-4 h-4 mr-1" />
              إعادة الاتصال
            </Button>
          )}
          {reconnectAttempts > 0 && reconnectAttempts < maxReconnectAttempts && (
            <span className="text-xs text-muted-foreground">
              محاولة {reconnectAttempts}/{maxReconnectAttempts}
            </span>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="learning">عمليات التعلم</TabsTrigger>
          <TabsTrigger value="search">عمليات البحث</TabsTrigger>
          <TabsTrigger value="keywords">الكلمات المفتاحية</TabsTrigger>
          <TabsTrigger value="sources">المصادر</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="learning">
          <LearningOperationsTab />
        </TabsContent>

        <TabsContent value="search">
          <SearchOperationsTab />
        </TabsContent>

        <TabsContent value="keywords">
          <KeywordsTab />
        </TabsContent>

        <TabsContent value="sources">
          <SourcesTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

