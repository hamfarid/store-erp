import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Trash2,
  Shield,
  User as UserIcon,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import { SortableTableHeader } from "@/components/SortableTableHeader";
import PaginationControls from "@/components/PaginationControls";

export default function UsersList() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<string>("all");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedUserName, setSelectedUserName] = useState<string>("");
  const [newRole, setNewRole] = useState<"admin" | "user">("user");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Sorting state
  const [sortField, setSortField] = useState<string>("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  // Check if user is admin
  if (!isAuthenticated || user?.role !== "admin") {
    navigate("/");
    return null;
  }

  // Fetch users
  const {
    data: users,
    isLoading,
    refetch,
  } = trpc.users.list.useQuery({
    limit: 100,
    offset: 0,
  });

  // Update role mutation
  const updateRoleMutation = trpc.users.updateRole.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث صلاحيات المستخدم بنجاح");
      refetch();
      setRoleDialogOpen(false);
      setSelectedUserId(null);
    },
    onError: error => {
      toast.error(`فشل تحديث الصلاحيات: ${error.message}`);
    },
  });

  // Delete mutation
  const deleteMutation = trpc.users.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المستخدم بنجاح");
      refetch();
      setDeleteDialogOpen(false);
      setSelectedUserId(null);
    },
    onError: error => {
      toast.error(`فشل حذف المستخدم: ${error.message}`);
    },
  });

  // Filter users
  let filteredUsers = users?.filter((u: any) => {
    const matchesSearch =
      (u as any).name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u as any).email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u as any).id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = filterRole === "all" || (u as any).role === filterRole;
    return matchesSearch && matchesRole;
  });

  // Sort users
  if (filteredUsers) {
    filteredUsers = [...filteredUsers].sort((a: any, b: any) => {
      let aValue: any = (a as any)[sortField as keyof typeof a];
      let bValue: any = (b as any)[sortField as keyof typeof b];

      // Handle date sorting
      if (sortField === "createdAt" || sortField === "lastSignedIn") {
        aValue = aValue ? new Date(aValue).getTime() : 0;
        bValue = bValue ? new Date(bValue).getTime() : 0;
      }

      // Handle string sorting
      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      // Handle numeric sorting
      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }

      return 0;
    });
  }

  // Pagination
  const totalItems = filteredUsers?.length || 0;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedUsers = filteredUsers?.slice(startIndex, endIndex);

  // Export to CSV
  const handleExport = () => {
    if (!filteredUsers || filteredUsers.length === 0) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const csv = [
      [
        "ID",
        "Name",
        "Email",
        "Role",
        "Login Method",
        "Created At",
        "Last Signed In",
      ].join(","),
      ...filteredUsers.map((u: any) =>
        [
          (u as any).id,
          (u as any).name || "N/A",
          (u as any).email || "N/A",
          (u as any).role,
          (u as any).loginMethod || "N/A",
          (u as any).createdAt
            ? new Date((u as any).createdAt).toLocaleDateString()
            : "N/A",
          (u as any).lastSignedIn
            ? new Date(u.lastSignedIn).toLocaleDateString()
            : "N/A",
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `users_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("تم تصدير البيانات بنجاح");
  };

  const handleDeleteClick = (userId: string, userName: string) => {
    if (userId === user?.id) {
      toast.error("لا يمكنك حذف حسابك الخاص");
      return;
    }
    setSelectedUserId(userId);
    setSelectedUserName(userName);
    setDeleteDialogOpen(true);
  };

  const handleRoleClick = (
    userId: string,
    userName: string,
    currentRole: "admin" | "user"
  ) => {
    if (userId === user?.id) {
      toast.error("لا يمكنك تغيير صلاحياتك الخاصة");
      return;
    }
    setSelectedUserId(userId);
    setSelectedUserName(userName);
    setNewRole(currentRole === "admin" ? "user" : "admin");
    setRoleDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedUserId) {
      deleteMutation.mutate({ id: selectedUserId });
    }
  };

  const confirmRoleChange = () => {
    if (selectedUserId) {
      updateRoleMutation.mutate({ id: selectedUserId, role: newRole });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 ml-2" />
              العودة للرئيسية
            </Button>
            <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <Shield className="h-6 w-6 text-blue-600" />
              إدارة المستخدمين
            </h1>
            <div className="w-32"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <p className="text-slate-600">
            إدارة المستخدمين والصلاحيات (Admin Only)
          </p>
        </div>

        {/* Toolbar */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4">
              {/* Search */}
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="بحث بالاسم أو البريد أو ID..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="pr-10"
                  />
                </div>
              </div>

              {/* Filter by Role */}
              <div className="w-[200px]">
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger>
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="تصفية حسب الصلاحية" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الصلاحيات</SelectItem>
                    <SelectItem value="admin">مدير</SelectItem>
                    <SelectItem value="user">مستخدم</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Export */}
              <Button variant="outline" onClick={handleExport}>
                <Download className="h-4 w-4 ml-2" />
                تصدير CSV
              </Button>

              {/* Refresh */}
              <Button
                variant="outline"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw
                  className={`h-4 w-4 ml-2 ${isLoading ? "animate-spin" : ""}`}
                />
                تحديث
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-slate-600 mt-4">جاري التحميل...</p>
          </div>
        ) : paginatedUsers && paginatedUsers.length > 0 ? (
          <>
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">المستخدم</TableHead>
                        <TableHead className="text-right">
                          البريد الإلكتروني
                        </TableHead>
                        <TableHead className="text-right">الصلاحية</TableHead>
                        <TableHead className="text-right">
                          طريقة تسجيل الدخول
                        </TableHead>
                        <TableHead className="text-right">
                          تاريخ الإنشاء
                        </TableHead>
                        <TableHead className="text-right">
                          آخر تسجيل دخول
                        </TableHead>
                        <TableHead className="text-right">الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedUsers.map((u: any) => (
                        <TableRow key={(u as any).id}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                                <UserIcon className="h-4 w-4 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium">
                                  {(u as any).name || "لا يوجد اسم"}
                                </p>
                                <p className="text-xs text-slate-500">
                                  {(u as any).id.substring(0, 8)}...
                                </p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {(u as any).email || "لا يوجد بريد"}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                (u as any).role === "admin"
                                  ? "default"
                                  : "secondary"
                              }
                              className="cursor-pointer"
                              onClick={() =>
                                handleRoleClick(
                                  (u as any).id,
                                  (u as any).name || (u as any).id,
                                  (u as any).role
                                )
                              }
                            >
                              {(u as any).role === "admin" ? (
                                <>
                                  <Shield className="h-3 w-3 ml-1" />
                                  مدير
                                </>
                              ) : (
                                <>
                                  <UserIcon className="h-3 w-3 ml-1" />
                                  مستخدم
                                </>
                              )}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {(u as any).loginMethod || "N/A"}
                          </TableCell>
                          <TableCell>
                            {(u as any).createdAt
                              ? new Date(
                                  (u as any).createdAt
                                ).toLocaleDateString("ar-EG")
                              : "N/A"}
                          </TableCell>
                          <TableCell>
                            {(u as any).lastSignedIn
                              ? new Date(
                                  (u as any).lastSignedIn
                                ).toLocaleDateString("ar-EG")
                              : "N/A"}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  navigate(`/admin/users/view/${(u as any).id}`)
                                }
                                title="عرض"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleDeleteClick(
                                    (u as any).id,
                                    (u as any).name || (u as any).id
                                  )
                                }
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                title="حذف"
                                disabled={(u as any).id === user?.id}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={totalItems}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={newSize => {
                    setPageSize(newSize);
                    setCurrentPage(1);
                  }}
                />
              </div>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <UserIcon className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg">لا يوجد مستخدمون</p>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد حذف المستخدم</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف المستخدم "{selectedUserName}"؟ سيتم حذف جميع
              البيانات المرتبطة به (التوقعات، التنبيهات، الإشعارات). لا يمكن
              التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "جاري الحذف..." : "حذف نهائياً"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Role Change Confirmation Dialog */}
      <Dialog open={roleDialogOpen} onOpenChange={setRoleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغيير صلاحيات المستخدم</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من تغيير صلاحيات المستخدم "{selectedUserName}" إلى{" "}
              {newRole === "admin" ? "مدير" : "مستخدم عادي"}؟
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRoleDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              onClick={confirmRoleChange}
              disabled={updateRoleMutation.isPending}
            >
              {updateRoleMutation.isPending
                ? "جاري التحديث..."
                : "تأكيد التغيير"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
