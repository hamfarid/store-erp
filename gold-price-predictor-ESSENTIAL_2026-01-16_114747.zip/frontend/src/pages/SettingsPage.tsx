import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  Mail,
  Bell,
  Palette,
  Download,
  Upload,
  Save,
  RotateCcw,
  Settings as SettingsIcon,
} from "lucide-react";
import { toast } from "sonner";

interface SettingsData {
  // Email Settings
  emailEnabled: boolean;
  emailAddress: string;
  smtpHost: string;
  smtpPort: string;
  smtpUser: string;
  smtpPassword: string;

  // Notification Preferences
  notifyPriceChanges: boolean;
  notifyAlerts: boolean;
  notifyPredictions: boolean;
  notifyReports: boolean;
  priceChangeThreshold: string;

  // Display Preferences
  language: string;
  theme: string;
  dateFormat: string;
  timeFormat: string;
  currency: string;

  // Export Settings
  exportFormat: string;
  includeHeaders: boolean;
  exportDateFormat: string;
  exportDelimiter: string;
}

const defaultSettings: SettingsData = {
  // Email Settings
  emailEnabled: false,
  emailAddress: "",
  smtpHost: "",
  smtpPort: "587",
  smtpUser: "",
  smtpPassword: "",

  // Notification Preferences
  notifyPriceChanges: true,
  notifyAlerts: true,
  notifyPredictions: true,
  notifyReports: false,
  priceChangeThreshold: "5",

  // Display Preferences
  language: "ar",
  theme: "light",
  dateFormat: "DD/MM/YYYY",
  timeFormat: "24h",
  currency: "USD",

  // Export Settings
  exportFormat: "csv",
  includeHeaders: true,
  exportDateFormat: "YYYY-MM-DD",
  exportDelimiter: ",",
};

export default function SettingsPage() {
  const [, navigate] = useLocation();
  const [settings, setSettings] = useState<SettingsData>(defaultSettings);
  const [hasChanges, setHasChanges] = useState(false);

  // Load settings from backend
  const { data: backendSettings, isLoading } = trpc.settings.get.useQuery();
  const updateSettings = trpc.settings.update.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ الإعدادات بنجاح!");
      setHasChanges(false);
    },
    onError: error => {
      toast.error("فشل حفظ الإعدادات: " + error.message);
    },
  });
  const resetSettings = trpc.settings.reset.useMutation({
    onSuccess: () => {
      toast.success("تم إعادة تعيين الإعدادات إلى القيم الافتراضية");
      setSettings(defaultSettings);
      setHasChanges(false);
    },
    onError: error => {
      toast.error("فشل إعادة تعيين الإعدادات: " + error.message);
    },
  });

  useEffect(() => {
    if (backendSettings) {
      setSettings({ ...defaultSettings, ...backendSettings });
    }
  }, [backendSettings]);

  const handleChange = (key: keyof SettingsData, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    updateSettings.mutate(settings as any);
  };

  const handleReset = () => {
    if (confirm("هل أنت متأكد من إعادة تعيين جميع الإعدادات؟")) {
      resetSettings.mutate();
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `settings_${new Date().toISOString().split("T")[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("تم تصدير الإعدادات بنجاح!");
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {return;}

    const reader = new FileReader();
    reader.onload = e => {
      try {
        const imported = JSON.parse(e.target?.result as string);
        setSettings({ ...defaultSettings, ...imported });
        setHasChanges(true);
        toast.success("تم استيراد الإعدادات بنجاح!");
      } catch (error) {
        toast.error("فشل استيراد الإعدادات: ملف غير صالح");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 ml-2" />
              العودة للرئيسية
            </Button>

            <div className="flex gap-2">
              {hasChanges && (
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  حفظ التغييرات
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <SettingsIcon className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-slate-800">الإعدادات</h1>
          </div>
          <p className="text-slate-600">
            إدارة إعدادات التطبيق والتفضيلات الشخصية
          </p>
        </div>

        <Tabs defaultValue="email" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="email">
              <Mail className="h-4 w-4 ml-2" />
              البريد الإلكتروني
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="h-4 w-4 ml-2" />
              التنبيهات
            </TabsTrigger>
            <TabsTrigger value="display">
              <Palette className="h-4 w-4 ml-2" />
              العرض
            </TabsTrigger>
            <TabsTrigger value="export">
              <Download className="h-4 w-4 ml-2" />
              التصدير
            </TabsTrigger>
          </TabsList>

          {/* Email Settings Tab */}
          <TabsContent value="email">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات البريد الإلكتروني</CardTitle>
                <CardDescription>
                  تكوين خادم SMTP لإرسال التنبيهات عبر البريد الإلكتروني
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="emailEnabled">
                      تفعيل البريد الإلكتروني
                    </Label>
                    <p className="text-sm text-slate-600">
                      إرسال التنبيهات عبر البريد الإلكتروني
                    </p>
                  </div>
                  <Switch
                    id="emailEnabled"
                    checked={settings.emailEnabled}
                    onCheckedChange={checked =>
                      handleChange("emailEnabled", checked)
                    }
                  />
                </div>

                <div className="grid gap-4">
                  <div>
                    <Label htmlFor="emailAddress">
                      عنوان البريد الإلكتروني
                    </Label>
                    <Input
                      id="emailAddress"
                      type="email"
                      placeholder="example@gmail.com"
                      value={settings.emailAddress}
                      onChange={e =>
                        handleChange("emailAddress", e.target.value)
                      }
                      disabled={!settings.emailEnabled}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="smtpHost">خادم SMTP</Label>
                      <Input
                        id="smtpHost"
                        placeholder="smtp.gmail.com"
                        value={settings.smtpHost}
                        onChange={e => handleChange("smtpHost", e.target.value)}
                        disabled={!settings.emailEnabled}
                      />
                    </div>

                    <div>
                      <Label htmlFor="smtpPort">المنفذ</Label>
                      <Input
                        id="smtpPort"
                        type="number"
                        placeholder="587"
                        value={settings.smtpPort}
                        onChange={e => handleChange("smtpPort", e.target.value)}
                        disabled={!settings.emailEnabled}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="smtpUser">اسم المستخدم</Label>
                    <Input
                      id="smtpUser"
                      placeholder="username"
                      value={settings.smtpUser}
                      onChange={e => handleChange("smtpUser", e.target.value)}
                      disabled={!settings.emailEnabled}
                    />
                  </div>

                  <div>
                    <Label htmlFor="smtpPassword">كلمة المرور</Label>
                    <Input
                      id="smtpPassword"
                      type="password"
                      placeholder="••••••••"
                      value={settings.smtpPassword}
                      onChange={e =>
                        handleChange("smtpPassword", e.target.value)
                      }
                      disabled={!settings.emailEnabled}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notification Preferences Tab */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>تفضيلات التنبيهات</CardTitle>
                <CardDescription>
                  اختر الأحداث التي تريد تلقي تنبيهات بشأنها
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="notifyPriceChanges">تغيرات الأسعار</Label>
                    <p className="text-sm text-slate-600">
                      تنبيه عند تغير الأسعار بنسبة معينة
                    </p>
                  </div>
                  <Switch
                    id="notifyPriceChanges"
                    checked={settings.notifyPriceChanges}
                    onCheckedChange={checked =>
                      handleChange("notifyPriceChanges", checked)
                    }
                  />
                </div>

                {settings.notifyPriceChanges && (
                  <div>
                    <Label htmlFor="priceChangeThreshold">
                      نسبة التغير (%)
                    </Label>
                    <Input
                      id="priceChangeThreshold"
                      type="number"
                      min="1"
                      max="100"
                      value={settings.priceChangeThreshold}
                      onChange={e =>
                        handleChange("priceChangeThreshold", e.target.value)
                      }
                    />
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="notifyAlerts">التنبيهات المخصصة</Label>
                    <p className="text-sm text-slate-600">
                      تنبيه عند تحقق شروط التنبيهات
                    </p>
                  </div>
                  <Switch
                    id="notifyAlerts"
                    checked={settings.notifyAlerts}
                    onCheckedChange={checked =>
                      handleChange("notifyAlerts", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="notifyPredictions">التوقعات الجديدة</Label>
                    <p className="text-sm text-slate-600">
                      تنبيه عند توفر توقعات جديدة
                    </p>
                  </div>
                  <Switch
                    id="notifyPredictions"
                    checked={settings.notifyPredictions}
                    onCheckedChange={checked =>
                      handleChange("notifyPredictions", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="notifyReports">التقارير الدورية</Label>
                    <p className="text-sm text-slate-600">
                      تنبيه عند إنشاء تقارير دورية
                    </p>
                  </div>
                  <Switch
                    id="notifyReports"
                    checked={settings.notifyReports}
                    onCheckedChange={checked =>
                      handleChange("notifyReports", checked)
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Display Preferences Tab */}
          <TabsContent value="display">
            <Card>
              <CardHeader>
                <CardTitle>تفضيلات العرض</CardTitle>
                <CardDescription>
                  تخصيص مظهر التطبيق وتنسيق البيانات
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="language">اللغة</Label>
                  <Select
                    value={settings.language}
                    onValueChange={value => handleChange("language", value)}
                  >
                    <SelectTrigger id="language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="theme">المظهر</Label>
                  <Select
                    value={settings.theme}
                    onValueChange={value => handleChange("theme", value)}
                  >
                    <SelectTrigger id="theme">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">فاتح</SelectItem>
                      <SelectItem value="dark">داكن</SelectItem>
                      <SelectItem value="auto">تلقائي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="dateFormat">تنسيق التاريخ</Label>
                  <Select
                    value={settings.dateFormat}
                    onValueChange={value => handleChange("dateFormat", value)}
                  >
                    <SelectTrigger id="dateFormat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="timeFormat">تنسيق الوقت</Label>
                  <Select
                    value={settings.timeFormat}
                    onValueChange={value => handleChange("timeFormat", value)}
                  >
                    <SelectTrigger id="timeFormat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="12h">12 ساعة (AM/PM)</SelectItem>
                      <SelectItem value="24h">24 ساعة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="currency">العملة الافتراضية</Label>
                  <Select
                    value={settings.currency}
                    onValueChange={value => handleChange("currency", value)}
                  >
                    <SelectTrigger id="currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">دولار أمريكي (USD)</SelectItem>
                      <SelectItem value="EUR">يورو (EUR)</SelectItem>
                      <SelectItem value="GBP">جنيه إسترليني (GBP)</SelectItem>
                      <SelectItem value="SAR">ريال سعودي (SAR)</SelectItem>
                      <SelectItem value="AED">درهم إماراتي (AED)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Export Settings Tab */}
          <TabsContent value="export">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات التصدير</CardTitle>
                <CardDescription>
                  تخصيص تنسيق البيانات المُصدّرة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="exportFormat">تنسيق التصدير</Label>
                  <Select
                    value={settings.exportFormat}
                    onValueChange={value => handleChange("exportFormat", value)}
                  >
                    <SelectTrigger id="exportFormat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="includeHeaders">تضمين رؤوس الأعمدة</Label>
                    <p className="text-sm text-slate-600">
                      إضافة أسماء الأعمدة في الصف الأول
                    </p>
                  </div>
                  <Switch
                    id="includeHeaders"
                    checked={settings.includeHeaders}
                    onCheckedChange={checked =>
                      handleChange("includeHeaders", checked)
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="exportDateFormat">
                    تنسيق التاريخ في التصدير
                  </Label>
                  <Select
                    value={settings.exportDateFormat}
                    onValueChange={value =>
                      handleChange("exportDateFormat", value)
                    }
                  >
                    <SelectTrigger id="exportDateFormat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="ISO">ISO 8601</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {settings.exportFormat === "csv" && (
                  <div>
                    <Label htmlFor="exportDelimiter">الفاصل</Label>
                    <Select
                      value={settings.exportDelimiter}
                      onValueChange={value =>
                        handleChange("exportDelimiter", value)
                      }
                    >
                      <SelectTrigger id="exportDelimiter">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value=",">فاصلة (,)</SelectItem>
                        <SelectItem value=";">فاصلة منقوطة (;)</SelectItem>
                        <SelectItem value="\t">Tab</SelectItem>
                        <SelectItem value="|">خط عمودي (|)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="pt-4 border-t">
                  <div className="flex gap-2">
                    <Button
                      onClick={handleExport}
                      variant="outline"
                      className="gap-2"
                    >
                      <Download className="h-4 w-4" />
                      تصدير الإعدادات
                    </Button>

                    <div>
                      <input
                        type="file"
                        id="import-settings"
                        accept=".json"
                        onChange={handleImport}
                        className="hidden"
                      />
                      <Button
                        onClick={() =>
                          document.getElementById("import-settings")?.click()
                        }
                        variant="outline"
                        className="gap-2"
                      >
                        <Upload className="h-4 w-4" />
                        استيراد الإعدادات
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-between items-center mt-6 p-4 bg-white rounded-lg border">
          <Button onClick={handleReset} variant="outline" className="gap-2">
            <RotateCcw className="h-4 w-4" />
            إعادة تعيين
          </Button>

          <Button onClick={handleSave} disabled={!hasChanges} className="gap-2">
            <Save className="h-4 w-4" />
            حفظ جميع التغييرات
          </Button>
        </div>
      </main>
    </div>
  );
}
