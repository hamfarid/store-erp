// /home/ubuntu/asset_predictor_ui/client/src/pages/Dashboard.tsx
/**
 * صفحة لوحة التحكم الرئيسية
 * Main Dashboard Page with Charts and Historical Data
 */

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import PriceChart from '@/components/PriceChart';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { PageLayout } from '@/components/PageLayout';
import { Breadcrumbs } from '@/components/ui/breadcrumbs';

interface Asset {
  id: number;
  symbol: string;
  name: string;
  category: string;
}

interface PriceData {
  date: string;
  price: number;
  predicted?: number;
  upperBound?: number;
  lowerBound?: number;
}

interface Stats {
  currentPrice: number;
  change24h: number;
  changePercent: number;
  high24h: number;
  low24h: number;
  volume: number;
}

export default function Dashboard() {
  const [selectedAsset, setSelectedAsset] = useState<string>('GC=F');
  const [timeRange, setTimeRange] = useState<string>('30d');
  const [assets, setAssets] = useState<Asset[]>([]);
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  // محاكاة تحميل البيانات
  useEffect(() => {
    // في الإنتاج، سيتم استبدال هذا بـ API call
    setLoading(true);
    
    // محاكاة الأصول
    setAssets([
      { id: 1, symbol: 'GC=F', name: 'Gold', category: 'Precious Metals' },
      { id: 2, symbol: 'BTC-USD', name: 'Bitcoin', category: 'Cryptocurrency' },
      { id: 3, symbol: 'ETH-USD', name: 'Ethereum', category: 'Cryptocurrency' },
      { id: 4, symbol: 'CL=F', name: 'Crude Oil', category: 'Energy' },
    ]);

    // محاكاة بيانات الأسعار
    const mockData: PriceData[] = [];
    const basePrice = selectedAsset === 'GC=F' ? 2000 : selectedAsset === 'BTC-USD' ? 45000 : 2500;
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
    
    for (let i = days; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const randomVariation = (Math.random() - 0.5) * 100;
      const price = basePrice + randomVariation + (i * 2);
      
      mockData.push({
        date: date.toISOString().split('T')[0],
        price: price,
        predicted: i < 7 ? price + (Math.random() - 0.5) * 50 : undefined,
        upperBound: i < 7 ? price + 100 : undefined,
        lowerBound: i < 7 ? price - 100 : undefined,
      });
    }
    
    setPriceData(mockData);

    // محاكاة الإحصائيات
    const currentPrice = mockData[mockData.length - 1].price;
    const previousPrice = mockData[mockData.length - 2].price;
    const change = currentPrice - previousPrice;
    const changePercent = (change / previousPrice) * 100;

    setStats({
      currentPrice,
      change24h: change,
      changePercent,
      high24h: Math.max(...mockData.slice(-24).map(d => d.price)),
      low24h: Math.min(...mockData.slice(-24).map(d => d.price)),
      volume: Math.floor(Math.random() * 1000000),
    });

    setTimeout(() => setLoading(false), 500);
  }, [selectedAsset, timeRange]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('en-US').format(value);
  };

  return (
    <PageLayout
      title="لوحة التحكم"
      description="تتبع وتوقع أسعار الأصول بالذكاء الاصطناعي"
      breadcrumbs={[
        { label: "الرئيسية", href: "/" },
        { label: "لوحة التحكم" },
      ]}
      actions={
        <div className="flex gap-4">
          <Select value={selectedAsset} onValueChange={setSelectedAsset}>
            <SelectTrigger className="w-48" data-testid="dashboard-asset-select">
              <SelectValue placeholder="Select Asset" />
            </SelectTrigger>
            <SelectContent>
              {assets.map((asset) => (
                <SelectItem key={asset.id} value={asset.symbol}>
                  {asset.name} ({asset.symbol})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32" data-testid="dashboard-time-range-select">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
              <SelectItem value="90d">90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      }
    >
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Price</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-2xl font-bold">{formatCurrency(stats?.currentPrice || 0)}</div>
                <p className={`text-xs ${stats && stats.changePercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {stats && stats.changePercent >= 0 ? '+' : ''}
                  {stats?.changePercent.toFixed(2)}% from yesterday
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h Change</CardTitle>
            {stats && stats.change24h >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600" />
            )}
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className={`text-2xl font-bold ${stats && stats.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {stats && stats.change24h >= 0 ? '+' : ''}
                  {formatCurrency(stats?.change24h || 0)}
                </div>
                <p className="text-xs text-muted-foreground">Last 24 hours</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h High / Low</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {formatCurrency(stats?.high24h || 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Low: {formatCurrency(stats?.low24h || 0)}
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Volume</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-2xl font-bold">{formatNumber(stats?.volume || 0)}</div>
                <p className="text-xs text-muted-foreground">24h trading volume</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Price Chart */}
      <PriceChart
        data={priceData}
        title={`${selectedAsset} Price History`}
        description={`Historical price data and predictions for the last ${timeRange}`}
        loading={loading}
        showPrediction={true}
        showConfidenceInterval={true}
      />

      {/* Additional Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Prediction Details</CardTitle>
            <CardDescription>AI model predictions and confidence intervals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Model Used:</span>
                <span className="text-sm font-medium">Ensemble (Ridge + LSTM)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Accuracy:</span>
                <span className="text-sm font-medium">99.53%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Confidence Level:</span>
                <span className="text-sm font-medium">95%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Last Updated:</span>
                <span className="text-sm font-medium">{new Date().toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Manage predictions and settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button className="w-full" variant="outline">
              Generate New Prediction
            </Button>
            <Button className="w-full" variant="outline">
              Export Historical Data
            </Button>
            <Button className="w-full" variant="outline">
              Configure Alerts
            </Button>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}

