import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Calendar,
  Target,
  Search,
  Filter,
  Download,
  RefreshCw,
  Edit,
  Trash2,
  Eye,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import CardSkeleton from "@/components/CardSkeleton";
import PaginationControls from "@/components/PaginationControls";
import { SortableTableHeader } from "@/components/SortableTableHeader";

export default function PredictionHistory() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const [searchQuery, setSearchQuery] = useState("");
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const [filterModel, setFilterModel] = useState<string>("all");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedPredictionId, setSelectedPredictionId] = useState<
    number | null
  >(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Sorting state
  const [sortField, setSortField] = useState<string>("predictionDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const {
    data: predictions,
    isLoading,
    refetch,
  } = trpc.predictions.getHistory.useQuery(
    {
      limit: 50,
    },
    {
      enabled: isAuthenticated,
    }
  );

  const { data: assets } = trpc.assets.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Delete mutation
  const deletePredictionMutation = trpc.predictions.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف التوقع بنجاح");
      refetch();
      setDeleteDialogOpen(false);
      setSelectedPredictionId(null);
    },
    onError: error => {
      toast.error(`فشل حذف التوقع: ${error.message}`);
    },
  });

  const getAssetName = (assetId: number) => {
    return (
      (assets?.find((a: any) => (a as any).id === assetId) as any)?.name ||
      `Asset #${assetId}`
    );
  };

  // Filter and sort predictions
  let filteredPredictions = predictions?.filter((prediction: any) => {
    const assetName = getAssetName((prediction as any).assetId);
    const matchesSearch = assetName
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesAsset =
      filterAsset === "all" ||
      (prediction as any).assetId.toString() === filterAsset;
    const matchesModel =
      filterModel === "all" || prediction.modelType === filterModel;
    return matchesSearch && matchesAsset && matchesModel;
  });

  // Sort predictions
  if (filteredPredictions) {
    filteredPredictions = [...filteredPredictions].sort((a: any, b: any) => {
      let aValue: any = (a as any)[sortField as keyof typeof a];
      let bValue: any = (b as any)[sortField as keyof typeof b];

      // Handle date sorting
      if (sortField === "predictionDate") {
        aValue = new Date(aValue).getTime();
        bValue = new Date(bValue).getTime();
      }

      // Handle numeric sorting
      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }

      // Handle string sorting
      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return 0;
    });
  }

  // Pagination
  const totalItems = filteredPredictions?.length || 0;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedPredictions = filteredPredictions?.slice(startIndex, endIndex);

  // Handle sort
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Export to CSV
  const handleExport = () => {
    if (!filteredPredictions || filteredPredictions.length === 0) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const csv = [
      [
        "ID",
        "Asset",
        "Date",
        "Days Ahead",
        "Current Price",
        "Predicted Price",
        "Confidence Lower",
        "Confidence Upper",
        "Model",
        "Accuracy",
      ].join(","),
      ...filteredPredictions.map((p: any) =>
        [
          (p as any).id,
          getAssetName((p as any).assetId),
          new Date((p as any).predictionDate).toLocaleDateString(),
          (p as any).daysAhead,
          (p as any).currentPrice,
          (p as any).predictedPrice,
          (p as any).confidenceLower,
          (p as any).confidenceUpper,
          (p as any).modelType,
          (p as any).accuracy || "N/A",
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `predictions_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("تم تصدير البيانات بنجاح");
  };

  // Handle delete
  const handleDeleteClick = (id: number) => {
    setSelectedPredictionId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedPredictionId) {
      deletePredictionMutation.mutate({ id: selectedPredictionId });
    }
  };

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="h-4 w-4 ml-2" />
            العودة للرئيسية
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-800">سجل التوقعات</h1>
          <p className="text-slate-600 mt-2">جميع التوقعات السابقة ودقتها</p>
        </div>

        {/* Toolbar */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4">
              {/* Search */}
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="بحث بالأصل..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="pr-10"
                  />
                </div>
              </div>

              {/* Filter by Asset */}
              <div className="w-[200px]">
                <Select value={filterAsset} onValueChange={setFilterAsset}>
                  <SelectTrigger>
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="تصفية حسب الأصل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأصول</SelectItem>
                    {assets?.map((asset: any) => (
                      <SelectItem
                        key={(asset as any).id}
                        value={(asset as any).id.toString()}
                      >
                        {(asset as any).name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Filter by Model */}
              <div className="w-[200px]">
                <Select value={filterModel} onValueChange={setFilterModel}>
                  <SelectTrigger>
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="تصفية حسب النموذج" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع النماذج</SelectItem>
                    <SelectItem value="simple">بسيط</SelectItem>
                    <SelectItem value="advanced">متقدم</SelectItem>
                    <SelectItem value="ensemble">مجمّع</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Export */}
              <Button variant="outline" onClick={handleExport}>
                <Download className="h-4 w-4 ml-2" />
                تصدير CSV
              </Button>

              {/* Refresh */}
              <Button
                variant="outline"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw
                  className={`h-4 w-4 ml-2 ${isLoading ? "animate-spin" : ""}`}
                />
                تحديث
              </Button>
            </div>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="grid grid-cols-1 gap-4">
            <CardSkeleton count={5} />
          </div>
        ) : paginatedPredictions && paginatedPredictions.length > 0 ? (
          <>
            <div className="grid grid-cols-1 gap-4">
              {paginatedPredictions.map((prediction: any) => (
                <Card
                  key={(prediction as any).id}
                  className="hover:shadow-lg transition-shadow"
                >
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                      {/* Asset Info */}
                      <div>
                        <p className="text-sm text-slate-600">الأصل</p>
                        <p className="font-semibold">
                          {getAssetName((prediction as any).assetId)}
                        </p>
                        <p className="text-xs text-slate-500">
                          {(prediction as any).modelType}
                        </p>
                      </div>

                      {/* Dates */}
                      <div>
                        <p className="text-sm text-slate-600">التاريخ</p>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4 text-slate-400" />
                          <p className="text-sm">
                            {new Date(
                              (prediction as any).predictionDate
                            ).toLocaleDateString("ar-EG")}
                          </p>
                        </div>
                        <p className="text-xs text-slate-500">
                          {(prediction as any).daysAhead} يوم
                        </p>
                      </div>

                      {/* Current Price */}
                      <div>
                        <p className="text-sm text-slate-600">السعر الحالي</p>
                        <p className="text-lg font-bold">
                          ${(prediction as any).currentPrice}
                        </p>
                      </div>

                      {/* Predicted Price */}
                      <div>
                        <p className="text-sm text-slate-600">السعر المتوقع</p>
                        <p className="text-lg font-bold text-blue-600">
                          ${(prediction as any).predictedPrice}
                        </p>
                        <p className="text-xs text-slate-500">
                          {(prediction as any).confidenceLower} -{" "}
                          {(prediction as any).confidenceUpper}
                        </p>
                      </div>

                      {/* Accuracy */}
                      <div>
                        <p className="text-sm text-slate-600">الدقة</p>
                        <div className="flex items-center gap-2">
                          {parseFloat((prediction as any).accuracy || "0") >
                          0 ? (
                            <TrendingUp className="h-5 w-5 text-green-600" />
                          ) : (
                            <TrendingDown className="h-5 w-5 text-red-600" />
                          )}
                          <span className="font-bold text-lg">
                            {(
                              parseFloat((prediction as any).accuracy || "0") *
                              100
                            ).toFixed(1)}
                            %
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            navigate(
                              `/predictions/view/${(prediction as any).id}`
                            )
                          }
                          title="عرض"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(prediction.id)}
                          title="حذف"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={totalItems}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={newSize => {
                    setPageSize(newSize);
                    setCurrentPage(1);
                  }}
                />
              </div>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Target className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg">لا توجد توقعات بعد</p>
              <Button className="mt-4" onClick={() => navigate("/")}>
                إنشاء توقع جديد
              </Button>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد الحذف</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا التوقع؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deletePredictionMutation.isPending}
            >
              {deletePredictionMutation.isPending ? "جاري الحذف..." : "حذف"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
