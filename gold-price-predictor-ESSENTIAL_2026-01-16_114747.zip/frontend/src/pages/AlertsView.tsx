import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Trash2, Edit, Bell, Mail, Smartphone } from "lucide-react";

export default function AlertsView() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams();
  const alertId = params.id ? parseInt(params.id) : null;

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // Fetch alert data
  const { data: alert, isLoading: alertLoading } = trpc.alerts.getById.useQuery(
    { id: alertId! },
    { enabled: !!alertId && isAuthenticated }
  );

  // Fetch asset data
  const { data: asset } = trpc.assets.getById.useQuery(
    { id: (alert as any)?.assetId! },
    { enabled: !!(alert as any)?.assetId && isAuthenticated }
  );

  // Delete mutation
  const deleteMutation = trpc.alerts.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف التنبيه بنجاح");
      setLocation("/alerts");
    },
    onError: error => {
      toast.error(`فشل حذف التنبيه: ${error.message}`);
    },
  });

  const handleDelete = () => {
    if (alertId) {
      deleteMutation.mutate({ id: alertId });
    }
  };

  const getConditionText = (condition: string) => {
    switch (condition) {
      case "above":
        return "أعلى من";
      case "below":
        return "أقل من";
      case "change":
        return "تغيير بنسبة";
      default:
        return condition;
    }
  };

  if (authLoading || alertLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  if (!alert) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">التنبيه غير موجود</p>
          <Button className="mt-4" onClick={() => setLocation("/alerts")}>
            العودة إلى التنبيهات
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/alerts")}
              >
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة إلى التنبيهات
              </Button>
              <h1 className="text-2xl font-bold text-slate-800">
                تفاصيل التنبيه
              </h1>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation(`/alerts/edit/${(alert as any).id}`)}
              >
                <Edit className="h-4 w-4 ml-2" />
                تعديل
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info Card */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-6 w-6 text-blue-600" />
                  {(asset as any)?.name || `Asset #${(alert as any).assetId}`}
                </CardTitle>
                <Badge
                  variant={(alert as any).isActive ? "default" : "secondary"}
                >
                  {(alert as any).isActive ? "نشط" : "غير نشط"}
                </Badge>
              </div>
              <CardDescription>
                تنبيه تم إنشاؤه في{" "}
                {new Date((alert as any).createdAt).toLocaleDateString("ar-EG")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Alert ID */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    معرف التنبيه
                  </label>
                  <p className="mt-1 text-lg font-semibold">
                    #{(alert as any).id}
                  </p>
                </div>

                {/* Asset */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    الأصل
                  </label>
                  <p className="mt-1 text-lg font-semibold">
                    {(asset as any)?.name || `Asset #${(alert as any).assetId}`}
                  </p>
                  <p className="text-sm text-slate-500">
                    {(asset as any)?.symbol}
                  </p>
                </div>

                {/* Condition */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    الشرط
                  </label>
                  <p className="mt-1 text-lg font-semibold">
                    {getConditionText((alert as any).alertType)}
                  </p>
                </div>

                {/* Target Price */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    السعر المستهدف
                  </label>
                  <p className="mt-1 text-2xl font-bold text-blue-600">
                    ${parseFloat((alert as any).targetPrice).toFixed(2)}
                  </p>
                </div>

                {/* Notification Method */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    طريقة الإشعار
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    {(alert as any).notificationMethod === "email" ? (
                      <>
                        <Mail className="h-5 w-5 text-slate-600" />
                        <span className="text-lg font-semibold">
                          بريد إلكتروني
                        </span>
                      </>
                    ) : (
                      <>
                        <Smartphone className="h-5 w-5 text-slate-600" />
                        <span className="text-lg font-semibold">
                          إشعار فوري
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Status */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    الحالة
                  </label>
                  <div className="mt-1">
                    <Badge
                      variant={
                        (alert as any).isActive ? "default" : "secondary"
                      }
                      className="text-base px-3 py-1"
                    >
                      {(alert as any).isActive ? "نشط" : "غير نشط"}
                    </Badge>
                  </div>
                </div>

                {/* Created At */}
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-slate-500">
                    تاريخ الإنشاء
                  </label>
                  <p className="mt-1 text-lg">
                    {new Date((alert as any).createdAt).toLocaleString(
                      "ar-EG",
                      {
                        dateStyle: "full",
                        timeStyle: "short",
                      }
                    )}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status Card */}
          <Card>
            <CardHeader>
              <CardTitle>حالة التنبيه</CardTitle>
              <CardDescription>معلومات الحالة الحالية</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center py-6">
                  <div
                    className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${(alert as any).isActive ? "bg-gradient-to-br from-green-500 to-emerald-600" : "bg-gradient-to-br from-slate-400 to-slate-500"} text-white mb-4`}
                  >
                    <Bell className="h-12 w-12" />
                  </div>
                  <p className="text-lg font-semibold">
                    {(alert as any).isActive
                      ? "التنبيه نشط"
                      : "التنبيه غير نشط"}
                  </p>
                  <p className="text-sm text-slate-600 mt-2">
                    {(alert as any).isActive
                      ? "سيتم إرسال إشعار عند تحقق الشرط"
                      : "لن يتم إرسال إشعارات حالياً"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mt-8 flex gap-4">
          <Button
            onClick={() => setLocation(`/alerts/edit/${(alert as any).id}`)}
          >
            <Edit className="h-4 w-4 ml-2" />
            تعديل التنبيه
          </Button>
          <Button variant="outline" onClick={() => setLocation("/alerts")}>
            العودة إلى التنبيهات
          </Button>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد الحذف</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا التنبيه؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "جاري الحذف..." : "حذف نهائياً"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
