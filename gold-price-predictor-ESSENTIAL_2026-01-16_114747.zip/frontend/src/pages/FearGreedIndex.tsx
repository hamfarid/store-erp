/**
 * Fear & Greed Index Page - Premium Gold Price Predictor
 * Modern market sentiment analysis with animated gauge
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw,
  Activity,
  BarChart3,
  Target,
  AlertTriangle,
  ArrowLeft,
  Sparkles,
  Clock,
  Gauge,
  ThermometerSun,
  Brain,
  Zap,
  History,
  Info,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Fear/Greed Gauge Component
function SentimentGauge({ value, classification }: { value: number; classification: string }) {
  const getGradientColor = (val: number) => {
    if (val <= 25) {return "from-red-600 via-red-500 to-red-400";}
    if (val <= 45) {return "from-orange-600 via-orange-500 to-orange-400";}
    if (val <= 55) {return "from-amber-500 via-yellow-500 to-yellow-400";}
    if (val <= 75) {return "from-lime-500 via-green-500 to-green-400";}
    return "from-emerald-500 via-emerald-400 to-green-400";
  };

  const rotation = (value / 100) * 180 - 90;

  return (
    <div className="relative w-64 h-32 mx-auto">
      {/* Gauge Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="w-64 h-64 rounded-full border-[20px] border-gradient-to-r from-red-500 via-yellow-500 to-green-500 opacity-20" />
      </div>
      
      {/* Gauge Track */}
      <svg className="w-full h-full" viewBox="0 0 200 100">
        {/* Background Arc */}
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke="currentColor"
          strokeWidth="16"
          className="text-muted/30"
          strokeLinecap="round"
        />
        {/* Colored Arc */}
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke="url(#gaugeGradient)"
          strokeWidth="16"
          strokeLinecap="round"
          strokeDasharray={`${(value / 100) * 251} 251`}
        />
        {/* Gradient Definition */}
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="25%" stopColor="#f97316" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="75%" stopColor="#84cc16" />
            <stop offset="100%" stopColor="#22c55e" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Needle */}
      <motion.div
        className="absolute bottom-0 left-1/2 origin-bottom w-1 h-20 bg-foreground rounded-full"
        style={{ marginLeft: "-2px" }}
        initial={{ rotate: -90 }}
        animate={{ rotate: rotation }}
        transition={{ type: "spring", stiffness: 60, damping: 15 }}
      />
      
      {/* Center Dot */}
      <div className="absolute bottom-0 left-1/2 w-4 h-4 -ml-2 mb-[-8px] rounded-full bg-foreground shadow-lg" />
      
      {/* Value Display */}
      <div className="absolute bottom-[-60px] left-1/2 -translate-x-1/2 text-center">
        <motion.p
          className={`text-5xl font-bold bg-gradient-to-r ${getGradientColor(value)} bg-clip-text text-transparent`}
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {value}
        </motion.p>
        <Badge className="mt-2" variant="outline">
          {classification}
        </Badge>
      </div>
    </div>
  );
}

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Signal Badge Component
function SignalBadge({ signal }: { signal: string }) {
  const configs: Record<string, { color: string; icon: any; label: string }> = {
    buy: { color: "bg-emerald-100 text-emerald-700 border-emerald-300", icon: TrendingUp, label: "شراء" },
    sell: { color: "bg-red-100 text-red-700 border-red-300", icon: TrendingDown, label: "بيع" },
    hold: { color: "bg-amber-100 text-amber-700 border-amber-300", icon: Minus, label: "انتظار" },
  };
  const config = configs[signal] || configs.hold;
  const Icon = config.icon;

  return (
    <Badge className={`text-lg px-4 py-2 ${config.color}`}>
      <Icon className="h-5 w-5 ml-2" />
      {config.label}
    </Badge>
  );
}

// Zone Distribution Bar
function ZoneDistributionBar({ distribution, total }: { distribution: any; total: number }) {
  const zones = [
    { key: "extremeFear", color: "bg-red-500", label: "خوف شديد" },
    { key: "fear", color: "bg-orange-500", label: "خوف" },
    { key: "neutral", color: "bg-yellow-500", label: "محايد" },
    { key: "greed", color: "bg-lime-500", label: "طمع" },
    { key: "extremeGreed", color: "bg-green-500", label: "طمع شديد" },
  ];

  return (
    <div className="space-y-3">
      <div className="flex rounded-full overflow-hidden h-6">
        {zones.map((zone, idx) => {
          const percentage = (distribution[zone.key] / total) * 100;
          return (
            <motion.div
              key={zone.key}
              className={`${zone.color} flex items-center justify-center text-white text-xs font-medium`}
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              transition={{ delay: 0.3 + idx * 0.1, duration: 0.5 }}
              title={`${zone.label}: ${distribution[zone.key]} يوم (${percentage.toFixed(1)}%)`}
            >
              {percentage > 10 && `${percentage.toFixed(0)}%`}
            </motion.div>
          );
        })}
      </div>
      <div className="flex justify-between text-xs text-muted-foreground">
        {zones.map((zone) => (
          <span key={zone.key} className="flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${zone.color}`} />
            {zone.label} ({distribution[zone.key]})
          </span>
        ))}
      </div>
    </div>
  );
}

export default function FearGreedIndex() {
  const [, navigate] = useLocation();
  const [historyDays, setHistoryDays] = useState(30);

  // Fetch current Fear & Greed Index
  const { data: current, isLoading: loadingCurrent, refetch: refetchCurrent } = trpc.fearGreed.getCurrent.useQuery(
    undefined,
    { refetchInterval: 60000 }
  );

  // Fetch analysis
  const { data: analysis, isLoading: loadingAnalysis } = trpc.fearGreed.getAnalysis.useQuery(
    { days: historyDays }
  );

  // Fetch trading signal
  const { data: signal, isLoading: loadingSignal } = trpc.fearGreed.getSignal.useQuery(
    undefined,
    { refetchInterval: 60000 }
  );

  // Fetch history
  const { data: history, isLoading: loadingHistory } = trpc.fearGreed.getHistory.useQuery(
    { days: historyDays }
  );

  const translateClassification = (classification?: string) => {
    const translations: Record<string, string> = {
      "Extreme Fear": "خوف شديد",
      "Fear": "خوف",
      "Neutral": "محايد",
      "Greed": "طمع",
      "Extreme Greed": "طمع شديد",
    };
    return translations[classification || ""] || classification;
  };

  const translateTrend = (trend?: string) => {
    const translations: Record<string, string> = {
      rising: "صاعد",
      falling: "هابط",
      stable: "مستقر",
    };
    return translations[trend || ""] || trend;
  };

  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case "rising": return <TrendingUp className="h-5 w-5 text-emerald-500" />;
      case "falling": return <TrendingDown className="h-5 w-5 text-red-500" />;
      default: return <Minus className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const isLoading = loadingCurrent || loadingAnalysis || loadingSignal || loadingHistory;

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Activity className="h-6 w-6 text-primary" />
                  مؤشر الخوف والطمع
                </h1>
                <p className="text-sm text-muted-foreground">
                  تحليل معنويات السوق وإشارات التداول
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Select value={historyDays.toString()} onValueChange={(v) => setHistoryDays(parseInt(v))}>
                <SelectTrigger data-testid="fear-greed-days-select" className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 أيام</SelectItem>
                  <SelectItem value="14">14 يوم</SelectItem>
                  <SelectItem value="30">30 يوم</SelectItem>
                  <SelectItem value="90">90 يوم</SelectItem>
                </SelectContent>
              </Select>
              <Button data-testid="refresh-fear-greed-button" variant="outline" size="sm" onClick={() => refetchCurrent()} disabled={isLoading}>
                <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                تحديث
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Main Gauge */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardContent className="pt-8 pb-16">
              {loadingCurrent ? (
                <div className="flex items-center justify-center py-16">
                  <div className="text-center">
                    <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                    <p className="mt-4 text-muted-foreground">جاري تحميل المؤشر...</p>
                  </div>
                </div>
              ) : current ? (
                <div className="flex flex-col items-center">
                  <SentimentGauge
                    value={current.value}
                    classification={translateClassification(current.classification) || ""}
                  />
                  <div className="mt-20 text-center">
                    <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
                      <Clock className="h-4 w-4" />
                      آخر تحديث: {current.timestamp ? formatDistanceToNow(new Date(current.timestamp), { addSuffix: true, locale: ar }) : "N/A"}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="p-4 rounded-full bg-amber-100 dark:bg-amber-900/30 w-fit mx-auto mb-4">
                    <AlertTriangle className="h-12 w-12 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">لا يمكن تحميل البيانات</h3>
                  <p className="text-muted-foreground">يرجى المحاولة مرة أخرى لاحقاً</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <StatCard icon={Gauge} label="القيمة الحالية" value={current?.value || "---"} color="primary" delay={0} />
          <StatCard icon={ThermometerSun} label="متوسط 7 أيام" value={analysis?.averages?.days7?.toFixed(1) || "---"} color="success" delay={0.1} />
          <StatCard icon={TrendingUp} label="أعلى قيمة" value={analysis?.extremes?.max || "---"} color="success" delay={0.2} />
          <StatCard icon={TrendingDown} label="أدنى قيمة" value={analysis?.extremes?.min || "---"} color="danger" delay={0.3} />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Trading Signal */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.1 }}
          >
            <Card className="premium-card h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  إشارة التداول
                </CardTitle>
                <CardDescription>
                  إشارة مبنية على استراتيجية المعاكسة
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingSignal ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                  </div>
                ) : signal ? (
                  <div className="space-y-6">
                    <div className="flex justify-center">
                      <SignalBadge signal={signal.signal} />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">الثقة</p>
                        <p className="text-xl font-bold">{(signal.confidence * 100).toFixed(0)}%</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">الاتجاه</p>
                        <div className="flex items-center justify-center gap-1">
                          {getTrendIcon(signal.trend)}
                          <span className="font-medium">{translateTrend(signal.trend)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-muted/50 text-center">
                      <p className="text-xs text-muted-foreground mb-1">الزخم</p>
                      <p className={`text-2xl font-bold ${
                        signal.momentum > 0 ? "text-emerald-600" : 
                        signal.momentum < 0 ? "text-red-600" : ""
                      }`}>
                        {signal.momentum > 0 ? "+" : ""}{signal.momentum.toFixed(1)}
                      </p>
                    </div>

                    <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-start gap-2">
                        <Brain className="h-5 w-5 text-primary mt-0.5" />
                        <p className="text-sm">{signal.reasoning}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    لا توجد إشارة متاحة
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Statistics */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="premium-card h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  إحصائيات الفترة
                </CardTitle>
                <CardDescription>
                  تحليل ({historyDays} يوم)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingAnalysis ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                  </div>
                ) : analysis ? (
                  <div className="space-y-6">
                    {/* Averages */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <Card className="stat-card">
                        <CardContent className="p-3 text-center">
                          <p className="text-xs text-muted-foreground">متوسط 7 أيام</p>
                          <p className="text-2xl font-bold">{analysis.averages.days7.toFixed(1)}</p>
                        </CardContent>
                      </Card>
                      <Card className="stat-card">
                        <CardContent className="p-3 text-center">
                          <p className="text-xs text-muted-foreground">متوسط 30 يوم</p>
                          <p className="text-2xl font-bold">{analysis.averages.days30.toFixed(1)}</p>
                        </CardContent>
                      </Card>
                      <Card className="stat-card bg-emerald-50 dark:bg-emerald-900/20">
                        <CardContent className="p-3 text-center">
                          <p className="text-xs text-muted-foreground">أعلى قيمة</p>
                          <p className="text-2xl font-bold text-emerald-600">{analysis.extremes.max}</p>
                        </CardContent>
                      </Card>
                      <Card className="stat-card bg-red-50 dark:bg-red-900/20">
                        <CardContent className="p-3 text-center">
                          <p className="text-xs text-muted-foreground">أدنى قيمة</p>
                          <p className="text-2xl font-bold text-red-600">{analysis.extremes.min}</p>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Zone Distribution */}
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium flex items-center gap-2">
                        <Activity className="h-4 w-4" />
                        توزيع المناطق
                      </h4>
                      <ZoneDistributionBar
                        distribution={analysis.zoneDistribution}
                        total={analysis.totalDays}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    لا توجد إحصائيات متاحة
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* History */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.3 }}
          className="mt-6"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                السجل التاريخي
              </CardTitle>
              <CardDescription>
                تطور المؤشر خلال الفترة الماضية
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingHistory ? (
                <div className="flex items-center justify-center py-12">
                  <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                </div>
              ) : (history as any[] || []).length > 0 ? (
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-2">
                    {(history as any[]).slice().reverse().map((item: any, index: number) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.03 }}
                        className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div
                            className="w-4 h-4 rounded-full shadow-lg"
                            style={{ backgroundColor: item.color }}
                          />
                          <div>
                            <p className="font-medium">
                              {format(new Date(item.date), "EEEE, d MMMM yyyy", { locale: ar })}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(item.date), { addSuffix: true, locale: ar })}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge variant="outline">{translateClassification(item.classification)}</Badge>
                          <span
                            className="text-2xl font-bold min-w-[60px] text-left"
                            style={{ color: item.color }}
                          >
                            {item.value}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-12">
                  <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                    <History className="h-12 w-12 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">لا توجد بيانات تاريخية</h3>
                  <p className="text-muted-foreground">سيتم تسجيل البيانات مع مرور الوقت</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
