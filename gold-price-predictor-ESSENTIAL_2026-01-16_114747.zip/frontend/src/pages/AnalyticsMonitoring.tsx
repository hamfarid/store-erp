/**
 * Analytics & Monitoring Page - Premium Gold Price Predictor
 * Comprehensive analytics dashboard with audit logs and system monitoring
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Progress } from "../components/ui/progress";
import { Separator } from "../components/ui/separator";
import { motion } from "framer-motion";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Activity,
  Shield,
  Database,
  RefreshCw,
  Search,
  AlertTriangle,
  LineChart,
  PieChart,
  ArrowLeft,
  Sparkles,
  CheckCircle2,
  Info,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">{value}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function AnalyticsMonitoring() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("GC=F");
  const [auditUserId, setAuditUserId] = useState("");
  const [auditDays, setAuditDays] = useState(7);
  const utils = trpc.useUtils();

  // Fetch assets using tRPC hook
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch learning trends
  const { data: learningTrends, isLoading: loadingTrends } =
    trpc.monitoring.getLearningTrends.useQuery({ days: 30 });

  // Fetch audit logs
  const {
    data: auditLogs,
    isLoading: loadingAudit,
    refetch: refetchAudit,
  } = trpc.monitoring.getAuditLogs.useQuery({
    userId: auditUserId || undefined,
    limit: 50,
  });

  // Fetch audit summary
  const { data: auditSummary } = trpc.monitoring.getAuditSummary.useQuery({
    days: auditDays,
  });

  // Fetch price analytics
  const { data: priceAnalytics, isLoading: loadingPrice } =
    trpc.monitoring.getPriceAnalytics.useQuery(
      { assetId: selectedAsset },
      { enabled: !!selectedAsset }
    );

  // Fetch portfolio performance
  const { data: portfolioPerf } =
    trpc.monitoring.getPortfolioPerformance.useQuery();

  // Initialize audit table mutation
  const initAuditMutation = trpc.monitoring.initializeAuditTable.useMutation({
    onSuccess: () => {
      utils.monitoring.getAuditLogs.invalidate();
      toast.success("تم تهيئة جدول المراجعة");
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في تهيئة جدول المراجعة");
    },
  });

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  التحليلات والمراقبة
                </h1>
                <p className="text-sm text-muted-foreground">
                  لوحة شاملة للتحليلات وسجلات المراجعة ومراقبة النظام
                </p>
              </div>
            </div>

            <Select value={selectedAsset} onValueChange={setSelectedAsset}>
              <SelectTrigger data-testid="analytics-asset-select" className="w-[180px]">
                <SelectValue placeholder="اختر الأصل" />
              </SelectTrigger>
              <SelectContent>
                {(assets as any[]).map((asset: any) => (
                  <SelectItem key={asset.id} value={asset.symbol}>
                    {asset.name} ({asset.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Activity}
            label="إجمالي الأحداث"
            value={auditSummary?.totalEvents || 0}
            color="primary"
            delay={0}
          />
          <StatCard
            icon={TrendingUp}
            label="المستخدمين النشطين"
            value={auditSummary?.topUsers?.length || 0}
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={AlertTriangle}
            label="أنواع الأحداث"
            value={Object.keys(auditSummary?.eventsByType || {}).length}
            color="warning"
            delay={0.2}
          />
          <StatCard
            icon={Database}
            label="الإجراءات"
            value={Object.keys(auditSummary?.eventsByAction || {}).length}
            color="primary"
            delay={0.3}
          />
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="analytics" className="gap-2">
              <LineChart className="h-4 w-4" />
              تحليلات الأسعار
            </TabsTrigger>
            <TabsTrigger value="audit" className="gap-2">
              <Shield className="h-4 w-4" />
              سجل المراجعة
            </TabsTrigger>
            <TabsTrigger value="trends" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              اتجاهات التعلم
            </TabsTrigger>
            <TabsTrigger value="portfolio" className="gap-2">
              <PieChart className="h-4 w-4" />
              أداء المحفظة
            </TabsTrigger>
          </TabsList>

          {/* Price Analytics Tab */}
          <TabsContent value="analytics">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <LineChart className="h-5 w-5 text-primary" />
                    تحليلات الأسعار
                  </CardTitle>
                  <CardDescription>
                    تحليل مفصل لأداء الأصل المحدد
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingPrice ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : priceAnalytics ? (
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          السعر الحالي
                        </p>
                        <p className="text-2xl font-bold">
                          ${priceAnalytics.currentPrice?.toFixed(2) || "N/A"}
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          التغير اليومي
                        </p>
                        <p
                          className={`text-2xl font-bold ${
                            ((priceAnalytics as any)?.dailyChange || 0) >= 0
                              ? "text-emerald-600"
                              : "text-red-600"
                          }`}
                        >
                          {((priceAnalytics as any)?.dailyChange || 0) >= 0
                            ? "+"
                            : ""}
                          {(priceAnalytics as any)?.dailyChange?.toFixed(2) ||
                            0}
                          %
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          التقلب
                        </p>
                        <p className="text-2xl font-bold">
                          {priceAnalytics.volatility?.toFixed(2) || "N/A"}%
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          أعلى سعر (24س)
                        </p>
                        <p className="text-2xl font-bold text-emerald-600">
                          ${priceAnalytics.high24h?.toFixed(2) || "N/A"}
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          أدنى سعر (24س)
                        </p>
                        <p className="text-2xl font-bold text-red-600">
                          ${priceAnalytics.low24h?.toFixed(2) || "N/A"}
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          حجم التداول
                        </p>
                        <p className="text-2xl font-bold">
                          {(priceAnalytics as any)?.volume?.toLocaleString() ||
                            "N/A"}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <LineChart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        لا توجد بيانات تحليلية متاحة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Audit Logs Tab */}
          <TabsContent value="audit">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.2 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="h-5 w-5 text-primary" />
                        سجل المراجعة
                      </CardTitle>
                      <CardDescription>سجل جميع العمليات في النظام</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="معرف المستخدم..."
                        value={auditUserId}
                        onChange={(e) => setAuditUserId(e.target.value)}
                        className="w-48"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => refetchAudit()}
                        disabled={loadingAudit}
                      >
                        <Search className="ml-2 h-4 w-4" />
                        بحث
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => initAuditMutation.mutate()}
                        disabled={initAuditMutation.isPending}
                      >
                        <Database className="ml-2 h-4 w-4" />
                        تهيئة
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingAudit ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : (auditLogs as any[] || []).length > 0 ? (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {(auditLogs as any[]).map((log: any, index: number) => (
                        <motion.div
                          key={index}
                          variants={cardVariants}
                          initial="initial"
                          animate="animate"
                          transition={{ delay: 0.05 * index }}
                          className="p-3 border rounded-lg hover:bg-muted/50"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge
                                variant={
                                  log.action === "create"
                                    ? "default"
                                    : log.action === "update"
                                    ? "secondary"
                                    : log.action === "delete"
                                    ? "destructive"
                                    : "outline"
                                }
                              >
                                {log.action === "create"
                                  ? "إنشاء"
                                  : log.action === "update"
                                  ? "تحديث"
                                  : log.action === "delete"
                                  ? "حذف"
                                  : log.action}
                              </Badge>
                              <span className="font-medium">{log.entityType}</span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(log.timestamp), "PPpp", {
                                locale: ar,
                              })}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            المستخدم: {log.userId || "غير معروف"} | الكيان:{" "}
                            {log.entityId || "N/A"}
                          </p>
                          {log.details && (
                            <p className="text-xs text-muted-foreground mt-1 truncate">
                              {typeof log.details === "string"
                                ? log.details
                                : JSON.stringify(log.details)}
                            </p>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد سجلات مراجعة</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Learning Trends Tab */}
          <TabsContent value="trends">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.3 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    اتجاهات التعلم
                  </CardTitle>
                  <CardDescription>
                    تطور بيانات التعلم خلال الفترة الماضية
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingTrends ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : (learningTrends as any[] || []).length > 0 ? (
                    <div className="space-y-4">
                      {(learningTrends as any[]).map(
                        (trend: any, index: number) => (
                          <motion.div
                            key={index}
                            variants={cardVariants}
                            initial="initial"
                            animate="animate"
                            transition={{ delay: 0.05 * index }}
                            className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
                          >
                            <div>
                              <p className="font-medium">{trend.date}</p>
                              <p className="text-sm text-muted-foreground">
                                {trend.category}
                              </p>
                            </div>
                            <div className="text-left">
                              <p className="text-lg font-bold">{trend.count}</p>
                              <p
                                className={`text-sm ${
                                  (trend.change || 0) >= 0
                                    ? "text-emerald-600"
                                    : "text-red-600"
                                }`}
                              >
                                {(trend.change || 0) >= 0 ? "+" : ""}
                                {trend.change || 0}%
                              </p>
                            </div>
                          </motion.div>
                        )
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        لا توجد بيانات اتجاهات متاحة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Portfolio Performance Tab */}
          <TabsContent value="portfolio">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="h-5 w-5 text-primary" />
                    أداء المحفظة
                  </CardTitle>
                  <CardDescription>
                    ملخص أداء محفظتك الاستثمارية
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {portfolioPerf ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          القيمة الإجمالية
                        </p>
                        <p className="text-2xl font-bold">
                          ${portfolioPerf.totalValue?.toFixed(2) || "0.00"}
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          التغير (24 ساعة)
                        </p>
                        <p
                          className={`text-2xl font-bold ${
                            (portfolioPerf.totalChange24h || 0) >= 0
                              ? "text-emerald-600"
                              : "text-red-600"
                          }`}
                        >
                          ${portfolioPerf.totalChange24h?.toFixed(2) || "0.00"}
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          نسبة التغير
                        </p>
                        <p
                          className={`text-2xl font-bold ${
                            (portfolioPerf.totalChangePercent24h || 0) >= 0
                              ? "text-emerald-600"
                              : "text-red-600"
                          }`}
                        >
                          {portfolioPerf.totalChangePercent24h?.toFixed(2) ||
                            "0.00"}
                          %
                        </p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">
                          عدد الأصول
                        </p>
                        <p className="text-2xl font-bold">
                          {portfolioPerf.assets?.length || 0}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <PieChart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        لا توجد بيانات محفظة متاحة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
