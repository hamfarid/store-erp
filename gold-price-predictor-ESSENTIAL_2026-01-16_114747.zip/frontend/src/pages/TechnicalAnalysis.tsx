/**
 * Technical Analysis Page - Premium Gold Price Predictor
 * Modern technical indicators dashboard with RSI, MACD, EMA
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  LineChart,
  TrendingUp,
  TrendingDown,
  Activity,
  BarChart3,
  RefreshCw,
  AlertTriangle,
  ArrowLeft,
  Sparkles,
  Target,
  Gauge,
  Zap,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Minus,
  Info,
} from "lucide-react";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Indicator Card Component
function IndicatorCard({
  title,
  description,
  icon: Icon,
  iconColor,
  data,
  children,
  delay = 0,
}: {
  title: string;
  description: string;
  icon: any;
  iconColor: string;
  data: any;
  children?: React.ReactNode;
  delay?: number;
}) {
  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="premium-card h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${iconColor}`}>
              <Icon className="h-5 w-5" />
            </div>
            {title}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>
          {data ? children : (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد بيانات
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function TechnicalAnalysis() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState<string>("");

  // Fetch assets
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch trading signals
  const {
    data: signals,
    isLoading: loadingSignals,
    refetch: refetchSignals,
  } = trpc.technicalIndicators.getTradingSignals.useQuery(
    { assetId: parseInt(selectedAsset) || 0 },
    { enabled: !!selectedAsset }
  );

  // Fetch all indicators
  const {
    data: indicators,
    isLoading: loadingIndicators,
    refetch: refetchIndicators,
  } = trpc.technicalIndicators.calculateAll.useQuery(
    { assetId: parseInt(selectedAsset) || 0 },
    { enabled: !!selectedAsset }
  );

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case "BUY":
        return "bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-900/30 dark:text-emerald-400";
      case "SELL":
        return "bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-400";
      default:
        return "bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-900/30 dark:text-amber-400";
    }
  };

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case "BUY":
        return <TrendingUp className="h-5 w-5" />;
      case "SELL":
        return <TrendingDown className="h-5 w-5" />;
      default:
        return <Activity className="h-5 w-5" />;
    }
  };

  const handleRefresh = () => {
    refetchSignals();
    refetchIndicators();
    toast.success("تم تحديث المؤشرات الفنية");
  };

  const isLoading = loadingSignals || loadingIndicators;
  const selectedAssetData = (assets as any[]).find((a: any) => a.id.toString() === selectedAsset);

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <LineChart className="h-6 w-6 text-primary" />
                  التحليل الفني
                </h1>
                <p className="text-sm text-muted-foreground">
                  مؤشرات فنية وإشارات التداول للأصول
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                <SelectTrigger data-testid="technical-asset-select" className="w-[200px]">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  {(assets as any[]).map((asset: any) => (
                    <SelectItem key={asset.id} value={asset.id.toString()}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={!selectedAsset || isLoading}
              >
                <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                تحديث
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {!selectedAsset ? (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="premium-card">
              <CardContent className="flex flex-col items-center justify-center py-20">
                <div className="p-4 rounded-full bg-primary/10 w-fit mb-4">
                  <BarChart3 className="h-16 w-16 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">اختر أصلاً للتحليل</h2>
                <p className="text-muted-foreground text-center max-w-md">
                  اختر أصلاً من القائمة أعلاه لعرض المؤشرات الفنية والإشارات
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <>
            {/* Overall Signal Card */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              className="mb-8"
            >
              <Card className={`premium-card border-2 ${
                signals?.overallSignal === "BUY" ? "border-emerald-500" :
                signals?.overallSignal === "SELL" ? "border-red-500" : "border-amber-500"
              }`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-primary" />
                    إشارة التداول الإجمالية
                  </CardTitle>
                  <CardDescription>
                    {selectedAssetData?.name || "الأصل المحدد"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">جاري حساب الإشارات...</p>
                      </div>
                    </div>
                  ) : signals ? (
                    <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                      <div className="flex items-center gap-6">
                        <div className={`p-6 rounded-2xl ${getSignalColor(signals.overallSignal)}`}>
                          {getSignalIcon(signals.overallSignal)}
                        </div>
                        <div>
                          <p className="text-4xl font-bold mb-2">
                            {signals.overallSignal === "BUY" ? "شراء" :
                             signals.overallSignal === "SELL" ? "بيع" : "انتظار"}
                          </p>
                          <div className="flex items-center gap-2">
                            <Gauge className="h-4 w-4 text-muted-foreground" />
                            <span className="text-muted-foreground">
                              ثقة: <span className="font-semibold text-foreground">{(signals.confidence * 100).toFixed(1)}%</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Individual Signals */}
                      <div className="flex flex-wrap gap-2 justify-center">
                        {signals.signals?.map((sig: any, index: number) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className={`${getSignalColor(sig.signal)} text-sm px-3 py-1`}
                          >
                            {sig.indicator}: {sig.signal === "BUY" ? "شراء" : sig.signal === "SELL" ? "بيع" : "انتظار"}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        لا توجد بيانات كافية لحساب الإشارات
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Indicators Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
              {/* RSI */}
              <IndicatorCard
                title="مؤشر القوة النسبية (RSI)"
                description="يقيس سرعة وتغير حركة السعر"
                icon={Activity}
                iconColor="bg-blue-100 dark:bg-blue-900/30 text-blue-600"
                data={signals?.indicators?.rsi}
                delay={0.1}
              >
                {signals?.indicators?.rsi && (
                  <div className="space-y-6">
                    <div className="text-center">
                      <p className="text-5xl font-bold mb-2" style={{
                        color: signals.indicators.rsi.rsi > 70 ? "#ef4444" :
                               signals.indicators.rsi.rsi < 30 ? "#10b981" : "#3b82f6"
                      }}>
                        {signals.indicators.rsi.rsi.toFixed(2)}
                      </p>
                      <div className="flex justify-between text-xs text-muted-foreground mb-2">
                        <span>تشبع بيعي (30)</span>
                        <span>تشبع شرائي (70)</span>
                      </div>
                      <Progress
                        value={signals.indicators.rsi.rsi}
                        className="h-3"
                      />
                    </div>
                    <Badge
                      variant="outline"
                      className={`w-full justify-center py-2 ${
                        signals.indicators.rsi.signal === "oversold"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-300"
                          : signals.indicators.rsi.signal === "overbought"
                          ? "bg-red-50 text-red-700 border-red-300"
                          : "bg-gray-50 text-gray-700"
                      }`}
                    >
                      {signals.indicators.rsi.signal === "oversold" ? "تشبع بيعي - فرصة شراء" :
                       signals.indicators.rsi.signal === "overbought" ? "تشبع شرائي - فرصة بيع" :
                       "منطقة محايدة"}
                    </Badge>
                  </div>
                )}
              </IndicatorCard>

              {/* MACD */}
              <IndicatorCard
                title="MACD"
                description="مؤشر تقارب وتباعد المتوسطات المتحركة"
                icon={BarChart3}
                iconColor="bg-purple-100 dark:bg-purple-900/30 text-purple-600"
                data={signals?.indicators?.macd}
                delay={0.2}
              >
                {signals?.indicators?.macd && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground mb-1">MACD</p>
                        <p className="text-lg font-bold">{signals.indicators.macd.macd.toFixed(4)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Signal</p>
                        <p className="text-lg font-bold">{signals.indicators.macd.signal.toFixed(4)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Histogram</p>
                        <p className={`text-lg font-bold ${
                          signals.indicators.macd.histogram > 0 ? "text-emerald-600" : "text-red-600"
                        }`}>
                          {signals.indicators.macd.histogram > 0 ? "+" : ""}
                          {signals.indicators.macd.histogram.toFixed(4)}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={`w-full justify-center py-2 ${
                        signals.indicators.macd.histogram > 0
                          ? "bg-emerald-50 text-emerald-700 border-emerald-300"
                          : "bg-red-50 text-red-700 border-red-300"
                      }`}
                    >
                      {signals.indicators.macd.histogram > 0 ? "اتجاه صعودي" : "اتجاه هبوطي"}
                    </Badge>
                  </div>
                )}
              </IndicatorCard>

              {/* EMA Crossover */}
              <IndicatorCard
                title="تقاطعات EMA"
                description="تقاطعات المتوسطات المتحركة الأسية"
                icon={TrendingUpIcon}
                iconColor="bg-orange-100 dark:bg-orange-900/30 text-orange-600"
                data={signals?.indicators?.latestCrossover}
                delay={0.3}
              >
                {signals?.indicators?.latestCrossover ? (
                  <div className="space-y-4">
                    <div className={`p-6 rounded-xl text-center ${
                      signals.indicators.latestCrossover.type === "bullish"
                        ? "bg-emerald-50 dark:bg-emerald-900/20 border-2 border-emerald-200 dark:border-emerald-800"
                        : "bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800"
                    }`}>
                      <div className={`p-3 rounded-full w-fit mx-auto mb-3 ${
                        signals.indicators.latestCrossover.type === "bullish"
                          ? "bg-emerald-100 dark:bg-emerald-900/30"
                          : "bg-red-100 dark:bg-red-900/30"
                      }`}>
                        {signals.indicators.latestCrossover.type === "bullish" ? (
                          <TrendingUpIcon className="h-8 w-8 text-emerald-600" />
                        ) : (
                          <TrendingDownIcon className="h-8 w-8 text-red-600" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">آخر تقاطع</p>
                      <p className={`text-2xl font-bold ${
                        signals.indicators.latestCrossover.type === "bullish" ? "text-emerald-700" : "text-red-700"
                      }`}>
                        {signals.indicators.latestCrossover.type === "bullish" ? "تقاطع ذهبي (صعودي)" : "تقاطع الموت (هبوطي)"}
                      </p>
                      <p className="text-xs text-muted-foreground mt-3">
                        EMA السريع: ${signals.indicators.latestCrossover.fast.toFixed(2)} | EMA البطيء: ${signals.indicators.latestCrossover.slow.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertTriangle className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">لا توجد تقاطعات حديثة</p>
                  </div>
                )}
              </IndicatorCard>
            </div>

            {/* Signal Details */}
            {signals?.signals && signals.signals.length > 0 && (
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.4 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Info className="h-5 w-5 text-primary" />
                      تفاصيل الإشارات
                    </CardTitle>
                    <CardDescription>
                      تحليل مفصل لكل مؤشر فني
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {signals.signals.map((sig: any, index: number) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.5 + index * 0.1 }}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div className={`p-3 rounded-xl ${getSignalColor(sig.signal)}`}>
                              {getSignalIcon(sig.signal)}
                            </div>
                            <div>
                              <p className="font-semibold">{sig.indicator}</p>
                              <p className="text-sm text-muted-foreground">{sig.description}</p>
                            </div>
                          </div>
                          <div className="text-left">
                            <Badge className={`${getSignalColor(sig.signal)} mb-2`}>
                              {sig.signal === "BUY" ? "شراء" : sig.signal === "SELL" ? "بيع" : "انتظار"}
                            </Badge>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Zap className="h-3 w-3" />
                              <span>قوة: {(sig.strength * 100).toFixed(0)}%</span>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
