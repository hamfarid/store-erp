/**
 * Help Center Page - Premium Gold Price Predictor
 * Comprehensive help with FAQ and support options
 */

import { useState } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { APP_TITLE } from "@/const";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  BookOpen,
  HelpCircle,
  Video,
  MessageCircle,
  Mail,
  FileText,
  Search,
  Play,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Zap,
  Brain,
  Bell,
  BarChart3,
  Settings,
  Download,
  Shield,
  Lightbulb,
  Clock,
} from "lucide-react";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const FAQ_CATEGORIES = [
  { id: "getting-started", label: "البدء", icon: Zap },
  { id: "predictions", label: "التوقعات", icon: Brain },
  { id: "alerts", label: "التنبيهات", icon: Bell },
  { id: "settings", label: "الإعدادات", icon: Settings },
];

const FAQ_DATA = {
  "getting-started": [
    {
      question: "كيف أبدأ في استخدام النظام؟",
      answer: `بعد تسجيل الدخول، ستجد الصفحة الرئيسية تعرض لك جميع الأصول المتاحة مع أسعارها الحالية.
      
يمكنك:
• الانتقال إلى صفحة "توقع" لإنشاء توقع جديد
• عرض سجل التوقعات السابقة
• إنشاء تنبيهات للأسعار
• استعراض الأسعار التاريخية`,
    },
    {
      question: "كيف أنشئ حساباً جديداً؟",
      answer: `1. اضغط على "تسجيل" من الصفحة الرئيسية
2. أدخل بياناتك (الاسم، البريد الإلكتروني، كلمة المرور)
3. تأكد من إدخال كلمة مرور قوية
4. اضغط على "إنشاء حساب"
5. ستتلقى بريداً للتأكيد (اختياري)`,
    },
    {
      question: "هل يمكنني استخدام النظام على الهاتف؟",
      answer: `نعم! النظام مصمم بتقنية Responsive Design ويعمل بشكل ممتاز على جميع الأجهزة:
• الهواتف الذكية
• الأجهزة اللوحية
• أجهزة الكمبيوتر

الواجهة تتكيف تلقائياً مع حجم الشاشة.`,
    },
  ],
  predictions: [
    {
      question: "كيف أنشئ توقع جديد؟",
      answer: `لإنشاء توقع جديد:
1. انتقل إلى صفحة "التوقعات"
2. اختر الأصل المالي (ذهب، بيتكوين، إلخ)
3. اختر النموذج (Ensemble موصى به)
4. حدد الفترة الزمنية (7-90 يوم)
5. اضغط على "توليد التوقعات"

سيتم عرض التوقع مع رسم بياني ومستوى الثقة.`,
    },
    {
      question: "ما هي دقة التوقعات؟",
      answer: `يستخدم النظام نماذج متقدمة بدقة:
• 1-7 أيام: 99%+ (LSTM + Ensemble)
• 8-14 يوم: 95-98%
• 15-30 يوم: 85-95%
• 30-90 يوم: 75-85%

يتم تحديث النماذج بشكل مستمر لتحسين الدقة.`,
    },
    {
      question: "ما الفرق بين النماذج المختلفة؟",
      answer: `• Ensemble: يجمع بين عدة نماذج للحصول على أفضل دقة (موصى به)
• LSTM: شبكة عصبية متقدمة للتسلسلات الزمنية
• Ridge: نموذج إحصائي بسيط وسريع
• XGBoost: نموذج تعلم آلي قوي

كل نموذج له نقاط قوة مختلفة حسب نوع الأصل والفترة الزمنية.`,
    },
  ],
  alerts: [
    {
      question: "كيف أنشئ تنبيه للأسعار؟",
      answer: `1. انتقل إلى صفحة "التنبيهات"
2. اضغط على "تنبيه جديد"
3. اختر الأصل المالي
4. حدد نوع التنبيه:
   • أعلى من: تنبيه عند ارتفاع السعر
   • أقل من: تنبيه عند انخفاض السعر
   • تغيير بنسبة: تنبيه عند تغيير محدد
5. أدخل القيمة المستهدفة
6. اختر قناة الإشعار`,
    },
    {
      question: "ما هي قنوات الإشعار المتاحة؟",
      answer: `• البريد الإلكتروني: إشعار على بريدك
• إشعار فوري: إشعار في المتصفح
• كلاهما: إشعار في القناتين

يمكنك تخصيص الإشعارات من صفحة الإعدادات.`,
    },
    {
      question: "كيف أعطّل تنبيهاً مؤقتاً؟",
      answer: `من صفحة التنبيهات:
1. ابحث عن التنبيه المطلوب
2. استخدم مفتاح التفعيل/الإيقاف
3. يمكنك إعادة تفعيله لاحقاً

لن يتم حذف التنبيه، فقط سيتوقف عن الإرسال.`,
    },
  ],
  settings: [
    {
      question: "كيف أغير إعدادات الإشعارات؟",
      answer: `1. انتقل إلى "الإعدادات"
2. اختر تبويب "الإشعارات"
3. تحكم في:
   • إشعارات البريد الإلكتروني
   • الإشعارات الفورية
   • تنبيهات الأسعار
   • التقرير الأسبوعي`,
    },
    {
      question: "كيف أصدّر البيانات؟",
      answer: `• من أي قائمة: زر "تصدير CSV"
• من الإعدادات > البيانات: تصدير شامل
• قاعدة البيانات الكاملة
• نماذج ML المدربة
• نسخة احتياطية كاملة`,
    },
    {
      question: "كيف أغير المظهر؟",
      answer: `من الإعدادات > المظهر:
• السمة: فاتح / داكن / تلقائي
• اللغة: العربية / English
• الوضع المضغوط
• الرسوم المتحركة`,
    },
  ],
};

const TUTORIALS = [
  {
    title: "البدء السريع",
    duration: "5 دقائق",
    thumbnail: "/tutorials/quick-start.png",
    description: "تعلم أساسيات استخدام النظام",
  },
  {
    title: "إنشاء توقعات دقيقة",
    duration: "8 دقائق",
    thumbnail: "/tutorials/predictions.png",
    description: "كيفية استخدام نماذج AI للتوقع",
  },
  {
    title: "إعداد التنبيهات الذكية",
    duration: "6 دقائق",
    thumbnail: "/tutorials/alerts.png",
    description: "تخصيص تنبيهات الأسعار",
  },
  {
    title: "تحليل الرسوم البيانية",
    duration: "10 دقائق",
    thumbnail: "/tutorials/charts.png",
    description: "قراءة وتحليل البيانات",
  },
];

export default function Help() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("getting-started");

  const filteredFAQ = FAQ_DATA[selectedCategory as keyof typeof FAQ_DATA]?.filter(
    (item) =>
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <HelpCircle className="h-6 w-6 text-primary" />
                  مركز المساعدة
                </h1>
                <p className="text-sm text-muted-foreground">
                  كل ما تحتاج معرفته عن {APP_TITLE}
                </p>
              </div>
            </div>
            <Link href="/about">
              <Button variant="outline" size="sm">
                عن النظام
                <ChevronRight className="mr-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Search */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="bg-card/80 backdrop-blur-sm overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
            <CardContent className="pt-6">
              <div className="relative max-w-xl mx-auto">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="ابحث في الأسئلة الشائعة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 text-lg h-12"
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Links */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
        >
          <Card className="stat-card group cursor-pointer" onClick={() => navigate("/predictions")}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">دليل البدء السريع</h3>
                  <p className="text-sm text-muted-foreground">
                    تعلم الأساسيات في دقائق
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </CardContent>
          </Card>

          <Card className="stat-card group cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 group-hover:bg-emerald-200 dark:group-hover:bg-emerald-900/50 transition-colors">
                  <Video className="h-6 w-6 text-emerald-600" />
                </div>
                <div>
                  <h3 className="font-semibold">فيديوهات تعليمية</h3>
                  <p className="text-sm text-muted-foreground">
                    شاهد دروس فيديو مفصلة
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </CardContent>
          </Card>

          <Card className="stat-card group cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-purple-100 dark:bg-purple-900/30 group-hover:bg-purple-200 dark:group-hover:bg-purple-900/50 transition-colors">
                  <FileText className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold">التوثيق الكامل</h3>
                  <p className="text-sm text-muted-foreground">
                    الوثائق التقنية الشاملة
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* FAQ Section */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  الأسئلة الشائعة
                </CardTitle>
                <CardDescription>إجابات على الأسئلة الأكثر شيوعاً</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
                  <TabsList className="grid grid-cols-4 w-full mb-4">
                    {FAQ_CATEGORIES.map((cat) => (
                      <TabsTrigger key={cat.id} value={cat.id} className="gap-2">
                        <cat.icon className="h-4 w-4" />
                        <span className="hidden sm:inline">{cat.label}</span>
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  {FAQ_CATEGORIES.map((cat) => (
                    <TabsContent key={cat.id} value={cat.id}>
                      <Accordion type="single" collapsible className="w-full">
                        {FAQ_DATA[cat.id as keyof typeof FAQ_DATA]
                          ?.filter(
                            (item) =>
                              !searchQuery ||
                              item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              item.answer.toLowerCase().includes(searchQuery.toLowerCase())
                          )
                          .map((item, index) => (
                            <AccordionItem key={index} value={`item-${index}`}>
                              <AccordionTrigger className="text-right">
                                {item.question}
                              </AccordionTrigger>
                              <AccordionContent>
                                <p className="text-muted-foreground whitespace-pre-line">
                                  {item.answer}
                                </p>
                              </AccordionContent>
                            </AccordionItem>
                          ))}
                      </Accordion>
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </motion.div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Video Tutorials */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Video className="h-5 w-5 text-primary" />
                    دروس فيديو
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {TUTORIALS.slice(0, 3).map((tutorial, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    >
                      <div className="w-16 h-10 rounded bg-muted flex items-center justify-center">
                        <Play className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{tutorial.title}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {tutorial.duration}
                        </p>
                      </div>
                    </div>
                  ))}
                  <Button variant="ghost" className="w-full text-sm">
                    عرض جميع الفيديوهات
                    <ChevronRight className="mr-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contact Support */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <MessageCircle className="h-5 w-5 text-primary" />
                    لم تجد ما تبحث عنه؟
                  </CardTitle>
                  <CardDescription>تواصل مع فريق الدعم الفني</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full glow-gold">
                    <MessageCircle className="ml-2 h-4 w-4" />
                    الدردشة المباشرة
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Mail className="ml-2 h-4 w-4" />
                    إرسال بريد إلكتروني
                  </Button>
                  <p className="text-xs text-center text-muted-foreground">
                    فريق الدعم متاح 24/7
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Useful Links */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">روابط مفيدة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {[
                    { label: "عن النظام", href: "/about" },
                    { label: "الإعدادات", href: "/settings" },
                    { label: "سياسة الخصوصية", href: "#" },
                    { label: "شروط الاستخدام", href: "#" },
                  ].map((link, i) => (
                    <Link key={i} href={link.href}>
                      <Button variant="ghost" className="w-full justify-start text-sm">
                        {link.label}
                        <ExternalLink className="mr-auto h-3 w-3" />
                      </Button>
                    </Link>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
