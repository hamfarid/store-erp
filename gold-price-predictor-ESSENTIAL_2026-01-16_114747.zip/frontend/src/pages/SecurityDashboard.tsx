/**
 * Security Dashboard Page - Premium Gold Price Predictor
 * Admin dashboard for security monitoring and management
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Separator } from "../components/ui/separator";
import { motion } from "framer-motion";
import {
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Lock,
  Unlock,
  Eye,
  UserX,
  Activity,
  AlertOctagon,
  Clock,
  ArrowLeft,
  Sparkles,
  Target,
  BarChart3,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">{value}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function SecurityDashboard() {
  const [, navigate] = useLocation();
  const [selectedUserId, setSelectedUserId] = useState("");
  const [ipToUnblock, setIpToUnblock] = useState("");
  const utils = trpc.useUtils();

  // Fetch security summary using tRPC hook
  const {
    data: summary,
    isLoading: loadingSummary,
    refetch: refetchSummary,
  } = trpc.security.getSummary.useQuery({ days: 7 }, { refetchInterval: 30000 });

  // Fetch security events
  const {
    data: events,
    isLoading: loadingEvents,
    refetch: refetchEvents,
  } = trpc.security.getEvents.useQuery({ limit: 50 });

  // Fetch active sessions count
  const { data: activeSessions } = trpc.security.getActiveSessionsCount.useQuery(
    undefined,
    { refetchInterval: 60000 }
  );

  // Fetch blocked IPs
  const { data: blockedIPs, refetch: refetchBlocked } =
    trpc.security.getBlockedIPs.useQuery();

  // Force logout mutation
  const forceLogoutMutation = trpc.security.forceLogout.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل خروج المستخدم بنجاح");
      utils.security.getEvents.invalidate();
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في تسجيل خروج المستخدم");
    },
  });

  // Clear rate limit mutation
  const clearRateLimitMutation = trpc.security.clearRateLimitForIP.useMutation({
    onSuccess: () => {
      toast.success("تم إلغاء حظر العنوان بنجاح");
      setIpToUnblock("");
      refetchBlocked();
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في إلغاء الحظر");
    },
  });

  const handleRefreshAll = () => {
    refetchSummary();
    refetchEvents();
    refetchBlocked();
    toast.success("تم تحديث البيانات");
  };

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "login_success":
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case "login_failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "session_hijack_detected":
        return <AlertOctagon className="h-4 w-4 text-red-600" />;
      case "rate_limit_exceeded":
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case "logout":
        return <Lock className="h-4 w-4 text-blue-500" />;
      case "session_created":
        return <Unlock className="h-4 w-4 text-emerald-500" />;
      default:
        return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  const getEventBadgeColor = (eventType: string) => {
    switch (eventType) {
      case "login_success":
      case "session_created":
        return "bg-emerald-100 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400";
      case "login_failed":
      case "session_hijack_detected":
        return "bg-red-100 dark:bg-red-950/20 text-red-800 dark:text-red-400";
      case "rate_limit_exceeded":
        return "bg-amber-100 dark:bg-amber-950/20 text-amber-800 dark:text-amber-400";
      case "logout":
        return "bg-blue-100 dark:bg-blue-950/20 text-blue-800 dark:text-blue-400";
      default:
        return "bg-gray-100 dark:bg-gray-950/20 text-gray-800 dark:text-gray-400";
    }
  };

  const translateEventType = (eventType: string) => {
    const translations: Record<string, string> = {
      login_success: "تسجيل دخول ناجح",
      login_failed: "فشل تسجيل الدخول",
      session_hijack_detected: "محاولة اختطاف جلسة",
      rate_limit_exceeded: "تجاوز الحد المسموح",
      logout: "تسجيل خروج",
      session_created: "إنشاء جلسة",
      admin_force_logout: "تسجيل خروج إجباري",
      admin_clear_rate_limit: "إلغاء حظر من المسؤول",
      ip_mismatch: "تغيير عنوان IP",
      useragent_mismatch: "تغيير المتصفح",
    };
    return translations[eventType] || eventType;
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Shield className="h-6 w-6 text-primary" />
                  لوحة الأمان
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة الأمان وإدارة الجلسات والحماية من الاختراق
                </p>
              </div>
            </div>

            <Button data-testid="refresh-security-button" onClick={handleRefreshAll} variant="outline" size="sm">
              <RefreshCw className="ml-2 h-4 w-4" />
              تحديث
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Activity}
            label="الجلسات النشطة"
            value={activeSessions?.activeSessions || 0}
            color="primary"
            delay={0}
          />
          <StatCard
            icon={CheckCircle}
            label="تسجيلات دخول ناجحة"
            value={summary?.successfulLogins || 0}
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={XCircle}
            label="محاولات فاشلة"
            value={summary?.failedLogins || 0}
            color="danger"
            delay={0.2}
          />
          <StatCard
            icon={AlertOctagon}
            label="نشاط مشبوه"
            value={summary?.suspiciousActivity || 0}
            color="warning"
            delay={0.3}
          />
        </div>

        <Tabs defaultValue="events" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="events" className="gap-2">
              <Eye className="h-4 w-4" />
              أحداث الأمان
            </TabsTrigger>
            <TabsTrigger value="blocked" className="gap-2">
              <Lock className="h-4 w-4" />
              العناوين المحظورة
            </TabsTrigger>
            <TabsTrigger value="actions" className="gap-2">
              <Shield className="h-4 w-4" />
              إجراءات أمنية
            </TabsTrigger>
          </TabsList>

          {/* Security Events Tab */}
          <TabsContent value="events">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5 text-primary" />
                    سجل أحداث الأمان
                  </CardTitle>
                  <CardDescription>آخر 50 حدث أمني</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingEvents ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : ((events as any[]) || []).length > 0 ? (
                    <div className="space-y-3 max-h-[600px] overflow-y-auto">
                      {(events as any[]).map((event: any, index: number) => (
                        <motion.div
                          key={index}
                          variants={cardVariants}
                          initial="initial"
                          animate="animate"
                          transition={{ delay: 0.05 * index }}
                          className="flex items-start justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            {getEventIcon(event.eventType)}
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <Badge className={getEventBadgeColor(event.eventType)}>
                                  {translateEventType(event.eventType)}
                                </Badge>
                                {event.userId && (
                                  <span className="text-xs text-muted-foreground">
                                    المستخدم: {event.userId.substring(0, 8)}...
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">
                                IP: {event.ipAddress || "غير معروف"}
                              </p>
                              {event.details && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {typeof event.details === "string"
                                    ? event.details
                                    : JSON.stringify(event.details)}
                                </p>
                              )}
                            </div>
                          </div>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {event.timestamp
                              ? format(new Date(event.timestamp), "HH:mm:ss PP", {
                                  locale: ar,
                                })
                              : "N/A"}
                          </span>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        لا توجد أحداث أمنية مسجلة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Blocked IPs Tab */}
          <TabsContent value="blocked">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.2 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5 text-primary" />
                    العناوين المحظورة
                  </CardTitle>
                  <CardDescription>
                    العناوين التي تجاوزت الحد المسموح
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {((blockedIPs as any[]) || []).length > 0 ? (
                    <div className="space-y-3">
                      {(blockedIPs as any[]).map((item: any, index: number) => (
                        <motion.div
                          key={index}
                          variants={cardVariants}
                          initial="initial"
                          animate="animate"
                          transition={{ delay: 0.05 * index }}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <Lock className="h-5 w-5 text-red-500" />
                            <div>
                              <p className="font-mono">{item.ipAddress}</p>
                              <p className="text-sm text-muted-foreground">
                                عدد المحاولات: {item.count}
                              </p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              clearRateLimitMutation.mutate(item.ipAddress)
                            }
                            disabled={clearRateLimitMutation.isPending}
                          >
                            <Unlock className="ml-2 h-4 w-4" />
                            إلغاء الحظر
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <CheckCircle className="h-12 w-12 text-emerald-500 mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد عناوين محظورة</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Security Actions Tab */}
          <TabsContent value="actions">
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.3 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <UserX className="h-5 w-5 text-primary" />
                      تسجيل خروج إجباري
                    </CardTitle>
                    <CardDescription>
                      إنهاء جلسة مستخدم بشكل إجباري
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>معرف المستخدم</Label>
                      <Input
                        placeholder="معرف المستخدم..."
                        value={selectedUserId}
                        onChange={(e) => setSelectedUserId(e.target.value)}
                      />
                    </div>
                    <Button
                      className="w-full"
                      variant="destructive"
                      onClick={() => {
                        if (selectedUserId) {
                          forceLogoutMutation.mutate({ userId: selectedUserId });
                        }
                      }}
                      disabled={
                        !selectedUserId || forceLogoutMutation.isPending
                      }
                    >
                      <UserX className="ml-2 h-4 w-4" />
                      تسجيل خروج المستخدم
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.4 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Unlock className="h-5 w-5 text-primary" />
                      إلغاء حظر عنوان IP
                    </CardTitle>
                    <CardDescription>
                      إلغاء حظر عنوان IP تم حظره
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>عنوان IP</Label>
                      <Input
                        placeholder="عنوان IP..."
                        value={ipToUnblock}
                        onChange={(e) => setIpToUnblock(e.target.value)}
                      />
                    </div>
                    <Button
                      className="w-full"
                      variant="secondary"
                      onClick={() => {
                        if (ipToUnblock) {
                          clearRateLimitMutation.mutate({ ip: ipToUnblock });
                        }
                      }}
                      disabled={
                        !ipToUnblock || clearRateLimitMutation.isPending
                      }
                    >
                      <Unlock className="ml-2 h-4 w-4" />
                      إلغاء الحظر
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
