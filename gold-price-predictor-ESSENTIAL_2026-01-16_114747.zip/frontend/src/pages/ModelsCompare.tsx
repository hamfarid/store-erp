import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import {
  BarChart3,
  Target,
  RefreshCw,
  Award,
  Zap,
  Brain,
  AlertCircle,
} from "lucide-react";

export default function ModelsCompare() {
  const [selectedAssetId, setSelectedAssetId] = useState<number | null>(null);

  // Fetch assets
  const { data: assetsData } = trpc.assets.list.useQuery();
  const assets = (assetsData as any)?.data?.assets || assetsData || [];

  // Fetch model comparison
  const {
    data: comparisonData,
    isLoading,
    refetch,
  } = trpc.performance.getModelComparison.useQuery(
    { assetId: selectedAssetId || 1 },
    { enabled: !!selectedAssetId }
  );
  const performance = (comparisonData as any)?.data?.performance || (comparisonData as any)?.performance || [];

  const models = [
    { name: "Ridge Regression", icon: BarChart3, color: "bg-blue-500" },
    { name: "LSTM Neural Network", icon: Brain, color: "bg-purple-500" },
    { name: "Ensemble Model", icon: Zap, color: "bg-amber-500" },
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <BarChart3 className="h-8 w-8 text-primary" />
            مقارنة النماذج
          </h1>
          <p className="text-muted-foreground mt-1">
            قارن أداء نماذج التنبؤ المختلفة
          </p>
        </div>
        <Button variant="outline" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4 ml-2" />
          تحديث
        </Button>
      </div>

      {/* Asset Selection */}
      <Card>
        <CardHeader>
          <CardTitle>اختر الأصل</CardTitle>
          <CardDescription>اختر الأصل لعرض مقارنة أداء النماذج</CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedAssetId?.toString() || ""}
            onValueChange={v => setSelectedAssetId(Number(v))}
          >
            <SelectTrigger className="w-full md:w-[300px]">
              <SelectValue placeholder="اختر أصل..." />
            </SelectTrigger>
            <SelectContent>
              {assets.map((asset: any) => (
                <SelectItem key={asset.id} value={asset.id.toString()}>
                  {asset.name} ({asset.symbol})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Models Comparison */}
      {selectedAssetId && (
        <>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-amber-800">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              <span className="font-medium">ملاحظة:</span>
            </div>
            <p className="mt-1 text-sm">
              هذه البيانات مُحاكاة لأغراض العرض. للحصول على بيانات حقيقية، يجب
              تدريب النماذج على البيانات التاريخية.
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {models.map((model, index) => {
              const modelData = performance[index] || {};
              // Use actual data if available, otherwise use realistic simulated values
              const baseAccuracy = [87.5, 91.2, 93.8][index];
              const baseMse = [0.0234, 0.0187, 0.0145][index];
              const baseMae = [0.0156, 0.0123, 0.0098][index];

              const accuracy = modelData.accuracy || baseAccuracy;
              const mse = modelData.mse || baseMse;
              const mae = modelData.mae || baseMae;

              return (
                <Card key={model.name} className="relative overflow-hidden">
                  <div
                    className={`absolute top-0 left-0 right-0 h-1 ${model.color}`}
                  />
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <model.icon className="h-5 w-5" />
                      {model.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        الدقة
                      </span>
                      <Badge variant={accuracy > 85 ? "default" : "secondary"}>
                        {accuracy.toFixed(1)}%
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">MSE</span>
                      <span className="font-mono text-sm">
                        {mse.toFixed(4)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">MAE</span>
                      <span className="font-mono text-sm">
                        {mae.toFixed(4)}
                      </span>
                    </div>
                    {index === 2 && (
                      <div className="flex items-center gap-2 text-amber-600 mt-2">
                        <Award className="h-4 w-4" />
                        <span className="text-sm font-medium">
                          الأفضل أداءً
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {!selectedAssetId && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>اختر أصلاً لعرض مقارنة النماذج</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
