import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Edit, Trash2, Printer } from "lucide-react";

export default function AssetsView() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams();
  const assetId = params.id ? parseInt(params.id) : null;

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // Fetch asset data
  const { data: asset, isLoading: assetLoading } = trpc.assets.getById.useQuery(
    { id: assetId! },
    { enabled: !!assetId && isAuthenticated }
  );

  // Delete mutation
  const deleteAssetMutation = trpc.assets.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الأصل بنجاح");
      setLocation("/assets");
    },
    onError: error => {
      toast.error(`فشل حذف الأصل: ${error.message}`);
    },
  });

  const handleDelete = () => {
    if (assetId) {
      deleteAssetMutation.mutate({ id: assetId });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (authLoading || assetLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  if (!asset) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">الأصل غير موجود</p>
          <Button className="mt-4" onClick={() => setLocation("/assets")}>
            العودة إلى القائمة
          </Button>
        </div>
      </div>
    );
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      commodity: "سلعة",
      crypto: "عملة رقمية",
      currency: "عملة",
      stock: "سهم",
    };
    return labels[type] || type;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 print:hidden">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/assets")}
              >
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة إلى القائمة
              </Button>
              <h1 className="text-2xl font-bold text-slate-800">
                تفاصيل الأصل
              </h1>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="h-4 w-4 ml-2" />
                طباعة
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation(`/assets/edit/${assetId}`)}
              >
                <Edit className="h-4 w-4 ml-2" />
                تعديل
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>{(asset as any).name}</CardTitle>
            <CardDescription>معلومات تفصيلية عن الأصل</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* ID */}
              <div>
                <label className="text-sm font-medium text-slate-500">
                  معرف الأصل
                </label>
                <p className="mt-1 text-lg font-semibold">
                  {(asset as any).id}
                </p>
              </div>

              {/* Name */}
              <div>
                <label className="text-sm font-medium text-slate-500">
                  الاسم
                </label>
                <p className="mt-1 text-lg font-semibold">
                  {(asset as any).name}
                </p>
              </div>

              {/* Symbol */}
              <div>
                <label className="text-sm font-medium text-slate-500">
                  الرمز
                </label>
                <p className="mt-1 text-lg font-semibold">
                  {(asset as any).symbol}
                </p>
              </div>

              {/* Type */}
              <div>
                <label className="text-sm font-medium text-slate-500">
                  النوع
                </label>
                <p className="mt-1 text-lg font-semibold">
                  {getTypeLabel((asset as any).type)}
                </p>
              </div>

              {/* Yahoo Symbol */}
              <div>
                <label className="text-sm font-medium text-slate-500">
                  رمز Yahoo Finance
                </label>
                <p className="mt-1 text-lg font-mono">
                  {(asset as any).yahooSymbol}
                </p>
              </div>

              {/* Description */}
              {(asset as any).description && (
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-slate-500">
                    الوصف
                  </label>
                  <p className="mt-1 text-base text-slate-700 whitespace-pre-wrap">
                    {(asset as any).description}
                  </p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t flex gap-4 print:hidden">
              <Button
                onClick={() => setLocation(`/predict/${(asset as any).id}`)}
              >
                إنشاء توقع جديد
              </Button>
              <Button
                variant="outline"
                onClick={() => setLocation(`/assets/edit/${assetId}`)}
              >
                تعديل المعلومات
              </Button>
              <Button variant="outline" onClick={() => setLocation("/assets")}>
                العودة إلى القائمة
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد الحذف</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف الأصل "{(asset as any).name}"؟ سيتم حذف جميع
              التوقعات والتنبيهات المرتبطة به. لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteAssetMutation.isPending}
            >
              {deleteAssetMutation.isPending ? "جاري الحذف..." : "حذف نهائياً"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
