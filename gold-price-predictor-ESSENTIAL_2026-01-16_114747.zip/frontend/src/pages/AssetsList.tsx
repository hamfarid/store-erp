/**
 * Assets List Page - Premium Gold Price Predictor
 * Modern asset management with grid and table views
 */

import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  Plus,
  Search,
  Filter,
  Download,
  RefreshCw,
  Edit,
  Trash2,
  Eye,
  ArrowLeft,
  Coins,
  TrendingUp,
  TrendingDown,
  Grid3X3,
  List,
  BarChart3,
  Sparkles,
  AlertTriangle,
  Bitcoin,
  DollarSign,
  Gem,
  Fuel,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import PaginationControls from "@/components/PaginationControls";
import { SortableTableHeader } from "@/components/SortableTableHeader";
import BulkActionsToolbar from "@/components/BulkActionsToolbar";
import { Checkbox } from "@/components/ui/checkbox";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Asset type icons
const assetIcons: Record<string, any> = {
  commodity: Gem,
  crypto: Bitcoin,
  currency: DollarSign,
  stock: BarChart3,
  oil: Fuel,
};

// Asset type colors
const assetColors: Record<string, string> = {
  commodity: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
  crypto: "bg-purple-100 dark:bg-purple-900/30 text-purple-600",
  currency: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
  stock: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
  oil: "bg-orange-100 dark:bg-orange-900/30 text-orange-600",
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "info";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    info: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
  };

  return (
    <Card className="stat-card">
      <CardContent className="pt-6">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${colors[color]}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Asset Card Component for Grid View
function AssetCard({
  asset,
  onView,
  onEdit,
  onDelete,
  delay = 0,
}: {
  asset: any;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
  delay?: number;
}) {
  const Icon = assetIcons[asset.type] || Coins;
  const colorClass = assetColors[asset.type] || assetColors.commodity;

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card overflow-hidden h-full">
        <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
        <CardContent className="pt-6">
          <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-xl ${colorClass}`}>
              <Icon className="h-6 w-6" />
            </div>
            <Badge variant="secondary" className="text-xs">
              {getTypeLabel(asset.type)}
            </Badge>
          </div>
          
          <h3 className="font-semibold text-lg mb-1">{asset.name}</h3>
          <p className="text-sm text-muted-foreground mb-4">{asset.symbol}</p>
          
          {asset.currentPrice && (
            <div className="flex items-center gap-2 mb-4">
              <span className="text-xl font-bold">${asset.currentPrice}</span>
              {asset.priceChange && (
                <Badge variant={asset.priceChange >= 0 ? "default" : "destructive"} className="text-xs">
                  {asset.priceChange >= 0 ? (
                    <TrendingUp className="h-3 w-3 mr-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-1" />
                  )}
                  {asset.priceChange >= 0 ? "+" : ""}{asset.priceChange}%
                </Badge>
              )}
            </div>
          )}
          
          <div className="flex items-center gap-2 pt-4 border-t">
            <Button variant="outline" size="sm" className="flex-1" onClick={onView}>
              <Eye className="h-4 w-4 ml-1" />
              عرض
            </Button>
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={onDelete} className="text-destructive hover:text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

const getTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    commodity: "سلعة",
    crypto: "عملة رقمية",
    currency: "عملة",
    stock: "سهم",
    oil: "نفط",
  };
  return labels[type] || type;
};

export default function AssetsList() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(12);
  const [sortConfig, setSortConfig] = useState<{
    column: string;
    direction: "asc" | "desc";
  }>({
    column: "name",
    direction: "asc",
  });

  // Bulk actions state
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Fetch assets
  const {
    data: assets,
    isLoading,
    refetch,
  } = trpc.assets.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Delete mutation
  const deleteAssetMutation = trpc.assets.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الأصل بنجاح");
      refetch();
      setDeleteDialogOpen(false);
      setSelectedAssetId(null);
    },
    onError: (error) => {
      toast.error(`فشل حذف الأصل: ${error.message}`);
    },
  });

  // Filter and search assets
  const filteredAssets = assets?.filter((asset: any) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.symbol.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === "all" || asset.type === filterType;
    return matchesSearch && matchesFilter;
  });

  // Sorting logic
  const sortedAssets = [...(filteredAssets || [])].sort((a: any, b: any) => {
    const aValue = a[sortConfig.column];
    const bValue = b[sortConfig.column];

    if (aValue === null || aValue === undefined) {return 1;}
    if (bValue === null || bValue === undefined) {return -1;}

    if (typeof aValue === "string") {
      return sortConfig.direction === "asc"
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }

    return sortConfig.direction === "asc" ? aValue - bValue : bValue - aValue;
  });

  // Pagination logic
  const totalItems = sortedAssets.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const paginatedAssets = sortedAssets.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Stats
  const totalAssets = assets?.length || 0;
  const commodityCount = assets?.filter((a: any) => a.type === "commodity").length || 0;
  const cryptoCount = assets?.filter((a: any) => a.type === "crypto").length || 0;
  const currencyCount = assets?.filter((a: any) => a.type === "currency").length || 0;

  // Export to CSV
  const handleExport = () => {
    if (!filteredAssets || filteredAssets.length === 0) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const csv = [
      ["ID", "Name", "Symbol", "Type", "Yahoo Symbol"].join(","),
      ...filteredAssets.map((asset: any) =>
        [asset.id, asset.name, asset.symbol, asset.type, asset.yahooSymbol].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `assets_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("تم تصدير البيانات بنجاح");
  };

  // Handle delete
  const handleDeleteClick = (id: number) => {
    setSelectedAssetId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedAssetId) {
      deleteAssetMutation.mutate({ id: selectedAssetId });
    }
  };

  // Bulk actions handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = paginatedAssets.map((asset: any) => asset.id);
      setSelectedIds(allIds);
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectOne = (id: number, checked: boolean) => {
    if (checked) {
      setSelectedIds([...selectedIds, id]);
    } else {
      setSelectedIds(selectedIds.filter((selectedId) => selectedId !== id));
    }
  };

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) {
      toast.error("الرجاء تحديد عناصر للحذف");
      return;
    }

    if (confirm(`هل أنت متأكد من حذف ${selectedIds.length} عنصر؟`)) {
      Promise.all(selectedIds.map((id) => deleteAssetMutation.mutateAsync({ id })))
        .then(() => {
          toast.success(`تم حذف ${selectedIds.length} عنصر بنجاح`);
          setSelectedIds([]);
          refetch();
        })
        .catch((error) => {
          toast.error(`فشل الحذف: ${error.message}`);
        });
    }
  };

  const handleBulkExport = () => {
    if (selectedIds.length === 0) {
      toast.error("الرجاء تحديد عناصر للتصدير");
      return;
    }

    const selectedAssets = assets?.filter((asset: any) => selectedIds.includes(asset.id));
    if (!selectedAssets) {return;}

    const csv = [
      ["ID", "Name", "Symbol", "Type", "Yahoo Symbol"].join(","),
      ...selectedAssets.map((asset: any) =>
        [asset.id, asset.name, asset.symbol, asset.type, asset.yahooSymbol].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `selected_assets_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success(`تم تصدير ${selectedIds.length} عنصر بنجاح`);
  };

  const handleSort = (column: string) => {
    setSortConfig((prev) => ({
      column,
      direction: prev.column === column && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Coins className="h-6 w-6 text-primary" />
                  إدارة الأصول
                </h1>
                <p className="text-sm text-muted-foreground">
                  جميع الأصول المتاحة للتوقع
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => refetch()}>
                <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                تحديث
              </Button>
              <Button data-testid="create-asset-button" onClick={() => setLocation("/assets/create")}>
                <Plus className="ml-2 h-4 w-4" />
                إضافة أصل
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard icon={Coins} label="إجمالي الأصول" value={totalAssets} color="primary" />
          <StatCard icon={Gem} label="السلع" value={commodityCount} color="warning" />
          <StatCard icon={Bitcoin} label="العملات الرقمية" value={cryptoCount} color="info" />
          <StatCard icon={DollarSign} label="العملات" value={currencyCount} color="success" />
        </div>

        {/* Toolbar */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-6"
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center gap-4">
                {/* Search */}
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      data-testid="search-assets"
                      placeholder="بحث بالاسم أو الرمز..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>

                {/* Filter */}
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="النوع" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأنواع</SelectItem>
                    <SelectItem value="commodity">سلعة</SelectItem>
                    <SelectItem value="crypto">عملة رقمية</SelectItem>
                    <SelectItem value="currency">عملة</SelectItem>
                    <SelectItem value="stock">سهم</SelectItem>
                  </SelectContent>
                </Select>

                {/* View Toggle */}
                <div className="flex items-center border rounded-lg p-1">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "table" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("table")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>

                {/* Export */}
                <Button variant="outline" onClick={handleExport}>
                  <Download className="ml-2 h-4 w-4" />
                  تصدير
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Bulk Actions */}
        {selectedIds.length > 0 && (
          <BulkActionsToolbar
            selectedCount={selectedIds.length}
            onDelete={handleBulkDelete}
            onExport={handleBulkExport}
            onClear={() => setSelectedIds([])}
          />
        )}

        {/* Content */}
        {paginatedAssets && paginatedAssets.length > 0 ? (
          <>
            {viewMode === "grid" ? (
              /* Grid View */
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {paginatedAssets.map((asset: any, index: number) => (
                  <AssetCard
                    key={asset.id}
                    asset={asset}
                    onView={() => setLocation(`/assets/view/${asset.id}`)}
                    onEdit={() => setLocation(`/assets/edit/${asset.id}`)}
                    onDelete={() => handleDeleteClick(asset.id)}
                    delay={0.05 * index}
                  />
                ))}
              </div>
            ) : (
              /* Table View */
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
              >
                <Card>
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">
                            <Checkbox
                              checked={
                                selectedIds.length === paginatedAssets.length &&
                                paginatedAssets.length > 0
                              }
                              onCheckedChange={handleSelectAll}
                            />
                          </TableHead>
                          <SortableTableHeader
                            column="id"
                            label="ID"
                            currentSort={sortConfig}
                            onSort={handleSort}
                            className="text-right"
                          />
                          <SortableTableHeader
                            column="name"
                            label="الاسم"
                            currentSort={sortConfig}
                            onSort={handleSort}
                            className="text-right"
                          />
                          <SortableTableHeader
                            column="symbol"
                            label="الرمز"
                            currentSort={sortConfig}
                            onSort={handleSort}
                            className="text-right"
                          />
                          <SortableTableHeader
                            column="type"
                            label="النوع"
                            currentSort={sortConfig}
                            onSort={handleSort}
                            className="text-right"
                          />
                          <TableHead className="text-right">رمز Yahoo</TableHead>
                          <TableHead className="text-center">الإجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paginatedAssets.map((asset: any) => (
                          <TableRow key={asset.id}>
                            <TableCell>
                              <Checkbox
                                checked={selectedIds.includes(asset.id)}
                                onCheckedChange={(checked) =>
                                  handleSelectOne(asset.id, checked as boolean)
                                }
                              />
                            </TableCell>
                            <TableCell>{asset.id}</TableCell>
                            <TableCell className="font-medium">{asset.name}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{asset.symbol}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge className={assetColors[asset.type] || ""}>
                                {getTypeLabel(asset.type)}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-sm">
                              {asset.yahooSymbol}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center justify-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  data-testid="view-asset"
                                  onClick={() => setLocation(`/assets/view/${asset.id}`)}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  data-testid="edit-asset"
                                  onClick={() => setLocation(`/assets/edit/${asset.id}`)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  data-testid="delete-asset"
                                  onClick={() => handleDeleteClick(asset.id)}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </Card>
              </motion.div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={totalItems}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setCurrentPage(1);
                  }}
                />
              </div>
            )}

            {/* Results count */}
            <div className="mt-4 text-sm text-muted-foreground text-center">
              عرض {paginatedAssets.length} من {totalItems} أصل
            </div>
          </>
        ) : (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="border-dashed">
              <CardContent className="p-12 text-center">
                <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                  <Coins className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">لا توجد أصول</h3>
                <p className="text-muted-foreground mb-6">
                  أضف أصولاً جديدة لبدء التوقع
                </p>
                <Button onClick={() => setLocation("/assets/create")}>
                  <Plus className="ml-2 h-4 w-4" />
                  إضافة أصل جديد
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا الأصل؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteAssetMutation.isPending}
            >
              {deleteAssetMutation.isPending ? "جاري الحذف..." : "حذف"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
