/**
 * Home Page - Premium Gold Price Predictor Landing
 * Modern, animated landing page with stunning visuals
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { APP_LOGO, APP_TITLE } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  AlertCircle,
  BarChart3,
  Brain,
  Zap,
  Shield,
  Target,
  ArrowRight,
  Sparkles,
  LineChart,
  Cpu,
  Globe,
  ChevronRight,
  Play,
  Star,
} from "lucide-react";
import NotificationCenter from "@/components/NotificationCenter";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

// Live price ticker simulation
function LivePriceTicker() {
  const [prices, setPrices] = useState([
    { name: "ذهب", symbol: "XAU", price: 2024.50, change: 1.2 },
    { name: "فضة", symbol: "XAG", price: 23.45, change: -0.5 },
    { name: "بيتكوين", symbol: "BTC", price: 42150.00, change: 2.8 },
    { name: "نفط", symbol: "OIL", price: 78.30, change: -1.1 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setPrices(prev => prev.map(p => ({
        ...p,
        price: p.price * (1 + (Math.random() - 0.5) * 0.001),
        change: p.change + (Math.random() - 0.5) * 0.1
      })));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex gap-6 overflow-x-auto py-2 scrollbar-hide">
      {prices.map((item, i) => (
        <motion.div
          key={item.symbol}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="flex items-center gap-3 px-4 py-2 rounded-lg bg-card/50 backdrop-blur-sm border border-border/50 min-w-fit"
        >
          <span className="font-semibold text-sm">{item.symbol}</span>
          <span className="font-mono text-sm">${item.price.toFixed(2)}</span>
          <span className={`text-xs font-medium flex items-center gap-1 ${item.change >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
            {item.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {Math.abs(item.change).toFixed(2)}%
          </span>
        </motion.div>
      ))}
    </div>
  );
}

// Feature card component
function FeatureCard({ icon: Icon, title, description, delay = 0 }: { 
  icon: any; 
  title: string; 
  description: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="group"
    >
      <Card className="h-full border-border/50 bg-card/50 backdrop-blur-sm transition-all duration-300 hover:border-primary/30 hover:shadow-lg">
        <CardContent className="pt-6">
          <div className="mb-4 inline-flex p-3 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
            <Icon className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Stats counter animation
function AnimatedCounter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const stepValue = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += stepValue;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    
    return () => clearInterval(timer);
  }, [value]);
  
  return <span>{count.toLocaleString()}{suffix}</span>;
}

export default function Home() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const { data: assets, isLoading: assetsLoading } = trpc.assets.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const { data: currentPrices } = trpc.assets.getCurrentPrices.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const { data: modelsData } = trpc.models.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  
  // Calculate models count
  const modelsCount = modelsData?.models 
    ? Object.keys(modelsData.models).length 
    : modelsData?.count || 3; // Fallback to 3 if API fails

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  // Landing page for non-authenticated users
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-hero overflow-hidden">
        {/* Hero Section */}
        <section className="relative pt-20 pb-32 px-4">
          {/* Background decorations */}
          <div className="absolute inset-0 bg-dots-pattern opacity-30" />
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          
          <div className="container mx-auto relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              {/* Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Badge variant="secondary" className="mb-6 px-4 py-1.5 text-sm font-medium">
                  <Sparkles className="h-3.5 w-3.5 mr-2" />
                  مدعوم بالذكاء الاصطناعي المتقدم
                </Badge>
              </motion.div>
              
              {/* Main heading */}
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 tracking-tight">
                <span className="block">توقع أسعار</span>
                <span className="gold-shimmer">الأصول المالية</span>
              </h1>
              
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
                نظام ذكي لتوقع أسعار الذهب والعملات الرقمية والنفط باستخدام نماذج 
                التعلم العميق مع دقة تتجاوز <span className="text-primary font-semibold">99%</span>
              </p>
              
              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="flex flex-col sm:flex-row gap-4 justify-center"
              >
                <Link href="/login">
                  <Button size="lg" className="group text-base px-8 glow-gold">
                    ابدأ الآن مجاناً
                    <ArrowRight className="mr-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="lg" variant="outline" className="text-base px-8">
                    <Play className="mr-2 h-4 w-4" />
                    شاهد العرض التوضيحي
                  </Button>
                </Link>
              </motion.div>
            </motion.div>
            
            {/* Live Ticker */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-16"
            >
              <LivePriceTicker />
            </motion.div>
            
            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8"
            >
              {[
                { value: 99.5, suffix: "%", label: "دقة التوقعات" },
                { value: 12, suffix: "+", label: "أصل مالي" },
                { value: 50000, suffix: "+", label: "توقع ناجح" },
                { value: 24, suffix: "/7", label: "مراقبة مستمرة" },
              ].map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-primary">
                    <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 px-4 bg-muted/30">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <Badge variant="outline" className="mb-4">المميزات</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">تقنيات متقدمة للتوقع الدقيق</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                نستخدم أحدث تقنيات الذكاء الاصطناعي والتعلم الآلي لتقديم توقعات دقيقة وموثوقة
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                icon={Brain}
                title="نماذج LSTM المتقدمة"
                description="شبكات عصبية متكررة مصممة لتحليل البيانات الزمنية وفهم الأنماط المعقدة"
                delay={0}
              />
              <FeatureCard
                icon={Cpu}
                title="التعلم الجماعي (Ensemble)"
                description="دمج عدة نماذج للحصول على توقعات أكثر دقة واستقراراً"
                delay={0.1}
              />
              <FeatureCard
                icon={Target}
                title="دقة تتجاوز 99%"
                description="نتائج موثقة ومختبرة على بيانات تاريخية حقيقية"
                delay={0.2}
              />
              <FeatureCard
                icon={Zap}
                title="توقعات فورية"
                description="احصل على توقعات لحظية مع تحديثات في الوقت الفعلي"
                delay={0.3}
              />
              <FeatureCard
                icon={Shield}
                title="أمان متقدم"
                description="تشفير شامل وحماية متعددة الطبقات لبياناتك"
                delay={0.4}
              />
              <FeatureCard
                icon={Globe}
                title="تغطية شاملة"
                description="12+ أصل مالي تشمل الذهب والفضة والعملات الرقمية"
                delay={0.5}
              />
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 px-4">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative overflow-hidden rounded-3xl bg-card border border-border/50 p-8 md:p-16 text-center"
            >
              {/* Decorative elements */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/10 rounded-full blur-3xl" />
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-primary/10 rounded-full blur-3xl" />
              
              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                  ))}
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">
                  ابدأ التوقع الآن
                </h2>
                <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                  انضم إلى آلاف المستخدمين الذين يعتمدون على نظامنا لاتخاذ قرارات استثمارية أفضل
                </p>
                <Link href="/register">
                  <Button size="lg" className="text-base px-10 glow-gold">
                    إنشاء حساب مجاني
                    <ChevronRight className="mr-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t bg-card/50">
          <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-primary/10">
                  <TrendingUp className="h-5 w-5 text-primary" />
                </div>
                <span className="font-semibold">{APP_TITLE}</span>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                نظام توقع أسعار الأصول المالية • دقة تتجاوز 99% • مدعوم بالذكاء الاصطناعي
              </p>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  // Dashboard view for authenticated users
  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10">
              <TrendingUp className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              <p className="text-xs text-muted-foreground">مرحباً، {user?.name || "مستخدم"}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <NotificationCenter />
            <Link href="/dashboard">
              <Button size="sm">لوحة التحكم</Button>
            </Link>
            <Button variant="ghost" size="sm" onClick={() => logout()}>
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Live Prices */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <LivePriceTicker />
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="mb-8 premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                إجراءات سريعة
              </CardTitle>
              <CardDescription>الوصول السريع لجميع ميزات النظام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {[
                  { href: "/dashboard", icon: BarChart3, label: "لوحة التحكم" },
                  { href: "/assets", icon: TrendingUp, label: "الأصول" },
                  { href: "/predictions/three-level", icon: Brain, label: "التوقعات" },
                  { href: "/alerts", icon: AlertCircle, label: "التنبيهات" },
                  { href: "/portfolio", icon: Activity, label: "المحفظة" },
                  { href: "/reports", icon: BarChart3, label: "التقارير" },
                  { href: "/admin/train-models", icon: Brain, label: "تدريب النماذج" },
                  { href: "/admin/model-performance", icon: Activity, label: "أداء النماذج" },
                  { href: "/ai-tasks", icon: Cpu, label: "مهام الذكاء الاصطناعي" },
                  { href: "/trading-signals", icon: LineChart, label: "إشارات التداول" },
                  { href: "/settings", icon: Activity, label: "الإعدادات" },
                  { href: "/help", icon: AlertCircle, label: "المساعدة" },
                ].map((item, i) => (
                  <motion.div
                    key={item.href}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.1 + i * 0.03 }}
                  >
                    <Link href={item.href}>
                      <Button
                        variant="outline"
                        className="w-full h-20 flex-col gap-2 hover:bg-primary/5 hover:border-primary/30 transition-all stat-card"
                      >
                        <item.icon className="h-6 w-6" />
                        <span className="text-xs">{item.label}</span>
                      </Button>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          {[
            { icon: BarChart3, label: "إجمالي الأصول", value: assets?.length || 0, desc: "أصول مالية متنوعة", color: "text-blue-500" },
            { icon: Activity, label: "دقة النماذج", value: "99.5%", desc: "متوسط دقة التوقعات", color: "text-emerald-500" },
            { icon: AlertCircle, label: "التنبيهات النشطة", value: "0", desc: "تنبيه قيد المراقبة", color: "text-amber-500" },
            { icon: Brain, label: "النماذج المتاحة", value: modelsCount.toString(), desc: "Ridge, LSTM, Ensemble", color: "text-purple-500" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.05 }}
            >
              <Card className="stat-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.label}
                  </CardTitle>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{stat.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Assets Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">الأصول المالية</h2>
            <Link href="/assets">
              <Button variant="ghost" size="sm">
                عرض الكل
                <ChevronRight className="mr-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {assetsLoading ? (
            <div className="text-center py-12">
              <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
              <p className="text-muted-foreground mt-4">جاري التحميل...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {assets?.slice(0, 6).map((asset: any, i: number) => (
                <motion.div
                  key={asset.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                >
                  <Card className="stat-card overflow-hidden">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{asset.name}</CardTitle>
                          <CardDescription>{asset.symbol}</CardDescription>
                        </div>
                        <div className={`p-2.5 rounded-xl ${
                          asset.category === "commodity" ? "bg-amber-100 dark:bg-amber-900/30" :
                          asset.category === "crypto" ? "bg-blue-100 dark:bg-blue-900/30" :
                          asset.category === "currency" ? "bg-green-100 dark:bg-green-900/30" :
                          "bg-purple-100 dark:bg-purple-900/30"
                        }`}>
                          {asset.category === "commodity" && "🏆"}
                          {asset.category === "crypto" && "₿"}
                          {asset.category === "currency" && "💱"}
                          {asset.category === "stock" && "📈"}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="text-sm text-muted-foreground">السعر الحالي</p>
                          <p className="text-2xl font-bold font-mono">--</p>
                        </div>
                        <div className="flex items-center gap-1 text-emerald-500">
                          <TrendingUp className="h-4 w-4" />
                          <span className="text-sm font-medium">--</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link href={`/predict/${asset.id}`} className="flex-1">
                          <Button size="sm" className="w-full">توقع السعر</Button>
                        </Link>
                        <Link href={`/alerts/create/${asset.id}`}>
                          <Button variant="outline" size="sm">
                            <AlertCircle className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Quick Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {[
            { icon: Brain, title: "مقارنة النماذج", desc: "قارن أداء النماذج المختلفة", href: "/models/compare", color: "text-blue-500 bg-blue-100 dark:bg-blue-900/30" },
            { icon: Activity, title: "سجل التوقعات", desc: "عرض جميع التوقعات السابقة", href: "/history", color: "text-emerald-500 bg-emerald-100 dark:bg-emerald-900/30" },
            { icon: AlertCircle, title: "إدارة التنبيهات", desc: "إنشاء وإدارة تنبيهات الأسعار", href: "/alerts", color: "text-amber-500 bg-amber-100 dark:bg-amber-900/30" },
            { icon: TrendingUp, title: "إشارات التداول", desc: "إشارات البيع والشراء الذكية", href: "/trading-signals", color: "text-purple-500 bg-purple-100 dark:bg-purple-900/30" },
            { icon: BarChart3, title: "حاسبة نقطة التعادل", desc: "احسب نقطة التعادل والربح/الخسارة", href: "/break-even-calculator", color: "text-rose-500 bg-rose-100 dark:bg-rose-900/30" },
          ].map((item, i) => (
            <motion.div
              key={item.href}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.05 }}
            >
              <Link href={item.href}>
                <Card className="stat-card cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${item.color}`}>
                        <item.icon className="h-5 w-5" />
                      </div>
                      {item.title}
                    </CardTitle>
                    <CardDescription>{item.desc}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="ghost" size="sm" className="w-full justify-between">
                      عرض المزيد
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-12 bg-card/50">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>نظام توقع أسعار الأصول المالية - مدعوم بالذكاء الاصطناعي</p>
          <p className="mt-1">دقة تتجاوز 99% • 12 أصل مالي • تنبيهات ذكية</p>
        </div>
      </footer>
    </div>
  );
}
