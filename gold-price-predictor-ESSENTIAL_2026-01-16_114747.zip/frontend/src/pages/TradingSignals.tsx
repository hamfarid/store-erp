/**
 * Trading Signals Page - Premium Gold Price Predictor
 * AI-powered buy/sell/hold signals with modern design
 */

import { useState } from "react";
import { useLocation, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  ArrowUpIcon,
  ArrowDownIcon,
  MinusIcon,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ArrowLeft,
  Sparkles,
  Target,
  Clock,
  Zap,
  Activity,
  BarChart3,
  Filter,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
  DollarSign,
  Percent,
} from "lucide-react";
import PaginationControls from "@/components/PaginationControls";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${colors[color]}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="text-2xl font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Signal Card Component
function SignalCard({
  signal,
  asset,
  delay = 0,
}: {
  signal: any;
  asset: any;
  delay?: number;
}) {
  const getSignalConfig = (type: string) => {
    switch (type) {
      case "buy":
        return {
          icon: ArrowUpIcon,
          label: "شراء",
          color: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
          badgeVariant: "default" as const,
          badgeClass: "bg-emerald-500",
        };
      case "sell":
        return {
          icon: ArrowDownIcon,
          label: "بيع",
          color: "bg-red-100 dark:bg-red-900/30 text-red-600",
          badgeVariant: "destructive" as const,
          badgeClass: "",
        };
      default:
        return {
          icon: MinusIcon,
          label: "انتظار",
          color: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
          badgeVariant: "secondary" as const,
          badgeClass: "",
        };
    }
  };

  const config = getSignalConfig(signal.signalType);
  const Icon = config.icon;

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className={`stat-card overflow-hidden ${signal.isActive ? "" : "opacity-60"}`}>
        {/* Signal type accent */}
        <div className={`h-1 ${
          signal.signalType === "buy" 
            ? "bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-500"
            : signal.signalType === "sell"
            ? "bg-gradient-to-r from-red-500 via-red-400 to-red-500"
            : "bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500"
        }`} />
        
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            {/* Signal Icon */}
            <div className={`p-4 rounded-xl ${config.color}`}>
              <Icon className="h-8 w-8" />
            </div>

            {/* Signal Details */}
            <div className="flex-1 min-w-0">
              {/* Header */}
              <div className="flex items-center gap-3 mb-3 flex-wrap">
                <h3 className="text-xl font-bold">{asset?.name || "أصل غير معروف"}</h3>
                <Badge className={config.badgeClass} variant={config.badgeVariant}>
                  {config.label}
                </Badge>
                {signal.isActive ? (
                  <Badge variant="outline" className="text-emerald-600 border-emerald-600">
                    <Zap className="h-3 w-3 mr-1" />
                    نشط
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    منتهي
                  </Badge>
                )}
              </div>

              {/* Price Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">السعر الحالي</p>
                  <p className="text-lg font-bold">${signal.price?.toFixed(2)}</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">السعر المستهدف</p>
                  <p className="text-lg font-bold text-emerald-600">
                    ${signal.targetPrice?.toFixed(2) || "---"}
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">وقف الخسارة</p>
                  <p className="text-lg font-bold text-red-600">
                    ${signal.stopLoss?.toFixed(2) || "---"}
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">القوة</p>
                  <div className="flex items-center gap-2">
                    <span className={`text-lg font-bold ${
                      signal.strength >= 80 ? "text-emerald-600" :
                      signal.strength >= 60 ? "text-amber-600" : "text-muted-foreground"
                    }`}>
                      {signal.strength?.toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Reason */}
              <div className="p-3 rounded-lg bg-muted/50 mb-3">
                <p className="text-sm">
                  <span className="font-semibold">السبب:</span> {signal.reason}
                </p>
              </div>

              {/* Meta Info */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3" />
                  الثقة: <span className="font-semibold">{signal.confidence?.toFixed(0)}%</span>
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {new Date(signal.timestamp).toLocaleString("ar-EG")}
                </span>
                {signal.expiresAt && (
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    ينتهي: {new Date(signal.expiresAt).toLocaleString("ar-EG")}
                  </span>
                )}
              </div>

              {/* Strength Progress */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span>قوة الإشارة</span>
                  <span>{signal.strength?.toFixed(0)}%</span>
                </div>
                <Progress 
                  value={signal.strength} 
                  className={`h-2 ${
                    signal.strength >= 80 ? "[&>div]:bg-emerald-500" :
                    signal.strength >= 60 ? "[&>div]:bg-amber-500" : "[&>div]:bg-red-500"
                  }`}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function TradingSignals() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState<number | undefined>();
  const [filterActive, setFilterActive] = useState<boolean | undefined>(true);
  const [activeTab, setActiveTab] = useState<"all" | "buy" | "sell" | "hold">("all");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { data: assets } = trpc.assets.list.useQuery();
  const {
    data: signals,
    isLoading,
    refetch,
  } = trpc.tradingSignals.list.useQuery({
    assetId: selectedAsset,
    isActive: filterActive,
  });

  const calculateMutation = trpc.tradingSignals.calculate.useMutation({
    onSuccess: () => {
      toast.success("تم حساب إشارة التداول بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل حساب الإشارة: ${error.message}`);
    },
  });

  const handleCalculate = (assetId: number) => {
    calculateMutation.mutate({ assetId });
  };

  // Filter by signal type
  let filteredSignals = signals ? [...signals] : [];
  if (activeTab !== "all") {
    filteredSignals = filteredSignals.filter((s: any) => s.signalType === activeTab);
  }

  // Sort by date
  filteredSignals.sort((a: any, b: any) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  // Stats
  const totalSignals = signals?.length || 0;
  const buySignals = signals?.filter((s: any) => s.signalType === "buy").length || 0;
  const sellSignals = signals?.filter((s: any) => s.signalType === "sell").length || 0;
  const holdSignals = signals?.filter((s: any) => s.signalType === "hold").length || 0;
  const activeSignals = signals?.filter((s: any) => s.isActive).length || 0;

  // Pagination
  const totalItems = filteredSignals.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const paginatedSignals = filteredSignals.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Activity className="h-6 w-6 text-primary" />
                  إشارات التداول
                </h1>
                <p className="text-sm text-muted-foreground">
                  إشارات شراء/بيع مدعومة بالذكاء الاصطناعي
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button data-testid="refresh-signals-button" variant="outline" size="sm" onClick={() => refetch()}>
                <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                تحديث
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
          <StatCard icon={BarChart3} label="إجمالي الإشارات" value={totalSignals} color="primary" delay={0} />
          <StatCard icon={TrendingUp} label="إشارات شراء" value={buySignals} color="success" delay={0.1} />
          <StatCard icon={TrendingDown} label="إشارات بيع" value={sellSignals} color="danger" delay={0.2} />
          <StatCard icon={MinusIcon} label="إشارات انتظار" value={holdSignals} color="warning" delay={0.3} />
          <StatCard icon={Zap} label="نشطة حالياً" value={activeSignals} color="primary" delay={0.4} />
        </div>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Sidebar - Calculate & Filters */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
            className="lg:col-span-1 space-y-6"
          >
            {/* Calculate New Signals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Target className="h-5 w-5 text-primary" />
                  حساب إشارة جديدة
                </CardTitle>
                <CardDescription>
                  إنشاء إشارة تداول بناءً على أحدث التوقعات
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px] pr-4">
                  <div className="space-y-2">
                    {assets?.map((asset: any) => (
                      <Button
                        key={asset.id}
                        onClick={() => handleCalculate(asset.id)}
                        disabled={calculateMutation.isPending}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                      >
                        <Zap className="ml-2 h-4 w-4 text-primary" />
                        {asset.symbol}
                        <ChevronRight className="mr-auto h-4 w-4" />
                      </Button>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Filter className="h-5 w-5 text-primary" />
                  التصفية
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">الأصل</label>
                  <Select
                    value={selectedAsset?.toString() || "all"}
                    onValueChange={(value) =>
                      setSelectedAsset(value === "all" ? undefined : parseInt(value))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="جميع الأصول" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الأصول</SelectItem>
                      {assets?.map((asset: any) => (
                        <SelectItem key={asset.id} value={asset.id.toString()}>
                          {asset.name} ({asset.symbol})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">الحالة</label>
                  <Select
                    value={filterActive === undefined ? "all" : filterActive ? "active" : "inactive"}
                    onValueChange={(value) =>
                      setFilterActive(value === "all" ? undefined : value === "active")
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="جميع الإشارات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الإشارات</SelectItem>
                      <SelectItem value="active">النشطة فقط</SelectItem>
                      <SelectItem value="inactive">المنتهية فقط</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Signals List */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
            className="lg:col-span-3"
          >
            {/* Signal Type Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="mb-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">الكل ({totalSignals})</TabsTrigger>
                <TabsTrigger value="buy" className="text-emerald-600">شراء ({buySignals})</TabsTrigger>
                <TabsTrigger value="sell" className="text-red-600">بيع ({sellSignals})</TabsTrigger>
                <TabsTrigger value="hold" className="text-amber-600">انتظار ({holdSignals})</TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Signals */}
            {paginatedSignals && paginatedSignals.length > 0 ? (
              <div className="space-y-4">
                {paginatedSignals.map((signal: any, index: number) => {
                  const asset = assets?.find((a: any) => a.id === signal.assetId);
                  return (
                    <SignalCard
                      key={signal.id}
                      signal={signal}
                      asset={asset}
                      delay={0.05 * index}
                    />
                  );
                })}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-6">
                    <PaginationControls
                      currentPage={currentPage}
                      totalPages={totalPages}
                      pageSize={pageSize}
                      totalItems={totalItems}
                      onPageChange={setCurrentPage}
                      onPageSizeChange={(newSize) => {
                        setPageSize(newSize);
                        setCurrentPage(1);
                      }}
                    />
                  </div>
                )}
              </div>
            ) : (
              <Card className="border-dashed">
                <CardContent className="py-16 text-center">
                  <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                    <Activity className="h-12 w-12 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">لا توجد إشارات</h3>
                  <p className="text-muted-foreground mb-6">
                    احسب إشارات جديدة للأصول للبدء
                  </p>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
