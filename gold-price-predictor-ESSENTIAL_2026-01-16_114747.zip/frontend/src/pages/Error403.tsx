/**
 * 403 Forbidden Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { ShieldOff } from "lucide-react";

export default function Error403() {
  return (
    <ErrorPageTemplate
      code={403}
      title="الوصول محظور"
      description="عذراً، ليس لديك صلاحية للوصول إلى هذه الصفحة. إذا كنت تعتقد أن هذا خطأ، يرجى التواصل مع المسؤول."
      icon={ShieldOff}
      iconColor="text-red-500"
      showRefresh={false}
      showHome={true}
      showDashboard={true}
    />
  );
}
