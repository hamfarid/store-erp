/**
 * Admin Dashboard Page
 * Premium admin control panel with modern UI
 */

import { trpc } from "@/lib/trpc";
import { PageLayout } from "@/components/PageLayout";
import { Breadcrumbs } from "@/components/ui/breadcrumbs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  Users,
  Coins,
  Bell,
  TrendingUp,
  Activity,
  Database,
  LayoutDashboard,
  Shield,
  Settings,
  Download,
  RefreshCw,
  Brain,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Server,
  HardDrive,
  Cpu,
  BarChart3,
  ArrowLeft,
  Sparkles,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import AccuracyChart from "@/components/AccuracyChart";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  trend,
  trendValue,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "primary" | "success" | "warning" | "danger" | "info";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
    info: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
  };

  const trendColors = {
    up: "text-emerald-600",
    down: "text-red-600",
    neutral: "text-muted-foreground",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="text-3xl font-bold mt-1">{value}</p>
              {trendValue && trend && (
                <p className={`text-xs mt-1 ${trendColors[trend]}`}>
                  {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {trendValue}
                </p>
              )}
            </div>
            <div className={`p-4 rounded-xl ${colors[color]}`}>
              <Icon className="h-6 w-6" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Quick Action Button
function QuickAction({
  icon: Icon,
  title,
  description,
  href,
  variant = "outline",
}: {
  icon: any;
  title: string;
  description: string;
  href: string;
  variant?: "outline" | "default";
}) {
  return (
    <Link href={href}>
      <Button
        variant={variant}
        className="w-full justify-start h-auto py-4 group hover:border-primary transition-colors"
      >
        <div className={`p-2 rounded-lg mr-3 ${variant === "default" ? "bg-primary-foreground/20" : "bg-primary/10"}`}>
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <div className="text-right flex-1">
          <div className="font-semibold">{title}</div>
          <div className="text-sm text-muted-foreground">{description}</div>
        </div>
        <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
      </Button>
    </Link>
  );
}

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { data: stats, isLoading, refetch } = trpc.admin.stats.useQuery();
  const { data: accuracyData } = trpc.reports.accuracyReport.useQuery({});

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <LayoutDashboard className="h-6 w-6 text-primary" />
                  لوحة تحكم المدير
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة شاملة للنظام
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button data-testid="refresh-admin-dashboard-button" variant="outline" size="sm" onClick={() => refetch()}>
                <RefreshCw className="ml-2 h-4 w-4" />
                تحديث
              </Button>
              <Link href="/settings">
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Statistics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Users}
            label="إجمالي المستخدمين"
            value={(stats as any)?.users || 0}
            trend="up"
            trendValue="+12% هذا الشهر"
            color="primary"
            delay={0}
          />
          <StatCard
            icon={Coins}
            label="الأصول المتتبعة"
            value={(stats as any)?.assets || 0}
            trend="neutral"
            trendValue="مستقر"
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={Bell}
            label="التنبيهات النشطة"
            value={(stats as any)?.alerts || 0}
            trend="up"
            trendValue="+5 جديدة"
            color="warning"
            delay={0.2}
          />
          <StatCard
            icon={TrendingUp}
            label="التوقعات اليوم"
            value={(stats as any)?.predictions || 0}
            trend="up"
            trendValue="+23%"
            color="info"
            delay={0.3}
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left Column - Quick Actions & System Health */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-primary" />
                    إجراءات سريعة
                  </CardTitle>
                  <CardDescription>الوصول السريع لأهم الوظائف</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3 sm:grid-cols-2">
                  <QuickAction
                    icon={Users}
                    title="إدارة المستخدمين"
                    description="عرض وتعديل المستخدمين"
                    href="/admin/users"
                  />
                  <QuickAction
                    icon={Coins}
                    title="إدارة الأصول"
                    description="إضافة وتعديل الأصول"
                    href="/admin/assets"
                  />
                  <QuickAction
                    icon={Brain}
                    title="تدريب النماذج"
                    description="إدارة نماذج الذكاء الاصطناعي"
                    href="/admin/train-models"
                  />
                  <QuickAction
                    icon={Shield}
                    title="الأمان"
                    description="إعدادات الحماية والأمان"
                    href="/security"
                  />
                  <QuickAction
                    icon={Database}
                    title="النسخ الاحتياطي"
                    description="إنشاء وإدارة النسخ"
                    href="/admin/backup"
                  />
                  <QuickAction
                    icon={Activity}
                    title="سجلات النظام"
                    description="مراقبة الأحداث والأخطاء"
                    href="/admin/logs"
                  />
                </CardContent>
              </Card>
            </motion.div>

            {/* Accuracy Chart */}
            {accuracyData && (accuracyData as any).length > 0 && (
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.5 }}
              >
                <AccuracyChart
                  data={(accuracyData as any) || []}
                  title="دقة التوقعات حسب النموذج"
                  description="مقارنة أداء نماذج التوقع المختلفة"
                  height={350}
                />
              </motion.div>
            )}

            {/* System Activity */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5 text-primary" />
                        النشاط الأخير
                      </CardTitle>
                      <CardDescription>آخر الأحداث في النظام</CardDescription>
                    </div>
                    <Link href="/admin/logs">
                      <Button variant="ghost" size="sm">
                        عرض الكل
                        <ChevronRight className="mr-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[250px]">
                    <div className="space-y-4">
                      {[
                        { icon: CheckCircle2, text: "توقع ناجح للذهب", time: "منذ 2 دقيقة", color: "text-emerald-500" },
                        { icon: Users, text: "تسجيل مستخدم جديد", time: "منذ 15 دقيقة", color: "text-blue-500" },
                        { icon: AlertTriangle, text: "تنبيه سعري مفعّل", time: "منذ 30 دقيقة", color: "text-amber-500" },
                        { icon: Brain, text: "تحديث نموذج LSTM", time: "منذ ساعة", color: "text-purple-500" },
                        { icon: Database, text: "نسخة احتياطية تلقائية", time: "منذ 3 ساعات", color: "text-primary" },
                        { icon: Shield, text: "فحص أمني اكتمل", time: "منذ 6 ساعات", color: "text-emerald-500" },
                      ].map((activity, i) => (
                        <div key={i} className="flex items-center gap-4">
                          <div className={`p-2 rounded-lg bg-muted ${activity.color}`}>
                            <activity.icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{activity.text}</p>
                            <p className="text-xs text-muted-foreground">{activity.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column - System Info */}
          <div className="space-y-6">
            {/* System Health */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5 text-primary" />
                    صحة النظام
                  </CardTitle>
                  <CardDescription>حالة الخوادم والخدمات</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { label: "الخادم الرئيسي", status: "online", value: 99.9 },
                    { label: "قاعدة البيانات", status: "online", value: 98.5 },
                    { label: "خدمة ML", status: "online", value: 97.2 },
                    { label: "Redis Cache", status: "online", value: 100 },
                  ].map((service, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{service.label}</span>
                        <Badge
                          variant={service.status === "online" ? "default" : "destructive"}
                          className={service.status === "online" ? "bg-emerald-500" : ""}
                        >
                          {service.status === "online" ? "متصل" : "غير متصل"}
                        </Badge>
                      </div>
                      <Progress value={service.value} className="h-2" />
                      <p className="text-xs text-muted-foreground text-left">
                        {service.value}% وقت التشغيل
                      </p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            {/* Resource Usage */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-primary" />
                    استخدام الموارد
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>المعالج (CPU)</span>
                      <span className="font-medium">45%</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>الذاكرة (RAM)</span>
                      <span className="font-medium">62%</span>
                    </div>
                    <Progress value={62} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>التخزين</span>
                      <span className="font-medium">38%</span>
                    </div>
                    <Progress value={38} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Database Stats */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.7 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-primary" />
                    إحصائيات البيانات
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "إجمالي التوقعات", value: (stats as any)?.predictions || 0 },
                    { label: "التنبيهات المفعّلة", value: (stats as any)?.alerts || 0 },
                    { label: "الأسعار التاريخية", value: "12,450" },
                    { label: "المحافظ", value: (stats as any)?.portfolios || 0 },
                  ].map((item, i) => (
                    <div key={i} className="flex justify-between">
                      <span className="text-muted-foreground">{item.label}</span>
                      <span className="font-semibold">{item.value}</span>
                    </div>
                  ))}
                  <Separator className="my-3" />
                  <div className="flex justify-between text-primary">
                    <span>متوسط الدقة</span>
                    <span className="font-bold">99.03%</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.8 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    تقارير سريعة
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Link href="/reports">
                    <Button variant="outline" className="w-full justify-start">
                      <BarChart3 className="ml-2 h-4 w-4" />
                      التقارير الشاملة
                    </Button>
                  </Link>
                  <Link href="/admin/model-performance">
                    <Button variant="outline" className="w-full justify-start">
                      <Brain className="ml-2 h-4 w-4" />
                      أداء النماذج
                    </Button>
                  </Link>
                  <Link href="/system-health">
                    <Button variant="outline" className="w-full justify-start">
                      <Activity className="ml-2 h-4 w-4" />
                      صحة النظام
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
