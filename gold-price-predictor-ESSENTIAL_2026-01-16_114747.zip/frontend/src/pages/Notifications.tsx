/**
 * Notifications Page - Premium Gold Price Predictor
 * Modern notification center with read/unread status and actions
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";
import { trpc } from "@/lib/trpc";
import {
  Bell,
  Check,
  CheckCheck,
  Trash2,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle,
  RefreshCw,
  ArrowLeft,
  MoreHorizontal,
  BellOff,
  Filter,
  Clock,
  TrendingUp,
  AlertCircle,
  Settings,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";
import { PageLayout } from "@/components/PageLayout";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, x: -100 },
};

const notificationVariants = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: 100, height: 0, marginBottom: 0 },
};

interface Notification {
  id: number;
  userId: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  isRead: number;
  createdAt: number;
}

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <Card className="stat-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${colors[color]}`}>
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-lg font-bold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Notification Item Component
function NotificationItem({
  notification,
  isSelected,
  onSelect,
  onMarkAsRead,
  onDelete,
  delay = 0,
}: {
  notification: Notification;
  isSelected: boolean;
  onSelect: () => void;
  onMarkAsRead: () => void;
  onDelete: () => void;
  delay?: number;
}) {
  const getTypeConfig = (type: string) => {
    switch (type) {
      case "warning":
        return {
          icon: AlertTriangle,
          color: "text-amber-500",
          bg: "bg-amber-50 dark:bg-amber-900/20",
          border: "border-amber-200 dark:border-amber-800",
          label: "تحذير",
        };
      case "error":
        return {
          icon: XCircle,
          color: "text-red-500",
          bg: "bg-red-50 dark:bg-red-900/20",
          border: "border-red-200 dark:border-red-800",
          label: "خطأ",
        };
      case "success":
        return {
          icon: CheckCircle,
          color: "text-emerald-500",
          bg: "bg-emerald-50 dark:bg-emerald-900/20",
          border: "border-emerald-200 dark:border-emerald-800",
          label: "نجاح",
        };
      default:
        return {
          icon: Info,
          color: "text-blue-500",
          bg: "bg-blue-50 dark:bg-blue-900/20",
          border: "border-blue-200 dark:border-blue-800",
          label: "معلومات",
        };
    }
  };

  const config = getTypeConfig(notification.type);
  const Icon = config.icon;
  const isUnread = !notification.isRead;

  return (
    <motion.div
      variants={notificationVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ delay }}
      layout
    >
      <Card
        className={`transition-all cursor-pointer group ${
          isUnread
            ? "border-primary/50 bg-primary/5 hover:bg-primary/10"
            : "hover:bg-muted/50"
        } ${isSelected ? "ring-2 ring-primary" : ""}`}
      >
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            {/* Checkbox */}
            <Checkbox
              checked={isSelected}
              onCheckedChange={onSelect}
              className="mt-1"
              onClick={e => e.stopPropagation()}
            />

            {/* Icon */}
            <div className={`p-2 rounded-lg ${config.bg} mt-0.5`}>
              <Icon className={`h-5 w-5 ${config.color}`} />
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <h3 className="font-semibold">{notification.title}</h3>
                <Badge
                  variant="outline"
                  className={`${config.bg} ${config.border} text-xs`}
                >
                  {config.label}
                </Badge>
                {isUnread && (
                  <Badge className="bg-primary text-primary-foreground text-xs animate-pulse">
                    جديد
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2">
                {notification.message}
              </p>
              <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>
                  {formatDistanceToNow(new Date(notification.createdAt), {
                    addSuffix: true,
                    locale: ar,
                  })}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {isUnread && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={e => {
                    e.stopPropagation();
                    onMarkAsRead();
                  }}
                  title="تحديد كمقروء"
                >
                  <Check className="h-4 w-4" />
                </Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={e => e.stopPropagation()}
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {isUnread && (
                    <DropdownMenuItem onClick={onMarkAsRead}>
                      <Check className="h-4 w-4 ml-2" />
                      تحديد كمقروء
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem
                    onClick={onDelete}
                    className="text-red-600 focus:text-red-600"
                  >
                    <Trash2 className="h-4 w-4 ml-2" />
                    حذف
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Notifications() {
  const [, navigate] = useLocation();
  const [filter, setFilter] = useState<"all" | "unread" | "read">("all");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const utils = trpc.useUtils();

  // Fetch notifications
  const {
    data: notifications = [],
    isLoading,
    refetch,
  } = trpc.notifications.getUserNotifications.useQuery(
    { limit: 100 },
    { refetchOnWindowFocus: false }
  );

  // Fetch unread count
  const { data: unreadData } = trpc.notifications.getUnreadCount.useQuery();

  // Mutations
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation({
    onSuccess: () => {
      utils.notifications.getUserNotifications.invalidate();
      utils.notifications.getUnreadCount.invalidate();
      toast.success("تم تحديد الإشعار كمقروء");
    },
  });

  const markAllAsReadMutation = trpc.notifications.markAllAsRead.useMutation({
    onSuccess: () => {
      utils.notifications.getUserNotifications.invalidate();
      utils.notifications.getUnreadCount.invalidate();
      toast.success("تم تحديد جميع الإشعارات كمقروءة");
    },
  });

  const deleteMutation = trpc.notifications.deleteNotification.useMutation({
    onSuccess: () => {
      utils.notifications.getUserNotifications.invalidate();
      utils.notifications.getUnreadCount.invalidate();
      toast.success("تم حذف الإشعار");
    },
  });

  const deleteAllReadMutation = trpc.notifications.deleteAllRead.useMutation({
    onSuccess: () => {
      utils.notifications.getUserNotifications.invalidate();
      utils.notifications.getUnreadCount.invalidate();
      setSelectedIds([]);
      toast.success("تم حذف جميع الإشعارات المقروءة");
    },
  });

  const filteredNotifications = (notifications as Notification[]).filter(n => {
    if (filter === "unread") {
      return !n.isRead;
    }
    if (filter === "read") {
      return n.isRead;
    }
    return true;
  });

  const unreadCount = (notifications as Notification[]).filter(
    n => !n.isRead
  ).length;
  const readCount = (notifications as Notification[]).filter(
    n => n.isRead
  ).length;

  const handleSelectAll = () => {
    if (selectedIds.length === filteredNotifications.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredNotifications.map(n => n.id));
    }
  };

  const handleDeleteSelected = () => {
    selectedIds.forEach(id => {
      deleteMutation.mutate({ id });
    });
    setSelectedIds([]);
  };

  const handleMarkSelectedAsRead = () => {
    selectedIds.forEach(id => {
      const notification = filteredNotifications.find(n => n.id === id);
      if (notification && !notification.isRead) {
        markAsReadMutation.mutate({ id });
      }
    });
    setSelectedIds([]);
  };

  const breadcrumbs = [
    { label: "الرئيسية", href: "/" },
    { label: "الإشعارات" },
  ];

  return (
    <PageLayout
      title={
        <div className="flex items-center gap-2">
          <Bell className="h-6 w-6 text-primary" />
          مركز الإشعارات
        </div>
      }
      description={`لديك ${unreadData?.count || 0} إشعارات غير مقروءة`}
      breadcrumbs={breadcrumbs}
      actions={
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isLoading}
          >
            <RefreshCw
              className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`}
            />
            تحديث
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/settings")}
          >
            <Settings className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </div>
      }
    >
      {/* Stats Cards */}
      <motion.div
        variants={cardVariants}
        initial="initial"
        animate="animate"
        className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8"
      >
        <StatCard
          icon={Bell}
          label="إجمالي الإشعارات"
          value={(notifications as Notification[]).length}
          color="primary"
        />
        <StatCard
          icon={AlertCircle}
          label="غير مقروءة"
          value={unreadCount}
          color="warning"
        />
        <StatCard
          icon={CheckCircle}
          label="مقروءة"
          value={readCount}
          color="success"
        />
        <StatCard
          icon={TrendingUp}
          label="اليوم"
          value={
            (notifications as Notification[]).filter(
              n =>
                new Date(n.createdAt).toDateString() ===
                new Date().toDateString()
            ).length
          }
          color="primary"
        />
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Sidebar */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
          className="lg:col-span-1"
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Filter className="h-5 w-5 text-primary" />
                الإجراءات السريعة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                data-testid="mark-all-read-button"
                variant="outline"
                className="w-full justify-start"
                onClick={() => markAllAsReadMutation.mutate()}
                disabled={markAllAsReadMutation.isPending || !unreadCount}
              >
                <CheckCheck className="ml-2 h-4 w-4" />
                تحديد الكل كمقروء
              </Button>
              <Button
                data-testid="delete-read-notifications-button"
                variant="outline"
                className="w-full justify-start text-red-600 hover:text-red-700"
                onClick={() => deleteAllReadMutation.mutate()}
                disabled={deleteAllReadMutation.isPending || !readCount}
              >
                <Trash2 className="ml-2 h-4 w-4" />
                حذف المقروءة
              </Button>
              {selectedIds.length > 0 && (
                <>
                  <Separator className="my-3" />
                  <p className="text-sm text-muted-foreground mb-2">
                    تم تحديد {selectedIds.length} إشعار
                  </p>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={handleMarkSelectedAsRead}
                  >
                    <Check className="ml-2 h-4 w-4" />
                    تحديد المحدد كمقروء
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-red-600 hover:text-red-700"
                    onClick={handleDeleteSelected}
                  >
                    <Trash2 className="ml-2 h-4 w-4" />
                    حذف المحدد
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Content */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.2 }}
          className="lg:col-span-3"
        >
          <Card className="premium-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-primary" />
                  الإشعارات
                </CardTitle>
                <Tabs
                  value={filter}
                  onValueChange={v => setFilter(v as "all" | "unread" | "read")}
                >
                  <TabsList>
                    <TabsTrigger value="all">
                      الكل ({(notifications as Notification[]).length})
                    </TabsTrigger>
                    <TabsTrigger value="unread">
                      غير مقروء ({unreadCount})
                    </TabsTrigger>
                    <TabsTrigger value="read">مقروء ({readCount})</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <Separator />
            <CardContent className="p-0">
              {/* Select All */}
              {filteredNotifications.length > 0 && (
                <div className="flex items-center gap-2 px-4 py-3 border-b bg-muted/30">
                  <Checkbox
                    checked={
                      selectedIds.length === filteredNotifications.length &&
                      filteredNotifications.length > 0
                    }
                    onCheckedChange={handleSelectAll}
                  />
                  <span className="text-sm text-muted-foreground">
                    تحديد الكل ({filteredNotifications.length})
                  </span>
                </div>
              )}

              {/* Notifications List */}
              <ScrollArea className="h-[500px]">
                <div className="p-4 space-y-3">
                  {isLoading ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">
                          جاري التحميل...
                        </p>
                      </div>
                    </div>
                  ) : filteredNotifications.length === 0 ? (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <BellOff className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">
                        لا توجد إشعارات
                      </h3>
                      <p className="text-muted-foreground">
                        {filter === "unread"
                          ? "لا توجد إشعارات غير مقروءة"
                          : filter === "read"
                            ? "لا توجد إشعارات مقروءة"
                            : "لم يتم استلام أي إشعارات بعد"}
                      </p>
                    </div>
                  ) : (
                    <AnimatePresence mode="popLayout">
                      {filteredNotifications.map((notification, index) => (
                        <NotificationItem
                          key={notification.id}
                          notification={notification}
                          isSelected={selectedIds.includes(notification.id)}
                          onSelect={() => {
                            if (selectedIds.includes(notification.id)) {
                              setSelectedIds(
                                selectedIds.filter(id => id !== notification.id)
                              );
                            } else {
                              setSelectedIds([...selectedIds, notification.id]);
                            }
                          }}
                          onMarkAsRead={() =>
                            markAsReadMutation.mutate({ id: notification.id })
                          }
                          onDelete={() =>
                            deleteMutation.mutate({ id: notification.id })
                          }
                          delay={index * 0.05}
                        />
                      ))}
                    </AnimatePresence>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </PageLayout>
  );
}
