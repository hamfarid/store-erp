/**
 * Learning Path Optimizer Page - Premium Gold Price Predictor
 * Learning Path Optimization Dashboard
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Separator } from "../components/ui/separator";
import { motion } from "framer-motion";
import { Loader2, TrendingUp, Zap, ArrowLeft, Sparkles, Target, Activity } from "lucide-react";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function LearningPathOptimizer() {
  const [, navigate] = useLocation();
  const [symbol, setSymbol] = useState("XAUUSD");
  const [optimizerType, setOptimizerType] = useState<"aco" | "rl">("aco");

  // Queries
  const { data: paths, isLoading } = trpc.learningPath.getLearningPaths.useQuery({
    symbol,
    limit: 10,
  });

  // Mutations
  const optimizeACO = trpc.learningPath.optimizeWithACO.useMutation({
    onSuccess: () => {
      toast.success("تم تحسين المسار بنجاح باستخدام ACO");
    },
    onError: (error) => {
      toast.error(`فشل التحسين: ${error.message}`);
    },
  });
  const optimizeRL = trpc.learningPath.optimizeWithRL.useMutation({
    onSuccess: () => {
      toast.success("تم تحسين المسار بنجاح باستخدام RL");
    },
    onError: (error) => {
      toast.error(`فشل التحسين: ${error.message}`);
    },
  });

  const handleOptimize = async () => {
    try {
      if (optimizerType === "aco") {
        await optimizeACO.mutateAsync({
          symbol,
          modelType: "lstm",
          availableFeatures: ["price", "volume", "ma_7", "ma_14", "rsi"],
          hyperparameterRanges: {
            learningRate: [0.001, 0.01],
            batchSize: [16, 64],
            epochs: [50, 200],
          },
          numAnts: 20,
          numIterations: 50,
        });
      } else {
        await optimizeRL.mutateAsync({
          symbol,
          modelType: "lstm",
          initialFeatures: ["price", "volume"],
          initialHyperparameters: {
            learningRate: 0.001,
            batchSize: 32,
            epochs: 100,
          },
          availableFeatures: ["price", "volume", "ma_7", "rsi", "macd"],
          hyperparameterOptions: {
            learningRate: [0.001, 0.01, 0.1],
            batchSize: [16, 32, 64],
            epochs: [50, 100, 200],
          },
          numEpisodes: 100,
        });
      }
    } catch (error) {
      console.error("Optimization failed:", error);
    }
  };

  const isPending = optimizeACO.isPending || optimizeRL.isPending;

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  محسّن مسار التعلم
                </h1>
                <p className="text-sm text-muted-foreground">
                  تحسين مسارات التعلم باستخدام خوارزميات ACO و RL
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Tabs value={optimizerType} onValueChange={(v) => setOptimizerType(v as any)}>
                <TabsList>
                  <TabsTrigger value="aco">ACO</TabsTrigger>
                  <TabsTrigger value="rl">RL</TabsTrigger>
                </TabsList>
              </Tabs>
              <Button data-testid="optimize-learning-path-button" onClick={handleOptimize} disabled={isPending} size="sm">
                {isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                {optimizerType === "aco" ? (
                  <Zap className="ml-2 h-4 w-4" />
                ) : (
                  <TrendingUp className="ml-2 h-4 w-4" />
                )}
                تحسين
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Optimization Results */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                تاريخ التحسين
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : paths && paths.length > 0 ? (
                <div className="space-y-4">
                  {paths.map((path: any, index: number) => (
                    <motion.div
                      key={path.id}
                      variants={cardVariants}
                      initial="initial"
                      animate="animate"
                      transition={{ delay: 0.1 * index }}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div>
                        <div className="font-medium flex items-center gap-2">
                          {path.modelType.toUpperCase()} -{" "}
                          {path.optimizerType.toUpperCase()}
                          <Badge variant="outline" className="mr-2">
                            {path.symbol}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          النقاط: {path.score.toFixed(4)}
                          {path.accuracy &&
                            ` | الدقة: ${(path.accuracy * 100).toFixed(2)}%`}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={
                            path.status === "completed"
                              ? "default"
                              : path.status === "running"
                              ? "secondary"
                              : "outline"
                          }
                        >
                          {path.status === "completed"
                            ? "مكتمل"
                            : path.status === "running"
                            ? "قيد التنفيذ"
                            : "فشل"}
                        </Badge>
                        {path.trainingTime && (
                          <span className="text-sm text-muted-foreground">
                            {Math.round(path.trainingTime / 1000)}s
                          </span>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    لا توجد نتائج تحسين بعد
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    انقر على "تحسين" لبدء عملية التحسين
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
