/**
 * Admin Users Management Page
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, UserCog, Trash2, Shield, User } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AdminUsers() {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | "admin" | "user">("all");

  const { data: users, isLoading, refetch } = trpc.admin.users.list.useQuery({
    limit: 50,
    offset: 0,
    search: search || undefined,
    role: roleFilter,
  });

  const updateRole = trpc.admin.users.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث دور المستخدم بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error("فشل تحديث دور المستخدم: " + error.message);
    },
  });

  const deleteUser = trpc.admin.users.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المستخدم بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error("فشل حذف المستخدم: " + error.message);
    },
  });

  const handleRoleChange = (userId: string, newRole: "admin" | "user") => {
    if (confirm(`هل أنت متأكد من تغيير دور المستخدم إلى ${newRole}؟`)) {
      updateRole.mutate({ userId, role: newRole });
    }
  };

  const handleDelete = (userId: string) => {
    if (confirm("هل أنت متأكد من حذف هذا المستخدم؟ هذا الإجراء لا يمكن التراجع عنه.")) {
      deleteUser.mutate({ userId });
    }
  };

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <UserCog className="h-6 w-6" />
            إدارة المستخدمين
          </CardTitle>
          <CardDescription>
            عرض وإدارة جميع مستخدمي النظام
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="search-users"
                placeholder="البحث بالاسم أو البريد الإلكتروني..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={roleFilter} onValueChange={(v: any) => setRoleFilter(v)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="تصفية حسب الدور" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأدوار</SelectItem>
                <SelectItem value="admin">مدير</SelectItem>
                <SelectItem value="user">مستخدم</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Users Table */}
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : !users || users.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا يوجد مستخدمين
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الاسم</TableHead>
                  <TableHead>البريد الإلكتروني</TableHead>
                  <TableHead>الدور</TableHead>
                  <TableHead>طريقة الدخول</TableHead>
                  <TableHead>تاريخ التسجيل</TableHead>
                  <TableHead>آخر دخول</TableHead>
                  <TableHead className="text-left">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user: any) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name || "-"}</TableCell>
                    <TableCell>{user.email || "-"}</TableCell>
                    <TableCell>
                      <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                        {user.role === "admin" ? (
                          <><Shield className="h-3 w-3 mr-1" /> مدير</>
                        ) : (
                          <><User className="h-3 w-3 mr-1" /> مستخدم</>
                        )}
                      </Badge>
                    </TableCell>
                    <TableCell>{user.loginMethod || "-"}</TableCell>
                    <TableCell>
                      {user.createdAt ? format(new Date(user.createdAt), "yyyy-MM-dd") : "-"}
                    </TableCell>
                    <TableCell>
                      {user.lastSignedIn ? format(new Date(user.lastSignedIn), "yyyy-MM-dd HH:mm") : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 justify-end">
                        <Select
                          value={user.role}
                          onValueChange={(v: "admin" | "user") => handleRoleChange(user.id, v)}
                        >
                          <SelectTrigger className="w-[120px]" data-testid="role-select">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">مستخدم</SelectItem>
                            <SelectItem value="admin">مدير</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          variant="destructive"
                          size="icon"
                          data-testid="delete-user"
                          onClick={() => handleDelete(user.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

