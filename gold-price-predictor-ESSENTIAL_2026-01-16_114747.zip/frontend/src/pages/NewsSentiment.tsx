/**
 * News Sentiment Page - Premium Gold Price Predictor
 * Modern news sentiment analysis with beautiful UI
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import {
  Newspaper,
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw,
  Search,
  ExternalLink,
  BarChart3,
  ThumbsUp,
  ThumbsDown,
  Circle,
  ArrowLeft,
  Sparkles,
  Brain,
  Zap,
  Filter,
  Clock,
  Globe,
  Target,
  Percent,
  FileText,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "",
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">
                {value}
                {suffix && (
                  <span className="text-sm font-normal text-muted-foreground">
                    {suffix}
                  </span>
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Sentiment Badge Component
function SentimentBadge({ label }: { label: string }) {
  const configs: Record<string, { color: string; icon: any; text: string }> = {
    positive: {
      color: "bg-emerald-100 text-emerald-700 border-emerald-300",
      icon: ThumbsUp,
      text: "إيجابي",
    },
    negative: {
      color: "bg-red-100 text-red-700 border-red-300",
      icon: ThumbsDown,
      text: "سلبي",
    },
    neutral: {
      color: "bg-gray-100 text-gray-700 border-gray-300",
      icon: Minus,
      text: "محايد",
    },
  };
  const config = configs[label] || configs.neutral;
  const Icon = config.icon;

  return (
    <Badge className={config.color} variant="outline">
      <Icon className="h-3 w-3 ml-1" />
      {config.text}
    </Badge>
  );
}

// Market Summary Card
function MarketSummaryCard({ asset }: { asset: any }) {
  const isPositive = asset.overallScore > 0.2;
  const isNegative = asset.overallScore < -0.2;

  return (
    <Card className="stat-card hover:shadow-lg transition-all group">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="font-bold text-lg">{asset.name}</span>
          <div
            className={`p-2 rounded-full ${
              isPositive
                ? "bg-emerald-100 dark:bg-emerald-900/30"
                : isNegative
                  ? "bg-red-100 dark:bg-red-900/30"
                  : "bg-gray-100 dark:bg-gray-800"
            }`}
          >
            {isPositive ? (
              <ThumbsUp className="h-5 w-5 text-emerald-600" />
            ) : isNegative ? (
              <ThumbsDown className="h-5 w-5 text-red-600" />
            ) : (
              <Minus className="h-5 w-5 text-gray-600" />
            )}
          </div>
        </div>
        <div
          className={`text-4xl font-bold mb-3 ${
            isPositive
              ? "text-emerald-600"
              : isNegative
                ? "text-red-600"
                : "text-gray-600"
          }`}
        >
          {asset.overallScore > 0 ? "+" : ""}
          {(asset.overallScore * 100).toFixed(0)}%
        </div>
        <SentimentBadge label={asset.overallLabel} />
        <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <FileText className="h-3 w-3" />
          <span>{asset.articlesAnalyzed} مقال تم تحليله</span>
        </div>
      </CardContent>
    </Card>
  );
}

// News Article Card
function NewsArticleCard({ article, index }: { article: any; index: number }) {
  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay: index * 0.05 }}
      className="group"
    >
      <Card className="hover:shadow-md transition-all">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-3 mb-2">
                <h3 className="font-semibold leading-tight line-clamp-2 group-hover:text-primary transition-colors">
                  {article.title}
                </h3>
                <SentimentBadge label={article.sentiment?.label || "neutral"} />
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {article.description}
              </p>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Globe className="h-3 w-3" />
                  <span>{article.source}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-3 w-3" />
                  <span>
                    {article.publishedAt
                      ? formatDistanceToNow(new Date(article.publishedAt), {
                          addSuffix: true,
                          locale: ar,
                        })
                      : ""}
                  </span>
                </div>
              </div>
            </div>
            <a
              href={article.url}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Button variant="outline" size="icon" className="h-8 w-8">
                <ExternalLink className="h-4 w-4" />
              </Button>
            </a>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function NewsSentiment() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("XAUUSD");
  const [customText, setCustomText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("gold");

  // Fetch asset sentiment
  const {
    data: assetSentiment,
    isLoading: loadingSentiment,
    refetch: refetchSentiment,
  } = trpc.newsSentiment.getAssetSentiment.useQuery({
    symbol: selectedAsset,
    days: 7,
  });

  // Fetch market summary
  const { data: marketSummary, isLoading: loadingSummary } =
    trpc.newsSentiment.getMarketSummary.useQuery();

  // Fetch news by category
  const { data: categoryNews, isLoading: loadingCategoryNews } =
    trpc.newsSentiment.getNewsByCategory.useQuery({
      category: selectedCategory as any,
      limit: 10,
    });

  // Fetch latest news
  const { data: latestNews, isLoading: loadingNews } =
    trpc.newsSentiment.getLatestNews.useQuery({ query: "gold price", days: 3 });

  // Analyze custom text mutation
  const analyzeTextMutation = trpc.newsSentiment.analyzeText.useMutation({
    onSuccess: (data: any) => {
      toast.success(
        `تحليل المشاعر: ${translateLabel(data?.label)} (${((data?.score || 0) * 100).toFixed(0)}%)`
      );
    },
  });

  const translateLabel = (label?: string) => {
    const translations: Record<string, string> = {
      positive: "إيجابي",
      negative: "سلبي",
      neutral: "محايد",
    };
    return translations[label || ""] || label;
  };

  const translateCategory = (category: string) => {
    const translations: Record<string, string> = {
      gold: "الذهب",
      silver: "الفضة",
      crypto: "العملات المشفرة",
      oil: "النفط",
      economy: "الاقتصاد",
      stocks: "الأسهم",
    };
    return translations[category] || category;
  };

  const isLoading =
    loadingSentiment || loadingSummary || loadingCategoryNews || loadingNews;

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Newspaper className="h-6 w-6 text-primary" />
                  تحليل مشاعر الأخبار
                </h1>
                <p className="text-sm text-muted-foreground">
                  تحليل المشاعر من الأخبار المالية
                </p>
              </div>
            </div>
            <Button
              data-testid="refresh-sentiment-button"
              variant="outline"
              size="sm"
              onClick={() => refetchSentiment()}
              disabled={isLoading}
            >
              <RefreshCw
                className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`}
              />
              تحديث
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Market Summary */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            ملخص السوق
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {loadingSummary
              ? Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i}>
                      <CardContent className="pt-6">
                        <div className="animate-pulse space-y-3">
                          <div className="h-4 bg-muted rounded w-1/2" />
                          <div className="h-10 bg-muted rounded w-3/4" />
                          <div className="h-6 bg-muted rounded w-1/3" />
                        </div>
                      </CardContent>
                    </Card>
                  ))
              : ((marketSummary as any[]) || []).map(
                  (asset: any, index: number) => (
                    <motion.div
                      key={index}
                      variants={cardVariants}
                      initial="initial"
                      animate="animate"
                      transition={{ delay: index * 0.1 }}
                    >
                      <MarketSummaryCard asset={asset} />
                    </motion.div>
                  )
                )}
          </div>
        </motion.div>

        {/* Sentiment Distribution */}
        {assetSentiment && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="mb-8"
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  توزيع المشاعر
                </CardTitle>
                <CardDescription>
                  تحليل {assetSentiment.articlesAnalyzed} مقال خلال الأسبوع
                  الماضي
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-6">
                  <Card className="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800">
                    <CardContent className="p-6 text-center">
                      <ThumbsUp className="h-10 w-10 text-emerald-600 mx-auto mb-3" />
                      <p className="text-4xl font-bold text-emerald-600 mb-1">
                        {assetSentiment.positiveCount}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        مقال إيجابي
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700">
                    <CardContent className="p-6 text-center">
                      <Circle className="h-10 w-10 text-gray-500 mx-auto mb-3" />
                      <p className="text-4xl font-bold text-gray-600 dark:text-gray-400 mb-1">
                        {assetSentiment.neutralCount}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        مقال محايد
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
                    <CardContent className="p-6 text-center">
                      <ThumbsDown className="h-10 w-10 text-red-600 mx-auto mb-3" />
                      <p className="text-4xl font-bold text-red-600 mb-1">
                        {assetSentiment.negativeCount}
                      </p>
                      <p className="text-sm text-muted-foreground">مقال سلبي</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Tabs */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.3 }}
        >
          <Tabs defaultValue="news" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 max-w-lg">
              <TabsTrigger value="news" className="gap-2">
                <Newspaper className="h-4 w-4" />
                آخر الأخبار
              </TabsTrigger>
              <TabsTrigger value="categories" className="gap-2">
                <Filter className="h-4 w-4" />
                حسب الفئة
              </TabsTrigger>
              <TabsTrigger value="analyze" className="gap-2">
                <Brain className="h-4 w-4" />
                تحليل نص
              </TabsTrigger>
            </TabsList>

            {/* Latest News Tab */}
            <TabsContent value="news">
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Newspaper className="h-5 w-5 text-primary" />
                    آخر الأخبار
                  </CardTitle>
                  <CardDescription>
                    أحدث الأخبار المتعلقة بالأسواق المالية
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingNews ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">
                          جاري تحميل الأخبار...
                        </p>
                      </div>
                    </div>
                  ) : ((latestNews as any[]) || []).length > 0 ? (
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-4">
                        {(latestNews as any[]).map(
                          (article: any, index: number) => (
                            <NewsArticleCard
                              key={index}
                              article={article}
                              index={index}
                            />
                          )
                        )}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <Newspaper className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">
                        لا توجد أخبار
                      </h3>
                      <p className="text-muted-foreground">
                        لم يتم العثور على أخبار متاحة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Categories Tab */}
            <TabsContent value="categories">
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Filter className="h-5 w-5 text-primary" />
                        الأخبار حسب الفئة
                      </CardTitle>
                      <CardDescription>
                        تصفية الأخبار حسب نوع الأصول
                      </CardDescription>
                    </div>
                    <Select
                      value={selectedCategory}
                      onValueChange={v => setSelectedCategory(v)}
                    >
                      <SelectTrigger
                        data-testid="news-category-select"
                        className="w-48"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gold">الذهب</SelectItem>
                        <SelectItem value="silver">الفضة</SelectItem>
                        <SelectItem value="crypto">العملات المشفرة</SelectItem>
                        <SelectItem value="oil">النفط</SelectItem>
                        <SelectItem value="economy">الاقتصاد</SelectItem>
                        <SelectItem value="stocks">الأسهم</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingCategoryNews ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                    </div>
                  ) : ((categoryNews as any[]) || []).length > 0 ? (
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-4">
                        {(categoryNews as any[]).map(
                          (article: any, index: number) => (
                            <NewsArticleCard
                              key={index}
                              article={article}
                              index={index}
                            />
                          )
                        )}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <Newspaper className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">
                        لا توجد أخبار
                      </h3>
                      <p className="text-muted-foreground">
                        لا توجد أخبار لفئة {translateCategory(selectedCategory)}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analyze Tab */}
            <TabsContent value="analyze">
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    تحليل نص مخصص
                  </CardTitle>
                  <CardDescription>
                    أدخل نصاً لتحليل مشاعره باستخدام الذكاء الاصطناعي
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Textarea
                    placeholder="أدخل النص هنا لتحليل المشاعر... مثال: ارتفعت أسعار الذهب اليوم بشكل ملحوظ مع تزايد المخاوف من التضخم"
                    value={customText}
                    onChange={e => setCustomText(e.target.value)}
                    className="min-h-[150px] resize-none"
                  />
                  <Button
                    onClick={() => {
                      if (customText.trim()) {
                        analyzeTextMutation.mutate({ text: customText });
                      }
                    }}
                    disabled={
                      !customText.trim() || analyzeTextMutation.isPending
                    }
                    className="w-full sm:w-auto"
                  >
                    {analyzeTextMutation.isPending ? (
                      <>
                        <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                        جاري التحليل...
                      </>
                    ) : (
                      <>
                        <Zap className="ml-2 h-4 w-4" />
                        تحليل المشاعر
                      </>
                    )}
                  </Button>

                  {analyzeTextMutation.data && (
                    <motion.div
                      variants={cardVariants}
                      initial="initial"
                      animate="animate"
                    >
                      <Card
                        className={`${
                          analyzeTextMutation.data.label === "positive"
                            ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200"
                            : analyzeTextMutation.data.label === "negative"
                              ? "bg-red-50 dark:bg-red-900/20 border-red-200"
                              : "bg-gray-50 dark:bg-gray-800/50 border-gray-200"
                        }`}
                      >
                        <CardContent className="p-6">
                          <div className="flex items-center gap-6">
                            <div
                              className={`p-4 rounded-xl ${
                                analyzeTextMutation.data.label === "positive"
                                  ? "bg-emerald-100 dark:bg-emerald-900/30"
                                  : analyzeTextMutation.data.label ===
                                      "negative"
                                    ? "bg-red-100 dark:bg-red-900/30"
                                    : "bg-gray-100 dark:bg-gray-700"
                              }`}
                            >
                              {analyzeTextMutation.data.label === "positive" ? (
                                <ThumbsUp className="h-10 w-10 text-emerald-600" />
                              ) : analyzeTextMutation.data.label ===
                                "negative" ? (
                                <ThumbsDown className="h-10 w-10 text-red-600" />
                              ) : (
                                <Minus className="h-10 w-10 text-gray-600" />
                              )}
                            </div>
                            <div className="flex-1">
                              <h3 className="text-2xl font-bold mb-2">
                                {translateLabel(analyzeTextMutation.data.label)}
                              </h3>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <p className="text-sm text-muted-foreground">
                                    النتيجة
                                  </p>
                                  <p className="text-xl font-bold">
                                    {(
                                      analyzeTextMutation.data.score * 100
                                    ).toFixed(0)}
                                    %
                                  </p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">
                                    الشدة
                                  </p>
                                  <p className="text-xl font-bold">
                                    {(
                                      analyzeTextMutation.data.magnitude * 100
                                    ).toFixed(0)}
                                    %
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  );
}
