/**
 * Register Page - Premium Gold Price Predictor
 * Modern registration page with animations
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { APP_LOGO, APP_TITLE } from "@/const";
import { trpc } from "@/lib/trpc";
import { useEffect, useState, useMemo } from "react";
import { useLocation, Link } from "wouter";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  Loader2,
  TrendingUp,
  Sparkles,
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  ArrowRight,
  Shield,
  CheckCircle2,
  XCircle,
  Gift,
} from "lucide-react";
import { cn } from "@/lib/utils";

// Password strength checker (aligned with backend validation)
function getPasswordStrength(password: string): { score: number; label: string; color: string } {
  let score = 0;
  
  if (password.length >= 8) {score += 20;}
  if (password.length >= 12) {score += 10;}
  if (/[a-z]/.test(password)) {score += 20;}
  if (/[A-Z]/.test(password)) {score += 20;}
  if (/[0-9]/.test(password)) {score += 15;}
  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {score += 15;}
  
  if (score < 30) {return { score, label: "ضعيفة جداً", color: "bg-red-500" };}
  if (score < 50) {return { score, label: "ضعيفة", color: "bg-orange-500" };}
  if (score < 70) {return { score, label: "متوسطة", color: "bg-amber-500" };}
  if (score < 85) {return { score, label: "جيدة", color: "bg-emerald-400" };}
  return { score: Math.min(score, 100), label: "قوية جداً", color: "bg-emerald-500" };
}

// Password requirement component
function PasswordRequirement({ met, text }: { met: boolean; text: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex items-center gap-2 text-xs"
    >
      {met ? (
        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
      ) : (
        <XCircle className="h-3.5 w-3.5 text-muted-foreground" />
      )}
      <span className={cn(met ? "text-emerald-500" : "text-muted-foreground")}>
        {text}
      </span>
    </motion.div>
  );
}

export default function Register() {
  const { user, loading, refresh } = useAuth();
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);

  const passwordStrength = useMemo(() => getPasswordStrength(password), [password]);

  const passwordRequirements = useMemo(() => ({
    length: password.length >= 8,
    lowercase: /[a-z]/.test(password),
    uppercase: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password),
  }), [password]);

  const registerMutation = trpc.auth.register.useMutation({
    onSuccess: async () => {
      toast.success("تم إنشاء الحساب بنجاح!");
      await refresh();
      setLocation("/dashboard");
    },
    onError: error => {
      toast.error(error.message || "فشل إنشاء الحساب");
    },
  });

  useEffect(() => {
    if (user && !loading) {
      setLocation("/dashboard");
    }
  }, [user, loading, setLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !email || !password || !confirmPassword) {
      toast.error("الرجاء ملء جميع الحقول");
      return;
    }

    if (password !== confirmPassword) {
      toast.error("كلمة المرور وتأكيد كلمة المرور غير متطابقين");
      return;
    }

    // Validate password strength
    if (password.length < 8) {
      toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }
    if (!/[A-Z]/.test(password)) {
      toast.error("كلمة المرور يجب أن تحتوي على حرف كبير على الأقل");
      return;
    }
    if (!/[a-z]/.test(password)) {
      toast.error("كلمة المرور يجب أن تحتوي على حرف صغير على الأقل");
      return;
    }
    if (!/[0-9]/.test(password)) {
      toast.error("كلمة المرور يجب أن تحتوي على رقم على الأقل");
      return;
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      toast.error("كلمة المرور يجب أن تحتوي على رمز خاص على الأقل (!@#$%^&*...)");
      return;
    }

    if (!acceptTerms) {
      toast.error("يجب الموافقة على شروط الخدمة");
      return;
    }

    registerMutation.mutate({ name, email, password });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gradient-hero overflow-hidden">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative p-12 flex-col justify-between">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-dots-pattern opacity-30" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative z-10"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 rounded-xl bg-primary/10 glow-gold">
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
            <span className="text-2xl font-bold">{APP_TITLE}</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="relative z-10 flex-1 flex flex-col justify-center"
        >
          <h1 className="text-4xl font-bold mb-6 leading-tight">
            <span className="block">انضم إلى آلاف</span>
            <span className="gold-shimmer">المستثمرين الأذكياء</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
            أنشئ حسابك مجاناً واحصل على توقعات دقيقة للأسعار وتحليلات متقدمة للسوق
          </p>
          
          {/* Benefits List */}
          <div className="mt-8 space-y-4">
            {[
              { icon: Gift, text: "فترة تجريبية مجانية" },
              { icon: Shield, text: "حماية بياناتك بأعلى المعايير" },
              { icon: TrendingUp, text: "توقعات دقيقة بنسبة 99%+" },
            ].map((benefit, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex items-center gap-3"
              >
                <div className="p-2 rounded-lg bg-primary/10">
                  <benefit.icon className="h-4 w-4 text-primary" />
                </div>
                <span className="text-muted-foreground">{benefit.text}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="relative z-10"
        >
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="w-8 h-8 rounded-full bg-primary/20 border-2 border-background flex items-center justify-center text-xs font-medium text-primary"
                >
                  {String.fromCharCode(65 + i)}
                </div>
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">+10,000</span> مستخدم نشط
            </p>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Register Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="inline-flex items-center gap-3">
              <div className="p-3 rounded-xl bg-primary/10 glow-gold">
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
              <span className="text-xl font-bold">{APP_TITLE}</span>
            </div>
          </div>

          <Card className="border-0 shadow-2xl bg-card/80 backdrop-blur-sm">
            <CardHeader className="text-center space-y-2 pb-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", duration: 0.5 }}
                className="mx-auto mb-2"
              >
                <div className="p-4 rounded-2xl bg-primary/10 inline-block">
                  <User className="h-8 w-8 text-primary" />
                </div>
              </motion.div>
              <CardTitle className="text-2xl font-bold">إنشاء حساب جديد</CardTitle>
              <CardDescription>
                أنشئ حسابك للوصول إلى توقعات الأسعار
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">الاسم</Label>
                  <div className="relative">
                    <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      name="name"
                      data-testid="register-name"
                      type="text"
                      placeholder="أحمد محمد"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      required
                      disabled={registerMutation.isPending}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <div className="relative">
                    <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      name="email"
                      data-testid="register-email"
                      type="email"
                      placeholder="example@email.com"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                      disabled={registerMutation.isPending}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">كلمة المرور</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      name="password"
                      data-testid="register-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                      disabled={registerMutation.isPending}
                      className="pr-10 pl-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  
                  {/* Password Strength */}
                  {password && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">قوة كلمة المرور</span>
                        <span className={cn("text-xs font-medium", 
                          passwordStrength.score < 50 ? "text-red-500" : 
                          passwordStrength.score < 75 ? "text-amber-500" : "text-emerald-500"
                        )}>
                          {passwordStrength.label}
                        </span>
                      </div>
                      <Progress value={passwordStrength.score} className="h-1.5" />
                      
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <PasswordRequirement met={passwordRequirements.length} text="8 أحرف على الأقل" />
                        <PasswordRequirement met={passwordRequirements.lowercase} text="حرف صغير" />
                        <PasswordRequirement met={passwordRequirements.uppercase} text="حرف كبير" />
                        <PasswordRequirement met={passwordRequirements.number} text="رقم واحد" />
                        <PasswordRequirement met={passwordRequirements.special} text="رمز خاص" />
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      data-testid="register-confirm-password"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      required
                      disabled={registerMutation.isPending}
                      className={cn(
                        "pr-10 pl-10",
                        confirmPassword && password !== confirmPassword && "border-red-500 focus-visible:ring-red-500"
                      )}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {confirmPassword && password !== confirmPassword && (
                    <p className="text-xs text-red-500">كلمة المرور غير متطابقة</p>
                  )}
                </div>

                <div className="flex items-start space-x-2 space-x-reverse">
                  <Checkbox
                    id="terms"
                    checked={acceptTerms}
                    onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                  />
                  <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
                    أوافق على{" "}
                    <Link href="/terms" className="text-primary hover:underline">
                      شروط الخدمة
                    </Link>{" "}
                    و{" "}
                    <Link href="/privacy" className="text-primary hover:underline">
                      سياسة الخصوصية
                    </Link>
                  </Label>
                </div>

                <Button
                  type="submit"
                  data-testid="register-submit"
                  className="w-full glow-gold group"
                  size="lg"
                  disabled={registerMutation.isPending || !acceptTerms}
                >
                  {registerMutation.isPending ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جاري إنشاء الحساب...
                    </>
                  ) : (
                    <>
                      إنشاء حساب
                      <ArrowRight className="mr-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">
                      أو
                    </span>
                  </div>
                </div>

                <div className="text-center text-sm">
                  <span className="text-muted-foreground">لديك حساب بالفعل؟ </span>
                  <Link
                    href="/login"
                    className="text-primary hover:underline font-medium"
                  >
                    تسجيل الدخول
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
