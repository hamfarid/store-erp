/**
 * Three-Level Predictions Page - Premium Gold Price Predictor
 * Display short, medium, and long-term predictions side by side
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  Target,
  Activity,
  Zap,
  ArrowLeft,
  Sparkles,
  BarChart3,
} from "lucide-react";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function ThreeLevelPredictions() {
  const [, navigate] = useLocation();
  const { language } = useLanguage();
  const isArabic = language === "ar";

  const [selectedAsset, setSelectedAsset] = useState<string>("GC=F");
  const [selectedAssetName, setSelectedAssetName] = useState<string>("Gold");

  const assets = [
    { symbol: "GC=F", name: "Gold", nameAr: "الذهب" },
    { symbol: "SI=F", name: "Silver", nameAr: "الفضة" },
    { symbol: "BTC-USD", name: "Bitcoin", nameAr: "بيتكوين" },
    { symbol: "ETH-USD", name: "Ethereum", nameAr: "إيثيريوم" },
    { symbol: "CL=F", name: "Crude Oil", nameAr: "النفط الخام" },
    { symbol: "PL=F", name: "Platinum", nameAr: "البلاتين" },
  ];

  const generatePredictionsMutation =
    trpc.predictionsAdvanced.generateThreeLevels.useMutation({
      onSuccess: () => {
        toast.success(
          isArabic ? "تم إنشاء التنبؤات بنجاح!" : "Predictions generated successfully!"
        );
      },
      onError: (error) => {
        toast.error(
          isArabic ? "فشل إنشاء التنبؤات" : "Failed to generate predictions"
        );
        console.error(error);
      },
    });

  const handleGenerate = () => {
    generatePredictionsMutation.mutate({
      assetSymbol: selectedAsset,
      assetName: selectedAssetName,
    });
  };

  const predictions = generatePredictionsMutation.data?.predictions;

  const renderPredictionCard = (
    prediction: any,
    level: "short" | "medium" | "long",
    icon: any,
    color: string
  ) => {
    if (!prediction) {return null;}

    const levelLabels = {
      short: {
        en: "Short-term",
        ar: "قصير المدى",
        days: "1-7 days",
        daysAr: "1-7 أيام",
      },
      medium: {
        en: "Medium-term",
        ar: "متوسط المدى",
        days: "7-30 days",
        daysAr: "7-30 يوم",
      },
      long: {
        en: "Long-term",
        ar: "طويل المدى",
        days: "30+ days",
        daysAr: "30+ يوم",
      },
    };

    const label = levelLabels[level];
    const isPositive = prediction.change >= 0;

    return (
      <motion.div
        variants={cardVariants}
        initial="initial"
        animate="animate"
        transition={{ delay: 0.1 }}
      >
        <Card className={`premium-card border-l-4 ${color}`}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                {icon}
                {isArabic ? label.ar : label.en}
              </span>
              <Badge variant={isPositive ? "default" : "destructive"}>
                {prediction.modelType.toUpperCase()}
              </Badge>
            </CardTitle>
            <CardDescription>
              {isArabic ? label.daysAr : label.days}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Current vs Predicted Price */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">
                  {isArabic ? "السعر الحالي" : "Current Price"}
                </p>
                <p className="text-2xl font-bold">
                  ${prediction.currentPrice.toLocaleString()}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">
                  {isArabic ? "السعر المتوقع" : "Predicted Price"}
                </p>
                <p className="text-2xl font-bold text-primary">
                  ${prediction.predictedPrice.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Change */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <span className="text-sm font-medium">
                {isArabic ? "التغيير" : "Change"}
              </span>
              <div className="flex items-center gap-2">
                {isPositive ? (
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-500" />
                )}
                <span
                  className={`font-bold ${
                    isPositive ? "text-emerald-500" : "text-red-500"
                  }`}
                >
                  {isPositive ? "+" : ""}
                  {prediction.changePercent.toFixed(2)}%
                </span>
                <span className="text-sm text-muted-foreground">
                  (${Math.abs(prediction.change).toFixed(2)})
                </span>
              </div>
            </div>

            {/* Confidence */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{isArabic ? "الثقة" : "Confidence"}</span>
                <span className="font-bold">
                  {prediction.confidence.toFixed(1)}%
                </span>
              </div>
              <Progress value={prediction.confidence} className="h-2" />
            </div>

            {/* Technical Indicators */}
            <div className="space-y-2">
              <p className="text-sm font-medium">
                {isArabic ? "المؤشرات الفنية" : "Technical Indicators"}
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex justify-between p-2 rounded bg-muted/50">
                  <span>RSI:</span>
                  <span className="font-medium">
                    {prediction.technicalIndicators.rsi}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-muted/50">
                  <span>MACD:</span>
                  <span className="font-medium">
                    {prediction.technicalIndicators.macd.value}
                  </span>
                </div>
              </div>
            </div>

            {/* Sentiment */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <span className="text-sm font-medium">
                {isArabic ? "المعنويات" : "Sentiment"}
              </span>
              <Badge
                variant={
                  prediction.sentiment.label === "positive"
                    ? "default"
                    : prediction.sentiment.label === "negative"
                    ? "destructive"
                    : "secondary"
                }
              >
                {prediction.sentiment.label === "positive"
                  ? isArabic
                    ? "إيجابي"
                    : "Positive"
                  : prediction.sentiment.label === "negative"
                  ? isArabic
                    ? "سلبي"
                    : "Negative"
                  : isArabic
                  ? "محايد"
                  : "Neutral"}
              </Badge>
            </div>

            {/* Correlations */}
            {prediction.correlations && prediction.correlations.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium">
                  {isArabic ? "الارتباطات" : "Correlations"}
                </p>
                <div className="space-y-1">
                  {prediction.correlations.slice(0, 3).map((corr: any, idx: number) => (
                    <div
                      key={idx}
                      className="flex justify-between text-xs p-2 rounded bg-muted/50"
                    >
                      <span>{corr.asset}</span>
                      <span className="font-medium">
                        {corr.correlation.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir={isArabic ? "rtl" : "ltr"}>
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  {isArabic ? "التنبؤات ثلاثية المستوى" : "Three-Level Predictions"}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {isArabic
                    ? "توقعات قصيرة ومتوسطة وطويلة المدى باستخدام نماذج مختلفة"
                    : "Short, medium, and long-term predictions using different models"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Controls */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                {isArabic ? "اختر الأصل" : "Select Asset"}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex gap-4">
              <Select
                value={selectedAsset}
                onValueChange={(value) => {
                  setSelectedAsset(value);
                  const asset = assets.find((a) => a.symbol === value);
                  if (asset) {setSelectedAssetName(asset.name);}
                }}
              >
                <SelectTrigger className="w-[300px]">
                  <SelectValue
                    placeholder={isArabic ? "اختر أصل" : "Select an asset"}
                  />
                </SelectTrigger>
                <SelectContent>
                  {assets.map((asset) => (
                    <SelectItem key={asset.symbol} value={asset.symbol}>
                      {isArabic ? asset.nameAr : asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                onClick={handleGenerate}
                disabled={generatePredictionsMutation.isPending}
              >
                {generatePredictionsMutation.isPending
                  ? isArabic
                    ? "جاري الإنشاء..."
                    : "Generating..."
                  : isArabic
                  ? "إنشاء التنبؤات"
                  : "Generate Predictions"}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Predictions Display */}
        {predictions && (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">{isArabic ? "الكل" : "All"}</TabsTrigger>
              <TabsTrigger value="short">
                {isArabic ? "قصير" : "Short"}
              </TabsTrigger>
              <TabsTrigger value="medium">
                {isArabic ? "متوسط" : "Medium"}
              </TabsTrigger>
              <TabsTrigger value="long">
                {isArabic ? "طويل" : "Long"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6 mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {renderPredictionCard(
                  predictions.shortTerm,
                  "short",
                  <Zap className="w-5 h-5" />,
                  "border-l-blue-500"
                )}
                {renderPredictionCard(
                  predictions.mediumTerm,
                  "medium",
                  <Activity className="w-5 h-5" />,
                  "border-l-yellow-500"
                )}
                {renderPredictionCard(
                  predictions.longTerm,
                  "long",
                  <Calendar className="w-5 h-5" />,
                  "border-l-green-500"
                )}
              </div>
            </TabsContent>

            <TabsContent value="short" className="mt-6">
              <div className="max-w-2xl mx-auto">
                {renderPredictionCard(
                  predictions.shortTerm,
                  "short",
                  <Zap className="w-5 h-5" />,
                  "border-l-blue-500"
                )}
              </div>
            </TabsContent>

            <TabsContent value="medium" className="mt-6">
              <div className="max-w-2xl mx-auto">
                {renderPredictionCard(
                  predictions.mediumTerm,
                  "medium",
                  <Activity className="w-5 h-5" />,
                  "border-l-yellow-500"
                )}
              </div>
            </TabsContent>

            <TabsContent value="long" className="mt-6">
              <div className="max-w-2xl mx-auto">
                {renderPredictionCard(
                  predictions.longTerm,
                  "long",
                  <Calendar className="w-5 h-5" />,
                  "border-l-green-500"
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}

        {/* Empty State */}
        {!predictions && !generatePredictionsMutation.isPending && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="premium-card">
              <CardContent className="p-12 text-center">
                <Target className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  {isArabic ? "لا توجد تنبؤات بعد" : "No Predictions Yet"}
                </h3>
                <p className="text-muted-foreground">
                  {isArabic
                    ? "اختر أصلاً وانقر على 'إنشاء التنبؤات' للبدء"
                    : "Select an asset and click 'Generate Predictions' to start"}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </main>
    </div>
  );
}
