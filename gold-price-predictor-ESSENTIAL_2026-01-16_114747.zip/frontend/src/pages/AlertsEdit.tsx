import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Save, X } from "lucide-react";

export default function AlertsEdit() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const alertId = params.id ? parseInt(params.id) : null;

  const [formData, setFormData] = useState({
    assetId: "",
    condition: "above" as "above" | "below" | "change",
    threshold: "",
    notificationMethod: "email" as "email" | "push",
    isActive: true,
  });

  // Fetch alert data
  const { data: alert, isLoading: alertLoading } = trpc.alerts.getById.useQuery(
    { id: alertId! },
    { enabled: !!alertId && isAuthenticated }
  );

  // Fetch assets
  const { data: assets } = trpc.assets.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Update mutation
  const updateMutation = trpc.alerts.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث التنبيه بنجاح");
      setLocation(`/alerts/view/${alertId}`);
    },
    onError: error => {
      toast.error(`فشل تحديث التنبيه: ${error.message}`);
    },
  });

  // Populate form when alert data loads
  useEffect(() => {
    if (alert) {
      const alertData = alert as any;
      setFormData({
        assetId: alertData.assetId?.toString() || "",
        condition: (alertData.alertType || "above") as
          | "above"
          | "below"
          | "change",
        threshold: alertData.targetPrice?.toString() || "",
        notificationMethod: (alertData.notificationMethod || "email") as
          | "email"
          | "push",
        isActive: alertData.isActive ?? true,
      });
    }
  }, [alert]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.assetId || !formData.threshold) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    if (alertId) {
      updateMutation.mutate({
        id: alertId,
        isActive: formData.isActive,
      });
    }
  };

  const handleCancel = () => {
    setLocation(`/alerts/view/${alertId}`);
  };

  if (authLoading || alertLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  if (!alert) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">التنبيه غير موجود</p>
          <Button className="mt-4" onClick={() => setLocation("/alerts")}>
            العودة إلى التنبيهات
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation(`/alerts/view/${alertId}`)}
            >
              <ArrowLeft className="h-4 w-4 ml-2" />
              العودة
            </Button>
            <h1 className="text-2xl font-bold text-slate-800">تعديل التنبيه</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>تعديل تفاصيل التنبيه</CardTitle>
            <CardDescription>قم بتحديث إعدادات التنبيه</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Asset (Read-only) */}
              <div className="space-y-2">
                <Label htmlFor="asset">الأصل</Label>
                <Input
                  id="asset"
                  value={
                    (assets as any)?.find(
                      (a: any) => (a as any).id === (alert as any).assetId
                    )?.name || ""
                  }
                  disabled
                  className="bg-slate-100"
                />
                <p className="text-sm text-slate-500">
                  لا يمكن تغيير الأصل بعد الإنشاء
                </p>
              </div>

              {/* Condition (Read-only) */}
              <div className="space-y-2">
                <Label htmlFor="condition">الشرط</Label>
                <Input
                  id="condition"
                  value={
                    formData.condition === "above"
                      ? "أعلى من"
                      : formData.condition === "below"
                        ? "أقل من"
                        : "تغيير بنسبة"
                  }
                  disabled
                  className="bg-slate-100"
                />
                <p className="text-sm text-slate-500">
                  لا يمكن تغيير الشرط بعد الإنشاء
                </p>
              </div>

              {/* Threshold (Read-only) */}
              <div className="space-y-2">
                <Label htmlFor="threshold">القيمة المستهدفة</Label>
                <Input
                  id="threshold"
                  value={`$${parseFloat(formData.threshold).toFixed(2)}`}
                  disabled
                  className="bg-slate-100"
                />
                <p className="text-sm text-slate-500">
                  لا يمكن تغيير القيمة بعد الإنشاء
                </p>
              </div>

              {/* Notification Method (Read-only) */}
              <div className="space-y-2">
                <Label htmlFor="method">طريقة الإشعار</Label>
                <Input
                  id="method"
                  value={
                    formData.notificationMethod === "email"
                      ? "بريد إلكتروني"
                      : "إشعار فوري"
                  }
                  disabled
                  className="bg-slate-100"
                />
                <p className="text-sm text-slate-500">
                  لا يمكن تغيير طريقة الإشعار بعد الإنشاء
                </p>
              </div>

              {/* Active Status (Editable) */}
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="isActive" className="text-base">
                    حالة التنبيه
                  </Label>
                  <p className="text-sm text-slate-500">
                    {formData.isActive
                      ? "التنبيه نشط وسيرسل إشعارات"
                      : "التنبيه غير نشط"}
                  </p>
                </div>
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={checked =>
                    setFormData({ ...formData, isActive: checked })
                  }
                />
              </div>

              {/* Buttons */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="flex-1"
                >
                  <Save className="h-4 w-4 ml-2" />
                  {updateMutation.isPending ? "جاري الحفظ..." : "حفظ التغييرات"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleCancel}
                  className="flex-1"
                >
                  <X className="h-4 w-4 ml-2" />
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="max-w-2xl mx-auto mt-6">
          <CardContent className="p-6">
            <h3 className="font-semibold text-lg mb-2">ملاحظة</h3>
            <p className="text-slate-600">
              يمكنك فقط تفعيل أو تعطيل التنبيه. لتغيير الأصل أو الشرط أو القيمة
              المستهدفة، يجب إنشاء تنبيه جديد.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
