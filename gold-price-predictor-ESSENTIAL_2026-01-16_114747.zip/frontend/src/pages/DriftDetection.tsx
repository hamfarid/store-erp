/**
 * Drift Detection Page - Premium Gold Price Predictor
 * Monitors model performance and detects data/concept drift
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "../components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Separator } from "../components/ui/separator";
import { motion } from "framer-motion";
import {
  Loader2,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Activity,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Bell,
  Check,
  ArrowLeft,
  Sparkles,
  Target,
  BarChart3,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">{value}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function DriftDetection() {
  const [, navigate] = useLocation();
  const [symbol, setSymbol] = useState("GC=F");
  const utils = trpc.useUtils();

  // Fetch assets using tRPC hook
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch drift detections
  const {
    data: detections,
    isLoading: loadingDetections,
    refetch: refetchDetections,
  } = trpc.drift.getDriftDetections.useQuery(
    { symbol, limit: 20 },
    { enabled: !!symbol }
  );

  // Fetch drift alerts
  const {
    data: alerts,
    isLoading: loadingAlerts,
    refetch: refetchAlerts,
  } = trpc.drift.getDriftAlerts.useQuery({
    acknowledged: false,
    limit: 10,
  });

  // Fetch metrics history
  const { data: metricsHistory } = trpc.drift.getDriftMetricsHistory.useQuery(
    { symbol, days: 30 },
    { enabled: !!symbol }
  );

  // Fetch retraining log
  const { data: retrainingLog } = trpc.drift.getModelRetrainingLog.useQuery(
    { symbol, limit: 10 },
    { enabled: !!symbol }
  );

  // Acknowledge alert mutation
  const acknowledgeMutation = trpc.drift.acknowledgeDriftAlert.useMutation({
    onSuccess: () => {
      utils.drift.getDriftAlerts.invalidate();
      toast.success("تم تأكيد التنبيه");
    },
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 dark:bg-red-950/20 text-red-800 dark:text-red-400 border-red-300 dark:border-red-800";
      case "high":
        return "bg-orange-100 dark:bg-orange-950/20 text-orange-800 dark:text-orange-400 border-orange-300 dark:border-orange-800";
      case "medium":
        return "bg-yellow-100 dark:bg-yellow-950/20 text-yellow-800 dark:text-yellow-400 border-yellow-300 dark:border-yellow-800";
      case "low":
        return "bg-emerald-100 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border-emerald-300 dark:border-emerald-800";
      default:
        return "bg-gray-100 dark:bg-gray-950/20 text-gray-800 dark:text-gray-400 border-gray-300 dark:border-gray-800";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <XCircle className="h-5 w-5 text-red-600" />;
      case "high":
        return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case "medium":
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case "low":
        return <CheckCircle className="h-5 w-5 text-emerald-600" />;
      default:
        return <Activity className="h-5 w-5" />;
    }
  };

  const handleRefresh = () => {
    refetchDetections();
    refetchAlerts();
    toast.success("تم تحديث البيانات");
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Activity className="h-6 w-6 text-primary" />
                  كشف الانحراف
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة أداء النماذج وكشف انحراف البيانات
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Select value={symbol} onValueChange={setSymbol}>
                <SelectTrigger data-testid="drift-asset-select" className="w-[180px]">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  {(assets as any[]).map((asset: any) => (
                    <SelectItem key={asset.id} value={asset.symbol}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button data-testid="refresh-drift-button" onClick={handleRefresh} variant="outline" size="sm">
                <RefreshCw
                  className={`ml-2 h-4 w-4 ${
                    loadingDetections || loadingAlerts ? "animate-spin" : ""
                  }`}
                />
                تحديث
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Active Alerts */}
        {alerts && (alerts as any[]).length > 0 && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            className="mb-8"
          >
            <div className="space-y-3">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                تنبيهات نشطة ({(alerts as any[]).length})
              </h2>
              {(alerts as any[]).map((alert: any, index: number) => (
                <motion.div
                  key={alert.id}
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.1 * index }}
                >
                  <Alert className={getSeverityColor(alert.severity)}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        {getSeverityIcon(alert.severity)}
                        <div>
                          <AlertTitle className="font-bold">
                            {alert.alertType}
                          </AlertTitle>
                          <AlertDescription className="mt-1">
                            {alert.message}
                          </AlertDescription>
                          <p className="text-xs mt-2 opacity-70">
                            {format(new Date(alert.createdAt), "PPpp", {
                              locale: ar,
                            })}
                          </p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => acknowledgeMutation.mutate(alert.id)}
                        disabled={acknowledgeMutation.isPending}
                      >
                        <Check className="ml-1 h-4 w-4" />
                        تأكيد
                      </Button>
                    </div>
                  </Alert>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={BarChart3}
            label="إجمالي الكشوفات"
            value={(detections as any[] || []).length}
            color="primary"
            delay={0}
          />
          <StatCard
            icon={TrendingDown}
            label="انحرافات مكتشفة"
            value={
              (detections as any[] || []).filter((d: any) => d.isDrift).length
            }
            color="danger"
            delay={0.1}
          />
          <StatCard
            icon={Bell}
            label="تنبيهات نشطة"
            value={(alerts as any[] || []).length}
            color="warning"
            delay={0.2}
          />
          <StatCard
            icon={RefreshCw}
            label="إعادات التدريب"
            value={(retrainingLog as any[] || []).length}
            color="primary"
            delay={0.3}
          />
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Detection History */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.4 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  سجل الكشف
                </CardTitle>
                <CardDescription>
                  آخر عمليات كشف الانحراف للأصل المحدد
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingDetections ? (
                  <div className="flex justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (detections as any[] || []).length > 0 ? (
                  <div className="space-y-3 max-h-[400px] overflow-y-auto">
                    {(detections as any[]).map((detection: any, index: number) => (
                      <div
                        key={detection.id || index}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          {detection.isDrift ? (
                            <TrendingDown className="h-5 w-5 text-red-500" />
                          ) : (
                            <TrendingUp className="h-5 w-5 text-emerald-500" />
                          )}
                          <div>
                            <div className="font-medium">
                              {detection.detectorType?.toUpperCase() || "Unknown"}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              نقاط: {parseFloat(detection.driftScore || 0).toFixed(4)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {format(new Date(detection.detectedAt), "PP", {
                                locale: ar,
                              })}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={detection.isDrift ? "destructive" : "secondary"}
                          >
                            {detection.isDrift ? "انحراف" : "طبيعي"}
                          </Badge>
                          <Badge className={getSeverityColor(detection.severity)}>
                            {detection.severity === "critical"
                              ? "حرج"
                              : detection.severity === "high"
                              ? "عالي"
                              : detection.severity === "medium"
                              ? "متوسط"
                              : "منخفض"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">لا توجد كشوفات مسجلة</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Retraining Log */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="h-5 w-5 text-primary" />
                  سجل إعادة التدريب
                </CardTitle>
                <CardDescription>عمليات إعادة تدريب النماذج</CardDescription>
              </CardHeader>
              <CardContent>
                {(retrainingLog as any[] || []).length > 0 ? (
                  <div className="space-y-3 max-h-[400px] overflow-y-auto">
                    {(retrainingLog as any[]).map((log: any, index: number) => (
                      <div
                        key={log.id || index}
                        className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">
                            {log.modelName || "Model"}
                          </span>
                          <Badge
                            variant={
                              log.status === "completed"
                                ? "default"
                                : "secondary"
                            }
                          >
                            {log.status === "completed"
                              ? "مكتمل"
                              : log.status === "running"
                              ? "قيد التنفيذ"
                              : "فشل"}
                          </Badge>
                        </div>
                        {log.metrics && (
                          <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
                            <span>
                              دقة: {(log.metrics.accuracy * 100).toFixed(1)}%
                            </span>
                            <span>MAE: {log.metrics.mae?.toFixed(4)}</span>
                            <span>RMSE: {log.metrics.rmse?.toFixed(4)}</span>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          {format(new Date(log.createdAt), "PPpp", { locale: ar })}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <RefreshCw className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      لا توجد عمليات إعادة تدريب
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Metrics History */}
        {(metricsHistory as any[] || []).length > 0 && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  تاريخ المقاييس
                </CardTitle>
                <CardDescription>
                  تطور مقاييس الانحراف خلال آخر 30 يوم
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-2">التاريخ</th>
                        <th className="text-right py-2">نوع الكاشف</th>
                        <th className="text-right py-2">القيمة</th>
                        <th className="text-right py-2">العتبة</th>
                        <th className="text-right py-2">الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(metricsHistory as any[])
                        .slice(0, 20)
                        .map((metric: any, index: number) => (
                          <tr
                            key={index}
                            className="border-b hover:bg-muted/50 transition-colors"
                          >
                            <td className="py-2">
                              {format(new Date(metric.timestamp), "PP", {
                                locale: ar,
                              })}
                            </td>
                            <td className="py-2">
                              {metric.detectorType?.toUpperCase()}
                            </td>
                            <td className="py-2">
                              {parseFloat(metric.value || 0).toFixed(4)}
                            </td>
                            <td className="py-2">
                              {parseFloat(metric.threshold || 0).toFixed(4)}
                            </td>
                            <td className="py-2">
                              <Badge
                                variant={
                                  metric.value > metric.threshold
                                    ? "destructive"
                                    : "secondary"
                                }
                              >
                                {metric.value > metric.threshold
                                  ? "تجاوز"
                                  : "طبيعي"}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </main>
    </div>
  );
}
