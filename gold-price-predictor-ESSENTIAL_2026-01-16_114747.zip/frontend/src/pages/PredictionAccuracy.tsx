/**
 * Prediction Accuracy Page - Premium Gold Price Predictor
 * Model accuracy comparison and analysis dashboard
 */

import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  TrendingUp,
  Award,
  BarChart3,
  Target,
  Sparkles,
  CheckCircle2,
  Activity,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "%",
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">
                  {value.toFixed(2)}
                  {suffix && <span className="text-sm font-normal text-muted-foreground">{suffix}</span>}
                </p>
              </div>
            </div>
          </div>
          <Progress value={value} className="h-1.5 mt-2" />
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function PredictionAccuracy() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState<number | null>(null);

  // Fetch assets
  const { data: assets } = trpc.assets.getAll.useQuery();

  // Fetch prediction accuracy data
  const { data: accuracyData, isLoading } =
    trpc.predictions.getAccuracyComparison.useQuery(
      {
        assetId: selectedAsset || undefined,
        days: 30,
      },
      {
        enabled: !!selectedAsset,
      }
    );

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  // Calculate overall accuracy for each model
  const modelStats = accuracyData
    ? {
        simple: {
          avgAccuracy:
            (accuracyData as any)
              .filter((d: any) => (d as any).modelType === "simple")
              .reduce((sum: any, d: any) => sum + (d as any).accuracy, 0) /
              (accuracyData as any).filter(
                (d: any) => (d as any).modelType === "simple"
              ).length || 0,
          count: (accuracyData as any).filter(
            (d: any) => (d as any).modelType === "simple"
          ).length,
        },
        advanced: {
          avgAccuracy:
            (accuracyData as any)
              .filter((d: any) => (d as any).modelType === "advanced")
              .reduce((sum: any, d: any) => sum + (d as any).accuracy, 0) /
              (accuracyData as any).filter(
                (d: any) => (d as any).modelType === "advanced"
              ).length || 0,
          count: (accuracyData as any).filter(
            (d: any) => (d as any).modelType === "advanced"
          ).length,
        },
        ensemble: {
          avgAccuracy:
            (accuracyData as any)
              .filter((d: any) => (d as any).modelType === "ensemble")
              .reduce((sum: any, d: any) => sum + (d as any).accuracy, 0) /
              (accuracyData as any).filter(
                (d: any) => (d as any).modelType === "ensemble"
              ).length || 0,
          count: (accuracyData as any).filter(
            (d: any) => (d as any).modelType === "ensemble"
          ).length,
        },
      }
    : null;

  // Prepare chart data
  const chartData = accuracyData
    ? (accuracyData as any).reduce((acc: any[], item: any) => {
        const dateStr = new Date(
          (item as any).predictionDate
        ).toLocaleDateString("ar-EG");
        let existing = acc.find((d) => d.date === dateStr);
        if (!existing) {
          existing = { date: dateStr };
          acc.push(existing);
        }
        existing[(item as any).modelType] = (item as any).accuracy;
        return acc;
      }, [])
    : [];

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  دقة التوقعات
                </h1>
                <p className="text-sm text-muted-foreground">
                  مقارنة أداء نماذج التعلم الآلي الثلاثة
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Asset Selection */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                اختيار الأصل
              </CardTitle>
              <CardDescription>اختر أصلاً لعرض دقة توقعاته</CardDescription>
            </CardHeader>
            <CardContent>
              <Select
                value={selectedAsset?.toString() || ""}
                onValueChange={(value) => setSelectedAsset(Number(value))}
              >
                <SelectTrigger className="w-full md:w-[300px]">
                  <SelectValue placeholder="-- اختر أصلاً --" />
                </SelectTrigger>
                <SelectContent>
                  {assets?.map((asset: any) => (
                    <SelectItem key={(asset as any).id} value={(asset as any).id.toString()}>
                      {(asset as any).name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {selectedAsset && modelStats ? (
          <>
            {/* Model Statistics Cards */}
            <div className="grid gap-4 md:grid-cols-3 mb-8">
              <StatCard
                icon={BarChart3}
                label="النموذج البسيط (Simple)"
                value={modelStats.simple.avgAccuracy}
                color="primary"
                delay={0.1}
              />
              <StatCard
                icon={TrendingUp}
                label="النموذج المتقدم (Advanced)"
                value={modelStats.advanced.avgAccuracy}
                color="success"
                delay={0.2}
              />
              <StatCard
                icon={Award}
                label="النموذج المجمّع (Ensemble)"
                value={modelStats.ensemble.avgAccuracy}
                color="warning"
                delay={0.3}
              />
            </div>

            {/* Accuracy Over Time Chart */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
              className="mb-8"
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    دقة التوقعات عبر الزمن
                  </CardTitle>
                  <CardDescription>
                    مقارنة دقة النماذج الثلاثة خلال آخر 30 يوماً
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="h-80 flex items-center justify-center">
                      <div className="text-muted-foreground">جاري التحميل...</div>
                    </div>
                  ) : chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={400}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                        <XAxis dataKey="date" />
                        <YAxis domain={[0, 100]} />
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="simple"
                          stroke="oklch(0.65 0.18 70)"
                          name="البسيط"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                        />
                        <Line
                          type="monotone"
                          dataKey="advanced"
                          stroke="oklch(0.72 0.19 145)"
                          name="المتقدم"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                        />
                        <Line
                          type="monotone"
                          dataKey="ensemble"
                          stroke="oklch(0.82 0.18 85)"
                          name="المجمّع"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-80 flex items-center justify-center">
                      <div className="text-muted-foreground">لا توجد بيانات متاحة</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Model Comparison Bar Chart */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.5 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-primary" />
                    مقارنة النماذج
                  </CardTitle>
                  <CardDescription>متوسط الدقة لكل نموذج</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={[
                        {
                          model: "البسيط",
                          accuracy: modelStats.simple.avgAccuracy,
                          count: modelStats.simple.count,
                        },
                        {
                          model: "المتقدم",
                          accuracy: modelStats.advanced.avgAccuracy,
                          count: modelStats.advanced.count,
                        },
                        {
                          model: "المجمّع",
                          accuracy: modelStats.ensemble.avgAccuracy,
                          count: modelStats.ensemble.count,
                        },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="model" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar dataKey="accuracy" fill="oklch(0.65 0.18 70)" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </>
        ) : (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="premium-card">
              <CardContent className="py-12 text-center">
                <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">اختر أصلاً لعرض دقة التوقعات</p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </main>
    </div>
  );
}
