/**
 * Admin Logs Page
 * View system logs and activities
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollText, Search, RefreshCw, Download } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function AdminLogs() {
  const [search, setSearch] = useState("");
  const [logType, setLogType] = useState<"all" | "error" | "warning" | "info">(
    "all"
  );
  const [dateFilter, setDateFilter] = useState("");

  const {
    data: logs,
    isLoading,
    refetch,
  } = trpc.admin.logs.list.useQuery({
    limit: 100,
    offset: 0,
    level: (logType as any) || undefined,
    startDate: dateFilter || undefined,
  });

  const exportLogs = (trpc.admin.logs as any).export.useMutation({
    onSuccess: (data: any) => {
      if ((data as any)?.content) {
        const blob = new Blob([(data as any).content], {
          type: (data as any).mimeType || "text/plain",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = (data as any).filename || "logs.txt";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }
      toast.success("تم تصدير السجلات بنجاح");
    },
    onError: (error: any) => {
      toast.error("فشل تصدير السجلات: " + error.message);
    },
  });

  const handleExport = () => {
    exportLogs.mutate({
      level: (logType as any) || undefined,
      startDate: dateFilter || undefined,
    } as any);
  };

  const getLogTypeBadge = (type: string) => {
    switch (type) {
      case "error":
        return <Badge variant="destructive">خطأ</Badge>;
      case "warning":
        return <Badge variant="secondary">تحذير</Badge>;
      case "info":
        return <Badge variant="default">معلومات</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl flex items-center gap-2">
                <ScrollText className="h-6 w-6" />
                سجلات النظام
              </CardTitle>
              <CardDescription>
                عرض وتصفية سجلات النشاط والأخطاء
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => refetch()}>
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button
                data-testid="export-logs-button"
                variant="outline"
                onClick={handleExport}
                disabled={exportLogs.isPending}
              >
                <Download className="h-4 w-4 mr-2" />
                {exportLogs.isPending ? "جاري التصدير..." : "تصدير"}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="search-logs"
                placeholder="البحث في السجلات..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={logType} onValueChange={(v: any) => setLogType(v)}>
              <SelectTrigger data-testid="log-type-filter">
                <SelectValue placeholder="نوع السجل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأنواع</SelectItem>
                <SelectItem value="error">أخطاء</SelectItem>
                <SelectItem value="warning">تحذيرات</SelectItem>
                <SelectItem value="info">معلومات</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="date"
              value={dateFilter}
              onChange={e => setDateFilter(e.target.value)}
              placeholder="تصفية حسب التاريخ"
            />
          </div>

          {/* Logs Table */}
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : !logs || logs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد سجلات
            </div>
          ) : (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>النوع</TableHead>
                    <TableHead>الرسالة</TableHead>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>التاريخ والوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log: any) => (
                    <TableRow key={log.id}>
                      <TableCell>{getLogTypeBadge(log.type)}</TableCell>
                      <TableCell className="max-w-md">
                        <div className="truncate" title={log.message}>
                          {log.message}
                        </div>
                        {log.details && (
                          <div className="text-xs text-muted-foreground mt-1 truncate">
                            {log.details}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{log.userName || log.userId || "-"}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {log.createdAt
                          ? format(
                              new Date(log.createdAt),
                              "yyyy-MM-dd HH:mm:ss"
                            )
                          : "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Summary */}
          {logs && logs.length > 0 && (
            <div className="mt-4 text-sm text-muted-foreground">
              عرض {logs.length} سجل
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
