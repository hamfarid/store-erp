/**
 * Reports Page - Premium Gold Price Predictor
 * Generate and export comprehensive analytics reports
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  FileText,
  Download,
  Calendar,
  ArrowLeft,
  Sparkles,
  BarChart3,
  PieChart,
  TrendingUp,
  Bell,
  FileJson,
  FileSpreadsheet,
  RefreshCw,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  DollarSign,
  Percent,
  Target,
  Activity,
  Filter,
} from "lucide-react";
import { toast } from "sonner";
import { Breadcrumbs } from "@/components/ui/breadcrumbs";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Report Type Card Component
function ReportTypeCard({
  icon: Icon,
  title,
  description,
  isActive,
  onClick,
}: {
  icon: any;
  title: string;
  description: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <Card
      className={`cursor-pointer transition-all hover:shadow-md ${
        isActive ? "ring-2 ring-primary border-primary" : ""
      }`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-lg ${isActive ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate">{title}</h3>
            <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Stats Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <Card className="stat-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${colors[color]}`}>
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-lg font-bold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Reports() {
  const [, navigate] = useLocation();
  const [activeReport, setActiveReport] = useState<"portfolio" | "accuracy" | "alerts">("portfolio");

  // Portfolio report params
  const [portfolioParams, setPortfolioParams] = useState({
    portfolioId: undefined as number | undefined,
    startDate: "",
    endDate: "",
  });

  // Accuracy report params
  const [accuracyParams, setAccuracyParams] = useState({
    assetId: undefined as number | undefined,
    modelType: "",
    startDate: "",
    endDate: "",
  });

  // Alerts report params
  const [alertsParams, setAlertsParams] = useState({
    startDate: "",
    endDate: "",
    status: "all" as "all" | "triggered" | "active" | "inactive",
  });

  // Queries with timeout handling
  const portfolioReport = trpc.reports.portfolioReport.useQuery(portfolioParams, {
    enabled: false,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const accuracyReport = trpc.reports.accuracyReport.useQuery(accuracyParams, {
    enabled: false,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const alertsReport = trpc.reports.alertsReport.useQuery(alertsParams, {
    enabled: false,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Mutations
  const exportCSV = trpc.reports.exportCSV.useMutation({
    onSuccess: (data) => {
      const blob = new Blob([data.content], { type: data.mimeType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success("تم تصدير التقرير بنجاح");
    },
    onError: (error) => {
      toast.error("فشل تصدير التقرير: " + error.message);
    },
  });

  const exportJSON = trpc.reports.exportJSON.useMutation({
    onSuccess: (data) => {
      const blob = new Blob([data.content], { type: data.mimeType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success("تم تصدير التقرير بنجاح");
    },
    onError: (error) => {
      toast.error("فشل تصدير التقرير: " + error.message);
    },
  });

  const handleExportCSV = (reportType: string, data: any) => {
    const filename = `${reportType}_report_${new Date().toISOString().split("T")[0]}.csv`;
    exportCSV.mutate({ reportType: reportType as any, data, filename });
  };

  const handleExportJSON = (reportType: string, data: any) => {
    const filename = `${reportType}_report_${new Date().toISOString().split("T")[0]}.json`;
    exportJSON.mutate({ reportType: reportType as any, data, filename });
  };

  const getCurrentReportData = () => {
    switch (activeReport) {
      case "portfolio": return portfolioReport.data;
      case "accuracy": return accuracyReport.data;
      case "alerts": return alertsReport.data;
    }
  };

  const isReportLoading = () => {
    switch (activeReport) {
      case "portfolio": return portfolioReport.isLoading || portfolioReport.isFetching;
      case "accuracy": return accuracyReport.isLoading || accuracyReport.isFetching;
      case "alerts": return alertsReport.isLoading || alertsReport.isFetching;
    }
  };

  const generateReport = () => {
    switch (activeReport) {
      case "portfolio": return portfolioReport.refetch();
      case "accuracy": return accuracyReport.refetch();
      case "alerts": return alertsReport.refetch();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <FileText className="h-6 w-6 text-primary" />
                  مركز التقارير
                </h1>
                <p className="text-sm text-muted-foreground">
                  إنشاء وتصدير تقارير شاملة
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="hidden sm:flex">
                <Clock className="h-3 w-3 ml-1" />
                آخر تحديث: {new Date().toLocaleDateString("ar-EG")}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Quick Stats */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8"
        >
          <StatCard icon={FileText} label="التقارير المتاحة" value={3} color="primary" />
          <StatCard icon={CheckCircle2} label="تقارير ناجحة" value={12} color="success" />
          <StatCard icon={Download} label="ملفات مُصدّرة" value={45} color="warning" />
          <StatCard icon={Clock} label="آخر تقرير" value="اليوم" color="primary" />
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Sidebar - Report Types */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.1 }}
            className="lg:col-span-1 space-y-4"
          >
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  نوع التقرير
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <ReportTypeCard
                  icon={PieChart}
                  title="تقرير المحفظة"
                  description="أداء المحفظة الاستثمارية"
                  isActive={activeReport === "portfolio"}
                  onClick={() => setActiveReport("portfolio")}
                />
                <ReportTypeCard
                  icon={Target}
                  title="تقرير الدقة"
                  description="دقة نماذج التوقع"
                  isActive={activeReport === "accuracy"}
                  onClick={() => setActiveReport("accuracy")}
                />
                <ReportTypeCard
                  icon={Bell}
                  title="تقرير التنبيهات"
                  description="ملخص التنبيهات والإشعارات"
                  isActive={activeReport === "alerts"}
                  onClick={() => setActiveReport("alerts")}
                />
              </CardContent>
            </Card>

            {/* Export Options */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Download className="h-5 w-5 text-primary" />
                  خيارات التصدير
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  data-testid="export-csv-button"
                  variant="outline"
                  className="w-full justify-start"
                  disabled={!getCurrentReportData() || exportCSV.isPending}
                  onClick={() => handleExportCSV(activeReport, getCurrentReportData())}
                >
                  <FileSpreadsheet className="ml-2 h-4 w-4 text-emerald-600" />
                  تصدير CSV
                </Button>
                <Button
                  data-testid="export-json-button"
                  variant="outline"
                  className="w-full justify-start"
                  disabled={!getCurrentReportData() || exportJSON.isPending}
                  onClick={() => handleExportJSON(activeReport, getCurrentReportData())}
                >
                  <FileJson className="ml-2 h-4 w-4 text-amber-600" />
                  تصدير JSON
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Main Report Area */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="lg:col-span-3"
          >
            <Card className="premium-card">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {activeReport === "portfolio" && <PieChart className="h-5 w-5 text-primary" />}
                      {activeReport === "accuracy" && <Target className="h-5 w-5 text-primary" />}
                      {activeReport === "alerts" && <Bell className="h-5 w-5 text-primary" />}
                      {activeReport === "portfolio" && "تقرير أداء المحفظة"}
                      {activeReport === "accuracy" && "تقرير دقة التوقعات"}
                      {activeReport === "alerts" && "تقرير التنبيهات"}
                    </CardTitle>
                    <CardDescription>
                      {activeReport === "portfolio" && "تحليل شامل لأداء محفظتك الاستثمارية"}
                      {activeReport === "accuracy" && "قياس دقة نماذج التوقع المختلفة"}
                      {activeReport === "alerts" && "ملخص تفصيلي لجميع التنبيهات"}
                    </CardDescription>
                  </div>
                  <Button data-testid="generate-report-button" onClick={() => generateReport()} disabled={isReportLoading()}>
                    {isReportLoading() ? (
                      <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Calendar className="ml-2 h-4 w-4" />
                    )}
                    إنشاء التقرير
                  </Button>
                </div>
              </CardHeader>
              <Separator />
              <CardContent className="pt-6">
                {/* Filters */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    معايير التقرير
                  </h4>

                  {/* Portfolio Report Filters */}
                  {activeReport === "portfolio" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>تاريخ البداية</Label>
                        <Input
                          type="date"
                          value={portfolioParams.startDate}
                          onChange={(e) =>
                            setPortfolioParams({ ...portfolioParams, startDate: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>تاريخ النهاية</Label>
                        <Input
                          type="date"
                          value={portfolioParams.endDate}
                          onChange={(e) =>
                            setPortfolioParams({ ...portfolioParams, endDate: e.target.value })
                          }
                        />
                      </div>
                    </div>
                  )}

                  {/* Accuracy Report Filters */}
                  {activeReport === "accuracy" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>تاريخ البداية</Label>
                        <Input
                          type="date"
                          value={accuracyParams.startDate}
                          onChange={(e) =>
                            setAccuracyParams({ ...accuracyParams, startDate: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>تاريخ النهاية</Label>
                        <Input
                          type="date"
                          value={accuracyParams.endDate}
                          onChange={(e) =>
                            setAccuracyParams({ ...accuracyParams, endDate: e.target.value })
                          }
                        />
                      </div>
                    </div>
                  )}

                  {/* Alerts Report Filters */}
                  {activeReport === "alerts" && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>تاريخ البداية</Label>
                        <Input
                          type="date"
                          value={alertsParams.startDate}
                          onChange={(e) =>
                            setAlertsParams({ ...alertsParams, startDate: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>تاريخ النهاية</Label>
                        <Input
                          type="date"
                          value={alertsParams.endDate}
                          onChange={(e) =>
                            setAlertsParams({ ...alertsParams, endDate: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>الحالة</Label>
                        <Select
                          value={alertsParams.status}
                          onValueChange={(v: any) =>
                            setAlertsParams({ ...alertsParams, status: v })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">الكل</SelectItem>
                            <SelectItem value="triggered">تم التنبيه</SelectItem>
                            <SelectItem value="active">نشط</SelectItem>
                            <SelectItem value="inactive">غير نشط</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>

                <Separator className="my-6" />

                {/* Report Results */}
                <div>
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Activity className="h-4 w-4" />
                    نتائج التقرير
                  </h4>

                  {isReportLoading() ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="relative">
                          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                          <Sparkles className="h-5 w-5 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                        </div>
                        <p className="mt-4 text-muted-foreground">جاري إنشاء التقرير...</p>
                        <p className="mt-2 text-xs text-muted-foreground">قد يستغرق هذا بضع ثوانٍ</p>
                      </div>
                    </div>
                  ) : getCurrentReportData() ? (
                    <Card className="bg-muted/50">
                      <CardContent className="p-4">
                        <ScrollArea className="h-[400px]">
                          <pre className="text-sm font-mono whitespace-pre-wrap break-words">
                            {JSON.stringify(getCurrentReportData(), null, 2)}
                          </pre>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card className="border-dashed">
                      <CardContent className="py-16 text-center">
                        <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                          <FileText className="h-12 w-12 text-primary" />
                        </div>
                        <h3 className="text-xl font-semibold mb-2">لا توجد بيانات</h3>
                        <p className="text-muted-foreground mb-6">
                          حدد معايير التقرير واضغط على "إنشاء التقرير"
                        </p>
                        <Button onClick={() => generateReport()}>
                          <Calendar className="ml-2 h-4 w-4" />
                          إنشاء التقرير
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
