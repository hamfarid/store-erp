/**
 * Learning Data Monitoring Dashboard
 * Monitor learning data quality trends with interactive charts
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Calendar,
  FileText,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

const COLORS = {
  primary: "#3b82f6",
  success: "#10b981",
  warning: "#f59e0b",
  danger: "#ef4444",
  purple: "#8b5cf6",
  cyan: "#06b6d4",
};

export default function LearningMonitoring() {
  const [days, setDays] = useState<number>(30);

  const { data: trends, isLoading, refetch } = trpc.monitoring.getLearningTrends.useQuery({ days });
  const { data: auditSummary } = trpc.monitoring.getAuditSummary.useQuery({ days: 7 });

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!trends) {
    return (
      <div className="container mx-auto py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>خطأ</AlertTitle>
          <AlertDescription>فشل تحميل بيانات المراقبة</AlertDescription>
        </Alert>
      </div>
    );
  }

  // Calculate current vs previous period
  const currentPeriod = trends.slice(-7);
  const previousPeriod = trends.slice(-14, -7);

  const avgNoiseCurrent = currentPeriod.reduce((sum, t) => sum + t.noisePercentage, 0) / currentPeriod.length;
  const avgNoisePrevious = previousPeriod.reduce((sum, t) => sum + t.noisePercentage, 0) / previousPeriod.length;
  const noiseChange = avgNoiseCurrent - avgNoisePrevious;

  const avgCoverageCurrent = currentPeriod.reduce((sum, t) => sum + t.coverageScore, 0) / currentPeriod.length;
  const avgCoveragePrevious = previousPeriod.reduce((sum, t) => sum + t.coverageScore, 0) / previousPeriod.length;
  const coverageChange = avgCoverageCurrent - avgCoveragePrevious;

  // Prepare data for pie chart (latest quality metrics)
  const latestMetrics = trends[trends.length - 1];
  const qualityPieData = [
    { name: "جودة عالية", value: latestMetrics.completenessScore, color: COLORS.success },
    { name: "تشوه", value: latestMetrics.noisePercentage, color: COLORS.danger },
    { name: "تكرار", value: latestMetrics.duplicatePercentage, color: COLORS.warning },
    {
      name: "أخرى",
      value: Math.max(0, 100 - latestMetrics.completenessScore - latestMetrics.noisePercentage - latestMetrics.duplicatePercentage),
      color: COLORS.cyan,
    },
  ];

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Activity className="h-8 w-8" />
            مراقبة بيانات التعلم
          </h1>
          <p className="text-muted-foreground">
            تتبع جودة واتجاهات بيانات التدريب عبر الزمن
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={days.toString()} onValueChange={(v) => setDays(parseInt(v))}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">آخر 7 أيام</SelectItem>
              <SelectItem value="14">آخر 14 يوم</SelectItem>
              <SelectItem value="30">آخر 30 يوم</SelectItem>
              <SelectItem value="90">آخر 90 يوم</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => refetch()} variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">عدد الأمثلة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{latestMetrics.totalExamples}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {trends[0].totalExamples < latestMetrics.totalExamples ? (
                <span className="text-green-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +{latestMetrics.totalExamples - trends[0].totalExamples} منذ البداية
                </span>
              ) : (
                <span className="text-gray-600">لا تغيير</span>
              )}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">نسبة التشوه</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgNoiseCurrent.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {noiseChange < 0 ? (
                <span className="text-green-600 flex items-center gap-1">
                  <TrendingDown className="h-3 w-3" />
                  {Math.abs(noiseChange).toFixed(1)}% تحسن
                </span>
              ) : noiseChange > 0 ? (
                <span className="text-red-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +{noiseChange.toFixed(1)}% زيادة
                </span>
              ) : (
                <span className="text-gray-600">لا تغيير</span>
              )}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">درجة التغطية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgCoverageCurrent.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {coverageChange > 0 ? (
                <span className="text-green-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +{coverageChange.toFixed(1)}% تحسن
                </span>
              ) : coverageChange < 0 ? (
                <span className="text-red-600 flex items-center gap-1">
                  <TrendingDown className="h-3 w-3" />
                  {Math.abs(coverageChange).toFixed(1)}% انخفاض
                </span>
              ) : (
                <span className="text-gray-600">لا تغيير</span>
              )}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">أحداث التدقيق</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{auditSummary?.totalEvents || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              آخر 7 أيام
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quality Trends Line Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            اتجاهات جودة البيانات
          </CardTitle>
          <CardDescription>
            تتبع مؤشرات الجودة عبر الزمن
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={trends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="date"
                tickFormatter={(date) => format(new Date(date), "dd MMM", { locale: ar })}
              />
              <YAxis domain={[0, 100]} />
              <Tooltip
                labelFormatter={(date) => format(new Date(date), "dd MMMM yyyy", { locale: ar })}
                formatter={(value: number) => `${value.toFixed(1)}%`}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="coverageScore"
                stroke={COLORS.success}
                name="التغطية"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="completenessScore"
                stroke={COLORS.primary}
                name="الاكتمال"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="noisePercentage"
                stroke={COLORS.danger}
                name="التشوه"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="duplicatePercentage"
                stroke={COLORS.warning}
                name="التكرار"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Examples Growth Area Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              نمو الأمثلة
            </CardTitle>
            <CardDescription>
              عدد أمثلة التدريب عبر الزمن
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={trends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(date) => format(new Date(date), "dd/MM", { locale: ar })}
                />
                <YAxis />
                <Tooltip
                  labelFormatter={(date) => format(new Date(date), "dd MMMM yyyy", { locale: ar })}
                />
                <Area
                  type="monotone"
                  dataKey="totalExamples"
                  stroke={COLORS.primary}
                  fill={COLORS.primary}
                  fillOpacity={0.6}
                  name="عدد الأمثلة"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Quality Distribution Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5" />
              توزيع الجودة
            </CardTitle>
            <CardDescription>
              التوزيع الحالي لمؤشرات الجودة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={qualityPieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {qualityPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `${value.toFixed(1)}%`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Audit Summary */}
      {auditSummary && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              ملخص التدقيق
            </CardTitle>
            <CardDescription>
              أحداث التدقيق في آخر 7 أيام
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Events by Type */}
              <div>
                <h4 className="font-medium mb-4">الأحداث حسب النوع</h4>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart
                    data={Object.entries(auditSummary.eventsByType).map(([type, count]) => ({
                      type,
                      count,
                    }))}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="type" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill={COLORS.primary} name="عدد الأحداث" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Events by Action */}
              <div>
                <h4 className="font-medium mb-4">الأحداث حسب الإجراء</h4>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart
                    data={Object.entries(auditSummary.eventsByAction).map(([action, count]) => ({
                      action,
                      count,
                    }))}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="action" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill={COLORS.success} name="عدد الأحداث" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

