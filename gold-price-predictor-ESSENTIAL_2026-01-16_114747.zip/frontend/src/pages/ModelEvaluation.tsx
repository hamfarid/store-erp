import { useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

/**
 * Model Evaluation Dashboard
 * Displays model performance metrics and comparisons
 */
export default function ModelEvaluation() {
  const [selectedAsset, setSelectedAsset] = useState<number | null>(null);
  const [timeRange, setTimeRange] = useState<number>(30);

  // Fetch assets
  const { data: assets, isLoading: assetsLoading } =
    trpc.assets.getAll.useQuery();

  // Fetch accuracy comparison
  const { data: accuracyData, isLoading: accuracyLoading } =
    trpc.predictions.getAccuracyComparison.useQuery(
      {
        assetId: selectedAsset || undefined,
        days: timeRange,
      },
      {
        enabled: !!selectedAsset,
      }
    );

  // Fetch model performance
  const { data: performanceData, isLoading: performanceLoading } =
    trpc.performance.getModelComparison.useQuery(
      {
        assetId: selectedAsset!,
      },
      {
        enabled: !!selectedAsset,
      }
    );

  // Fetch accuracy history
  const { data: historyData, isLoading: historyLoading } =
    trpc.performance.getAccuracyHistory.useQuery(
      {
        assetId: selectedAsset!,
        days: timeRange,
      },
      {
        enabled: !!selectedAsset,
      }
    );

  // Calculate metrics summary
  const metricsSummary = accuracyData
    ? {
        totalPredictions: accuracyData.length,
        avgAccuracy:
          accuracyData.reduce(
            (sum: number, item: any) => sum + parseFloat(item.accuracy || "0"),
            0
          ) / accuracyData.length,
        bestModel: accuracyData.reduce((best: any, current: any) =>
          parseFloat(current.accuracy || "0") > parseFloat(best.accuracy || "0")
            ? current
            : best
        ),
      }
    : null;

  // Prepare chart data for accuracy over time
  const accuracyChartData = historyData
    ? {
        labels: historyData.map((item: any) =>
          new Date(item.date).toLocaleDateString()
        ),
        datasets: [
          {
            label: "Model Accuracy (%)",
            data: historyData.map((item: any) =>
              parseFloat(item.accuracy || "0")
            ),
            borderColor: "rgb(75, 192, 192)",
            backgroundColor: "rgba(75, 192, 192, 0.2)",
            fill: true,
            tension: 0.4,
          },
        ],
      }
    : null;

  // Prepare chart data for model comparison
  const comparisonChartData =
    performanceData && Array.isArray(performanceData)
      ? {
          labels: performanceData.map((item: any) => item.modelType),
          datasets: [
            {
              label: "MSE",
              data: performanceData.map((item: any) => item.mse || 0),
              borderColor: "rgb(255, 99, 132)",
              backgroundColor: "rgba(255, 99, 132, 0.2)",
            },
            {
              label: "RMSE",
              data: performanceData.map((item: any) => item.rmse || 0),
              borderColor: "rgb(54, 162, 235)",
              backgroundColor: "rgba(54, 162, 235, 0.2)",
            },
            {
              label: "MAE",
              data: performanceData.map((item: any) => item.mae || 0),
              borderColor: "rgb(255, 206, 86)",
              backgroundColor: "rgba(255, 206, 86, 0.2)",
            },
          ],
        }
      : null;

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Model Evaluation Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Compare model performance and analyze prediction accuracy
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>
            Select asset and time range for evaluation
          </CardDescription>
        </CardHeader>
        <CardContent className="flex gap-4">
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Asset</label>
            <Select
              value={selectedAsset?.toString() || ""}
              onValueChange={value => setSelectedAsset(parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an asset" />
              </SelectTrigger>
              <SelectContent>
                {assetsLoading ? (
                  <SelectItem value="loading" disabled>
                    Loading...
                  </SelectItem>
                ) : (
                  assets?.map((asset: any) => (
                    <SelectItem key={asset.id} value={asset.id.toString()}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Time Range</label>
            <Select
              value={timeRange.toString()}
              onValueChange={value => setTimeRange(parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="180">Last 6 months</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {!selectedAsset ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Please select an asset to view evaluation metrics
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Metrics Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">
                  Total Predictions
                </CardTitle>
              </CardHeader>
              <CardContent>
                {accuracyLoading ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {metricsSummary?.totalPredictions || 0}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">
                  Average Accuracy
                </CardTitle>
              </CardHeader>
              <CardContent>
                {accuracyLoading ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {metricsSummary?.avgAccuracy.toFixed(2) || "0.00"}%
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">
                  Best Model
                </CardTitle>
              </CardHeader>
              <CardContent>
                {accuracyLoading ? (
                  <Skeleton className="h-8 w-32" />
                ) : (
                  <div className="space-y-1">
                    <div className="text-xl font-bold">
                      {(metricsSummary as any)?.bestModel?.modelType || "N/A"}
                    </div>
                    <Badge variant="secondary">
                      {(metricsSummary as any)?.bestModel?.accuracy || "0"}%
                      accuracy
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Tabs for different views */}
          <Tabs defaultValue="accuracy" className="space-y-4">
            <TabsList>
              <TabsTrigger value="accuracy">Accuracy Over Time</TabsTrigger>
              <TabsTrigger value="comparison">Model Comparison</TabsTrigger>
              <TabsTrigger value="metrics">Detailed Metrics</TabsTrigger>
            </TabsList>

            {/* Accuracy Over Time */}
            <TabsContent value="accuracy">
              <Card>
                <CardHeader>
                  <CardTitle>Accuracy Over Time</CardTitle>
                  <CardDescription>Track model accuracy trends</CardDescription>
                </CardHeader>
                <CardContent>
                  {historyLoading ? (
                    <Skeleton className="h-[400px] w-full" />
                  ) : accuracyChartData ? (
                    <div className="h-[400px]">
                      <Line data={accuracyChartData} options={chartOptions} />
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Model Comparison */}
            <TabsContent value="comparison">
              <Card>
                <CardHeader>
                  <CardTitle>Model Performance Comparison</CardTitle>
                  <CardDescription>
                    Compare MSE, RMSE, and MAE across models
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {performanceLoading ? (
                    <Skeleton className="h-[400px] w-full" />
                  ) : comparisonChartData ? (
                    <div className="h-[400px]">
                      <Line data={comparisonChartData} options={chartOptions} />
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Detailed Metrics */}
            <TabsContent value="metrics">
              <Card>
                <CardHeader>
                  <CardTitle>Detailed Metrics</CardTitle>
                  <CardDescription>
                    View all evaluation metrics by model
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {performanceLoading ? (
                    <Skeleton className="h-[400px] w-full" />
                  ) : performanceData &&
                    Array.isArray(performanceData) &&
                    performanceData.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Model Type</TableHead>
                          <TableHead>MSE</TableHead>
                          <TableHead>RMSE</TableHead>
                          <TableHead>MAE</TableHead>
                          <TableHead>R²</TableHead>
                          <TableHead>Directional Accuracy</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {performanceData.map((model: any, index: number) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">
                              {model.modelType}
                            </TableCell>
                            <TableCell>
                              {model.mse?.toFixed(4) || "N/A"}
                            </TableCell>
                            <TableCell>
                              {model.rmse?.toFixed(4) || "N/A"}
                            </TableCell>
                            <TableCell>
                              {model.mae?.toFixed(4) || "N/A"}
                            </TableCell>
                            <TableCell>
                              {model.r2?.toFixed(4) || "N/A"}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  model.directionalAccuracy >= 70
                                    ? "default"
                                    : "secondary"
                                }
                              >
                                {model.directionalAccuracy?.toFixed(2) || "0"}%
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}
