/**
 * Alerts Page - Premium Gold Price Predictor
 * Modern alerts management with gold theme
 */

import { useState } from "react";
import { PageLayout } from "@/components/PageLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation, Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Bell,
  Plus,
  Trash2,
  Mail,
  Smartphone,
  Search,
  Filter,
  Download,
  RefreshCw,
  Edit,
  Eye,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Sparkles,
  BellRing,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Settings,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import PaginationControls from "@/components/PaginationControls";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  subtext,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  subtext?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${colors[color]}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="text-2xl font-bold">{value}</p>
              {subtext && (
                <p className="text-xs text-muted-foreground">{subtext}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Alerts() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedAlertId, setSelectedAlertId] = useState<number | null>(null);
  const [sortConfig, setSortConfig] = useState<{
    column: string;
    direction: "asc" | "desc";
  }>({ column: "createdAt", direction: "desc" });

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [newAlert, setNewAlert] = useState({
    assetId: "",
    condition: "above" as "above" | "below" | "change",
    threshold: "",
    notificationMethod: "email" as "email" | "push" | "both",
  });

  const {
    data: alerts,
    refetch,
    isLoading,
  } = trpc.alerts.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: assets } = trpc.assets.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createMutation = trpc.alerts.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء التنبيه بنجاح!");
      setShowCreateForm(false);
      setNewAlert({
        assetId: "",
        condition: "above",
        threshold: "",
        notificationMethod: "email",
      });
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل إنشاء التنبيه: ${error.message}`);
    },
  });

  const updateMutation = trpc.alerts.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث التنبيه!");
      refetch();
    },
  });

  const deleteMutation = trpc.alerts.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف التنبيه!");
      refetch();
      setDeleteDialogOpen(false);
      setSelectedAlertId(null);
    },
    onError: (error) => {
      toast.error(`فشل حذف التنبيه: ${error.message}`);
    },
  });

  const handleCreate = () => {
    if (!newAlert.assetId || !newAlert.threshold) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    const channels =
      newAlert.notificationMethod === "both"
        ? ["email" as const, "push" as const]
        : [newAlert.notificationMethod as "email" | "push"];

    createMutation.mutate({
      assetId: parseInt(newAlert.assetId),
      condition: newAlert.condition,
      threshold: newAlert.threshold.toString(),
      channels,
    });
  };

  const handleToggle = (id: number, isActive: boolean) => {
    updateMutation.mutate({ id, isActive: !isActive });
  };

  const handleDeleteClick = (id: number) => {
    setSelectedAlertId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedAlertId) {
      deleteMutation.mutate({ id: selectedAlertId });
    }
  };

  const getAssetName = (assetId: number) => {
    return (
      (assets as any)?.find((a: any) => (a as any).id === assetId)?.name ||
      `Asset #${assetId}`
    );
  };

  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case "above":
        return <ArrowUpRight className="h-4 w-4 text-emerald-500" />;
      case "below":
        return <ArrowDownRight className="h-4 w-4 text-red-500" />;
      case "change":
        return <TrendingUp className="h-4 w-4 text-amber-500" />;
      default:
        return <Target className="h-4 w-4" />;
    }
  };

  const getConditionText = (condition: string) => {
    switch (condition) {
      case "above":
        return "أعلى من";
      case "below":
        return "أقل من";
      case "change":
        return "تغيير بنسبة";
      default:
        return condition;
    }
  };

  // Filter and sort alerts
  let filteredAlerts = alerts?.filter((alert: any) => {
    const assetName = getAssetName((alert as any).assetId);
    const matchesSearch = assetName
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesAsset =
      filterAsset === "all" || alert.assetId.toString() === filterAsset;
    const matchesStatus =
      filterStatus === "all" ||
      (filterStatus === "active" && alert.isActive) ||
      (filterStatus === "inactive" && !alert.isActive);
    return matchesSearch && matchesAsset && matchesStatus;
  });

  // Sort alerts
  if (filteredAlerts) {
    filteredAlerts = [...filteredAlerts].sort((a: any, b: any) => {
      const { column, direction } = sortConfig;
      let aValue: any = (a as any)[column as keyof typeof a];
      let bValue: any = (b as any)[column as keyof typeof b];

      if (column === "createdAt" || column === "lastTriggered") {
        aValue = aValue ? new Date(aValue).getTime() : 0;
        bValue = bValue ? new Date(bValue).getTime() : 0;
      }

      if (typeof aValue === "number" && typeof bValue === "number") {
        return direction === "asc" ? aValue - bValue : bValue - aValue;
      }

      if (typeof aValue === "string" && typeof bValue === "string") {
        return direction === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return 0;
    });
  }

  // Pagination
  const totalItems = filteredAlerts?.length || 0;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedAlerts = filteredAlerts?.slice(startIndex, endIndex);

  // Stats
  const totalAlerts = alerts?.length || 0;
  const activeAlerts = alerts?.filter((a: any) => a.isActive).length || 0;
  const triggeredAlerts = alerts?.filter((a: any) => a.isTriggered).length || 0;
  const activationRate = totalAlerts > 0 ? Math.round((activeAlerts / totalAlerts) * 100) : 0;

  // Export to CSV
  const handleExport = () => {
    if (!filteredAlerts || filteredAlerts.length === 0) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const csv = [
      ["ID", "Asset", "Condition", "Threshold", "Status", "Notification Method", "Created At"].join(","),
      ...filteredAlerts.map((a: any) =>
        [
          a.id,
          getAssetName(a.assetId),
          getConditionText(a.alertType),
          a.targetPrice,
          a.isActive ? "Active" : "Inactive",
          a.notificationMethod,
          a.createdAt ? new Date(a.createdAt).toLocaleDateString() : "N/A",
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `alerts_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
    toast.success("تم تصدير البيانات بنجاح");
  };

  if (!isAuthenticated) {
    navigate("/login");
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <PageLayout
      title={
        <div className="flex items-center gap-2">
          <Bell className="h-6 w-6 text-primary" />
          التنبيهات
        </div>
      }
      description="إدارة تنبيهات الأسعار والإشعارات"
      breadcrumbs={[
        { label: "الرئيسية", href: "/" },
        { label: "التنبيهات" },
      ]}
      actions={
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            تحديث
          </Button>
          <Button data-testid="create-alert-button" onClick={() => setShowCreateForm(true)}>
            <Plus className="ml-2 h-4 w-4" />
            تنبيه جديد
          </Button>
        </div>
      }
    >
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Bell}
            label="إجمالي التنبيهات"
            value={totalAlerts}
            subtext="جميع التنبيهات المسجلة"
            color="primary"
            delay={0}
          />
          <StatCard
            icon={BellRing}
            label="التنبيهات النشطة"
            value={activeAlerts}
            subtext="تنبيهات مفعّلة حالياً"
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={AlertTriangle}
            label="تم التفعيل"
            value={triggeredAlerts}
            subtext="تنبيهات تم تشغيلها"
            color="warning"
            delay={0.2}
          />
          <StatCard
            icon={Target}
            label="معدل التفعيل"
            value={`${activationRate}%`}
            subtext="نسبة التنبيهات المفعّلة"
            color="primary"
            delay={0.3}
          />
        </div>

        {/* Toolbar */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.4 }}
        >
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-4">
                {/* Search */}
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="بحث بالأصل..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>

                {/* Filter by Asset */}
                <Select value={filterAsset} onValueChange={setFilterAsset}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="الأصل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأصول</SelectItem>
                    {assets?.map((asset: any) => (
                      <SelectItem key={asset.id} value={asset.id.toString()}>
                        {asset.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Filter by Status */}
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="الحالة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الحالات</SelectItem>
                    <SelectItem value="active">نشط</SelectItem>
                    <SelectItem value="inactive">غير نشط</SelectItem>
                  </SelectContent>
                </Select>

                {/* Export */}
                <Button variant="outline" onClick={handleExport}>
                  <Download className="ml-2 h-4 w-4" />
                  تصدير
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Alerts List */}
        {paginatedAlerts && paginatedAlerts.length > 0 ? (
          <>
            <div className="grid gap-4">
              {paginatedAlerts.map((alert: any, index: number) => (
                <motion.div
                  key={alert.id}
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.5 + index * 0.05 }}
                >
                  <Card
                    className={`stat-card overflow-hidden ${
                      alert.isActive
                        ? "border-primary/30"
                        : "opacity-60"
                    }`}
                  >
                    {/* Gold accent for active alerts */}
                    {alert.isActive && (
                      <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
                    )}
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          {/* Status Icon */}
                          <div className={`p-3 rounded-xl ${
                            alert.isActive
                              ? "bg-primary/10"
                              : "bg-muted"
                          }`}>
                            {alert.isTriggered ? (
                              <CheckCircle2 className="h-6 w-6 text-emerald-500" />
                            ) : alert.isActive ? (
                              <BellRing className="h-6 w-6 text-primary" />
                            ) : (
                              <XCircle className="h-6 w-6 text-muted-foreground" />
                            )}
                          </div>

                          {/* Alert Details */}
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold text-lg">
                                {getAssetName(alert.assetId)}
                              </h3>
                              <Badge variant={alert.isActive ? "default" : "secondary"}>
                                {alert.isActive ? "نشط" : "غير نشط"}
                              </Badge>
                              {alert.isTriggered && (
                                <Badge variant="outline" className="text-emerald-600 border-emerald-600">
                                  تم التفعيل
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-1 text-muted-foreground">
                              {getConditionIcon(alert.alertType)}
                              <span>{getConditionText(alert.alertType)}</span>
                              <span className="font-semibold text-foreground">${alert.targetPrice}</span>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                {alert.notificationMethod === "email" ? (
                                  <><Mail className="h-3 w-3" /> بريد إلكتروني</>
                                ) : (
                                  <><Smartphone className="h-3 w-3" /> إشعار فوري</>
                                )}
                              </span>
                              <span>
                                تم الإنشاء: {new Date(alert.createdAt).toLocaleDateString("ar-EG")}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={alert.isActive}
                              onCheckedChange={() => handleToggle(alert.id, alert.isActive)}
                            />
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid="view-alert"
                            onClick={() => navigate(`/alerts/view/${alert.id}`)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid="edit-alert"
                            onClick={() => navigate(`/alerts/edit/${alert.id}`)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid="delete-alert"
                            onClick={() => handleDeleteClick(alert.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={totalItems}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={(newSize) => {
                    setPageSize(newSize);
                    setCurrentPage(1);
                  }}
                />
              </div>
            )}
          </>
        ) : (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
          >
            <Card className="border-dashed">
              <CardContent className="p-12 text-center">
                <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                  <Bell className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">لا توجد تنبيهات بعد</h3>
                <p className="text-muted-foreground mb-6">
                  أنشئ تنبيهاً جديداً لتتبع أسعار الأصول
                </p>
                <Button onClick={() => setShowCreateForm(true)}>
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء تنبيه جديد
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

      {/* Create Alert Dialog */}
      <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              إنشاء تنبيه جديد
            </DialogTitle>
            <DialogDescription>
              سيتم إرسال إشعار عند تحقق الشرط المحدد
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="asset">الأصل</Label>
              <Select
                value={newAlert.assetId}
                onValueChange={(value) => setNewAlert({ ...newAlert, assetId: value })}
              >
                <SelectTrigger id="asset" data-testid="alert-asset-select">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  {assets?.map((asset: any) => (
                    <SelectItem key={asset.id} value={asset.id.toString()}>
                      {asset.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="condition">الشرط</Label>
              <Select
                value={newAlert.condition}
                onValueChange={(value: "above" | "below" | "change") =>
                  setNewAlert({ ...newAlert, condition: value })
                }
              >
                <SelectTrigger id="condition">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">
                    <div className="flex items-center gap-2">
                      <ArrowUpRight className="h-4 w-4 text-emerald-500" />
                      أعلى من
                    </div>
                  </SelectItem>
                  <SelectItem value="below">
                    <div className="flex items-center gap-2">
                      <ArrowDownRight className="h-4 w-4 text-red-500" />
                      أقل من
                    </div>
                  </SelectItem>
                  <SelectItem value="change">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-amber-500" />
                      تغيير بنسبة
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="threshold">القيمة المستهدفة</Label>
              <Input
                id="threshold"
                type="number"
                step="0.01"
                data-testid="alert-threshold-input"
                placeholder={newAlert.condition === "change" ? "مثال: 5 (نسبة مئوية)" : "مثال: 2000"}
                value={newAlert.threshold}
                onChange={(e) => setNewAlert({ ...newAlert, threshold: e.target.value })}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="method">طريقة الإشعار</Label>
              <Select
                value={newAlert.notificationMethod}
                onValueChange={(value: "email" | "push" | "both") =>
                  setNewAlert({ ...newAlert, notificationMethod: value })
                }
              >
                <SelectTrigger id="method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      بريد إلكتروني
                    </div>
                  </SelectItem>
                  <SelectItem value="push">
                    <div className="flex items-center gap-2">
                      <Smartphone className="h-4 w-4" />
                      إشعار فوري
                    </div>
                  </SelectItem>
                  <SelectItem value="both">
                    <div className="flex items-center gap-2">
                      <Bell className="h-4 w-4" />
                      كلاهما
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateForm(false)}>
              إلغاء
            </Button>
            <Button data-testid="submit-alert-form" onClick={handleCreate} disabled={createMutation.isPending}>
              {createMutation.isPending ? "جاري الإنشاء..." : "إنشاء التنبيه"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا التنبيه؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "جاري الحذف..." : "حذف"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  );
}
