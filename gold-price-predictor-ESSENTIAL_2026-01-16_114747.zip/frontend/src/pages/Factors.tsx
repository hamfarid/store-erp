/**
 * Factors Page - Premium Gold Price Predictor
 * Factor influence adjustment and weight management
 */

import { useState } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  Sliders,
  RotateCcw,
  TrendingUp,
  TrendingDown,
  ArrowLeft,
  Sparkles,
  BarChart3,
  Target,
  AlertTriangle,
  CheckCircle2,
  Zap,
} from "lucide-react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { toast } from "sonner";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

interface Factor {
  name: string;
  description: string;
  weight: number;
  defaultWeight: number;
  impact: "positive" | "negative" | "neutral";
  category: "economic" | "technical" | "market" | "geopolitical";
}

const ASSETS = [
  { value: "gold", label: "Gold (الذهب)" },
  { value: "bitcoin", label: "Bitcoin (بيتكوين)" },
  { value: "ethereum", label: "Ethereum (إيثيريوم)" },
  { value: "try_usd", label: "TRY/USD (الليرة التركية)" },
  { value: "egp_usd", label: "EGP/USD (الجنيه المصري)" },
];

const INITIAL_FACTORS: Factor[] = [
  {
    name: "CPI (Consumer Price Index)",
    description: "مؤشر التضخم",
    weight: 0.15,
    defaultWeight: 0.15,
    impact: "positive",
    category: "economic",
  },
  {
    name: "Interest Rates",
    description: "أسعار الفائدة للبنك المركزي",
    weight: 0.12,
    defaultWeight: 0.12,
    impact: "negative",
    category: "economic",
  },
  {
    name: "DXY Index",
    description: "قوة الدولار الأمريكي",
    weight: 0.18,
    defaultWeight: 0.18,
    impact: "negative",
    category: "market",
  },
  {
    name: "Oil Prices",
    description: "سوق النفط الخام",
    weight: 0.10,
    defaultWeight: 0.10,
    impact: "positive",
    category: "market",
  },
  {
    name: "Silver Prices",
    description: "ارتباط المعادن الثمينة",
    weight: 0.08,
    defaultWeight: 0.08,
    impact: "positive",
    category: "market",
  },
  {
    name: "Moving Average (7d)",
    description: "الاتجاه قصير المدى",
    weight: 0.12,
    defaultWeight: 0.12,
    impact: "neutral",
    category: "technical",
  },
  {
    name: "Moving Average (30d)",
    description: "الاتجاه طويل المدى",
    weight: 0.10,
    defaultWeight: 0.10,
    impact: "neutral",
    category: "technical",
  },
  {
    name: "Volatility",
    description: "استقرار السعر",
    weight: 0.08,
    defaultWeight: 0.08,
    impact: "negative",
    category: "technical",
  },
  {
    name: "Geopolitical Events",
    description: "التوترات العالمية",
    weight: 0.07,
    defaultWeight: 0.07,
    impact: "positive",
    category: "geopolitical",
  },
];

export default function Factors() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("gold");
  const [factors, setFactors] = useState<Factor[]>(INITIAL_FACTORS);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const updateFactorWeight = (index: number, newWeight: number) => {
    const newFactors = [...factors];
    newFactors[index].weight = newWeight / 100;
    setFactors(newFactors);
  };

  const resetFactors = () => {
    setFactors(
      factors.map((f) => ({
        ...f,
        weight: f.defaultWeight,
      }))
    );
    toast.success("تم إعادة تعيين الأوزان إلى القيم الافتراضية");
  };

  const normalizeWeights = () => {
    const total = factors.reduce((sum, f) => sum + f.weight, 0);
    setFactors(
      factors.map((f) => ({
        ...f,
        weight: f.weight / total,
      }))
    );
    toast.success("تم تطبيع الأوزان بنجاح");
  };

  const filteredFactors =
    selectedCategory === "all"
      ? factors
      : factors.filter((f) => f.category === selectedCategory);

  // Chart data
  const chartData = {
    labels: factors.map((f) => f.name),
    datasets: [
      {
        label: "وزن العامل",
        data: factors.map((f) => f.weight * 100),
        backgroundColor: factors.map((f) => {
          if (f.impact === "positive")
            {return "oklch(0.72 0.19 145 / 0.6)";}
          if (f.impact === "negative")
            {return "oklch(0.55 0.22 25 / 0.6)";}
          return "oklch(0.65 0.05 250 / 0.6)";
        }),
        borderColor: factors.map((f) => {
          if (f.impact === "positive")
            {return "oklch(0.72 0.19 145)";}
          if (f.impact === "negative")
            {return "oklch(0.55 0.22 25)";}
          return "oklch(0.65 0.05 250)";
        }),
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `الوزن: ${context.parsed.y.toFixed(1)}%`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 25,
        ticks: {
          callback: (value: any) => `${value}%`,
        },
      },
    },
  };

  const totalWeight = factors.reduce((sum, f) => sum + f.weight, 0);
  const isNormalized = Math.abs(totalWeight - 1.0) < 0.01;

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      economic: "اقتصادي",
      technical: "تقني",
      market: "السوق",
      geopolitical: "جيو سياسي",
    };
    return labels[category] || category;
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Sliders className="h-6 w-6 text-primary" />
                  تأثير العوامل
                </h1>
                <p className="text-sm text-muted-foreground">
                  اضبط وزن العوامل التي تؤثر على توقعات الأسعار
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button data-testid="reset-factors-button" variant="outline" onClick={resetFactors} size="sm">
                <RotateCcw className="ml-2 h-4 w-4" />
                إعادة تعيين
              </Button>
              <Button
                data-testid="normalize-weights-button"
                onClick={normalizeWeights}
                disabled={isNormalized}
                size="sm"
              >
                <Sliders className="ml-2 h-4 w-4" />
                تطبيع الأوزان
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Asset Selection */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                اختيار الأصل
              </CardTitle>
              <CardDescription>
                اختر الأصل لتكوين العوامل له
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                <SelectTrigger data-testid="factors-asset-select" className="w-full md:w-[300px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ASSETS.map((asset) => (
                    <SelectItem key={asset.value} value={asset.value}>
                      {asset.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {/* Weight Summary */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                توزيع الأوزان
              </CardTitle>
              <CardDescription>
                إجمالي الوزن: {(totalWeight * 100).toFixed(1)}%
                {!isNormalized && (
                  <Badge variant="outline" className="mr-2 text-amber-600 border-amber-600">
                    <AlertTriangle className="h-3 w-3 ml-1" />
                    غير مطبيع - انقر على "تطبيع الأوزان"
                  </Badge>
                )}
                {isNormalized && (
                  <Badge variant="outline" className="mr-2 text-emerald-600 border-emerald-600">
                    <CheckCircle2 className="h-3 w-3 ml-1" />
                    مطبيع
                  </Badge>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <Bar data={chartData} options={chartOptions} />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                تصفية حسب الفئة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 flex-wrap">
                <Button
                  variant={selectedCategory === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("all")}
                >
                  الكل
                </Button>
                <Button
                  variant={selectedCategory === "economic" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("economic")}
                >
                  اقتصادي
                </Button>
                <Button
                  variant={selectedCategory === "technical" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("technical")}
                >
                  تقني
                </Button>
                <Button
                  variant={selectedCategory === "market" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("market")}
                >
                  السوق
                </Button>
                <Button
                  variant={selectedCategory === "geopolitical" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("geopolitical")}
                >
                  جيو سياسي
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Factors List */}
        <div className="space-y-4">
          {filteredFactors.map((factor, index) => {
            const actualIndex = factors.findIndex((f) => f.name === factor.name);
            return (
              <motion.div
                key={factor.name}
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 * index }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">{factor.name}</CardTitle>
                        <CardDescription>{factor.description}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{getCategoryLabel(factor.category)}</Badge>
                        {factor.impact === "positive" && (
                          <Badge className="bg-emerald-500 text-white">
                            <TrendingUp className="h-3 w-3 ml-1" />
                            إيجابي
                          </Badge>
                        )}
                        {factor.impact === "negative" && (
                          <Badge className="bg-red-500 text-white">
                            <TrendingDown className="h-3 w-3 ml-1" />
                            سلبي
                          </Badge>
                        )}
                        {factor.impact === "neutral" && (
                          <Badge variant="secondary">محايد</Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          الوزن: {(factor.weight * 100).toFixed(1)}%
                        </span>
                        <span className="text-xs text-muted-foreground">
                          الافتراضي: {(factor.defaultWeight * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Slider
                        value={[factor.weight * 100]}
                        onValueChange={(value) =>
                          updateFactorWeight(actualIndex, value[0])
                        }
                        min={0}
                        max={25}
                        step={0.5}
                        className="w-full"
                      />
                      <Progress value={(factor.weight * 100) / 25} className="h-1.5" />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
