/**
 * Not Found (404) Page
 * Modern error page with gold theme
 */

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { AlertCircle, Home, ArrowRight, Search, Sparkles } from "lucide-react";
import { useLocation, Link } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-hero p-4">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-dots-pattern opacity-30" />
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-lg"
      >
        <Card className="border-0 shadow-2xl bg-card/80 backdrop-blur-sm overflow-hidden">
          {/* Gold accent line */}
          <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
          
          <CardContent className="pt-12 pb-10 text-center px-8">
            {/* Animated Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.6 }}
              className="flex justify-center mb-8"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping" />
                <div className="relative p-6 bg-primary/10 rounded-full">
                  <AlertCircle className="h-12 w-12 text-primary" />
                </div>
              </div>
            </motion.div>

            {/* Error Code */}
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-7xl font-bold gold-shimmer mb-4"
            >
              404
            </motion.h1>

            {/* Title */}
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-2xl font-semibold text-foreground mb-4"
            >
              الصفحة غير موجودة
            </motion.h2>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-muted-foreground mb-8 leading-relaxed"
            >
              عذراً، الصفحة التي تبحث عنها غير موجودة.
              <br />
              ربما تم نقلها أو حذفها.
            </motion.p>

            {/* Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-3 justify-center"
            >
              <Button
                onClick={() => setLocation("/")}
                className="glow-gold group"
                size="lg"
              >
                <Home className="ml-2 h-4 w-4" />
                العودة للرئيسية
                <ArrowRight className="mr-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button
                variant="outline"
                onClick={() => setLocation("/dashboard")}
                size="lg"
              >
                <Sparkles className="ml-2 h-4 w-4" />
                لوحة التحكم
              </Button>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-10 pt-6 border-t"
            >
              <p className="text-sm text-muted-foreground mb-4">روابط سريعة</p>
              <div className="flex flex-wrap justify-center gap-2">
                {[
                  { href: "/assets", label: "الأصول" },
                  { href: "/predictions", label: "التوقعات" },
                  { href: "/alerts", label: "التنبيهات" },
                  { href: "/help", label: "المساعدة" },
                ].map((link) => (
                  <Link key={link.href} href={link.href}>
                    <Button variant="ghost" size="sm" className="text-xs">
                      {link.label}
                    </Button>
                  </Link>
                ))}
              </div>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
