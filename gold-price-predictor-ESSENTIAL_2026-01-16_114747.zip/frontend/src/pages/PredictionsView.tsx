import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Trash2,
  Printer,
  TrendingUp,
  TrendingDown,
  Calendar,
  Target,
} from "lucide-react";

export default function PredictionsView() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams();
  const predictionId = params.id ? parseInt(params.id) : null;

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // Fetch prediction data
  const { data: prediction, isLoading: predictionLoading } =
    trpc.predictions.getById.useQuery(
      { id: predictionId! },
      { enabled: !!predictionId && isAuthenticated }
    );

  // Fetch asset data
  const { data: asset } = trpc.assets.getById.useQuery(
    { id: (prediction as any)?.assetId! },
    { enabled: !!(prediction as any)?.assetId && isAuthenticated }
  );

  // Delete mutation
  const deletePredictionMutation = trpc.predictions.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف التوقع بنجاح");
      setLocation("/history");
    },
    onError: error => {
      toast.error(`فشل حذف التوقع: ${error.message}`);
    },
  });

  const handleDelete = () => {
    if (predictionId) {
      deletePredictionMutation.mutate({ id: predictionId });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (authLoading || predictionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  if (!prediction) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">التوقع غير موجود</p>
          <Button className="mt-4" onClick={() => setLocation("/history")}>
            العودة إلى السجل
          </Button>
        </div>
      </div>
    );
  }

  const priceChange =
    parseFloat((prediction as any).predictedPrice) -
    parseFloat((prediction as any).currentPrice);
  const priceChangePercent =
    (priceChange / parseFloat((prediction as any).currentPrice)) * 100;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 print:hidden">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/history")}
              >
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة إلى السجل
              </Button>
              <h1 className="text-2xl font-bold text-slate-800">
                تفاصيل التوقع
              </h1>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="h-4 w-4 ml-2" />
                طباعة
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info Card */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-6 w-6 text-blue-600" />
                {(asset as any)?.name ||
                  `Asset #${(prediction as any).assetId}`}
              </CardTitle>
              <CardDescription>
                توقع تم إنشاؤه في{" "}
                {new Date(
                  (prediction as any).predictionDate
                ).toLocaleDateString("ar-EG")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Prediction ID */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    معرف التوقع
                  </label>
                  <p className="mt-1 text-lg font-semibold">
                    #{(prediction as any).id}
                  </p>
                </div>

                {/* Model Type */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    نوع النموذج
                  </label>
                  <p className="mt-1 text-lg font-semibold capitalize">
                    {(prediction as any).modelType}
                  </p>
                </div>

                {/* Prediction Date */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    تاريخ التوقع
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <Calendar className="h-4 w-4 text-slate-400" />
                    <p className="text-lg font-semibold">
                      {new Date(
                        (prediction as any).predictionDate
                      ).toLocaleDateString("ar-EG")}
                    </p>
                  </div>
                </div>

                {/* Target Date */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    التاريخ المستهدف
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <Calendar className="h-4 w-4 text-slate-400" />
                    <p className="text-lg font-semibold">
                      {new Date(
                        (prediction as any).targetDate
                      ).toLocaleDateString("ar-EG")}
                    </p>
                  </div>
                  <p className="text-sm text-slate-500">
                    {(prediction as any).daysAhead} يوم قادم
                  </p>
                </div>

                {/* Current Price */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    السعر الحالي
                  </label>
                  <p className="mt-1 text-2xl font-bold text-slate-800">
                    ${parseFloat((prediction as any).currentPrice).toFixed(2)}
                  </p>
                </div>

                {/* Predicted Price */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    السعر المتوقع
                  </label>
                  <p className="mt-1 text-2xl font-bold text-blue-600">
                    ${parseFloat((prediction as any).predictedPrice).toFixed(2)}
                  </p>
                </div>

                {/* Price Change */}
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-slate-500">
                    التغير المتوقع
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    {priceChange > 0 ? (
                      <TrendingUp className="h-6 w-6 text-green-600" />
                    ) : (
                      <TrendingDown className="h-6 w-6 text-red-600" />
                    )}
                    <p
                      className={`text-2xl font-bold ${priceChange > 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {priceChange > 0 ? "+" : ""}
                      {priceChange.toFixed(2)} ({priceChangePercent.toFixed(2)}
                      %)
                    </p>
                  </div>
                </div>

                {/* Confidence Interval */}
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-slate-500">
                    فترة الثقة
                  </label>
                  <p className="mt-1 text-lg">
                    ${(prediction as any).confidenceLower} - $
                    {(prediction as any).confidenceUpper}
                  </p>
                  <p className="text-sm text-slate-500">
                    نطاق السعر المتوقع بثقة 95%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Accuracy Card */}
          <Card>
            <CardHeader>
              <CardTitle>دقة التوقع</CardTitle>
              <CardDescription>مقياس جودة النموذج</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-6">
                <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white mb-4">
                  <span className="text-4xl font-bold">
                    {(
                      parseFloat((prediction as any).accuracy || "0") * 100
                    ).toFixed(1)}
                    %
                  </span>
                </div>
                <p className="text-slate-600">
                  {parseFloat((prediction as any).accuracy || "0") >= 0.9
                    ? "دقة ممتازة"
                    : parseFloat((prediction as any).accuracy || "0") >= 0.8
                      ? "دقة جيدة جداً"
                      : parseFloat((prediction as any).accuracy || "0") >= 0.7
                        ? "دقة جيدة"
                        : "دقة متوسطة"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mt-8 flex gap-4 print:hidden">
          <Button
            onClick={() =>
              setLocation(`/predict/${(prediction as any).assetId}`)
            }
          >
            إنشاء توقع جديد لنفس الأصل
          </Button>
          <Button variant="outline" onClick={() => setLocation("/history")}>
            العودة إلى السجل
          </Button>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد الحذف</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا التوقع؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deletePredictionMutation.isPending}
            >
              {deletePredictionMutation.isPending
                ? "جاري الحذف..."
                : "حذف نهائياً"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
