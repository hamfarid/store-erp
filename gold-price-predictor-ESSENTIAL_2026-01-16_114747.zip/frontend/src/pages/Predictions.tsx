/**
 * Predictions Page - Premium Gold Price Predictor
 * AI-powered price predictions with confidence intervals
 */

import { useState } from "react";
import { useLocation, Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Download,
  Calendar,
  Target,
  ArrowLeft,
  RefreshCw,
  Brain,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  LineChart,
  Activity,
  Zap,
  Info,
  ChevronRight,
} from "lucide-react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const ASSETS = [
  { value: "gold", label: "الذهب (XAU)", symbol: "XAU", icon: "🥇" },
  { value: "silver", label: "الفضة (XAG)", symbol: "XAG", icon: "🥈" },
  { value: "bitcoin", label: "بيتكوين (BTC)", symbol: "BTC", icon: "₿" },
  { value: "ethereum", label: "إيثيريوم (ETH)", symbol: "ETH", icon: "Ξ" },
  { value: "try_usd", label: "الليرة التركية (TRY)", symbol: "TRY", icon: "₺" },
  { value: "egp_usd", label: "الجنيه المصري (EGP)", symbol: "EGP", icon: "£" },
];

const MODELS = [
  { value: "ensemble", label: "Ensemble (الأفضل)", accuracy: 99.03 },
  { value: "lstm", label: "LSTM", accuracy: 97.8 },
  { value: "ridge", label: "Ridge", accuracy: 96.5 },
  { value: "xgboost", label: "XGBoost", accuracy: 95.2 },
];

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  trend,
  trendValue,
  color = "primary",
}: {
  icon: any;
  label: string;
  value: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "primary" | "success" | "warning" | "danger";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  const trendColors = {
    up: "text-emerald-600",
    down: "text-red-600",
    neutral: "text-muted-foreground",
  };

  return (
    <Card className="stat-card">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {trendValue && trend && (
              <p className={`text-xs mt-1 flex items-center gap-1 ${trendColors[trend]}`}>
                {trend === "up" ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : trend === "down" ? (
                  <ArrowDownRight className="h-3 w-3" />
                ) : null}
                {trendValue}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-xl ${colors[color]}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Predictions() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("gold");
  const [selectedModel, setSelectedModel] = useState("ensemble");
  const [predictionDays, setPredictionDays] = useState(30);
  const [showConfidenceInterval, setShowConfidenceInterval] = useState(true);

  // Fetch historical data
  const { data: historicalData } = (trpc as any).models.getHistoricalData.useQuery({
    days: 90,
  });

  // Fetch predictions
  const {
    data: predictionsData,
    isLoading: predictionsLoading,
    mutate: generatePredictions,
  } = (trpc as any).models.predictMultipleDays.useMutation();

  const handleGeneratePredictions = () => {
    generatePredictions({
      asset: selectedAsset,
      days: predictionDays,
      model: selectedModel,
    });
  };

  // Prepare chart data
  const prepareChartData = () => {
    if (!historicalData?.data || !predictionsData?.predictions) {
      return null;
    }

    const historical = historicalData.data.slice(-30);
    const priceKey = getPriceKey(selectedAsset);

    const historicalPrices = historical.map((d: any) => d[priceKey]);
    const historicalDates = historical.map((d: any) =>
      new Date(d.Date).toLocaleDateString("ar-EG", { month: "short", day: "numeric" })
    );

    const lastDate = new Date(historical[historical.length - 1].Date);
    const futureDates = Array.from({ length: predictionDays }, (_, i) => {
      const date = new Date(lastDate);
      date.setDate(date.getDate() + i + 1);
      return date.toLocaleDateString("ar-EG", { month: "short", day: "numeric" });
    });

    const upperBound = predictionsData.predictions.map((p: number) => p * 1.05);
    const lowerBound = predictionsData.predictions.map((p: number) => p * 0.95);

    return {
      labels: [...historicalDates, ...futureDates],
      datasets: [
        {
          label: "البيانات التاريخية",
          data: [...historicalPrices, ...Array(predictionDays).fill(null)],
          borderColor: "rgb(59, 130, 246)",
          backgroundColor: "rgba(59, 130, 246, 0.1)",
          fill: false,
          tension: 0.4,
          pointRadius: 2,
        },
        {
          label: "التوقعات",
          data: [
            ...Array(historicalPrices.length - 1).fill(null),
            historicalPrices[historicalPrices.length - 1],
            ...predictionsData.predictions,
          ],
          borderColor: "oklch(0.75 0.15 80)",
          backgroundColor: "oklch(0.75 0.15 80 / 20%)",
          fill: false,
          tension: 0.4,
          borderDash: [5, 5],
          pointRadius: 3,
          pointBackgroundColor: "oklch(0.75 0.15 80)",
        },
        ...(showConfidenceInterval
          ? [
              {
                label: "الحد الأعلى (+5%)",
                data: [...Array(historicalPrices.length).fill(null), ...upperBound],
                borderColor: "oklch(0.75 0.15 80 / 30%)",
                backgroundColor: "oklch(0.75 0.15 80 / 10%)",
                fill: "+1",
                tension: 0.4,
                borderDash: [2, 2],
                pointRadius: 0,
              },
              {
                label: "الحد الأدنى (-5%)",
                data: [...Array(historicalPrices.length).fill(null), ...lowerBound],
                borderColor: "oklch(0.75 0.15 80 / 30%)",
                backgroundColor: "transparent",
                fill: false,
                tension: 0.4,
                borderDash: [2, 2],
                pointRadius: 0,
              },
            ]
          : []),
      ],
    };
  };

  const getPriceKey = (asset: string) => {
    const mapping: Record<string, string> = {
      gold: "Gold_Price",
      silver: "Silver_Price",
      bitcoin: "BTC_Price",
      ethereum: "ETH_Price",
      try_usd: "TRY_USD",
      egp_usd: "EGP_USD",
    };
    return mapping[asset] || "Gold_Price";
  };

  const chartData = prepareChartData();

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top" as const,
        rtl: true,
        labels: {
          font: { family: "Outfit" },
        },
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
        rtl: true,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: "oklch(0.9 0.02 80 / 50%)",
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  const exportPredictions = () => {
    if (!predictionsData?.predictions) {return;}

    const csv = [
      ["اليوم", "السعر المتوقع", "الحد الأعلى", "الحد الأدنى"],
      ...predictionsData.predictions.map((price: number, index: number) => [
        index + 1,
        price.toFixed(2),
        (price * 1.05).toFixed(2),
        (price * 0.95).toFixed(2),
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `predictions_${selectedAsset}_${predictionDays}days.csv`;
    a.click();
  };

  // Calculate stats
  const currentPrice = predictionsData?.predictions?.[0];
  const finalPrice = predictionsData?.predictions?.[predictionsData.predictions.length - 1];
  const priceChange = currentPrice && finalPrice ? ((finalPrice - currentPrice) / currentPrice) * 100 : 0;
  const selectedModelData = MODELS.find((m) => m.value === selectedModel);

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  التوقعات الذكية
                </h1>
                <p className="text-sm text-muted-foreground">
                  توقعات مدعومة بالذكاء الاصطناعي
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {predictionsData && (
                <Button variant="outline" size="sm" onClick={exportPredictions}>
                  <Download className="ml-2 h-4 w-4" />
                  تصدير CSV
                </Button>
              )}
              <Link href="/predictions/three-level">
                <Button variant="outline" size="sm">
                  توقعات متقدمة
                  <ChevronRight className="mr-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Controls Panel */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            className="lg:col-span-1 space-y-6"
          >
            {/* Prediction Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  إعدادات التوقع
                </CardTitle>
                <CardDescription>
                  حدد معايير التوقع المطلوبة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Asset Selection */}
                <div className="space-y-2">
                  <Label>اختر الأصل</Label>
                  <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                    <SelectTrigger data-testid="predictions-asset-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ASSETS.map((asset) => (
                        <SelectItem key={asset.value} value={asset.value}>
                          <span className="flex items-center gap-2">
                            <span>{asset.icon}</span>
                            {asset.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Model Selection */}
                <div className="space-y-2">
                  <Label>النموذج</Label>
                  <Select value={selectedModel} onValueChange={setSelectedModel}>
                    <SelectTrigger data-testid="predictions-model-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MODELS.map((model) => (
                        <SelectItem key={model.value} value={model.value}>
                          <span className="flex items-center justify-between w-full">
                            {model.label}
                            <Badge variant="secondary" className="mr-2">
                              {model.accuracy}%
                            </Badge>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Days Selection */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>فترة التوقع</Label>
                    <span className="text-sm font-medium text-primary">{predictionDays} يوم</span>
                  </div>
                  <Slider
                    value={[predictionDays]}
                    onValueChange={(value) => setPredictionDays(value[0])}
                    min={7}
                    max={90}
                    step={1}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>7 أيام</span>
                    <span>30 يوم (موصى)</span>
                    <span>90 يوم</span>
                  </div>
                </div>

                {/* Confidence Interval Toggle */}
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <Label>نطاق الثقة</Label>
                    <p className="text-xs text-muted-foreground">إظهار الحدود العليا والدنيا</p>
                  </div>
                  <Switch
                    checked={showConfidenceInterval}
                    onCheckedChange={setShowConfidenceInterval}
                  />
                </div>

                {/* Generate Button */}
                <Button
                  data-testid="generate-predictions-button"
                  onClick={handleGeneratePredictions}
                  disabled={predictionsLoading}
                  className="w-full glow-gold"
                  size="lg"
                >
                  {predictionsLoading ? (
                    <>
                      <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                      جاري التوقع...
                    </>
                  ) : (
                    <>
                      <Sparkles className="ml-2 h-4 w-4" />
                      توليد التوقعات
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Model Info */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Info className="h-4 w-4 text-primary" />
                  معلومات النموذج
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">النموذج</span>
                  <span className="font-medium">{selectedModelData?.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الدقة</span>
                  <span className="font-medium text-primary">{selectedModelData?.accuracy}%</span>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>مستوى الثقة</span>
                    <span>{selectedModelData?.accuracy}%</span>
                  </div>
                  <Progress value={selectedModelData?.accuracy} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Chart and Results */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Statistics Cards */}
            {predictionsData && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard
                  icon={Calendar}
                  label="السعر الحالي"
                  value={`$${currentPrice?.toFixed(2) || "---"}`}
                  color="primary"
                />
                <StatCard
                  icon={Target}
                  label={`التوقع (${predictionDays} يوم)`}
                  value={`$${finalPrice?.toFixed(2) || "---"}`}
                  color="success"
                />
                <StatCard
                  icon={priceChange >= 0 ? TrendingUp : TrendingDown}
                  label="التغيير المتوقع"
                  value={`${priceChange >= 0 ? "+" : ""}${priceChange.toFixed(2)}%`}
                  trend={priceChange >= 0 ? "up" : "down"}
                  color={priceChange >= 0 ? "success" : "danger"}
                />
                <StatCard
                  icon={Activity}
                  label="الثقة"
                  value={`${selectedModelData?.accuracy}%`}
                  color="primary"
                />
              </div>
            )}

            {/* Chart */}
            <Card className="overflow-hidden">
              {/* Gold accent line */}
              <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <LineChart className="h-5 w-5 text-primary" />
                      رسم التوقعات
                    </CardTitle>
                    <CardDescription>
                      {ASSETS.find((a) => a.value === selectedAsset)?.label} - {predictionDays} يوم
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="text-primary border-primary">
                    <Zap className="ml-1 h-3 w-3" />
                    {selectedModelData?.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {chartData ? (
                  <div className="h-[400px]">
                    <Line data={chartData} options={chartOptions} />
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center border-2 border-dashed rounded-lg">
                    <div className="text-center">
                      <Brain className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                      <p className="text-muted-foreground mb-2">لا توجد توقعات بعد</p>
                      <p className="text-sm text-muted-foreground">
                        اختر الإعدادات ثم اضغط "توليد التوقعات"
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Prediction Details */}
            {predictionsData && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    تفاصيل التوقعات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="summary">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="summary">ملخص</TabsTrigger>
                      <TabsTrigger value="details">التفاصيل</TabsTrigger>
                    </TabsList>
                    <TabsContent value="summary" className="space-y-4 mt-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="p-4 rounded-lg bg-muted/50">
                          <p className="text-sm text-muted-foreground">أقل سعر متوقع</p>
                          <p className="text-2xl font-bold">
                            ${Math.min(...predictionsData.predictions).toFixed(2)}
                          </p>
                        </div>
                        <div className="p-4 rounded-lg bg-muted/50">
                          <p className="text-sm text-muted-foreground">أعلى سعر متوقع</p>
                          <p className="text-2xl font-bold">
                            ${Math.max(...predictionsData.predictions).toFixed(2)}
                          </p>
                        </div>
                        <div className="p-4 rounded-lg bg-muted/50">
                          <p className="text-sm text-muted-foreground">متوسط السعر</p>
                          <p className="text-2xl font-bold">
                            ${(
                              predictionsData.predictions.reduce((a: number, b: number) => a + b, 0) /
                              predictionsData.predictions.length
                            ).toFixed(2)}
                          </p>
                        </div>
                        <div className="p-4 rounded-lg bg-muted/50">
                          <p className="text-sm text-muted-foreground">التقلب المتوقع</p>
                          <p className="text-2xl font-bold">
                            {(
                              ((Math.max(...predictionsData.predictions) -
                                Math.min(...predictionsData.predictions)) /
                                Math.min(...predictionsData.predictions)) *
                              100
                            ).toFixed(2)}%
                          </p>
                        </div>
                      </div>
                    </TabsContent>
                    <TabsContent value="details" className="mt-4">
                      <div className="max-h-[200px] overflow-auto rounded-lg border">
                        <table className="w-full text-sm">
                          <thead className="bg-muted sticky top-0">
                            <tr>
                              <th className="p-2 text-right">اليوم</th>
                              <th className="p-2 text-right">السعر المتوقع</th>
                              <th className="p-2 text-right">الحد الأعلى</th>
                              <th className="p-2 text-right">الحد الأدنى</th>
                            </tr>
                          </thead>
                          <tbody>
                            {predictionsData.predictions.map((price: number, index: number) => (
                              <tr key={index} className="border-t">
                                <td className="p-2">{index + 1}</td>
                                <td className="p-2 font-medium">${price.toFixed(2)}</td>
                                <td className="p-2 text-emerald-600">${(price * 1.05).toFixed(2)}</td>
                                <td className="p-2 text-red-600">${(price * 0.95).toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
