/**
 * Investment Page - Premium Gold Price Predictor
 * AI-powered investment recommendations dashboard
 */

import { useState } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Target,
  Shield,
  Zap,
  ArrowLeft,
  Sparkles,
  BarChart3,
  PieChart,
  Info,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

interface Investment {
  asset: string;
  action: "buy" | "sell" | "hold";
  confidence: number;
  expectedReturn: number;
  risk: "low" | "medium" | "high";
  timeframe: string;
  reasoning: string;
  currentPrice: number;
  targetPrice: number;
}

const RISK_PROFILES = [
  { value: "conservative", label: "Conservative (محافظ)" },
  { value: "moderate", label: "Moderate (معتدل)" },
  { value: "aggressive", label: "Aggressive (جريء)" },
];

const TIMEFRAMES = [
  { value: "short", label: "Short-term (1-7 days)" },
  { value: "medium", label: "Medium-term (1-4 weeks)" },
  { value: "long", label: "Long-term (1-6 months)" },
];

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "",
  color = "primary",
  trend,
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  trend?: "up" | "down";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">
                  {value}
                  {suffix && <span className="text-sm font-normal text-muted-foreground">{suffix}</span>}
                </p>
              </div>
            </div>
            {trend && (
              <div className={`p-1.5 rounded-lg ${trend === "up" ? "bg-emerald-100 dark:bg-emerald-900/30" : "bg-red-100 dark:bg-red-900/30"}`}>
                {trend === "up" ? (
                  <ArrowUpRight className="h-4 w-4 text-emerald-600" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 text-red-600" />
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Investment() {
  const [, navigate] = useLocation();
  const [riskProfile, setRiskProfile] = useState("moderate");
  const [timeframe, setTimeframe] = useState("medium");
  const [investmentAmount, setInvestmentAmount] = useState(10000);

  // Mock investment recommendations
  const recommendations: Investment[] = [
    {
      asset: "Gold",
      action: "buy",
      confidence: 92,
      expectedReturn: 8.5,
      risk: "low",
      timeframe: "2-4 weeks",
      reasoning:
        "Strong upward trend with high inflation expectations. Technical indicators show bullish momentum.",
      currentPrice: 2050,
      targetPrice: 2224,
    },
    {
      asset: "Bitcoin",
      action: "hold",
      confidence: 78,
      expectedReturn: 5.2,
      risk: "high",
      timeframe: "1-2 weeks",
      reasoning:
        "Consolidation phase after recent rally. Wait for breakout above $45,000 resistance.",
      currentPrice: 43250,
      targetPrice: 45500,
    },
    {
      asset: "Ethereum",
      action: "buy",
      confidence: 85,
      expectedReturn: 12.3,
      risk: "medium",
      timeframe: "3-6 weeks",
      reasoning:
        "Upcoming network upgrade and increasing DeFi adoption. Strong fundamentals support price growth.",
      currentPrice: 2280,
      targetPrice: 2560,
    },
    {
      asset: "Silver",
      action: "sell",
      confidence: 70,
      expectedReturn: -3.2,
      risk: "medium",
      timeframe: "1-2 weeks",
      reasoning:
        "Overbought conditions and weakening industrial demand. Consider taking profits.",
      currentPrice: 24.85,
      targetPrice: 24.05,
    },
  ];

  const getActionIcon = (action: string) => {
    switch (action) {
      case "buy":
        return <TrendingUp className="h-4 w-4" />;
      case "sell":
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <CheckCircle2 className="h-4 w-4" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case "buy":
        return "bg-emerald-500 text-white";
      case "sell":
        return "bg-red-500 text-white";
      default:
        return "bg-blue-500 text-white";
    }
  };

  const getActionText = (action: string) => {
    switch (action) {
      case "buy":
        return "شراء";
      case "sell":
        return "بيع";
      default:
        return "احتفظ";
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case "low":
        return <Shield className="h-4 w-4" />;
      case "medium":
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Zap className="h-4 w-4" />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "bg-emerald-500 text-white";
      case "medium":
        return "bg-amber-500 text-white";
      default:
        return "bg-red-500 text-white";
    }
  };

  const getRiskText = (risk: string) => {
    switch (risk) {
      case "low":
        return "منخفض";
      case "medium":
        return "متوسط";
      default:
        return "عالي";
    }
  };

  const calculatePortfolio = () => {
    const buyRecommendations = recommendations.filter((r) => r.action === "buy");
    const totalConfidence = buyRecommendations.reduce(
      (sum, r) => sum + r.confidence,
      0
    );

    return buyRecommendations.map((rec) => {
      const allocation = (rec.confidence / totalConfidence) * investmentAmount;
      const shares = allocation / rec.currentPrice;
      const potentialProfit = (allocation * rec.expectedReturn) / 100;

      return {
        ...rec,
        allocation,
        shares,
        potentialProfit,
      };
    });
  };

  const portfolio = calculatePortfolio();
  const totalExpectedReturn = portfolio.reduce(
    (sum, p) => sum + p.potentialProfit,
    0
  );

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  توصيات الاستثمار
                </h1>
                <p className="text-sm text-muted-foreground">
                  اقتراحات استثمارية مدعومة بالذكاء الاصطناعي بناءً على تحليل السوق
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Configuration */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                ملف الاستثمار
              </CardTitle>
              <CardDescription>قم بتكوين تفضيلات الاستثمار الخاصة بك</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">ملف المخاطر</label>
                  <Select value={riskProfile} onValueChange={setRiskProfile}>
                    <SelectTrigger data-testid="risk-profile-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {RISK_PROFILES.map((profile) => (
                        <SelectItem key={profile.value} value={profile.value}>
                          {profile.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">الإطار الزمني للاستثمار</label>
                  <Select value={timeframe} onValueChange={setTimeframe}>
                    <SelectTrigger data-testid="investment-timeframe-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TIMEFRAMES.map((tf) => (
                        <SelectItem key={tf.value} value={tf.value}>
                          {tf.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  مبلغ الاستثمار: ${investmentAmount.toLocaleString()}
                </label>
                <Slider
                  value={[investmentAmount]}
                  onValueChange={(value) => setInvestmentAmount(value[0])}
                  min={1000}
                  max={100000}
                  step={1000}
                />
                <p className="text-xs text-muted-foreground">
                  $1,000 إلى $100,000
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Portfolio Summary */}
        <div className="grid gap-4 md:grid-cols-4 mb-8">
          <StatCard
            icon={DollarSign}
            label="إجمالي الاستثمار"
            value={`$${investmentAmount.toLocaleString()}`}
            color="primary"
            delay={0.1}
          />
          <StatCard
            icon={TrendingUp}
            label="العائد المتوقع"
            value={`$${totalExpectedReturn.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}`}
            color="success"
            trend="up"
            delay={0.2}
          />
          <StatCard
            icon={Target}
            label="الأصول للشراء"
            value={recommendations.filter((r) => r.action === "buy").length}
            color="primary"
            delay={0.3}
          />
          <StatCard
            icon={CheckCircle2}
            label="متوسط الثقة"
            value={`${(
              recommendations.reduce((sum, r) => sum + r.confidence, 0) /
              recommendations.length
            ).toFixed(0)}%`}
            color="success"
            delay={0.4}
          />
        </div>

        {/* Recommendations */}
        <div className="space-y-4 mb-8">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            التوصيات
          </h2>
          {recommendations.map((rec, index) => (
            <motion.div
              key={rec.asset}
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 * index }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-xl flex items-center gap-2">
                        {rec.asset}
                        <Badge className={getActionColor(rec.action)}>
                          {getActionIcon(rec.action)}
                          <span className="mr-1">{getActionText(rec.action)}</span>
                        </Badge>
                      </CardTitle>
                      <CardDescription>{rec.reasoning}</CardDescription>
                    </div>
                    <Badge className={getRiskColor(rec.risk)}>
                      {getRiskIcon(rec.risk)}
                      <span className="mr-1">مخاطر {getRiskText(rec.risk)}</span>
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-5">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">السعر الحالي</p>
                      <p className="text-lg font-bold">
                        ${rec.currentPrice.toLocaleString()}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">السعر المستهدف</p>
                      <p className="text-lg font-bold">
                        ${rec.targetPrice.toLocaleString()}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">العائد المتوقع</p>
                      <p
                        className={`text-lg font-bold ${
                          rec.expectedReturn >= 0 ? "text-emerald-600" : "text-red-600"
                        }`}
                      >
                        {rec.expectedReturn >= 0 ? "+" : ""}
                        {rec.expectedReturn.toFixed(1)}%
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">الثقة</p>
                      <div className="space-y-1">
                        <p className="text-lg font-bold">{rec.confidence}%</p>
                        <Progress value={rec.confidence} className="h-1.5" />
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">الإطار الزمني</p>
                      <p className="text-lg font-bold">{rec.timeframe}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Suggested Portfolio */}
        {portfolio.length > 0 && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
            className="mb-8"
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-primary" />
                  توزيع المحفظة المقترح
                </CardTitle>
                <CardDescription>
                  بناءً على استثمارك البالغ ${investmentAmount.toLocaleString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {portfolio.map((item) => (
                    <div key={item.asset} className="space-y-3 p-4 rounded-lg bg-muted/50">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-lg">{item.asset}</span>
                        <Badge variant="outline" className="text-sm">
                          {((item.allocation / investmentAmount) * 100).toFixed(1)}%
                        </Badge>
                      </div>
                      <div className="grid gap-3 md:grid-cols-4 text-sm">
                        <div className="p-2 rounded bg-background">
                          <span className="text-muted-foreground">المبلغ: </span>
                          <span className="font-bold">
                            ${item.allocation.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                        <div className="p-2 rounded bg-background">
                          <span className="text-muted-foreground">الأسهم: </span>
                          <span className="font-bold">
                            {item.shares.toFixed(4)}
                          </span>
                        </div>
                        <div className="p-2 rounded bg-background">
                          <span className="text-muted-foreground">الربح المحتمل: </span>
                          <span className="font-bold text-emerald-600">
                            +${item.potentialProfit.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                        <div className="p-2 rounded bg-background">
                          <span className="text-muted-foreground">الثقة: </span>
                          <span className="font-bold">{item.confidence}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Disclaimer */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.6 }}
        >
          <Card className="border-amber-500 bg-amber-50/50 dark:bg-amber-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-500">
                <AlertTriangle className="h-5 w-5" />
                إخلاء المسؤولية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                يتم إنشاء هذه التوصيات بواسطة نماذج الذكاء الاصطناعي ولا ينبغي اعتبارها
                نصيحة مالية. قم دائمًا بإجراء بحثك الخاص واستشر مستشارًا ماليًا مؤهلاً
                قبل اتخاذ قرارات الاستثمار. الأداء السابق لا يضمن النتائج المستقبلية.
                الاستثمار ينطوي على مخاطر، بما في ذلك احتمال فقدان رأس المال.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
