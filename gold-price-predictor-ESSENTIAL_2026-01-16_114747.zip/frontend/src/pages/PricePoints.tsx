/**
 * Price Points Page - Premium Gold Price Predictor
 * Modern breakout and inflection points detection
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  RefreshCw,
  Zap,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  ArrowLeft,
  Sparkles,
  Gauge,
  Shield,
  AlertTriangle,
  TrendingUp as TrendingUpIcon,
  Clock,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Breakout Point Card
function BreakoutPointCard({ point, index }: { point: any; index: number }) {
  const isUp = point.direction === "up";
  const isBreached = point.breached;

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay: index * 0.05 }}
    >
      <Card className={`stat-card hover:shadow-md transition-all ${
        isBreached ? "border-2 border-red-500" : ""
      }`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-xl ${
                isUp
                  ? "bg-emerald-100 dark:bg-emerald-900/30"
                  : "bg-red-100 dark:bg-red-900/30"
              }`}>
                {isUp ? (
                  <TrendingUp className="h-6 w-6 text-emerald-600" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-red-600" />
                )}
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">
                  مستوى {point.type === "resistance" ? "المقاومة" : "الدعم"}
                </p>
                <p className="text-3xl font-bold mb-2">
                  ${point.price?.toFixed(2) || "N/A"}
                </p>
                <div className="flex items-center gap-2">
                  <Gauge className="h-3 w-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">
                    القوة: {(point.strength * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="mt-2">
                  <Progress value={point.strength * 100} className="h-2" />
                </div>
              </div>
            </div>
            <div className="text-left">
              <Badge
                variant={isBreached ? "destructive" : "default"}
                className="mb-2"
              >
                {isBreached ? "تم الاختراق" : "نشط"}
              </Badge>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>
                  {formatDistanceToNow(new Date(point.createdAt), {
                    addSuffix: true,
                    locale: ar,
                  })}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Inflection Point Card
function InflectionPointCard({ point, index }: { point: any; index: number }) {
  const getPointConfig = (type: string) => {
    switch (type) {
      case "peak":
        return {
          icon: ArrowUp,
          color: "bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-900/30 dark:text-emerald-400",
          label: "قمة",
        };
      case "trough":
        return {
          icon: ArrowDown,
          color: "bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-400",
          label: "قاع",
        };
      case "reversal_up":
        return {
          icon: RotateCcw,
          color: "bg-blue-100 text-blue-700 border-blue-300 dark:bg-blue-900/30 dark:text-blue-400",
          label: "انعكاس صعودي",
        };
      case "reversal_down":
        return {
          icon: RotateCcw,
          color: "bg-orange-100 text-orange-700 border-orange-300 dark:bg-orange-900/30 dark:text-orange-400",
          label: "انعكاس هبوطي",
        };
      default:
        return {
          icon: Activity,
          color: "bg-gray-100 text-gray-700 border-gray-300",
          label: type,
        };
    }
  };

  const config = getPointConfig(point.pointType);
  const Icon = config.icon;

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay: index * 0.05 }}
    >
      <Card className="stat-card hover:shadow-md transition-all">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-xl ${config.color.split(" ")[0]}`}>
                <Icon className="h-5 w-5" />
              </div>
              <Badge className={config.color} variant="outline">
                {config.label}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatDistanceToNow(
                new Date(point.detectedAt || point.createdAt),
                { addSuffix: true, locale: ar }
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="p-3 rounded-lg bg-muted/50 text-center">
              <p className="text-xs text-muted-foreground mb-1">السعر</p>
              <p className="text-2xl font-bold">
                ${point.price?.toFixed(2) || "N/A"}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50 text-center">
              <p className="text-xs text-muted-foreground mb-1">الثقة</p>
              <p className="text-2xl font-bold">
                {(point.confidence * 100).toFixed(0)}%
              </p>
            </div>
          </div>

          {point.significance && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">الأهمية</span>
                <span className="font-medium">
                  {(point.significance * 100).toFixed(0)}%
                </span>
              </div>
              <Progress value={point.significance * 100} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function PricePoints() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState<number | undefined>();
  const utils = trpc.useUtils();

  // Fetch assets
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch breakout points
  const {
    data: breakoutPoints,
    isLoading: loadingBreakout,
    refetch: refetchBreakout,
  } = trpc.breakoutPoints.list.useQuery(
    { assetId: selectedAsset },
    { enabled: !!selectedAsset }
  );

  // Fetch inflection points
  const {
    data: inflectionPoints,
    isLoading: loadingInflection,
    refetch: refetchInflection,
  } = trpc.inflectionPoints.list.useQuery(
    { assetId: selectedAsset },
    { enabled: !!selectedAsset }
  );

  // Calculate mutations
  const calculateBreakoutMutation = trpc.breakoutPoints.calculate.useMutation({
    onSuccess: () => {
      utils.breakoutPoints.list.invalidate({ assetId: selectedAsset });
      toast.success("تم حساب نقاط الاختراق بنجاح");
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في حساب نقاط الاختراق");
    },
  });

  const calculateInflectionMutation =
    trpc.inflectionPoints.calculate.useMutation({
      onSuccess: () => {
        utils.inflectionPoints.list.invalidate({ assetId: selectedAsset });
        toast.success("تم حساب نقاط الانعطاف بنجاح");
      },
      onError: (error: any) => {
        toast.error(error.message || "فشل في حساب نقاط الانعطاف");
      },
    });

  const getAssetName = (assetId: number) => {
    const asset = (assets as any[]).find((a: any) => a.id === assetId);
    return asset ? `${asset.name} (${asset.symbol})` : `Asset #${assetId}`;
  };

  const breakoutCount = (breakoutPoints as any[])?.length || 0;
  const inflectionCount = (inflectionPoints as any[])?.length || 0;
  const breachedCount = (breakoutPoints as any[])?.filter((p: any) => p.breached).length || 0;

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  نقاط السعر الحرجة
                </h1>
                <p className="text-sm text-muted-foreground">
                  كشف نقاط الاختراق ونقاط الانعطاف للأصول
                </p>
              </div>
            </div>
            <Select
              value={selectedAsset?.toString() || ""}
              onValueChange={(v) => setSelectedAsset(parseInt(v))}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="اختر الأصل" />
              </SelectTrigger>
              <SelectContent>
                {(assets as any[]).map((asset: any) => (
                  <SelectItem key={asset.id} value={asset.id.toString()}>
                    {asset.name} ({asset.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {!selectedAsset ? (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="premium-card">
              <CardContent className="flex flex-col items-center justify-center py-20">
                <div className="p-4 rounded-full bg-primary/10 w-fit mb-4">
                  <Target className="h-16 w-16 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">اختر أصلاً للتحليل</h2>
                <p className="text-muted-foreground text-center max-w-md">
                  اختر أصلاً من القائمة أعلاه لعرض نقاط السعر الحرجة
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <>
            {/* Quick Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              <StatCard
                icon={Zap}
                label="نقاط الاختراق"
                value={breakoutCount}
                color="warning"
                delay={0}
              />
              <StatCard
                icon={RotateCcw}
                label="نقاط الانعطاف"
                value={inflectionCount}
                color="primary"
                delay={0.1}
              />
              <StatCard
                icon={AlertTriangle}
                label="تم الاختراق"
                value={breachedCount}
                color="danger"
                delay={0.2}
              />
              <StatCard
                icon={Shield}
                label="نشطة"
                value={breakoutCount - breachedCount}
                color="success"
                delay={0.3}
              />
            </div>

            <Tabs defaultValue="breakout" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md">
                <TabsTrigger value="breakout" className="gap-2">
                  <Zap className="h-4 w-4" />
                  نقاط الاختراق ({breakoutCount})
                </TabsTrigger>
                <TabsTrigger value="inflection" className="gap-2">
                  <RotateCcw className="h-4 w-4" />
                  نقاط الانعطاف ({inflectionCount})
                </TabsTrigger>
              </TabsList>

              {/* Breakout Points Tab */}
              <TabsContent value="breakout">
                <Card className="premium-card">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Zap className="h-5 w-5 text-primary" />
                          نقاط الاختراق
                        </CardTitle>
                        <CardDescription>
                          مستويات الدعم والمقاومة المحتمل اختراقها
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => refetchBreakout()}
                          disabled={loadingBreakout}
                        >
                          <RefreshCw
                            className={`ml-2 h-4 w-4 ${loadingBreakout ? "animate-spin" : ""}`}
                          />
                          تحديث
                        </Button>
                        <Button
                          size="sm"
                          onClick={() =>
                            selectedAsset &&
                            calculateBreakoutMutation.mutate({ assetId: selectedAsset })
                          }
                          disabled={calculateBreakoutMutation.isPending}
                        >
                          {calculateBreakoutMutation.isPending ? (
                            <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Zap className="ml-2 h-4 w-4" />
                          )}
                          حساب جديد
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {loadingBreakout ? (
                      <div className="flex items-center justify-center py-16">
                        <div className="text-center">
                          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                          <p className="mt-4 text-muted-foreground">جاري تحميل نقاط الاختراق...</p>
                        </div>
                      </div>
                    ) : ((breakoutPoints as any[]) || []).length > 0 ? (
                      <ScrollArea className="h-[500px] pr-4">
                        <div className="space-y-4">
                          {(breakoutPoints as any[]).map((point: any, index: number) => (
                            <BreakoutPointCard key={point.id} point={point} index={index} />
                          ))}
                        </div>
                      </ScrollArea>
                    ) : (
                      <div className="text-center py-16">
                        <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                          <Zap className="h-12 w-12 text-primary" />
                        </div>
                        <h3 className="text-xl font-semibold mb-2">لا توجد نقاط اختراق</h3>
                        <p className="text-muted-foreground mb-6">
                          اضغط على "حساب جديد" لحساب نقاط الاختراق
                        </p>
                        <Button
                          onClick={() =>
                            selectedAsset &&
                            calculateBreakoutMutation.mutate({ assetId: selectedAsset })
                          }
                          disabled={calculateBreakoutMutation.isPending}
                        >
                          {calculateBreakoutMutation.isPending ? (
                            <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Zap className="ml-2 h-4 w-4" />
                          )}
                          حساب نقاط الاختراق
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Inflection Points Tab */}
              <TabsContent value="inflection">
                <Card className="premium-card">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <RotateCcw className="h-5 w-5 text-primary" />
                          نقاط الانعطاف
                        </CardTitle>
                        <CardDescription>
                          نقاط تغير اتجاه السعر (قمم، قيعان، انعكاسات)
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => refetchInflection()}
                          disabled={loadingInflection}
                        >
                          <RefreshCw
                            className={`ml-2 h-4 w-4 ${loadingInflection ? "animate-spin" : ""}`}
                          />
                          تحديث
                        </Button>
                        <Button
                          size="sm"
                          onClick={() =>
                            selectedAsset &&
                            calculateInflectionMutation.mutate({ assetId: selectedAsset })
                          }
                          disabled={calculateInflectionMutation.isPending}
                        >
                          {calculateInflectionMutation.isPending ? (
                            <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                          ) : (
                            <RotateCcw className="ml-2 h-4 w-4" />
                          )}
                          حساب جديد
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {loadingInflection ? (
                      <div className="flex items-center justify-center py-16">
                        <div className="text-center">
                          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                          <p className="mt-4 text-muted-foreground">جاري تحميل نقاط الانعطاف...</p>
                        </div>
                      </div>
                    ) : ((inflectionPoints as any[]) || []).length > 0 ? (
                      <div className="grid md:grid-cols-2 gap-4">
                        {(inflectionPoints as any[]).map((point: any, index: number) => (
                          <InflectionPointCard key={point.id} point={point} index={index} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-16">
                        <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                          <RotateCcw className="h-12 w-12 text-primary" />
                        </div>
                        <h3 className="text-xl font-semibold mb-2">لا توجد نقاط انعطاف</h3>
                        <p className="text-muted-foreground mb-6">
                          اضغط على "حساب جديد" لحساب نقاط الانعطاف
                        </p>
                        <Button
                          onClick={() =>
                            selectedAsset &&
                            calculateInflectionMutation.mutate({ assetId: selectedAsset })
                          }
                          disabled={calculateInflectionMutation.isPending}
                        >
                          {calculateInflectionMutation.isPending ? (
                            <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                          ) : (
                            <RotateCcw className="ml-2 h-4 w-4" />
                          )}
                          حساب نقاط الانعطاف
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>
    </div>
  );
}
