import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function PermissionsManagement() {
  const [, navigate] = useLocation();
  const params = useParams();
  const userId = params.userId as string;

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newPermission, setNewPermission] = useState({
    resource: "",
    action: "",
  });

  const {
    data: permissions,
    isLoading,
    refetch,
  } = trpc.permissions.getUserPermissions.useQuery(
    { userId },
    { enabled: !!userId }
  );

  const createPermissionMutation = trpc.permissions.create.useMutation({
    onSuccess: () => {
      toast.success("Permission added successfully!");
      setIsAddDialogOpen(false);
      setNewPermission({ resource: "", action: "" });
      refetch();
    },
    onError: error => {
      toast.error(`Failed to add permission: ${error.message}`);
    },
  });

  const revokePermissionMutation = trpc.permissions.revoke.useMutation({
    onSuccess: () => {
      toast.success("Permission revoked successfully!");
      refetch();
    },
    onError: error => {
      toast.error(`Failed to revoke permission: ${error.message}`);
    },
  });

  const handleAddPermission = () => {
    if (!newPermission.resource || !newPermission.action) {
      toast.error("Please fill in all fields");
      return;
    }

    createPermissionMutation.mutate({
      userId,
      resource: newPermission.resource,
      action: newPermission.action,
    });
  };

  const handleRevokePermission = (permission: string) => {
    if (confirm("Are you sure you want to revoke this permission?")) {
      revokePermissionMutation.mutate({ userId, permission });
    }
  };

  if (isLoading) {
    return <div className="container mx-auto py-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto py-8">
      <Button
        variant="ghost"
        onClick={() => navigate("/admin/users")}
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Users
      </Button>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Manage Permissions</CardTitle>
              <CardDescription>User ID: {userId}</CardDescription>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Permission
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Permission</DialogTitle>
                  <DialogDescription>
                    Grant a new permission to this user
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="resource">Resource</Label>
                    <Input
                      id="resource"
                      value={newPermission.resource}
                      onChange={e =>
                        setNewPermission({
                          ...newPermission,
                          resource: e.target.value,
                        })
                      }
                      placeholder="e.g., assets, predictions, alerts"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="action">Action</Label>
                    <Input
                      id="action"
                      value={newPermission.action}
                      onChange={e =>
                        setNewPermission({
                          ...newPermission,
                          action: e.target.value,
                        })
                      }
                      placeholder="e.g., create, read, update, delete"
                    />
                  </div>
                  <Button
                    onClick={handleAddPermission}
                    disabled={createPermissionMutation.isPending}
                    className="w-full"
                  >
                    {createPermissionMutation.isPending
                      ? "Adding..."
                      : "Add Permission"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {!permissions || permissions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No permissions found for this user
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Granted</TableHead>
                  <TableHead>Created At</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {permissions.map((permission: any) => (
                  <TableRow key={permission.id}>
                    <TableCell className="font-medium">
                      {permission.resource}
                    </TableCell>
                    <TableCell>{permission.action}</TableCell>
                    <TableCell>
                      <span
                        className={
                          permission.granted ? "text-green-600" : "text-red-600"
                        }
                      >
                        {permission.granted ? "Yes" : "No"}
                      </span>
                    </TableCell>
                    <TableCell>
                      {new Date(permission.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() =>
                          handleRevokePermission(permission.permission)
                        }
                        disabled={revokePermissionMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
