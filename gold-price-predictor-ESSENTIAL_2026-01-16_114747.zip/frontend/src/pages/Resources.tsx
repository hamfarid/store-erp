/**
 * Resources Page - Premium Gold Price Predictor
 * Real-time system resource monitoring with modern UI
 */

import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  Cpu,
  HardDrive,
  MemoryStick,
  Activity,
  Server,
  Database,
  ArrowLeft,
  Sparkles,
  Gauge,
  Wifi,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Zap,
} from "lucide-react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

interface ResourceMetrics {
  cpu: number;
  memory: number;
  disk: number;
  network: {
    upload: number;
    download: number;
  };
}

// Resource Card Component
function ResourceCard({
  icon: Icon,
  label,
  value,
  unit = "%",
  status,
  details,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: number;
  unit?: string;
  status?: string;
  details?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  const statusColors: Record<string, string> = {
    Good: "bg-emerald-500",
    Moderate: "bg-amber-500",
    High: "bg-red-500",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            {label}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold mb-3">
            {value.toFixed(1)}
            <span className="text-lg text-muted-foreground">{unit}</span>
          </div>
          <Progress value={value} className="h-2 mb-3" />
          {status && (
            <div className="flex items-center justify-between">
              <Badge
                className={`${statusColors[status] || "bg-gray-500"} text-white`}
              >
                {status}
              </Badge>
              {details && (
                <span className="text-xs text-muted-foreground">{details}</span>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Resources() {
  const [, navigate] = useLocation();
  const [metrics, setMetrics] = useState<ResourceMetrics>({
    cpu: 0,
    memory: 0,
    disk: 0,
    network: { upload: 0, download: 0 },
  });

  const [history, setHistory] = useState<ResourceMetrics[]>([]);

  // Simulate real-time resource monitoring
  useEffect(() => {
    const interval = setInterval(() => {
      const newMetrics: ResourceMetrics = {
        cpu: Math.random() * 40 + 30,
        memory: Math.random() * 30 + 50,
        disk: Math.random() * 10 + 60,
        network: {
          upload: Math.random() * 5 + 2,
          download: Math.random() * 10 + 5,
        },
      };

      setMetrics(newMetrics);
      setHistory((prev) => {
        const newHistory = [...prev, newMetrics];
        return newHistory.slice(-60);
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Prepare chart data
  const cpuChartData = {
    labels: history.map((_, i) => `${i}s`),
    datasets: [
      {
        label: "استخدام المعالج (%)",
        data: history.map((h) => h.cpu),
        borderColor: "oklch(0.65 0.18 70)",
        backgroundColor: "oklch(0.65 0.18 70 / 0.1)",
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const memoryChartData = {
    labels: history.map((_, i) => `${i}s`),
    datasets: [
      {
        label: "استخدام الذاكرة (%)",
        data: history.map((h) => h.memory),
        borderColor: "oklch(0.72 0.19 145)",
        backgroundColor: "oklch(0.72 0.19 145 / 0.1)",
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const networkChartData = {
    labels: history.map((_, i) => `${i}s`),
    datasets: [
      {
        label: "الرفع (MB/s)",
        data: history.map((h) => h.network.upload),
        borderColor: "oklch(0.55 0.22 25)",
        backgroundColor: "oklch(0.55 0.22 25 / 0.1)",
        fill: false,
        tension: 0.4,
      },
      {
        label: "التنزيل (MB/s)",
        data: history.map((h) => h.network.download),
        borderColor: "oklch(0.82 0.18 85)",
        backgroundColor: "oklch(0.82 0.18 85 / 0.1)",
        fill: false,
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: 0,
    },
    plugins: {
      legend: {
        display: true,
        position: "top" as const,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
      },
      x: {
        display: false,
      },
    },
  };

  const getStatusColor = (value: number) => {
    if (value < 50) {return "Good";}
    if (value < 75) {return "Moderate";}
    return "High";
  };

  const getStatusText = (value: number) => {
    if (value < 50) {return "جيد";}
    if (value < 75) {return "متوسط";}
    return "عالي";
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Activity className="h-6 w-6 text-primary" />
                  استخدام الموارد
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة موارد النظام في الوقت الفعلي
                </p>
              </div>
            </div>
            <Badge variant="outline" className="flex items-center gap-1">
              <Zap className="h-3 w-3" />
              مباشر
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Current Status */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <ResourceCard
            icon={Cpu}
            label="استخدام المعالج"
            value={metrics.cpu}
            unit="%"
            status={getStatusText(metrics.cpu)}
            color={metrics.cpu < 50 ? "success" : metrics.cpu < 75 ? "warning" : "danger"}
            delay={0}
          />
          <ResourceCard
            icon={MemoryStick}
            label="استخدام الذاكرة"
            value={metrics.memory}
            unit="%"
            status={getStatusText(metrics.memory)}
            details="6.4 GB / 8 GB"
            color={metrics.memory < 50 ? "success" : metrics.memory < 75 ? "warning" : "danger"}
            delay={0.1}
          />
          <ResourceCard
            icon={HardDrive}
            label="استخدام القرص"
            value={metrics.disk}
            unit="%"
            status={getStatusText(metrics.disk)}
            details="128 GB / 200 GB"
            color={metrics.disk < 50 ? "success" : metrics.disk < 75 ? "warning" : "danger"}
            delay={0.2}
          />
          <Card className="stat-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <div className="p-2 rounded-lg bg-primary/10 text-primary">
                  <Wifi className="h-4 w-4" />
                </div>
                الشبكة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    الرفع
                  </span>
                  <span className="font-bold text-emerald-600">
                    {metrics.network.upload.toFixed(1)} MB/s
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="h-3 w-3 rotate-180" />
                    التنزيل
                  </span>
                  <span className="font-bold text-amber-600">
                    {metrics.network.download.toFixed(1)} MB/s
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Charts */}
        <div className="grid gap-6 lg:grid-cols-2 mb-6">
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.3 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  استخدام المعالج (آخر 60 ثانية)
                </CardTitle>
                <CardDescription>استخدام المعالج في الوقت الفعلي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  {history.length > 0 && (
                    <Line data={cpuChartData} options={chartOptions} />
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.4 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MemoryStick className="h-5 w-5 text-primary" />
                  استخدام الذاكرة (آخر 60 ثانية)
                </CardTitle>
                <CardDescription>استخدام الذاكرة في الوقت الفعلي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  {history.length > 0 && (
                    <Line data={memoryChartData} options={chartOptions} />
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.5 }}
          className="mb-6"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                نشاط الشبكة (آخر 60 ثانية)
              </CardTitle>
              <CardDescription>سرعات الرفع والتنزيل</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                {history.length > 0 && (
                  <Line data={networkChartData} options={chartOptions} />
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* System Information */}
        <div className="grid gap-6 lg:grid-cols-2">
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  معلومات النظام
                </CardTitle>
                <CardDescription>تفاصيل الأجهزة والبرمجيات</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Server className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">نظام التشغيل</span>
                  </div>
                  <span className="font-semibold text-sm">Ubuntu 22.04 LTS</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Cpu className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">المعالج</span>
                  </div>
                  <span className="font-semibold text-sm">Intel Core i7-9700K</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <MemoryStick className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">الذاكرة</span>
                  </div>
                  <span className="font-semibold text-sm">8 GB DDR4</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <HardDrive className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">التخزين</span>
                  </div>
                  <span className="font-semibold text-sm">200 GB SSD</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.7 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  حالة الخدمات
                </CardTitle>
                <CardDescription>الخدمات قيد التشغيل وحالتها</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Database className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">قاعدة البيانات</span>
                  </div>
                  <Badge className="bg-emerald-500 text-white flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    يعمل
                  </Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Server className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">واجهة برمجة التطبيقات</span>
                  </div>
                  <Badge className="bg-emerald-500 text-white flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    يعمل
                  </Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Activity className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">واجهة برمجة ML</span>
                  </div>
                  <Badge className="bg-emerald-500 text-white flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    يعمل
                  </Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Server className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium">الواجهة الأمامية</span>
                  </div>
                  <Badge className="bg-emerald-500 text-white flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    يعمل
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
