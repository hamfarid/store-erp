/**
 * Expert Opinions Page - Premium Gold Price Predictor
 * Modern expert opinions and social sentiment dashboard
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Globe,
  Twitter,
  RefreshCw,
  ExternalLink,
  Users,
  MessageSquare,
  BookOpen,
  ArrowLeft,
  Sparkles,
  Brain,
  Zap,
  Target,
  Shield,
  Clock,
  ThumbsUp,
  ThumbsDown,
  AlertCircle,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Sentiment Badge Component
function SentimentBadge({ sentiment }: { sentiment: string }) {
  const configs: Record<string, { color: string; icon: any; text: string }> = {
    bullish: {
      color: "bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-900/30 dark:text-emerald-400",
      icon: TrendingUp,
      text: "صعودي",
    },
    bearish: {
      color: "bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-400",
      icon: TrendingDown,
      text: "هبوطي",
    },
    neutral: {
      color: "bg-gray-100 text-gray-700 border-gray-300 dark:bg-gray-800 dark:text-gray-400",
      icon: Minus,
      text: "محايد",
    },
  };
  const config = configs[sentiment] || configs.neutral;
  const Icon = config.icon;

  return (
    <Badge className={config.color} variant="outline">
      <Icon className="h-3 w-3 ml-1" />
      {config.text}
    </Badge>
  );
}

// Expert Opinion Card
function ExpertOpinionCard({ opinion, index }: { opinion: any; index: number }) {
  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay: index * 0.05 }}
    >
      <Card className="stat-card hover:shadow-md transition-all">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-xl ${
                opinion.sentiment === "bullish"
                  ? "bg-emerald-100 dark:bg-emerald-900/30"
                  : opinion.sentiment === "bearish"
                  ? "bg-red-100 dark:bg-red-900/30"
                  : "bg-gray-100 dark:bg-gray-800"
              }`}>
                {opinion.sentiment === "bullish" ? (
                  <TrendingUp className="h-5 w-5 text-emerald-600" />
                ) : opinion.sentiment === "bearish" ? (
                  <TrendingDown className="h-5 w-5 text-red-600" />
                ) : (
                  <Minus className="h-5 w-5 text-gray-600" />
                )}
              </div>
              <div>
                <p className="font-semibold">{opinion.expertName || "خبير"}</p>
                <p className="text-xs text-muted-foreground">{opinion.source}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <SentimentBadge sentiment={opinion.sentiment} />
              {opinion.sourceUrl && (
                <a
                  href={opinion.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="h-4 w-4" />
                </a>
              )}
            </div>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
            {opinion.opinionText}
          </p>

          <Separator className="my-4" />

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <div className="flex items-center gap-1">
              <Target className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">نقاط:</span>
              <span className="font-medium">{opinion.sentimentScore?.toFixed(2) || "N/A"}</span>
            </div>
            {opinion.confidence && (
              <div className="flex items-center gap-1">
                <Shield className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">ثقة:</span>
                <span className="font-medium">{(opinion.confidence * 100).toFixed(0)}%</span>
              </div>
            )}
            {opinion.targetPrice && (
              <Badge variant="outline" className="text-primary border-primary">
                السعر المستهدف: ${opinion.targetPrice}
              </Badge>
            )}
            {opinion.timeframe && (
              <Badge variant="outline">
                {opinion.timeframe === "short"
                  ? "قصير المدى"
                  : opinion.timeframe === "medium"
                  ? "متوسط المدى"
                  : "طويل المدى"}
              </Badge>
            )}
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-3 w-3" />
              {formatDistanceToNow(new Date(opinion.scrapedAt), {
                addSuffix: true,
                locale: ar,
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Platform Sentiment Card
function PlatformSentimentCard({ platform, data }: { platform: string; data: any }) {
  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "twitter":
        return <Twitter className="h-5 w-5 text-blue-400" />;
      case "reddit":
        return <MessageSquare className="h-5 w-5 text-orange-500" />;
      default:
        return <Users className="h-5 w-5 text-green-500" />;
    }
  };

  return (
    <Card className="stat-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {getPlatformIcon(platform)}
            <span className="font-medium capitalize">{platform}</span>
          </div>
          <Badge
            variant={data.sentimentScore > 0 ? "default" : "destructive"}
          >
            {data.sentimentScore?.toFixed(2) || 0}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-center">
            <p className="text-lg font-bold text-emerald-600">
              {data.bullishCount || 0}
            </p>
            <p className="text-xs text-muted-foreground">صعودي</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800 text-center">
            <p className="text-lg font-bold">{data.neutralCount || 0}</p>
            <p className="text-xs text-muted-foreground">محايد</p>
          </div>
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 text-center">
            <p className="text-lg font-bold text-red-600">
              {data.bearishCount || 0}
            </p>
            <p className="text-xs text-muted-foreground">هبوطي</p>
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          إجمالي الإشارات: <span className="font-medium">{data.totalMentions || 0}</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ExpertOpinions() {
  const [, navigate] = useLocation();
  const [symbol, setSymbol] = useState("GC=F");
  const [url, setUrl] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState<
    "twitter" | "reddit" | "stocktwits"
  >("twitter");
  const utils = trpc.useUtils();

  // Fetch assets
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch expert opinions
  const {
    data: opinions,
    isLoading: loadingOpinions,
    refetch: refetchOpinions,
  } = trpc.expertOpinions.getOpinions.useQuery(
    { symbol, limit: 20 },
    { enabled: !!symbol }
  );

  // Fetch aggregated sentiment
  const { data: aggregated, isLoading: loadingAggregated } =
    trpc.expertOpinions.getAggregatedSentiment.useQuery(
      { symbol, days: 7 },
      { enabled: !!symbol }
    );

  // Fetch platform sentiment
  const { data: platformSentiment, refetch: refetchPlatform } =
    trpc.expertOpinions.getAggregatedPlatformSentiment.useQuery(
      { symbol, timeframe: "24h" },
      { enabled: !!symbol }
    );

  // Fetch sentiment trends
  const { data: sentimentTrends } =
    trpc.expertOpinions.getSentimentTrends.useQuery(
      { symbol, days: 30 },
      { enabled: !!symbol }
    );

  // Mutations
  const scrapeMutation = trpc.expertOpinions.scrapeAndAnalyze.useMutation({
    onSuccess: () => {
      utils.expertOpinions.getOpinions.invalidate({ symbol });
      utils.expertOpinions.getAggregatedSentiment.invalidate({ symbol });
      setUrl("");
      toast.success("تم تحليل الرابط بنجاح");
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في تحليل الرابط");
    },
  });

  const collectSocialMutation =
    trpc.expertOpinions.collectSocialSentiment.useMutation({
      onSuccess: () => {
        utils.expertOpinions.getAggregatedPlatformSentiment.invalidate({
          symbol,
        });
        toast.success("تم جمع المشاعر الاجتماعية");
      },
      onError: (error: any) => {
        toast.error(error.message || "فشل في جمع المشاعر");
      },
    });

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <BookOpen className="h-6 w-6 text-primary" />
                  آراء الخبراء والمشاعر الاجتماعية
                </h1>
                <p className="text-sm text-muted-foreground">
                  تحليل آراء الخبراء ومشاعر وسائل التواصل الاجتماعي
                </p>
              </div>
            </div>
            <Select value={symbol} onValueChange={setSymbol}>
              <SelectTrigger data-testid="expert-opinions-asset-select" className="w-[180px]">
                <SelectValue placeholder="اختر الأصل" />
              </SelectTrigger>
              <SelectContent>
                {(assets as any[]).map((asset: any) => (
                  <SelectItem key={asset.id} value={asset.symbol}>
                    {asset.name} ({asset.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Aggregated Sentiment Cards */}
        {aggregated && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            className="mb-8"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="premium-card border-2">
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground mb-3">المشاعر العامة</p>
                  <div className="flex items-center gap-3 mb-2">
                    {aggregated.overallSentiment === "bullish" ? (
                      <ThumbsUp className="h-8 w-8 text-emerald-600" />
                    ) : aggregated.overallSentiment === "bearish" ? (
                      <ThumbsDown className="h-8 w-8 text-red-600" />
                    ) : (
                      <Minus className="h-8 w-8 text-gray-600" />
                    )}
                    <span className="text-2xl font-bold">
                      {aggregated.overallSentiment === "bullish"
                        ? "صعودي"
                        : aggregated.overallSentiment === "bearish"
                        ? "هبوطي"
                        : "محايد"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    نقاط: {aggregated.averageScore?.toFixed(2) || "N/A"}
                  </p>
                </CardContent>
              </Card>

              <StatCard
                icon={TrendingUp}
                label="صعودي"
                value={`${aggregated.bullishPercentage?.toFixed(1) || 0}%`}
                color="success"
                delay={0.1}
              />
              <StatCard
                icon={TrendingDown}
                label="هبوطي"
                value={`${aggregated.bearishPercentage?.toFixed(1) || 0}%`}
                color="danger"
                delay={0.2}
              />
              <StatCard
                icon={Shield}
                label="الثقة"
                value={`${((aggregated.confidence || 0) * 100).toFixed(0)}%`}
                color="primary"
                delay={0.3}
              />
            </div>
          </motion.div>
        )}

        <Tabs defaultValue="opinions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-lg">
            <TabsTrigger value="opinions" className="gap-2">
              <BookOpen className="h-4 w-4" />
              آراء الخبراء
            </TabsTrigger>
            <TabsTrigger value="social" className="gap-2">
              <MessageSquare className="h-4 w-4" />
              المشاعر الاجتماعية
            </TabsTrigger>
            <TabsTrigger value="scrape" className="gap-2">
              <Globe className="h-4 w-4" />
              تحليل رابط
            </TabsTrigger>
          </TabsList>

          {/* Expert Opinions Tab */}
          <TabsContent value="opinions">
            <Card className="premium-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-primary" />
                      آراء الخبراء الحديثة
                    </CardTitle>
                    <CardDescription>
                      تحليلات وتوصيات من خبراء السوق
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => refetchOpinions()}
                    disabled={loadingOpinions}
                  >
                    <RefreshCw
                      className={`ml-2 h-4 w-4 ${loadingOpinions ? "animate-spin" : ""}`}
                    />
                    تحديث
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loadingOpinions ? (
                  <div className="flex items-center justify-center py-16">
                    <div className="text-center">
                      <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                      <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
                    </div>
                  </div>
                ) : ((opinions as any[]) || []).length > 0 ? (
                  <ScrollArea className="h-[500px] pr-4">
                    <div className="space-y-4">
                      {(opinions as any[]).map((opinion: any, index: number) => (
                        <ExpertOpinionCard key={opinion.id} opinion={opinion} index={index} />
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-16">
                    <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                      <BookOpen className="h-12 w-12 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">لا توجد آراء متاحة</h3>
                    <p className="text-muted-foreground mb-2">
                      استخدم تبويب "تحليل رابط" لإضافة آراء جديدة
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Social Sentiment Tab */}
          <TabsContent value="social">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <MessageSquare className="h-5 w-5 text-primary" />
                        المشاعر حسب المنصة
                      </CardTitle>
                      <CardDescription>تحليل مشاعر آخر 24 ساعة</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={selectedPlatform}
                        onValueChange={(v: any) => setSelectedPlatform(v)}
                      >
                        <SelectTrigger className="w-[130px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="twitter">Twitter</SelectItem>
                          <SelectItem value="reddit">Reddit</SelectItem>
                          <SelectItem value="stocktwits">StockTwits</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button
                        size="sm"
                        onClick={() =>
                          collectSocialMutation.mutate({
                            symbol,
                            platform: selectedPlatform,
                            timeframe: "24h",
                          })
                        }
                        disabled={collectSocialMutation.isPending}
                      >
                        {collectSocialMutation.isPending ? (
                          <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                          <RefreshCw className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {platformSentiment?.platformBreakdown ? (
                    <div className="space-y-4">
                      {Object.entries(platformSentiment.platformBreakdown).map(
                        ([platform, data]: [string, any], index: number) => (
                          <motion.div
                            key={platform}
                            variants={cardVariants}
                            initial="initial"
                            animate="animate"
                            transition={{ delay: index * 0.1 }}
                          >
                            <PlatformSentimentCard platform={platform} data={data} />
                          </motion.div>
                        )
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد بيانات متاحة</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Sentiment Trends */}
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    اتجاهات المشاعر
                  </CardTitle>
                  <CardDescription>تطور المشاعر خلال آخر 30 يوم</CardDescription>
                </CardHeader>
                <CardContent>
                  {((sentimentTrends as any[]) || []).length > 0 ? (
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="space-y-2">
                        {(sentimentTrends as any[])
                          .slice(0, 15)
                          .map((trend: any, index: number) => (
                            <motion.div
                              key={index}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.05 }}
                              className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                            >
                              <span className="text-sm font-medium">{trend.date}</span>
                              <div className="flex items-center gap-2">
                                {trend.sentiment === "bullish" ? (
                                  <TrendingUp className="h-4 w-4 text-emerald-600" />
                                ) : trend.sentiment === "bearish" ? (
                                  <TrendingDown className="h-4 w-4 text-red-600" />
                                ) : (
                                  <Minus className="h-4 w-4 text-gray-600" />
                                )}
                                <span className="text-sm font-bold">
                                  {trend.sentimentScore?.toFixed(2) || 0}
                                </span>
                              </div>
                            </motion.div>
                          ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-12">
                      <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد اتجاهات متاحة</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Scrape Tab */}
          <TabsContent value="scrape">
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-primary" />
                  تحليل رابط جديد
                </CardTitle>
                <CardDescription>
                  أدخل رابط مقال أو تحليل خبير لاستخراج وتحليل الرأي
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="url">رابط المقال</Label>
                  <div className="flex gap-2">
                    <Input
                      id="url"
                      placeholder="https://example.com/expert-analysis"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      dir="ltr"
                      className="flex-1"
                    />
                    <Button
                      onClick={() => scrapeMutation.mutate({ url, symbol })}
                      disabled={scrapeMutation.isPending || !url}
                    >
                      {scrapeMutation.isPending ? (
                        <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Zap className="ml-2 h-4 w-4" />
                      )}
                      تحليل
                    </Button>
                  </div>
                </div>

                <Card className="bg-muted/50">
                  <CardContent className="p-6">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <AlertCircle className="h-4 w-4" />
                      كيفية الاستخدام:
                    </h4>
                    <ul className="text-sm text-muted-foreground space-y-2 list-disc list-inside">
                      <li>أدخل رابط مقال يحتوي على رأي أو تحليل حول الأصل المحدد</li>
                      <li>سيتم استخراج النص وتحليله باستخدام الذكاء الاصطناعي</li>
                      <li>
                        سيتم تحديد المشاعر (صعودي/هبوطي/محايد) والسعر المستهدف إن وجد
                      </li>
                      <li>ستظهر النتيجة في قائمة آراء الخبراء</li>
                    </ul>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
