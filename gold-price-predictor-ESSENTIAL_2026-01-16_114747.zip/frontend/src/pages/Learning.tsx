/**
 * Learning Page - Premium Gold Price Predictor
 * Model learning and performance monitoring dashboard
 */

import { useState } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  Brain,
  TrendingUp,
  Target,
  Zap,
  RefreshCw,
  ArrowLeft,
  Sparkles,
  Gauge,
  Activity,
  BarChart3,
  Clock,
  CheckCircle2,
  Info,
  Cpu,
  Database,
} from "lucide-react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { toast } from "sonner";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const ASSETS = [
  { value: "gold", label: "Gold (الذهب)" },
  { value: "bitcoin", label: "Bitcoin (بيتكوين)" },
  { value: "ethereum", label: "Ethereum (إيثيريوم)" },
  { value: "try_usd", label: "TRY/USD (الليرة التركية)" },
  { value: "egp_usd", label: "EGP/USD (الجنيه المصري)" },
];

interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  mse: number;
  mae: number;
  r2Score: number;
}

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "",
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">
                {value}
                {suffix && <span className="text-sm font-normal text-muted-foreground">{suffix}</span>}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Metric Progress Card
function MetricProgressCard({
  label,
  value,
  max = 100,
  format = "number",
}: {
  label: string;
  value: number;
  max?: number;
  format?: "number" | "percent";
}) {
  const displayValue = format === "percent" ? `${value}%` : value.toFixed(4);
  const percentage = (value / max) * 100;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm font-bold">{displayValue}</span>
      </div>
      <Progress value={percentage} className="h-2" />
    </div>
  );
}

export default function Learning() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("gold");
  const [isTraining, setIsTraining] = useState(false);

  // Mock metrics
  const metrics: ModelMetrics = {
    accuracy: 99.2,
    precision: 98.8,
    recall: 99.1,
    f1Score: 98.9,
    mse: 0.0012,
    mae: 0.0234,
    r2Score: 0.992,
  };

  // Training history data
  const trainingHistory = {
    labels: Array.from({ length: 100 }, (_, i) => `Epoch ${i + 1}`),
    datasets: [
      {
        label: "Training Loss",
        data: Array.from({ length: 100 }, (_, i) =>
          Math.max(0.001, 0.5 * Math.exp(-i / 20) + Math.random() * 0.01)
        ),
        borderColor: "oklch(0.55 0.22 25)",
        backgroundColor: "oklch(0.55 0.22 25 / 0.1)",
        tension: 0.4,
      },
      {
        label: "Validation Loss",
        data: Array.from({ length: 100 }, (_, i) =>
          Math.max(0.001, 0.5 * Math.exp(-i / 20) + Math.random() * 0.015)
        ),
        borderColor: "oklch(0.65 0.18 70)",
        backgroundColor: "oklch(0.65 0.18 70 / 0.1)",
        tension: 0.4,
      },
    ],
  };

  const accuracyHistory = {
    labels: Array.from({ length: 100 }, (_, i) => `Epoch ${i + 1}`),
    datasets: [
      {
        label: "Training Accuracy",
        data: Array.from({ length: 100 }, (_, i) =>
          Math.min(100, 50 + 50 * (1 - Math.exp(-i / 15)) + Math.random() * 2)
        ),
        borderColor: "oklch(0.72 0.19 145)",
        backgroundColor: "oklch(0.72 0.19 145 / 0.1)",
        tension: 0.4,
      },
      {
        label: "Validation Accuracy",
        data: Array.from({ length: 100 }, (_, i) =>
          Math.min(100, 50 + 50 * (1 - Math.exp(-i / 15)) + Math.random() * 2.5)
        ),
        borderColor: "oklch(0.82 0.18 85)",
        backgroundColor: "oklch(0.82 0.18 85 / 0.1)",
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top" as const,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const handleRetrain = () => {
    setIsTraining(true);
    toast.info("بدء إعادة تدريب النموذج...");
    setTimeout(() => {
      setIsTraining(false);
      toast.success("تم إعادة تدريب النموذج بنجاح!");
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  تعلم النموذج
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة أداء النموذج وتقدم التدريب
                </p>
              </div>
            </div>
            <Button
              data-testid="retrain-model-button"
              onClick={handleRetrain}
              disabled={isTraining}
              size="sm"
            >
              {isTraining ? (
                <>
                  <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                  جاري التدريب...
                </>
              ) : (
                <>
                  <Brain className="ml-2 h-4 w-4" />
                  إعادة تدريب النموذج
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Asset Selection */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                اختيار النموذج
              </CardTitle>
              <CardDescription>اختر النموذج للمراقبة</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                <SelectTrigger data-testid="learning-asset-select" className="w-full md:w-[300px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ASSETS.map((asset) => (
                    <SelectItem key={asset.value} value={asset.value}>
                      {asset.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {/* Model Status Cards */}
        <div className="grid gap-4 md:grid-cols-4 mb-8">
          <Card className="stat-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <div className="p-2 rounded-lg bg-primary/10 text-primary">
                  <Brain className="h-4 w-4" />
                </div>
                حالة النموذج
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Badge className="bg-emerald-500 text-white mb-2 flex items-center gap-1 w-fit">
                <CheckCircle2 className="h-3 w-3" />
                نشط
              </Badge>
              <p className="text-xs text-muted-foreground">
                آخر تدريب: منذ يومين
              </p>
            </CardContent>
          </Card>

          <StatCard
            icon={Target}
            label="الدقة"
            value={metrics.accuracy}
            suffix="%"
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={TrendingUp}
            label="R² Score"
            value={metrics.r2Score.toFixed(3)}
            color="success"
            delay={0.2}
          />
          <StatCard
            icon={Zap}
            label="سرعة التدريب"
            value="سريع"
            color="primary"
            delay={0.3}
          />
        </div>

        {/* Detailed Metrics */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                مقاييس الأداء
              </CardTitle>
              <CardDescription>مقاييس تقييم النموذج التفصيلية</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <MetricProgressCard
                  label="Precision"
                  value={metrics.precision}
                  format="percent"
                />
                <MetricProgressCard
                  label="Recall"
                  value={metrics.recall}
                  format="percent"
                />
                <MetricProgressCard
                  label="F1 Score"
                  value={metrics.f1Score}
                  format="percent"
                />
                <MetricProgressCard
                  label="MSE"
                  value={metrics.mse}
                  max={1}
                />
                <MetricProgressCard
                  label="MAE"
                  value={metrics.mae}
                  max={1}
                />
                <MetricProgressCard
                  label="R² Score"
                  value={metrics.r2Score * 100}
                  format="percent"
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Training History */}
        <div className="grid gap-6 lg:grid-cols-2 mb-8">
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  تاريخ الخسارة
                </CardTitle>
                <CardDescription>
                  خسارة التدريب والتحقق عبر الحقب
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <Line data={trainingHistory} options={chartOptions} />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  تاريخ الدقة
                </CardTitle>
                <CardDescription>
                  دقة التدريب والتحقق عبر الحقب
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <Line data={accuracyHistory} options={chartOptions} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Model Information */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.7 }}
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                معلومات النموذج
              </CardTitle>
              <CardDescription>التفاصيل التقنية حول النموذج</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="architecture" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="architecture">الهندسة المعمارية</TabsTrigger>
                  <TabsTrigger value="training">التدريب</TabsTrigger>
                  <TabsTrigger value="features">الميزات</TabsTrigger>
                  <TabsTrigger value="dataset">مجموعة البيانات</TabsTrigger>
                </TabsList>

                <TabsContent value="architecture" className="mt-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Brain className="h-4 w-4 text-primary" />
                        البنية
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          النوع: LSTM (Long Short-Term Memory)
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          الطبقات: 3 طبقات LSTM + 2 طبقات Dense
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          الوحدات: 128, 64, 32
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          التفعيل: ReLU, Sigmoid
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          المحسّن: Adam
                        </li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="training" className="mt-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Zap className="h-4 w-4 text-primary" />
                        إعدادات التدريب
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          الحقب: 100
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          حجم الدفعة: 32
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          معدل التعلم: 0.001
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          دالة الخسارة: MSE
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          تقسيم التحقق: 20%
                        </li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="features" className="mt-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" />
                        الميزات
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          ميزات التأخير: 1, 2, 3, 7 أيام
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          المتوسطات المتحركة: 7, 30 يوم
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          التقلب: الانحراف المعياري المتداول 7 أيام
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          المؤشرات الاقتصادية: CPI, DXY
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          بيانات السوق: أسعار النفط والفضة
                        </li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="dataset" className="mt-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Database className="h-4 w-4 text-primary" />
                        مجموعة البيانات
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          إجمالي العينات: 2,486
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          التدريب: 1,989 (80%)
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          التحقق: 497 (20%)
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          النطاق الزمني: 2015-2025
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          الميزات: 13
                        </li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
