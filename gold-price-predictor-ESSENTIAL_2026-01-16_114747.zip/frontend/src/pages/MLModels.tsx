/**
 * ML Models Management Page - Premium Gold Price Predictor
 * View model status, health check, and make predictions
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Progress } from "../components/ui/progress";
import { Separator } from "../components/ui/separator";
import { motion } from "framer-motion";
import {
  Brain,
  Activity,
  CheckCircle,
  XCircle,
  RefreshCw,
  Play,
  Cpu,
  Database,
  TrendingUp,
  Zap,
  ArrowLeft,
  Sparkles,
  AlertTriangle,
  Info,
  BarChart3,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function MLModels() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("GC=F");
  const [predictionDays, setPredictionDays] = useState(7);
  const utils = trpc.useUtils();

  // Fetch assets using tRPC hook
  const { data: assets = [] } = trpc.assets.list.useQuery();

  // Fetch ML health check
  const {
    data: healthCheck,
    isLoading: loadingHealth,
    refetch: refetchHealth,
  } = trpc.models.healthCheck.useQuery(undefined, { refetchInterval: 30000 });

  // Fetch available models
  const {
    data: models,
    isLoading: loadingModels,
    refetch: refetchModels,
  } = trpc.models.list.useQuery();

  // Fetch model info for selected asset
  const { data: modelInfo, isLoading: loadingModelInfo } =
    trpc.models.getInfo.useQuery(
      { asset: selectedAsset },
      { enabled: !!selectedAsset }
    );

  // Fetch latest data
  const { data: latestData, isLoading: loadingData } =
    trpc.models.getLatestData.useQuery();

  // Single prediction mutation
  const predictMutation = trpc.models.predict.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء التوقع بنجاح");
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في إنشاء التوقع");
    },
  });

  // Multi-day prediction mutation
  const predictMultipleMutation = trpc.models.predictMultipleDays.useMutation({
    onSuccess: () => {
      toast.success(`تم إنشاء ${predictionDays} توقعات بنجاح`);
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في إنشاء التوقعات");
    },
  });

  const getStatusIcon = (status: string) => {
    if (status === "healthy" || status === "ok") {
      return <CheckCircle className="h-5 w-5 text-emerald-500" />;
    }
    return <XCircle className="h-5 w-5 text-red-500" />;
  };

  const getStatusBadge = (status: string) => {
    if (status === "healthy" || status === "ok") {
      return (
        <Badge className="bg-emerald-500 text-white flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          متصل
        </Badge>
      );
    }
    return (
      <Badge variant="destructive" className="flex items-center gap-1">
        <XCircle className="h-3 w-3" />
        غير متصل
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  نماذج التعلم الآلي
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة ومراقبة نماذج الذكاء الاصطناعي للتوقعات
                </p>
              </div>
            </div>

            <Button
              data-testid="refresh-models-button"
              variant="outline"
              onClick={() => {
                refetchHealth();
                refetchModels();
              }}
              disabled={loadingHealth || loadingModels}
              size="sm"
            >
              <RefreshCw
                className={`ml-2 h-4 w-4 ${
                  loadingHealth || loadingModels ? "animate-spin" : ""
                }`}
              />
              تحديث
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Health Status */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card
            className={`premium-card border-2 ${
              healthCheck?.status === "healthy"
                ? "border-emerald-500"
                : "border-red-500"
            }`}
          >
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  حالة واجهة ML
                </CardTitle>
                {getStatusBadge(healthCheck?.status || "unhealthy")}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">الحالة</p>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(healthCheck?.status || "unhealthy")}
                    <span className="font-bold">
                      {healthCheck?.status === "healthy" ? "يعمل" : "متوقف"}
                    </span>
                  </div>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">الرابط</p>
                  <p className="font-mono text-sm truncate">
                    {healthCheck?.api_url || "N/A"}
                  </p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">الإصدار</p>
                  <p className="font-bold">{healthCheck?.version || "N/A"}</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">وقت التشغيل</p>
                  <p className="font-bold">{healthCheck?.uptime || "N/A"}</p>
                </div>
              </div>
              {healthCheck?.error && (
                <div className="mt-4 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                  <p className="text-sm text-red-600 dark:text-red-400">
                    {healthCheck.error}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <Tabs defaultValue="models" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="models" className="gap-2">
              <Brain className="h-4 w-4" />
              النماذج
            </TabsTrigger>
            <TabsTrigger value="predict" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              التوقعات
            </TabsTrigger>
            <TabsTrigger value="data" className="gap-2">
              <Database className="h-4 w-4" />
              البيانات
            </TabsTrigger>
          </TabsList>

          {/* Models Tab */}
          <TabsContent value="models">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    النماذج المتاحة
                  </CardTitle>
                  <CardDescription>
                    قائمة بجميع نماذج التعلم الآلي المتاحة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingModels ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : models && (models as any[]).length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {(models as any[]).map((model: any, index: number) => (
                        <motion.div
                          key={index}
                          variants={cardVariants}
                          initial="initial"
                          animate="animate"
                          transition={{ delay: 0.1 * index }}
                        >
                          <Card className="stat-card">
                            <CardContent className="pt-4">
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <Brain className="h-5 w-5 text-primary" />
                                  <span className="font-bold">
                                    {model.name ||
                                      model.asset ||
                                      `نموذج ${index + 1}`}
                                  </span>
                                </div>
                                <Badge variant="secondary">
                                  {model.type || "LSTM"}
                                </Badge>
                              </div>
                              <div className="space-y-2 text-sm">
                                {model.accuracy && (
                                  <div className="flex justify-between p-2 rounded bg-muted/50">
                                    <span className="text-muted-foreground">الدقة:</span>
                                    <span className="font-bold">{model.accuracy}%</span>
                                  </div>
                                )}
                                {model.mae && (
                                  <div className="flex justify-between p-2 rounded bg-muted/50">
                                    <span className="text-muted-foreground">MAE:</span>
                                    <span className="font-bold">{model.mae}</span>
                                  </div>
                                )}
                                {model.trainedAt && (
                                  <div className="flex justify-between p-2 rounded bg-muted/50">
                                    <span className="text-muted-foreground">تاريخ التدريب:</span>
                                    <span className="font-medium text-xs">
                                      {format(
                                        new Date(model.trainedAt),
                                        "PP",
                                        { locale: ar }
                                      )}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد نماذج متاحة</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        تأكد من تشغيل خادم ML
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Predictions Tab */}
          <TabsContent value="predict">
            <div className="grid lg:grid-cols-2 gap-6">
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.2 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-primary" />
                      توقع فوري
                    </CardTitle>
                    <CardDescription>
                      إنشاء توقع واحد للأصل المحدد
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>الأصل</Label>
                      <Select
                        value={selectedAsset}
                        onValueChange={setSelectedAsset}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(assets as any[]).map((asset: any) => (
                            <SelectItem key={asset.id} value={asset.symbol}>
                              {asset.name} ({asset.symbol})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      className="w-full"
                      onClick={() =>
                        predictMutation.mutate({ asset: selectedAsset })
                      }
                      disabled={predictMutation.isPending || !selectedAsset}
                    >
                      {predictMutation.isPending ? (
                        <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Play className="ml-2 h-4 w-4" />
                      )}
                      إنشاء توقع
                    </Button>

                    {predictMutation.data && (
                      <div className="p-4 bg-muted rounded-lg">
                        <p className="text-sm text-muted-foreground mb-2">
                          نتيجة التوقع:
                        </p>
                        <pre className="text-xs overflow-auto">
                          {JSON.stringify(predictMutation.data, null, 2)}
                        </pre>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.3 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-primary" />
                      توقعات متعددة
                    </CardTitle>
                    <CardDescription>إنشاء توقعات لعدة أيام</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>الأصل</Label>
                      <Select
                        value={selectedAsset}
                        onValueChange={setSelectedAsset}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(assets as any[]).map((asset: any) => (
                            <SelectItem key={asset.id} value={asset.symbol}>
                              {asset.name} ({asset.symbol})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>عدد الأيام</Label>
                      <Input
                        type="number"
                        min={1}
                        max={365}
                        value={predictionDays}
                        onChange={(e) =>
                          setPredictionDays(parseInt(e.target.value) || 7)
                        }
                      />
                    </div>
                    <Button
                      className="w-full"
                      variant="secondary"
                      onClick={() =>
                        predictMultipleMutation.mutate({
                          asset: selectedAsset,
                          days: predictionDays,
                        })
                      }
                      disabled={
                        predictMultipleMutation.isPending || !selectedAsset
                      }
                    >
                      {predictMultipleMutation.isPending ? (
                        <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                      ) : (
                        <TrendingUp className="ml-2 h-4 w-4" />
                      )}
                      إنشاء {predictionDays} توقعات
                    </Button>

                    {predictMultipleMutation.data && (
                      <div className="p-4 bg-muted rounded-lg max-h-60 overflow-auto">
                        <p className="text-sm text-muted-foreground mb-2">
                          نتائج التوقعات:
                        </p>
                        <pre className="text-xs">
                          {JSON.stringify(
                            predictMultipleMutation.data,
                            null,
                            2
                          )}
                        </pre>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Data Tab */}
          <TabsContent value="data">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-primary" />
                    أحدث البيانات
                  </CardTitle>
                  <CardDescription>
                    آخر البيانات المستخدمة في التدريب والتوقعات
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingData ? (
                    <div className="flex items-center justify-center py-12">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : latestData ? (
                    <div className="p-4 bg-muted rounded-lg overflow-auto max-h-96">
                      <pre className="text-xs">
                        {JSON.stringify(latestData, null, 2)}
                      </pre>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Database className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">لا توجد بيانات متاحة</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
