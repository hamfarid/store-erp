/**
 * Admin Assets Management Page
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Pencil, Trash2, Coins } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AdminAssets() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<any>(null);
  const [formData, setFormData] = useState({
    symbol: "",
    name: "",
    type: "",
    description: "",
  });

  const { data: assets, isLoading, refetch } = trpc.admin.assets.list.useQuery();

  const createAsset = trpc.admin.assets.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء الأصل بنجاح");
      setIsCreateOpen(false);
      setFormData({ symbol: "", name: "", type: "", description: "" });
      refetch();
    },
    onError: (error) => {
      toast.error("فشل إنشاء الأصل: " + error.message);
    },
  });

  const updateAsset = trpc.admin.assets.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الأصل بنجاح");
      setEditingAsset(null);
      refetch();
    },
    onError: (error) => {
      toast.error("فشل تحديث الأصل: " + error.message);
    },
  });

  const deleteAsset = trpc.admin.assets.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الأصل بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error("فشل حذف الأصل: " + error.message);
    },
  });

  const handleCreate = () => {
    if (!formData.symbol || !formData.name || !formData.type) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    createAsset.mutate(formData);
  };

  const handleUpdate = () => {
    if (!editingAsset) {return;}
    updateAsset.mutate({
      id: editingAsset.id,
      ...formData,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا الأصل؟ هذا الإجراء لا يمكن التراجع عنه.")) {
      deleteAsset.mutate({ id });
    }
  };

  const openEditDialog = (asset: any) => {
    setEditingAsset(asset);
    setFormData({
      symbol: asset.symbol,
      name: asset.name,
      type: asset.type,
      description: asset.description || "",
    });
  };

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Coins className="h-6 w-6" />
                إدارة الأصول
              </CardTitle>
              <CardDescription>
                عرض وإدارة جميع الأصول المتاحة في النظام
              </CardDescription>
            </div>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button data-testid="create-asset-button">
                  <Plus className="h-4 w-4 mr-2" />
                  إضافة أصل جديد
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>إضافة أصل جديد</DialogTitle>
                  <DialogDescription>
                    أدخل معلومات الأصل الجديد
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">الرمز *</label>
                    <Input
                      placeholder="مثال: GOLD"
                      value={formData.symbol}
                      onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">الاسم *</label>
                    <Input
                      placeholder="مثال: الذهب"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">النوع *</label>
                    <Input
                      placeholder="مثال: precious_metal"
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">الوصف</label>
                    <Textarea
                      placeholder="وصف الأصل..."
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                    إلغاء
                  </Button>
                  <Button data-testid="submit-asset-form" onClick={handleCreate} disabled={createAsset.isPending}>
                    {createAsset.isPending ? "جاري الإنشاء..." : "إنشاء"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : !assets || assets.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا يوجد أصول
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرمز</TableHead>
                  <TableHead>الاسم</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الوصف</TableHead>
                  <TableHead>تاريخ الإنشاء</TableHead>
                  <TableHead className="text-left">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.map((asset: any) => (
                  <TableRow key={asset.id}>
                    <TableCell className="font-medium">{asset.symbol}</TableCell>
                    <TableCell>{asset.name}</TableCell>
                    <TableCell>{asset.type}</TableCell>
                    <TableCell className="max-w-xs truncate">
                      {asset.description || "-"}
                    </TableCell>
                    <TableCell>
                      {asset.createdAt ? format(new Date(asset.createdAt), "yyyy-MM-dd") : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 justify-end">
                        <Dialog open={editingAsset?.id === asset.id} onOpenChange={(open) => !open && setEditingAsset(null)}>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              data-testid="edit-asset"
                              onClick={() => openEditDialog(asset)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>تعديل الأصل</DialogTitle>
                              <DialogDescription>
                                تحديث معلومات الأصل
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium">الرمز</label>
                                <Input
                                  value={formData.symbol}
                                  onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                                />
                              </div>
                              <div>
                                <label className="text-sm font-medium">الاسم</label>
                                <Input
                                  value={formData.name}
                                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                />
                              </div>
                              <div>
                                <label className="text-sm font-medium">النوع</label>
                                <Input
                                  value={formData.type}
                                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                                />
                              </div>
                              <div>
                                <label className="text-sm font-medium">الوصف</label>
                                <Textarea
                                  value={formData.description}
                                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                />
                              </div>
                            </div>
                            <DialogFooter>
                              <Button variant="outline" onClick={() => setEditingAsset(null)}>
                                إلغاء
                              </Button>
                              <Button onClick={handleUpdate} disabled={updateAsset.isPending}>
                                {updateAsset.isPending ? "جاري التحديث..." : "تحديث"}
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        <Button
                          variant="destructive"
                          size="icon"
                          data-testid="delete-asset"
                          onClick={() => handleDelete(asset.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

