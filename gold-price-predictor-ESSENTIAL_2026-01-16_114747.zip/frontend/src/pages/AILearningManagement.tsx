/**
 * AI Learning Management Page
 * Display training data statistics, quality metrics, keywords, and management tools
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Brain,
  Search,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Database,
  FileText,
  Tag,
  BarChart3,
  RefreshCw,
  Filter,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AILearningManagement() {
  const [searchKeyword, setSearchKeyword] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedTopic, setSelectedTopic] = useState<string>("all");

  const {
    data: stats,
    isLoading,
    refetch,
  } = trpc.aiLearning.getStatistics.useQuery();
  const { data: searchResults } = trpc.aiLearning.searchExamples.useQuery(
    { keyword: searchKeyword },
    { enabled: searchKeyword.length > 2 }
  );
  const { data: categoryExamples } =
    trpc.aiLearning.getExamplesByCategory.useQuery(
      { category: selectedCategory },
      { enabled: selectedCategory !== "all" }
    );
  const { data: allExamples } = trpc.aiLearning.getAllExamples.useQuery();
  const { data: allKnowledge } = trpc.aiLearning.getAllKnowledge.useQuery();

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) {return `${bytes} B`;}
    if (bytes < 1024 * 1024) {return `${(bytes / 1024).toFixed(2)} KB`;}
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const getQualityColor = (percentage: number) => {
    if (percentage >= 80) {return "text-green-600";}
    if (percentage >= 60) {return "text-yellow-600";}
    return "text-red-600";
  };

  const getQualityIcon = (percentage: number) => {
    if (percentage >= 80)
      {return <CheckCircle2 className="h-5 w-5 text-green-600" />;}
    if (percentage >= 60)
      {return <AlertTriangle className="h-5 w-5 text-yellow-600" />;}
    return <AlertTriangle className="h-5 w-5 text-red-600" />;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="container mx-auto py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>خطأ</AlertTitle>
          <AlertDescription>فشل تحميل إحصائيات التعلم</AlertDescription>
        </Alert>
      </div>
    );
  }

  const displayedExamples =
    searchKeyword.length > 2
      ? searchResults
      : selectedCategory !== "all"
        ? categoryExamples
        : allExamples;

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Brain className="h-8 w-8" />
            إدارة ملفات التعلم
          </h1>
          <p className="text-muted-foreground">
            تحليل وإدارة بيانات تدريب المساعد الذكي
          </p>
        </div>
        <Button onClick={() => refetch()} variant="outline" size="icon">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      {/* Recommendations Alert */}
      {stats.recommendations && stats.recommendations.length > 0 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>توصيات لتحسين الجودة</AlertTitle>
          <AlertDescription>
            <ul className="list-disc list-inside space-y-1 mt-2">
              {stats.recommendations.map((rec, idx) => (
                <li key={idx}>{rec}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {/* Overview Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <FileText className="h-4 w-4" />
              أمثلة التدريب
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalExamples}</div>
            <p className="text-xs text-muted-foreground mt-1">
              متوسط الطول: {Math.round(stats.averageResponseLength)} حرف
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Database className="h-4 w-4" />
              قاعدة المعرفة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalKnowledge}</div>
            <p className="text-xs text-muted-foreground mt-1">
              قواعد ومعلومات ثابتة
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              حجم البيانات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatBytes(stats.storageInfo.totalSize)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              تدريب: {formatBytes(stats.storageInfo.trainingDataSize)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Tag className="h-4 w-4" />
              الفئات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Object.keys(stats.categories).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">فئة مختلفة</p>
          </CardContent>
        </Card>
      </div>

      {/* Data Quality Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            مؤشرات جودة البيانات
          </CardTitle>
          <CardDescription>تحليل شامل لجودة بيانات التدريب</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Noise Percentage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getQualityIcon(100 - stats.dataQuality.noisePercentage)}
                <span className="font-medium">نسبة التشوه</span>
              </div>
              <span
                className={`text-lg font-bold ${getQualityColor(100 - stats.dataQuality.noisePercentage)}`}
              >
                {stats.dataQuality.noisePercentage.toFixed(1)}%
              </span>
            </div>
            <Progress
              value={stats.dataQuality.noisePercentage}
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              نسبة البيانات غير الصالحة أو المشوهة (يُفضل أقل من 10%)
            </p>
          </div>

          {/* Duplicate Percentage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getQualityIcon(100 - stats.dataQuality.duplicatePercentage)}
                <span className="font-medium">نسبة التكرار</span>
              </div>
              <span
                className={`text-lg font-bold ${getQualityColor(100 - stats.dataQuality.duplicatePercentage)}`}
              >
                {stats.dataQuality.duplicatePercentage.toFixed(1)}%
              </span>
            </div>
            <Progress
              value={stats.dataQuality.duplicatePercentage}
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              نسبة البيانات المكررة (يُفضل أقل من 5%)
            </p>
          </div>

          {/* Coverage Score */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getQualityIcon(stats.dataQuality.coverageScore)}
                <span className="font-medium">درجة التغطية</span>
              </div>
              <span
                className={`text-lg font-bold ${getQualityColor(stats.dataQuality.coverageScore)}`}
              >
                {stats.dataQuality.coverageScore.toFixed(1)}%
              </span>
            </div>
            <Progress value={stats.dataQuality.coverageScore} className="h-2" />
            <p className="text-xs text-muted-foreground">
              مدى تغطية البيانات لجميع المواضيع المتوقعة (يُفضل أكثر من 80%)
            </p>
          </div>

          {/* Completeness Score */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getQualityIcon(stats.dataQuality.completenessScore)}
                <span className="font-medium">درجة الاكتمال</span>
              </div>
              <span
                className={`text-lg font-bold ${getQualityColor(stats.dataQuality.completenessScore)}`}
              >
                {stats.dataQuality.completenessScore.toFixed(1)}%
              </span>
            </div>
            <Progress
              value={stats.dataQuality.completenessScore}
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              نسبة الأمثلة المكتملة بجميع الحقول (يُفضل أكثر من 90%)
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Keywords Cloud */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Tag className="h-5 w-5" />
            الكلمات المفتاحية الأكثر تكراراً
          </CardTitle>
          <CardDescription>
            أهم الكلمات في بيانات التدريب (Top 30)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {stats.keywords.slice(0, 30).map((keyword, idx) => {
              const size = Math.min(
                Math.max(keyword.frequency / stats.keywords[0].frequency, 0.5),
                1.5
              );
              return (
                <Badge
                  key={idx}
                  variant="outline"
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                  style={{ fontSize: `${size}rem` }}
                  onClick={() => setSearchKeyword(keyword.word)}
                >
                  {keyword.word} ({keyword.frequency})
                </Badge>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Categories Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            توزيع الفئات
          </CardTitle>
          <CardDescription>عدد الأمثلة في كل فئة</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(stats.categories)
              .sort(([, a], [, b]) => b - a)
              .map(([category, count]) => (
                <div key={category} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{category}</span>
                    <span className="text-muted-foreground">
                      {count} (
                      {((count / stats.totalExamples) * 100).toFixed(1)}%)
                    </span>
                  </div>
                  <Progress
                    value={(count / stats.totalExamples) * 100}
                    className="h-2"
                  />
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Training Examples Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            إدارة أمثلة التدريب
          </CardTitle>
          <CardDescription>البحث والتصفية والإدارة</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search and Filter */}
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث في الأمثلة..."
                  value={searchKeyword}
                  onChange={e => setSearchKeyword(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="اختر فئة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الفئات</SelectItem>
                {Object.keys(stats.categories).map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Examples Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">#</TableHead>
                  <TableHead>السؤال</TableHead>
                  <TableHead>الإجابة</TableHead>
                  <TableHead>الفئة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayedExamples && displayedExamples.length > 0 ? (
                  displayedExamples
                    .slice(0, 10)
                    .map((example: any, idx: number) => (
                      <TableRow key={idx}>
                        <TableCell className="font-medium">{idx + 1}</TableCell>
                        <TableCell className="max-w-xs truncate">
                          {example.question}
                        </TableCell>
                        <TableCell className="max-w-md truncate">
                          {example.answer}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {example.category || "غير محدد"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      className="text-center text-muted-foreground py-8"
                    >
                      لا توجد أمثلة
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {displayedExamples && displayedExamples.length > 10 && (
            <p className="text-sm text-muted-foreground text-center">
              عرض 10 من {displayedExamples.length} مثال
            </p>
          )}
        </CardContent>
      </Card>

      {/* Knowledge Base */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            قاعدة المعرفة
          </CardTitle>
          <CardDescription>القواعد والمعلومات الثابتة</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {allKnowledge && allKnowledge.length > 0 ? (
              allKnowledge.map((kb, idx) => (
                <div key={idx} className="border rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{kb.topic}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {kb.content.length} حرف
                    </span>
                  </div>
                  <p className="text-sm">{kb.content}</p>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-8">
                لا توجد قواعد معرفة
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
