/**
 * User Profile Page - Premium Gold Price Predictor
 * Modern profile page with comprehensive user information
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import {
  User,
  TrendingUp,
  Bell,
  Package,
  LogOut,
  Settings,
  ArrowLeft,
  Mail,
  Calendar,
  Shield,
  Activity,
  Brain,
  Target,
  ChevronRight,
  Edit,
  Camera,
  Key,
  Sparkles,
  Award,
  Wallet,
  BarChart3,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { PageLayout } from "@/components/PageLayout";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { FadeIn, SlideUp } from "@/components/animations";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  subtext,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  subtext?: string;
  color?: "primary" | "success" | "warning" | "info";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    info: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card h-full">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${colors[color]}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="text-2xl font-bold">{value}</p>
              {subtext && (
                <p className="text-xs text-muted-foreground">{subtext}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function UserProfile() {
  const { user, loading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [isSaving, setIsSaving] = useState(false);

  const { data: assets } = trpc.assets.list.useQuery(undefined, {
    enabled: !!user,
  });

  const { data: predictions } = trpc.predictions.getHistory.useQuery(
    { limit: 1000 },
    { enabled: !!user }
  );

  const { data: alerts } = (trpc.alerts as any).getAll.useQuery(undefined, {
    enabled: !!user,
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    setTimeout(() => {
      toast.success("تم حفظ التغييرات بنجاح!");
      setIsSaving(false);
      setIsEditing(false);
    }, 1000);
  };

  const stats = {
    totalAssets: assets?.length || 0,
    totalPredictions: predictions?.length || 0,
    activePredictions:
      predictions?.filter(
        (p: any) =>
          new Date((p as any).createdAt) >
          new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      ).length || 0,
    totalAlerts: alerts?.length || 0,
    activeAlerts: alerts?.filter((a: any) => (a as any).isActive).length || 0,
    triggeredAlerts: alerts?.filter((a: any) => (a as any).isTriggered).length || 0,
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  // Calculate profile completion
  const profileCompletion = [
    !!user.name,
    !!user.email,
    stats.totalPredictions > 0,
    stats.totalAlerts > 0,
  ].filter(Boolean).length * 25;

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <User className="h-6 w-6 text-primary" />
                  الملف الشخصي
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة معلومات حسابك
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/settings">
                <Button variant="outline" size="sm">
                  <Settings className="ml-2 h-4 w-4" />
                  الإعدادات
                </Button>
              </Link>
              <Button data-testid="logout-button" variant="destructive" size="sm" onClick={handleLogout}>
                <LogOut className="ml-2 h-4 w-4" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Profile Card - Left Column */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            className="lg:col-span-1"
          >
            <Card className="sticky top-24 overflow-hidden">
              {/* Cover gradient */}
              <div className="h-24 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent" />
              
              <CardContent className="-mt-12 text-center">
                {/* Avatar */}
                <div className="relative inline-block mb-4">
                  <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
                    <AvatarImage src="" alt={user.name || "User"} />
                    <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                      {getInitials(user.name || "User")}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    size="icon"
                    variant="secondary"
                    className="absolute bottom-0 right-0 h-8 w-8 rounded-full shadow"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>

                {/* Name & Role */}
                <h2 className="text-xl font-bold">{user.name || "مستخدم"}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                
                <div className="flex justify-center gap-2 mt-3">
                  <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                    <Shield className="ml-1 h-3 w-3" />
                    {user.role === "admin" ? "مدير" : "مستخدم"}
                  </Badge>
                  {profileCompletion === 100 && (
                    <Badge variant="outline" className="text-emerald-600 border-emerald-600">
                      <CheckCircle2 className="ml-1 h-3 w-3" />
                      مكتمل
                    </Badge>
                  )}
                </div>

                <Separator className="my-6" />

                {/* Profile Completion */}
                <div className="text-right">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">اكتمال الملف</span>
                    <span className="text-sm font-medium">{profileCompletion}%</span>
                  </div>
                  <Progress value={profileCompletion} className="h-2" />
                </div>

                <Separator className="my-6" />

                {/* Quick Info */}
                <div className="space-y-3 text-right">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      عضو منذ {user.createdAt
                        ? new Date(user.createdAt).toLocaleDateString("ar-EG", {
                            month: "long",
                            year: "numeric",
                          })
                        : "حديثاً"}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      آخر دخول: {user.lastSignedIn
                        ? new Date(user.lastSignedIn).toLocaleString("ar-EG")
                        : "غير متاح"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Main Content - Right Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <StatCard
                icon={Package}
                label="إجمالي الأصول"
                value={stats.totalAssets}
                color="primary"
                delay={0}
              />
              <StatCard
                icon={TrendingUp}
                label="التوقعات"
                value={stats.totalPredictions}
                subtext={`${stats.activePredictions} نشطة هذا الأسبوع`}
                color="success"
                delay={0.1}
              />
              <StatCard
                icon={Bell}
                label="التنبيهات"
                value={stats.totalAlerts}
                subtext={`${stats.activeAlerts} نشطة`}
                color="warning"
                delay={0.2}
              />
              <StatCard
                icon={Target}
                label="مُفعّلة"
                value={stats.triggeredAlerts}
                subtext="تنبيهات تم تفعيلها"
                color="info"
                delay={0.3}
              />
            </div>

            {/* Tabs */}
            <Tabs defaultValue="info" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">المعلومات</TabsTrigger>
                <TabsTrigger value="activity">النشاط</TabsTrigger>
                <TabsTrigger value="security">الأمان</TabsTrigger>
              </TabsList>

              {/* Information Tab */}
              <TabsContent value="info" className="space-y-6">
                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.4 }}
                >
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                      <div>
                        <CardTitle>معلومات الحساب</CardTitle>
                        <CardDescription>تفاصيل حسابك الشخصي</CardDescription>
                      </div>
                      <Button
                        variant={isEditing ? "default" : "outline"}
                        size="sm"
                        onClick={() => isEditing ? handleSaveProfile() : setIsEditing(true)}
                      >
                        {isEditing ? (
                          isSaving ? (
                            <>جاري الحفظ...</>
                          ) : (
                            <>حفظ</>
                          )
                        ) : (
                          <>
                            <Edit className="ml-2 h-4 w-4" />
                            تعديل
                          </>
                        )}
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                          <Label>الاسم</Label>
                          {isEditing ? (
                            <Input
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                            />
                          ) : (
                            <p className="p-2 bg-muted rounded-md">{user.name}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label>البريد الإلكتروني</Label>
                          <p className="p-2 bg-muted rounded-md text-muted-foreground">
                            {user.email}
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label>معرف المستخدم</Label>
                          <p className="p-2 bg-muted rounded-md font-mono text-sm">
                            {user.id}
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label>الصلاحية</Label>
                          <p className="p-2 bg-muted rounded-md">
                            {user.role === "admin" ? "مدير النظام" : "مستخدم عادي"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </TabsContent>

              {/* Activity Tab */}
              <TabsContent value="activity" className="space-y-6">
                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.4 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle>سجل النشاط</CardTitle>
                      <CardDescription>آخر نشاطاتك في النظام</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {[
                          { icon: TrendingUp, text: "توقع جديد للذهب", time: "منذ 5 دقائق", color: "text-emerald-500" },
                          { icon: Bell, text: "تنبيه سعري تم تفعيله", time: "منذ ساعة", color: "text-amber-500" },
                          { icon: Brain, text: "تم تحديث نموذج ML", time: "منذ 3 ساعات", color: "text-blue-500" },
                          { icon: Activity, text: "تسجيل دخول ناجح", time: "اليوم", color: "text-primary" },
                        ].map((item, i) => (
                          <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                            <div className={`p-2 rounded-lg bg-muted ${item.color}`}>
                              <item.icon className="h-4 w-4" />
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{item.text}</p>
                              <p className="text-xs text-muted-foreground">{item.time}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security" className="space-y-6">
                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.4 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle>الأمان</CardTitle>
                      <CardDescription>إعدادات أمان حسابك</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Button variant="outline" className="w-full justify-between">
                        <div className="flex items-center gap-2">
                          <Key className="h-4 w-4" />
                          تغيير كلمة المرور
                        </div>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" className="w-full justify-between">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4" />
                          تفعيل المصادقة الثنائية
                        </div>
                        <Badge variant="secondary">غير مفعّل</Badge>
                      </Button>
                      <Separator />
                      <div className="rounded-lg border p-4 space-y-2">
                        <h4 className="font-medium">جلسات الدخول النشطة</h4>
                        <p className="text-sm text-muted-foreground">
                          لديك جلسة نشطة واحدة على هذا الجهاز
                        </p>
                        <Button variant="ghost" size="sm" className="text-destructive">
                          إنهاء جميع الجلسات الأخرى
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </TabsContent>
            </Tabs>

            {/* Quick Actions */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>إجراءات سريعة</CardTitle>
                  <CardDescription>الوصول السريع للميزات المهمة</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { icon: Package, label: "الأصول", href: "/assets" },
                    { icon: TrendingUp, label: "توقع جديد", href: "/predictions" },
                    { icon: Bell, label: "التنبيهات", href: "/alerts" },
                    { icon: BarChart3, label: "التقارير", href: "/reports" },
                  ].map((action) => (
                    <Link key={action.href} href={action.href}>
                      <Button variant="outline" className="w-full h-20 flex-col gap-2">
                        <action.icon className="h-5 w-5" />
                        <span className="text-xs">{action.label}</span>
                      </Button>
                    </Link>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
