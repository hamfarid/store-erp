import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  Filter,
  Download,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Calendar,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import { SortableTableHeader } from "@/components/SortableTableHeader";
import PaginationControls from "@/components/PaginationControls";

export default function HistoricalPricesList() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const [searchQuery, setSearchQuery] = useState("");
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const [limit, setLimit] = useState(100);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Sorting state
  const [sortField, setSortField] = useState<string>("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  // Fetch historical prices
  const {
    data: prices,
    isLoading,
    refetch,
  } = trpc.historicalPrices.list.useQuery({
    assetId: 1, // Default to first asset
    limit,
  });

  // Fetch assets for filter
  const { data: assets } = trpc.assets.list.useQuery();

  // Get asset name helper
  const getAssetName = (assetId: number) => {
    return (
      (assets?.find((a: any) => (a as any).id === assetId) as any)?.name ||
      `Asset #${assetId}`
    );
  };

  // Filter and sort prices
  let filteredPrices = prices?.filter((price: any) => {
    const assetName = getAssetName(price.assetId);
    const matchesSearch = (assetName as any)
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesAsset =
      filterAsset === "all" || price.assetId.toString() === filterAsset;
    return matchesSearch && matchesAsset;
  });

  // Sort prices
  if (filteredPrices) {
    filteredPrices = [...filteredPrices].sort((a: any, b: any) => {
      let aValue: any = a[sortField as keyof typeof a];
      let bValue: any = b[sortField as keyof typeof b];

      // Handle date sorting
      if (sortField === "date") {
        aValue = new Date(aValue).getTime();
        bValue = new Date(bValue).getTime();
      }

      // Handle numeric sorting
      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }

      return 0;
    });
  }

  // Pagination
  const totalItems = filteredPrices?.length || 0;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedPrices = filteredPrices?.slice(startIndex, endIndex);

  // Export to CSV
  const handleExport = () => {
    if (!filteredPrices || filteredPrices.length === 0) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const csv = [
      [
        "Date",
        "Asset",
        "Price",
        "High",
        "Low",
        "Volume",
        "Change",
        "Change %",
      ].join(","),
      ...filteredPrices.map((p: any) =>
        [
          new Date(p.date).toLocaleDateString(),
          getAssetName(p.assetId),
          p.price,
          p.high || p.price,
          p.low || p.price,
          p.volume || 0,
          p.change || 0,
          p.changePercent || 0,
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `historical_prices_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("تم تصدير البيانات بنجاح");
  };

  // Calculate price change
  const getPriceChange = (open: string, close: string) => {
    const openPrice = parseFloat(open);
    const closePrice = parseFloat(close);
    const change = closePrice - openPrice;
    const changePercent = (change / openPrice) * 100;
    return { change, changePercent };
  };

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 ml-2" />
              العودة للرئيسية
            </Button>
            <h1 className="text-2xl font-bold text-slate-800">
              الأسعار التاريخية
            </h1>
            <div className="w-32"></div> {/* Spacer for centering */}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <p className="text-slate-600">
            بيانات الأسعار التاريخية لجميع الأصول
          </p>
        </div>

        {/* Toolbar */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4">
              {/* Search */}
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="بحث بالأصل..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="pr-10"
                  />
                </div>
              </div>

              {/* Filter by Asset */}
              <div className="w-[200px]">
                <Select value={filterAsset} onValueChange={setFilterAsset}>
                  <SelectTrigger>
                    <Filter className="h-4 w-4 ml-2" />
                    <SelectValue placeholder="تصفية حسب الأصل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأصول</SelectItem>
                    {assets?.map(asset => (
                      <SelectItem
                        key={(asset as any).id}
                        value={(asset as any).id.toString()}
                      >
                        {(asset as any).name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Limit */}
              <div className="w-[150px]">
                <Select
                  value={limit.toString()}
                  onValueChange={val => setLimit(parseInt(val))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="50">50 سجل</SelectItem>
                    <SelectItem value="100">100 سجل</SelectItem>
                    <SelectItem value="200">200 سجل</SelectItem>
                    <SelectItem value="500">500 سجل</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Export */}
              <Button variant="outline" onClick={handleExport}>
                <Download className="h-4 w-4 ml-2" />
                تصدير CSV
              </Button>

              {/* Refresh */}
              <Button
                variant="outline"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw
                  className={`h-4 w-4 ml-2 ${isLoading ? "animate-spin" : ""}`}
                />
                تحديث
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-slate-600 mt-4">جاري التحميل...</p>
          </div>
        ) : paginatedPrices && paginatedPrices.length > 0 ? (
          <>
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">التاريخ</TableHead>
                        <TableHead className="text-right">الأصل</TableHead>
                        <TableHead className="text-right">الافتتاح</TableHead>
                        <TableHead className="text-right">الأعلى</TableHead>
                        <TableHead className="text-right">الأدنى</TableHead>
                        <TableHead className="text-right">الإغلاق</TableHead>
                        <TableHead className="text-right">الحجم</TableHead>
                        <TableHead className="text-right">التغيير</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedPrices.map((price: any) => {
                        const { change, changePercent } = getPriceChange(
                          price.open,
                          price.close
                        );
                        const isPositive = change >= 0;

                        return (
                          <TableRow key={price.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-slate-400" />
                                {new Date(price.date).toLocaleDateString(
                                  "ar-EG"
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="font-medium">
                              {getAssetName(price.assetId)}
                            </TableCell>
                            <TableCell>
                              ${parseFloat(price.open).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-green-600 font-semibold">
                              ${parseFloat(price.high).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-red-600 font-semibold">
                              ${parseFloat(price.low).toFixed(2)}
                            </TableCell>
                            <TableCell className="font-bold">
                              ${parseFloat(price.close).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-slate-600">
                              {parseInt(price.volume).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <div
                                className={`flex items-center gap-1 ${isPositive ? "text-green-600" : "text-red-600"}`}
                              >
                                {isPositive ? (
                                  <TrendingUp className="h-4 w-4" />
                                ) : (
                                  <TrendingDown className="h-4 w-4" />
                                )}
                                <span className="font-semibold">
                                  {isPositive ? "+" : ""}
                                  {change.toFixed(2)}
                                </span>
                                <span className="text-sm">
                                  ({changePercent.toFixed(2)}%)
                                </span>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={totalItems}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={newSize => {
                    setPageSize(newSize);
                    setCurrentPage(1);
                  }}
                />
              </div>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Calendar className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg">لا توجد بيانات تاريخية</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
