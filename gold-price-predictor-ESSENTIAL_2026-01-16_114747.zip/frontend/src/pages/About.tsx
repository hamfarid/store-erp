/**
 * About Page - Premium Gold Price Predictor
 * Company information and technology showcase
 */

import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { APP_LOGO, APP_TITLE } from "@/const";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Brain,
  BarChart3,
  AlertCircle,
  Activity,
  TrendingUp,
  Shield,
  Zap,
  Users,
  Github,
  Mail,
  ExternalLink,
  Star,
  Award,
  Sparkles,
  ChevronRight,
  Heart,
  Globe,
  Server,
  Database,
  Cpu,
  Code2,
  Layers,
} from "lucide-react";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const FEATURES = [
  {
    icon: Brain,
    title: "نماذج AI متقدمة",
    description: "استخدام LSTM و Ensemble Learning للتوقعات الدقيقة",
    color: "text-blue-600",
    bgColor: "bg-blue-100 dark:bg-blue-900/30",
  },
  {
    icon: BarChart3,
    title: "17+ أصل مالي",
    description: "ذهب، فضة، بيتكوين، عملات رئيسية، ومزيد",
    color: "text-emerald-600",
    bgColor: "bg-emerald-100 dark:bg-emerald-900/30",
  },
  {
    icon: Bell,
    title: "تنبيهات ذكية",
    description: "نظام إشعارات متعدد القنوات مع شروط مخصصة",
    color: "text-amber-600",
    bgColor: "bg-amber-100 dark:bg-amber-900/30",
  },
  {
    icon: Activity,
    title: "دقة 99%+",
    description: "للتوقعات قصيرة المدى مع تحديث مستمر",
    color: "text-purple-600",
    bgColor: "bg-purple-100 dark:bg-purple-900/30",
  },
  {
    icon: TrendingUp,
    title: "تحليلات متقدمة",
    description: "رسوم بيانية تفاعلية وإحصائيات شاملة",
    color: "text-indigo-600",
    bgColor: "bg-indigo-100 dark:bg-indigo-900/30",
  },
  {
    icon: Shield,
    title: "أمان وخصوصية",
    description: "تشفير متقدم وحماية شاملة للبيانات",
    color: "text-red-600",
    bgColor: "bg-red-100 dark:bg-red-900/30",
  },
];

const TECH_STACK = [
  {
    category: "Frontend",
    icon: Layers,
    technologies: ["React 19", "TypeScript", "TailwindCSS", "Framer Motion", "shadcn/ui"],
  },
  {
    category: "Backend",
    icon: Server,
    technologies: ["Node.js", "FastAPI", "tRPC", "Express"],
  },
  {
    category: "Database",
    icon: Database,
    technologies: ["SQLite", "PostgreSQL", "Redis", "Drizzle ORM"],
  },
  {
    category: "AI/ML",
    icon: Cpu,
    technologies: ["TensorFlow", "Keras", "LSTM", "XGBoost", "Ensemble"],
  },
];

const STATS = [
  { value: "99.03%", label: "دقة التوقعات" },
  { value: "17+", label: "أصل مالي" },
  { value: "8", label: "نماذج AI" },
  { value: "24/7", label: "دعم فني" },
];

// Import Bell for features
import { Bell } from "lucide-react";

export default function About() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Sparkles className="h-6 w-6 text-primary" />
                  عن النظام
                </h1>
                <p className="text-sm text-muted-foreground">
                  {APP_TITLE}
                </p>
              </div>
            </div>
            <Link href="/help">
              <Button variant="outline" size="sm">
                مركز المساعدة
                <ChevronRight className="mr-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Hero Section */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="text-center mb-12"
        >
          <div className="mb-6 relative inline-block">
            {APP_LOGO ? (
              <img src={APP_LOGO} alt={APP_TITLE} className="h-24 mx-auto" />
            ) : (
              <div className="p-6 rounded-2xl bg-primary/10 inline-block">
                <Sparkles className="h-16 w-16 text-primary" />
              </div>
            )}
            <Badge className="absolute -top-2 -right-2 bg-primary">
              v2.0
            </Badge>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="gold-shimmer">{APP_TITLE}</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            نظام متقدم لتوقع أسعار الأصول المالية باستخدام أحدث تقنيات الذكاء الاصطناعي والتعلم العميق
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 max-w-3xl mx-auto">
            {STATS.map((stat, i) => (
              <motion.div
                key={i}
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 * i }}
              >
                <Card className="stat-card">
                  <CardContent className="pt-6 text-center">
                    <p className="text-3xl font-bold text-primary">{stat.value}</p>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* About Section */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <Card className="overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
            <CardHeader>
              <CardTitle>عن النظام</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p className="text-lg leading-relaxed">
                <strong>{APP_TITLE}</strong> هو نظام متقدم لتوقع أسعار الأصول المالية باستخدام تقنيات الذكاء الاصطناعي والتعلم الآلي.
                يوفر النظام توقعات دقيقة للأسعار المستقبلية لمجموعة واسعة من الأصول المالية بما في ذلك الذهب،
                الفضة، البيتكوين، النفط، والعملات الرئيسية.
              </p>
              <p className="leading-relaxed">
                تم تطوير النظام باستخدام أحدث تقنيات التعلم العميق (Deep Learning) ونماذج LSTM المتقدمة،
                مع دقة تتجاوز <strong className="text-primary">99%</strong> للتوقعات قصيرة المدى. 
                يتميز النظام بواجهة مستخدم احترافية مع نظام تنبيهات ذكي متعدد القنوات.
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6 text-center">المميزات الرئيسية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((feature, i) => (
              <motion.div
                key={i}
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 * i }}
              >
                <Card className="stat-card h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-lg">
                      <div className={`p-2 rounded-xl ${feature.bgColor}`}>
                        <feature.icon className={`h-5 w-5 ${feature.color}`} />
                      </div>
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Technology Stack */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code2 className="h-5 w-5 text-primary" />
                التقنيات المستخدمة
              </CardTitle>
              <CardDescription>بُني باستخدام أحدث التقنيات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {TECH_STACK.map((stack, i) => (
                  <div key={i} className="space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <stack.icon className="h-4 w-4 text-primary" />
                      </div>
                      <h3 className="font-semibold">{stack.category}</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {stack.technologies.map((tech, j) => (
                        <Badge key={j} variant="secondary" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Team & Contact */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.5 }}
          className="grid md:grid-cols-2 gap-6 mb-12"
        >
          {/* Team */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                الفريق
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                تم تطوير هذا النظام بواسطة فريق من المتخصصين في الذكاء الاصطناعي، التعلم الآلي،
                وتطوير البرمجيات، بهدف توفير أداة احترافية لتوقع أسعار الأصول المالية.
              </p>
              <div className="flex gap-3">
                <Button variant="outline" size="sm">
                  <Github className="ml-2 h-4 w-4" />
                  GitHub
                </Button>
                <Button variant="outline" size="sm">
                  <Globe className="ml-2 h-4 w-4" />
                  الموقع
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                تواصل معنا
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                لديك سؤال أو اقتراح؟ نحن هنا للمساعدة!
              </p>
              <Button className="w-full glow-gold">
                <Mail className="ml-2 h-4 w-4" />
                إرسال رسالة
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Footer */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.6 }}
        >
          <Card>
            <CardContent className="py-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <span className="font-semibold">{APP_TITLE}</span>
                  <Badge variant="outline">v2.0.0</Badge>
                </div>
                <div className="text-sm text-muted-foreground text-center">
                  © 2025 {APP_TITLE}. جميع الحقوق محفوظة.
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  صُنع بـ <Heart className="h-4 w-4 text-red-500 mx-1" /> بواسطة فريق التطوير
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
