import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  AlertTriangle,
  Activity,
  TrendingUp,
  Server,
} from "lucide-react";

export default function Logs() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const { data: errors, isLoading: errorsLoading } =
    trpc.logs.getErrors.useQuery(
      { limit: 50 },
      {
        enabled: isAuthenticated,
      }
    );

  const { data: mlLogs, isLoading: mlLoading } =
    trpc.logs.getMLTrainingHistory.useQuery(
      { limit: 50 },
      {
        enabled: isAuthenticated,
      }
    );

  const { data: predictionLogs, isLoading: predLoading } =
    trpc.logs.getPredictionLogs.useQuery(
      { limit: 50 },
      {
        enabled: isAuthenticated,
      }
    );

  const { data: systemHealth } = trpc.logs.getSystemHealth.useQuery(undefined, {
    enabled: isAuthenticated,
    // Manual refresh only - no auto-refetch to avoid performance issues
  });

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="h-4 w-4 ml-2" />
            العودة للرئيسية
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-800">سجلات النظام</h1>
          <p className="text-slate-600 mt-2">مراقبة الأخطاء والأداء والتدريب</p>
        </div>

        {/* System Health */}
        {systemHealth && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">
                  حالة النظام
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div
                    className={`h-3 w-3 rounded-full ${systemHealth.status === "healthy" ? "bg-green-500" : "bg-red-500"}`}
                  ></div>
                  <p className="text-2xl font-bold">
                    {systemHealth.status === "healthy" ? "سليم" : "مشاكل"}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600">
                  أخطاء حديثة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {systemHealth.recentErrors}
                </p>
                <p className="text-xs text-slate-500">آخر ساعة</p>
              </CardContent>
            </Card>

            {systemHealth.apiStats && (
              <>
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-600">
                      معدل النجاح
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">
                      {systemHealth.apiStats.successRate.toFixed(1)}%
                    </p>
                    <p className="text-xs text-slate-500">آخر 24 ساعة</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-600">
                      متوسط الاستجابة
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">
                      {systemHealth.apiStats.avgResponseTime}ms
                    </p>
                    <p className="text-xs text-slate-500">آخر 24 ساعة</p>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="errors" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="errors">
              <AlertTriangle className="h-4 w-4 ml-2" />
              الأخطاء
            </TabsTrigger>
            <TabsTrigger value="ml">
              <TrendingUp className="h-4 w-4 ml-2" />
              تدريب ML
            </TabsTrigger>
            <TabsTrigger value="predictions">
              <Activity className="h-4 w-4 ml-2" />
              التوقعات
            </TabsTrigger>
          </TabsList>

          {/* Errors Tab */}
          <TabsContent value="errors" className="space-y-4">
            {errorsLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : errors && errors.length > 0 ? (
              errors.map((error: any) => (
                <Card
                  key={(error as any).id}
                  className={`${(error as any).level === "error" ? "border-red-200" : (error as any).level === "warn" ? "border-yellow-200" : ""}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <AlertTriangle
                        className={`h-5 w-5 mt-1 ${(error as any).level === "error" ? "text-red-600" : (error as any).level === "warn" ? "text-yellow-600" : "text-blue-600"}`}
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold">
                            {(error as any).source}/{(error as any).component}
                          </span>
                          <span className="text-xs text-slate-500">
                            {(error as any).timestamp
                              ? new Date(
                                  (error as any).timestamp
                                ).toLocaleString("ar-EG")
                              : ""}
                          </span>
                        </div>
                        <p className="text-sm text-slate-700">
                          {(error as any).message}
                        </p>
                        {(error as any).stack && (
                          <details className="mt-2">
                            <summary className="text-xs text-slate-500 cursor-pointer">
                              عرض Stack Trace
                            </summary>
                            <pre className="text-xs bg-slate-100 p-2 rounded mt-1 overflow-x-auto">
                              {(error as any).stack}
                            </pre>
                          </details>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <AlertTriangle className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">لا توجد أخطاء مسجلة</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ML Training Tab */}
          <TabsContent value="ml" className="space-y-4">
            {mlLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : mlLogs && mlLogs.length > 0 ? (
              mlLogs.map((log: any) => (
                <Card key={(log as any).id}>
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      <div>
                        <p className="text-sm text-slate-600">النموذج</p>
                        <p className="font-semibold">
                          {(log as any).modelType}
                        </p>
                        <p className="text-xs text-slate-500">
                          Asset #{(log as any).assetId}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">الحالة</p>
                        <p
                          className={`font-semibold ${(log as any).status === "completed" ? "text-green-600" : (log as any).status === "failed" ? "text-red-600" : "text-yellow-600"}`}
                        >
                          {log.status === "completed"
                            ? "مكتمل"
                            : log.status === "failed"
                              ? "فشل"
                              : "جاري"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Train R²</p>
                        <p className="font-semibold">
                          {log.trainScore || "--"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Test R²</p>
                        <p className="font-semibold">{log.testScore || "--"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">الوقت</p>
                        <p className="font-semibold">
                          {log.trainingDuration
                            ? `${log.trainingDuration}s`
                            : "--"}
                        </p>
                        <p className="text-xs text-slate-500">
                          {log.timestamp
                            ? new Date(log.timestamp).toLocaleDateString(
                                "ar-EG"
                              )
                            : ""}
                        </p>
                      </div>
                    </div>
                    {log.errorMessage && (
                      <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-700">
                        {log.errorMessage}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <TrendingUp className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">لا توجد سجلات تدريب</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Predictions Tab */}
          <TabsContent value="predictions" className="space-y-4">
            {predLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : predictionLogs && predictionLogs.length > 0 ? (
              predictionLogs.map((log: any) => (
                <Card key={(log as any).id}>
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-slate-600">النموذج</p>
                        <p className="font-semibold">
                          {(log as any).modelType}
                        </p>
                        <p className="text-xs text-slate-500">
                          Asset #{log.assetId}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">الحالة</p>
                        <p
                          className={`font-semibold ${log.status === "success" ? "text-green-600" : "text-red-600"}`}
                        >
                          {log.status === "success" ? "نجح" : "فشل"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">وقت التنفيذ</p>
                        <p className="font-semibold">
                          {log.executionTime ? `${log.executionTime}ms` : "--"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">التاريخ</p>
                        <p className="text-sm">
                          {log.timestamp
                            ? new Date(log.timestamp).toLocaleString("ar-EG")
                            : ""}
                        </p>
                      </div>
                    </div>
                    {log.errorMessage && (
                      <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-700">
                        {log.errorMessage}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Activity className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">لا توجد سجلات توقعات</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
