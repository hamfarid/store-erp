/**
 * Settings Page - Premium Gold Price Predictor
 * Comprehensive settings management with modern UI
 */

import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Download,
  Upload,
  Database,
  HardDrive,
  Loader2,
  CheckCircle,
  Settings2,
  Bell,
  Shield,
  Palette,
  Globe,
  Smartphone,
  Mail,
  Key,
  User,
  Moon,
  Sun,
  Volume2,
  Eye,
  Lock,
  Trash2,
  AlertTriangle,
  Save,
  RefreshCw,
  Sparkles,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import { PageLayout } from "@/components/PageLayout";
import { Breadcrumbs } from "@/components/ui/breadcrumbs";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Settings Section Component
function SettingsSection({
  icon: Icon,
  title,
  description,
  children,
  delay = 0,
}: {
  icon: any;
  title: string;
  description?: string;
  children: React.ReactNode;
  delay?: number;
}) {
  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg">
            <div className="p-2 rounded-lg bg-primary/10">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            {title}
          </CardTitle>
          {description && (
            <CardDescription>{description}</CardDescription>
          )}
        </CardHeader>
        <CardContent>{children}</CardContent>
      </Card>
    </motion.div>
  );
}

// Setting Item Component
function SettingItem({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="space-y-0.5">
        <Label className="text-sm font-medium">{label}</Label>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </div>
      {children}
    </div>
  );
}

export default function Settings() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [isExporting, setIsExporting] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Settings state
  const [settings, setSettings] = useState({
    // Notifications
    emailAlerts: true,
    pushNotifications: true,
    priceAlerts: true,
    dailyReport: false,
    weeklyReport: true,
    
    // Appearance
    theme: "system",
    language: "ar",
    compactMode: false,
    animations: true,
    
    // Privacy
    showProfile: true,
    shareData: false,
    analytics: true,
    
    // Trading
    defaultAsset: "gold",
    defaultModel: "ensemble",
    autoRefresh: true,
    refreshInterval: "30",
  });

  const { data: exports } = trpc.export.listExports.useQuery();
  const { data: backups } = trpc.export.listBackups.useQuery();

  const exportDbMutation = trpc.export.exportDatabase.useMutation({
    onSuccess: (data) => {
      toast.success(`تم تصدير قاعدة البيانات بنجاح!`);
      setIsExporting(false);
    },
    onError: (error) => {
      toast.error(`فشل التصدير: ${error.message}`);
      setIsExporting(false);
    },
  });

  const exportMLMutation = trpc.export.exportMLModels.useMutation({
    onSuccess: (data) => {
      toast.success(`تم تصدير نماذج ML بنجاح!`);
    },
    onError: (error) => {
      toast.error(`فشل التصدير: ${error.message}`);
    },
  });

  const createBackupMutation = trpc.export.createBackup.useMutation({
    onSuccess: (data) => {
      toast.success(`تم إنشاء النسخة الاحتياطية بنجاح!`);
      setIsBackingUp(false);
    },
    onError: (error) => {
      toast.error(`فشل إنشاء النسخة الاحتياطية: ${error.message}`);
      setIsBackingUp(false);
    },
  });

  const handleSaveSettings = () => {
    setIsSaving(true);
    // Simulate save
    setTimeout(() => {
      toast.success("تم حفظ الإعدادات بنجاح!");
      setIsSaving(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Settings2 className="h-6 w-6 text-primary" />
                  الإعدادات
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة تفضيلاتك وحسابك
                </p>
              </div>
            </div>
            <Button data-testid="save-settings-button" onClick={handleSaveSettings} disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ التغييرات
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-flex">
            <TabsTrigger value="general" className="gap-2">
              <Settings2 className="h-4 w-4" />
              <span className="hidden sm:inline">عام</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">الإشعارات</span>
            </TabsTrigger>
            <TabsTrigger value="appearance" className="gap-2">
              <Palette className="h-4 w-4" />
              <span className="hidden sm:inline">المظهر</span>
            </TabsTrigger>
            <TabsTrigger value="privacy" className="gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">الخصوصية</span>
            </TabsTrigger>
            <TabsTrigger value="data" className="gap-2">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">البيانات</span>
            </TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general" className="space-y-6">
            <SettingsSection
              icon={User}
              title="معلومات الحساب"
              description="معلوماتك الأساسية"
              delay={0}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="p-4 rounded-full bg-primary/10">
                    <User className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold">{user?.name || "مستخدم"}</p>
                    <p className="text-sm text-muted-foreground">{user?.email}</p>
                  </div>
                  <Link href="/profile">
                    <Button variant="outline" size="sm">
                      تعديل الملف
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
                <Separator />
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>الأصل الافتراضي</Label>
                    <Select
                      value={settings.defaultAsset}
                      onValueChange={(v) => setSettings({ ...settings, defaultAsset: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gold">الذهب (XAU)</SelectItem>
                        <SelectItem value="silver">الفضة (XAG)</SelectItem>
                        <SelectItem value="bitcoin">بيتكوين (BTC)</SelectItem>
                        <SelectItem value="oil">النفط (OIL)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>النموذج الافتراضي</Label>
                    <Select
                      value={settings.defaultModel}
                      onValueChange={(v) => setSettings({ ...settings, defaultModel: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ridge">Ridge</SelectItem>
                        <SelectItem value="lstm">LSTM</SelectItem>
                        <SelectItem value="ensemble">Ensemble</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={RefreshCw}
              title="التحديث التلقائي"
              description="تحديث البيانات تلقائياً"
              delay={0.1}
            >
              <div className="space-y-4">
                <SettingItem
                  label="تفعيل التحديث التلقائي"
                  description="تحديث الأسعار والتوقعات تلقائياً"
                >
                  <Switch
                    checked={settings.autoRefresh}
                    onCheckedChange={(v) => setSettings({ ...settings, autoRefresh: v })}
                  />
                </SettingItem>
                {settings.autoRefresh && (
                  <div className="space-y-2">
                    <Label>فترة التحديث</Label>
                    <Select
                      value={settings.refreshInterval}
                      onValueChange={(v) => setSettings({ ...settings, refreshInterval: v })}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">كل 10 ثوانٍ</SelectItem>
                        <SelectItem value="30">كل 30 ثانية</SelectItem>
                        <SelectItem value="60">كل دقيقة</SelectItem>
                        <SelectItem value="300">كل 5 دقائق</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </SettingsSection>
          </TabsContent>

          {/* Notifications Settings */}
          <TabsContent value="notifications" className="space-y-6">
            <SettingsSection
              icon={Bell}
              title="تنبيهات البريد الإلكتروني"
              description="إدارة إشعارات البريد الإلكتروني"
              delay={0}
            >
              <div className="space-y-2">
                <SettingItem
                  label="تنبيهات الأسعار"
                  description="تلقي إشعار عند تفعيل تنبيه سعري"
                >
                  <Switch
                    data-testid="toggle-email-alerts"
                    checked={settings.emailAlerts}
                    onCheckedChange={(v) => setSettings({ ...settings, emailAlerts: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="التقرير اليومي"
                  description="ملخص يومي للأداء والتوقعات"
                >
                  <Switch
                    checked={settings.dailyReport}
                    onCheckedChange={(v) => setSettings({ ...settings, dailyReport: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="التقرير الأسبوعي"
                  description="تحليل أسبوعي شامل"
                >
                  <Switch
                    checked={settings.weeklyReport}
                    onCheckedChange={(v) => setSettings({ ...settings, weeklyReport: v })}
                  />
                </SettingItem>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={Smartphone}
              title="الإشعارات الفورية"
              description="إشعارات التطبيق والمتصفح"
              delay={0.1}
            >
              <div className="space-y-2">
                <SettingItem
                  label="إشعارات الدفع"
                  description="إشعارات فورية على المتصفح"
                >
                  <Switch
                    data-testid="toggle-push-notifications"
                    checked={settings.pushNotifications}
                    onCheckedChange={(v) => setSettings({ ...settings, pushNotifications: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="تنبيهات الأسعار"
                  description="إشعار فوري عند الوصول لسعر معين"
                >
                  <Switch
                    checked={settings.priceAlerts}
                    onCheckedChange={(v) => setSettings({ ...settings, priceAlerts: v })}
                  />
                </SettingItem>
              </div>
            </SettingsSection>
          </TabsContent>

          {/* Appearance Settings */}
          <TabsContent value="appearance" className="space-y-6">
            <SettingsSection
              icon={Palette}
              title="المظهر"
              description="تخصيص شكل التطبيق"
              delay={0}
            >
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>السمة</Label>
                  <Select
                    value={settings.theme}
                    onValueChange={(v) => setSettings({ ...settings, theme: v })}
                  >
                    <SelectTrigger data-testid="theme-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">
                        <div className="flex items-center gap-2">
                          <Sun className="h-4 w-4" />
                          فاتح
                        </div>
                      </SelectItem>
                      <SelectItem value="dark">
                        <div className="flex items-center gap-2">
                          <Moon className="h-4 w-4" />
                          داكن
                        </div>
                      </SelectItem>
                      <SelectItem value="system">
                        <div className="flex items-center gap-2">
                          <Sparkles className="h-4 w-4" />
                          تلقائي (حسب النظام)
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <SettingItem
                  label="الوضع المضغوط"
                  description="تقليل المسافات بين العناصر"
                >
                  <Switch
                    checked={settings.compactMode}
                    onCheckedChange={(v) => setSettings({ ...settings, compactMode: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="الرسوم المتحركة"
                  description="تفعيل الرسوم المتحركة في الواجهة"
                >
                  <Switch
                    checked={settings.animations}
                    onCheckedChange={(v) => setSettings({ ...settings, animations: v })}
                  />
                </SettingItem>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={Globe}
              title="اللغة والمنطقة"
              description="إعدادات اللغة والمنطقة الزمنية"
              delay={0.1}
            >
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>اللغة</Label>
                  <Select
                    value={settings.language}
                    onValueChange={(v) => setSettings({ ...settings, language: v })}
                  >
                    <SelectTrigger data-testid="language-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </SettingsSection>
          </TabsContent>

          {/* Privacy Settings */}
          <TabsContent value="privacy" className="space-y-6">
            <SettingsSection
              icon={Eye}
              title="الخصوصية"
              description="إعدادات الخصوصية والأمان"
              delay={0}
            >
              <div className="space-y-2">
                <SettingItem
                  label="إظهار الملف الشخصي"
                  description="السماح للآخرين برؤية ملفك الشخصي"
                >
                  <Switch
                    checked={settings.showProfile}
                    onCheckedChange={(v) => setSettings({ ...settings, showProfile: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="مشاركة البيانات"
                  description="مشاركة بيانات مجهولة لتحسين الخدمة"
                >
                  <Switch
                    checked={settings.shareData}
                    onCheckedChange={(v) => setSettings({ ...settings, shareData: v })}
                  />
                </SettingItem>
                <Separator />
                <SettingItem
                  label="التحليلات"
                  description="تتبع استخدام التطبيق لتحسين التجربة"
                >
                  <Switch
                    checked={settings.analytics}
                    onCheckedChange={(v) => setSettings({ ...settings, analytics: v })}
                  />
                </SettingItem>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={Lock}
              title="الأمان"
              description="إعدادات أمان الحساب"
              delay={0.1}
            >
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start">
                  <Key className="ml-2 h-4 w-4" />
                  تغيير كلمة المرور
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="ml-2 h-4 w-4" />
                  تفعيل المصادقة الثنائية
                </Button>
                <Separator />
                <Button variant="destructive" className="w-full justify-start">
                  <Trash2 className="ml-2 h-4 w-4" />
                  حذف الحساب
                </Button>
              </div>
            </SettingsSection>
          </TabsContent>

          {/* Data Settings */}
          <TabsContent value="data" className="space-y-6">
            <SettingsSection
              icon={Download}
              title="تصدير البيانات"
              description="تصدير قاعدة البيانات ونماذج التعلم الآلي"
              delay={0}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="p-4 border rounded-lg space-y-4">
                  <div className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">قاعدة البيانات</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    تصدير جميع الأصول، التوقعات، والتنبيهات إلى ملف JSON
                  </p>
                  <Button
                    onClick={() => {
                      setIsExporting(true);
                      exportDbMutation.mutate();
                    }}
                    disabled={isExporting}
                    className="w-full"
                  >
                    {isExporting ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري التصدير...
                      </>
                    ) : (
                      <>
                        <Download className="ml-2 h-4 w-4" />
                        تصدير قاعدة البيانات
                      </>
                    )}
                  </Button>
                </div>

                <div className="p-4 border rounded-lg space-y-4">
                  <div className="flex items-center gap-2">
                    <HardDrive className="h-5 w-5 text-purple-600" />
                    <h3 className="font-semibold">نماذج ML</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    تصدير النماذج المدربة وبيانات التدريب
                  </p>
                  <Button
                    onClick={() => exportMLMutation.mutate()}
                    disabled={exportMLMutation.isPending}
                    variant="outline"
                    className="w-full"
                  >
                    {exportMLMutation.isPending ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري التصدير...
                      </>
                    ) : (
                      <>
                        <Download className="ml-2 h-4 w-4" />
                        تصدير نماذج ML
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={HardDrive}
              title="النسخ الاحتياطية"
              description="إنشاء وإدارة النسخ الاحتياطية"
              delay={0.1}
            >
              <div className="space-y-4">
                <div className="p-4 border rounded-lg bg-emerald-50 dark:bg-emerald-900/20 space-y-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-emerald-600" />
                    <h3 className="font-semibold">نسخة احتياطية كاملة</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    تشمل قاعدة البيانات، نماذج ML، وبيانات التدريب
                  </p>
                  <Button
                    onClick={() => {
                      setIsBackingUp(true);
                      createBackupMutation.mutate();
                    }}
                    disabled={isBackingUp}
                    className="w-full bg-emerald-600 hover:bg-emerald-700"
                  >
                    {isBackingUp ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري الإنشاء...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="ml-2 h-4 w-4" />
                        إنشاء نسخة احتياطية
                      </>
                    )}
                  </Button>
                </div>

                {backups && backups.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3">النسخ الاحتياطية المتاحة</h4>
                    <ScrollArea className="h-[200px]">
                      <div className="space-y-2">
                        {backups.map((backup: any, index: number) => (
                          <div
                            key={index}
                            className="p-3 border rounded-lg flex items-center justify-between"
                          >
                            <div>
                              <p className="font-medium">{backup.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(backup.created).toLocaleString("ar-EG")}
                              </p>
                            </div>
                            <Button variant="ghost" size="icon">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                )}
              </div>
            </SettingsSection>

            <SettingsSection
              icon={Upload}
              title="استيراد البيانات"
              description="استيراد بيانات من ملفات سابقة"
              delay={0.2}
            >
              <div className="p-8 border-2 border-dashed rounded-lg text-center">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  اسحب وأفلت ملف JSON هنا أو اضغط للاختيار
                </p>
                <Button variant="outline">اختيار ملف</Button>
              </div>
            </SettingsSection>

            <SettingsSection
              icon={Sparkles}
              title="معلومات النظام"
              description="معلومات عامة عن النظام"
              delay={0.3}
            >
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: "الإصدار", value: "7.0" },
                  { label: "عدد الأصول", value: "17" },
                  { label: "عدد النماذج", value: "3" },
                  { label: "الدقة المتوسطة", value: "99.5%" },
                ].map((item, i) => (
                  <div key={i} className="p-4 rounded-lg bg-muted/50 text-center">
                    <p className="text-sm text-muted-foreground">{item.label}</p>
                    <p className="text-xl font-bold text-primary">{item.value}</p>
                  </div>
                ))}
              </div>
            </SettingsSection>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
