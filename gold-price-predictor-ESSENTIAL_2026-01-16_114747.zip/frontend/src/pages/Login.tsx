/**
 * Login Page - Premium Gold Price Predictor
 * Modern authentication page with animations
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  Loader2,
  TrendingUp,
  Sparkles,
  Eye,
  EyeOff,
  Mail,
  Lock,
  ArrowRight,
  Shield,
  CheckCircle2,
} from "lucide-react";

export default function Login() {
  const { user, loading, refresh } = useAuth();
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async () => {
      toast.success("تم تسجيل الدخول بنجاح!");
      const result = await refresh();
      await new Promise(resolve => setTimeout(resolve, 100));

      if (result.data) {
        setLocation("/dashboard");
      } else {
        window.location.href = "/dashboard";
      }
    },
    onError: error => {
      // Check if error is about OAuth account
      if (error.message?.includes("OAuth") || error.message?.includes("oauth")) {
        const oauthUrl = getLoginUrl();
        if (oauthUrl && oauthUrl !== "#") {
          toast.error("هذا الحساب يستخدم OAuth", {
            description: "يرجى استخدام زر تسجيل الدخول باستخدام OAuth أدناه",
            duration: 8000,
            action: {
              label: "تسجيل الدخول بـ OAuth",
              onClick: () => {
                window.location.href = oauthUrl;
              },
            },
          });
        } else {
          toast.error("هذا الحساب يستخدم OAuth", {
            description: "OAuth غير متاح حالياً. يرجى الاتصال بالدعم الفني أو إدارة النظام لتكوين OAuth.",
            duration: 10000,
          });
        }
      } else {
        toast.error(error.message || "فشل تسجيل الدخول");
      }
    },
  });

  useEffect(() => {
    if (user && !loading) {
      setLocation("/dashboard");
    }
  }, [user, loading, setLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password) {
      toast.error("الرجاء إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }

    loginMutation.mutate({ email, password });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
            <Sparkles className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gradient-hero overflow-hidden">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative p-12 flex-col justify-between">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-dots-pattern opacity-30" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative z-10"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 rounded-xl bg-primary/10 glow-gold">
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
            <span className="text-2xl font-bold">{APP_TITLE}</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="relative z-10 flex-1 flex flex-col justify-center"
        >
          <h1 className="text-4xl font-bold mb-6 leading-tight">
            <span className="block">مرحباً بعودتك إلى</span>
            <span className="gold-shimmer">منصة التوقعات الذكية</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
            سجل دخولك للوصول إلى توقعات الأسعار الدقيقة وتحليلات السوق المتقدمة
          </p>
          
          {/* Features List */}
          <div className="mt-8 space-y-4">
            {[
              "توقعات دقيقة بنسبة 99%+",
              "تحليل في الوقت الفعلي",
              "تنبيهات ذكية متعددة القنوات",
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex items-center gap-3"
              >
                <div className="p-1 rounded-full bg-primary/10">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                </div>
                <span className="text-muted-foreground">{feature}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="relative z-10 flex items-center gap-2 text-sm text-muted-foreground"
        >
          <Shield className="h-4 w-4" />
          <span>بياناتك آمنة ومحمية بأحدث تقنيات التشفير</span>
        </motion.div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="inline-flex items-center gap-3">
              <div className="p-3 rounded-xl bg-primary/10 glow-gold">
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
              <span className="text-xl font-bold">{APP_TITLE}</span>
            </div>
          </div>

          <Card className="border-0 shadow-2xl bg-card/80 backdrop-blur-sm">
            <CardHeader className="text-center space-y-2 pb-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", duration: 0.5 }}
                className="mx-auto mb-2"
              >
                <div className="p-4 rounded-2xl bg-primary/10 inline-block">
                  <Sparkles className="h-8 w-8 text-primary" />
                </div>
              </motion.div>
              <CardTitle className="text-2xl font-bold">تسجيل الدخول</CardTitle>
              <CardDescription>
                ادخل إلى حسابك للوصول إلى توقعات الأسعار
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <div className="relative">
                    <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      name="email"
                      data-testid="login-email"
                      type="email"
                      placeholder="example@email.com"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                      disabled={loginMutation.isPending}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">كلمة المرور</Label>
                    <Link
                      href="/forgot-password"
                      className="text-xs text-primary hover:underline"
                    >
                      نسيت كلمة المرور؟
                    </Link>
                  </div>
                  <div className="relative">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      name="password"
                      data-testid="login-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                      disabled={loginMutation.isPending}
                      className="pr-10 pl-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  />
                  <Label htmlFor="remember" className="text-sm cursor-pointer">
                    تذكرني
                  </Label>
                </div>

                <Button
                  type="submit"
                  data-testid="login-submit"
                  className="w-full glow-gold group"
                  size="lg"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جاري تسجيل الدخول...
                    </>
                  ) : (
                    <>
                      تسجيل الدخول
                      <ArrowRight className="mr-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">
                      أو
                    </span>
                  </div>
                </div>

                {/* OAuth Login Button - Always show, but disable if not configured */}
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  size="lg"
                  disabled={getLoginUrl() === "#"}
                  onClick={() => {
                    const oauthUrl = getLoginUrl();
                    if (oauthUrl && oauthUrl !== "#") {
                      window.location.href = oauthUrl;
                    } else {
                      toast.error("OAuth غير متاح حالياً", {
                        description: "يرجى الاتصال بالدعم الفني أو إدارة النظام لتكوين OAuth.",
                        duration: 5000,
                      });
                    }
                  }}
                >
                  <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  </svg>
                  {getLoginUrl() === "#" 
                    ? "تسجيل الدخول باستخدام OAuth (غير متاح)" 
                    : "تسجيل الدخول باستخدام OAuth"}
                </Button>
                {getLoginUrl() === "#" && (
                  <p className="text-xs text-muted-foreground text-center mt-2">
                    OAuth غير مكون حالياً. إذا كان لديك حساب OAuth، يرجى الاتصال بالدعم الفني.
                  </p>
                )}

                <div className="text-center text-sm">
                  <span className="text-muted-foreground">ليس لديك حساب؟ </span>
                  <Link
                    href="/register"
                    className="text-primary hover:underline font-medium"
                  >
                    إنشاء حساب جديد
                  </Link>
                </div>
              </form>

              <p className="mt-6 text-center text-xs text-muted-foreground">
                بتسجيل الدخول، أنت توافق على{" "}
                <Link href="/terms" className="underline hover:text-primary">
                  شروط الخدمة
                </Link>{" "}
                و{" "}
                <Link href="/privacy" className="underline hover:text-primary">
                  سياسة الخصوصية
                </Link>
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
