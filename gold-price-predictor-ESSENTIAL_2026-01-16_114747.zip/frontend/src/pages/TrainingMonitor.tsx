/**
 * Training Monitor Page - Premium Gold Price Predictor
 * Real-time monitoring of ML model training with live metrics
 */

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  Play,
  Pause,
  StopCircle,
  RefreshCw,
  Clock,
  TrendingDown,
  Activity,
  ArrowLeft,
  Sparkles,
  Target,
  Zap,
  BarChart3,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

interface TrainingJob {
  job_id: string;
  model_type: string;
  asset_symbol: string;
  status: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress: number;
  current_epoch: number;
  total_epochs: number;
  metrics?: {
    loss: number;
    val_loss: number;
    mae: number;
    val_mae: number;
    rmse: number;
    val_rmse: number;
  };
  started_at?: string;
  estimated_completion?: string;
}

export default function TrainingMonitor() {
  const [, navigate] = useLocation();
  const [activeJobs, setActiveJobs] = useState<TrainingJob[]>([]);
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Mock training history data
  const [trainingHistory, setTrainingHistory] = useState([
    { epoch: 1, loss: 0.125, val_loss: 0.145, mae: 15.2, val_mae: 16.8 },
    { epoch: 5, loss: 0.085, val_loss: 0.098, mae: 12.5, val_mae: 13.9 },
    { epoch: 10, loss: 0.062, val_loss: 0.075, mae: 10.8, val_mae: 11.5 },
    { epoch: 15, loss: 0.045, val_loss: 0.058, mae: 9.2, val_mae: 10.1 },
    { epoch: 20, loss: 0.035, val_loss: 0.048, mae: 8.5, val_mae: 9.2 },
    { epoch: 25, loss: 0.028, val_loss: 0.042, mae: 7.9, val_mae: 8.6 },
    { epoch: 30, loss: 0.023, val_loss: 0.038, mae: 7.5, val_mae: 8.2 },
  ]);

  // Mock active jobs
  useEffect(() => {
    const mockJobs: TrainingJob[] = [
      {
        job_id: "job_001",
        model_type: "LSTM",
        asset_symbol: "GOLD",
        status: "running",
        progress: 0.65,
        current_epoch: 65,
        total_epochs: 100,
        metrics: {
          loss: 0.0125,
          val_loss: 0.0145,
          mae: 8.5,
          val_mae: 9.2,
          rmse: 11.2,
          val_rmse: 12.1,
        },
        started_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        estimated_completion: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      },
      {
        job_id: "job_002",
        model_type: "Transformer",
        asset_symbol: "BTC",
        status: "running",
        progress: 0.42,
        current_epoch: 42,
        total_epochs: 100,
        metrics: {
          loss: 0.0185,
          val_loss: 0.0205,
          mae: 125.5,
          val_mae: 138.2,
          rmse: 165.2,
          val_rmse: 182.1,
        },
        started_at: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
        estimated_completion: new Date(Date.now() + 28 * 60 * 1000).toISOString(),
      },
      {
        job_id: "job_003",
        model_type: "GRU",
        asset_symbol: "ETH",
        status: "pending",
        progress: 0,
        current_epoch: 0,
        total_epochs: 100,
      },
    ];

    setActiveJobs(mockJobs);
    if (!selectedJob && mockJobs.length > 0) {
      setSelectedJob(mockJobs[0].job_id);
    }
  }, []);

  // Auto-refresh every 5 seconds
  useEffect(() => {
    if (!autoRefresh) {return;}

    const interval = setInterval(() => {
      setActiveJobs((prev) =>
        prev.map((job) => {
          if (job.status === "running" && job.progress < 1) {
            return {
              ...job,
              progress: Math.min(job.progress + 0.01, 1),
              current_epoch: Math.min(job.current_epoch + 1, job.total_epochs),
            };
          }
          return job;
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-primary";
      case "completed":
        return "bg-emerald-500";
      case "failed":
        return "bg-red-500";
      case "pending":
        return "bg-amber-500";
      case "cancelled":
        return "bg-gray-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<
      string,
      "default" | "secondary" | "destructive" | "outline"
    > = {
      running: "default",
      completed: "secondary",
      failed: "destructive",
      pending: "outline",
      cancelled: "secondary",
    };
    return variants[status] || "outline";
  };

  const formatTime = (isoString?: string) => {
    if (!isoString) {return "N/A";}
    const date = new Date(isoString);
    return date.toLocaleTimeString("ar-EG");
  };

  const formatDuration = (start?: string, end?: string) => {
    if (!start) {return "N/A";}
    const startTime = new Date(start).getTime();
    const endTime = end ? new Date(end).getTime() : Date.now();
    const minutes = Math.floor((endTime - startTime) / 60000);
    return `${minutes} دقيقة`;
  };

  const selectedJobData = activeJobs.find((j) => j.job_id === selectedJob);

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Activity className="h-6 w-6 text-primary" />
                  مراقب التدريب
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة تقدم تدريب نماذج التعلم الآلي في الوقت الفعلي
                </p>
              </div>
            </div>
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <RefreshCw
                className={`ml-2 h-4 w-4 ${autoRefresh ? "animate-spin" : ""}`}
              />
              {autoRefresh ? "تحديث تلقائي مفعّل" : "تحديث تلقائي معطّل"}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Active Jobs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {activeJobs.map((job, index) => (
            <motion.div
              key={job.job_id}
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 * index }}
            >
              <Card
                className={`stat-card cursor-pointer transition-all ${
                  selectedJob === job.job_id
                    ? "ring-2 ring-primary border-primary"
                    : ""
                }`}
                onClick={() => setSelectedJob(job.job_id)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{job.model_type}</CardTitle>
                    <Badge variant={getStatusBadge(job.status)}>
                      {job.status === "running"
                        ? "قيد التشغيل"
                        : job.status === "completed"
                        ? "مكتمل"
                        : job.status === "failed"
                        ? "فشل"
                        : job.status === "pending"
                        ? "في الانتظار"
                        : "ملغي"}
                    </Badge>
                  </div>
                  <CardDescription>{job.asset_symbol}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>التقدم</span>
                        <span className="font-semibold">
                          {Math.round(job.progress * 100)}%
                        </span>
                      </div>
                      <Progress value={job.progress * 100} />
                    </div>
                    <div className="flex justify-between text-sm p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">الحقبة</span>
                      <span className="font-semibold">
                        {job.current_epoch} / {job.total_epochs}
                      </span>
                    </div>
                    {job.metrics && (
                      <div className="pt-2 border-t space-y-1">
                        <div className="flex justify-between text-xs p-1 rounded bg-muted/30">
                          <span className="text-muted-foreground">Loss</span>
                          <span>{job.metrics.loss.toFixed(4)}</span>
                        </div>
                        <div className="flex justify-between text-xs p-1 rounded bg-muted/30">
                          <span className="text-muted-foreground">Val Loss</span>
                          <span>{job.metrics.val_loss.toFixed(4)}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Detailed View */}
        {selectedJobData && (
          <>
            {/* Job Details */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
              className="mb-8"
            >
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5 text-primary" />
                        {selectedJobData.model_type} - {selectedJobData.asset_symbol}
                      </CardTitle>
                      <CardDescription>معرف المهمة: {selectedJobData.job_id}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {selectedJobData.status === "running" && (
                        <>
                          <Button variant="outline" size="sm">
                            <Pause className="ml-2 h-4 w-4" />
                            إيقاف مؤقت
                          </Button>
                          <Button variant="destructive" size="sm">
                            <StopCircle className="ml-2 h-4 w-4" />
                            إيقاف
                          </Button>
                        </>
                      )}
                      {selectedJobData.status === "pending" && (
                        <Button size="sm">
                          <Play className="ml-2 h-4 w-4" />
                          بدء
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground">الحالة</p>
                      <div className="flex items-center gap-2 mt-1">
                        <div
                          className={`w-2 h-2 rounded-full ${getStatusColor(
                            selectedJobData.status
                          )}`}
                        />
                        <p className="font-semibold capitalize">
                          {selectedJobData.status === "running"
                            ? "قيد التشغيل"
                            : selectedJobData.status === "completed"
                            ? "مكتمل"
                            : selectedJobData.status === "failed"
                            ? "فشل"
                            : selectedJobData.status === "pending"
                            ? "في الانتظار"
                            : "ملغي"}
                        </p>
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground">بدأ في</p>
                      <p className="font-semibold mt-1">
                        {formatTime(selectedJobData.started_at)}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground">المدة</p>
                      <p className="font-semibold mt-1">
                        {formatDuration(selectedJobData.started_at)}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground">الوقت المتوقع</p>
                      <p className="font-semibold mt-1">
                        {formatTime(selectedJobData.estimated_completion)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Metrics */}
            {selectedJobData.metrics && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.5 }}
                >
                  <Card className="stat-card">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <TrendingDown className="h-4 w-4 text-primary" />
                        Loss
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التدريب</span>
                          <span className="text-2xl font-bold">
                            {selectedJobData.metrics.loss.toFixed(4)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التحقق</span>
                          <span className="text-lg font-semibold text-muted-foreground">
                            {selectedJobData.metrics.val_loss.toFixed(4)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.6 }}
                >
                  <Card className="stat-card">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <BarChart3 className="h-4 w-4 text-primary" />
                        MAE
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التدريب</span>
                          <span className="text-2xl font-bold">
                            {selectedJobData.metrics.mae.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التحقق</span>
                          <span className="text-lg font-semibold text-muted-foreground">
                            {selectedJobData.metrics.val_mae.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  transition={{ delay: 0.7 }}
                >
                  <Card className="stat-card">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Activity className="h-4 w-4 text-primary" />
                        RMSE
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التدريب</span>
                          <span className="text-2xl font-bold">
                            {selectedJobData.metrics.rmse.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <span className="text-sm text-muted-foreground">التحقق</span>
                          <span className="text-lg font-semibold text-muted-foreground">
                            {selectedJobData.metrics.val_rmse.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            )}

            {/* Training History Chart */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.8 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    تاريخ التدريب
                  </CardTitle>
                  <CardDescription>Loss و MAE عبر الحقب</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={trainingHistory}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="epoch" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="loss"
                        stroke="oklch(0.65 0.18 70)"
                        strokeWidth={2}
                        name="Training Loss"
                        dot={{ r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="val_loss"
                        stroke="oklch(0.72 0.19 145)"
                        strokeWidth={2}
                        name="Validation Loss"
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </>
        )}
      </main>
    </div>
  );
}
