/**
 * Data Management Page - Premium Gold Price Predictor
 * Modern data export/import interface with gold theme
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Download,
  Upload,
  FileJson,
  FileSpreadsheet,
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  ArrowLeft,
  Database,
  Sparkles,
  HardDrive,
  Shield,
  Clock,
  FileArchive,
  RefreshCw,
  Trash2,
  FolderOpen,
  History,
  Settings,
  Info,
} from "lucide-react";
import { showSuccess, showError, showPromise } from "@/lib/toast-utils";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <Card className="stat-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${colors[color]}`}>
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-lg font-bold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Export Option Card
function ExportOptionCard({
  icon: Icon,
  title,
  description,
  format,
  onClick,
  isLoading,
}: {
  icon: any;
  title: string;
  description: string;
  format: string;
  onClick: () => void;
  isLoading: boolean;
}) {
  return (
    <Card className="stat-card hover:border-primary/50 transition-colors cursor-pointer" onClick={onClick}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-primary/10">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-semibold">{title}</h3>
              <Badge variant="outline">{format}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          <Button size="sm" disabled={isLoading} variant="ghost">
            {isLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DataManagement() {
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);
  const [importProgress, setImportProgress] = useState(0);

  const exportAllMutation = (trpc as any).dataExport?.exportAll?.useQuery?.(
    undefined,
    { enabled: false }
  ) || { refetch: async () => ({ data: null }), isLoading: false };

  const importAllMutation = (trpc as any).dataImport?.importAll?.useMutation?.({
    onSuccess: (result: any) => {
      showSuccess(
        "تم استيراد البيانات بنجاح!",
        `تم استيراد: ${result?.imported?.assets || 0} أصول، ${result?.imported?.predictions || 0} توقعات، ${result?.imported?.alerts || 0} تنبيهات`
      );
      setImportResult(result);
      setImporting(false);
      setImportProgress(100);
    },
    onError: (error: any) => {
      showError("فشل استيراد البيانات", error?.message || "حدث خطأ غير متوقع");
      setImporting(false);
      setImportProgress(0);
    },
  }) || { mutateAsync: async () => {}, isPending: false };

  const handleExportJSON = async () => {
    const promise = exportAllMutation.refetch().then((result: any) => {
      if (result.data) {
        const blob = new Blob([JSON.stringify(result.data, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `gold-predictor-export-${new Date().toISOString().split("T")[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return result.data;
      }
      throw new Error("لا توجد بيانات للتصدير");
    });

    showPromise(promise, {
      loading: "جاري تصدير البيانات...",
      success: "تم تصدير البيانات بنجاح!",
      error: "فشل تصدير البيانات",
    });
  };

  const handleExportCSV = async () => {
    const promise = exportAllMutation.refetch().then((result: any) => {
      if (result.data) {
        const assets = result.data.data?.assets || [];
        const predictions = result.data.data?.predictions || [];
        const alerts = result.data.data?.alerts || [];

        let csv = "";

        if (assets.length > 0) {
          csv += "ASSETS\n";
          csv += Object.keys(assets[0]).join(",") + "\n";
          assets.forEach((asset: any) => {
            csv += Object.values(asset).join(",") + "\n";
          });
          csv += "\n";
        }

        if (predictions.length > 0) {
          csv += "PREDICTIONS\n";
          csv += Object.keys(predictions[0]).join(",") + "\n";
          predictions.forEach((pred: any) => {
            csv += Object.values(pred).join(",") + "\n";
          });
          csv += "\n";
        }

        if (alerts.length > 0) {
          csv += "ALERTS\n";
          csv += Object.keys(alerts[0]).join(",") + "\n";
          alerts.forEach((alert: any) => {
            csv += Object.values(alert).join(",") + "\n";
          });
        }

        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `gold-predictor-export-${new Date().toISOString().split("T")[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return result.data;
      }
      throw new Error("لا توجد بيانات للتصدير");
    });

    showPromise(promise, {
      loading: "جاري تصدير البيانات كـ CSV...",
      success: "تم تصدير CSV بنجاح!",
      error: "فشل تصدير CSV",
    });
  };

  const handleImportJSON = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) {return;}

      setImporting(true);
      setImportProgress(10);

      try {
        const text = await file.text();
        setImportProgress(30);
        
        const data = JSON.parse(text);
        setImportProgress(50);

        if (!data.data) {
          throw new Error("صيغة الملف غير صحيحة");
        }

        setImportProgress(70);
        await importAllMutation.mutateAsync({ data: data.data });
      } catch (error: any) {
        showError("فشل استيراد البيانات", error.message);
        setImporting(false);
        setImportProgress(0);
      }
    };
    input.click();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4" dir="rtl">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="p-4 rounded-full bg-amber-100 dark:bg-amber-900/30 w-fit mx-auto mb-4">
              <Shield className="h-12 w-12 text-amber-600" />
            </div>
            <h2 className="text-xl font-bold mb-2">تسجيل الدخول مطلوب</h2>
            <p className="text-muted-foreground mb-6">
              يرجى تسجيل الدخول للوصول إلى ميزات إدارة البيانات
            </p>
            <Button onClick={() => navigate("/login")}>
              تسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Database className="h-6 w-6 text-primary" />
                  إدارة البيانات
                </h1>
                <p className="text-sm text-muted-foreground">
                  تصدير واستيراد البيانات للنسخ الاحتياطي والترحيل
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="hidden sm:flex">
                <Clock className="h-3 w-3 ml-1" />
                آخر نسخ احتياطي: اليوم
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8"
        >
          <StatCard icon={Database} label="إجمالي السجلات" value="1,234" color="primary" />
          <StatCard icon={HardDrive} label="حجم البيانات" value="45 MB" color="success" />
          <StatCard icon={History} label="النسخ الاحتياطية" value="12" color="warning" />
          <StatCard icon={Shield} label="حالة الأمان" value="آمن" color="success" />
        </motion.div>

        <Tabs defaultValue="export" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="export" className="gap-2">
              <Download className="h-4 w-4" />
              تصدير
            </TabsTrigger>
            <TabsTrigger value="import" className="gap-2">
              <Upload className="h-4 w-4" />
              استيراد
            </TabsTrigger>
            <TabsTrigger value="backup" className="gap-2">
              <FileArchive className="h-4 w-4" />
              النسخ
            </TabsTrigger>
          </TabsList>

          {/* Export Tab */}
          <TabsContent value="export">
            <div className="grid gap-6 lg:grid-cols-3">
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 }}
                className="lg:col-span-2 space-y-4"
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Download className="h-5 w-5 text-primary" />
                      تصدير البيانات
                    </CardTitle>
                    <CardDescription>
                      قم بتنزيل بياناتك بصيغة JSON أو CSV
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <ExportOptionCard
                      icon={FileJson}
                      title="تصدير كـ JSON"
                      description="يحافظ على بنية البيانات الكاملة، موصى به للنسخ الاحتياطي"
                      format="JSON"
                      onClick={handleExportJSON}
                      isLoading={exportAllMutation.isLoading}
                    />
                    <ExportOptionCard
                      icon={FileSpreadsheet}
                      title="تصدير كـ CSV"
                      description="مناسب للعرض في تطبيقات جداول البيانات"
                      format="CSV"
                      onClick={handleExportCSV}
                      isLoading={exportAllMutation.isLoading}
                    />
                  </CardContent>
                </Card>

                {/* Selective Export */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">تصدير انتقائي</CardTitle>
                    <CardDescription>اختر نوع البيانات للتصدير</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-3">
                      <Button variant="outline" className="h-20 flex-col gap-2">
                        <Database className="h-5 w-5 text-primary" />
                        <span className="text-xs">الأصول فقط</span>
                      </Button>
                      <Button variant="outline" className="h-20 flex-col gap-2">
                        <Sparkles className="h-5 w-5 text-primary" />
                        <span className="text-xs">التوقعات فقط</span>
                      </Button>
                      <Button variant="outline" className="h-20 flex-col gap-2">
                        <AlertCircle className="h-5 w-5 text-primary" />
                        <span className="text-xs">التنبيهات فقط</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Info Sidebar */}
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.2 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Info className="h-5 w-5 text-primary" />
                      معلومات
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm font-medium mb-1">صيغة JSON</p>
                      <p className="text-xs text-muted-foreground">
                        الأفضل للنسخ الاحتياطي الكامل واستعادة البيانات
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm font-medium mb-1">صيغة CSV</p>
                      <p className="text-xs text-muted-foreground">
                        مناسبة لتحليل البيانات في Excel أو Google Sheets
                      </p>
                    </div>
                    <Separator />
                    <Alert>
                      <Shield className="h-4 w-4" />
                      <AlertTitle>نصيحة أمنية</AlertTitle>
                      <AlertDescription className="text-xs">
                        احفظ ملفات التصدير في مكان آمن ولا تشاركها مع أي شخص
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Import Tab */}
          <TabsContent value="import">
            <div className="grid gap-6 lg:grid-cols-3">
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 }}
                className="lg:col-span-2"
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="h-5 w-5 text-primary" />
                      استيراد البيانات
                    </CardTitle>
                    <CardDescription>
                      قم بتحميل بيانات مصدرة سابقاً
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Upload Area */}
                    <div
                      className="border-2 border-dashed rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
                      onClick={handleImportJSON}
                    >
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <FolderOpen className="h-10 w-10 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">
                        {importing ? "جاري الاستيراد..." : "اضغط للاختيار أو اسحب الملف هنا"}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        يدعم ملفات JSON فقط
                      </p>
                      <Button className="mt-4" disabled={importing}>
                        {importing ? (
                          <>
                            <RefreshCw className="ml-2 h-4 w-4 animate-spin" />
                            جاري الاستيراد...
                          </>
                        ) : (
                          <>
                            <Upload className="ml-2 h-4 w-4" />
                            اختيار ملف
                          </>
                        )}
                      </Button>
                    </div>

                    {/* Progress */}
                    {importing && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>تقدم الاستيراد</span>
                          <span>{importProgress}%</span>
                        </div>
                        <Progress value={importProgress} className="h-2" />
                      </div>
                    )}

                    {/* Import Result */}
                    {importResult && (
                      <Alert className="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                        <AlertTitle className="text-emerald-700 dark:text-emerald-400">
                          تم الاستيراد بنجاح!
                        </AlertTitle>
                        <AlertDescription>
                          <ul className="mt-2 space-y-1 text-sm">
                            <li>• {importResult.imported?.assets || 0} أصول</li>
                            <li>• {importResult.imported?.predictions || 0} توقعات</li>
                            <li>• {importResult.imported?.alerts || 0} تنبيهات</li>
                          </ul>
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Warning Sidebar */}
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.2 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-amber-600" />
                      تحذيرات
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Alert className="bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800">
                      <AlertTriangle className="h-4 w-4 text-amber-600" />
                      <AlertDescription className="text-sm">
                        استيراد البيانات سيضيف سجلات جديدة. قد يتم إنشاء
                        إدخالات مكررة إذا تم استيراد نفس الملف عدة مرات.
                      </AlertDescription>
                    </Alert>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm font-medium mb-1">قبل الاستيراد</p>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>• تأكد من أن الملف من مصدر موثوق</li>
                        <li>• قم بعمل نسخة احتياطية من بياناتك الحالية</li>
                        <li>• تحقق من صيغة الملف (JSON)</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Backup Tab */}
          <TabsContent value="backup">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileArchive className="h-5 w-5 text-primary" />
                    النسخ الاحتياطية
                  </CardTitle>
                  <CardDescription>
                    إدارة النسخ الاحتياطية التلقائية والمجدولة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                      <Settings className="h-12 w-12 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">قريباً</h3>
                    <p className="text-muted-foreground mb-6">
                      ميزة النسخ الاحتياطي التلقائي قيد التطوير
                    </p>
                    <Button variant="outline" onClick={() => navigate("/settings")}>
                      <Settings className="ml-2 h-4 w-4" />
                      إعدادات النسخ الاحتياطي
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
