/**
 * AI Tasks Page - Premium Gold Price Predictor
 * Scheduled AI tasks management dashboard
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import {
  Calendar,
  CheckCircle,
  Clock,
  Play,
  Plus,
  XCircle,
  ArrowLeft,
  Sparkles,
  Zap,
  Activity,
  Brain,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const TASK_TYPES = [
  { value: "price_analysis", label: "تحليل الأسعار" },
  { value: "portfolio_report", label: "تقرير المحفظة" },
  { value: "news_summary", label: "ملخص الأخبار" },
  { value: "prediction_update", label: "تحديث التوقعات" },
  { value: "alert_check", label: "فحص التنبيهات" },
  { value: "custom_query", label: "استعلام مخصص" },
];

const SCHEDULE_TYPES = [
  { value: "daily", label: "يومي" },
  { value: "weekly", label: "أسبوعي" },
  { value: "monthly", label: "شهري" },
  { value: "custom", label: "مخصص (cron)" },
];

export default function AITasks() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const {
    data: tasks,
    isLoading,
    refetch,
  } = trpc.aiTasks.list.useQuery(undefined, {
    enabled: !!user,
  });

  const { data: schedulerStatus } = trpc.aiTasks.getSchedulerStatus.useQuery();

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-hero" dir="rtl">
        <div className="container py-8">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="grid gap-6">
            <Skeleton className="h-64" />
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center" dir="rtl">
        <Card className="premium-card max-w-md">
          <CardContent className="py-16 text-center">
            <h1 className="text-3xl font-bold mb-4">يرجى تسجيل الدخول</h1>
            <p className="text-muted-foreground mb-8">
              يجب تسجيل الدخول لعرض المهام المجدولة
            </p>
            <Button onClick={() => navigate("/login")}>تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  المهام المجدولة للذكاء الصناعي
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة المهام التلقائية للمساعد الذكي
                </p>
              </div>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء مهمة جديدة
                </Button>
              </DialogTrigger>
              <CreateTaskDialog
                onClose={() => setIsCreateDialogOpen(false)}
                onSuccess={refetch}
              />
            </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Scheduler Status */}
        {schedulerStatus && (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            className="mb-8"
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  حالة المجدول
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">الحالة</p>
                    <p className="text-lg font-semibold">
                      {schedulerStatus.isInitialized ? "يعمل" : "متوقف"}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">المهام النشطة</p>
                    <p className="text-lg font-semibold">
                      {schedulerStatus.activeJobs || 0}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">المهام المجدولة</p>
                    <p className="text-lg font-semibold">
                      {schedulerStatus.jobIds?.length || 0}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">آخر تحديث</p>
                    <p className="text-lg font-semibold">
                      {new Date().toLocaleTimeString("ar-EG")}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Tasks List */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                المهام
              </CardTitle>
              <CardDescription>جميع المهام المجدولة</CardDescription>
            </CardHeader>
            <CardContent>
              {tasks && tasks.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الاسم</TableHead>
                        <TableHead>النوع</TableHead>
                        <TableHead>الجدولة</TableHead>
                        <TableHead>الحالة</TableHead>
                        <TableHead>آخر تشغيل</TableHead>
                        <TableHead>التشغيل القادم</TableHead>
                        <TableHead>الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tasks.map((task: any) => (
                        <TaskRow
                          key={(task as any).id}
                          task={task as any}
                          onSuccess={refetch}
                        />
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="py-16 text-center text-muted-foreground">
                  <Calendar className="mx-auto h-16 w-16 mb-4 opacity-50" />
                  <p className="mb-4">لا توجد مهام مجدولة</p>
                  <Button data-testid="create-first-task-button" onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="ml-2 h-4 w-4" />
                    إنشاء مهمة أولى
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}

function TaskRow({ task, onSuccess }: { task: any; onSuccess: () => void }) {
  const [showResults, setShowResults] = useState(false);

  const { data: results } = trpc.aiTasks.getResults.useQuery(
    { taskId: task.id },
    { enabled: showResults }
  );

  const triggerMutation = trpc.aiTasks.triggerNow.useMutation({
    onSuccess: () => {
      toast.success("تم تشغيل المهمة بنجاح");
      onSuccess();
    },
    onError: (error) => {
      toast.error(`فشل تشغيل المهمة: ${error.message}`);
    },
  });

  const deleteMutation = trpc.aiTasks.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المهمة");
      onSuccess();
    },
  });

  const taskType =
    TASK_TYPES.find((t) => t.value === task.taskType)?.label || task.taskType;
  const scheduleType =
    SCHEDULE_TYPES.find((s) => s.value === task.scheduleType)?.label ||
    task.scheduleType;

  return (
    <>
      <TableRow>
        <TableCell className="font-medium">{task.taskName}</TableCell>
        <TableCell>
          <Badge variant="outline">{taskType}</Badge>
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{scheduleType}</span>
          </div>
        </TableCell>
        <TableCell>
          {task.isActive ? (
            <Badge className="bg-emerald-500 text-white flex items-center gap-1 w-fit">
              <CheckCircle className="h-3 w-3" />
              نشط
            </Badge>
          ) : (
            <Badge variant="secondary" className="flex items-center gap-1 w-fit">
              <XCircle className="h-3 w-3" />
              معطل
            </Badge>
          )}
        </TableCell>
        <TableCell className="text-sm text-muted-foreground">
          {task.lastRun
            ? new Date(task.lastRun).toLocaleString("ar-EG")
            : "-"}
        </TableCell>
        <TableCell className="text-sm text-muted-foreground">
          {task.nextRun
            ? new Date(task.nextRun).toLocaleString("ar-EG")
            : "-"}
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => triggerMutation.mutate({ taskId: task.id })}
              disabled={triggerMutation.isPending}
            >
              <Play className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowResults(!showResults)}
            >
              {showResults ? "إخفاء" : "النتائج"}
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => deleteMutation.mutate({ taskId: task.id })}
              disabled={deleteMutation.isPending}
            >
              حذف
            </Button>
          </div>
        </TableCell>
      </TableRow>
      {showResults && results && results.length > 0 && (
        <TableRow>
          <TableCell colSpan={7}>
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <h4 className="font-semibold mb-2">نتائج التنفيذ (آخر 5)</h4>
              {results.slice(0, 5).map((result: any) => (
                <div
                  key={result.id}
                  className="border-r-2 border-primary pr-4 mb-3"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">
                      {new Date(result.createdAt).toLocaleString("ar-EG")}
                    </span>
                    <Badge
                      variant={
                        result.status === "success"
                          ? "default"
                          : result.status === "error"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {result.status === "success"
                        ? "نجح"
                        : result.status === "error"
                        ? "خطأ"
                        : "قيد التنفيذ"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {result.result}
                  </p>
                  {result.executionTime && (
                    <p className="text-xs text-muted-foreground mt-1">
                      وقت التنفيذ: {result.executionTime}ms
                    </p>
                  )}
                </div>
              ))}
            </div>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

function CreateTaskDialog({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [taskName, setTaskName] = useState("");
  const [taskType, setTaskType] = useState("price_analysis");
  const [scheduleType, setScheduleType] = useState("daily");
  const [cronExpression, setCronExpression] = useState("0 0 9 * * *");
  const [description, setDescription] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");

  const createMutation = trpc.aiTasks.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء المهمة بنجاح");
      onSuccess();
      onClose();
    },
    onError: (error) => {
      toast.error(`فشل إنشاء المهمة: ${error.message}`);
    },
  });

  const handleSubmit = () => {
    if (!taskName.trim()) {
      toast.error("يرجى إدخال اسم المهمة");
      return;
    }

    createMutation.mutate({
      taskName,
      taskType: taskType as any,
      scheduleType: scheduleType as any,
      cronExpression: (scheduleType === "custom"
        ? cronExpression
        : "0 0 * * *") as string,
      description: description || undefined,
      parameters:
        taskType === "custom_query" && customPrompt
          ? JSON.stringify({ prompt: customPrompt })
          : undefined,
      assistantId: 2, // Paid AI (Goldy)
      isActive: true,
    });
  };

  return (
    <DialogContent className="max-w-2xl" dir="rtl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5 text-primary" />
          إنشاء مهمة مجدولة جديدة
        </DialogTitle>
        <DialogDescription>أنشئ مهمة تلقائية للمساعد الذكي</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-4">
        <div className="space-y-2">
          <Label htmlFor="taskName">اسم المهمة *</Label>
          <Input
            id="taskName"
            placeholder="مثال: تحليل يومي للذهب"
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="taskType">نوع المهمة *</Label>
            <Select value={taskType} onValueChange={setTaskType}>
              <SelectTrigger data-testid="task-type-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TASK_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="scheduleType">نوع الجدولة *</Label>
            <Select value={scheduleType} onValueChange={setScheduleType}>
              <SelectTrigger data-testid="schedule-type-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SCHEDULE_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {scheduleType === "custom" && (
          <div className="space-y-2">
            <Label htmlFor="cronExpression">تعبير Cron *</Label>
            <Input
              id="cronExpression"
              placeholder="0 0 9 * * * (كل يوم الساعة 9 صباحاً)"
              value={cronExpression}
              onChange={(e) => setCronExpression(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              صيغة: ثانية دقيقة ساعة يوم_الشهر شهر يوم_الأسبوع
            </p>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="description">الوصف (اختياري)</Label>
          <Textarea
            id="description"
            placeholder="وصف المهمة..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
          />
        </div>

        {taskType === "custom_query" && (
          <div className="space-y-2">
            <Label htmlFor="customPrompt">الاستعلام المخصص *</Label>
            <Textarea
              id="customPrompt"
              placeholder="مثال: قم بتحليل أداء الذهب خلال الأسبوع الماضي وقدم توصيات"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              rows={3}
            />
          </div>
        )}

        <div className="bg-muted p-4 rounded-lg">
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <Zap className="h-4 w-4 text-primary" />
            معلومات
          </h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• سيتم تشغيل المهمة تلقائياً حسب الجدولة</li>
            <li>• يمكنك تشغيل المهمة يدوياً في أي وقت</li>
            <li>• سيتم حفظ نتائج كل تنفيذ</li>
            <li>• يمكنك تعطيل المهمة مؤقتاً</li>
          </ul>
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onClose}>
          إلغاء
        </Button>
        <Button
          onClick={handleSubmit}
          disabled={
            createMutation.isPending ||
            !taskName.trim() ||
            (taskType === "custom_query" && !customPrompt.trim())
          }
        >
          {createMutation.isPending ? "جاري الإنشاء..." : "إنشاء"}
        </Button>
      </div>
    </DialogContent>
  );
}
