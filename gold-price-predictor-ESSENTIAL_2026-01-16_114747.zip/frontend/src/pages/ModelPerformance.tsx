/**
 * Model Performance Page - Premium Gold Price Predictor
 * Model performance comparison and analysis dashboard
 */

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Award,
  Download,
  ArrowLeft,
  Sparkles,
  Target,
  BarChart3,
  CheckCircle2,
  Zap,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

/**
 * Model Performance Comparison Dashboard
 * Compare accuracy and performance of all ML models
 */
export default function ModelPerformance() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState("GOLD");
  const [timeRange, setTimeRange] = useState("30");

  // Mock data - replace with real tRPC calls
  const models = [
    {
      id: "lstm_001",
      name: "LSTM Model",
      type: "LSTM",
      accuracy: 94.5,
      mae: 8.2,
      rmse: 11.5,
      r2: 0.92,
      trainedOn: "2024-11-15",
      status: "active",
      predictions: 1250,
    },
    {
      id: "gru_001",
      name: "GRU Model",
      type: "GRU",
      accuracy: 93.8,
      mae: 9.1,
      rmse: 12.3,
      r2: 0.91,
      trainedOn: "2024-11-14",
      status: "active",
      predictions: 1180,
    },
    {
      id: "transformer_001",
      name: "Transformer Model",
      type: "Transformer",
      accuracy: 95.2,
      mae: 7.5,
      rmse: 10.8,
      r2: 0.93,
      trainedOn: "2024-11-16",
      status: "active",
      predictions: 980,
    },
    {
      id: "ensemble_001",
      name: "Ensemble Model",
      type: "Ensemble",
      accuracy: 96.1,
      mae: 6.8,
      rmse: 9.9,
      r2: 0.95,
      trainedOn: "2024-11-17",
      status: "active",
      predictions: 1420,
    },
  ];

  // Performance comparison data
  const comparisonData = [
    {
      metric: "الدقة (%)",
      LSTM: 94.5,
      GRU: 93.8,
      Transformer: 95.2,
      Ensemble: 96.1,
    },
    { metric: "MAE", LSTM: 8.2, GRU: 9.1, Transformer: 7.5, Ensemble: 6.8 },
    {
      metric: "RMSE",
      LSTM: 11.5,
      GRU: 12.3,
      Transformer: 10.8,
      Ensemble: 9.9,
    },
    { metric: "R² Score", LSTM: 0.92, GRU: 0.91, Transformer: 0.93, Ensemble: 0.95 },
  ];

  // Historical accuracy over time
  const accuracyHistory = [
    { date: "الأسبوع 1", LSTM: 91.2, GRU: 90.5, Transformer: 92.1, Ensemble: 93.5 },
    { date: "الأسبوع 2", LSTM: 92.5, GRU: 91.8, Transformer: 93.4, Ensemble: 94.2 },
    { date: "الأسبوع 3", LSTM: 93.8, GRU: 92.9, Transformer: 94.5, Ensemble: 95.1 },
    { date: "الأسبوع 4", LSTM: 94.5, GRU: 93.8, Transformer: 95.2, Ensemble: 96.1 },
  ];

  const getBestModel = () => {
    return models.reduce((best, current) =>
      current.accuracy > best.accuracy ? current : best
    );
  };

  const bestModel = getBestModel();

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  مقارنة أداء النماذج
                </h1>
                <p className="text-sm text-muted-foreground">
                  مقارنة الدقة ومقاييس الأداء عبر جميع نماذج التعلم الآلي
                </p>
              </div>
            </div>
            <Button variant="outline" size="sm">
              <Download className="ml-2 h-4 w-4" />
              تصدير التقرير
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium mb-2 block">الأصل</label>
                  <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                    <SelectTrigger data-testid="performance-asset-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GOLD">Gold (XAU/USD)</SelectItem>
                      <SelectItem value="BTC">Bitcoin (BTC/USD)</SelectItem>
                      <SelectItem value="ETH">Ethereum (ETH/USD)</SelectItem>
                      <SelectItem value="SPY">S&P 500 (SPY)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1">
                  <label className="text-sm font-medium mb-2 block">النطاق الزمني</label>
                  <Select value={timeRange} onValueChange={setTimeRange}>
                    <SelectTrigger data-testid="performance-time-range-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">آخر 7 أيام</SelectItem>
                      <SelectItem value="30">آخر 30 يوم</SelectItem>
                      <SelectItem value="90">آخر 90 يوم</SelectItem>
                      <SelectItem value="365">آخر سنة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Best Model Highlight */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="premium-card border-primary">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-primary" />
                <CardTitle>أفضل نموذج أداء</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold">{bestModel.name}</h3>
                  <p className="text-muted-foreground">
                    {bestModel.type} Architecture
                  </p>
                </div>
                <div className="text-left">
                  <div className="text-3xl font-bold text-primary">
                    {bestModel.accuracy}%
                  </div>
                  <p className="text-sm text-muted-foreground">الدقة</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-sm text-muted-foreground">MAE</p>
                  <p className="text-lg font-semibold">{bestModel.mae}</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-sm text-muted-foreground">RMSE</p>
                  <p className="text-lg font-semibold">{bestModel.rmse}</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-sm text-muted-foreground">R² Score</p>
                  <p className="text-lg font-semibold">{bestModel.r2}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Models Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {models.map((model, index) => (
            <motion.div
              key={model.id}
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 * index }}
            >
              <Card className="stat-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{model.type}</CardTitle>
                    <Badge
                      variant={model.id === bestModel.id ? "default" : "secondary"}
                    >
                      {model.id === bestModel.id ? "الأفضل" : "نشط"}
                    </Badge>
                  </div>
                  <CardDescription>{model.name}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span className="text-sm text-muted-foreground">الدقة</span>
                      <span className="font-semibold">{model.accuracy}%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span className="text-sm text-muted-foreground">MAE</span>
                      <span className="font-semibold">{model.mae}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span className="text-sm text-muted-foreground">RMSE</span>
                      <span className="font-semibold">{model.rmse}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span className="text-sm text-muted-foreground">R² Score</span>
                      <span className="font-semibold">{model.r2}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground">
                        {model.predictions} توقعات
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Detailed Comparison */}
        <Tabs defaultValue="metrics" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="metrics">مقارنة المقاييس</TabsTrigger>
            <TabsTrigger value="accuracy">تاريخ الدقة</TabsTrigger>
            <TabsTrigger value="predictions">تحليل التوقعات</TabsTrigger>
          </TabsList>

          <TabsContent value="metrics" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.2 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    مقارنة مقاييس الأداء
                  </CardTitle>
                  <CardDescription>
                    مقارنة مؤشرات الأداء الرئيسية عبر جميع النماذج
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={comparisonData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="metric" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="LSTM" fill="oklch(0.65 0.18 70)" />
                      <Bar dataKey="GRU" fill="oklch(0.72 0.19 145)" />
                      <Bar dataKey="Transformer" fill="oklch(0.82 0.18 85)" />
                      <Bar dataKey="Ensemble" fill="oklch(0.55 0.22 25)" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="accuracy" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.3 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    الدقة عبر الزمن
                  </CardTitle>
                  <CardDescription>
                    تتبع تحسن دقة النموذج مع مرور الوقت
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={accuracyHistory}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="date" />
                      <YAxis domain={[85, 100]} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="LSTM"
                        stroke="oklch(0.65 0.18 70)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="GRU"
                        stroke="oklch(0.72 0.19 145)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="Transformer"
                        stroke="oklch(0.82 0.18 85)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="Ensemble"
                        stroke="oklch(0.55 0.22 25)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="predictions" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-primary" />
                    تحليل التوقعات
                  </CardTitle>
                  <CardDescription>
                    تحليل مفصل لدقة التوقعات والأخطاء
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>تحليل التوقعات قريباً</p>
                    <p className="text-sm mt-2">
                      سيتم عرض مقارنات مفصلة بين التوقعات والقيم الفعلية
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
