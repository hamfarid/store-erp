/**
 * Comprehensive Management Page - Premium Gold Price Predictor
 * All-in-one interface for: Notifications, Reports, KPIs, Activity, AI, Risk
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  Bell,
  FileText,
  TrendingUp,
  Activity,
  Brain,
  Shield,
  Download,
  Send,
  AlertTriangle,
  CheckCircle,
  XCircle,
  BarChart3,
  PieChart,
  LineChart,
  Briefcase,
  ArrowLeft,
  Sparkles,
  Target,
  DollarSign,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "",
  color = "primary",
  trend,
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  trend?: "up" | "down";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${colors[color]}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">
                  {value}
                  {suffix && <span className="text-sm font-normal text-muted-foreground">{suffix}</span>}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function ComprehensiveManagement() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  // Queries
  const { data: notifications } =
    trpc.comprehensive.notifications.getAll.useQuery({ limit: 10 });
  const { data: kpis } = trpc.comprehensive.kpis.getCurrent.useQuery();
  const { data: activity } = trpc.comprehensive.activity.getHistory.useQuery({
    limit: 20,
  });

  // Mutations
  const generateReport = trpc.comprehensive.reports.generate.useMutation();
  const calculateRisk = trpc.comprehensive.risk.calculateProfile.useMutation();
  const generateAI = trpc.comprehensive.ai.generateRecommendation.useMutation();

  const handleGenerateReport = async (type: string, format: string) => {
    try {
      const result = await generateReport.mutateAsync({
        name: `${type}_report_${Date.now()}`,
        type: type as any,
        format: format as any,
      });
      toast.success("تم إنشاء التقرير بنجاح");
    } catch (error) {
      toast.error("فشل إنشاء التقرير");
    }
  };

  const handleCalculateRisk = async () => {
    try {
      const result = await calculateRisk.mutateAsync({});
      toast.success(`مستوى المخاطر: ${result?.riskLevel || "غير محدد"}`);
    } catch (error) {
      toast.error("فشل حساب المخاطر");
    }
  };

  const handleGenerateAI = async () => {
    try {
      await generateAI.mutateAsync({});
      toast.success("تم إنشاء توصيات AI");
    } catch (error) {
      toast.error("فشل إنشاء التوصيات");
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>يرجى تسجيل الدخول</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Briefcase className="h-6 w-6 text-primary" />
                  نظام الإدارة الشامل
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة متكاملة للإشعارات، التقارير، المؤشرات، النشاط، AI، والمخاطر
                </p>
              </div>
            </div>
            <Button
              onClick={() => handleGenerateReport("portfolio", "pdf")}
              size="sm"
            >
              <Download className="ml-2 h-4 w-4" />
              تقرير سريع
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <StatCard
            icon={Bell}
            label="الإشعارات"
            value={notifications?.length || 0}
            suffix=" إشعار جديد"
            color="primary"
            delay={0}
          />
          <StatCard
            icon={TrendingUp}
            label="ROI"
            value={kpis?.roi ? `${kpis.roi.toFixed(2)}%` : "0%"}
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={BarChart3}
            label="معدل النجاح"
            value={kpis?.winRate ? `${kpis.winRate.toFixed(1)}%` : "0%"}
            color="success"
            delay={0.2}
          />
          <StatCard
            icon={Activity}
            label="النشاط"
            value={activity?.length || 0}
            suffix=" عملية اليوم"
            color="primary"
            delay={0.3}
          />
        </div>

        {/* Main Tabs */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="notifications">الإشعارات</TabsTrigger>
            <TabsTrigger value="reports">التقارير</TabsTrigger>
            <TabsTrigger value="kpis">المؤشرات</TabsTrigger>
            <TabsTrigger value="ai">AI</TabsTrigger>
            <TabsTrigger value="risk">المخاطر</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* KPI Summary */}
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.1 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-primary" />
                      ملخص المؤشرات الرئيسية
                    </CardTitle>
                    <CardDescription>أداء المحفظة الحالي</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {kpis ? (
                      <>
                        <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                          <span>القيمة الإجمالية:</span>
                          <span className="font-bold">
                            ${kpis.totalValue?.toFixed(2) || 0}
                          </span>
                        </div>
                        <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                          <span>المستثمر:</span>
                          <span>${kpis.totalInvested?.toFixed(2) || 0}</span>
                        </div>
                        <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                          <span>الربح:</span>
                          <span className="text-emerald-600 font-bold">
                            +${kpis.totalProfit?.toFixed(2) || 0}
                          </span>
                        </div>
                        <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                          <span>الخسارة:</span>
                          <span className="text-red-600">
                            -${kpis.totalLoss?.toFixed(2) || 0}
                          </span>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center pt-2">
                          <span className="font-bold">ROI:</span>
                          <Badge variant={kpis.roi > 0 ? "default" : "destructive"}>
                            {kpis.roi?.toFixed(2)}%
                          </Badge>
                        </div>
                      </>
                    ) : (
                      <p className="text-muted-foreground">جاري التحميل...</p>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.2 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5 text-primary" />
                      النشاط الأخير
                    </CardTitle>
                    <CardDescription>آخر 5 عمليات</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {activity?.slice(0, 5).map((item: any, index: number) => (
                        <div
                          key={index}
                          className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 text-sm"
                        >
                          <Activity className="h-4 w-4 mt-0.5 text-muted-foreground" />
                          <div className="flex-1">
                            <p className="font-medium">{item.action}</p>
                            <p className="text-muted-foreground text-xs">
                              {item.entityType} -{" "}
                              {new Date(item.timestamp).toLocaleString("ar-EG")}
                            </p>
                          </div>
                        </div>
                      ))}
                      {(!activity || activity.length === 0) && (
                        <p className="text-muted-foreground text-center py-4">
                          لا يوجد نشاط
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Quick Actions */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.3 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-primary" />
                    إجراءات سريعة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3 md:grid-cols-3">
                    <Button
                      onClick={() => handleGenerateReport("portfolio", "pdf")}
                      disabled={(generateReport as any).isPending}
                    >
                      <FileText className="ml-2 h-4 w-4" />
                      تقرير المحفظة
                    </Button>
                    <Button
                      onClick={handleCalculateRisk}
                      disabled={(calculateRisk as any).isPending}
                      variant="outline"
                    >
                      <Shield className="ml-2 h-4 w-4" />
                      تقييم المخاطر
                    </Button>
                    <Button
                      onClick={handleGenerateAI}
                      disabled={(generateAI as any).isPending}
                      variant="outline"
                    >
                      <Brain className="ml-2 h-4 w-4" />
                      توصيات AI
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5 text-primary" />
                    الإشعارات
                  </CardTitle>
                  <CardDescription>جميع إشعاراتك في مكان واحد</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {notifications?.map((notif: any) => (
                      <div
                        key={notif.id}
                        className="flex items-start gap-3 p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <Bell className="h-5 w-5 mt-0.5 text-primary" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{notif.title}</h4>
                            <Badge
                              variant={
                                notif.status === "read" ? "secondary" : "default"
                              }
                            >
                              {notif.status === "read" ? "مقروء" : "جديد"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {notif.message}
                          </p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {new Date(notif.createdAt).toLocaleString("ar-EG")}
                          </p>
                        </div>
                      </div>
                    ))}
                    {(!notifications || notifications.length === 0) && (
                      <p className="text-center text-muted-foreground py-8">
                        لا توجد إشعارات
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    إنشاء تقارير
                  </CardTitle>
                  <CardDescription>اختر نوع التقرير والصيغة</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    {[
                      {
                        type: "portfolio",
                        label: "تقرير المحفظة",
                        icon: Briefcase,
                      },
                      {
                        type: "price_analysis",
                        label: "تحليل الأسعار",
                        icon: LineChart,
                      },
                      { type: "predictions", label: "التوقعات", icon: TrendingUp },
                      { type: "alerts", label: "التنبيهات", icon: Bell },
                    ].map((report) => (
                      <Card key={report.type} className="stat-card">
                        <CardHeader>
                          <CardTitle className="text-base flex items-center gap-2">
                            <report.icon className="h-4 w-4 text-primary" />
                            {report.label}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() =>
                                handleGenerateReport(report.type, "pdf")
                              }
                              disabled={(generateReport as any).isPending}
                            >
                              PDF
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                handleGenerateReport(report.type, "excel")
                              }
                              disabled={(generateReport as any).isPending}
                            >
                              Excel
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                handleGenerateReport(report.type, "csv")
                              }
                              disabled={(generateReport as any).isPending}
                            >
                              CSV
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* KPIs Tab */}
          <TabsContent value="kpis" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    المؤشرات التنفيذية
                  </CardTitle>
                  <CardDescription>مؤشرات الأداء الرئيسية</CardDescription>
                </CardHeader>
                <CardContent>
                  {kpis ? (
                    <div className="grid gap-4 md:grid-cols-3">
                      {[
                        { label: "ROI", value: kpis.roi?.toFixed(2), suffix: "%" },
                        { label: "Win Rate", value: kpis.winRate?.toFixed(1), suffix: "%" },
                        { label: "Profit Factor", value: kpis.profitFactor?.toFixed(2) },
                        { label: "متوسط الربح", value: `$${kpis.avgProfit?.toFixed(2)}`, color: "emerald" },
                        { label: "متوسط الخسارة", value: `$${kpis.avgLoss?.toFixed(2)}`, color: "red" },
                        { label: "صافي الربح", value: `$${(kpis.totalProfit - kpis.totalLoss).toFixed(2)}` },
                      ].map((kpi, index) => (
                        <Card key={index} className="stat-card">
                          <CardHeader>
                            <CardTitle className="text-sm">{kpi.label}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className={`text-3xl font-bold ${kpi.color === "emerald" ? "text-emerald-600" : kpi.color === "red" ? "text-red-600" : ""}`}>
                              {kpi.value}
                              {kpi.suffix && <span className="text-sm font-normal text-muted-foreground">{kpi.suffix}</span>}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">
                      جاري التحميل...
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* AI Tab */}
          <TabsContent value="ai" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    توصيات الذكاء الاصطناعي
                  </CardTitle>
                  <CardDescription>
                    توصيات ذكية بناءً على تحليل البيانات
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Brain className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">
                      قم بإنشاء توصيات ذكية بناءً على محفظتك الحالية
                    </p>
                    <Button
                      onClick={handleGenerateAI}
                      disabled={(generateAI as any).isPending}
                    >
                      <Brain className="ml-2 h-4 w-4" />
                      إنشاء توصيات
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Risk Tab */}
          <TabsContent value="risk" className="space-y-4">
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.1 }}
            >
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-primary" />
                    إدارة المخاطر
                  </CardTitle>
                  <CardDescription>تقييم وإدارة مخاطر المحفظة</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Shield className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">
                      احسب مستوى المخاطر الحالي للمحفظة
                    </p>
                    <Button
                      onClick={handleCalculateRisk}
                      disabled={(calculateRisk as any).isPending}
                    >
                      <Shield className="ml-2 h-4 w-4" />
                      تقييم المخاطر
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
