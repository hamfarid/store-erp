/**
 * Enhanced Dashboard - Premium Gold Price Predictor
 * Modern dashboard with comprehensive data visualization
 */

import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { trpc } from "@/lib/trpc";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  Bell,
  Target,
  BarChart3,
  ArrowRight,
  RefreshCw,
  Clock,
  Eye,
  Zap,
  Brain,
  LineChart,
  PieChart,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Globe,
} from "lucide-react";
import {
  LineChart as RechartsLineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 }
};

// Mock data for charts
const generateMockPriceData = () => {
  const data = [];
  let price = 2024;
  for (let i = 30; i >= 0; i--) {
    price = price + (Math.random() - 0.48) * 15;
    data.push({
      date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' }),
      price: parseFloat(price.toFixed(2)),
      predicted: parseFloat((price * (1 + (Math.random() - 0.5) * 0.02)).toFixed(2)),
    });
  }
  return data;
};

// Stats Card Component
function StatCard({ 
  icon: Icon, 
  title, 
  value, 
  change, 
  changeLabel, 
  trend,
  color = "primary",
  delay = 0 
}: { 
  icon: any;
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  trend?: "up" | "down" | "neutral";
  color?: "primary" | "success" | "warning" | "destructive";
  delay?: number;
}) {
  const colorClasses = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    destructive: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card h-full">
        <CardContent className="pt-6">
          <div className="flex items-start justify-between">
            <div className={`p-3 rounded-xl ${colorClasses[color]}`}>
              <Icon className="h-5 w-5" />
            </div>
            {change !== undefined && (
              <Badge variant={trend === "up" ? "default" : trend === "down" ? "destructive" : "secondary"} className="text-xs">
                {trend === "up" ? <ArrowUpRight className="h-3 w-3 mr-1" /> : trend === "down" ? <ArrowDownRight className="h-3 w-3 mr-1" /> : null}
                {change > 0 ? "+" : ""}{change}%
              </Badge>
            )}
          </div>
          <div className="mt-4">
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {changeLabel && (
              <p className="text-xs text-muted-foreground mt-1">{changeLabel}</p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Activity Item Component
function ActivityItem({ activity, index }: { activity: any; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
    >
      <div className={`p-2 rounded-lg ${
        activity.type === "prediction" ? "bg-blue-100 dark:bg-blue-900/30" :
        activity.type === "alert" ? "bg-amber-100 dark:bg-amber-900/30" :
        "bg-emerald-100 dark:bg-emerald-900/30"
      }`}>
        {activity.type === "prediction" ? <Brain className="h-4 w-4 text-blue-600" /> :
         activity.type === "alert" ? <Bell className="h-4 w-4 text-amber-600" /> :
         <CheckCircle2 className="h-4 w-4 text-emerald-600" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{activity.title}</p>
        <p className="text-xs text-muted-foreground">{activity.description}</p>
      </div>
      <div className="text-xs text-muted-foreground whitespace-nowrap">
        {activity.time}
      </div>
    </motion.div>
  );
}

// Chart colors
const CHART_COLORS = [
  "oklch(0.75 0.15 80)",  // Gold primary
  "oklch(0.65 0.18 70)",  // Gold dark
  "oklch(0.72 0.19 145)", // Success green
  "oklch(0.82 0.18 85)",  // Warning amber
  "oklch(0.65 0.18 250)", // Info blue
];

export default function DashboardEnhanced() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [refreshing, setRefreshing] = useState(false);
  const [priceData] = useState(generateMockPriceData);

  // Fetch data from APIs
  const { data: assets, refetch: refetchAssets } = trpc.assets.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const { data: predictions, refetch: refetchPredictions } =
    trpc.predictions.getHistory.useQuery(
      { limit: 100 },
      { enabled: isAuthenticated }
    );

  const { data: alerts, refetch: refetchAlerts } = (
    trpc.alerts as any
  ).getAll.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Calculate statistics
  const stats = {
    totalAssets: assets?.length || 0,
    totalPredictions: predictions?.length || 0,
    activePredictions: predictions?.filter(
      (p: any) => new Date(p.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ).length || 0,
    totalAlerts: alerts?.length || 0,
    activeAlerts: alerts?.filter((a: any) => a.isActive).length || 0,
    triggeredAlerts: alerts?.filter((a: any) => a.isTriggered).length || 0,
  };

  // Prepare chart data
  const predictionsByModel = predictions?.reduce((acc: Record<string, any>, pred: any) => {
    const model = pred.modelType || "unknown";
    if (!acc[model]) {
      acc[model] = { model, count: 0, avgAccuracy: 0, total: 0 };
    }
    acc[model].count++;
    if (pred.accuracy) {
      acc[model].total += parseFloat(pred.accuracy);
    }
    return acc;
  }, {});

  const modelChartData = predictionsByModel
    ? Object.values(predictionsByModel).map((item: any) => ({
        name: item.model,
        value: item.count,
        accuracy: item.total > 0 ? parseFloat((item.total / item.count).toFixed(2)) : 0,
      }))
    : [
        { name: "Ridge", value: 35, accuracy: 98.5 },
        { name: "LSTM", value: 45, accuracy: 99.2 },
        { name: "Ensemble", value: 20, accuracy: 99.7 },
      ];

  // Recent activity mock data
  const recentActivity = [
    { type: "prediction", title: "توقع جديد للذهب", description: "نموذج LSTM - دقة 99.2%", time: "منذ 5 دقائق" },
    { type: "alert", title: "تنبيه سعري", description: "وصل الذهب إلى $2,025", time: "منذ 15 دقيقة" },
    { type: "success", title: "تدريب مكتمل", description: "تم تحديث نموذج Ensemble", time: "منذ ساعة" },
    { type: "prediction", title: "توقع البيتكوين", description: "نموذج Ridge - دقة 97.8%", time: "منذ 2 ساعة" },
    { type: "alert", title: "تنبيه جديد", description: "تم إنشاء تنبيه للفضة", time: "منذ 3 ساعات" },
  ];

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchAssets(), refetchPredictions(), refetchAlerts()]);
    setTimeout(() => setRefreshing(false), 1000);
  };

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Sparkles className="h-6 w-6 text-primary" />
                لوحة التحكم
              </h1>
              <p className="text-sm text-muted-foreground">نظرة شاملة على جميع الأنظمة</p>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={handleRefresh} disabled={refreshing}>
                <RefreshCw className={`h-4 w-4 ml-2 ${refreshing ? "animate-spin" : ""}`} />
                تحديث
              </Button>
              <Badge variant="secondary" className="hidden md:flex">
                <Clock className="h-3 w-3 mr-1" />
                آخر تحديث: {new Date().toLocaleTimeString('ar-EG')}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Wallet}
            title="إجمالي الأصول"
            value={stats.totalAssets}
            change={12}
            changeLabel="من الشهر الماضي"
            trend="up"
            color="primary"
            delay={0}
          />
          <StatCard
            icon={Brain}
            title="التوقعات النشطة"
            value={stats.activePredictions}
            change={8}
            changeLabel={`من ${stats.totalPredictions} إجمالي`}
            trend="up"
            color="success"
            delay={0.1}
          />
          <StatCard
            icon={Bell}
            title="التنبيهات"
            value={stats.activeAlerts}
            change={-5}
            changeLabel={`${stats.triggeredAlerts} مُفعّلة`}
            trend="neutral"
            color="warning"
            delay={0.2}
          />
          <StatCard
            icon={Target}
            title="دقة النماذج"
            value="99.5%"
            change={2}
            changeLabel="متوسط الدقة"
            trend="up"
            color="success"
            delay={0.3}
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Price Chart - Large */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.4 }}
            className="lg:col-span-2"
          >
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <LineChart className="h-5 w-5 text-primary" />
                      سعر الذهب
                    </CardTitle>
                    <CardDescription>آخر 30 يوم مع التوقعات</CardDescription>
                  </div>
                  <Tabs defaultValue="1m" className="w-fit">
                    <TabsList className="h-8">
                      <TabsTrigger value="1w" className="text-xs px-2">أسبوع</TabsTrigger>
                      <TabsTrigger value="1m" className="text-xs px-2">شهر</TabsTrigger>
                      <TabsTrigger value="3m" className="text-xs px-2">3 أشهر</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={priceData}>
                    <defs>
                      <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.75 0.15 80)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="oklch(0.75 0.15 80)" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }} 
                      stroke="var(--muted-foreground)"
                    />
                    <YAxis 
                      domain={['auto', 'auto']} 
                      tick={{ fontSize: 12 }}
                      stroke="var(--muted-foreground)"
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'var(--card)',
                        border: '1px solid var(--border)',
                        borderRadius: '8px',
                      }}
                    />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="price"
                      name="السعر الفعلي"
                      stroke="oklch(0.75 0.15 80)"
                      strokeWidth={2}
                      fill="url(#priceGradient)"
                    />
                    <Area
                      type="monotone"
                      dataKey="predicted"
                      name="السعر المتوقع"
                      stroke="oklch(0.72 0.19 145)"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      fill="url(#predictedGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          {/* Model Distribution */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-primary" />
                  توزيع النماذج
                </CardTitle>
                <CardDescription>نسبة استخدام كل نموذج</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <RechartsPieChart>
                    <Pie
                      data={modelChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {modelChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-2">
                  {modelChartData.map((item, index) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                        />
                        <span>{item.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">{item.value}%</span>
                        <Badge variant="secondary" className="text-xs">
                          {item.accuracy}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5 text-primary" />
                      النشاط الأخير
                    </CardTitle>
                    <CardDescription>آخر التحديثات والأحداث</CardDescription>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => navigate("/history")}>
                    عرض الكل
                    <ArrowRight className="h-4 w-4 mr-2" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-3">
                    {recentActivity.map((activity, index) => (
                      <ActivityItem key={index} activity={activity} index={index} />
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.7 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  إجراءات سريعة
                </CardTitle>
                <CardDescription>الإجراءات الأكثر استخداماً</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { icon: TrendingUp, label: "توقع جديد", href: "/predict/1", color: "text-blue-500" },
                  { icon: Bell, label: "إضافة تنبيه", href: "/alerts/create", color: "text-amber-500" },
                  { icon: BarChart3, label: "عرض التقارير", href: "/reports", color: "text-emerald-500" },
                  { icon: Brain, label: "تدريب النماذج", href: "/admin/train-models", color: "text-purple-500" },
                  { icon: Globe, label: "الأصول المالية", href: "/assets", color: "text-rose-500" },
                ].map((action, index) => (
                  <motion.div
                    key={action.href}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + index * 0.05 }}
                  >
                    <Link href={action.href}>
                      <Button
                        variant="ghost"
                        className="w-full justify-between h-12 hover:bg-primary/5"
                      >
                        <div className="flex items-center gap-3">
                          <action.icon className={`h-4 w-4 ${action.color}`} />
                          <span>{action.label}</span>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </Link>
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Performance Overview */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.8 }}
          className="mt-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                أداء النماذج
              </CardTitle>
              <CardDescription>مقارنة دقة النماذج المختلفة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "LSTM", accuracy: 99.2, color: "bg-primary" },
                  { name: "Ensemble", accuracy: 99.7, color: "bg-emerald-500" },
                  { name: "Ridge", accuracy: 98.5, color: "bg-amber-500" },
                ].map((model, index) => (
                  <motion.div
                    key={model.name}
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: "100%" }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{model.name}</span>
                      <span className="text-sm text-muted-foreground">{model.accuracy}%</span>
                    </div>
                    <Progress value={model.accuracy} className="h-2" />
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
