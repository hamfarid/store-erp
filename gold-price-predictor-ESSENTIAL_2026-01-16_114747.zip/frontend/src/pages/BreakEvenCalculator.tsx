/**
 * Break-Even Calculator Page - Premium Gold Price Predictor
 * Modern break-even calculator with position tracking
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  CalculatorIcon,
  TrashIcon,
  RefreshCwIcon,
  ArrowLeft,
  Sparkles,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  AlertCircle,
  Info,
  Shield,
} from "lucide-react";
import TableSkeleton from "@/components/TableSkeleton";
import PaginationControls from "@/components/PaginationControls";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { format } from "date-fns";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">{value}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function BreakEvenCalculator() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [assetId, setAssetId] = useState<number>(0);
  const [buyPrice, setBuyPrice] = useState<string>("");
  const [quantity, setQuantity] = useState<string>("");
  const [fees, setFees] = useState<string>("0");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { data: assets } = trpc.assets.list.useQuery();
  const {
    data: breakEvenPoints,
    refetch,
    isLoading: loadingPoints,
  } = trpc.breakEvenPoints.list.useQuery({}, { enabled: !!user });

  const calculateMutation = trpc.breakEvenPoints.calculate.useMutation({
    onSuccess: () => {
      toast.success("تم حساب نقطة التعادل بنجاح");
      refetch();
      setBuyPrice("");
      setQuantity("");
      setFees("0");
    },
    onError: (error) => {
      toast.error(`فشل الحساب: ${error.message}`);
    },
  });

  const deleteMutation = trpc.breakEvenPoints.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المركز بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error(`فشل الحذف: ${error.message}`);
    },
  });

  const handleCalculate = () => {
    if (!assetId || !buyPrice || !quantity) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    calculateMutation.mutate({
      assetId,
      buyPrice: parseFloat(buyPrice),
      quantity: parseFloat(quantity),
      fees: parseFloat(fees) || 0,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا المركز؟")) {
      deleteMutation.mutate({ id });
    }
  };

  const getProfitLossColor = (profitLoss: number | null) => {
    if (profitLoss === null) {return "text-muted-foreground";}
    if (profitLoss > 0) {return "text-emerald-600";}
    if (profitLoss < 0) {return "text-red-600";}
    return "text-muted-foreground";
  };

  // Calculate stats
  const totalPositions = breakEvenPoints?.length || 0;
  const totalProfitLoss = breakEvenPoints?.reduce(
    (sum: number, point: any) => sum + (point.profitLoss || 0),
    0
  ) || 0;
  const profitablePositions =
    breakEvenPoints?.filter((p: any) => (p.profitLoss || 0) > 0).length || 0;

  // Pagination
  const totalItems = breakEvenPoints?.length || 0;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedPoints = breakEvenPoints?.slice(startIndex, endIndex);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-6" dir="rtl">
        <Card className="max-w-md premium-card">
          <CardContent className="p-8 text-center">
            <div className="p-4 rounded-full bg-amber-100 dark:bg-amber-900/30 w-fit mx-auto mb-4">
              <Shield className="h-12 w-12 text-amber-600" />
            </div>
            <h2 className="text-xl font-bold mb-2">تسجيل الدخول مطلوب</h2>
            <p className="text-muted-foreground mb-6">
              يرجى تسجيل الدخول لاستخدام حاسبة التعادل
            </p>
            <Button onClick={() => navigate("/login")}>
              تسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <CalculatorIcon className="h-6 w-6 text-primary" />
                  حاسبة التعادل
                </h1>
                <p className="text-sm text-muted-foreground">
                  احسب سعر التعادل وتتبع الربح/الخسارة لمراكزك
                </p>
              </div>
            </div>
            <Button data-testid="refresh-breakeven-button" variant="outline" size="sm" onClick={() => refetch()} disabled={loadingPoints}>
              <RefreshCwIcon className={`ml-2 h-4 w-4 ${loadingPoints ? "animate-spin" : ""}`} />
              تحديث
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Quick Stats */}
        {totalPositions > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
            <StatCard
              icon={Target}
              label="إجمالي المراكز"
              value={totalPositions}
              color="primary"
              delay={0}
            />
            <StatCard
              icon={totalProfitLoss >= 0 ? TrendingUp : TrendingDown}
              label="إجمالي الربح/الخسارة"
              value={`$${totalProfitLoss.toFixed(2)}`}
              color={totalProfitLoss >= 0 ? "success" : "danger"}
              delay={0.1}
            />
            <StatCard
              icon={TrendingUp}
              label="مراكز مربحة"
              value={profitablePositions}
              color="success"
              delay={0.2}
            />
          </div>
        )}

        {/* Calculator Form */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalculatorIcon className="h-5 w-5 text-primary" />
                حساب نقطة التعادل
              </CardTitle>
              <CardDescription>
                أدخل تفاصيل الشراء لحساب سعر التعادل
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="asset">الأصل *</Label>
                  <Select
                    value={assetId.toString()}
                    onValueChange={(value) => setAssetId(parseInt(value))}
                  >
                    <SelectTrigger id="asset">
                      <SelectValue placeholder="اختر أصل" />
                    </SelectTrigger>
                    <SelectContent>
                      {assets?.map((asset: any) => (
                        <SelectItem
                          key={asset.id}
                          value={asset.id.toString()}
                        >
                          {asset.name} ({asset.symbol})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="buyPrice">سعر الشراء ($) *</Label>
                  <Input
                    id="buyPrice"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={buyPrice}
                    onChange={(e) => setBuyPrice(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity">الكمية *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fees">الرسوم ($)</Label>
                  <Input
                    id="fees"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={fees}
                    onChange={(e) => setFees(e.target.value)}
                  />
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button
                  onClick={handleCalculate}
                  disabled={calculateMutation.isPending}
                  className="w-full md:w-auto"
                  size="lg"
                >
                  {calculateMutation.isPending ? (
                    <RefreshCwIcon className="ml-2 h-4 w-4 animate-spin" />
                  ) : (
                    <CalculatorIcon className="ml-2 h-4 w-4" />
                  )}
                  حساب نقطة التعادل
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Saved Positions */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.1 }}
        >
          <Card className="premium-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-primary" />
                    مراكزك
                  </CardTitle>
                  <CardDescription>
                    تتبع نقاط التعادل والربح/الخسارة
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loadingPoints ? (
                <TableSkeleton rows={5} />
              ) : paginatedPoints && paginatedPoints.length > 0 ? (
                <>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>الأصل</TableHead>
                          <TableHead>سعر الشراء</TableHead>
                          <TableHead>الكمية</TableHead>
                          <TableHead>الرسوم</TableHead>
                          <TableHead>سعر التعادل</TableHead>
                          <TableHead>السعر الحالي</TableHead>
                          <TableHead>الربح/الخسارة</TableHead>
                          <TableHead>النسبة</TableHead>
                          <TableHead>تاريخ الشراء</TableHead>
                          <TableHead>الإجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paginatedPoints.map((point: any) => {
                          const asset = assets?.find(
                            (a: any) => a.id === point.assetId
                          ) as { name?: string; symbol?: string } | undefined;
                          const isProfit = (point.profitLoss || 0) > 0;
                          return (
                            <TableRow key={point.id}>
                              <TableCell className="font-medium">
                                {asset?.name || "غير معروف"}
                                <br />
                                <span className="text-sm text-muted-foreground">
                                  {asset?.symbol || "N/A"}
                                </span>
                              </TableCell>
                              <TableCell>${point.buyPrice.toFixed(2)}</TableCell>
                              <TableCell>{point.quantity.toFixed(2)}</TableCell>
                              <TableCell>${point.fees.toFixed(2)}</TableCell>
                              <TableCell className="font-semibold">
                                ${point.breakEvenPrice.toFixed(2)}
                              </TableCell>
                              <TableCell>
                                {point.currentPrice
                                  ? `$${point.currentPrice.toFixed(2)}`
                                  : "N/A"}
                              </TableCell>
                              <TableCell className={getProfitLossColor(point.profitLoss)}>
                                {point.profitLoss !== null
                                  ? `$${point.profitLoss.toFixed(2)}`
                                  : "N/A"}
                              </TableCell>
                              <TableCell>
                                {point.profitLossPercent !== null ? (
                                  <Badge
                                    variant={isProfit ? "default" : "destructive"}
                                    className={
                                      isProfit
                                        ? "bg-emerald-600"
                                        : "bg-red-600"
                                    }
                                  >
                                    {point.profitLossPercent > 0 ? "+" : ""}
                                    {point.profitLossPercent.toFixed(2)}%
                                  </Badge>
                                ) : (
                                  "N/A"
                                )}
                              </TableCell>
                              <TableCell>
                                {format(new Date(point.purchaseDate), "dd/MM/yyyy")}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDelete(point.id)}
                                  disabled={deleteMutation.isPending}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <TrashIcon className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="mt-6">
                      <PaginationControls
                        currentPage={currentPage}
                        totalPages={totalPages}
                        pageSize={pageSize}
                        totalItems={totalItems}
                        onPageChange={setCurrentPage}
                        onPageSizeChange={(newSize) => {
                          setPageSize(newSize);
                          setCurrentPage(1);
                        }}
                      />
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-16">
                  <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                    <Target className="h-12 w-12 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">لا توجد مراكز محفوظة</h3>
                  <p className="text-muted-foreground">
                    احسب نقطة التعادل الأولى أعلاه
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
