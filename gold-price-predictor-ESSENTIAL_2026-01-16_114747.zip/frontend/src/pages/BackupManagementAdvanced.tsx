/**
 * Advanced Backup Management Page
 * Export/Import with multiple storage options
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import {
  Database,
  Download,
  Upload,
  Trash2,
  HardDrive,
  Brain,
  FileArchive,
  RefreshCw,
  AlertTriangle,
  Cloud,
  Newspaper,
  MessageSquare,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

type BackupStorageType = "internal" | "external" | "google_drive" | "s3";

export default function BackupManagementAdvanced() {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [selectedStorage, setSelectedStorage] =
    useState<BackupStorageType>("internal");
  const [advancedBackupDialogOpen, setAdvancedBackupDialogOpen] =
    useState(false);

  const {
    data: backups,
    isLoading,
    refetch,
  } = trpc.backup.listBackups.useQuery();
  const { data: storageOptions } = trpc.backup.getStorageOptions.useQuery();

  const createFullBackupMutation = trpc.backup.createFullBackup.useMutation({
    onSuccess: result => {
      if (result.success) {
        toast.success("تم إنشاء النسخة الاحتياطية بنجاح!");
        refetch();
      } else {
        toast.error(`فشل إنشاء النسخة الاحتياطية: ${result.error}`);
      }
    },
    onError: error => {
      toast.error(`خطأ: ${error.message}`);
    },
  });

  const saveBackupAdvancedMutation = trpc.backup.saveBackupAdvanced.useMutation(
    {
      onSuccess: result => {
        if (result.success) {
          toast.success(
            `تم حفظ النسخة الاحتياطية على ${getStorageLabel(result.storageType)}!`
          );
          if (result.url) {
            toast.info(`الرابط: ${result.url}`);
          }
          setAdvancedBackupDialogOpen(false);
        } else {
          toast.error(`فشل الحفظ: ${result.error}`);
        }
      },
      onError: error => {
        toast.error(`خطأ: ${error.message}`);
      },
    }
  );

  const deleteBackupMutation = trpc.backup.deleteBackup.useMutation({
    onSuccess: result => {
      if (result.success) {
        toast.success("تم حذف النسخة الاحتياطية");
        refetch();
      } else {
        toast.error(`فشل الحذف: ${result.message}`);
      }
    },
    onError: error => {
      toast.error(`خطأ: ${error.message}`);
    },
  });

  const getStorageLabel = (type: string) => {
    const labels: Record<string, string> = {
      internal: "التخزين الداخلي",
      s3: "S3 Storage",
      google_drive: "Google Drive",
      external: "رابط خارجي",
    };
    return labels[type] || type;
  };

  const getStorageIcon = (type: BackupStorageType) => {
    switch (type) {
      case "internal":
        return <HardDrive className="h-4 w-4" />;
      case "s3":
        return <Cloud className="h-4 w-4" />;
      case "google_drive":
        return <Cloud className="h-4 w-4" />;
      case "external":
        return <Upload className="h-4 w-4" />;
      default:
        return <Database className="h-4 w-4" />;
    }
  };

  const handleExportDatabase = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportDatabase as any).query();
      if (result.success && result.data) {
        downloadJSON(
          result.data,
          `database-export-${new Date().toISOString().split("T")[0]}.json`
        );
        toast.success("تم تصدير قاعدة البيانات بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportAIData = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportAIData as any).query();
      if (result.success && result.data) {
        downloadJSON(
          result.data,
          `ai-training-data-${new Date().toISOString().split("T")[0]}.json`
        );
        toast.success("تم تصدير بيانات التعلم بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportNews = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportNews as any).query();
      if (result.success && result.data) {
        downloadJSON(
          result.data,
          `news-data-${new Date().toISOString().split("T")[0]}.json`
        );
        toast.success("تم تصدير بيانات الأخبار بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportAIConversations = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportAIConversations as any).query();
      if (result.success && result.data) {
        downloadJSON(
          result.data,
          `ai-conversations-${new Date().toISOString().split("T")[0]}.json`
        );
        toast.success("تم تصدير محادثات المساعد الذكي بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const downloadJSON = (data: any, fileName: string) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCreateFullBackup = () => {
    if (confirm("هل تريد إنشاء نسخة احتياطية كاملة؟")) {
      createFullBackupMutation.mutate();
    }
  };

  const handleCreateAdvancedBackup = async () => {
    try {
      // Export full data
      const dbResult = await (trpc.backup.exportDatabase as any).query();
      const aiResult = await (trpc.backup.exportAIData as any).query();

      if (!dbResult.success || !aiResult.success) {
        toast.error("فشل تصدير البيانات");
        return;
      }

      const fullData = {
        version: "1.0",
        backupDate: new Date().toISOString(),
        database: dbResult.data,
        aiTrainingData: aiResult.data,
      };

      saveBackupAdvancedMutation.mutate({
        data: fullData,
        storageType: selectedStorage,
        fileName: `full-backup-${Date.now()}.json`,
        metadata: {
          createdBy: "admin",
          type: "full",
        },
      });
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    }
  };

  const handleImportFile = async () => {
    if (!importFile) {
      toast.error("الرجاء اختيار ملف");
      return;
    }

    setIsImporting(true);
    try {
      const text = await importFile.text();
      const data = JSON.parse(text);

      // Determine import type
      if (data.database && data.aiTrainingData) {
        const result = await (trpc.backup.restoreFullBackup as any).mutate(
          data
        );
        if (result.success) {
          toast.success(result.message);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(result.message);
        }
      } else if (data.tables) {
        const result = await (trpc.backup.importDatabase as any).mutate(data);
        if (result.success) {
          toast.success(`تم استيراد ${result.imported} سجل`);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(`فشل الاستيراد: ${result.errors.join(", ")}`);
        }
      } else if (data.trainingExamples) {
        const result = await (trpc.backup.importAIData as any).mutate(data);
        if (result.success) {
          toast.success(result.message);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(result.message);
        }
      } else if (data.newsCache) {
        const result = await (trpc.backup.importNews as any).mutate(data);
        if (result.success) {
          toast.success(`تم استيراد ${result.imported} خبر`);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(`فشل الاستيراد: ${result.errors.join(", ")}`);
        }
      } else if (data.conversations) {
        const result = await (trpc.backup.importAIConversations as any).mutate(
          data
        );
        if (result.success) {
          toast.success(`تم استيراد ${result.imported} محادثة`);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(`فشل الاستيراد: ${result.errors.join(", ")}`);
        }
      } else {
        toast.error("تنسيق ملف غير صالح");
      }
    } catch (error) {
      toast.error(`خطأ في قراءة الملف: ${error}`);
    } finally {
      setIsImporting(false);
    }
  };

  const handleDeleteBackup = (fileName: string) => {
    if (confirm(`هل تريد حذف النسخة الاحتياطية: ${fileName}؟`)) {
      deleteBackupMutation.mutate({ fileName });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) {return `${bytes} B`;}
    if (bytes < 1024 * 1024) {return `${(bytes / 1024).toFixed(2)} KB`;}
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          إدارة النسخ الاحتياطي المتقدمة
        </h1>
        <p className="text-muted-foreground">
          تصدير واستيراد مع خيارات تخزين متعددة
        </p>
      </div>

      {/* Warning Alert */}
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>تحذير</AlertTitle>
        <AlertDescription>
          استيراد البيانات سيستبدل البيانات الحالية. تأكد من إنشاء نسخة احتياطية
          قبل الاستيراد.
        </AlertDescription>
      </Alert>

      {/* Storage Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            خيارات التخزين المتاحة
          </CardTitle>
          <CardDescription>اختر وجهة التخزين للنسخ الاحتياطية</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {storageOptions?.map(option => (
              <Card
                key={option.type}
                className={`cursor-pointer transition-all ${
                  option.available
                    ? "hover:border-primary"
                    : "opacity-50 cursor-not-allowed"
                }`}
                onClick={() =>
                  option.available &&
                  setSelectedStorage(option.type as BackupStorageType)
                }
              >
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3 mb-2">
                    {getStorageIcon(option.type as BackupStorageType)}
                    <span className="font-medium">{option.label}</span>
                    {option.available ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600 ml-auto" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600 ml-auto" />
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {option.description}
                  </p>
                  {selectedStorage === option.type && option.available && (
                    <Badge className="mt-2">محدد</Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            تصدير البيانات
          </CardTitle>
          <CardDescription>تحميل نسخة من البيانات (تنزيل محلي)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              onClick={handleExportDatabase}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Database className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "قاعدة البيانات"}
            </Button>

            <Button
              onClick={handleExportAIData}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Brain className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "بيانات التعلم"}
            </Button>

            <Button
              onClick={handleExportNews}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Newspaper className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "الأخبار"}
            </Button>

            <Button
              onClick={handleExportAIConversations}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "المحادثات"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Backup Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileArchive className="h-5 w-5" />
            نسخ احتياطي متقدم
          </CardTitle>
          <CardDescription>
            إنشاء نسخة احتياطية كاملة مع اختيار وجهة التخزين
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button
              onClick={handleCreateFullBackup}
              disabled={createFullBackupMutation.isPending}
              variant="default"
            >
              <FileArchive className="mr-2 h-4 w-4" />
              {createFullBackupMutation.isPending
                ? "جاري الإنشاء..."
                : "نسخة احتياطية (داخلي)"}
            </Button>

            <Dialog
              open={advancedBackupDialogOpen}
              onOpenChange={setAdvancedBackupDialogOpen}
            >
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Cloud className="mr-2 h-4 w-4" />
                  نسخة احتياطية متقدمة
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>إنشاء نسخة احتياطية متقدمة</DialogTitle>
                  <DialogDescription>
                    اختر وجهة التخزين للنسخة الاحتياطية
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>وجهة التخزين</Label>
                    <Select
                      value={selectedStorage}
                      onValueChange={value =>
                        setSelectedStorage(value as BackupStorageType)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {storageOptions
                          ?.filter(opt => opt.available)
                          .map(opt => (
                            <SelectItem key={opt.type} value={opt.type}>
                              {opt.label}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    onClick={handleCreateAdvancedBackup}
                    disabled={saveBackupAdvancedMutation.isPending}
                    className="w-full"
                  >
                    {saveBackupAdvancedMutation.isPending
                      ? "جاري الحفظ..."
                      : "إنشاء النسخة الاحتياطية"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            استيراد البيانات
          </CardTitle>
          <CardDescription>
            استعادة البيانات من ملف نسخة احتياطية
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full md:w-auto">
                <Upload className="mr-2 h-4 w-4" />
                استيراد من ملف
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>استيراد البيانات</DialogTitle>
                <DialogDescription>
                  اختر ملف JSON لاستيراد البيانات (يدعم جميع الأنواع)
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="import-file">ملف النسخة الاحتياطية</Label>
                  <Input
                    id="import-file"
                    type="file"
                    accept=".json"
                    onChange={e => setImportFile(e.target.files?.[0] || null)}
                  />
                </div>
                {importFile && (
                  <div className="text-sm text-muted-foreground">
                    الملف المختار: {importFile.name} (
                    {formatFileSize(importFile.size)})
                  </div>
                )}
                <Button
                  onClick={handleImportFile}
                  disabled={!importFile || isImporting}
                  className="w-full"
                >
                  {isImporting ? "جاري الاستيراد..." : "استيراد"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Backups List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5" />
                النسخ الاحتياطية المحفوظة (داخلي)
              </CardTitle>
              <CardDescription>
                قائمة النسخ الاحتياطية المتوفرة على الخادم
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => refetch()}
              disabled={isLoading}
            >
              <RefreshCw
                className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`}
              />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              جاري التحميل...
            </div>
          ) : !backups || backups.backups.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد نسخ احتياطية محفوظة
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الملف</TableHead>
                  <TableHead>الحجم</TableHead>
                  <TableHead>تاريخ الإنشاء</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {backups.backups.map(backup => (
                  <TableRow key={backup.fileName}>
                    <TableCell className="font-medium">
                      {backup.fileName}
                    </TableCell>
                    <TableCell>{formatFileSize(backup.size)}</TableCell>
                    <TableCell>
                      {format(new Date(backup.createdAt), "PPp", {
                        locale: ar,
                      })}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteBackup(backup.fileName)}
                        disabled={deleteBackupMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
