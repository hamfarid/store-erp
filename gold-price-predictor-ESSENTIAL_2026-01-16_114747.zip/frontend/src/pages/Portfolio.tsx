/**
 * Portfolio Page - Premium Gold Price Predictor
 * Investment portfolio management with analytics
 */

import { PageLayout } from "@/components/PageLayout";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { FadeIn } from "@/components/animations/FadeIn";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Plus,
  TrendingDown,
  TrendingUp,
  Wallet,
  ArrowLeft,
  PieChart as PieChartIcon,
  BarChart3,
  DollarSign,
  Percent,
  Eye,
  Sparkles,
  ChevronRight,
  Target,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { useState } from "react";
import {
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { Link, useLocation } from "wouter";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const COLORS = [
  "oklch(0.75 0.15 80)",  // Gold
  "oklch(0.72 0.19 145)", // Green
  "oklch(0.65 0.18 250)", // Blue
  "oklch(0.55 0.22 25)",  // Red
  "oklch(0.70 0.16 300)", // Purple
  "oklch(0.70 0.18 30)",  // Orange
];

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  trend,
  trendValue,
  color = "primary",
}: {
  icon: any;
  label: string;
  value: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "primary" | "success" | "warning" | "danger";
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  const trendColors = {
    up: "text-emerald-600",
    down: "text-red-600",
    neutral: "text-muted-foreground",
  };

  return (
    <Card className="stat-card">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {trendValue && trend && (
              <p className={`text-xs mt-1 flex items-center gap-1 ${trendColors[trend]}`}>
                {trend === "up" ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : trend === "down" ? (
                  <ArrowDownRight className="h-3 w-3" />
                ) : null}
                {trendValue}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-xl ${colors[color]}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Portfolio() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newPortfolioName, setNewPortfolioName] = useState("");
  const [newPortfolioDescription, setNewPortfolioDescription] = useState("");

  const {
    data: portfolios,
    isLoading,
    refetch,
  } = trpc.portfolio.list.useQuery(undefined, {
    enabled: !!user,
  });

  const createMutation = trpc.portfolio.create.useMutation({
    onSuccess: () => {
      refetch();
      setIsCreateDialogOpen(false);
      setNewPortfolioName("");
      setNewPortfolioDescription("");
    },
  });

  const handleCreatePortfolio = () => {
    if (!newPortfolioName.trim()) {return;}
    createMutation.mutate({
      name: newPortfolioName,
      description: newPortfolioDescription || undefined,
    });
  };

  if (authLoading || isLoading) {
    return (
      <PageLayout title="جاري التحميل...">
        <div className="flex items-center justify-center min-h-[60vh]">
          <LoadingSpinner />
        </div>
      </PageLayout>
    );
  }

  if (!user) {
    return (
      <PageLayout
        title="يرجى تسجيل الدخول"
        breadcrumbs={[
          { label: "الرئيسية", href: "/" },
          { label: "المحفظة" },
        ]}
      >
        <FadeIn>
          <Card className="max-w-md mx-auto text-center overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
            <CardContent className="pt-12 pb-8">
              <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-6">
                <Wallet className="h-12 w-12 text-primary" />
              </div>
              <h1 className="text-2xl font-bold mb-2">يرجى تسجيل الدخول</h1>
              <p className="text-muted-foreground mb-6">
                يجب تسجيل الدخول لعرض محفظتك الاستثمارية
              </p>
              <Button asChild className="glow-gold">
                <Link href="/login">تسجيل الدخول</Link>
              </Button>
            </CardContent>
          </Card>
        </FadeIn>
      </PageLayout>
    );
  }

  // Calculate total portfolio stats
  const totalValue = portfolios?.reduce((sum: number, p: any) => sum + (p.currentValue || 0), 0) || 0;
  const totalInvested = portfolios?.reduce((sum: number, p: any) => sum + (p.totalInvested || 0), 0) || 0;
  const totalProfitLoss = totalValue - totalInvested;
  const totalROI = totalInvested > 0 ? (totalProfitLoss / totalInvested) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Wallet className="h-6 w-6 text-primary" />
                  محفظتي الاستثمارية
                </h1>
                <p className="text-sm text-muted-foreground">
                  إدارة وتتبع استثماراتك
                </p>
              </div>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button data-testid="create-portfolio-button">
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء محفظة
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Plus className="h-5 w-5 text-primary" />
                    إنشاء محفظة جديدة
                  </DialogTitle>
                  <DialogDescription>
                    أنشئ محفظة جديدة لتتبع استثماراتك
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">اسم المحفظة *</Label>
                    <Input
                      id="name"
                      placeholder="مثال: محفظة الذهب"
                      value={newPortfolioName}
                      onChange={(e) => setNewPortfolioName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">الوصف (اختياري)</Label>
                    <Textarea
                      id="description"
                      placeholder="وصف المحفظة..."
                      value={newPortfolioDescription}
                      onChange={(e) => setNewPortfolioDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    إلغاء
                  </Button>
                  <Button
                    data-testid="submit-portfolio-form"
                    onClick={handleCreatePortfolio}
                    disabled={createMutation.isPending || !newPortfolioName.trim()}
                  >
                    {createMutation.isPending ? "جاري الإنشاء..." : "إنشاء المحفظة"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Summary Stats */}
        {portfolios && portfolios.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard
              icon={DollarSign}
              label="إجمالي القيمة"
              value={`$${totalValue.toFixed(2)}`}
              color="primary"
            />
            <StatCard
              icon={Wallet}
              label="إجمالي المستثمر"
              value={`$${totalInvested.toFixed(2)}`}
              color="success"
            />
            <StatCard
              icon={totalProfitLoss >= 0 ? TrendingUp : TrendingDown}
              label="الربح/الخسارة"
              value={`${totalProfitLoss >= 0 ? "+" : ""}$${totalProfitLoss.toFixed(2)}`}
              trend={totalProfitLoss >= 0 ? "up" : "down"}
              color={totalProfitLoss >= 0 ? "success" : "danger"}
            />
            <StatCard
              icon={Percent}
              label="العائد على الاستثمار"
              value={`${totalROI >= 0 ? "+" : ""}${totalROI.toFixed(2)}%`}
              trend={totalROI >= 0 ? "up" : "down"}
              color={totalROI >= 0 ? "success" : "danger"}
            />
          </div>
        )}

        {/* Portfolios */}
        {!portfolios || portfolios.length === 0 ? (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-6">
                  <Wallet className="h-16 w-16 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">لا توجد محافظ</h2>
                <p className="text-muted-foreground mb-6">
                  ابدأ بإنشاء محفظتك الأولى لتتبع استثماراتك
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)} className="glow-gold">
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء محفظة جديدة
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {portfolios.map((portfolio: any, index: number) => (
              <PortfolioCard key={portfolio.id} portfolio={portfolio} delay={0.1 * index} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function PortfolioCard({ portfolio, delay = 0 }: { portfolio: any; delay?: number }) {
  const { data: summary, isLoading } = trpc.portfolio.getSummary.useQuery({
    portfolioId: portfolio.id,
  });
  const { data: breakdown } = trpc.portfolio.getBreakdown.useQuery({
    portfolioId: portfolio.id,
  });

  if (isLoading) {
    return (
      <Card className="h-96">
        <CardContent className="p-6 space-y-4">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-48 w-full" />
        </CardContent>
      </Card>
    );
  }

  const profitLossPercent = (summary as any)?.totalInvested
    ? ((summary as any).profitLoss / (summary as any).totalInvested) * 100
    : 0;
  const isProfit = ((summary as any)?.profitLoss || 0) >= 0;

  // Prepare pie chart data
  const pieData =
    (breakdown as any)?.map((item: any, index: number) => ({
      name: item.assetSymbol,
      value: item.currentValue,
      color: COLORS[index % COLORS.length],
    })) || [];

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Link href={`/portfolio/${portfolio.id}`}>
        <Card className="stat-card h-full overflow-hidden cursor-pointer group">
          <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="group-hover:text-primary transition-colors">
                  {portfolio.name}
                </CardTitle>
                {portfolio.description && (
                  <CardDescription className="mt-1 line-clamp-1">
                    {portfolio.description}
                  </CardDescription>
                )}
              </div>
              <Badge variant={isProfit ? "default" : "destructive"} className="text-xs">
                {isProfit ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                {isProfit ? "+" : ""}{profitLossPercent.toFixed(1)}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Summary Stats */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">القيمة الحالية</span>
                <span className="text-xl font-bold gold-shimmer">
                  ${(summary as any)?.currentValue?.toFixed(2) || "0.00"}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">المستثمر</span>
                <span className="text-sm">${(summary as any)?.totalInvested?.toFixed(2) || "0.00"}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">الربح/الخسارة</span>
                <span className={`text-sm font-semibold flex items-center gap-1 ${isProfit ? "text-emerald-600" : "text-red-600"}`}>
                  {isProfit ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                  ${Math.abs((summary as any)?.profitLoss || 0).toFixed(2)}
                </span>
              </div>
              
              {/* ROI Progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">العائد على الاستثمار</span>
                  <span className={isProfit ? "text-emerald-600" : "text-red-600"}>
                    {(summary as any)?.roi?.toFixed(2) || "0.00"}%
                  </span>
                </div>
                <Progress
                  value={Math.min(Math.abs((summary as any)?.roi || 0), 100)}
                  className={`h-2 ${isProfit ? "[&>div]:bg-emerald-500" : "[&>div]:bg-red-500"}`}
                />
              </div>
            </div>

            {/* Pie Chart */}
            {pieData.length > 0 && (
              <div className="h-40 -mx-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={35}
                      outerRadius={60}
                      fill="#8884d8"
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {pieData.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => `$${value.toFixed(2)}`}
                      contentStyle={{
                        borderRadius: "8px",
                        border: "1px solid var(--border)",
                        background: "var(--card)",
                      }}
                    />
                    <Legend
                      iconType="circle"
                      iconSize={8}
                      formatter={(value) => <span className="text-xs">{value}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* View Details Button */}
            <Button className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors" variant="outline">
              <Eye className="ml-2 h-4 w-4" />
              عرض التفاصيل
              <ChevronRight className="mr-auto h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Button>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}
