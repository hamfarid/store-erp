/**
 * 401 Unauthorized Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { Lock } from "lucide-react";

export default function Error401() {
  return (
    <ErrorPageTemplate
      code={401}
      title="غير مصرح"
      description="عذراً، يجب تسجيل الدخول للوصول إلى هذه الصفحة. يرجى تسجيل الدخول بحسابك للمتابعة."
      icon={Lock}
      iconColor="text-amber-500"
      showRefresh={false}
      showHome={false}
      showDashboard={false}
      actionButton={{
        label: "تسجيل الدخول",
        href: "/login",
      }}
    />
  );
}
