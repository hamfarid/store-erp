/**
 * 505 HTTP Version Not Supported Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { FileWarning } from "lucide-react";

export default function Error505() {
  return (
    <ErrorPageTemplate
      code={505}
      title="إصدار HTTP غير مدعوم"
      description="عذراً، إصدار بروتوكول HTTP المستخدم غير مدعوم من قبل الخادم."
      icon={FileWarning}
      iconColor="text-red-500"
      showRefresh={false}
      showHome={true}
      showDashboard={true}
    />
  );
}
