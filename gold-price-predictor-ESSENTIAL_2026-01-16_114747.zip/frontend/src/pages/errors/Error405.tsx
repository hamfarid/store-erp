/**
 * 405 Method Not Allowed Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { Ban } from "lucide-react";

export default function Error405() {
  return (
    <ErrorPageTemplate
      code={405}
      title="الطريقة غير مسموحة"
      description="عذراً، طريقة الطلب المستخدمة غير مسموح بها لهذا المورد. يرجى المحاولة بطريقة مختلفة."
      icon={Ban}
      iconColor="text-red-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
