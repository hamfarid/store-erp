/**
 * 503 Service Unavailable Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { ServerOff } from "lucide-react";

export default function Error503() {
  return (
    <ErrorPageTemplate
      code={503}
      title="الخدمة غير متاحة"
      description="عذراً، الخدمة غير متاحة حالياً بسبب الصيانة أو الحمل الزائد. يرجى المحاولة مرة أخرى لاحقاً."
      icon={ServerOff}
      iconColor="text-amber-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
