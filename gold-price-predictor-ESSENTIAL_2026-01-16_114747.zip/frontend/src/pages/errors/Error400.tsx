/**
 * 400 Bad Request Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { AlertTriangle } from "lucide-react";

export default function Error400() {
  return (
    <ErrorPageTemplate
      code={400}
      title="طلب غير صالح"
      description="عذراً، الطلب الذي أرسلته غير صالح أو يحتوي على بيانات غير صحيحة. يرجى التحقق من البيانات والمحاولة مرة أخرى."
      icon={AlertTriangle}
      iconColor="text-amber-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
