/**
 * 506 Variant Also Negotiates Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { CircleAlert } from "lucide-react";

export default function Error506() {
  return (
    <ErrorPageTemplate
      code={506}
      title="خطأ في التفاوض"
      description="عذراً، حدث خطأ داخلي في تكوين الخادم. يرجى التواصل مع الدعم الفني."
      icon={CircleAlert}
      iconColor="text-red-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
