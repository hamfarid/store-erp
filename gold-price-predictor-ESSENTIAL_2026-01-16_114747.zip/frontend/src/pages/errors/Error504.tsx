/**
 * 504 Gateway Timeout Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { Clock } from "lucide-react";

export default function Error504() {
  return (
    <ErrorPageTemplate
      code={504}
      title="انتهت مهلة البوابة"
      description="عذراً، الخادم استغرق وقتاً طويلاً للاستجابة. يرجى المحاولة مرة أخرى لاحقاً."
      icon={Clock}
      iconColor="text-amber-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
