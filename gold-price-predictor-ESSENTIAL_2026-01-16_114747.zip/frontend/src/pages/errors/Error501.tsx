/**
 * 501 Not Implemented Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { Construction } from "lucide-react";

export default function Error501() {
  return (
    <ErrorPageTemplate
      code={501}
      title="غير منفذ"
      description="عذراً، هذه الميزة لم يتم تنفيذها بعد. نحن نعمل على إضافتها قريباً."
      icon={Construction}
      iconColor="text-amber-500"
      showRefresh={false}
      showHome={true}
      showDashboard={true}
    />
  );
}
