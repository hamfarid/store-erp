/**
 * 502 Bad Gateway Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { ServerCrash } from "lucide-react";

export default function Error502() {
  return (
    <ErrorPageTemplate
      code={502}
      title="خطأ في البوابة"
      description="عذراً، الخادم الوسيط تلقى استجابة غير صالحة. يرجى المحاولة مرة أخرى لاحقاً."
      icon={ServerCrash}
      iconColor="text-red-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
