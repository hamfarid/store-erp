/**
 * 402 Payment Required Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { CreditCard } from "lucide-react";

export default function Error402() {
  return (
    <ErrorPageTemplate
      code={402}
      title="الدفع مطلوب"
      description="عذراً، هذه الميزة تتطلب اشتراكاً مدفوعاً. يرجى الترقية إلى الخطة المميزة للوصول إلى جميع الميزات."
      icon={CreditCard}
      iconColor="text-primary"
      showRefresh={false}
      showHome={true}
      showDashboard={true}
    />
  );
}
