/**
 * System Health & Monitoring Page - Premium Gold Price Predictor
 * View system health, API stats, error logs, and ML training history
 */

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import {
  Activity,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Server,
  Clock,
  BarChart3,
  Bug,
  Brain,
  ArrowLeft,
  Sparkles,
  Shield,
  Zap,
  Database,
  Cpu,
  HardDrive,
  Gauge,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Timer,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  suffix = "",
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  suffix?: string;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${colors[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-lg font-bold">
                {value}
                {suffix && <span className="text-sm font-normal text-muted-foreground">{suffix}</span>}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Health Status Component
function HealthStatus({ status }: { status: string }) {
  const isHealthy = status === "healthy";
  return (
    <div className={`flex items-center gap-2 px-4 py-2 rounded-full ${
      isHealthy ? "bg-emerald-100 dark:bg-emerald-900/30" : "bg-red-100 dark:bg-red-900/30"
    }`}>
      {isHealthy ? (
        <CheckCircle className="h-5 w-5 text-emerald-600" />
      ) : (
        <XCircle className="h-5 w-5 text-red-600" />
      )}
      <span className={`font-semibold ${isHealthy ? "text-emerald-700 dark:text-emerald-400" : "text-red-700 dark:text-red-400"}`}>
        {isHealthy ? "النظام يعمل بشكل سليم" : "يحتاج انتباه"}
      </span>
    </div>
  );
}

// Error Item Component
function ErrorItem({ error }: { error: any }) {
  return (
    <div className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-red-500" />
          <span className="font-medium">{error.source || "Unknown"}</span>
          <Badge variant="outline">{error.component || "System"}</Badge>
        </div>
        <span className="text-xs text-muted-foreground">
          {error.timestamp ? format(new Date(error.timestamp), "PPpp", { locale: ar }) : "N/A"}
        </span>
      </div>
      <p className="text-sm text-muted-foreground">{error.message}</p>
      {error.stack && (
        <details className="mt-2">
          <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
            عرض التفاصيل
          </summary>
          <pre className="text-xs bg-muted p-2 rounded mt-1 overflow-auto max-h-32">
            {error.stack}
          </pre>
        </details>
      )}
    </div>
  );
}

// ML Training Item Component
function MLTrainingItem({ log }: { log: any }) {
  return (
    <div className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Brain className="h-4 w-4 text-primary" />
          <span className="font-medium">{log.modelType || "Unknown Model"}</span>
          <Badge variant={log.status === "completed" ? "default" : "secondary"}>
            {log.status === "completed" ? "مكتمل" : log.status}
          </Badge>
        </div>
        <span className="text-xs text-muted-foreground">
          {log.timestamp ? format(new Date(log.timestamp), "PPpp", { locale: ar }) : "N/A"}
        </span>
      </div>
      <div className="grid grid-cols-4 gap-3 text-sm">
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">الدقة</p>
          <p className="font-semibold">{log.accuracy ? `${log.accuracy}%` : "N/A"}</p>
        </div>
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">MAE</p>
          <p className="font-semibold">{log.mae || "N/A"}</p>
        </div>
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">RMSE</p>
          <p className="font-semibold">{log.rmse || "N/A"}</p>
        </div>
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">المدة</p>
          <p className="font-semibold">{log.duration || "N/A"}</p>
        </div>
      </div>
    </div>
  );
}

// Prediction Item Component
function PredictionItem({ log }: { log: any }) {
  return (
    <div className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-primary" />
          <span className="font-medium">{log.assetName || "Unknown Asset"}</span>
          <Badge variant="outline">{log.modelType || "N/A"}</Badge>
        </div>
        <span className="text-xs text-muted-foreground">
          {log.timestamp ? format(new Date(log.timestamp), "PPpp", { locale: ar }) : "N/A"}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-3 text-sm mt-3">
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">التوقع</p>
          <p className="font-semibold text-primary">${log.predictedPrice || "N/A"}</p>
        </div>
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">الثقة</p>
          <p className="font-semibold">{log.confidence || "N/A"}%</p>
        </div>
        <div className="p-2 rounded bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">المدى</p>
          <p className="font-semibold">{log.horizon || "N/A"}</p>
        </div>
      </div>
    </div>
  );
}

export default function SystemHealth() {
  const [, navigate] = useLocation();
  const [errorLimit, setErrorLimit] = useState(50);
  const [mlAssetId, setMlAssetId] = useState<number | undefined>();
  const [apiHours, setApiHours] = useState(24);
  const [selectedAssetId, setSelectedAssetId] = useState<number | undefined>();

  // Fetch assets using tRPC hook
  const { data: assets = [] } = trpc.assets.list.useQuery();
  
  // Update mlAssetId when selectedAssetId changes
  useEffect(() => {
    setMlAssetId(selectedAssetId);
  }, [selectedAssetId]);

  // Fetch system health
  const { data: health, isLoading: loadingHealth, refetch: refetchHealth } =
    trpc.logs.getSystemHealth.useQuery(undefined, { refetchInterval: 30000 });

  // Fetch recent errors
  const { data: errors, isLoading: loadingErrors, refetch: refetchErrors } =
    trpc.logs.getErrors.useQuery({ limit: errorLimit });

  // Fetch API stats
  const { data: apiStats, isLoading: loadingApiStats, refetch: refetchApiStats } =
    trpc.logs.getAPIStats.useQuery({ hours: apiHours });

  // Fetch ML training history
  const { data: mlHistory, isLoading: loadingML, refetch: refetchML } =
    trpc.logs.getMLTrainingHistory.useQuery({ assetId: mlAssetId, limit: 50 });

  // Fetch prediction logs
  const { data: predictionLogs, isLoading: loadingPredictions } =
    trpc.logs.getPredictionLogs.useQuery({ limit: 50 });

  const handleRefreshAll = () => {
    refetchHealth();
    refetchErrors();
    refetchApiStats();
    refetchML();
    toast.success("تم تحديث جميع البيانات");
  };

  const isLoading = loadingHealth || loadingErrors || loadingApiStats || loadingML || loadingPredictions;

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Server className="h-6 w-6 text-primary" />
                  صحة النظام والمراقبة
                </h1>
                <p className="text-sm text-muted-foreground">
                  مراقبة حالة النظام وسجلات الأخطاء وإحصائيات API
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Select
                value={selectedAssetId?.toString() || "all"}
                onValueChange={(v) => setSelectedAssetId(v === "all" ? undefined : parseInt(v))}
              >
                <SelectTrigger data-testid="system-health-asset-select" className="w-[200px]">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأصول</SelectItem>
                  {(assets as any[]).map((asset: any) => (
                    <SelectItem key={asset.id} value={asset.id.toString()}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button data-testid="refresh-system-health-button" variant="outline" size="sm" onClick={handleRefreshAll} disabled={isLoading}>
                <RefreshCw className={`ml-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                تحديث الكل
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* System Status Hero */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className={`premium-card border-2 ${
            health?.status === "healthy" ? "border-emerald-500" : "border-red-500"
          }`}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className={`p-4 rounded-xl ${
                    health?.status === "healthy"
                      ? "bg-emerald-100 dark:bg-emerald-900/30"
                      : "bg-red-100 dark:bg-red-900/30"
                  }`}>
                    {health?.status === "healthy" ? (
                      <Shield className="h-10 w-10 text-emerald-600" />
                    ) : (
                      <AlertCircle className="h-10 w-10 text-red-600" />
                    )}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">حالة النظام العامة</h2>
                    <HealthStatus status={health?.status || "unhealthy"} />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  آخر فحص: {health?.timestamp
                    ? format(new Date(health.timestamp), "HH:mm:ss", { locale: ar })
                    : "N/A"}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Zap}
            label="حالة النظام"
            value={health?.status === "healthy" ? "يعمل" : "متعطل"}
            color={health?.status === "healthy" ? "success" : "danger"}
            delay={0}
          />
          <StatCard
            icon={Bug}
            label="أخطاء حديثة"
            value={health?.recentErrors || 0}
            color={(health?.recentErrors || 0) > 5 ? "danger" : "success"}
            delay={0.1}
          />
          <StatCard
            icon={BarChart3}
            label="طلبات API"
            value={health?.apiStats?.totalRequests || 0}
            color="primary"
            delay={0.2}
          />
          <StatCard
            icon={Timer}
            label="متوسط الاستجابة"
            value={(apiStats as any)?.avgResponseTime || 0}
            suffix="ms"
            color="primary"
            delay={0.3}
          />
        </div>

        {/* Tabs Content */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.4 }}
        >
          <Tabs defaultValue="errors" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="errors" className="gap-2">
                <Bug className="h-4 w-4" />
                الأخطاء
              </TabsTrigger>
              <TabsTrigger value="api" className="gap-2">
                <Activity className="h-4 w-4" />
                إحصائيات API
              </TabsTrigger>
              <TabsTrigger value="ml" className="gap-2">
                <Brain className="h-4 w-4" />
                تدريب ML
              </TabsTrigger>
              <TabsTrigger value="predictions" className="gap-2">
                <TrendingUp className="h-4 w-4" />
                التوقعات
              </TabsTrigger>
            </TabsList>

            {/* Errors Tab */}
            <TabsContent value="errors">
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Bug className="h-5 w-5 text-red-500" />
                        سجل الأخطاء
                      </CardTitle>
                      <CardDescription>آخر الأخطاء المسجلة في النظام</CardDescription>
                    </div>
                    <Select value={errorLimit.toString()} onValueChange={(v) => setErrorLimit(parseInt(v))}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="20">آخر 20</SelectItem>
                        <SelectItem value="50">آخر 50</SelectItem>
                        <SelectItem value="100">آخر 100</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingErrors ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
                      </div>
                    </div>
                  ) : (errors as any[] || []).length > 0 ? (
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-3">
                        {(errors as any[]).map((error: any, index: number) => (
                          <ErrorItem key={index} error={error} />
                        ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-emerald-100 dark:bg-emerald-900/30 w-fit mx-auto mb-4">
                        <CheckCircle2 className="h-12 w-12 text-emerald-600" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">لا توجد أخطاء</h3>
                      <p className="text-muted-foreground">النظام يعمل بشكل سليم 🎉</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* API Stats Tab */}
            <TabsContent value="api">
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Activity className="h-5 w-5 text-primary" />
                        إحصائيات API
                      </CardTitle>
                      <CardDescription>معدلات الاستخدام وأوقات الاستجابة</CardDescription>
                    </div>
                    <Select value={apiHours.toString()} onValueChange={(v) => setApiHours(parseInt(v))}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">آخر ساعة</SelectItem>
                        <SelectItem value="6">آخر 6 ساعات</SelectItem>
                        <SelectItem value="24">آخر 24 ساعة</SelectItem>
                        <SelectItem value="168">آخر أسبوع</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingApiStats ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
                      </div>
                    </div>
                  ) : apiStats ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Card className="stat-card">
                          <CardContent className="p-4 text-center">
                            <p className="text-xs text-muted-foreground mb-1">إجمالي الطلبات</p>
                            <p className="text-3xl font-bold">{(apiStats as any).totalRequests || 0}</p>
                          </CardContent>
                        </Card>
                        <Card className="stat-card">
                          <CardContent className="p-4 text-center">
                            <p className="text-xs text-muted-foreground mb-1">متوسط الاستجابة</p>
                            <p className="text-3xl font-bold">{(apiStats as any).avgResponseTime || 0}<span className="text-lg font-normal">ms</span></p>
                          </CardContent>
                        </Card>
                        <Card className="stat-card">
                          <CardContent className="p-4 text-center">
                            <p className="text-xs text-muted-foreground mb-1">معدل النجاح</p>
                            <p className="text-3xl font-bold text-emerald-600">{(apiStats as any).successRate || 0}%</p>
                          </CardContent>
                        </Card>
                        <Card className="stat-card">
                          <CardContent className="p-4 text-center">
                            <p className="text-xs text-muted-foreground mb-1">الأخطاء</p>
                            <p className="text-3xl font-bold text-red-600">{(apiStats as any).errorCount || 0}</p>
                          </CardContent>
                        </Card>
                      </div>

                      {/* Success Rate Progress */}
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">معدل نجاح الطلبات</span>
                            <span className="text-sm text-muted-foreground">{(apiStats as any).successRate || 0}%</span>
                          </div>
                          <Progress value={(apiStats as any).successRate || 0} className="h-2" />
                        </CardContent>
                      </Card>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <Activity className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">لا توجد إحصائيات</h3>
                      <p className="text-muted-foreground">لم يتم تسجيل أي طلبات بعد</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ML Training Tab */}
            <TabsContent value="ml">
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="h-5 w-5 text-primary" />
                        سجل تدريب ML
                      </CardTitle>
                      <CardDescription>تاريخ عمليات تدريب نماذج التعلم الآلي</CardDescription>
                    </div>
                    <Select
                      value={mlAssetId?.toString() || "all"}
                      onValueChange={(v) => setMlAssetId(v === "all" ? undefined : parseInt(v))}
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="جميع الأصول" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع الأصول</SelectItem>
                        {(assets as any[]).map((asset: any) => (
                          <SelectItem key={asset.id} value={asset.id.toString()}>
                            {asset.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingML ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
                      </div>
                    </div>
                  ) : (mlHistory as any[] || []).length > 0 ? (
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-3">
                        {(mlHistory as any[]).map((log: any, index: number) => (
                          <MLTrainingItem key={index} log={log} />
                        ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <Brain className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">لا توجد سجلات تدريب</h3>
                      <p className="text-muted-foreground">لم يتم تدريب أي نماذج بعد</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Predictions Tab */}
            <TabsContent value="predictions">
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    سجل التوقعات
                  </CardTitle>
                  <CardDescription>آخر التوقعات التي تم إنشاؤها</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingPredictions ? (
                    <div className="flex items-center justify-center py-16">
                      <div className="text-center">
                        <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                        <p className="mt-4 text-muted-foreground">جاري التحميل...</p>
                      </div>
                    </div>
                  ) : (predictionLogs as any[] || []).length > 0 ? (
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-3">
                        {(predictionLogs as any[]).map((log: any, index: number) => (
                          <PredictionItem key={index} log={log} />
                        ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center py-16">
                      <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                        <TrendingUp className="h-12 w-12 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">لا توجد سجلات توقعات</h3>
                      <p className="text-muted-foreground">لم يتم إنشاء أي توقعات بعد</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  );
}
