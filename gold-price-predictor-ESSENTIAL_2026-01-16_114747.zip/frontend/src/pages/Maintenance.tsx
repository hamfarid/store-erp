/**
 * Maintenance Page
 * Displayed when the system is under maintenance
 */

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { Wrench, Clock, Bell, Twitter, Mail, RefreshCw } from "lucide-react";
import { useState, useEffect } from "react";

export default function Maintenance() {
  const [progress, setProgress] = useState(45);
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 30 });

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => Math.min(prev + 0.1, 100));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleRefresh = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-hero p-4">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-dots-pattern opacity-30" />
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-lg"
      >
        <Card className="border-0 shadow-2xl bg-card/80 backdrop-blur-sm overflow-hidden">
          {/* Progress bar at top */}
          <div className="h-1.5 bg-muted">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-gradient-to-r from-primary via-primary to-amber-500"
            />
          </div>
          
          <CardContent className="pt-12 pb-10 text-center px-8">
            {/* Animated Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.6 }}
              className="flex justify-center mb-8"
            >
              <div className="relative">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 border-4 border-dashed border-primary/30 rounded-full"
                />
                <div className="relative p-6 bg-primary/10 rounded-full">
                  <motion.div
                    animate={{ rotate: [0, 15, -15, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <Wrench className="h-12 w-12 text-primary" />
                  </motion.div>
                </div>
              </div>
            </motion.div>

            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mb-6"
            >
              <Badge variant="secondary" className="px-4 py-1.5">
                <Clock className="h-3 w-3 mr-2" />
                صيانة مجدولة
              </Badge>
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-3xl font-bold text-foreground mb-4"
            >
              نحن نقوم بتحسين النظام
            </motion.h1>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-muted-foreground mb-8 leading-relaxed"
            >
              نعتذر عن الإزعاج. نقوم حالياً بإجراء تحديثات لتحسين الأداء وإضافة ميزات جديدة.
              سنعود قريباً!
            </motion.p>

            {/* Progress Section */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mb-8 p-4 rounded-lg bg-muted/50"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">التقدم</span>
                <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">
                الوقت المتبقي المقدر: {timeLeft.hours} ساعات و {timeLeft.minutes} دقيقة
              </p>
            </motion.div>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-3 justify-center"
            >
              <Button
                onClick={handleRefresh}
                className="glow-gold group"
                size="lg"
              >
                <RefreshCw className="ml-2 h-4 w-4" />
                تحديث الصفحة
              </Button>
              
              <Button variant="outline" size="lg">
                <Bell className="ml-2 h-4 w-4" />
                إشعاري عند العودة
              </Button>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="mt-10 pt-6 border-t"
            >
              <p className="text-sm text-muted-foreground mb-4">تابعنا للحصول على التحديثات</p>
              <div className="flex justify-center gap-4">
                <Button variant="ghost" size="icon">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Mail className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
