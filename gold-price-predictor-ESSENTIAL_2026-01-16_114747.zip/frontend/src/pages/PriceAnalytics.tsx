/**
 * Price Analytics & Reports Dashboard - Premium Gold Price Predictor
 * Comprehensive price analysis with modern charts and downloadable reports
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  BarChart3,
  Download,
  RefreshCw,
  AlertCircle,
  ArrowLeft,
  Sparkles,
  Activity,
  Gauge,
  Target,
  Percent,
  Clock,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

const COLORS = {
  primary: "oklch(0.65 0.18 70)",
  success: "oklch(0.72 0.19 145)",
  warning: "oklch(0.82 0.18 85)",
  danger: "oklch(0.55 0.22 25)",
  purple: "#8b5cf6",
  cyan: "#06b6d4",
};

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// Stat Card Component
function StatCard({
  icon: Icon,
  label,
  value,
  change,
  changePercent,
  color = "primary",
  delay = 0,
}: {
  icon: any;
  label: string;
  value: string | number;
  change?: number;
  changePercent?: number;
  color?: "primary" | "success" | "warning" | "danger";
  delay?: number;
}) {
  const colors = {
    primary: "bg-primary/10 text-primary",
    success: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600",
    warning: "bg-amber-100 dark:bg-amber-900/30 text-amber-600",
    danger: "bg-red-100 dark:bg-red-900/30 text-red-600",
  };

  const isPositive = change !== undefined && change >= 0;

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      transition={{ delay }}
    >
      <Card className="stat-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-xl ${colors[color]}`}>
              <Icon className="h-5 w-5" />
            </div>
            {change !== undefined && (
              <div className={`flex items-center gap-1 ${
                isPositive ? "text-emerald-600" : "text-red-600"
              }`}>
                {isPositive ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                {changePercent !== undefined && (
                  <span className="text-sm font-medium">
                    {isPositive ? "+" : ""}{changePercent.toFixed(2)}%
                  </span>
                )}
              </div>
            )}
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">{label}</p>
            <p className="text-2xl font-bold">{value}</p>
            {change !== undefined && (
              <p className={`text-sm mt-1 ${
                isPositive ? "text-emerald-600" : "text-red-600"
              }`}>
                {isPositive ? "+" : ""}{change.toFixed(2)}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function PriceAnalytics() {
  const [, navigate] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState<string>("1");
  const [period, setPeriod] = useState<"1h" | "24h" | "7d" | "30d" | "1y">("24h");
  const [comparisonAssets, setComparisonAssets] = useState<string[]>(["1", "2"]);

  const { data: assets } = trpc.assets.list.useQuery();
  const {
    data: analytics,
    isLoading,
    refetch,
  } = trpc.monitoring.getPriceAnalytics.useQuery(
    { assetId: selectedAsset },
    { enabled: !!selectedAsset }
  );
  const { data: priceHistory } = trpc.monitoring.getPriceHistory.useQuery(
    { assetId: selectedAsset, period },
    { enabled: !!selectedAsset }
  );
  const { data: comparison } = trpc.monitoring.getAssetsComparison.useQuery(
    {
      assetIds: comparisonAssets,
      period: period === "1h" || period === "1y" ? "24h" : period,
    },
    { enabled: comparisonAssets.length > 0 }
  );
  const { data: portfolioPerformance } =
    trpc.monitoring.getPortfolioPerformance.useQuery();

  const handleDownloadReport = () => {
    if (!analytics) {return;}

    const csvContent = [
      ["تقرير تحليل الأسعار"],
      [""],
      ["الأصل", analytics.assetName],
      ["السعر الحالي", analytics.currentPrice.toFixed(2)],
      ["التغيير 24 ساعة", analytics.priceChange24h.toFixed(2)],
      ["نسبة التغيير", `${analytics.priceChangePercent24h.toFixed(2)}%`],
      ["أعلى سعر 24 ساعة", analytics.high24h.toFixed(2)],
      ["أدنى سعر 24 ساعة", analytics.low24h.toFixed(2)],
      ["التقلب", analytics.volatility.toFixed(2)],
      [
        "الاتجاه",
        analytics.trend === "up"
          ? "صاعد"
          : analytics.trend === "down"
            ? "هابط"
            : "مستقر",
      ],
      [""],
      ["تاريخ التقرير", new Date().toLocaleString("ar-EG")],
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob(["\ufeff" + csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `price_report_${analytics.assetName}_${format(new Date(), "yyyy-MM-dd")}.csv`;
    link.click();

    toast.success("تم تنزيل التقرير بنجاح");
  };

  const periodLabels: Record<string, string> = {
    "1h": "الساعة الأخيرة",
    "24h": "24 ساعة",
    "7d": "7 أيام",
    "30d": "30 يوم",
    "1y": "السنة الأخيرة",
  };

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  تحليلات الأسعار والتقارير
                </h1>
                <p className="text-sm text-muted-foreground">
                  تحليل شامل للأسعار مع رسومات بيانية تفاعلية
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={handleDownloadReport}
                variant="outline"
                size="sm"
                disabled={!analytics}
              >
                <Download className="ml-2 h-4 w-4" />
                تنزيل التقرير
              </Button>
              <Button onClick={() => refetch()} variant="outline" size="icon" disabled={isLoading}>
                <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Asset Selector */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          className="mb-8"
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                اختيار الأصل والفترة
              </CardTitle>
              <CardDescription>
                اختر الأصل والفترة الزمنية لعرض التحليلات
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-4">
              <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                <SelectTrigger data-testid="price-analytics-asset-select" className="w-[250px]">
                  <SelectValue placeholder="اختر أصل" />
                </SelectTrigger>
                <SelectContent>
                  {assets?.map((asset: any) => (
                    <SelectItem
                      key={asset.id}
                      value={asset.id.toString()}
                    >
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={period} onValueChange={(v) => setPeriod(v as any)}>
                <SelectTrigger data-testid="price-analytics-period-select" className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">آخر ساعة</SelectItem>
                  <SelectItem value="24h">آخر 24 ساعة</SelectItem>
                  <SelectItem value="7d">آخر 7 أيام</SelectItem>
                  <SelectItem value="30d">آخر 30 يوم</SelectItem>
                  <SelectItem value="1y">آخر سنة</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
              <p className="mt-4 text-muted-foreground">جاري تحميل البيانات...</p>
            </div>
          </div>
        ) : analytics ? (
          <>
            {/* Analytics Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard
                icon={DollarSign}
                label="السعر الحالي"
                value={`$${analytics.currentPrice.toFixed(2)}`}
                change={analytics.priceChange24h}
                changePercent={analytics.priceChangePercent24h}
                color={analytics.trend === "up" ? "success" : analytics.trend === "down" ? "danger" : "primary"}
                delay={0}
              />
              <StatCard
                icon={Activity}
                label="التغيير 24 ساعة"
                value={`${analytics.priceChange24h >= 0 ? "+" : ""}${analytics.priceChange24h.toFixed(2)}`}
                changePercent={analytics.priceChangePercent24h}
                color={analytics.priceChange24h >= 0 ? "success" : "danger"}
                delay={0.1}
              />
              <StatCard
                icon={Gauge}
                label="النطاق 24 ساعة"
                value={`$${analytics.low24h.toFixed(2)} - $${analytics.high24h.toFixed(2)}`}
                color="warning"
                delay={0.2}
              />
              <StatCard
                icon={BarChart3}
                label="التقلب"
                value={analytics.volatility.toFixed(2)}
                color={analytics.volatility > 5 ? "danger" : analytics.volatility > 2 ? "warning" : "success"}
                delay={0.3}
              />
            </div>

            {/* Price History Chart */}
            <motion.div
              variants={cardVariants}
              initial="initial"
              animate="animate"
              transition={{ delay: 0.4 }}
              className="mb-8"
            >
              <Card className="premium-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="h-5 w-5 text-primary" />
                        تاريخ الأسعار - {analytics.assetName}
                      </CardTitle>
                      <CardDescription>
                        تتبع حركة السعر خلال {periodLabels[period]}
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {periodLabels[period]}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  {priceHistory && priceHistory.length > 0 ? (
                    <ResponsiveContainer width="100%" height={400}>
                      <AreaChart data={priceHistory}>
                        <defs>
                          <linearGradient
                            id="colorPrice"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="oklch(0.65 0.18 70)"
                              stopOpacity={0.8}
                            />
                            <stop
                              offset="95%"
                              stopColor="oklch(0.65 0.18 70)"
                              stopOpacity={0}
                            />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis
                          dataKey="timestamp"
                          tickFormatter={(timestamp) => {
                            const date = new Date(timestamp);
                            if (period === "1h") {return format(date, "HH:mm");}
                            if (period === "24h") {return format(date, "HH:mm");}
                            if (period === "7d" || period === "30d")
                              {return format(date, "dd/MM");}
                            return format(date, "MMM yy", { locale: ar });
                          }}
                          className="text-xs"
                        />
                        <YAxis domain={["auto", "auto"]} className="text-xs" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "8px",
                          }}
                          labelFormatter={(timestamp) =>
                            format(new Date(timestamp), "dd MMMM yyyy HH:mm", {
                              locale: ar,
                            })
                          }
                          formatter={(value: number) => [
                            `$${value.toFixed(2)}`,
                            "السعر",
                          ]}
                        />
                        <Area
                          type="monotone"
                          dataKey="price"
                          stroke="oklch(0.65 0.18 70)"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#colorPrice)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-64 text-muted-foreground">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>لا توجد بيانات متاحة</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Assets Comparison */}
            {comparison && Object.keys(comparison).length > 1 && (
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.5 }}
                className="mb-8"
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" />
                      مقارنة الأصول
                    </CardTitle>
                    <CardDescription>
                      مقارنة الأداء بين الأصول المختلفة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                      <BarChart
                        data={Object.values(comparison).map((asset: any) => ({
                          name: asset.assetName,
                          price: asset.currentPrice,
                          change: asset.priceChangePercent24h,
                        }))}
                      >
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="name" className="text-xs" />
                        <YAxis
                          yAxisId="left"
                          orientation="left"
                          stroke="oklch(0.65 0.18 70)"
                          className="text-xs"
                        />
                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          stroke="oklch(0.72 0.19 145)"
                          className="text-xs"
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "8px",
                          }}
                        />
                        <Legend />
                        <Bar
                          yAxisId="left"
                          dataKey="price"
                          fill="oklch(0.65 0.18 70)"
                          name="السعر ($)"
                          radius={[8, 8, 0, 0]}
                        />
                        <Bar
                          yAxisId="right"
                          dataKey="change"
                          fill="oklch(0.72 0.19 145)"
                          name="التغيير (%)"
                          radius={[8, 8, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Portfolio Performance */}
            {portfolioPerformance && portfolioPerformance.assets.length > 0 && (
              <motion.div
                variants={cardVariants}
                initial="initial"
                animate="animate"
                transition={{ delay: 0.6 }}
              >
                <Card className="premium-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      أداء المحفظة
                    </CardTitle>
                    <CardDescription>
                      ملخص أداء محفظتك الاستثمارية
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Summary */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="stat-card">
                        <CardContent className="p-4">
                          <p className="text-sm text-muted-foreground mb-2">القيمة الإجمالية</p>
                          <p className="text-3xl font-bold">
                            ${portfolioPerformance.totalValue.toFixed(2)}
                          </p>
                        </CardContent>
                      </Card>
                      <Card className="stat-card">
                        <CardContent className="p-4">
                          <p className="text-sm text-muted-foreground mb-2">التغيير 24 ساعة</p>
                          <p
                            className={`text-3xl font-bold ${
                              portfolioPerformance.totalChange24h >= 0
                                ? "text-emerald-600"
                                : "text-red-600"
                            }`}
                          >
                            {portfolioPerformance.totalChange24h >= 0 ? "+" : ""}$
                            {portfolioPerformance.totalChange24h.toFixed(2)}
                          </p>
                        </CardContent>
                      </Card>
                      <Card className="stat-card">
                        <CardContent className="p-4">
                          <p className="text-sm text-muted-foreground mb-2">نسبة التغيير</p>
                          <p
                            className={`text-3xl font-bold ${
                              portfolioPerformance.totalChangePercent24h >= 0
                                ? "text-emerald-600"
                                : "text-red-600"
                            }`}
                          >
                            {portfolioPerformance.totalChangePercent24h >= 0
                              ? "+"
                              : ""}
                            {portfolioPerformance.totalChangePercent24h.toFixed(2)}%
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <Separator />

                    {/* Assets Chart */}
                    <div>
                      <h4 className="text-sm font-semibold mb-4">توزيع الأصول</h4>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={portfolioPerformance.assets}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis dataKey="assetName" className="text-xs" />
                          <YAxis className="text-xs" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Legend />
                          <Bar
                            dataKey="currentValue"
                            fill="oklch(0.65 0.18 70)"
                            name="القيمة الحالية ($)"
                            radius={[8, 8, 0, 0]}
                          />
                          <Bar
                            dataKey="change24h"
                            fill="oklch(0.72 0.19 145)"
                            name="التغيير 24 ساعة ($)"
                            radius={[8, 8, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        ) : (
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
          >
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>لا توجد بيانات</AlertTitle>
              <AlertDescription>
                اختر أصلاً من القائمة أعلاه لعرض التحليلات
              </AlertDescription>
            </Alert>
          </motion.div>
        )}
      </main>
    </div>
  );
}
