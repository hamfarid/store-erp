// FILE: client/src/pages/admin/AlertsList.tsx | PURPOSE: Alerts list page with CRUD operations | OWNER: Frontend Team | RELATED: backend/app/routers/alerts.py | LAST-AUDITED: 2025-01-18

/**
 * Alerts List Page
 * User page to manage price alerts (list, create, edit, delete)
 */

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Loader2,
  Plus,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  Bell,
  BellOff,
  CheckCircle,
} from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "@/api/client";

interface Alert {
  id: number;
  asset_id: number;
  alert_type: string;
  target_price: number | null;
  change_percent: number | null;
  is_active: boolean;
  is_triggered: boolean;
  triggered_at: string | null;
  notification_method: string;
  created_at: string;
}

const ALERT_TYPES = ["above", "below", "change"];

export default function AlertsList() {
  const [, navigate] = useLocation();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // Fetch alerts
  const fetchAlerts = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (typeFilter !== "all") {
        params.alert_type = typeFilter;
      }
      if (statusFilter === "active") {
        params.is_active = true;
      } else if (statusFilter === "inactive") {
        params.is_active = false;
      } else if (statusFilter === "triggered") {
        params.is_triggered = true;
      }
      const response = await apiClient.get<Alert[]>("/api/alerts", { params });
      setAlerts(response);
    } catch (error: any) {
      toast.error(`Failed to load alerts: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Delete alert
  const handleDelete = async (alertId: number) => {
    if (!confirm("Are you sure you want to delete this alert?")) {
      return;
    }

    try {
      await apiClient.delete(`/api/alerts/${alertId}`);
      toast.success("Alert deleted successfully");
      fetchAlerts();
    } catch (error: any) {
      toast.error(`Failed to delete alert: ${error.message}`);
    }
  };

  // Toggle alert active status
  const handleToggleActive = async (
    alertId: number,
    currentStatus: boolean
  ) => {
    try {
      await apiClient.put(`/api/alerts/${alertId}`, {
        is_active: !currentStatus,
      });
      toast.success(
        `Alert ${!currentStatus ? "activated" : "deactivated"} successfully`
      );
      fetchAlerts();
    } catch (error: any) {
      toast.error(`Failed to update alert: ${error.message}`);
    }
  };

  // Filter alerts by search query
  const filteredAlerts = alerts.filter(alert =>
    alert.asset_id.toString().includes(searchQuery)
  );

  // Load alerts on mount and when filters change
  useEffect(() => {
    fetchAlerts();
  }, [typeFilter, statusFilter]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Price Alerts
          </h1>
          <p className="text-slate-600">
            Manage your price alert notifications
          </p>
        </div>

        {/* Actions Bar */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search by asset ID..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Filters */}
              <div className="flex gap-2">
                {/* Type Filter */}
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="above">Above</SelectItem>
                    <SelectItem value="below">Below</SelectItem>
                    <SelectItem value="change">Change</SelectItem>
                  </SelectContent>
                </Select>

                {/* Status Filter */}
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="triggered">Triggered</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Create Button */}
              <Button onClick={() => navigate("/alerts/create")}>
                <Plus className="h-4 w-4 mr-2" />
                Create Alert
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Alerts Table */}
        <Card>
          <CardHeader>
            <CardTitle>Alerts ({filteredAlerts.length})</CardTitle>
            <CardDescription>
              {typeFilter !== "all"
                ? `${typeFilter} alerts`
                : "All price alerts"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredAlerts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-slate-500">No alerts found</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Asset ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Notification</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAlerts.map(alert => (
                    <TableRow key={alert.id}>
                      <TableCell className="font-medium">
                        #{alert.asset_id}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{alert.alert_type}</Badge>
                      </TableCell>
                      <TableCell>
                        {alert.alert_type === "change"
                          ? `${alert.change_percent}%`
                          : `$${alert.target_price}`}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Badge
                            variant={alert.is_active ? "default" : "secondary"}
                          >
                            {alert.is_active ? "Active" : "Inactive"}
                          </Badge>
                          {alert.is_triggered && (
                            <Badge variant="destructive">Triggered</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {alert.notification_method}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(alert.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => navigate(`/alerts/${alert.id}`)}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                handleToggleActive(alert.id, alert.is_active)
                              }
                            >
                              {alert.is_active ? (
                                <>
                                  <BellOff className="h-4 w-4 mr-2" />
                                  Deactivate
                                </>
                              ) : (
                                <>
                                  <Bell className="h-4 w-4 mr-2" />
                                  Activate
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleDelete(alert.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
