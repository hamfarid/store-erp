// FILE: client/src/pages/admin/AssetsList.tsx | PURPOSE: Assets list page with CRUD operations | OWNER: Frontend Team | RELATED: backend/app/routers/assets.py | LAST-AUDITED: 2025-01-18

/**
 * Assets List Page
 * Admin page to manage assets (list, create, edit, delete)
 */

import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Loader2,
  Plus,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "@/api/client";

interface Asset {
  id: number;
  symbol: string;
  name: string;
  category: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const ASSET_CATEGORIES = [
  "Precious Metals",
  "Energy",
  "Industrial Metals",
  "Cryptocurrency",
  "Currency",
  "Index",
  "Stocks",
  "Commodities",
];

export default function AssetsList() {
  const [, navigate] = useLocation();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<boolean | null>(null);

  // Fetch assets
  const fetchAssets = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (categoryFilter !== "all") {
        params.category = categoryFilter;
      }
      if (statusFilter !== null) {
        params.is_active = statusFilter;
      }
      const response = await apiClient.get<Asset[]>("/api/assets", { params });
      setAssets(response);
    } catch (error: any) {
      toast.error(`Failed to load assets: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Delete asset
  const handleDelete = async (assetId: number, symbol: string) => {
    if (!confirm(`Are you sure you want to delete asset "${symbol}"?`)) {
      return;
    }

    try {
      await apiClient.delete(`/api/assets/${assetId}`);
      toast.success(`Asset "${symbol}" deleted successfully`);
      fetchAssets();
    } catch (error: any) {
      toast.error(`Failed to delete asset: ${error.message}`);
    }
  };

  // Toggle asset active status
  const handleToggleActive = async (
    assetId: number,
    symbol: string,
    currentStatus: boolean
  ) => {
    try {
      await apiClient.put(`/api/assets/${assetId}`, {
        is_active: !currentStatus,
      });
      toast.success(
        `Asset "${symbol}" ${!currentStatus ? "activated" : "deactivated"} successfully`
      );
      fetchAssets();
    } catch (error: any) {
      toast.error(`Failed to update asset: ${error.message}`);
    }
  };

  // Load assets on mount and when filters change
  useEffect(() => {
    fetchAssets();
  }, [categoryFilter, statusFilter]);

  // Filter assets by search query (memoized to avoid setState during render)
  const filteredAssets = useMemo(() => {
    return assets.filter(
      asset =>
        asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [assets, searchQuery]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Assets Management
          </h1>
          <p className="text-slate-600">
            Manage tradable assets and commodities
          </p>
        </div>

        {/* Actions Bar */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Filters */}
              <div className="flex gap-2">
                {/* Category Filter */}
                <Select
                  value={categoryFilter}
                  onValueChange={setCategoryFilter}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {ASSET_CATEGORIES.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Status Filter */}
                <Button
                  variant={statusFilter === null ? "default" : "outline"}
                  onClick={() => setStatusFilter(null)}
                >
                  All
                </Button>
                <Button
                  variant={statusFilter === true ? "default" : "outline"}
                  onClick={() => setStatusFilter(true)}
                >
                  Active
                </Button>
                <Button
                  variant={statusFilter === false ? "default" : "outline"}
                  onClick={() => setStatusFilter(false)}
                >
                  Inactive
                </Button>
              </div>

              {/* Create Button */}
              <Button onClick={() => navigate("/admin/assets/create")}>
                <Plus className="h-4 w-4 mr-2" />
                Create Asset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Assets Table */}
        <Card>
          <CardHeader>
            <CardTitle>Assets ({filteredAssets.length})</CardTitle>
            <CardDescription>
              {categoryFilter !== "all"
                ? `${categoryFilter} assets`
                : statusFilter === null
                  ? "All assets in the system"
                  : statusFilter
                    ? "Active assets only"
                    : "Inactive assets only"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredAssets.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-slate-500">No assets found</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAssets.map(asset => (
                    <TableRow key={asset.id}>
                      <TableCell className="font-medium font-mono">
                        {asset.symbol}
                      </TableCell>
                      <TableCell>{asset.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{asset.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={asset.is_active ? "default" : "secondary"}
                        >
                          {asset.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(asset.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() =>
                                navigate(`/admin/assets/${asset.id}`)
                              }
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                handleToggleActive(
                                  asset.id,
                                  asset.symbol,
                                  asset.is_active
                                )
                              }
                            >
                              {asset.is_active ? (
                                <>
                                  <TrendingDown className="h-4 w-4 mr-2" />
                                  Deactivate
                                </>
                              ) : (
                                <>
                                  <TrendingUp className="h-4 w-4 mr-2" />
                                  Activate
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() =>
                                handleDelete(asset.id, asset.symbol)
                              }
                              className="text-red-600"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
