// FILE: client/src/pages/admin/AlertsForm.tsx | PURPOSE: Alert create/edit form | OWNER: Frontend Team | RELATED: backend/app/routers/alerts.py | LAST-AUDITED: 2025-01-18

/**
 * Alert Form Page
 * Create or edit price alert with conditional validation
 */

import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "@/api/client";

// Validation schema with conditional validation
const alertSchema = z
  .object({
    asset_id: z.coerce.number().min(1, "Asset ID is required"),
    alert_type: z.union([
      z.literal("above"),
      z.literal("below"),
      z.literal("change"),
    ]),
    target_price: z.coerce.number().optional(),
    change_percent: z.coerce.number().optional(),
    notification_method: z.union([
      z.literal("email"),
      z.literal("sms"),
      z.literal("push"),
    ]),
  })
  .refine(
    data => {
      if (data.alert_type === "above" || data.alert_type === "below") {
        return data.target_price !== undefined && data.target_price > 0;
      }
      return true;
    },
    {
      message: "Target price is required for 'above' and 'below' alert types",
      path: ["target_price"],
    }
  )
  .refine(
    data => {
      if (data.alert_type === "change") {
        return data.change_percent !== undefined && data.change_percent !== 0;
      }
      return true;
    },
    {
      message: "Change percent is required for 'change' alert type",
      path: ["change_percent"],
    }
  );

type AlertFormData = z.infer<typeof alertSchema>;

interface Alert {
  id: number;
  asset_id: number;
  alert_type: string;
  target_price: number | null;
  change_percent: number | null;
  notification_method: string;
}

export default function AlertsForm() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const isEdit = !!id;

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<AlertFormData>({
    resolver: zodResolver(alertSchema) as any,
    defaultValues: {
      asset_id: 0,
      alert_type: "above",
      target_price: undefined,
      change_percent: undefined,
      notification_method: "email",
    },
  });

  const alertType = watch("alert_type");
  const notificationMethod = watch("notification_method");

  // Fetch alert data if editing
  useEffect(() => {
    if (isEdit) {
      fetchAlert();
    }
  }, [id]);

  const fetchAlert = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get<Alert>(`/api/alerts/${id}`);
      setValue("asset_id", response.asset_id);
      setValue(
        "alert_type",
        response.alert_type as "above" | "below" | "change"
      );
      setValue("target_price", response.target_price || undefined);
      setValue("change_percent", response.change_percent || undefined);
      setValue(
        "notification_method",
        response.notification_method as "email" | "sms" | "push"
      );
    } catch (error: any) {
      toast.error(`Failed to load alert: ${error.message}`);
      navigate("/alerts");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: AlertFormData) => {
    try {
      setSubmitting(true);

      const payload: any = {
        asset_id: data.asset_id,
        alert_type: data.alert_type,
        notification_method: data.notification_method,
      };

      if (data.alert_type === "above" || data.alert_type === "below") {
        payload.target_price = data.target_price;
      } else if (data.alert_type === "change") {
        payload.change_percent = data.change_percent;
      }

      if (isEdit) {
        // Update alert
        await apiClient.put(`/api/alerts/${id}`, payload);
        toast.success("Alert updated successfully");
      } else {
        // Create alert
        await apiClient.post("/api/alerts", payload);
        toast.success("Alert created successfully");
      }

      navigate("/alerts");
    } catch (error: any) {
      toast.error(
        `Failed to ${isEdit ? "update" : "create"} alert: ${error.message}`
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/alerts")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Alerts
          </Button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            {isEdit ? "Edit Alert" : "Create Alert"}
          </h1>
          <p className="text-slate-600">
            {isEdit ? "Update alert settings" : "Set up a new price alert"}
          </p>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>{isEdit ? "Alert Details" : "New Alert"}</CardTitle>
            <CardDescription>
              {isEdit
                ? "Update the alert's settings below"
                : "Configure your price alert notification"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Asset ID */}
              <div className="space-y-2">
                <Label htmlFor="asset_id">Asset ID</Label>
                <Input
                  id="asset_id"
                  type="number"
                  {...register("asset_id")}
                  placeholder="Enter asset ID"
                />
                {errors.asset_id && (
                  <p className="text-sm text-red-600">
                    {errors.asset_id.message}
                  </p>
                )}
              </div>

              {/* Alert Type */}
              <div className="space-y-2">
                <Label htmlFor="alert_type">Alert Type</Label>
                <Select
                  value={alertType}
                  onValueChange={value =>
                    setValue(
                      "alert_type",
                      value as "above" | "below" | "change"
                    )
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select alert type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="above">Price Above</SelectItem>
                    <SelectItem value="below">Price Below</SelectItem>
                    <SelectItem value="change">Price Change %</SelectItem>
                  </SelectContent>
                </Select>
                {errors.alert_type && (
                  <p className="text-sm text-red-600">
                    {errors.alert_type.message}
                  </p>
                )}
              </div>

              {/* Target Price (for above/below) */}
              {(alertType === "above" || alertType === "below") && (
                <div className="space-y-2">
                  <Label htmlFor="target_price">Target Price ($)</Label>
                  <Input
                    id="target_price"
                    type="number"
                    step="0.01"
                    {...register("target_price")}
                    placeholder="Enter target price"
                  />
                  {errors.target_price && (
                    <p className="text-sm text-red-600">
                      {errors.target_price.message}
                    </p>
                  )}
                </div>
              )}

              {/* Change Percent (for change) */}
              {alertType === "change" && (
                <div className="space-y-2">
                  <Label htmlFor="change_percent">Change Percent (%)</Label>
                  <Input
                    id="change_percent"
                    type="number"
                    step="0.01"
                    {...register("change_percent")}
                    placeholder="Enter change percentage"
                  />
                  {errors.change_percent && (
                    <p className="text-sm text-red-600">
                      {errors.change_percent.message}
                    </p>
                  )}
                  <p className="text-sm text-slate-500">
                    Positive for increase, negative for decrease
                  </p>
                </div>
              )}

              {/* Notification Method */}
              <div className="space-y-2">
                <Label htmlFor="notification_method">Notification Method</Label>
                <Select
                  value={notificationMethod}
                  onValueChange={value =>
                    setValue(
                      "notification_method",
                      value as "email" | "sms" | "push"
                    )
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select notification method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="sms">SMS</SelectItem>
                    <SelectItem value="push">Push Notification</SelectItem>
                  </SelectContent>
                </Select>
                {errors.notification_method && (
                  <p className="text-sm text-red-600">
                    {errors.notification_method.message}
                  </p>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/alerts")}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={submitting} className="flex-1">
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {isEdit ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      {isEdit ? "Update Alert" : "Create Alert"}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
