// FILE: client/src/pages/admin/UserForm.tsx | PURPOSE: User create/edit form | OWNER: Frontend Team | RELATED: backend/app/routers/users.py | LAST-AUDITED: 2025-01-18

/**
 * User Form Page
 * Create or edit user with validation
 */

import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Loader2, ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "@/api/client";

// Validation schema
const userSchema = z.object({
  username: z
    .string()
    .min(3, "Username must be at least 3 characters")
    .max(50, "Username must be at most 50 characters")
    .regex(
      /^[a-zA-Z0-9_]+$/,
      "Username must contain only alphanumeric characters and underscores"
    ),
  email: z.string().email("Invalid email address"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one digit")
    .optional()
    .or(z.literal("")),
  is_admin: z.boolean().default(false),
});

type UserFormData = z.infer<typeof userSchema>;

interface User {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
  is_admin: boolean;
}

export default function UserForm() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const isEdit = !!id;

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<UserFormData>({
    resolver: zodResolver(userSchema) as any,
    defaultValues: {
      username: "",
      email: "",
      password: "",
      is_admin: false,
    },
  });

  const isAdmin = watch("is_admin");

  // Fetch user data if editing
  useEffect(() => {
    if (isEdit) {
      fetchUser();
    }
  }, [id]);

  const fetchUser = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get<User>(`/api/users/${id}`);
      setValue("username", response.username);
      setValue("email", response.email);
      setValue("is_admin", response.is_admin);
    } catch (error: any) {
      toast.error(`Failed to load user: ${error.message}`);
      navigate("/admin/users");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: UserFormData) => {
    try {
      setSubmitting(true);

      if (isEdit) {
        // Update user
        await apiClient.put(`/api/users/${id}`, {
          email: data.email,
          is_admin: data.is_admin,
        });
        toast.success("User updated successfully");
      } else {
        // Create user
        await apiClient.post("/api/users", {
          username: data.username,
          email: data.email,
          password: data.password,
          is_admin: data.is_admin,
        });
        toast.success("User created successfully");
      }

      navigate("/admin/users");
    } catch (error: any) {
      toast.error(
        `Failed to ${isEdit ? "update" : "create"} user: ${error.message}`
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/admin/users")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Users
          </Button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            {isEdit ? "Edit User" : "Create User"}
          </h1>
          <p className="text-slate-600">
            {isEdit
              ? "Update user information"
              : "Add a new user to the system"}
          </p>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>{isEdit ? "User Details" : "New User"}</CardTitle>
            <CardDescription>
              {isEdit
                ? "Update the user's information below"
                : "Fill in the details to create a new user"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Username */}
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  {...register("username")}
                  disabled={isEdit}
                  placeholder="Enter username"
                />
                {errors.username && (
                  <p className="text-sm text-red-600">
                    {errors.username.message}
                  </p>
                )}
                {isEdit && (
                  <p className="text-sm text-slate-500">
                    Username cannot be changed
                  </p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...register("email")}
                  placeholder="Enter email address"
                />
                {errors.email && (
                  <p className="text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              {/* Password (only for create) */}
              {!isEdit && (
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    {...register("password")}
                    placeholder="Enter password"
                  />
                  {errors.password && (
                    <p className="text-sm text-red-600">
                      {errors.password.message}
                    </p>
                  )}
                  <p className="text-sm text-slate-500">
                    Password must be at least 8 characters with uppercase,
                    lowercase, and digit
                  </p>
                </div>
              )}

              {/* Admin Role */}
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="is_admin">Administrator Role</Label>
                  <p className="text-sm text-slate-500">
                    Grant this user administrator privileges
                  </p>
                </div>
                <Switch
                  id="is_admin"
                  checked={isAdmin}
                  onCheckedChange={checked => setValue("is_admin", checked)}
                />
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/admin/users")}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={submitting} className="flex-1">
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {isEdit ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      {isEdit ? "Update User" : "Create User"}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
