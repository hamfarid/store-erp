// FILE: client/src/pages/admin/AssetsForm.tsx | PURPOSE: Asset create/edit form | OWNER: Frontend Team | RELATED: backend/app/routers/assets.py | LAST-AUDITED: 2025-01-18

/**
 * Asset Form Page
 * Create or edit asset with validation
 */

import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "@/api/client";

const ASSET_CATEGORIES = [
  "Precious Metals",
  "Energy",
  "Industrial Metals",
  "Cryptocurrency",
  "Currency",
  "Index",
  "Stocks",
  "Commodities",
];

// Validation schema
const assetSchema = z.object({
  symbol: z
    .string()
    .min(1, "Symbol is required")
    .max(20, "Symbol must be at most 20 characters")
    .regex(
      /^[A-Z0-9]+$/,
      "Symbol must contain only uppercase letters and numbers"
    ),
  name: z
    .string()
    .min(1, "Name is required")
    .max(100, "Name must be at most 100 characters"),
  category: z.string().min(1, "Category is required"),
  description: z.string().optional(),
});

type AssetFormData = z.infer<typeof assetSchema>;

interface Asset {
  id: number;
  symbol: string;
  name: string;
  category: string;
  description: string | null;
  is_active: boolean;
}

export default function AssetsForm() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const isEdit = !!id;

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<AssetFormData>({
    resolver: zodResolver(assetSchema),
    defaultValues: {
      symbol: "",
      name: "",
      category: "",
      description: "",
    },
  });

  const category = watch("category");

  // Fetch asset data if editing
  useEffect(() => {
    if (isEdit) {
      fetchAsset();
    }
  }, [id]);

  const fetchAsset = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get<Asset>(`/api/assets/${id}`);
      setValue("symbol", response.symbol);
      setValue("name", response.name);
      setValue("category", response.category);
      setValue("description", response.description || "");
    } catch (error: any) {
      toast.error(`Failed to load asset: ${error.message}`);
      navigate("/admin/assets");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: AssetFormData) => {
    try {
      setSubmitting(true);

      if (isEdit) {
        // Update asset
        await apiClient.put(`/api/assets/${id}`, {
          name: data.name,
          category: data.category,
          description: data.description || null,
        });
        toast.success("Asset updated successfully");
      } else {
        // Create asset
        await apiClient.post("/api/assets", {
          symbol: data.symbol,
          name: data.name,
          category: data.category,
          description: data.description || null,
        });
        toast.success("Asset created successfully");
      }

      navigate("/admin/assets");
    } catch (error: any) {
      toast.error(
        `Failed to ${isEdit ? "update" : "create"} asset: ${error.message}`
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/admin/assets")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Assets
          </Button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            {isEdit ? "Edit Asset" : "Create Asset"}
          </h1>
          <p className="text-slate-600">
            {isEdit ? "Update asset information" : "Add a new tradable asset"}
          </p>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>{isEdit ? "Asset Details" : "New Asset"}</CardTitle>
            <CardDescription>
              {isEdit
                ? "Update the asset's information below"
                : "Fill in the details to create a new asset"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Symbol */}
              <div className="space-y-2">
                <Label htmlFor="symbol">Symbol</Label>
                <Input
                  id="symbol"
                  {...register("symbol")}
                  disabled={isEdit}
                  placeholder="e.g., GOLD, BTC, EUR"
                  className="font-mono uppercase"
                  onChange={e => {
                    e.target.value = e.target.value.toUpperCase();
                    register("symbol").onChange(e);
                  }}
                />
                {errors.symbol && (
                  <p className="text-sm text-red-600">
                    {errors.symbol.message}
                  </p>
                )}
                {isEdit && (
                  <p className="text-sm text-slate-500">
                    Symbol cannot be changed
                  </p>
                )}
              </div>

              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  {...register("name")}
                  placeholder="e.g., Gold, Bitcoin, Euro"
                />
                {errors.name && (
                  <p className="text-sm text-red-600">{errors.name.message}</p>
                )}
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={category}
                  onValueChange={value => setValue("category", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {ASSET_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.category && (
                  <p className="text-sm text-red-600">
                    {errors.category.message}
                  </p>
                )}
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  {...register("description")}
                  placeholder="Enter a brief description of the asset"
                  rows={4}
                />
                {errors.description && (
                  <p className="text-sm text-red-600">
                    {errors.description.message}
                  </p>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/admin/assets")}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={submitting} className="flex-1">
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {isEdit ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      {isEdit ? "Update Asset" : "Create Asset"}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
