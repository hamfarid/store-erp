import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Home,
  ArrowLeft,
  RefreshCw,
  ShieldAlert,
  Lock,
  CreditCard,
  FileQuestion,
  Ban,
  ServerCrash,
  Server,
  Network,
  Clock,
  AlertTriangle,
} from "lucide-react";

interface ErrorConfig {
  code: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;
  iconBg: string;
  showRefresh?: boolean;
}

const errorConfigs: Record<string, ErrorConfig> = {
  "400": {
    code: "400",
    title: "طلب غير صحيح",
    description:
      "الطلب الذي أرسلته غير صحيح أو يحتوي على بيانات غير صالحة. يرجى التحقق من المدخلات والمحاولة مرة أخرى.",
    icon: <AlertTriangle className="h-12 w-12" />,
    gradient: "from-orange-50 to-red-50",
    iconBg: "from-orange-500 to-red-600",
  },
  "401": {
    code: "401",
    title: "غير مصرح",
    description:
      "يجب عليك تسجيل الدخول للوصول إلى هذه الصفحة. يرجى تسجيل الدخول والمحاولة مرة أخرى.",
    icon: <Lock className="h-12 w-12" />,
    gradient: "from-blue-50 to-indigo-50",
    iconBg: "from-blue-500 to-indigo-600",
  },
  "402": {
    code: "402",
    title: "الدفع مطلوب",
    description:
      "هذه الميزة تتطلب اشتراكاً مدفوعاً. يرجى الترقية إلى خطة مدفوعة للوصول إلى هذا المحتوى.",
    icon: <CreditCard className="h-12 w-12" />,
    gradient: "from-green-50 to-emerald-50",
    iconBg: "from-green-500 to-emerald-600",
  },
  "403": {
    code: "403",
    title: "ممنوع الوصول",
    description:
      "ليس لديك صلاحية الوصول إلى هذه الصفحة. يرجى التواصل مع المسؤول إذا كنت تعتقد أن هذا خطأ.",
    icon: <ShieldAlert className="h-12 w-12" />,
    gradient: "from-red-50 to-orange-50",
    iconBg: "from-red-500 to-orange-600",
  },
  "404": {
    code: "404",
    title: "الصفحة غير موجودة",
    description:
      "عذراً، الصفحة التي تبحث عنها غير موجودة. ربما تم نقلها أو حذفها.",
    icon: <FileQuestion className="h-12 w-12" />,
    gradient: "from-slate-50 to-gray-50",
    iconBg: "from-slate-500 to-gray-600",
  },
  "405": {
    code: "405",
    title: "الطريقة غير مسموحة",
    description:
      "طريقة HTTP المستخدمة غير مسموحة لهذا المورد. يرجى استخدام طريقة مختلفة.",
    icon: <Ban className="h-12 w-12" />,
    gradient: "from-yellow-50 to-amber-50",
    iconBg: "from-yellow-500 to-amber-600",
  },
  "500": {
    code: "500",
    title: "خطأ في الخادم",
    description:
      "حدث خطأ غير متوقع في الخادم. نحن نعمل على حل المشكلة. يرجى المحاولة مرة أخرى لاحقاً.",
    icon: <ServerCrash className="h-12 w-12" />,
    gradient: "from-purple-50 to-pink-50",
    iconBg: "from-purple-500 to-pink-600",
    showRefresh: true,
  },
  "501": {
    code: "501",
    title: "غير مطبق",
    description:
      "الخادم لا يدعم الوظيفة المطلوبة. هذه الميزة غير متاحة حالياً.",
    icon: <Server className="h-12 w-12" />,
    gradient: "from-indigo-50 to-purple-50",
    iconBg: "from-indigo-500 to-purple-600",
  },
  "502": {
    code: "502",
    title: "بوابة سيئة",
    description:
      "الخادم تلقى استجابة غير صالحة من خادم آخر. يرجى المحاولة مرة أخرى لاحقاً.",
    icon: <Network className="h-12 w-12" />,
    gradient: "from-cyan-50 to-blue-50",
    iconBg: "from-cyan-500 to-blue-600",
    showRefresh: true,
  },
  "503": {
    code: "503",
    title: "الخدمة غير متاحة",
    description:
      "الخادم غير متاح حالياً بسبب الصيانة أو الحمل الزائد. يرجى المحاولة مرة أخرى لاحقاً.",
    icon: <Clock className="h-12 w-12" />,
    gradient: "from-amber-50 to-orange-50",
    iconBg: "from-amber-500 to-orange-600",
    showRefresh: true,
  },
  "504": {
    code: "504",
    title: "انتهت مهلة البوابة",
    description:
      "استغرق الخادم وقتاً طويلاً للاستجابة. يرجى المحاولة مرة أخرى.",
    icon: <Clock className="h-12 w-12" />,
    gradient: "from-rose-50 to-red-50",
    iconBg: "from-rose-500 to-red-600",
    showRefresh: true,
  },
  "505": {
    code: "505",
    title: "إصدار HTTP غير مدعوم",
    description:
      "إصدار بروتوكول HTTP المستخدم في الطلب غير مدعوم من قبل الخادم.",
    icon: <Server className="h-12 w-12" />,
    gradient: "from-violet-50 to-purple-50",
    iconBg: "from-violet-500 to-purple-600",
  },
};

export default function ErrorPage() {
  const [, navigate] = useLocation();
  const params = useParams();
  const errorCode = params.code || "404";

  const config = errorConfigs[errorCode] || errorConfigs["404"];

  const handleRefresh = () => {
    window.location.reload();
  };

  return (
    <div
      className={`min-h-screen bg-gradient-to-br ${config.gradient} flex items-center justify-center p-4`}
    >
      <Card className="max-w-2xl w-full">
        <CardContent className="p-12 text-center">
          {/* Icon */}
          <div className="mb-8">
            <div
              className={`inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br ${config.iconBg} text-white`}
            >
              {config.icon}
            </div>
          </div>

          {/* Error Code */}
          <h1 className="text-8xl font-bold text-slate-700 mb-4">
            {config.code}
          </h1>

          {/* Title */}
          <h2 className="text-3xl font-bold text-slate-800 mb-4">
            {config.title}
          </h2>

          {/* Description */}
          <p className="text-lg text-slate-600 mb-8 max-w-md mx-auto">
            {config.description}
          </p>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => navigate("-1")} variant="outline">
              <ArrowLeft className="h-4 w-4 ml-2" />
              العودة للصفحة السابقة
            </Button>
            {config.showRefresh && (
              <Button size="lg" onClick={handleRefresh} variant="outline">
                <RefreshCw className="h-4 w-4 ml-2" />
                إعادة تحميل الصفحة
              </Button>
            )}
            <Button size="lg" onClick={() => navigate("/")}>
              <Home className="h-4 w-4 ml-2" />
              العودة للرئيسية
            </Button>
          </div>

          {/* Additional Info */}
          <div className="mt-12 pt-8 border-t border-slate-200">
            <p className="text-sm text-slate-500 mb-2">
              إذا استمرت المشكلة، يرجى التواصل مع فريق الدعم الفني.
            </p>
            <p className="text-xs text-slate-400">
              رمز الخطأ: {config.code} | الوقت:{" "}
              {new Date().toLocaleString("ar-EG")}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
