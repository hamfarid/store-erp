/**
 * Reports Setup Page
 * Configure report generation settings and templates
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Settings, 
  Calendar, 
  Bell, 
  Download, 
  Mail,
  Clock,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  Save,
  RefreshCw
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface ReportConfig {
  type: string;
  name: string;
  enabled: boolean;
  frequency: string;
  format: string;
  emailEnabled: boolean;
  recipients: string[];
}

const defaultReportConfigs: ReportConfig[] = [
  {
    type: "portfolio",
    name: "تقرير أداء المحفظة",
    enabled: true,
    frequency: "weekly",
    format: "pdf",
    emailEnabled: false,
    recipients: [],
  },
  {
    type: "predictions",
    name: "تقرير دقة التوقعات",
    enabled: true,
    frequency: "daily",
    format: "csv",
    emailEnabled: false,
    recipients: [],
  },
  {
    type: "alerts",
    name: "تقرير التنبيهات",
    enabled: true,
    frequency: "daily",
    format: "pdf",
    emailEnabled: true,
    recipients: [],
  },
  {
    type: "market",
    name: "تقرير تحليل السوق",
    enabled: false,
    frequency: "weekly",
    format: "pdf",
    emailEnabled: false,
    recipients: [],
  },
];

export default function ReportsSetup() {
  const [reportConfigs, setReportConfigs] = useState<ReportConfig[]>(defaultReportConfigs);
  const [scheduleTime, setScheduleTime] = useState("09:00");
  const [timezone, setTimezone] = useState("Asia/Riyadh");
  const [isLoading, setIsLoading] = useState(false);

  const handleConfigChange = (index: number, field: keyof ReportConfig, value: any) => {
    const newConfigs = [...reportConfigs];
    newConfigs[index] = { ...newConfigs[index], [field]: value };
    setReportConfigs(newConfigs);
  };

  const handleSaveSettings = async () => {
    setIsLoading(true);
    try {
      // Save report settings to backend
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      toast.success("تم حفظ إعدادات التقارير بنجاح");
    } catch (error) {
      toast.error("فشل في حفظ الإعدادات");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateReport = async (reportType: string) => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate report generation
      toast.success(`تم إنشاء التقرير بنجاح`);
    } catch (error) {
      toast.error("فشل في إنشاء التقرير");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
          إعداد التقارير
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          قم بتكوين إعدادات التقارير وجدولة إرسالها تلقائياً
        </p>
      </div>

      <Tabs defaultValue="reports" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 max-w-md">
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            التقارير
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            الجدولة
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            الإشعارات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid gap-4">
            {reportConfigs.map((config, index) => (
              <Card key={config.type}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {config.type === "portfolio" && <BarChart3 className="w-5 h-5 text-blue-500" />}
                      {config.type === "predictions" && <TrendingUp className="w-5 h-5 text-green-500" />}
                      {config.type === "alerts" && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                      {config.type === "market" && <FileText className="w-5 h-5 text-purple-500" />}
                      <div>
                        <CardTitle className="text-lg">{config.name}</CardTitle>
                        <CardDescription>
                          {config.type === "portfolio" && "تقرير شامل عن أداء محفظتك الاستثمارية"}
                          {config.type === "predictions" && "تحليل دقة التوقعات السابقة"}
                          {config.type === "alerts" && "ملخص التنبيهات المُفعّلة والمُطلقة"}
                          {config.type === "market" && "تحليل اتجاهات السوق والأصول"}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Switch
                        checked={config.enabled}
                        onCheckedChange={(checked) => handleConfigChange(index, "enabled", checked)}
                      />
                      {config.enabled && (
                        <Badge variant="secondary" className="bg-green-100 text-green-700">
                          مُفعّل
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                {config.enabled && (
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>التكرار</Label>
                        <Select
                          value={config.frequency}
                          onValueChange={(value) => handleConfigChange(index, "frequency", value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">يومياً</SelectItem>
                            <SelectItem value="weekly">أسبوعياً</SelectItem>
                            <SelectItem value="monthly">شهرياً</SelectItem>
                            <SelectItem value="manual">يدوي فقط</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>صيغة التصدير</Label>
                        <Select
                          value={config.format}
                          onValueChange={(value) => handleConfigChange(index, "format", value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pdf">PDF</SelectItem>
                            <SelectItem value="csv">CSV</SelectItem>
                            <SelectItem value="excel">Excel</SelectItem>
                            <SelectItem value="json">JSON</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => handleGenerateReport(config.type)}
                          disabled={isLoading}
                        >
                          <Download className="w-4 h-4 ml-2" />
                          إنشاء الآن
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={config.emailEnabled}
                        onCheckedChange={(checked) => handleConfigChange(index, "emailEnabled", checked)}
                      />
                      <Label>إرسال بالبريد الإلكتروني</Label>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                إعدادات الجدولة
              </CardTitle>
              <CardDescription>
                حدد وقت إنشاء وإرسال التقارير التلقائية
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="scheduleTime">وقت الإرسال</Label>
                  <Input
                    id="scheduleTime"
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">المنطقة الزمنية</Label>
                  <Select value={timezone} onValueChange={setTimezone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Asia/Riyadh">توقيت الرياض (GMT+3)</SelectItem>
                      <SelectItem value="Asia/Dubai">توقيت دبي (GMT+4)</SelectItem>
                      <SelectItem value="Africa/Cairo">توقيت القاهرة (GMT+2)</SelectItem>
                      <SelectItem value="Europe/London">توقيت لندن (GMT+0)</SelectItem>
                      <SelectItem value="America/New_York">توقيت نيويورك (GMT-5)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  سيتم إنشاء التقارير التلقائية في الساعة {scheduleTime} بتوقيت {timezone === "Asia/Riyadh" ? "الرياض" : timezone}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                إعدادات البريد الإلكتروني
              </CardTitle>
              <CardDescription>
                قم بتكوين إعدادات إرسال التقارير عبر البريد الإلكتروني
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="recipients">المستلمون</Label>
                <Input
                  id="recipients"
                  placeholder="أدخل البريد الإلكتروني (افصل بين عدة عناوين بفاصلة)"
                />
                <p className="text-sm text-gray-500">
                  يمكنك إضافة عدة عناوين بريد إلكتروني مفصولة بفواصل
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="attachReport" defaultChecked />
                <Label htmlFor="attachReport">إرفاق التقرير كملف</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="summaryOnly" />
                <Label htmlFor="summaryOnly">إرسال ملخص فقط</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-4 mt-6">
        <Button variant="outline" onClick={() => setReportConfigs(defaultReportConfigs)}>
          <RefreshCw className="w-4 h-4 ml-2" />
          إعادة تعيين
        </Button>
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          <Save className="w-4 h-4 ml-2" />
          {isLoading ? "جاري الحفظ..." : "حفظ الإعدادات"}
        </Button>
      </div>
    </div>
  );
}

