/**
 * Backup Management Page
 * Export/Import database and AI training data
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import {
  Database,
  Download,
  Upload,
  Trash2,
  HardDrive,
  Brain,
  FileArchive,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function BackupManagement() {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);

  const {
    data: backups,
    isLoading,
    refetch,
  } = trpc.backup.listBackups.useQuery();

  const createFullBackupMutation = trpc.backup.createFullBackup.useMutation({
    onSuccess: result => {
      if (result.success) {
        toast.success("تم إنشاء النسخة الاحتياطية بنجاح!");
        refetch();
      } else {
        toast.error(`فشل إنشاء النسخة الاحتياطية: ${result.error}`);
      }
    },
    onError: error => {
      toast.error(`خطأ: ${error.message}`);
    },
  });

  const deleteBackupMutation = trpc.backup.deleteBackup.useMutation({
    onSuccess: result => {
      if (result.success) {
        toast.success("تم حذف النسخة الاحتياطية");
        refetch();
      } else {
        toast.error(`فشل الحذف: ${result.message}`);
      }
    },
    onError: error => {
      toast.error(`خطأ: ${error.message}`);
    },
  });

  const handleExportDatabase = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportDatabase as any).query();
      if (result.success && result.data) {
        // Download as JSON file
        const blob = new Blob([JSON.stringify(result.data, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `database-export-${new Date().toISOString().split("T")[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast.success("تم تصدير قاعدة البيانات بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportAIData = async () => {
    setIsExporting(true);
    try {
      const result = await (trpc.backup.exportAIData as any).query();
      if (result.success && result.data) {
        // Download as JSON file
        const blob = new Blob([JSON.stringify(result.data, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `ai-training-data-${new Date().toISOString().split("T")[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast.success("تم تصدير بيانات التعلم بنجاح!");
      } else {
        toast.error(`فشل التصدير: ${result.error}`);
      }
    } catch (error) {
      toast.error(`خطأ: ${error}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleCreateFullBackup = () => {
    if (confirm("هل تريد إنشاء نسخة احتياطية كاملة؟")) {
      createFullBackupMutation.mutate();
    }
  };

  const handleImportFile = async () => {
    if (!importFile) {
      toast.error("الرجاء اختيار ملف");
      return;
    }

    setIsImporting(true);
    try {
      const text = await importFile.text();
      const data = JSON.parse(text);

      // Determine import type based on file content
      if (data.database && data.aiTrainingData) {
        // Full backup
        const result = await (trpc.backup.restoreFullBackup as any).mutate(
          data
        );
        if (result.success) {
          toast.success(result.message);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(result.message);
        }
      } else if (data.tables) {
        // Database only
        const result = await (trpc.backup.importDatabase as any).mutate(data);
        if (result.success) {
          toast.success(`تم استيراد ${result.imported} سجل`);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(`فشل الاستيراد: ${result.errors.join(", ")}`);
        }
      } else if (data.trainingExamples) {
        // AI data only
        const result = await (trpc.backup.importAIData as any).mutate(data);
        if (result.success) {
          toast.success(result.message);
          setImportDialogOpen(false);
          setImportFile(null);
        } else {
          toast.error(result.message);
        }
      } else {
        toast.error("تنسيق ملف غير صالح");
      }
    } catch (error) {
      toast.error(`خطأ في قراءة الملف: ${error}`);
    } finally {
      setIsImporting(false);
    }
  };

  const handleDeleteBackup = (fileName: string) => {
    if (confirm(`هل تريد حذف النسخة الاحتياطية: ${fileName}؟`)) {
      deleteBackupMutation.mutate({ fileName });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) {return `${bytes} B`;}
    if (bytes < 1024 * 1024) {return `${(bytes / 1024).toFixed(2)} KB`;}
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">إدارة النسخ الاحتياطي</h1>
        <p className="text-muted-foreground">
          تصدير واستيراد قاعدة البيانات وبيانات التعلم
        </p>
      </div>

      {/* Warning Alert */}
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>تحذير</AlertTitle>
        <AlertDescription>
          استيراد البيانات سيستبدل البيانات الحالية. تأكد من إنشاء نسخة احتياطية
          قبل الاستيراد.
        </AlertDescription>
      </Alert>

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            تصدير البيانات
          </CardTitle>
          <CardDescription>
            تحميل نسخة من قاعدة البيانات أو بيانات التعلم
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              data-testid="export-database-button"
              onClick={handleExportDatabase}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Database className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "تصدير قاعدة البيانات"}
            </Button>

            <Button
              data-testid="export-ai-data-button"
              onClick={handleExportAIData}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Brain className="mr-2 h-4 w-4" />
              {isExporting ? "جاري التصدير..." : "تصدير بيانات التعلم"}
            </Button>

            <Button
              data-testid="create-full-backup-button"
              onClick={handleCreateFullBackup}
              disabled={createFullBackupMutation.isPending}
              className="w-full"
            >
              <FileArchive className="mr-2 h-4 w-4" />
              {createFullBackupMutation.isPending
                ? "جاري الإنشاء..."
                : "نسخة احتياطية كاملة"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            استيراد البيانات
          </CardTitle>
          <CardDescription>
            استعادة البيانات من ملف نسخة احتياطية
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full md:w-auto">
                <Upload className="mr-2 h-4 w-4" />
                استيراد من ملف
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>استيراد البيانات</DialogTitle>
                <DialogDescription>
                  اختر ملف JSON لاستيراد البيانات
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="import-file">ملف النسخة الاحتياطية</Label>
                  <Input
                    id="import-file"
                    type="file"
                    accept=".json"
                    onChange={e => setImportFile(e.target.files?.[0] || null)}
                  />
                </div>
                {importFile && (
                  <div className="text-sm text-muted-foreground">
                    الملف المختار: {importFile.name} (
                    {formatFileSize(importFile.size)})
                  </div>
                )}
                <Button
                  onClick={handleImportFile}
                  disabled={!importFile || isImporting}
                  className="w-full"
                >
                  {isImporting ? "جاري الاستيراد..." : "استيراد"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Backups List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5" />
                النسخ الاحتياطية المحفوظة
              </CardTitle>
              <CardDescription>
                قائمة النسخ الاحتياطية المتوفرة على الخادم
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => refetch()}
              disabled={isLoading}
            >
              <RefreshCw
                className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`}
              />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              جاري التحميل...
            </div>
          ) : !backups || backups.backups.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد نسخ احتياطية محفوظة
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الملف</TableHead>
                  <TableHead>الحجم</TableHead>
                  <TableHead>تاريخ الإنشاء</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {backups.backups.map(backup => (
                  <TableRow key={backup.fileName}>
                    <TableCell className="font-medium">
                      {backup.fileName}
                    </TableCell>
                    <TableCell>{formatFileSize(backup.size)}</TableCell>
                    <TableCell>
                      {format(new Date(backup.createdAt), "PPp", {
                        locale: ar,
                      })}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteBackup(backup.fileName)}
                        disabled={deleteBackupMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
