import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Trash2,
  Shield,
  User as UserIcon,
  Mail,
  Calendar,
  LogIn,
} from "lucide-react";

export default function UsersView() {
  const { user: currentUser, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams();
  const userId = params.id;

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // Check if user is admin
  if (!isAuthenticated || currentUser?.role !== "admin") {
    setLocation("/");
    return null;
  }

  // Fetch user data
  const { data: user, isLoading } = trpc.users.getById.useQuery(
    { id: userId! },
    { enabled: !!userId }
  );

  // Delete mutation
  const deleteMutation = trpc.users.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المستخدم بنجاح");
      setLocation("/admin/users");
    },
    onError: error => {
      toast.error(`فشل حذف المستخدم: ${error.message}`);
    },
  });

  const handleDelete = () => {
    if (userId) {
      if (userId === currentUser?.id) {
        toast.error("لا يمكنك حذف حسابك الخاص");
        return;
      }
      deleteMutation.mutate({ id: userId });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">المستخدم غير موجود</p>
          <Button className="mt-4" onClick={() => setLocation("/admin/users")}>
            العودة إلى قائمة المستخدمين
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/admin/users")}
              >
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة إلى المستخدمين
              </Button>
              <h1 className="text-2xl font-bold text-slate-800">
                تفاصيل المستخدم
              </h1>
            </div>
            <div className="flex gap-2">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
                disabled={(user as any).id === currentUser?.id}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info Card */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <UserIcon className="h-6 w-6 text-blue-600" />
                  </div>
                  {(user as any).name || "لا يوجد اسم"}
                </CardTitle>
                <Badge
                  variant={
                    (user as any).role === "admin" ? "default" : "secondary"
                  }
                >
                  {(user as any).role === "admin" ? (
                    <>
                      <Shield className="h-3 w-3 ml-1" />
                      مدير
                    </>
                  ) : (
                    <>
                      <UserIcon className="h-3 w-3 ml-1" />
                      مستخدم
                    </>
                  )}
                </Badge>
              </div>
              <CardDescription>
                تم الإنشاء في{" "}
                {(user as any).createdAt
                  ? new Date((user as any).createdAt).toLocaleDateString(
                      "ar-EG"
                    )
                  : "N/A"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* User ID */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    معرف المستخدم
                  </label>
                  <p className="mt-1 text-lg font-mono text-slate-800 break-all">
                    {(user as any).id}
                  </p>
                </div>

                {/* Name */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    الاسم
                  </label>
                  <p className="mt-1 text-lg font-semibold">
                    {(user as any).name || "لا يوجد اسم"}
                  </p>
                </div>

                {/* Email */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    البريد الإلكتروني
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <Mail className="h-4 w-4 text-slate-400" />
                    <p className="text-lg">
                      {(user as any).email || "لا يوجد بريد"}
                    </p>
                  </div>
                </div>

                {/* Login Method */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    طريقة تسجيل الدخول
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <LogIn className="h-4 w-4 text-slate-400" />
                    <p className="text-lg">
                      {(user as any).loginMethod || "N/A"}
                    </p>
                  </div>
                </div>

                {/* Role */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    الصلاحية
                  </label>
                  <div className="mt-1">
                    <Badge
                      variant={
                        (user as any).role === "admin" ? "default" : "secondary"
                      }
                      className="text-base px-3 py-1"
                    >
                      {(user as any).role === "admin" ? (
                        <>
                          <Shield className="h-4 w-4 ml-1" />
                          مدير
                        </>
                      ) : (
                        <>
                          <UserIcon className="h-4 w-4 ml-1" />
                          مستخدم
                        </>
                      )}
                    </Badge>
                  </div>
                </div>

                {/* Created At */}
                <div>
                  <label className="text-sm font-medium text-slate-500">
                    تاريخ الإنشاء
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <Calendar className="h-4 w-4 text-slate-400" />
                    <p className="text-lg">
                      {(user as any).createdAt
                        ? new Date((user as any).createdAt).toLocaleString(
                            "ar-EG",
                            {
                              dateStyle: "full",
                              timeStyle: "short",
                            }
                          )
                        : "N/A"}
                    </p>
                  </div>
                </div>

                {/* Last Signed In */}
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-slate-500">
                    آخر تسجيل دخول
                  </label>
                  <div className="flex items-center gap-2 mt-1">
                    <LogIn className="h-4 w-4 text-slate-400" />
                    <p className="text-lg">
                      {(user as any).lastSignedIn
                        ? new Date((user as any).lastSignedIn).toLocaleString(
                            "ar-EG",
                            {
                              dateStyle: "full",
                              timeStyle: "short",
                            }
                          )
                        : "لم يسجل دخول بعد"}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status Card */}
          <Card>
            <CardHeader>
              <CardTitle>حالة الحساب</CardTitle>
              <CardDescription>معلومات الحالة الحالية</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center py-6">
                  <div
                    className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${(user as any).role === "admin" ? "bg-gradient-to-br from-blue-500 to-indigo-600" : "bg-gradient-to-br from-slate-400 to-slate-500"} text-white mb-4`}
                  >
                    {(user as any).role === "admin" ? (
                      <Shield className="h-12 w-12" />
                    ) : (
                      <UserIcon className="h-12 w-12" />
                    )}
                  </div>
                  <p className="text-lg font-semibold">
                    {(user as any).role === "admin"
                      ? "مدير النظام"
                      : "مستخدم عادي"}
                  </p>
                  <p className="text-sm text-slate-600 mt-2">
                    {(user as any).role === "admin"
                      ? "لديه صلاحيات كاملة على النظام"
                      : "لديه صلاحيات محدودة"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mt-8 flex gap-4">
          <Button
            variant="destructive"
            onClick={() => setDeleteDialogOpen(true)}
            disabled={(user as any).id === currentUser?.id}
          >
            <Trash2 className="h-4 w-4 ml-2" />
            حذف المستخدم
          </Button>
          <Button variant="outline" onClick={() => setLocation("/admin/users")}>
            العودة إلى القائمة
          </Button>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد حذف المستخدم</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف المستخدم "
              {(user as any).name || (user as any).id}"؟ سيتم حذف جميع البيانات
              المرتبطة به. لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "جاري الحذف..." : "حذف نهائياً"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
