import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Save, RotateCcw } from "lucide-react";

export default function AssetsCreate() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  const [formData, setFormData] = useState({
    name: "",
    symbol: "",
    type: "commodity" as "commodity" | "crypto" | "currency" | "stock",
    yahooSymbol: "",
    description: "",
  });

  const createAssetMutation = trpc.assets.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء الأصل بنجاح");
      setLocation("/assets");
    },
    onError: (error) => {
      toast.error(`فشل إنشاء الأصل: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.symbol || !formData.yahooSymbol) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    createAssetMutation.mutate(formData);
  };

  const handleReset = () => {
    setFormData({
      name: "",
      symbol: "",
      type: "commodity",
      yahooSymbol: "",
      description: "",
    });
  };

  const handleSaveAndAddAnother = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.symbol || !formData.yahooSymbol) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    createAssetMutation.mutate(formData, {
      onSuccess: () => {
        toast.success("تم إنشاء الأصل بنجاح");
        handleReset();
      },
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/assets")}
              >
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة إلى القائمة
              </Button>
              <h1 className="text-2xl font-bold text-slate-800">إضافة أصل جديد</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>معلومات الأصل</CardTitle>
            <CardDescription>أدخل تفاصيل الأصل الجديد</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name">الاسم *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="مثال: الذهب"
                  required
                />
              </div>

              {/* Symbol */}
              <div className="space-y-2">
                <Label htmlFor="symbol">الرمز *</Label>
                <Input
                  id="symbol"
                  value={formData.symbol}
                  onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                  placeholder="مثال: GOLD"
                  required
                />
              </div>

              {/* Type */}
              <div className="space-y-2">
                <Label htmlFor="type">النوع *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value: any) => setFormData({ ...formData, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="commodity">سلعة</SelectItem>
                    <SelectItem value="crypto">عملة رقمية</SelectItem>
                    <SelectItem value="currency">عملة</SelectItem>
                    <SelectItem value="stock">سهم</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Yahoo Symbol */}
              <div className="space-y-2">
                <Label htmlFor="yahooSymbol">رمز Yahoo Finance *</Label>
                <Input
                  id="yahooSymbol"
                  value={formData.yahooSymbol}
                  onChange={(e) => setFormData({ ...formData, yahooSymbol: e.target.value })}
                  placeholder="مثال: GC=F"
                  required
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">الوصف</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="وصف الأصل..."
                  rows={4}
                />
              </div>

              {/* Buttons */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={createAssetMutation.isPending}
                >
                  <Save className="h-4 w-4 ml-2" />
                  {createAssetMutation.isPending ? "جاري الحفظ..." : "حفظ"}
                </Button>
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleSaveAndAddAnother}
                  disabled={createAssetMutation.isPending}
                >
                  <Save className="h-4 w-4 ml-2" />
                  حفظ وإضافة آخر
                </Button>
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-4 w-4 ml-2" />
                  إعادة تعيين
                </Button>
                
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setLocation("/assets")}
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

