/**
 * Predict Page - Premium Gold Price Predictor
 * Generate predictions for assets with advanced model selection
 */

import { useState } from "react";
import { useParams, useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import {
  Brain,
  TrendingUp,
  TrendingDown,
  ArrowLeft,
  Loader2,
  Target,
  Zap,
  Activity,
  Sparkles,
  BarChart3,
} from "lucide-react";
import { toast } from "sonner";
import { PageLayout } from "@/components/PageLayout";
import { FadeIn, SlideUp } from "@/components/animations";
import { LoadingSpinner } from "@/components/LoadingSpinner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function Predict() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const assetId = parseInt(id || "0");

  const [horizon, setHorizon] = useState<"short" | "medium" | "long">("short");
  const [modelType, setModelType] = useState<
    "transformer" | "lstm" | "gru" | "ensemble"
  >("ensemble");
  const [confidenceLevel, setConfidenceLevel] = useState(0.95);
  const [predictionResult, setPredictionResult] = useState<any>(null);

  const { data: asset, isLoading: assetLoading } = trpc.assets.getById.useQuery({
    id: assetId,
  });
  const generateMutation = trpc.predictions.generate.useMutation({
    onSuccess: (data) => {
      toast.success("تم توليد التوقع بنجاح!");
      setPredictionResult(data);
    },
    onError: (error) => {
      toast.error(`فشل توليد التوقع: ${error.message}`);
    },
  });

  const handleGenerate = () => {
    if (!asset) {return;}
    generateMutation.mutate({
      assetSymbol: (asset as any).symbol || "XAUUSD",
      assetName: (asset as any).name || "Gold",
      horizon,
      modelType,
    });
  };

  if (assetLoading) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center" dir="rtl">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!asset) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center" dir="rtl">
        <Card className="premium-card max-w-md">
          <CardContent className="py-16 text-center">
            <h1 className="text-3xl font-bold mb-4">الأصل غير موجود</h1>
            <Button onClick={() => navigate("/")}>العودة للرئيسية</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const expectedAccuracy =
    horizon === "short" ? 99 : horizon === "medium" ? 95 : 85;

  const breadcrumbs = [
    { label: "الرئيسية", href: "/" },
    { label: "التوقعات", href: "/predictions" },
    { label: `توقع ${(asset as any).name}` },
  ];

  return (
    <PageLayout
      title={
        <div className="flex items-center gap-2">
          <Brain className="h-6 w-6 text-primary" />
          توقع سعر {(asset as any).name}
        </div>
      }
      description="اختر النموذج والإطار الزمني لتوليد توقع دقيق"
      breadcrumbs={breadcrumbs}
      actions={
        <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
      }
    >
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Asset Info */}
            <SlideUp>
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-primary" />
                    معلومات الأصل
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">الاسم</p>
                      <p className="text-lg font-semibold">
                        {(asset as any).name}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">الرمز</p>
                      <p className="text-lg font-semibold">
                        {(asset as any).symbol}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">الفئة</p>
                      <p className="text-lg font-semibold">
                        {(asset as any).category === "commodity"
                          ? "سلعة"
                          : (asset as any).category === "crypto"
                          ? "عملة رقمية"
                          : (asset as any).category === "currency"
                          ? "عملة"
                          : "سهم"}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">
                        السعر الحالي
                      </p>
                      <p className="text-lg font-semibold text-primary">--</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </SlideUp>

            {/* Horizon Selection */}
            <SlideUp delay={0.1}>
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-primary" />
                    الإطار الزمني
                  </CardTitle>
                  <CardDescription>اختر المدة الزمنية للتوقع</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    data-testid="prediction-horizon"
                    value={horizon}
                    onValueChange={(v) => setHorizon(v as any)}
                  >
                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                      <RadioGroupItem value="short" id="short" />
                      <Label htmlFor="short" className="flex-1 cursor-pointer">
                        <div className="font-semibold">قصير المدى (1-7 أيام)</div>
                        <div className="text-sm text-muted-foreground">
                          دقة عالية جداً (99%+)
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="flex-1 cursor-pointer">
                        <div className="font-semibold">متوسط المدى (7-30 يوم)</div>
                        <div className="text-sm text-muted-foreground">
                          دقة جيدة (95%+)
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                      <RadioGroupItem value="long" id="long" />
                      <Label htmlFor="long" className="flex-1 cursor-pointer">
                        <div className="font-semibold">طويل المدى (30+ يوم)</div>
                        <div className="text-sm text-muted-foreground">
                          دقة متوسطة (85%+)
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            </SlideUp>

            {/* Model Selection */}
            <SlideUp delay={0.2}>
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-primary" />
                    نوع النموذج
                  </CardTitle>
                  <CardDescription>اختر النموذج المناسب لاحتياجاتك</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    data-testid="prediction-model-type"
                    value={modelType}
                    onValueChange={(v) => setModelType(v as any)}
                  >
                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                      <RadioGroupItem value="simple" id="simple" />
                      <Label htmlFor="simple" className="flex-1 cursor-pointer">
                        <div className="font-semibold">
                          Ridge Regression (بسيط)
                        </div>
                        <div className="text-sm text-muted-foreground">
                          سريع • دقة عالية • مناسب للمبتدئين
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                      <RadioGroupItem value="advanced" id="advanced" />
                      <Label htmlFor="advanced" className="flex-1 cursor-pointer">
                        <div className="font-semibold">LSTM (متقدم)</div>
                        <div className="text-sm text-muted-foreground">
                          بطيء • دقة عالية جداً • يلتقط الأنماط المعقدة
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center gap-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer bg-primary/5 border-primary/20 transition-colors">
                      <RadioGroupItem value="ensemble" id="ensemble" />
                      <Label htmlFor="ensemble" className="flex-1 cursor-pointer">
                        <div className="font-semibold flex items-center gap-2">
                          Ensemble (موصى به)
                          <Badge variant="default" className="text-xs">
                            الأفضل
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          متوسط السرعة • أعلى دقة • يدمج عدة نماذج
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            </SlideUp>

            {/* Confidence Level */}
            <SlideUp delay={0.3}>
              <Card className="premium-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    مستوى الثقة
                  </CardTitle>
                  <CardDescription>نطاق الثقة للتوقع</CardDescription>
                </CardHeader>
                <CardContent>
                  <Select
                    value={confidenceLevel.toString()}
                    onValueChange={(v) => setConfidenceLevel(parseFloat(v))}
                  >
                    <SelectTrigger data-testid="confidence-level-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.80">80%</SelectItem>
                      <SelectItem value="0.90">90%</SelectItem>
                      <SelectItem value="0.95">95% (موصى به)</SelectItem>
                      <SelectItem value="0.99">99%</SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </SlideUp>
          </div>

          {/* Summary Panel */}
          <div className="lg:col-span-1">
            <SlideUp delay={0.4}>
              <Card className="premium-card sticky top-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    ملخص التوقع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">الأصل</p>
                    <p className="font-semibold">{(asset as any).name}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">
                      الإطار الزمني
                    </p>
                    <p className="font-semibold">
                      {horizon === "short"
                        ? "قصير المدى (1-7 أيام)"
                        : horizon === "medium"
                        ? "متوسط المدى (7-30 يوم)"
                        : "طويل المدى (30+ يوم)"}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">النموذج</p>
                    <p className="font-semibold">
                      {modelType === "transformer"
                        ? "Transformer"
                        : modelType === "lstm"
                        ? "LSTM"
                        : modelType === "gru"
                        ? "GRU"
                        : "Ensemble"}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">
                      مستوى الثقة
                    </p>
                    <p className="font-semibold">
                      {(confidenceLevel * 100).toFixed(0)}%
                    </p>
                  </div>

                  <Separator />

                  <div className="p-3 rounded-lg bg-primary/5">
                    <p className="text-sm text-muted-foreground mb-2">
                      الدقة المتوقعة
                    </p>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-emerald-500" />
                      <span className="text-2xl font-bold text-emerald-500">
                        {expectedAccuracy}%+
                      </span>
                    </div>
                    <Progress value={expectedAccuracy} className="mt-2" />
                  </div>

                  <Button
                    data-testid="generate-prediction-button"
                    className="w-full"
                    size="lg"
                    onClick={handleGenerate}
                    disabled={generateMutation.isPending}
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري التوليد...
                      </>
                    ) : (
                      <>
                        <Brain className="ml-2 h-4 w-4" />
                        توليد التوقع
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    قد يستغرق التوليد من 5-30 ثانية حسب النموذج المختار
                  </p>
                </CardContent>
              </Card>
            </SlideUp>
          </div>
        </div>

        {/* Prediction Results */}
        {predictionResult && (
          <FadeIn delay={0.5} className="mt-6">
            <Card className="premium-card border-2 border-primary">
              <CardHeader className="bg-primary/5">
                <CardTitle className="flex items-center gap-2 text-primary">
                  <TrendingUp className="h-6 w-6" />
                  نتائج التوقع
                </CardTitle>
                <CardDescription>تم توليد التوقع بنجاح</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">
                      السعر الحالي
                    </p>
                    <p className="text-3xl font-bold">
                      ${parseFloat(predictionResult.currentPrice).toFixed(2)}
                    </p>
                  </div>

                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">
                      السعر المتوقع
                    </p>
                    <p className="text-3xl font-bold text-primary">
                      ${parseFloat(predictionResult.predictedPrice).toFixed(2)}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      بعد {predictionResult.daysAhead} يوم
                    </p>
                  </div>

                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">
                      التغير المتوقع
                    </p>
                    <p
                      className={`text-3xl font-bold ${
                        parseFloat(predictionResult.predictedPrice) >
                        parseFloat(predictionResult.currentPrice)
                          ? "text-emerald-500"
                          : "text-red-500"
                      }`}
                    >
                      {(
                        ((parseFloat(predictionResult.predictedPrice) -
                          parseFloat(predictionResult.currentPrice)) /
                          parseFloat(predictionResult.currentPrice)) *
                        100
                      ).toFixed(2)}
                      %
                    </p>
                  </div>
                </div>

                <div className="bg-muted/50 p-4 rounded-lg mb-6">
                  <h3 className="font-semibold mb-3">
                    فاصل الثقة ({(confidenceLevel * 100).toFixed(0)}%)
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">الحد الأدنى</p>
                      <p className="text-xl font-bold text-amber-600">
                        ${parseFloat(predictionResult.confidenceLower).toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">الحد الأعلى</p>
                      <p className="text-xl font-bold text-emerald-600">
                        ${parseFloat(predictionResult.confidenceUpper).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    نحن واثقون بنسبة {(confidenceLevel * 100).toFixed(0)}% أن
                    السعر الفعلي سيكون بين هذين الحدين
                  </p>
                </div>

                <div className="bg-primary/5 p-4 rounded-lg mb-6">
                  <h3 className="font-semibold mb-2">معلومات النموذج</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">النموذج المستخدم</p>
                      <p className="font-semibold">
                        {predictionResult.modelType}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">الدقة المتوقعة</p>
                      <p className="font-semibold">
                        {(
                          parseFloat(predictionResult.accuracy || "0.95") * 100
                        ).toFixed(1)}
                        %
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">تاريخ التوقع</p>
                      <p className="font-semibold">
                        {new Date(
                          predictionResult.predictionDate
                        ).toLocaleDateString("ar-EG")}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">التاريخ المستهدف</p>
                      <p className="font-semibold">
                        {new Date(predictionResult.targetDate).toLocaleDateString(
                          "ar-EG"
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    className="flex-1"
                    onClick={() => navigate("/history")}
                  >
                    عرض جميع التوقعات
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setPredictionResult(null);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  >
                    توقع جديد
                  </Button>
                </div>
              </CardContent>
            </Card>
          </FadeIn>
        )}
      </div>
    </PageLayout>
  );
}
