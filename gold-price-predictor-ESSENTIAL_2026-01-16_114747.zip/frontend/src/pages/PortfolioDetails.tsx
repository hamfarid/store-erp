/**
 * Portfolio Details Page - Premium Gold Price Predictor
 * Detailed portfolio view with transactions and performance charts
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  Plus,
  TrendingDown,
  TrendingUp,
  Wallet,
  DollarSign,
  Target,
  BarChart3,
} from "lucide-react";
import { useState } from "react";
import {
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Link, useParams } from "wouter";
import { toast } from "sonner";

// Animation variants
const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const COLORS = [
  "oklch(0.65 0.18 70)", // Gold
  "oklch(0.72 0.19 145)", // Emerald
  "oklch(0.75 0.15 50)", // Amber
  "oklch(0.65 0.2 25)", // Red
  "oklch(0.7 0.2 280)", // Purple
  "oklch(0.7 0.2 330)", // Pink
];

export default function PortfolioDetails() {
  const { id } = useParams();
  const portfolioId = parseInt(id || "0");
  const { user, loading: authLoading } = useAuth();
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);

  const { data: portfolio, isLoading: portfolioLoading } =
    trpc.portfolio.get.useQuery(
      { portfolioId },
      { enabled: !!user && portfolioId > 0 }
    );

  const { data: summary } = trpc.portfolio.getSummary.useQuery(
    { portfolioId },
    { enabled: portfolioId > 0 }
  );

  const { data: breakdown } = trpc.portfolio.getBreakdown.useQuery(
    { portfolioId },
    { enabled: portfolioId > 0 }
  );

  const { data: performance } = trpc.portfolio.getPerformance.useQuery(
    {
      portfolioId,
      startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
      endDate: new Date(),
    },
    { enabled: portfolioId > 0 }
  );

  const { data: transactions, refetch: refetchTransactions } =
    trpc.portfolio.getTransactions.useQuery(
      { portfolioId },
      { enabled: portfolioId > 0 }
    );

  if (authLoading || portfolioLoading) {
    return (
      <div className="min-h-screen bg-gradient-hero" dir="rtl">
        <div className="container py-8">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="grid gap-6">
            <Skeleton className="h-64" />
            <Skeleton className="h-96" />
          </div>
        </div>
      </div>
    );
  }

  if (!user || !portfolio) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center" dir="rtl">
        <Card className="premium-card max-w-md">
          <CardContent className="py-16 text-center">
            <h1 className="text-3xl font-bold mb-4">المحفظة غير موجودة</h1>
            <Button asChild>
              <Link href="/portfolio">العودة للمحافظ</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const profitLossPercent = summary?.totalInvested
    ? (summary.profitLoss / summary.totalInvested) * 100
    : 0;
  const isProfit = (summary?.profitLoss || 0) >= 0;

  // Prepare pie chart data
  const pieData =
    (breakdown as any)?.map((item: any, index: any) => ({
      name: (item as any).assetSymbol,
      value: (item as any).currentValue,
      color: COLORS[index % COLORS.length],
    })) || [];

  // Prepare line chart data
  const lineData =
    (performance as any)?.map((snapshot: any) => ({
      date: new Date((snapshot as any).date).toLocaleDateString("ar-EG", {
        month: "short",
        day: "numeric",
      }),
      value: (snapshot as any).totalValue,
      invested: (snapshot as any).totalInvested,
    })) || [];

  return (
    <div className="min-h-screen bg-gradient-hero" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/portfolio">
                  <ArrowLeft className="h-5 w-5" />
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Wallet className="h-6 w-6 text-primary" />
                  {portfolio.name}
                </h1>
                {portfolio.description && (
                  <p className="text-sm text-muted-foreground">
                    {portfolio.description}
                  </p>
                )}
              </div>
            </div>
            <Button data-testid="add-transaction-button" onClick={() => setIsAddTransactionOpen(true)} size="sm">
              <Plus className="ml-2 h-4 w-4" />
              إضافة معاملة
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">

        {/* Summary Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0 }}
          >
            <Card className="stat-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10 text-primary">
                      <DollarSign className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">القيمة الحالية</p>
                      <p className="text-lg font-bold">
                        ${(summary as any)?.currentValue?.toFixed(2) || "0.00"}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.1 }}
          >
            <Card className="stat-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10 text-primary">
                      <Target className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">المبلغ المستثمر</p>
                      <p className="text-lg font-bold">
                        ${summary?.totalInvested.toFixed(2) || "0.00"}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
          >
            <Card className="stat-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        isProfit
                          ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600"
                          : "bg-red-100 dark:bg-red-900/30 text-red-600"
                      }`}
                    >
                      {isProfit ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">الربح/الخسارة</p>
                      <p
                        className={`text-lg font-bold ${
                          isProfit ? "text-emerald-500" : "text-red-500"
                        }`}
                      >
                        ${Math.abs(summary?.profitLoss || 0).toFixed(2)}
                      </p>
                      <p
                        className={`text-xs ${
                          isProfit ? "text-emerald-500" : "text-red-500"
                        }`}
                      >
                        {profitLossPercent.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.3 }}
          >
            <Card className="stat-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        isProfit
                          ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600"
                          : "bg-red-100 dark:bg-red-900/30 text-red-600"
                      }`}
                    >
                      <BarChart3 className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">العائد على الاستثمار</p>
                      <p
                        className={`text-lg font-bold ${
                          isProfit ? "text-emerald-500" : "text-red-500"
                        }`}
                      >
                        {(summary as any)?.roi?.toFixed(2) || "0.00"}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts */}
        <div className="grid gap-6 md:grid-cols-2 mb-8">
          {/* Pie Chart - Asset Distribution */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.4 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  توزيع الأصول
                </CardTitle>
                <CardDescription>توزيع المحفظة حسب الأصل</CardDescription>
              </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry: any) =>
                      `${(entry as any).name}: ${(((entry as any).value / (summary as any)!.currentValue) * 100).toFixed(1)}%`
                    }
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry: any, index: any) => (
                      <Cell key={`cell-${index}`} fill={(entry as any).color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => `$${value.toFixed(2)}`}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                لا توجد بيانات
              </div>
            )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Line Chart - Performance */}
          <motion.div
            variants={cardVariants}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.5 }}
          >
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  الأداء التاريخي
                </CardTitle>
                <CardDescription>آخر 30 يوم</CardDescription>
              </CardHeader>
          <CardContent>
            {lineData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={lineData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip
                    formatter={(value: number) => `$${value.toFixed(2)}`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#3b82f6"
                    name="القيمة الحالية"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="invested"
                    stroke="#10b981"
                    name="المبلغ المستثمر"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                لا توجد بيانات تاريخية
              </div>
            )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Transactions Table */}
        <motion.div
          variants={cardVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.6 }}
        >
          <Card className="premium-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5 text-primary" />
                المعاملات
              </CardTitle>
              <CardDescription>سجل جميع عمليات الشراء والبيع</CardDescription>
            </CardHeader>
        <CardContent>
          {transactions && transactions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>الأصل</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الكمية</TableHead>
                  <TableHead>السعر</TableHead>
                  <TableHead>الرسوم</TableHead>
                  <TableHead>الإجمالي</TableHead>
                  <TableHead>الملاحظات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((tx: any) => (
                  <TableRow key={(tx as any).id}>
                    <TableCell>
                      {new Date((tx as any).date).toLocaleDateString("ar-EG")}
                    </TableCell>
                    <TableCell>{(tx as any).assetId}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          tx.transactionType === "buy" ? "default" : "destructive"
                        }
                      >
                        {tx.transactionType === "buy" ? "شراء" : "بيع"}
                      </Badge>
                    </TableCell>
                    <TableCell>{tx.quantity}</TableCell>
                    <TableCell>${tx.pricePerUnit.toFixed(2)}</TableCell>
                    <TableCell>${tx.fees?.toFixed(2) || "0.00"}</TableCell>
                    <TableCell className="font-semibold">
                      ${tx.totalAmount.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {tx.notes || "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="py-16 text-center text-muted-foreground">
              <p>لا توجد معاملات</p>
              <Button
                className="mt-4"
                onClick={() => setIsAddTransactionOpen(true)}
              >
                إضافة معاملة أولى
              </Button>
            </div>
          )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Add Transaction Dialog */}
        <AddTransactionDialog
          portfolioId={portfolioId}
          open={isAddTransactionOpen}
          onOpenChange={setIsAddTransactionOpen}
          onSuccess={refetchTransactions}
        />
      </main>
    </div>
  );
}

function AddTransactionDialog({
  portfolioId,
  open,
  onOpenChange,
  onSuccess,
}: {
  portfolioId: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}) {
  const [assetId, setAssetId] = useState("");
  const [type, setType] = useState<"buy" | "sell">("buy");
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [fees, setFees] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [notes, setNotes] = useState("");

  const { data: assets } = trpc.assets.list.useQuery();

  const addMutation = trpc.portfolio.addTransaction.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة المعاملة بنجاح");
      onSuccess();
      onOpenChange(false);
      // Reset form
      setAssetId("");
      setType("buy");
      setQuantity("");
      setPrice("");
      setFees("");
      setDate(new Date().toISOString().split("T")[0]);
      setNotes("");
    },
    onError: (error) => {
      toast.error(`فشل إضافة المعاملة: ${error.message}`);
    },
  });

  const handleSubmit = () => {
    if (!assetId || !quantity || !price) {return;}

    const qty = parseFloat(quantity);
    const pricePerUnit = parseFloat(price);
    const feeAmount = fees ? parseFloat(fees) : 0;
    const total =
      type === "buy"
        ? qty * pricePerUnit + feeAmount
        : qty * pricePerUnit - feeAmount;

    addMutation.mutate({
      portfolioId,
      assetId: parseInt(assetId),
      transactionType: type,
      quantity: quantity, // Keep as string for decimal precision
      pricePerUnit: price, // Keep as string for decimal precision
      totalAmount: total.toString(), // Convert to string for decimal precision
      fees: fees || undefined,
      transactionDate: new Date(date),
      notes: notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-primary" />
            إضافة معاملة جديدة
          </DialogTitle>
          <DialogDescription>أضف عملية شراء أو بيع للمحفظة</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="asset">الأصل *</Label>
              <Select value={assetId} onValueChange={setAssetId}>
                <SelectTrigger data-testid="transaction-asset-select">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  {assets?.map(asset => (
                    <SelectItem
                      key={(asset as any).id}
                      value={(asset as any).id.toString()}
                    >
                      {(asset as any).name} ({(asset as any).symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">نوع المعاملة *</Label>
              <Select
                value={type}
                onValueChange={v => setType(v as "buy" | "sell")}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="buy">شراء</SelectItem>
                  <SelectItem value="sell">بيع</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">الكمية *</Label>
              <Input
                id="quantity"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">السعر لكل وحدة *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={price}
                onChange={e => setPrice(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fees">الرسوم (اختياري)</Label>
              <Input
                id="fees"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={fees}
                onChange={e => setFees(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">التاريخ *</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">الملاحظات (اختياري)</Label>
            <Input
              id="notes"
              placeholder="ملاحظات..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
          </div>

          {quantity && price && (
            <div className="bg-muted p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">الإجمالي:</span>
                <span className="text-lg font-bold">
                  $
                  {(
                    (type === "buy" ? 1 : -1) *
                    (parseFloat(quantity) * parseFloat(price) +
                      (fees ? parseFloat(fees) : 0))
                  ).toFixed(2)}
                </span>
              </div>
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={addMutation.isPending || !assetId || !quantity || !price}
          >
            {addMutation.isPending ? "جاري الإضافة..." : "إضافة"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
