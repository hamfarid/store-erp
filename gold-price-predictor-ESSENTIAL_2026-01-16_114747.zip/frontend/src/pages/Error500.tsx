/**
 * 500 Internal Server Error Page
 */

import ErrorPageTemplate from "@/components/ErrorPageTemplate";
import { ServerCrash } from "lucide-react";

export default function Error500() {
  return (
    <ErrorPageTemplate
      code={500}
      title="خطأ في الخادم"
      description="عذراً، حدث خطأ داخلي في الخادم. فريقنا يعمل على حل المشكلة. يرجى المحاولة مرة أخرى لاحقاً."
      icon={ServerCrash}
      iconColor="text-red-500"
      showRefresh={true}
      showHome={true}
      showDashboard={false}
    />
  );
}
