// File: /home/ubuntu/asset_predictor_ui/client/src/store/slices/predictionSlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import apiClient, { PredictionRequest, PredictionResponse } from '../../api/client';

interface PredictionState {
  predictions: PredictionResponse[];
  currentPrediction: PredictionResponse | null;
  history: PredictionResponse[];
  loading: boolean;
  error: string | null;
}

const initialState: PredictionState = {
  predictions: [],
  currentPrediction: null,
  history: [],
  loading: false,
  error: null,
};

// Async thunks
export const getPrediction = createAsyncThunk(
  'prediction/getPrediction',
  async (request: PredictionRequest, { rejectWithValue }) => {
    try {
      const response = await apiClient.getPrediction(request);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Prediction failed');
    }
  }
);

// Legacy support - kept for backward compatibility
export const fetchPrediction = createAsyncThunk(
  'prediction/fetch',
  async ({ symbol, horizon }: { symbol: string; horizon: 'short' | 'medium' | 'long' }, { rejectWithValue }) => {
    try {
      const response = await apiClient.getPrediction({
        symbol,
        horizon,
        include_sentiment: true,
        include_economic_data: true
      });
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Prediction failed');
    }
  }
);

export const getPredictionHistory = createAsyncThunk(
  'prediction/getHistory',
  async ({ limit = 50, offset = 0 }: { limit?: number; offset?: number }, { rejectWithValue }) => {
    try {
      const response = await apiClient.getPredictionHistory(limit, offset);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch history');
    }
  }
);

const predictionSlice = createSlice({
  name: 'prediction',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    clearPredictions: (state) => {
      state.predictions = [];
    },
    clearCurrentPrediction: (state) => {
      state.currentPrediction = null;
    },
    addPrediction: (state, action: PayloadAction<PredictionResponse>) => {
      state.predictions.unshift(action.payload);
      // Keep only last 100 predictions
      if (state.predictions.length > 100) {
        state.predictions = state.predictions.slice(0, 100);
      }
    },
  },
  extraReducers: (builder) => {
    builder
      // Get Prediction
      .addCase(getPrediction.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getPrediction.fulfilled, (state, action) => {
        state.loading = false;
        state.currentPrediction = action.payload;
        state.predictions.unshift(action.payload);
        // Keep only last 100 predictions
        if (state.predictions.length > 100) {
          state.predictions = state.predictions.slice(0, 100);
        }
      })
      .addCase(getPrediction.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Legacy fetchPrediction support
      .addCase(fetchPrediction.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPrediction.fulfilled, (state, action) => {
        state.loading = false;
        state.currentPrediction = action.payload;
        state.predictions.unshift(action.payload);
        if (state.predictions.length > 100) {
          state.predictions = state.predictions.slice(0, 100);
        }
      })
      .addCase(fetchPrediction.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Get History
      .addCase(getPredictionHistory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getPredictionHistory.fulfilled, (state, action) => {
        state.loading = false;
        state.history = action.payload;
      })
      .addCase(getPredictionHistory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearError, clearPredictions, clearCurrentPrediction, addPrediction } = predictionSlice.actions;
export default predictionSlice.reducer;

