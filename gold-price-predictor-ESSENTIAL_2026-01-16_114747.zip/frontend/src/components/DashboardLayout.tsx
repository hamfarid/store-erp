/**
 * Dashboard Layout Component
 * Modern layout with premium sidebar navigation
 */

import { useAuth } from "@/_core/hooks/useAuth";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { APP_TITLE, getLoginUrl } from "@/const";
// import { APP_LOGO } from "@/const"; // Unused
import { CSSProperties, useState } from "react";
import { useLocation, Link } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { Button } from "./ui/button";
import { AppSidebar } from "./AppSidebar";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "./ui/breadcrumb";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Bell, Settings, User, LogOut, Search, Sparkles } from "lucide-react";
// Unused: Moon, Sun
import { Input } from "./ui/input";
import { motion, AnimatePresence } from "framer-motion";

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;

// Route to title mapping
const routeTitles: Record<string, string> = {
  "/": "الرئيسية",
  "/dashboard": "لوحة التحكم",
  "/comprehensive": "الإدارة الشاملة",
  "/assets": "الأصول",
  "/predictions": "التوقعات",
  "/portfolio": "المحفظة",
  "/alerts": "التنبيهات",
  "/trading-signals": "إشارات التداول",
  "/technical-analysis": "التحليل الفني",
  "/analytics": "تحليلات الأسعار",
  "/fear-greed": "مؤشر الخوف والطمع",
  "/news-sentiment": "تحليل الأخبار",
  "/expert-opinions": "آراء الخبراء",
  "/ml-models": "نماذج ML",
  "/ai-tasks": "مهام الذكاء الاصطناعي",
  "/learning": "التعلم",
  "/system-health": "صحة النظام",
  "/reports": "التقارير",
  "/notifications": "الإشعارات",
  "/settings": "الإعدادات",
  "/profile": "الملف الشخصي",
  "/admin": "لوحة المدير",
  "/admin/users": "المستخدمون",
  "/admin/assets": "الأصول",
  "/admin/train-models": "تدريب النماذج",
  "/admin/backup": "النسخ الاحتياطي",
  "/admin/logs": "السجلات",
  "/security": "الأمان",
};

function getPageTitle(path: string): string {
  // Check exact match first
  if (routeTitles[path]) {
    return routeTitles[path];
  }

  // Check partial match for dynamic routes
  for (const [route, title] of Object.entries(routeTitles)) {
    if (path.startsWith(route) && route !== "/") {
      return title;
    }
  }

  return "الصفحة";
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  // const [sidebarWidth, setSidebarWidth] = useState(...); // setSidebarWidth unused
  const { loading, user, logout } = useAuth();
  const [location] = useLocation();
  // const isMobile = useIsMobile(); // Unused
  const pageTitle = getPageTitle(location);

  if (loading) {
    return <DashboardLayoutSkeleton />;
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center gap-8 p-8 max-w-md w-full"
        >
          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <div className="p-4 rounded-2xl bg-primary/10 glow-gold">
                <Sparkles className="h-12 w-12 text-primary" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h1 className="text-2xl font-bold tracking-tight">{APP_TITLE}</h1>
              <p className="text-sm text-muted-foreground">
                يرجى تسجيل الدخول للمتابعة
              </p>
            </div>
          </div>
          <Button
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
            size="lg"
            className="w-full glow-gold"
          >
            تسجيل الدخول
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <SidebarProvider
      style={{
        "--sidebar-width": `${sidebarWidth}px`,
      } as CSSProperties}
    >
      <AppSidebar />
      <SidebarInset>
        {/* Top Header Bar */}
        <header className="sticky top-0 z-40 flex h-14 shrink-0 items-center gap-2 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b px-4">
          <SidebarTrigger className="-mr-1" />
          <Separator orientation="vertical" className="mr-2 h-4" />

          {/* Breadcrumb */}
          <Breadcrumb className="hidden md:flex">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link href="/">الرئيسية</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              {location !== "/" && (
                <>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbPage>{pageTitle}</BreadcrumbPage>
                  </BreadcrumbItem>
                </>
              )}
            </BreadcrumbList>
          </Breadcrumb>

          {/* Mobile Title */}
          <span className="md:hidden font-semibold">{pageTitle}</span>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Search */}
          <div className="hidden md:flex relative max-w-sm">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث..."
              className="pr-9 w-64 bg-muted/50"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              <Badge className="absolute -top-1 -left-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                3
              </Badge>
            </Button>

            {/* Settings */}
            <Button variant="ghost" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
              </Link>
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="" alt={user?.name || "User"} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {user?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center gap-2 p-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {user?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
                <Separator className="my-1" />
                <DropdownMenuItem asChild>
                  <Link href="/profile">
                    <User className="ml-2 h-4 w-4" />
                    الملف الشخصي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">
                    <Settings className="ml-2 h-4 w-4" />
                    الإعدادات
                  </Link>
                </DropdownMenuItem>
                <Separator className="my-1" />
                <DropdownMenuItem onClick={() => logout()} className="text-destructive">
                  <LogOut className="ml-2 h-4 w-4" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={location}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
