/**
 * Alert Card Component
 * Displays alert information in a card format
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Bell, BellOff, TrendingUp, TrendingDown } from "lucide-react";
import { format } from "date-fns";

interface AlertCardProps {
  alert: {
    id: number;
    assetName?: string;
    assetSymbol?: string;
    condition: "above" | "below";
    threshold: number;
    currentPrice?: number;
    isActive: boolean;
    isTriggered: boolean;
    createdAt: number;
    triggeredAt?: number;
  };
  onToggle?: (id: number, isActive: boolean) => void;
  onDelete?: (id: number) => void;
}

export function AlertCard({ alert, onToggle, onDelete }: AlertCardProps) {
  const isAboveThreshold = alert.condition === "above";
  const statusColor = alert.isTriggered
    ? "destructive"
    : alert.isActive
    ? "default"
    : "secondary";

  const statusText = alert.isTriggered
    ? "تم التنبيه"
    : alert.isActive
    ? "نشط"
    : "غير نشط";

  return (
    <Card className={alert.isTriggered ? "border-red-500" : ""}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center gap-2">
              {alert.assetName || alert.assetSymbol}
              {isAboveThreshold ? (
                <TrendingUp className="h-4 w-4 text-green-500" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500" />
              )}
            </CardTitle>
            <CardDescription className="mt-1">
              {isAboveThreshold ? "عند الارتفاع فوق" : "عند الانخفاض تحت"}{" "}
              <span className="font-semibold">${alert.threshold.toLocaleString()}</span>
            </CardDescription>
          </div>
          <Badge variant={statusColor}>{statusText}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {alert.currentPrice && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">السعر الحالي:</span>
              <span className="font-semibold">${alert.currentPrice.toLocaleString()}</span>
            </div>
          )}
          
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">تاريخ الإنشاء:</span>
            <span>{format(new Date(alert.createdAt), "yyyy-MM-dd HH:mm")}</span>
          </div>

          {alert.triggeredAt && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">تاريخ التنبيه:</span>
              <span className="text-red-600">
                {format(new Date(alert.triggeredAt), "yyyy-MM-dd HH:mm")}
              </span>
            </div>
          )}

          <div className="flex gap-2 mt-4">
            {onToggle && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onToggle(alert.id, !alert.isActive)}
                className="flex-1"
              >
                {alert.isActive ? (
                  <>
                    <BellOff className="h-4 w-4 mr-2" />
                    إيقاف
                  </>
                ) : (
                  <>
                    <Bell className="h-4 w-4 mr-2" />
                    تفعيل
                  </>
                )}
              </Button>
            )}
            {onDelete && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => onDelete(alert.id)}
              >
                حذف
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default AlertCard;

