/**
 * Real-time Price Ticker Component
 * Displays live asset prices with auto-refresh
 */

import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";
import { Card } from "@/components/ui/card";

interface PriceData {
  asset: string;
  assetAr: string;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
}

export function RealTimePriceTicker() {
  const [prices, setPrices] = useState<PriceData[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const { data, refetch } = trpc.dashboard.getLivePrices.useQuery(undefined, {
    refetchInterval: 30000, // Refresh every 30 seconds
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (data) {
      setPrices(data as PriceData[]);
      setLastUpdate(new Date());
    }
  }, [data]);

  // Manual refresh every minute
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 60000);

    return () => clearInterval(interval);
  }, [refetch]);

  if (!prices || prices.length === 0) {
    return null;
  }

  return (
    <div className="w-full overflow-hidden bg-background border-b">
      <div className="flex items-center gap-1 px-4 py-2">
        <Activity className="w-4 h-4 text-primary animate-pulse" />
        <span className="text-xs text-muted-foreground mr-4">
          Live: {lastUpdate.toLocaleTimeString()}
        </span>
        
        <div className="flex-1 overflow-hidden">
          <div className="flex gap-6 animate-scroll">
            {prices.concat(prices).map((price, idx) => {
              const isPositive = price.changePercent >= 0;
              return (
                <div key={`${price.symbol}-${idx}`} className="flex items-center gap-2 whitespace-nowrap">
                  <span className="font-medium text-sm">{price.asset}</span>
                  <span className="text-sm">${price.price.toLocaleString()}</span>
                  <span className={`flex items-center gap-1 text-xs ${isPositive ? "text-green-500" : "text-red-500"}`}>
                    {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {isPositive ? "+" : ""}{price.changePercent.toFixed(2)}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-scroll {
          animation: scroll 30s linear infinite;
        }

        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
}

/**
 * Real-time Price Card Component
 * Individual card for displaying asset price with updates
 */

interface RealTimePriceCardProps {
  symbol: string;
  name: string;
  nameAr?: string;
  refreshInterval?: number;
}

export function RealTimePriceCard({
  symbol,
  name,
  nameAr,
  refreshInterval = 30000,
}: RealTimePriceCardProps) {
  const [priceData, setPriceData] = useState<any>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  const { data, refetch } = trpc.dashboard.getLivePrices.useQuery(undefined, {
    refetchInterval: refreshInterval,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (data) {
      const assetData = (data as PriceData[]).find((p) => p.symbol === symbol);
      if (assetData) {
        setIsUpdating(true);
        setPriceData(assetData);
        setTimeout(() => setIsUpdating(false), 500);
      }
    }
  }, [data, symbol]);

  if (!priceData) {
    return (
      <Card className="p-4">
        <div className="animate-pulse space-y-2">
          <div className="h-4 bg-muted rounded w-1/2" />
          <div className="h-6 bg-muted rounded w-3/4" />
        </div>
      </Card>
    );
  }

  const isPositive = priceData.changePercent >= 0;

  return (
    <Card className={`p-4 transition-all ${isUpdating ? "ring-2 ring-primary" : ""}`}>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">{name}</h3>
          <Activity className={`w-4 h-4 ${isUpdating ? "text-primary animate-pulse" : "text-muted-foreground"}`} />
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold">${priceData.price.toLocaleString()}</span>
          <span className={`flex items-center gap-1 text-sm ${isPositive ? "text-green-500" : "text-red-500"}`}>
            {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {isPositive ? "+" : ""}{priceData.changePercent.toFixed(2)}%
          </span>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>24h: ${priceData.low24h.toFixed(2)} - ${priceData.high24h.toFixed(2)}</span>
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : ""}${priceData.change.toFixed(2)}
          </span>
        </div>
      </div>
    </Card>
  );
}

