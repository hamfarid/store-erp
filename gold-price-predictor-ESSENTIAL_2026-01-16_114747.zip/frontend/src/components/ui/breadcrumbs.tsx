/**
 * Breadcrumbs Component
 * Professional navigation breadcrumbs
 */

import { Link, useLocation } from "wouter";
import { ChevronLeft, Home } from "lucide-react";
import { cn } from "@/lib/utils";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  items?: BreadcrumbItem[];
  className?: string;
}

export function Breadcrumbs({ items, className }: BreadcrumbsProps) {
  const [location] = useLocation();

  // Auto-generate breadcrumbs from path if not provided
  const breadcrumbs = items || (() => {
    const paths = location.split("/").filter(Boolean);
    const result: BreadcrumbItem[] = [{ label: "الرئيسية", href: "/" }];
    
    let currentPath = "";
    paths.forEach((path, index) => {
      currentPath += `/${path}`;
      // Map common paths to Arabic labels
      const labelMap: Record<string, string> = {
        dashboard: "لوحة التحكم",
        admin: "لوحة المدير",
        users: "المستخدمون",
        assets: "الأصول",
        alerts: "التنبيهات",
        reports: "التقارير",
        portfolio: "المحفظة",
        settings: "الإعدادات",
        predictions: "التوقعات",
        analytics: "التحليلات",
      };
      
      result.push({
        label: labelMap[path] || path,
        href: index === paths.length - 1 ? undefined : currentPath,
      });
    });
    
    return result;
  })();

  return (
    <nav
      aria-label="Breadcrumb"
      className={cn("flex items-center gap-2 text-sm text-muted-foreground", className)}
      dir="rtl"
    >
      {breadcrumbs.map((item, index) => (
        <div key={index} className="flex items-center gap-2">
          {index === 0 ? (
            <Link href={item.href || "/"}>
              <Home className="h-4 w-4 hover:text-foreground transition-colors" />
            </Link>
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              {item.href ? (
                <Link
                  href={item.href}
                  className="hover:text-foreground transition-colors"
                >
                  {item.label}
                </Link>
              ) : (
                <span className="text-foreground font-medium">{item.label}</span>
              )}
            </>
          )}
        </div>
      ))}
    </nav>
  );
}

