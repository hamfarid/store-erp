/**
 * Animated Button Component
 * Button with smooth animations and loading states
 */

import { motion } from "framer-motion";
import { ReactNode } from "react";
import { Button, buttonVariants } from "./button";
import { cn } from "@/lib/utils";
import * as React from "react";
import { type VariantProps } from "class-variance-authority";

type ButtonProps = React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  };

interface AnimatedButtonProps extends ButtonProps {
  children: ReactNode;
  loading?: boolean;
  delay?: number;
  className?: string;
  disabled?: boolean;
}

export function AnimatedButton({
  children,
  loading,
  delay = 0,
  className,
  disabled,
  ...props
}: AnimatedButtonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.3 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        className={cn("transition-smooth", className)}
        disabled={loading || disabled}
        {...props}
      >
        {loading ? (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="mr-2"
          >
            ⏳
          </motion.div>
        ) : null}
        {children}
      </Button>
    </motion.div>
  );
}
