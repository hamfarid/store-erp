/**
 * Chat Input Component
 * Text input for sending messages to AI assistant
 */

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
  assistantType: 'free' | 'paid';
  remainingMessages?: number | null;
}

export function ChatInput({ onSend, disabled, assistantType, remainingMessages }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const maxLength = assistantType === 'free' ? 2000 : 5000;
  const showCounter = message.length > maxLength * 0.8;

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [message]);

  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSend(message.trim());
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Send on Enter (without Shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const isLimitReached = remainingMessages !== null && remainingMessages !== undefined && remainingMessages <= 0;

  return (
    <div className="border-t p-4 space-y-2">
      {/* Warning if limit reached */}
      {isLimitReached && (
        <div className="text-xs text-destructive bg-destructive/10 p-2 rounded">
          ⚠️ وصلت للحد الأقصى اليومي. جرب المساعد المتقدم للحصول على رسائل غير محدودة!
        </div>
      )}

      {/* Input area */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              isLimitReached 
                ? "وصلت للحد الأقصى اليومي..."
                : "اكتب رسالتك... (Enter للإرسال)"
            }
            disabled={disabled || isLimitReached}
            maxLength={maxLength}
            className="min-h-[60px] max-h-[120px] resize-none pr-16"
            dir="auto"
          />

          {/* Character counter */}
          {showCounter && (
            <div className={cn(
              "absolute bottom-2 left-2 text-xs",
              message.length >= maxLength ? "text-destructive" : "text-muted-foreground"
            )}>
              {message.length}/{maxLength}
            </div>
          )}
        </div>

        <Button
          onClick={handleSend}
          disabled={!message.trim() || disabled || isLimitReached}
          size="icon"
          className="h-[60px] w-[60px]"
        >
          {disabled ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <Send className="h-5 w-5" />
          )}
        </Button>
      </div>

      {/* Helper text */}
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {assistantType === 'free' ? '🤖 مساعد مجاني' : '💎 مساعد متقدم'}
        </span>
        {remainingMessages !== null && remainingMessages !== undefined && (
          <span>
            {remainingMessages} رسالة متبقية اليوم
          </span>
        )}
      </div>
    </div>
  );
}

