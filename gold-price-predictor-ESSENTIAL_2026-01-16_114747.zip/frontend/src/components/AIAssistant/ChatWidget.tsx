/**
 * Chat Widget Component
 * Floating AI assistant chat interface
 */

import { useState, useEffect } from "react";
// import { useRef } from "react"; // Unused
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Minimize2, Maximize2, Sparkles, MessageCircle } from "lucide-react";
import { ChatMessages } from "./ChatMessages";
import { ChatInput } from "./ChatInput";
import { Avatar } from "./Avatar";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  tokensUsed?: number;
  responseTime?: number;
}

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [assistantType, setAssistantType] = useState<'free' | 'paid'>('free');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const { isAuthenticated } = useAuth();
  // const { user } = useAuth(); // Unused

  // Get usage stats
  const { data: usage } = trpc.ai.getUsage.useQuery(
    { assistantType },
    { enabled: isAuthenticated && isOpen, refetchInterval: 60000 }
  );

  // Get assistant info
  // const { data: assistantInfo } = trpc.ai.getAssistantInfo.useQuery( // Unused
  //   { assistantType },
  //   { enabled: isOpen }
  // );

  // Chat mutations
  const chatFreeMutation = trpc.ai.chatFree.useMutation();
  const chatPaidMutation = trpc.ai.chatPaid.useMutation();

  // Handle send message
  const handleSend = async (message: string) => {
    if (!message.trim() || isLoading) {
      return;
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Call appropriate AI
      const mutation = assistantType === 'free' ? chatFreeMutation : chatPaidMutation;
      const response = await mutation.mutateAsync({ message });

      if (response.success) {
        // Add assistant response
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: response.message,
          timestamp: new Date(),
          tokensUsed: response.tokensUsed,
          responseTime: response.responseTime
        };
        setMessages(prev => [...prev, assistantMessage]);
      } else {
        // Add error message
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `❌ ${response.errorMessage || 'حدث خطأ أثناء المعالجة'}`,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } catch (error) {
      console.error('[ChatWidget] Error sending message:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '❌ عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Switch assistant type
  const handleSwitchAssistant = () => {
    const newType = assistantType === 'free' ? 'paid' : 'free';
    setAssistantType(newType);

    // Add system message
    const systemMessage: Message = {
      id: Date.now().toString(),
      role: 'assistant',
      content: `تم التبديل إلى ${newType === 'free' ? 'المساعد المجاني 🤖' : 'المساعد المتقدم 💎'}`,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, systemMessage]);
  };

  // Keyboard shortcut to open chat (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Don't render if not authenticated
  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 group"
          aria-label="فتح المساعد الذكي"
        >
          <div className="relative">
            <Avatar type={assistantType} animated />

            {/* Notification badge */}
            {usage?.remaining !== undefined && usage.remaining !== null && usage.remaining <= 3 && (
              <Badge
                variant="destructive"
                className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs"
              >
                {usage.remaining}
              </Badge>
            )}

            {/* Pulse animation */}
            <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
          </div>

          {/* Tooltip */}
          <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-900 text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            المساعد الذكي (Ctrl+K)
          </div>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card
          className={`fixed z-50 shadow-2xl transition-all ${
            isMinimized
              ? 'bottom-6 right-6 w-80 h-16'
              : 'bottom-6 right-6 w-96 h-[600px]'
          }`}
        >
          {/* Header */}
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 border-b">
            <div className="flex items-center gap-2">
              <Avatar type={assistantType} size="sm" />
              <div>
                <CardTitle className="text-base">
                  {assistantType === 'free' ? 'مساعد مجاني' : 'مساعد متقدم'}
                </CardTitle>
                {usage?.remaining !== undefined && usage.remaining !== null && (
                  <p className="text-xs text-muted-foreground">
                    {usage.remaining} رسالة متبقية اليوم
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1">
              {/* Switch Assistant */}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleSwitchAssistant}
                title={assistantType === 'free' ? 'التبديل للمساعد المتقدم' : 'التبديل للمساعد المجاني'}
              >
                {assistantType === 'free' ? <Sparkles className="h-4 w-4" /> : <MessageCircle className="h-4 w-4" />}
              </Button>

              {/* Minimize */}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>

              {/* Close */}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>

          {/* Content */}
          {!isMinimized && (
            <CardContent className="p-0 flex flex-col h-[calc(600px-4rem)]">
              {/* Messages */}
              <ChatMessages
                messages={messages}
                isLoading={isLoading}
                assistantType={assistantType}
              />

              {/* Input */}
              <ChatInput
                onSend={handleSend}
                disabled={isLoading}
                assistantType={assistantType}
                remainingMessages={usage?.remaining}
              />
            </CardContent>
          )}
        </Card>
      )}
    </>
  );
}

