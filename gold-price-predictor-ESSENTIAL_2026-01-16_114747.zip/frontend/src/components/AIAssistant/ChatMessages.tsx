/**
 * Chat Messages Component
 * Displays chat message history with markdown support
 */

import { useEffect, useRef } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { Avatar } from "./Avatar";
import { cn } from "@/lib/utils";
import { Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import type { Message } from "./ChatWidget";
import "highlight.js/styles/github-dark.css";
import { trpc } from "@/lib/trpc";

interface ChatMessagesProps {
  messages: Message[];
  isLoading: boolean;
  assistantType: "free" | "paid";
}

function WelcomeMessage({ assistantType }: { assistantType: "free" | "paid" }) {
  const { data: assistantInfo, isLoading } = trpc.ai.getAssistantInfo.useQuery({
    assistantType,
  });

  if (isLoading || !assistantInfo) {
    return (
      <div className="text-center text-muted-foreground py-8">
        <Avatar type={assistantType} size="lg" />
        <p className="mt-4 text-sm">جاري التحميل...</p>
      </div>
    );
  }

  return (
    <div className="text-center py-8">
      <Avatar type={assistantType} size="lg" animated />
      <div className="mt-6 max-w-md mx-auto text-right prose prose-sm dark:prose-invert">
        <p>
          🌟 <strong>مرحباً بك! أنا {assistantInfo.name}</strong> 🌟
        </p>
        <h3>من أنا؟</h3>
        <p>
          {assistantType === "free"
            ? "أنا مساعد ذكاء اصطناعي مجاني متخصص في الإجابة على الأسئلة العامة حول الأسعار والتداول."
            : "أنا مساعد ذكاء اصطناعي متقدم متخصص في التحليل المالي والتوقعات."}
        </p>
        <h3>وظيفتي:</h3>
        <ul>
          {assistantInfo.features.map((f: string) => (
            <li key={f}>{f}</li>
          ))}
        </ul>
        <h3>كيف يمكنني مساعدتك؟</h3>
        <p>
          {assistantType === "free"
            ? "اسألني عن أي سعر أو مفهوم تريد فهمه! 😊"
            : "فقط اسألني عن أي أصل أو تحليل تحتاجه! 🚀"}
        </p>
      </div>
    </div>
  );
}

export function ChatMessages({
  messages,
  isLoading,
  assistantType,
}: ChatMessagesProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.length === 0 && (
        <WelcomeMessage assistantType={assistantType} />
      )}

      {messages.map(message => (
        <MessageBubble
          key={message.id}
          message={message}
          assistantType={assistantType}
        />
      ))}

      {isLoading && (
        <div className="flex items-start gap-2">
          <Avatar type={assistantType} size="sm" state="thinking" />
          <div className="bg-muted rounded-lg p-3 max-w-[80%]">
            <div className="flex gap-1">
              <div
                className="w-2 h-2 bg-primary rounded-full animate-bounce"
                style={{ animationDelay: "0ms" }}
              />
              <div
                className="w-2 h-2 bg-primary rounded-full animate-bounce"
                style={{ animationDelay: "150ms" }}
              />
              <div
                className="w-2 h-2 bg-primary rounded-full animate-bounce"
                style={{ animationDelay: "300ms" }}
              />
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}

function MessageBubble({
  message,
  assistantType,
}: {
  message: Message;
  assistantType: "free" | "paid";
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isUser = message.role === "user";

  return (
    <div className={cn("flex gap-2", isUser ? "justify-end" : "justify-start")}>
      {!isUser && <Avatar type={assistantType} size="sm" />}

      <div
        className={cn(
          "rounded-lg p-3 max-w-[80%] group relative",
          isUser ? "bg-primary text-primary-foreground" : "bg-muted"
        )}
      >
        {/* Message content with markdown */}
        <div className="prose prose-sm dark:prose-invert max-w-none">
          {isUser ? (
            <p className="m-0">{message.content}</p>
          ) : (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeHighlight]}
              components={{
                // Custom code block with copy button
                code({ node, inline, className, children, ...props }: any) {
                  const match = /language-(\w+)/.exec(className || "");
                  return !inline && match ? (
                    <div className="relative">
                      <pre className={className} {...props}>
                        <code className={className}>{children}</code>
                      </pre>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => {
                          navigator.clipboard.writeText(String(children));
                        }}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <code className={className} {...props}>
                      {children}
                    </code>
                  );
                },
              }}
            >
              {message.content}
            </ReactMarkdown>
          )}
        </div>

        {/* Copy button for assistant messages */}
        {!isUser && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-1 left-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={handleCopy}
          >
            {copied ? (
              <Check className="h-3 w-3" />
            ) : (
              <Copy className="h-3 w-3" />
            )}
          </Button>
        )}

        {/* Metadata */}
        <div className="flex items-center gap-2 mt-2 text-xs opacity-70">
          <span>
            {message.timestamp.toLocaleTimeString("ar-EG", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
          {message.tokensUsed && <span>• {message.tokensUsed} tokens</span>}
          {message.responseTime && (
            <span>• {(message.responseTime / 1000).toFixed(1)}s</span>
          )}
        </div>
      </div>

      {isUser && (
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-medium">
          {message.content[0]?.toUpperCase() || "U"}
        </div>
      )}
    </div>
  );
}
