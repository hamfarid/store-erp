/**
 * Avatar Component
 * Displays AI assistant avatar with animations
 */

import { cn } from "@/lib/utils";

interface AvatarProps {
  type: 'free' | 'paid';
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
  state?: 'idle' | 'thinking' | 'speaking';
}

export function Avatar({ type, size = 'lg', animated = false, state = 'idle' }: AvatarProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const avatarSrc = type === 'free' 
    ? '/avatars/free-ai-avatar.png' 
    : '/avatars/paid-ai-avatar.png';

  return (
    <div className="relative inline-block">
      <img
        src={avatarSrc}
        alt={type === 'free' ? 'مساعد مجاني' : 'مساعد متقدم'}
        className={cn(
          sizeClasses[size],
          'rounded-full object-cover',
          'transition-transform duration-300',
          animated && 'hover:scale-110',
          state === 'thinking' && 'animate-pulse',
          state === 'speaking' && 'animate-bounce'
        )}
      />

      {/* Status indicator */}
      {state === 'thinking' && (
        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-yellow-500 rounded-full animate-pulse border-2 border-white" />
      )}
      {state === 'speaking' && (
        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-ping border-2 border-white" />
      )}
    </div>
  );
}

