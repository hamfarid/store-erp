/**
 * Prediction Card Component
 * Displays prediction information in a card format
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown, Activity, Target } from "lucide-react";
import { format } from "date-fns";

interface PredictionCardProps {
  prediction: {
    id: number;
    assetName?: string;
    assetSymbol?: string;
    modelType: string;
    predictedPrice: number;
    currentPrice?: number;
    targetDate: string;
    confidenceLevel: number;
    accuracy?: number;
    createdAt: number;
  };
  compact?: boolean;
}

export function PredictionCard({ prediction, compact = false }: PredictionCardProps) {
  const priceChange = prediction.currentPrice
    ? ((prediction.predictedPrice - prediction.currentPrice) / prediction.currentPrice) * 100
    : 0;

  const isPositive = priceChange > 0;
  const confidenceColor =
    prediction.confidenceLevel >= 80
      ? "default"
      : prediction.confidenceLevel >= 60
      ? "secondary"
      : "outline";

  return (
    <Card>
      <CardHeader className={compact ? "pb-3" : ""}>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center gap-2">
              {prediction.assetName || prediction.assetSymbol}
              {isPositive ? (
                <TrendingUp className="h-4 w-4 text-green-500" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500" />
              )}
            </CardTitle>
            <CardDescription className="mt-1">
              {prediction.modelType} • {format(new Date(prediction.targetDate), "yyyy-MM-dd")}
            </CardDescription>
          </div>
          <Badge variant={confidenceColor}>
            <Activity className="h-3 w-3 mr-1" />
            {prediction.confidenceLevel}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">السعر المتوقع</p>
            <p className="text-2xl font-bold">
              ${prediction.predictedPrice.toLocaleString()}
            </p>
          </div>
          {prediction.currentPrice && (
            <div>
              <p className="text-sm text-muted-foreground">التغير المتوقع</p>
              <p
                className={`text-2xl font-bold ${
                  isPositive ? "text-green-600" : "text-red-600"
                }`}
              >
                {isPositive ? "+" : ""}
                {priceChange.toFixed(2)}%
              </p>
            </div>
          )}
        </div>

        {!compact && (
          <>
            {prediction.currentPrice && (
              <div className="flex justify-between text-sm pt-2 border-t">
                <span className="text-muted-foreground">السعر الحالي:</span>
                <span className="font-semibold">
                  ${prediction.currentPrice.toLocaleString()}
                </span>
              </div>
            )}

            {prediction.accuracy !== undefined && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground flex items-center gap-1">
                  <Target className="h-3 w-3" />
                  الدقة:
                </span>
                <span className="font-semibold">{prediction.accuracy.toFixed(2)}%</span>
              </div>
            )}

            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">تاريخ التوقع:</span>
              <span>{format(new Date(prediction.createdAt), "yyyy-MM-dd HH:mm")}</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default PredictionCard;

