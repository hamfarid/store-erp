// File: /home/ubuntu/asset_predictor_ui/client/src/components/Layout.tsx
/**
 * Main Layout Component
 * Provides consistent layout structure for all pages
 */

import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-background">
      <main className="container mx-auto p-4">
        {children}
      </main>
    </div>
  );
};

export default Layout;

