import { Button } from "@/components/ui/button";
import { Trash2, Download, X } from "lucide-react";

interface BulkActionsToolbarProps {
  selectedCount: number;
  onDelete: () => void;
  onExport: () => void;
  onClear: () => void;
}

export default function BulkActionsToolbar({
  selectedCount,
  onDelete,
  onExport,
  onClear,
}: BulkActionsToolbarProps) {
  if (selectedCount === 0) {
    return null;
  }

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="font-medium text-blue-900">
          تم تحديد {selectedCount} عنصر
        </span>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onExport}
          className="gap-2"
        >
          <Download className="h-4 w-4" />
          تصدير المحدد
        </Button>
        <Button
          variant="destructive"
          size="sm"
          onClick={onDelete}
          className="gap-2"
        >
          <Trash2 className="h-4 w-4" />
          حذف المحدد
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClear}
          className="gap-2"
        >
          <X className="h-4 w-4" />
          إلغاء التحديد
        </Button>
      </div>
    </div>
  );
}

