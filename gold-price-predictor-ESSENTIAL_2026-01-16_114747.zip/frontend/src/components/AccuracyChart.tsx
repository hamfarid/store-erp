/**
 * Accuracy Chart Component
 * Displays prediction accuracy visualization
 */

import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface AccuracyDataPoint {
  modelType: string;
  accuracy: number;
  totalPredictions: number;
}

interface AccuracyChartProps {
  data: AccuracyDataPoint[];
  title?: string;
  description?: string;
  height?: number;
}

export function AccuracyChart({
  data,
  title = "دقة التوقعات حسب النموذج",
  description = "مقارنة دقة نماذج التوقع المختلفة",
  height = 300,
}: AccuracyChartProps) {
  const chartData = {
    labels: data.map(d => d.modelType),
    datasets: [
      {
        label: 'الدقة (%)',
        data: data.map(d => d.accuracy),
        backgroundColor: data.map(d =>
          d.accuracy >= 80 ? 'rgba(34, 197, 94, 0.8)' :
          d.accuracy >= 60 ? 'rgba(59, 130, 246, 0.8)' :
          'rgba(239, 68, 68, 0.8)'
        ),
        borderColor: data.map(d =>
          d.accuracy >= 80 ? 'rgb(34, 197, 94)' :
          d.accuracy >= 60 ? 'rgb(59, 130, 246)' :
          'rgb(239, 68, 68)'
        ),
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const dataPoint = data[context.dataIndex];
            const accuracy = context.parsed.y || 0;
            return [
              `الدقة: ${accuracy.toFixed(2)}%`,
              `عدد التوقعات: ${dataPoint.totalPredictions}`,
            ];
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: function(value: number | string) {
            return value + '%';
          },
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div style={{ height: `${height}px`, width: '100%' }}>
          <Bar data={chartData} options={options} />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4 text-center text-sm">
          <div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 rounded bg-green-500" />
              <span className="text-muted-foreground">ممتاز</span>
            </div>
            <div className="font-semibold mt-1">≥ 80%</div>
          </div>
          <div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 rounded bg-blue-500" />
              <span className="text-muted-foreground">جيد</span>
            </div>
            <div className="font-semibold mt-1">60-79%</div>
          </div>
          <div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 rounded bg-red-500" />
              <span className="text-muted-foreground">ضعيف</span>
            </div>
            <div className="font-semibold mt-1">&lt; 60%</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default AccuracyChart;

