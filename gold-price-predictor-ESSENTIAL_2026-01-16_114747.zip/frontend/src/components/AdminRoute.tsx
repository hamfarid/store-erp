// FILE: client/src/components/AdminRoute.tsx | PURPOSE: Route guard for admin users | OWNER: Frontend Team | RELATED: App.tsx, useAuth.ts | LAST-AUDITED: 2025-01-18

/**
 * AdminRoute Component
 * Wraps routes that require admin role
 * Redirects to 403 (Forbidden) if user is not admin
 */

import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

interface AdminRouteProps {
  children: React.ReactNode;
}

export function AdminRoute({ children }: AdminRouteProps) {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        // Redirect to login if not authenticated
        navigate("/login");
      } else if (user.role !== "admin") {
        // Redirect to 403 if not admin
        navigate("/403");
      }
    }
  }, [user, loading, navigate]);

  // Show loading spinner while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-sm text-muted-foreground">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  // Don't render children if not authenticated or not admin
  if (!user || user.role !== "admin") {
    return null;
  }

  // Render children if authenticated and admin
  return <>{children}</>;
}

