/**
 * Professional Page Layout Component
 * Consistent layout wrapper for all pages with animations and responsive design
 */

import { ReactNode } from "react";
import { Breadcrumbs } from "./ui/breadcrumbs";
import { cn } from "@/lib/utils";
import { motion, type Variants } from "framer-motion";

interface PageLayoutProps {
  children: ReactNode;
  title?: string | ReactNode;
  description?: string | ReactNode;
  breadcrumbs?: Array<{ label: string; href?: string }>;
  actions?: ReactNode;
  className?: string;
  showBreadcrumbs?: boolean;
}

const headerVariants: Variants = {
  hidden: { opacity: 0, y: -20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] },
  },
};

const contentVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.4, delay: 0.1, ease: [0.4, 0, 0.2, 1] },
  },
};

export function PageLayout({
  children,
  title,
  description,
  breadcrumbs,
  actions,
  className,
  showBreadcrumbs = true,
}: PageLayoutProps) {
  return (
    <div className={cn("min-h-screen bg-gradient-hero", className)}>
      {/* Header */}
      {(title || showBreadcrumbs) && (
        <motion.header
          variants={headerVariants}
          initial="hidden"
          animate="visible"
          className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b"
        >
          <div className="container mx-auto px-4 py-4 sm:px-6 lg:px-8">
            {showBreadcrumbs && breadcrumbs && breadcrumbs.length > 0 && (
              <div className="mb-4">
                <Breadcrumbs items={breadcrumbs} />
              </div>
            )}
            {(title || actions) && (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                {title && (
                  <div className="flex-1">
                    {typeof title === "string" ? (
                      <h1 className="text-2xl sm:text-3xl font-bold">
                        {title}
                      </h1>
                    ) : (
                      <div className="text-2xl sm:text-3xl font-bold">
                        {title}
                      </div>
                    )}
                    {description &&
                      (typeof description === "string" ? (
                        <p className="text-sm sm:text-base text-muted-foreground mt-1">
                          {description}
                        </p>
                      ) : (
                        <div className="text-sm sm:text-base text-muted-foreground mt-1">
                          {description}
                        </div>
                      ))}
                  </div>
                )}
                {actions && (
                  <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap">
                    {actions}
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.header>
      )}

      {/* Main Content */}
      <motion.main
        variants={contentVariants}
        initial="hidden"
        animate="visible"
        className="container mx-auto px-4 py-8 sm:px-6 lg:px-8"
      >
        {children}
      </motion.main>
    </div>
  );
}
