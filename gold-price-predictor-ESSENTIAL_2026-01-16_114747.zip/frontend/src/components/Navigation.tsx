/**
 * Global Navigation Component - Premium Gold Price Predictor
 * Modern navigation bar with gold theme
 */

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "./ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "./ui/sheet";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { useAuth } from "@/_core/hooks/useAuth";
import { APP_TITLE } from "@/const";
import { cn } from "@/lib/utils";
import { NotificationDropdown } from "./notifications/NotificationDropdown";
import {
  LayoutDashboard,
  TrendingUp,
  Bell,
  Briefcase,
  FileText,
  Settings,
  Shield,
  User,
  LogOut,
  Menu,
  Database,
  Brain,
  Activity,
  BarChart3,
  Layers,
  LineChart,
  BookOpen,
  Calculator,
  History,
  AlertTriangle,
  GraduationCap,
  ChevronDown,
  Sparkles,
  Sun,
  Moon,
  HelpCircle,
  X,
} from "lucide-react";

// Theme toggle hook (simplified)
function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window !== "undefined") {
      return document.documentElement.classList.contains("dark") ? "dark" : "light";
    }
    return "light";
  });

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme(theme === "light" ? "dark" : "light");

  return { theme, toggleTheme };
}

// Navigation item type
interface NavItem {
  href: string;
  label: string;
  icon: any;
  badge?: string;
}

// Navigation group type
interface NavGroup {
  label: string;
  items: NavItem[];
}

export function Navigation() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const mainMenuItems: NavItem[] = [
    { href: "/", label: "الرئيسية", icon: LayoutDashboard },
    { href: "/dashboard", label: "لوحة التحكم", icon: TrendingUp },
    { href: "/comprehensive", label: "الإدارة الشاملة", icon: Layers },
    { href: "/portfolio", label: "المحفظة", icon: Briefcase },
    { href: "/alerts", label: "التنبيهات", icon: Bell, badge: "3" },
  ];

  const analysisItems: NavItem[] = [
    { href: "/predictions", label: "التوقعات", icon: LineChart },
    { href: "/analytics", label: "تحليلات الأسعار", icon: BarChart3 },
    { href: "/technical-analysis", label: "التحليل الفني", icon: LineChart },
    { href: "/trading-signals", label: "إشارات التداول", icon: Activity },
    { href: "/price-points", label: "نقاط السعر", icon: Activity },
    { href: "/break-even-calculator", label: "حاسبة التعادل", icon: Calculator },
    { href: "/reports", label: "التقارير", icon: FileText },
  ];

  const advancedItems: NavItem[] = [
    { href: "/history", label: "سجل التوقعات", icon: History },
    { href: "/prediction-accuracy", label: "دقة التوقعات", icon: BarChart3 },
    { href: "/analytics-monitoring", label: "التحليلات والمراقبة", icon: BarChart3 },
    { href: "/ml-models", label: "نماذج ML", icon: Brain },
    { href: "/system-health", label: "صحة النظام", icon: Activity },
    { href: "/drift-detection", label: "كشف الانحراف", icon: AlertTriangle },
  ];

  const marketItems: NavItem[] = [
    { href: "/fear-greed", label: "مؤشر الخوف والطمع", icon: Activity },
    { href: "/news-sentiment", label: "تحليل الأخبار", icon: TrendingUp },
    { href: "/expert-opinions", label: "آراء الخبراء", icon: BookOpen },
    { href: "/learning", label: "التعلم", icon: GraduationCap },
    { href: "/learning-control", label: "لوحة تحكم التعلم", icon: Brain },
  ];

  const adminItems: NavItem[] = [
    { href: "/admin", label: "لوحة المدير", icon: Shield },
    { href: "/admin/users", label: "المستخدمون", icon: User },
    { href: "/admin/assets", label: "الأصول", icon: TrendingUp },
    { href: "/admin/backup", label: "النسخ الاحتياطي", icon: Database },
    { href: "/admin/ai-learning", label: "إدارة التعلم", icon: Brain },
    { href: "/admin/learning-monitoring", label: "مراقبة التعلم", icon: Activity },
    { href: "/admin/logs", label: "السجلات", icon: FileText },
    { href: "/security", label: "الأمان", icon: AlertTriangle },
  ];

  const navGroups: NavGroup[] = [
    { label: "التحليلات", items: analysisItems },
    { label: "متقدم", items: advancedItems },
    { label: "السوق", items: marketItems },
  ];

  const isActive = (href: string) => {
    if (href === "/") {return location === "/";}
    return location.startsWith(href);
  };

  const NavLink = ({ item, onClick }: { item: NavItem; onClick?: () => void }) => (
    <Link href={item.href} onClick={onClick}>
      <Button
        variant={isActive(item.href) ? "default" : "ghost"}
        size="sm"
        className={cn(
          "gap-2 transition-all",
          isActive(item.href)
            ? "bg-primary text-primary-foreground shadow-sm"
            : "hover:bg-primary/10"
        )}
      >
        <item.icon className="h-4 w-4" />
        <span>{item.label}</span>
        {item.badge && (
          <Badge variant="destructive" className="h-5 w-5 p-0 justify-center text-[10px]">
            {item.badge}
          </Badge>
        )}
      </Button>
    </Link>
  );

  const MobileNavItem = ({ item, onClick }: { item: NavItem; onClick?: () => void }) => (
    <Link href={item.href} onClick={onClick}>
      <div
        className={cn(
          "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
          isActive(item.href)
            ? "bg-primary text-primary-foreground"
            : "hover:bg-muted"
        )}
      >
        <item.icon className="h-5 w-5" />
        <span className="font-medium">{item.label}</span>
        {item.badge && (
          <Badge variant="destructive" className="mr-auto">
            {item.badge}
          </Badge>
        )}
      </div>
    </Link>
  );

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled
          ? "bg-background/95 backdrop-blur-lg border-b shadow-sm"
          : "bg-background border-b"
      )}
      dir="rtl"
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer group">
              <div className="p-2 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg shadow-amber-500/20 group-hover:shadow-amber-500/40 transition-shadow">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div className="hidden sm:block">
                <span className="font-bold text-lg gold-shimmer">{APP_TITLE}</span>
                <p className="text-xs text-muted-foreground">توقعات الذهب بالذكاء الاصطناعي</p>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {/* Main Menu Items */}
            {mainMenuItems.map((item) => (
              <NavLink key={item.href} item={item} />
            ))}

            {/* More Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2">
                  <Menu className="h-4 w-4" />
                  المزيد
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-56">
                {navGroups.map((group, idx) => (
                  <div key={group.label}>
                    {idx > 0 && <DropdownMenuSeparator />}
                    <DropdownMenuLabel className="text-xs text-muted-foreground">
                      {group.label}
                    </DropdownMenuLabel>
                    <DropdownMenuGroup>
                      {group.items.map((item) => (
                        <Link key={item.href} href={item.href}>
                          <DropdownMenuItem
                            className={cn(
                              "cursor-pointer gap-2",
                              isActive(item.href) && "bg-primary/10"
                            )}
                          >
                            <item.icon className="h-4 w-4" />
                            <span>{item.label}</span>
                          </DropdownMenuItem>
                        </Link>
                      ))}
                    </DropdownMenuGroup>
                  </div>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="hidden sm:flex"
            >
              {theme === "light" ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
            </Button>

            {/* Notifications */}
            {isAuthenticated && (
              <NotificationDropdown className="hidden sm:flex" />
            )}

            {/* Help */}
            <Link href="/help">
              <Button variant="ghost" size="icon" className="hidden sm:flex">
                <HelpCircle className="h-5 w-5" />
              </Button>
            </Link>

            {/* User Menu */}
            {isAuthenticated ? (
              <>
                {/* Admin Menu */}
                {user?.role === "admin" && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 border-amber-500/50 hover:border-amber-500 hover:bg-amber-500/10"
                      >
                        <Shield className="h-4 w-4 text-amber-600" />
                        <span className="hidden md:inline">المدير</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-52">
                      <DropdownMenuLabel className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-amber-600" />
                        إدارة النظام
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      {adminItems.map((item) => (
                        <Link key={item.href} href={item.href}>
                          <DropdownMenuItem className="cursor-pointer gap-2">
                            <item.icon className="h-4 w-4" />
                            <span>{item.label}</span>
                          </DropdownMenuItem>
                        </Link>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}

                {/* User Profile Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-2 pr-1">
                      <Avatar className="h-7 w-7">
                        <AvatarFallback className="bg-primary/20 text-primary text-xs">
                          {user?.name?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <span className="hidden md:inline font-medium">
                        {user?.name || "المستخدم"}
                      </span>
                      <ChevronDown className="h-3 w-3 hidden md:block" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-primary/20 text-primary">
                            {user?.name?.charAt(0) || "U"}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{user?.name}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {user?.email}
                          </p>
                        </div>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <Link href="/profile">
                      <DropdownMenuItem className="cursor-pointer gap-2">
                        <User className="h-4 w-4" />
                        الملف الشخصي
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/settings">
                      <DropdownMenuItem className="cursor-pointer gap-2">
                        <Settings className="h-4 w-4" />
                        الإعدادات
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/notifications">
                      <DropdownMenuItem className="cursor-pointer gap-2">
                        <Bell className="h-4 w-4" />
                        الإشعارات
                        <Badge variant="destructive" className="mr-auto h-5 px-1.5 text-[10px]">
                          3
                        </Badge>
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      className="cursor-pointer gap-2 text-red-600 focus:text-red-600"
                      onClick={() => logout()}
                    >
                      <LogOut className="h-4 w-4" />
                      تسجيل الخروج
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm">
                    تسجيل الدخول
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm" className="bg-primary hover:bg-primary/90">
                    إنشاء حساب
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 p-0">
                <SheetHeader className="p-4 border-b">
                  <SheetTitle className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600">
                      <Sparkles className="h-4 w-4 text-white" />
                    </div>
                    {APP_TITLE}
                  </SheetTitle>
                </SheetHeader>
                <ScrollArea className="h-[calc(100vh-80px)]">
                  <div className="p-4 space-y-6">
                    {/* Main Items */}
                    <div className="space-y-1">
                      {mainMenuItems.map((item) => (
                        <MobileNavItem
                          key={item.href}
                          item={item}
                          onClick={() => setMobileMenuOpen(false)}
                        />
                      ))}
                    </div>

                    {/* Groups */}
                    {navGroups.map((group) => (
                      <div key={group.label}>
                        <p className="text-xs font-semibold text-muted-foreground px-4 mb-2">
                          {group.label}
                        </p>
                        <div className="space-y-1">
                          {group.items.map((item) => (
                            <MobileNavItem
                              key={item.href}
                              item={item}
                              onClick={() => setMobileMenuOpen(false)}
                            />
                          ))}
                        </div>
                      </div>
                    ))}

                    {/* Admin Items */}
                    {user?.role === "admin" && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground px-4 mb-2 flex items-center gap-1">
                          <Shield className="h-3 w-3" />
                          إدارة النظام
                        </p>
                        <div className="space-y-1">
                          {adminItems.map((item) => (
                            <MobileNavItem
                              key={item.href}
                              item={item}
                              onClick={() => setMobileMenuOpen(false)}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Theme Toggle */}
                    <div className="px-4 pt-4 border-t">
                      <Button
                        variant="outline"
                        className="w-full justify-start gap-2"
                        onClick={toggleTheme}
                      >
                        {theme === "light" ? (
                          <>
                            <Moon className="h-4 w-4" />
                            الوضع الداكن
                          </>
                        ) : (
                          <>
                            <Sun className="h-4 w-4" />
                            الوضع الفاتح
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </ScrollArea>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
