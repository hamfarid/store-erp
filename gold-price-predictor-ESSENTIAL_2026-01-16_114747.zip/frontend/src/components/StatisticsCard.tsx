/**
 * Statistics Card Component
 * Displays statistical information in a card format
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatisticsCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon?: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: "default" | "secondary" | "destructive" | "outline";
  loading?: boolean;
}

export function StatisticsCard({
  title,
  value,
  description,
  icon: Icon,
  trend,
  variant = "default",
  loading = false,
}: StatisticsCardProps) {
  const variantColors = {
    default: "text-primary",
    secondary: "text-green-600",
    destructive: "text-red-600",
    outline: "text-yellow-600",
  };

  const variantBgColors = {
    default: "bg-primary/10",
    secondary: "bg-green-100 dark:bg-green-900/20",
    destructive: "bg-red-100 dark:bg-red-900/20",
    outline: "bg-yellow-100 dark:bg-yellow-900/20",
  };

  if (loading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          {Icon && (
            <div className={cn("h-10 w-10 rounded-full flex items-center justify-center", variantBgColors[variant])}>
              <Icon className={cn("h-5 w-5", variantColors[variant])} />
            </div>
          )}
        </CardHeader>
        <CardContent>
          <div className="h-8 w-24 bg-muted animate-pulse rounded" />
          {description && <div className="h-4 w-32 bg-muted animate-pulse rounded mt-2" />}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {Icon && (
          <div className={cn("h-10 w-10 rounded-full flex items-center justify-center", variantBgColors[variant])}>
            <Icon className={cn("h-5 w-5", variantColors[variant])} />
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <CardDescription className="mt-1">{description}</CardDescription>
        )}
        {trend && (
          <div className="flex items-center mt-2 text-sm">
            <span
              className={cn(
                "font-medium",
                trend.isPositive ? "text-green-600" : "text-red-600"
              )}
            >
              {trend.isPositive ? "+" : ""}
              {trend.value}%
            </span>
            <span className="text-muted-foreground mr-2">عن الشهر الماضي</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default StatisticsCard;

