/**
 * App Sidebar Component
 * Premium sidebar navigation with collapsible groups
 */

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/_core/hooks/useAuth";
import { APP_TITLE } from "@/const";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  TrendingUp,
  Bell,
  FileText,
  Settings,
  Shield,
  User,
  LogOut,
  ChevronRight,
  Home,
  Brain,
  Activity,
  BarChart3,
  Layers,
  LineChart,
  BookOpen,
  Calculator,
  Cpu,
  GraduationCap,
  Database,
  ChevronDown,
  Sparkles,
  Globe,
  Wallet,
  Target,
  Zap,
  PieChart,
  HelpCircle,
} from "lucide-react";
// Unused imports: Briefcase, History, AlertTriangle, Moon, Sun, Eye, CreditCard
// import { cn } from "@/lib/utils"; // Unused
// import { motion } from "framer-motion"; // Unused

// Navigation items configuration
const mainNavItems = [
  {
    title: "الرئيسية",
    icon: Home,
    href: "/",
  },
  {
    title: "لوحة التحكم",
    icon: LayoutDashboard,
    href: "/dashboard",
    badge: "جديد",
  },
  {
    title: "الإدارة الشاملة",
    icon: Layers,
    href: "/comprehensive",
  },
];

const tradingItems = [
  {
    title: "الأصول",
    icon: Globe,
    href: "/assets",
  },
  {
    title: "التوقعات",
    icon: Brain,
    href: "/predictions",
    children: [
      { title: "التوقعات الحالية", href: "/predictions" },
      { title: "توقعات ثلاثية المستوى", href: "/predictions/three-level" },
      { title: "دقة التوقعات", href: "/prediction-accuracy" },
      { title: "سجل التوقعات", href: "/history" },
    ],
  },
  {
    title: "المحفظة",
    icon: Wallet,
    href: "/portfolio",
  },
  {
    title: "التنبيهات",
    icon: Bell,
    href: "/alerts",
    badge: "3",
  },
  {
    title: "إشارات التداول",
    icon: Target,
    href: "/trading-signals",
  },
];

const analysisItems = [
  {
    title: "التحليل الفني",
    icon: LineChart,
    href: "/technical-analysis",
  },
  {
    title: "تحليلات الأسعار",
    icon: BarChart3,
    href: "/analytics",
  },
  {
    title: "مؤشر الخوف والطمع",
    icon: Activity,
    href: "/fear-greed",
  },
  {
    title: "تحليل الأخبار",
    icon: FileText,
    href: "/news-sentiment",
  },
  {
    title: "آراء الخبراء",
    icon: BookOpen,
    href: "/expert-opinions",
  },
  {
    title: "حاسبة التعادل",
    icon: Calculator,
    href: "/break-even-calculator",
  },
];

const aiItems = [
  {
    title: "نماذج ML",
    icon: Cpu,
    href: "/ml-models",
    children: [
      { title: "النماذج المتاحة", href: "/ml-models" },
      { title: "تقييم النماذج", href: "/model-evaluation" },
      { title: "كشف الانحراف", href: "/drift-detection" },
    ],
  },
  {
    title: "مهام الذكاء الاصطناعي",
    icon: Zap,
    href: "/ai-tasks",
  },
  {
    title: "التعلم",
    icon: GraduationCap,
    href: "/learning",
    children: [
      { title: "المسار التعليمي", href: "/learning" },
      { title: "تحسين المسار", href: "/learning-path" },
    ],
  },
  {
    title: "لوحة تحكم التعلم",
    icon: Brain,
    href: "/learning-control",
    badge: "جديد",
  },
];

const adminItems = [
  {
    title: "لوحة المدير",
    icon: Shield,
    href: "/admin",
  },
  {
    title: "المستخدمون",
    icon: User,
    href: "/admin/users",
  },
  {
    title: "الأصول",
    icon: TrendingUp,
    href: "/admin/assets",
  },
  {
    title: "تدريب النماذج",
    icon: Brain,
    href: "/admin/train-models",
    children: [
      { title: "بدء التدريب", href: "/admin/train-models" },
      { title: "أداء النماذج", href: "/admin/model-performance" },
      { title: "مراقبة التدريب", href: "/admin/training-monitor" },
    ],
  },
  {
    title: "إدارة التعلم",
    icon: GraduationCap,
    href: "/admin/ai-learning",
    children: [
      { title: "إدارة التعلم", href: "/admin/ai-learning" },
      { title: "مراقبة التعلم", href: "/admin/learning-monitoring" },
    ],
  },
  {
    title: "النسخ الاحتياطي",
    icon: Database,
    href: "/admin/backup",
  },
  {
    title: "السجلات",
    icon: FileText,
    href: "/admin/logs",
  },
  {
    title: "الأمان",
    icon: Shield,
    href: "/security",
  },
];

const systemItems = [
  {
    title: "صحة النظام",
    icon: Activity,
    href: "/system-health",
  },
  {
    title: "التقارير",
    icon: PieChart,
    href: "/reports",
    children: [
      { title: "التقارير", href: "/reports" },
      { title: "إعداد التقارير", href: "/reports/setup" },
    ],
  },
  {
    title: "الإشعارات",
    icon: Bell,
    href: "/notifications",
  },
  {
    title: "إدارة البيانات",
    icon: Database,
    href: "/data-management",
  },
];

// Navigation Group Component
function NavGroup({
  title,
  items,
  defaultOpen = true,
}: {
  title: string;
  items: Array<{
    href: string;
    title: string;
    icon?: any;
    badge?: string;
    children?: Array<{ title: string; href: string }>;
  }>;
  defaultOpen?: boolean;
}) {
  const [location] = useLocation();

  const isActive = (href: string) => {
    if (href === "/") {
      return location === "/";
    }
    if (location.startsWith(href)) {
      return true;
    }
    return false;
  };

  return (
    <SidebarGroup>
      <SidebarGroupLabel>{title}</SidebarGroupLabel>
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) =>
            item.children ? (
              <Collapsible key={item.href} defaultOpen={defaultOpen} className="group/collapsible">
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton tooltip={item.title}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                      <ChevronRight className="mr-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <SidebarMenuSub>
                      {item.children.map((child: { href: string; title: string }) => (
                        <SidebarMenuSubItem key={child.href}>
                          <SidebarMenuSubButton asChild isActive={isActive(child.href)}>
                            <Link href={child.href}>{child.title}</Link>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  </CollapsibleContent>
                </SidebarMenuItem>
              </Collapsible>
            ) : (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton asChild tooltip={item.title} isActive={isActive(item.href)}>
                  <Link href={item.href}>
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                    {item.badge && (
                      <Badge variant="secondary" className="mr-auto text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            )
          )}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  );
}

// Main Sidebar Component
export function AppSidebar() {
  const { user, isAuthenticated, logout } = useAuth();
  // const { state } = useSidebar(); // Unused

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Sidebar collapsible="icon">
      {/* Header */}
      <SidebarHeader className="border-b">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <Link href="/">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <Sparkles className="size-4" />
                </div>
                <div className="flex flex-col gap-0.5 leading-none">
                  <span className="font-semibold">{APP_TITLE}</span>
                  <span className="text-xs text-muted-foreground">توقع الأصول</span>
                </div>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      {/* Content */}
      <SidebarContent>
        <NavGroup title="الرئيسية" items={mainNavItems} />
        <SidebarSeparator />
        <NavGroup title="التداول" items={tradingItems} />
        <SidebarSeparator />
        <NavGroup title="التحليل" items={analysisItems} defaultOpen={false} />
        <SidebarSeparator />
        <NavGroup title="الذكاء الاصطناعي" items={aiItems} defaultOpen={false} />
        <SidebarSeparator />
        <NavGroup title="النظام" items={systemItems} defaultOpen={false} />

        {user?.role === "admin" && (
          <>
            <SidebarSeparator />
            <NavGroup title="الإدارة" items={adminItems} defaultOpen={false} />
          </>
        )}
      </SidebarContent>

      {/* Footer */}
      <SidebarFooter className="border-t">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton
                  size="lg"
                  className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                >
                  <Avatar className="h-8 w-8 rounded-lg">
                    <AvatarImage src="" alt={user?.name || "User"} />
                    <AvatarFallback className="rounded-lg bg-primary/10 text-primary">
                      {user?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="grid flex-1 text-right text-sm leading-tight">
                    <span className="truncate font-semibold">{user?.name || "مستخدم"}</span>
                    <span className="truncate text-xs text-muted-foreground">{user?.email}</span>
                  </div>
                  <ChevronDown className="mr-auto size-4" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                side="top"
                align="start"
                sideOffset={4}
              >
                <DropdownMenuLabel className="p-0 font-normal">
                  <div className="flex items-center gap-2 px-1 py-1.5 text-right text-sm">
                    <Avatar className="h-8 w-8 rounded-lg">
                      <AvatarImage src="" alt={user?.name || "User"} />
                      <AvatarFallback className="rounded-lg bg-primary/10 text-primary">
                        {user?.name?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="grid flex-1 text-right text-sm leading-tight">
                      <span className="truncate font-semibold">{user?.name || "مستخدم"}</span>
                      <span className="truncate text-xs text-muted-foreground">{user?.email}</span>
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile">
                    <User className="ml-2 h-4 w-4" />
                    الملف الشخصي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">
                    <Settings className="ml-2 h-4 w-4" />
                    الإعدادات
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/help">
                    <HelpCircle className="ml-2 h-4 w-4" />
                    المساعدة
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => logout()} className="text-destructive">
                  <LogOut className="ml-2 h-4 w-4" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

