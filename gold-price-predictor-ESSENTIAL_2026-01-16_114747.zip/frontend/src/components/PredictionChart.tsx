// FILE: client/src/components/PredictionChart.tsx | PURPOSE: Display ML predictions with chart | OWNER: Frontend Team | LAST-AUDITED: 2025-11-25

import React, { useState } from 'react';
import { trpc } from '../lib/trpc';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  ComposedChart,
} from 'recharts';
// @ts-expect-error - antd may not be installed
import { Button, Card, Select, Spin, Alert, Statistic, Row, Col } from 'antd';
// @ts-expect-error - @ant-design/icons may not be installed
import { RocketOutlined, LineChartOutlined } from '@ant-design/icons';

const { Option } = Select;

interface PredictionData {
  date: string;
  predicted_price: number;
  lower_bound: number;
  upper_bound: number;
}

interface PredictionChartProps {
  symbol?: string;
}

export const PredictionChart: React.FC<PredictionChartProps> = ({ symbol: initialSymbol = 'GC=F' }) => {
  const [symbol, setSymbol] = useState(initialSymbol);
  const [days, setDays] = useState(7);
  const [predictions, setPredictions] = useState<PredictionData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePredict = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:8000/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symbol,
          days,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setPredictions(data.predictions);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch predictions');
      console.error('Prediction error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getSymbolName = (sym: string) => {
    const names: Record<string, string> = {
      'GC=F': 'Gold',
      'SI=F': 'Silver',
      'BTC-USD': 'Bitcoin',
    };
    return names[sym] || sym;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const avgPrediction = predictions.length > 0
    ? predictions.reduce((sum, p) => sum + p.predicted_price, 0) / predictions.length
    : 0;

  const maxPrediction = predictions.length > 0
    ? Math.max(...predictions.map(p => p.predicted_price))
    : 0;

  const minPrediction = predictions.length > 0
    ? Math.min(...predictions.map(p => p.predicted_price))
    : 0;

  return (
    <Card
      title={
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <RocketOutlined />
          <span>AI Price Predictions - {getSymbolName(symbol)}</span>
        </div>
      }
      extra={
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <Select value={symbol} onChange={setSymbol} style={{ width: 150 }}>
            <Option value="GC=F">Gold (GC=F)</Option>
            <Option value="SI=F">Silver (SI=F)</Option>
            <Option value="BTC-USD">Bitcoin (BTC-USD)</Option>
          </Select>
          <Select value={days} onChange={setDays} style={{ width: 120 }}>
            <Option value={7}>7 Days</Option>
            <Option value={14}>14 Days</Option>
            <Option value={30}>30 Days</Option>
            <Option value={60}>60 Days</Option>
            <Option value={90}>90 Days</Option>
          </Select>
          <Button
            type="primary"
            icon={<LineChartOutlined />}
            onClick={handlePredict}
            loading={isLoading}
          >
            Predict
          </Button>
        </div>
      }
    >
      {error && (
        <Alert
          message="Prediction Error"
          description={error}
          type="error"
          showIcon
          closable
          style={{ marginBottom: 16 }}
        />
      )}

      {predictions.length > 0 && (
        <>
          <Row gutter={16} style={{ marginBottom: 24 }}>
            <Col span={8}>
              <Statistic
                title="Average Prediction"
                value={avgPrediction}
                precision={2}
                prefix="$"
                valueStyle={{ color: '#3f8600' }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="Maximum"
                value={maxPrediction}
                precision={2}
                prefix="$"
                valueStyle={{ color: '#cf1322' }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="Minimum"
                value={minPrediction}
                precision={2}
                prefix="$"
                valueStyle={{ color: '#1890ff' }}
              />
            </Col>
          </Row>

          <ResponsiveContainer width="100%" height={400}>
            <ComposedChart data={predictions}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip formatter={(value: number) => formatPrice(value)} />
              <Legend />
              <Area
                type="monotone"
                dataKey="upper_bound"
                fill="#8884d8"
                stroke="#8884d8"
                fillOpacity={0.3}
                name="Upper Bound"
              />
              <Area
                type="monotone"
                dataKey="lower_bound"
                fill="#82ca9d"
                stroke="#82ca9d"
                fillOpacity={0.3}
                name="Lower Bound"
              />
              <Line
                type="monotone"
                dataKey="predicted_price"
                stroke="#ff7300"
                strokeWidth={3}
                dot={{ r: 5 }}
                name="Predicted Price"
              />
            </ComposedChart>
          </ResponsiveContainer>
        </>
      )}

      {isLoading && (
        <div style={{ textAlign: 'center', padding: '60px 0' }}>
          <Spin size="large" tip="Generating predictions..." />
        </div>
      )}

      {!isLoading && predictions.length === 0 && !error && (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#999' }}>
          <LineChartOutlined style={{ fontSize: 48, marginBottom: 16 }} />
          <p>Select an asset and click "Predict" to see AI-powered price predictions</p>
        </div>
      )}
    </Card>
  );
};

