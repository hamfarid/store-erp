/**
 * Mobile Navigation Component
 * Bottom navigation bar for mobile devices
 */

import { useState } from 'react';
import { useLocation } from 'wouter';
import {
  Home,
  TrendingUp,
  Bell,
  Briefcase,
  Settings,
  Menu,
  BarChart3,
  // Unused: X
  FileText,
  Shield,
  Bot,
  LineChart,
  Activity,
  Calculator,
  History,
  BookOpen,
  GraduationCap,
  AlertTriangle,
  Layers,
} from 'lucide-react';
// import { Button } from '@/components/ui/button'; // Unused
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { useAuth } from '@/_core/hooks/useAuth';

interface NavItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  labelAr: string;
  path: string;
  requiresAuth?: boolean;
  adminOnly?: boolean;
}

const mainNavItems: NavItem[] = [
  { icon: Home, label: 'Home', labelAr: 'الرئيسية', path: '/' },
  { icon: TrendingUp, label: 'Predictions', labelAr: 'التوقعات', path: '/predict', requiresAuth: true },
  { icon: Bell, label: 'Alerts', labelAr: 'التنبيهات', path: '/alerts', requiresAuth: true },
  { icon: Briefcase, label: 'Portfolio', labelAr: 'المحفظة', path: '/portfolio', requiresAuth: true },
  { icon: Settings, label: 'Settings', labelAr: 'الإعدادات', path: '/settings', requiresAuth: true },
];

const additionalNavItems: NavItem[] = [
  { icon: BarChart3, label: 'Dashboard', labelAr: 'لوحة التحكم', path: '/dashboard', requiresAuth: true },
  { icon: Layers, label: 'Comprehensive', labelAr: 'الإدارة الشاملة', path: '/comprehensive', requiresAuth: true },
  { icon: Bell, label: 'Notifications', labelAr: 'الإشعارات', path: '/notifications', requiresAuth: true },
  { icon: LineChart, label: 'Predictions', labelAr: 'التوقعات', path: '/predictions', requiresAuth: true },
  { icon: LineChart, label: 'Technical Analysis', labelAr: 'التحليل الفني', path: '/technical-analysis', requiresAuth: true },
  { icon: Activity, label: 'Trading Signals', labelAr: 'إشارات التداول', path: '/trading-signals', requiresAuth: true },
  { icon: Activity, label: 'Price Points', labelAr: 'نقاط السعر', path: '/price-points', requiresAuth: true },
  { icon: Calculator, label: 'Break Even', labelAr: 'حاسبة التعادل', path: '/break-even-calculator', requiresAuth: true },
  { icon: History, label: 'History', labelAr: 'سجل التوقعات', path: '/history', requiresAuth: true },
  { icon: BarChart3, label: 'Accuracy', labelAr: 'دقة التوقعات', path: '/prediction-accuracy', requiresAuth: true },
  { icon: BarChart3, label: 'Analytics', labelAr: 'التحليلات والمراقبة', path: '/analytics-monitoring', requiresAuth: true },
  { icon: Activity, label: 'ML Models', labelAr: 'نماذج ML', path: '/ml-models', requiresAuth: true },
  { icon: Activity, label: 'System Health', labelAr: 'صحة النظام', path: '/system-health', requiresAuth: true },
  { icon: BookOpen, label: 'Expert Opinions', labelAr: 'آراء الخبراء', path: '/expert-opinions', requiresAuth: true },
  { icon: Activity, label: 'Fear & Greed', labelAr: 'مؤشر الخوف والطمع', path: '/fear-greed', requiresAuth: false },
  { icon: TrendingUp, label: 'News Sentiment', labelAr: 'تحليل الأخبار', path: '/news-sentiment', requiresAuth: false },
  { icon: GraduationCap, label: 'Learning', labelAr: 'التعلم', path: '/learning', requiresAuth: true },
  { icon: AlertTriangle, label: 'Drift Detection', labelAr: 'كشف الانحراف', path: '/drift-detection', requiresAuth: true },
  { icon: FileText, label: 'Reports', labelAr: 'التقارير', path: '/reports', requiresAuth: true },
  { icon: Bot, label: 'AI Assistant', labelAr: 'المساعد الذكي', path: '/ai-tasks', requiresAuth: true },
  { icon: Shield, label: 'Security', labelAr: 'الأمان', path: '/security', requiresAuth: true, adminOnly: true },
  { icon: Shield, label: 'Admin', labelAr: 'الإدارة', path: '/admin', requiresAuth: true, adminOnly: true },
];

export default function MobileNav() {
  const [location, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const isAdmin = user?.role === 'admin';

  const handleNavigation = (path: string) => {
    setLocation(path);
    setIsOpen(false);
  };

  const filterNavItems = (items: NavItem[]) => {
    return items.filter(item => {
      if (item.requiresAuth && !isAuthenticated) {
        return false;
      }
      if (item.adminOnly && !isAdmin) {
        return false;
      }
      return true;
    });
  };

  const visibleMainItems = filterNavItems(mainNavItems);
  const visibleAdditionalItems = filterNavItems(additionalNavItems);

  return (
    <>
      {/* Bottom Navigation Bar - Mobile Only */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border z-50 safe-area-inset-bottom">
        <div className="flex items-center justify-around h-16 px-2">
          {visibleMainItems.slice(0, 4).map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;

            return (
              <button
                key={item.path}
                onClick={() => handleNavigation(item.path)}
                className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                  isActive
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="h-5 w-5 mb-1" />
                <span className="text-xs">{item.labelAr}</span>
              </button>
            );
          })}

          {/* More Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <button className="flex flex-col items-center justify-center flex-1 h-full text-muted-foreground hover:text-foreground transition-colors">
                <Menu className="h-5 w-5 mb-1" />
                <span className="text-xs">المزيد</span>
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh] rounded-t-2xl">
              <SheetHeader>
                <SheetTitle className="text-right">القائمة الكاملة</SheetTitle>
              </SheetHeader>

              <div className="mt-6 space-y-2">
                {/* Main Items */}
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground px-3 mb-2">القائمة الرئيسية</p>
                  {visibleMainItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location === item.path;

                    return (
                      <button
                        key={item.path}
                        onClick={() => handleNavigation(item.path)}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-colors ${
                          isActive
                            ? 'bg-primary text-primary-foreground'
                            : 'hover:bg-muted'
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                        <span className="text-sm font-medium">{item.labelAr}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Additional Items */}
                {visibleAdditionalItems.length > 0 && (
                  <div className="space-y-1 pt-4">
                    <p className="text-sm font-medium text-muted-foreground px-3 mb-2">المزيد</p>
                    {visibleAdditionalItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = location === item.path;

                      return (
                        <button
                          key={item.path}
                          onClick={() => handleNavigation(item.path)}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-colors ${
                            isActive
                              ? 'bg-primary text-primary-foreground'
                              : 'hover:bg-muted'
                          }`}
                        >
                          <Icon className="h-5 w-5" />
                          <span className="text-sm font-medium">{item.labelAr}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* User Info */}
                {isAuthenticated && user && (
                  <div className="pt-4 mt-4 border-t">
                    <div className="px-3 py-2">
                      <p className="text-sm font-medium">{user.name || 'مستخدم'}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                      {isAdmin && (
                        <span className="inline-block mt-2 px-2 py-1 text-xs bg-primary/10 text-primary rounded">
                          مدير
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>

      {/* Spacer to prevent content from being hidden behind bottom nav */}
      <div className="md:hidden h-16" />
    </>
  );
}

