/**
 * Page Wrapper Component
 * Wraps pages with consistent layout, transitions, and error handling
 */

import { ReactNode } from "react";
import { PageTransition } from "./PageTransition";
import ErrorBoundary from "./ErrorBoundary";

interface PageWrapperProps {
  children: ReactNode;
  enableTransition?: boolean;
}

export function PageWrapper({ children, enableTransition = true }: PageWrapperProps) {
  const content = <ErrorBoundary>{children}</ErrorBoundary>;

  if (enableTransition) {
    return <PageTransition>{content}</PageTransition>;
  }

  return content;
}

