/**
 * NotificationToast Component - Toast Notifications with Arabic RTL
 * Part of Global Professional Core Prompt v23.0 Implementation  
 * Task: T121 (Phase 5 - Alerts Frontend)
 * 
 * Features:
 * - Slide-in animation from right (RTL)
 * - Auto-dismiss with customizable duration
 * - Action buttons
 * - Type-based styling
 * - Multiple toast stacking
 */

import { useEffect } from 'react';
import { toast as sonnerToast, Toaster } from 'sonner';
import { Bell, CheckCircle2, XCircle, AlertTriangle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Notification, AlertTriggeredPayload } from '@/hooks/useNotifications';

export interface ToastProps {
  type?: 'success' | 'error' | 'warning' | 'info' | 'alert';
  title: string;
  description?: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

/**
 * Toast notification system configured for Arabic RTL
 */
export function NotificationToastProvider() {
  return (
    <Toaster
      position="top-left"  // Use top-left for RTL (appears on right side)
      dir="rtl"
      richColors
      closeButton
      toastOptions={{
        style: {
          fontFamily: 'var(--font-arabic, Cairo, sans-serif)',
          direction: 'rtl',
          textAlign: 'right',
        },
        className: 'toast-rtl',
        duration: 5000,
      }}
    />
  );
}

/**
 * Show a notification toast
 */
export function showToast({ type = 'info', title, description, duration = 5000, action }: ToastProps) {
  const { icon, className } = getToastStyles(type);

  sonnerToast(title, {
    description,
    duration,
    icon,
    className,
    action: action ? {
      label: action.label,
      onClick: action.onClick,
    } : undefined,
  });
}

/**
 * Show an alert-triggered toast notification
 * Special formatting for alert triggers
 */
export function showAlertTriggeredToast(alert: AlertTriggeredPayload) {
  const conditionText = {
    gt: 'تجاوز',
    gte: 'وصل إلى',
    lt: 'انخفض عن',
    lte: 'وصل إلى',
    eq: 'يساوي',
  }[alert.condition] || 'تحقق';

  const icon = (
    <div className="flex-shrink-0 rounded-full bg-amber-100 dark:bg-amber-900/30 p-2">
      <Bell className="h-5 w-5 text-amber-600 dark:text-amber-400" />
    </div>
  );

  sonnerToast('🔔 تم تفعيل التنبيه', {
    description: (
      <div className="space-y-1">
        <p className="font-medium">
          {alert.assetNameAr} {conditionText} {formatNumber(alert.targetValue)}
        </p>
        <p className="text-sm text-muted-foreground">
          السعر الحالي: {formatNumber(alert.currentPrice)}
        </p>
      </div>
    ),
    duration: 10000,
    icon,
    className: 'toast-alert-triggered',
    action: {
      label: 'عرض التفاصيل',
      onClick: () => {
        window.location.href = `/alerts/view/${alert.alertId}`;
      },
    },
  });
}

/**
 * Show a new notification toast
 */
export function showNotificationToast(notification: Notification) {
  const { icon, className } = getToastStyles(notification.type);

  sonnerToast(notification.titleAr, {
    description: notification.messageAr,
    duration: 5000,
    icon,
    className,
    action: notification.metadata?.alertId ? {
      label: 'عرض',
      onClick: () => {
        window.location.href = `/alerts/view/${notification.metadata!.alertId}`;
      },
    } : undefined,
  });
}

/**
 * Utility functions
 */

function getToastStyles(type: string) {
  const styles = {
    success: {
      icon: <CheckCircle2 className="h-5 w-5 text-emerald-600" />,
      className: 'toast-success',
    },
    error: {
      icon: <XCircle className="h-5 w-5 text-red-600" />,
      className: 'toast-error',
    },
    warning: {
      icon: <AlertTriangle className="h-5 w-5 text-amber-600" />,
      className: 'toast-warning',
    },
    info: {
      icon: <Info className="h-5 w-5 text-blue-600" />,
      className: 'toast-info',
    },
    alert: {
      icon: <Bell className="h-5 w-5 text-amber-600" />,
      className: 'toast-alert',
    },
  };

  return styles[type as keyof typeof styles] || styles.info;
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat('ar-EG', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

/**
 * Custom toast component for advanced use cases
 * This can be used for more complex toast layouts
 */
export interface CustomToastProps {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  actions?: Array<{
    label: string;
    onClick: () => void;
    variant?: 'default' | 'destructive';
  }>;
  onClose?: () => void;
}

export function CustomToast({ title, description, icon, actions, onClose }: CustomToastProps) {
  return (
    <div className="flex items-start gap-3 p-4 bg-card rounded-lg border shadow-lg">
      {icon && (
        <div className="flex-shrink-0 mt-0.5">
          {icon}
        </div>
      )}
      
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm mb-1">{title}</p>
        {description && (
          <p className="text-sm text-muted-foreground">{description}</p>
        )}
        
        {actions && actions.length > 0 && (
          <div className="flex items-center gap-2 mt-3">
            {actions.map((action, index) => (
              <button
                key={index}
                onClick={action.onClick}
                className={cn(
                  'text-xs font-medium px-3 py-1.5 rounded-md transition-colors',
                  action.variant === 'destructive'
                    ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
                    : 'bg-primary text-primary-foreground hover:bg-primary/90'
                )}
              >
                {action.label}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {onClose && (
        <button
          onClick={onClose}
          className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
        >
          <XCircle className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}

/**
 * Hook to listen for WebSocket events and show toasts
 * Use this in the root App component
 */
export function useToastNotifications() {
  useEffect(() => {
    // This will be populated when WebSocket service is implemented
    // For now, toasts are triggered manually via the useNotifications hook
    
    return () => {
      // Cleanup
    };
  }, []);
}

/**
 * Success toast shorthand
 */
export const toastSuccess = (title: string, description?: string) => {
  showToast({ type: 'success', title, description });
};

/**
 * Error toast shorthand
 */
export const toastError = (title: string, description?: string) => {
  showToast({ type: 'error', title, description });
};

/**
 * Warning toast shorthand
 */
export const toastWarning = (title: string, description?: string) => {
  showToast({ type: 'warning', title, description });
};

/**
 * Info toast shorthand
 */
export const toastInfo = (title: string, description?: string) => {
  showToast({ type: 'info', title, description });
};

// CSS for toast animations (to be added to global styles)
/*
.toast-rtl {
  animation: slideInFromRight 0.3s ease-out;
}

@keyframes slideInFromRight {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.toast-alert-triggered {
  border-right: 4px solid theme('colors.amber.500');
}

.toast-success {
  border-right: 4px solid theme('colors.emerald.500');
}

.toast-error {
  border-right: 4px solid theme('colors.red.500');
}

.toast-warning {
  border-right: 4px solid theme('colors.amber.500');
}

.toast-info {
  border-right: 4px solid theme('colors.blue.500');
}

[dir="rtl"] [data-sonner-toaster] {
  right: auto;
  left: 0;
}
*/
