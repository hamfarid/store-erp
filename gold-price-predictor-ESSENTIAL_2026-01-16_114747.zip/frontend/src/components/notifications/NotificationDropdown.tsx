/**
 * NotificationDropdown Component - Real-time Notification Center
 * Part of Global Professional Core Prompt v23.0 Implementation
 * Task: T120 (Phase 5 - Alerts Frontend)
 * 
 * Features:
 * - Real-time WebSocket notifications
 * - Arabic RTL design
 * - Unread count badge
 * - Type-based icons and colors
 * - Mark as read/delete actions
 */

import { Bell, Check, X, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { 
  useNotifications, 
  formatRelativeTime, 
  getNotificationIcon, 
  getNotificationColor,
  type Notification,
} from '@/hooks/useNotifications';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

interface NotificationDropdownProps {
  className?: string;
}

export function NotificationDropdown({ className }: NotificationDropdownProps) {
  const { 
    notifications, 
    unreadCount, 
    isConnected,
    markAsRead, 
    markAllAsRead, 
    deleteNotification 
  } = useNotifications();

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className={cn('relative', className)}
          aria-label={`الإشعارات${unreadCount > 0 ? ` (${unreadCount} غير مقروء)` : ''}`}
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 min-w-[20px] flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
          {/* Connection status indicator */}
          {isConnected && (
            <span className="absolute bottom-0 right-0 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-background" />
          )}
        </Button>
      </PopoverTrigger>

      <PopoverContent 
        className="w-[400px] p-0" 
        align="end"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">الإشعارات</h3>
            {unreadCount > 0 && (
              <Badge variant="secondary" className="text-xs">
                {unreadCount} جديد
              </Badge>
            )}
          </div>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllAsRead}
              className="text-xs"
            >
              <Check className="ml-1 h-3 w-3" />
              تعليم الكل كمقروء
            </Button>
          )}
        </div>

        {/* Notifications List */}
        <ScrollArea className="h-[400px]">
          {notifications.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="divide-y">
              {notifications.slice(0, 10).map((notification) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  onMarkAsRead={markAsRead}
                  onDelete={deleteNotification}
                />
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        {notifications.length > 0 && (
          <div className="border-t p-3">
            <Link href="/notifications">
              <Button variant="ghost" className="w-full justify-center" size="sm">
                عرض جميع الإشعارات
                <ExternalLink className="mr-2 h-3 w-3" />
              </Button>
            </Link>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

interface NotificationItemProps {
  notification: Notification;
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
}

function NotificationItem({ notification, onMarkAsRead, onDelete }: NotificationItemProps) {
  const handleClick = () => {
    if (!notification.isRead) {
      onMarkAsRead(notification.id);
    }
    // Navigate to relevant page if metadata exists
    if (notification.metadata?.alertId) {
      window.location.href = `/alerts/view/${notification.metadata.alertId}`;
    } else if (notification.metadata?.assetId) {
      window.location.href = `/assets/${notification.metadata.assetId}`;
    }
  };

  return (
    <div
      className={cn(
        'p-4 hover:bg-muted/50 transition-colors cursor-pointer relative group',
        !notification.isRead && 'bg-primary/5'
      )}
      onClick={handleClick}
    >
      {/* Unread indicator */}
      {!notification.isRead && (
        <div className="absolute top-4 right-2 h-2 w-2 rounded-full bg-primary" />
      )}

      <div className="flex items-start gap-3">
        {/* Icon */}
        <div className={cn(
          'flex-shrink-0 text-2xl',
          getNotificationColor(notification.type)
        )}>
          {getNotificationIcon(notification.type)}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <p className={cn(
            'text-sm font-medium mb-1',
            !notification.isRead && 'font-semibold'
          )}>
            {notification.titleAr}
          </p>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {notification.messageAr}
          </p>
          
          {/* Metadata display for alerts */}
          {notification.metadata && notification.type === 'alert' && (
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              {notification.metadata.currentPrice && (
                <span className="font-semibold text-foreground">
                  ${notification.metadata.currentPrice.toLocaleString()}
                </span>
              )}
              {notification.metadata.targetValue && (
                <span>
                  الهدف: ${notification.metadata.targetValue.toLocaleString()}
                </span>
              )}
            </div>
          )}

          <p className="text-xs text-muted-foreground mt-1">
            {formatRelativeTime(notification.createdAt)}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {!notification.isRead && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onMarkAsRead(notification.id);
              }}
              aria-label="تعليم كمقروء"
            >
              <Check className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(notification.id);
            }}
            aria-label="حذف"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center">
      <div className="rounded-full bg-muted p-4 mb-4">
        <Bell className="h-8 w-8 text-muted-foreground" />
      </div>
      <p className="text-sm font-medium mb-1">لا توجد إشعارات</p>
      <p className="text-xs text-muted-foreground">
        ستظهر الإشعارات الجديدة هنا
      </p>
    </div>
  );
}
