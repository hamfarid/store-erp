// File: /home/ubuntu/asset_predictor_ui/client/src/api/client.ts
/**
 * API Client for Backend Communication
 * Handles all HTTP requests with authentication and error handling
 */

import axios, { AxiosInstance, AxiosError, AxiosRequestConfig } from "axios";

const API_BASE_URL =
  import.meta.env.VITE_API_URL || "http://localhost:8000/api";

export interface ApiError {
  error: string;
  status_code: number;
  timestamp: string;
}

export interface PredictionRequest {
  symbol: string;
  horizon: "short" | "medium" | "long";
  include_sentiment?: boolean;
  include_economic_data?: boolean;
}

export interface PredictionResponse {
  symbol: string;
  current_price: number;
  predicted_price: number;
  change_percent: number;
  confidence: number;
  horizon: string;
  timestamp: string;
  sentiment_score?: number;
  economic_indicators?: {
    inflation?: number;
    interest_rate?: number;
    [key: string]: unknown;
  };
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface UserResponse {
  id: number;
  username: string;
  email: string;
  is_2fa_enabled: boolean;
  created_at: string;
}

export interface TwoFactorSetupResponse {
  qr_code: string;
  secret: string;
}

class ApiClient {
  private client: AxiosInstance;
  private refreshTokenPromise: Promise<string> | null = null;
  private csrfToken: string | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      withCredentials: true, // Required for cookies (CSRF & Session)
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Request interceptor
    this.client.interceptors.request.use(
      config => {
        // Add JWT token
        const token = this.getToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }

        // Add CSRF token for state-changing requests
        if (
          config.method &&
          ["post", "put", "delete", "patch"].includes(
            config.method.toLowerCase()
          )
        ) {
          const csrfToken = this.getCsrfToken();
          if (csrfToken) {
            config.headers["X-CSRF-Token"] = csrfToken;
          }
        }

        return config;
      },
      error => Promise.reject(error)
    );

    // Response interceptor
    this.client.interceptors.response.use(
      response => {
        // Update CSRF token if provided in response headers
        const newCsrfToken = response.headers["x-csrf-token"];
        if (newCsrfToken) {
          this.csrfToken = newCsrfToken;
          // eslint-disable-next-line no-console
          console.debug("[API Client] CSRF token updated from header");
        }
        return response;
      },
      async (error: AxiosError<ApiError>) => {
        const originalRequest = error.config as AxiosRequestConfig & {
          _retry?: boolean;
        };

        // Handle 401 errors (token expired)
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const newToken = await this.refreshToken();
            if (newToken && originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
              return this.client(originalRequest);
            }
          } catch (refreshError) {
            // Refresh failed, logout user
            this.logout();
            window.location.href = "/login";
            return Promise.reject(refreshError);
          }
        }

        // Handle other errors
        return Promise.reject(this.handleError(error));
      }
    );
  }

  private getToken(): string | null {
    return localStorage.getItem("access_token");
  }

  private getRefreshToken(): string | null {
    return localStorage.getItem("refresh_token");
  }

  private setTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem("access_token", accessToken);
    localStorage.setItem("refresh_token", refreshToken);
  }

  private clearTokens(): void {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
  }

  private getCsrfToken(): string | null {
    return this.csrfToken;
  }

  private async refreshToken(): Promise<string> {
    // Prevent multiple simultaneous refresh requests
    if (this.refreshTokenPromise) {
      return this.refreshTokenPromise;
    }

    this.refreshTokenPromise = (async () => {
      try {
        const refreshToken = this.getRefreshToken();
        if (!refreshToken) {
          throw new Error("No refresh token available");
        }

        const response = await axios.post<TokenResponse>(
          `${API_BASE_URL}/auth/refresh`,
          { refresh_token: refreshToken }
        );

        const { access_token, refresh_token: new_refresh_token } =
          response.data;
        this.setTokens(access_token, new_refresh_token);

        return access_token;
      } finally {
        this.refreshTokenPromise = null;
      }
    })();

    return this.refreshTokenPromise;
  }

  private handleError(error: AxiosError<ApiError>): Error {
    if (error.response) {
      // Server responded with error
      const apiError = error.response.data;
      return new Error(apiError.error || "An error occurred");
    } else if (error.request) {
      // Request made but no response
      return new Error(
        "No response from server. Please check your connection."
      );
    } else {
      // Error in request setup
      return new Error(error.message || "An unexpected error occurred");
    }
  }

  // ==================== Authentication ====================

  async login(credentials: LoginRequest): Promise<TokenResponse> {
    const formData = new FormData();
    formData.append("username", credentials.username);
    formData.append("password", credentials.password);

    const response = await this.client.post<TokenResponse>(
      "/auth/login",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );

    this.setTokens(response.data.access_token, response.data.refresh_token);
    return response.data;
  }

  async register(userData: RegisterRequest): Promise<TokenResponse> {
    const response = await this.client.post<TokenResponse>(
      "/auth/register",
      userData
    );
    this.setTokens(response.data.access_token, response.data.refresh_token);
    return response.data;
  }

  logout(): void {
    this.clearTokens();
  }

  async getCurrentUser(): Promise<UserResponse> {
    const response = await this.client.get<UserResponse>("/auth/me");
    return response.data;
  }

  // ==================== 2FA ====================

  async setup2FA(): Promise<TwoFactorSetupResponse> {
    const response =
      await this.client.post<TwoFactorSetupResponse>("/auth/2fa/setup");
    return response.data;
  }

  async verify2FA(token: string): Promise<{ message: string }> {
    const response = await this.client.post("/auth/2fa/verify", { token });
    return response.data;
  }

  async disable2FA(token: string): Promise<{ message: string }> {
    const response = await this.client.post("/auth/2fa/disable", { token });
    return response.data;
  }

  // ==================== Predictions ====================

  async getPrediction(request: PredictionRequest): Promise<PredictionResponse> {
    const response = await this.client.post<PredictionResponse>(
      "/predict",
      request
    );
    return response.data;
  }

  async getPredictionHistory(
    limit: number = 50,
    offset: number = 0
  ): Promise<PredictionResponse[]> {
    const response = await this.client.get<PredictionResponse[]>(
      "/predictions/history",
      {
        params: { limit, offset },
      }
    );
    return response.data;
  }

  // ==================== Generic HTTP Methods ====================

  async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.get<T>(url, config);
    return response.data;
  }

  async post<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<T> {
    const response = await this.client.post<T>(url, data, config);
    return response.data;
  }

  async put<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<T> {
    const response = await this.client.put<T>(url, data, config);
    return response.data;
  }

  async patch<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<T> {
    const response = await this.client.patch<T>(url, data, config);
    return response.data;
  }

  async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.delete<T>(url, config);
    return response.data;
  }

  // ==================== Health Check ====================

  async healthCheck(): Promise<{
    status: string;
    timestamp: string;
    version: string;
  }> {
    const response = await this.client.get("/health");
    return response.data;
  }
}

// Export singleton instance
export const apiClient = new ApiClient();
export default apiClient;
