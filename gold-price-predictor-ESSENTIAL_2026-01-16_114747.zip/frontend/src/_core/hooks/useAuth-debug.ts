import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useMemo, useRef } from "react";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = getLoginUrl() } =
    options ?? {};
  const utils = trpc.useUtils();
  
  // Debug: Track render count
  const renderCount = useRef(0);
  renderCount.current += 1;
  
  console.log(`[useAuth] Render #${renderCount.current}`, {
    redirectOnUnauthenticated,
    redirectPath,
  });

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  console.log(`[useAuth] meQuery state:`, {
    isLoading: meQuery.isLoading,
    isFetching: meQuery.isFetching,
    data: meQuery.data,
    error: meQuery.error,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      console.log('[useAuth] Logout success');
      utils.auth.me.setData(undefined, null);
    },
  });

  const logout = useCallback(async () => {
    console.log('[useAuth] Logout called');
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        console.log('[useAuth] Logout: Already unauthorized');
        return;
      }
      console.error('[useAuth] Logout error:', error);
      throw error;
    } finally {
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
    }
  }, [logoutMutation, utils]);

  // Save to localStorage in useEffect to avoid side effects in render
  useEffect(() => {
    console.log('[useAuth] localStorage effect triggered', { data: meQuery.data });
    if (meQuery.data) {
      localStorage.setItem(
        "manus-runtime-user-info",
        JSON.stringify(meQuery.data)
      );
    }
  }, [meQuery.data]);

  const state = useMemo(() => {
    const newState = {
      user: meQuery.data ?? null,
      loading: meQuery.isLoading || logoutMutation.isPending,
      error: meQuery.error ?? logoutMutation.error ?? null,
      isAuthenticated: Boolean(meQuery.data),
    };
    console.log('[useAuth] State computed:', newState);
    return newState;
  }, [
    meQuery.data,
    meQuery.error,
    meQuery.isLoading,
    logoutMutation.error,
    logoutMutation.isPending,
  ]);

  useEffect(() => {
    console.log('[useAuth] Redirect effect triggered', {
      redirectOnUnauthenticated,
      isLoading: meQuery.isLoading,
      isPending: logoutMutation.isPending,
      hasUser: Boolean(state.user),
      currentPath: window.location.pathname,
      redirectPath,
    });
    
    if (!redirectOnUnauthenticated) {
      console.log('[useAuth] Redirect disabled');
      return;
    }
    if (meQuery.isLoading || logoutMutation.isPending) {
      console.log('[useAuth] Still loading, skip redirect');
      return;
    }
    if (state.user) {
      console.log('[useAuth] User authenticated, skip redirect');
      return;
    }
    if (typeof window === "undefined") {
      console.log('[useAuth] SSR environment, skip redirect');
      return;
    }
    if (window.location.pathname === redirectPath) {
      console.log('[useAuth] Already on redirect path, skip redirect');
      return;
    }

    console.log('[useAuth] Redirecting to:', redirectPath);
    window.location.href = redirectPath;
  }, [
    redirectOnUnauthenticated,
    redirectPath,
    logoutMutation.isPending,
    meQuery.isLoading,
    state.user,
  ]);

  return {
    ...state,
    refresh: () => {
      console.log('[useAuth] Refresh called');
      return meQuery.refetch();
    },
    logout,
  };
}

