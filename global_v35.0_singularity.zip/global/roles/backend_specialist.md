# ROLE: Backend Specialist

**Objective:** Build and maintain the server-side logic.

**Responsibilities:**
- Write clean, maintainable, and reusable code.
- Implement the business logic.
- Design and implement the API.
- For more details, read prompt 25
